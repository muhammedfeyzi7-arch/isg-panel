# IBYS Mobil — API Sözleşmesi

**Tarih:** 2026-10-21  
**Kaynak:** `src/lib/**` içindeki gerçek çağrı yerleri taranarak çıkarıldı. Uydurma uç yok.  
**Kural:** Mobil istemci **sadece** bu dosyadaki uçları kullanır. Yeni tablo/view/RPC açmaz.

---

## 1. Bağlantı

| Değişken | Kaynak |
|---|---|
| `SUPABASE_URL` | Self-hosted GoTrue/PostgREST kökü, TLS zorunlu (`https://…`) |
| `SUPABASE_ANON_KEY` | `anon` rolü anahtarı. Mobilde bulunan **tek** anahtar |

Web tarafı `VITE_PUBLIC_SUPABASE_URL` / `VITE_PUBLIC_SUPABASE_ANON_KEY` kullanıyor; mobil aynı değerleri kendi `.env` / EAS secret'ına alır. Değerler repoya yazılmaz.

Edge Function çağrısı: `https://<SUPABASE_URL>/functions/v1/<slug>` + `Authorization: Bearer <kullanıcı access_token>`.

---

## 2. Auth

| İşlem | Yol | Not |
|---|---|---|
| Giriş | `POST /auth/v1/token?grant_type=password` | GoTrue |
| Token yenile | SDK otomatik | `autoRefreshToken` |
| Çıkış | `POST /auth/v1/logout` | Sunucuda refresh token iptal edilir |
| Şifre kodu gönder | Edge `sifre-dogrulama` → `{ action: 'kod-gonder', currentPassword }` | 6 hane, 10 dk, tek kullanım, 5 deneme |
| Şifre değiştir | Edge `sifre-dogrulama` → `{ action: 'sifre-degistir', code, newPassword, currentPassword }` | Sunucuda geçmiş kontrolü + diğer oturumların iptali |
| Şifre sıfırla (recovery) | Edge `sifre-dogrulama` → `{ action: 'sifirla-degistir', newPassword }` | Yalnız RECOVERY oturumu |
| Sıfırlama e-postası | Edge `send-reset-email` | |

**Yasak:** `auth.updateUser({ password })` doğrudan çağrısı. GUV-44 kapısını atlar.

**Oturum politikası:** 12 saat idle, 7 gün mutlak. Uygulama foreground'a döndüğünde kontrol; süre dolmuşsa `signOut()`.

---

## 3. Roller

`profiles.role` ∈ `admin`, `osgb_admin`, `uzman`, `hekim`, `firma` (legacy `osgb` görülebilir — `osgb_admin` gibi davranır).

Rol sadece **UI seçimi** içindir. Yetki daima RLS/RPC'de uygulanır. Mobil "ben adminim" diyerek veri genişletemez.

---

## 4. RPC kataloğu (mobilde kullanılacaklar)

Çağrı biçimi: `supabase.rpc('<ad>', { ...parametreler })`.

### 4.1 Atama / OSGB

| RPC | Parametre (koddan doğrulanmış) | Kullanım | Kapsam notu |
|---|---|---|---|
| `atama_firma_list` | `p_search`, `p_tehlike_sinifi`, `p_nace_kod`, `p_atama_durum`, `p_eksik_durum`, `p_sort_by`, `p_sort_dir`, `p_page`, `p_page_size` (hepsi default'lu) | Ekran 17 firma listesi | **Yalnız `admin` / `osgb_admin`.** Aksi halde `UNAUTHORIZED_ATAMA_FIRMA_LIST` (P0001). Dönüş `json` (pagination objesi, dizi değil) |
| `atama_rol_doygunluk` | yok | Ekran 17 doygunluk özeti | Kapsamı `atama_firma_list`'ten devralır. Dönüş: `{ isg_uzmani:{gereken,karsilanan}, isyeri_hekimi:{…}, dsp:{…}, toplamFirma }` |
| `atama_firma_yasal_mevcut_dakika` | `p_firma_ids: uuid[]` | Süre karşılaştırma | Dizi chunk'lanarak çağrılır |
| `atama_firma_durum_ozet` | yok | Firma durum özeti | |
| `atama_personel_list` | bkz. `assignmentService` | Personel seçimi | |
| `atama_personel_assignments` | `p_personel_id` | Personelin atamaları | |
| `atama_list`, `atama_create`, `atama_update`, `atama_deactivate` | sırasıyla `p_atama_id` vb. | Atama CRUD | `create/update` MVP-2 |
| `has_active_firma_assignment` | | Ön kontrol | |
| `firma_aktif_atamalar` | `p_firma_id` | Firma atamaları | |
| `hazard_change_detect` / `resolve_hazard_change_assignment` | | Tehlike sınıfı değişimi | MVP-2 |
| `uzman_hekim_firma_list` | yok | Ekran 5 / hekim firma listesi | `uzman` + `hekim` |
| `personel_backfill_mutabakat` | `p_apply: boolean` | Bakım işi | Mobilde çağrılmaz |

### 4.2 Personel

| RPC | Parametre | Kullanım |
|---|---|---|
| `personel_tckn_masked` | `p_ids: uuid[]` | **Listelerde tek yol.** Maskeli TCKNO |
| `personel_tckn_erisim` | `p_personel_id` | Tam TCKNO, sadece yetkili + log'lu. Her çağrı kullanıcıya açıkça gösterilir |
| `personel_saglik_ozet` | `p_personel_ids: uuid[]` | Sağlık özeti (chunk'lanır) |
| `personel_saglik_kaydi_ekle` | bkz. `firmaPersonelService:1283` | Ekran 12 muayene kaydı |
| `personel_aktif_bagimliliklar` | `p_personel_id` | Bağlılık kontrolü |
| `personel_isten_cikar` / `firma_personel_isten_cikar` | | MVP-2 |
| `auth_personel_bilgi` | yok | Oturum sahibinin personel kaydı |
| `firma_aktif_personel_sayisi` | `p_firma_id` | Ekran 14 KPI |
| `firma_evrak_sayilari` | `p_firma_id` | Ekran 14 KPI |

### 4.3 Ziyaret / saha

| RPC / uç | Parametre | Kullanım |
|---|---|---|
| Edge `ziyaret-planlama` | `options` (bkz. `planlamaService:29`, `planlamaIzinService:23`) | Ziyaret planı CRUD, başlat/bitir, izin |
| `ziyaret_durum_dagilimi` | bkz. `osgbDashboardService:1120` | Ekran 4 / 17 dağılım |
| Edge `saha-denetim` | `body` (action bazlı) | Uygunsuzluk listele/oluştur/kapatma talebi |
| Edge `saha-denetim-tutanak` | `body` | Saha tutanağı |
| Edge `ekipman` | `options` | Ekipman listele/kontrol/bakım |
| Edge `tutanak` | `body` | Tutanak oluştur/listele |

**Geofence:** ziyaret başlatma, web'deki ile aynı kuralla — firma koordinatı + yarıçap. Konum izni reddedilirse başlatma engellenir (web ile aynı davranış).

### 4.4 Diğer

| RPC | Kullanım |
|---|---|
| `resolve_profile_names` (`p_ids`) | Yükleyen adı çözümleme. **Kapsam:** `admin` OR aynı `osgb_id` OR kendi id → OSGB içi genişlik (Gözlem-03, kabul edilmiş) |
| `mesajlasma_unread_count` | Okunmamış sayısı rozeti |
| `create_support_ticket` | Destek talebi |
| `is_maintenance_active` | Bakım modu kontrolü — uygulama açılışında |
| `log_system_event` | Kritik işlem logu (mobil de yazar) |
| `admin_dashboard_summary` | Sadece `admin`. Mobilde kullanılmaz |

**Mobilde çağrılmayacaklar:** `search_system_logs`, `search_server_security_events`, `server_security_summary`, `set_maintenance`, `create/update/cancel_maintenance_plan`, `delete_osgb_permanent` (edge), `update_osgb_kurumsal_v2`, `firma_pasiflestir`, `teklif_*`, `create_announcement` / `update_announcement`, `personel_backfill_mutabakat`, `personel_isten_cikar_vadesi_gecenleri_uygula`.

---

## 5. Edge Function kataloğu

| Slug | Mobilde | Amaç |
|---|---|---|
| `sifre-dogrulama` | ✅ zorunlu | Şifre değiştirme/sıfırlama kapısı |
| `send-reset-email` | ✅ | Sıfırlama e-postası |
| `ziyaret-planlama` | ✅ | Ziyaret planı, başlat/bitir, izin |
| `saha-denetim` | ✅ | Uygunsuzluk yaşam döngüsü |
| `saha-denetim-tutanak` | ✅ | Saha tutanağı |
| `ekipman` | ✅ | Ekipman + kontrol + bakım |
| `tutanak` | ✅ | Tutanak |
| `evrak` / `evrak-klasor` | ✅ (yükle/görüntüle) | Evrak |
| `firma-sozlesme` | ⛔ | Sözleşme (web) |
| `isg-organizasyon`, `isg-gorevlendirme-yazi`, `isg-kurulu-*` | ⛔ | Web |
| `risk-ai-oneriler`, `emergency-plan-ai-suggestions` | ⛔ | Web (AI) |
| `mail`, `auth-log`, `osgb-status` | ⛔ | Web / sistem |
| `accept-invite`, `osgb-davet`, `firma-davet`, `personel-hesap` | ⛔ | Davet akışı web + e-posta |
| `profil-isimleri`, `tani-bilgi`, `firma-mesaj-hedef`, `ibys-gonderim`, `myk-belge`, `nace-import`, `personel-import`, `toplu-evrak` | ⛔ | Web |
| `osgb-delete-permanent` | ⛔ | Admin, web |

**Kural:** Hiçbir edge function mobil için yeniden yazılmaz. Mevcut sözleşme (`body.action` deseni) korunur.

---

## 6. Storage

| Bucket | Erişim | Kullanım |
|---|---|---|
| Mevcut public/tenant bucket'ları | RLS politikalı | Foto, evrak, belge |

Yükleme kuralı: `supabase.storage.from(bucket).upload(path, fileBlob, { contentType })` — **File/Blob doğrudan verilir**, `FormData` ile sarılmaz.

Yol deseni: `<osgb_id>/<firma_id>/<modul>/<uuid>.<ext>` — politika mevcut şemayla uyumlu olmalı; dökümden doğrulanır.

Boyut limitleri (GUV-24) sunucuda zorunlu; mobil yükleme öncesi küçültür (uzun kenar 1600px, JPEG %75).

---

## 7. Hata sözleşmesi

| Kod | Anlam | Mobil davranış |
|---|---|---|
| `P0001` + `UNAUTHORIZED_*` | Yetki yok | Toast + geri; retry yok |
| `42501` | RLS/izin reddi | "Bu işlem için yetkiniz yok" |
| `PGRST301` / 401 | Token geçersiz | Sessizce yenile, olmazsa çıkış |
| 404 (edge) | Fonksiyon yayında değil | Özellik gizlenir, çökme yok |
| Ağ hatası | Offline | Kuyruğa al, "gönderilecek" rozeti |

Kullanıcıya SQLSTATE, tablo adı, RPC adı **gösterilmez**.

---

## 8. Doğrulama sorguları (F0 — bir kez sunucuda çalıştır)

Bu blok, mobil ekibin kolon adı uydurmasını engeller. Çıktı dosya olarak saklanır.

```bash
cd /opt/ibys/supabase/docker
docker compose exec -T db psql -U supabase_admin -d postgres -P pager=off <<'SQL'
\echo '=== 1) RPC imzaları ==='
SELECT p.proname,
       pg_get_function_arguments(p.oid) AS args,
       pg_get_function_result(p.oid)    AS returns
FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
WHERE n.nspname = 'public' AND p.prokind = 'f'
ORDER BY p.proname;

\echo '=== 2) Mobilin okuyacağı tabloların kolonları ==='
SELECT table_name, ordinal_position, column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_schema = 'public'
  AND table_name IN (
    'profiles','osgb','firmalar','personel','atamalar','ziyaretler',
    'saha_denetimleri','uygunsuzluklar','ekipman','ekipman_kontrolleri',
    'tutanaklar','evraklar','bildirimler','saglik_kayitlari','teklifler'
  )
ORDER BY table_name, ordinal_position;

\echo '=== 3) Storage bucket ve limitleri ==='
SELECT id, name, public, file_size_limit, allowed_mime_types FROM storage.buckets ORDER BY name;

\echo '=== 4) Mobilin dokunacağı tablolarda RLS ==='
SELECT c.relname AS tablo, c.relrowsecurity AS rls_acik,
       count(p.polname) AS politika_sayisi
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace AND n.nspname = 'public'
LEFT JOIN pg_policy p ON p.polrelid = c.oid
WHERE c.relkind = 'r' AND c.relname IN (
  'profiles','firmalar','personel','atamalar','ziyaretler',
  'saha_denetimleri','uygunsuzluklar','ekipman','tutanaklar','evraklar','bildirimler'
)
GROUP BY c.relname, c.relrowsecurity
ORDER BY c.relname;
SQL
```

**Kabul:** Her ekranın veri kaynağı, bu dökümdeki gerçek kolon/RPC adıyla eşleşiyor. Eşleşmeyen varsa ekran kapsamdan çıkar, kolon uydurulmaz.

---

## 9. Sabit kurallar (özet)

1. `anon` dışında anahtar yok.
2. Yeni migration yok, şema değişmiyor.
3. TCKNO listelerde maskeli.
4. Şifre yazımı yalnız `sifre-dogrulama` üzerinden.
5. Mobil belge üretmez, tüketir.
6. Edge function'lar yeniden yazılmaz.
7. Her ekranın F0 dökümünde karşılığı var.