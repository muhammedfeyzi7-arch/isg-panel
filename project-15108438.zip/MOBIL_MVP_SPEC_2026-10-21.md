# IBYS Mobil — Saha Odaklı MVP Spesifikasyonu

**Tarih:** 2026-10-21  
**Karar:** Expo / React Native, saha odaklı MVP  
**Kritik kural:** Mevcut Supabase (self-hosted) aynen kullanılır. Yeni şema, yeni migration, yeni backend **yok**.

---

## 0. Karar özeti

| Konu | Karar |
|---|---|
| Platform | iOS + Android, tek kod tabanı |
| Framework | Expo (managed workflow, EAS Build) |
| Dil | TypeScript |
| Backend | **Mevcut** self-hosted Supabase (`VITE_PUBLIC_SUPABASE_URL`) |
| Veritabanı | **Mevcut** şema + 46 migration + RLS. Tek satır DDL değişmez |
| Edge Functions | **Mevcut** 60+ fonksiyon aynen çağrılır |
| Web panel | Olduğu gibi kalır. Mobil onun yerine geçmez, **saha tamamlayıcısıdır** |
| Rapor/PDF üretimi | Mobilde üretilmez — mevcut edge function / web tarafı |
| MVP kapsam | 20 ekran (aşağıda), 4 rol |

**MVP'in tek cümlelik hedefi:** Uzman sahada telefonla ziyaret başlatıp bitirebilsin, uygunsuzluk açıp fotoğraf ekleyebilsin, ekipman QR okutup kontrol girebilsin. Hekim muayene kaydı girebilsin. Firma kullanıcısı uygunsuzluğu kapatma talebi açabilsin. OSGB yöneticisi atama doygunluğunu görebilsin.

---

## 1. Değişmeyen omurga (dokunulmaz)

Bunlara **hiç** dokunulmaz. Mobil bunları tüketir:

| Katman | Neden dokunulmaz |
|---|---|
| `supabase/migrations/*.sql` (GUV-01 → GUV-46) | Pentest kapanışının tamamı burada. Yeniden yazılırsa 1 yıllık iş çöp olur |
| RLS politikaları (`auth_role()`, `auth_osgb_id()`, `auth_firma_id()`) | Tenant izolasyonunu bu sağlıyor; mobil için ayrı politika yazılmaz |
| `SECURITY DEFINER` RPC'ler (kapsam + `search_path` sabit) | Retest edilmiş, temiz |
| Edge Functions (service_role anahtarı sadece burada) | Mobilde service_role **asla** bulunmaz |
| `sifre-dogrulama` akışı (GUV-40/41/42/44) | Şifre yazımı DB kapısından geçiyor; mobil bunu atlayamaz |
| Storage bucket politikaları + boyut limitleri | `ensure` edilmiş bucket'lar aynen kullanılır |

> Mobil uygulama, web uygulamasının **yerine geçmez**. Aynı veritabanına ikinci bir istemcidir. Bu yüzden mobilde "yeni tablo", "kolaylık olsun diye ayrı view" gibi hiçbir şey açılmaz.

---

## 2. Teknoloji yığını

```
expo                (SDK 52+)
expo-router         dosya tabanlı navigasyon
@supabase/supabase-js  (web ile aynı sürüm)
@tanstack/react-query  sunucu state
zustand             hafif yerel state
react-native-mmkv   hızlı yerel cache (offline kuyruk)
expo-secure-store   oturum belirteci (Keychain / Keystore)
expo-camera         QR / barkod okuma
expo-image-picker   fotoğraf
expo-image-manipulator  yükleme öncesi küçültme
expo-file-system    dosya seçme + yükleme
expo-notifications  push
expo-location       ziyaret geofence
react-native-svg    ikonlar (veya @expo/vector-icons)
```

**Not:** Tailwind kullanılmaz. Tema, web tarafındaki 5 rollü token sisteminin mobil karşılığı olarak `theme.ts` içinde sabit objelerle kurulur (`background/accent/primary/secondary/foreground`). Renk uydurulmaz, web ile aynı görsel dil korunur.

---

## 3. Ekran envanteri (20 ekran)

### 3.1 Ortak — Auth (3)

| # | Ekran | Veri kaynağı |
|---|---|---|
| 1 | Giriş (e-posta + şifre) | GoTrue `signInWithPassword` |
| 2 | Şifremi unuttum / şifre değiştir (2 adım: kod gönder → kod + yeni şifre) | `sifre-dogrulama` edge fn, `send-reset-email` |
| 3 | Oturum kapandı bilgilendirme | yerel (12 saat idle / 7 gün mutlak) |

### 3.2 Uzman — saha (7) — **MVP-1, en yüksek öncelik**

| # | Ekran | Veri kaynağı |
|---|---|---|
| 4 | Bugün / Genel bakış | `ziyaret_durum_dagilimi`, bildirimler |
| 5 | Firmalarım | `uzman_hekim_firma_list` |
| 6 | Ziyaretler — bugünkü liste + harita | `ziyaret-planlama` (liste/başlat/bitir) |
| 7 | Ziyaret başlat/bitir (GPS + süre) | `ziyaret-planlama` |
| 8 | Saha denetimi — uygunsuzluk listesi + yeni kayıt (foto) | `saha-denetim` |
| 9 | Ekipman QR → ekipman kartı → kontrol ekle | `ekipman` (QR'a özel salt-okunur uç) |
| 10 | Tutanaklar — liste + yeni (iş kazası / ramak kala / tehlikeli olay) | `tutanak`, `saha-denetim-tutanak` |

### 3.3 İşyeri hekimi (3)

| # | Ekran | Veri kaynağı |
|---|---|---|
| 11 | Muayene planı / bugünkü muayeneler | planlama servisleri (mevcut RPC'ler) |
| 12 | Muayene kaydı formu | `personel_saglik_kaydi_ekle` |
| 13 | Sağlık evrağı yükle + tetkik kaydı | `evrak` edge fn, storage |

### 3.4 Firma kullanıcısı (3)

| # | Ekran | Veri kaynağı |
|---|---|---|
| 14 | Genel bakış (açık uygunsuzluklar, personel sayısı) | `firma_aktif_personel_sayisi`, `firma_evrak_sayilari` |
| 15 | Personellerim (liste + detay; TCKNO maskeli) | `personel_tckn_masked`, `personel_saglik_ozet` |
| 16 | Uygunsuzluk kapatma talebi (foto zorunlu) | `saha-denetim` |

### 3.5 OSGB yöneticisi (2)

| # | Ekran | Veri kaynağı |
|---|---|---|
| 17 | Atama doygunluğu — firma listesi + rol bazlı eksik | `atama_firma_list`, `atama_rol_doygunluk`, `atama_firma_yasal_mevcut_dakika` |
| 18 | Onay / bildirim merkezi | bildirim RPC'leri |

### 3.6 Ortak (2)

| # | Ekran | Veri kaynağı |
|---|---|---|
| 19 | Bildirimler | `bildirimService` RPC'leri + push |
| 20 | Profil / ayarlar (şifre değiştir, çıkış, tema) | GoTrue + `profiles` (self update kısıtlı) |

### 3.7 Kapsam dışı (MVP'de yok)

Teklif oluşturma, IBYS bildirim, ISG kurulu, risk analizi sihirbazları (fine-kinney / HAZOP / acil durum), Excel/Word/PDF rapor üretimi, envanter, zimmet, evrak OCR, mesajlaşma, döküman önizleme, admin paneli, OSGB kalıcı silme, Chrome eklentisi. Bunların hepsi web'de kalır.

---

## 4. Navigasyon

```
app/
  (auth)/giris.tsx, sifre.tsx, oturum-kapandi.tsx
  (app)/
    _layout.tsx        rol bazlı sekme üretimi
    (uzman)/ bugun.tsx, firmalar.tsx, ziyaretler.tsx, denetim.tsx, tutanaklar.tsx
    (hekim)/ plan.tsx, muayeneler.tsx, evraklar.tsx
    (firma)/ ozet.tsx, personeller.tsx, uygunsuzluklar.tsx
    (osgb)/ atamalar.tsx, onaylar.tsx
    bildirimler.tsx, profil.tsx
```

Sekme sayısı role göre 4-5'i geçmez. Rol `profiles.role` üzerinden okunur (`admin`, `osgb_admin`, `uzman`, `hekim`, `firma`); `admin` mobilde OSGB yöneticisi sekmesini görür. Rol **istemcide karar vermez** — yalnızca hangi sekmenin görüneceğini belirler; asıl yetki RLS'tedir.

---

## 5. Auth akışı (mobil)

```
1. Giriş → supabase.auth.signInWithPassword
2. Session → expo-secure-store (SecureStoreAdapter)
3. profiles'tan rol + osgb_id + firma_id okunur (SELECT, RLS zaten kısıtlı)
4. Rol → sekme seti
5. Her istekte access token otomatik yenilenir (autoRefreshToken: true)
```

**Zorunlu ayarlar:**

```ts
createClient(url, anonKey, {
  auth: {
    storage: SecureStoreAdapter,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,   // RN'de yok, derin bağlantı elle işlenir
    flowType: 'pkce',
  },
})
```

- Şifre sıfırlama derin bağlantısı: `ibys://auth/callback` → Supabase **Redirect URL allowlist**'ine eklenmeli (GoTrue config).
- **Şifre değiştirme akışı web ile aynı kalır:** doğrudan `updateUser({ password })` çağrılmaz. `sifre-dogrulama` edge function'ın `kod-gonder` → `sifre-degistir` adımları kullanılır. Sebep: GUV-44 / PENTEST F1 kapanışı bu kapıya bağlı.
- Oturum politikası: 12 saat hareketsizlik, 7 gün mutlak süre. Uygulama arka plandan döndüğünde süre kontrol edilir, dolmuşsa `signOut()` + `oturum-kapandi` ekranı.
- `service_role` anahtarı **hiçbir koşulda** mobil bundle'a girmez. Bundle'a giren tek anahtar `anon`.

---

## 6. Offline ve saha gerçekliği

Saha = zayıf ağ. MVP'de "tam offline" hedeflenmez, **"kaybetmeyen kuyruk"** hedeflenir:

| Durum | Davranış |
|---|---|
| Fotoğraf çekildi, ağ yok | Dosya cihazda kalır, kuyruğa `pending` yazılır (MMKV) |
| Form gönderildi, ağ yok | Kayıt kuyrukta bekler, listede "gönderilecek" rozeti |
| Ağ geldi | Kuyruk sırayla boşalır, idempotency anahtarı ile tekrar yazma engellenir |
| Çakışma | Sunucu kazanır; kullanıcıya "başka cihazda güncellendi" uyarısı |

Fotoğraf: `expo-image-manipulator` ile uzun kenar 1600px + JPEG %75'e indirilir, **sonra** yüklenir. Storage boyut limitleri (GUV-24) zaten var; mobil bu limiti aşan dosyayı hiç göndermez.

---

## 7. Belge / PDF stratejisi

Mevcut 30+ rapor modülü (`riskRapor`, `calismaRapor`, `egitimRapor`, `fineKinneyRapor`, `hazopRapor`, `tutanakRapor`, `isKazasiRapor`…) tarayıcı kütüphanelerine (jsPDF, xlsx, docx, pdfjs, mammoth) bağlı. **Bunlar React Native'e taşınmaz.**

| İhtiyaç | Mobil çözüm |
|---|---|
| Tutanak PDF'i oluşturma | Mevcut edge function (`tutanak`, `saha-denetim-tutanak`) → storage → mobil sadece indirir/açar |
| Rapor görüntüleme | `expo-print` veya native viewer ile URL açma |
| Excel import (personel, ekipman) | MVP dışı — web'de kalır |
| Word/PPTX önizleme | MVP dışı |

Kural: **mobil belge üretmez, belge tüketir.** Üretim gerekiyorsa sunucuda yeni bir yetenek açılır (ayrı iş kalemi, MVP dışı).

---

## 8. Güvenlik kuralları (pazarlık dışı)

1. `service_role` anahtarı mobilde yok. Sadece `anon`.
2. Tüm yetki kararları RLS + `SECURITY DEFINER` RPC'lerde. Mobil "ben admin'im" diyemez.
3. TCKNO: liste ekranlarında **yalnız** `personel_tckn_masked`; tam TCKNO sadece `personel_tckn_erisim` (yetki + log'lu).
4. Token `expo-secure-store`'da; MMKV'ye asla token yazılmaz.
5. Fotoğraflar public bucket'a atılmaz; mevcut tenant-izole storage politikaları kullanılır.
6. Hata mesajlarında tablo/kolon adı, RPC adı, SQLSTATE gösterilmez.
7. Debug build'de `console.log` ile payload basılmaz (release'te tamamen kapalı).
8. Sertifika sabitleme (pinning) MVP-2 kalemi; en azından `https` zorunlu, cleartext trafiği kapalı (`usesCleartextTraffic=false`, ATS).

---

## 9. Faz planı

| Faz | Süre | Çıktı | Kabul kriteri |
|---|---|---|---|
| F0 — Sözleşme | 3-4 gün | `MOBIL_API_SOZLESMESI` + şema dökümü + Postman/HTTP koleksiyonu | Her ekranın veri kaynağı tek tek eşleşmiş |
| F1 — İskelet + Auth | 1 hafta | Expo projesi, tema, oturum, rol yönlendirme, şifre akışı | 4 rolle giriş yapılıp doğru sekmeler açılıyor |
| F2 — Uzman saha | 2 hafta | Ekran 4-10 | Sahada uçak modunda ziyaret + foto kuyruğa giriyor, ağ gelince gidiyor |
| F3 — Hekim + Firma | 1,5 hafta | Ekran 11-16 | Muayene kaydı + uygunsuzluk kapatma talebi çalışıyor |
| F4 — OSGB + bildirim | 1 hafta | Ekran 17-19 | Atama doygunluğu web ile aynı sayıyı veriyor |
| F5 — Sertleştirme + yayın | 1 hafta | EAS build, store hazırlığı | Güvenlik kontrol listesi (Bölüm 8) tamam |

**Toplam: ~7 hafta.** Tek geliştirici + AI desteği varsayımıyla.

---

## 10. Riskler

| Risk | Etki | Önlem |
|---|---|---|
| Mobil ekibin kolon adı uydurması | Sessiz yanlış veri, RLS hataları | F0'da şema dökümü zorunlu; mock ile ilerlenmez |
| PDF'i mobilde üretmeye kalkmak | 6+ hafta kayıp | Kural: mobil belge tüketir |
| Push token tablosu yok | Bildirim yapılamaz | GUV kapsamında yeni tablo **açılmaz**; önce mevcut `bildirimler` yapısı incelenir, gerekiyorsa ayrı migration olarak planlanır |
| Derin bağlantı allowlist eksik | Şifre sıfırlama kırılır | GoTrue `SITE_URL` + redirect listesi güncellenir |
| 20 ekranı 40'a çıkarma isteği | MVP bitmez | Kapsam dondurulur; yeni istek MVP-2 |
| Aynı Supabase'e iki istemci | Yanlış anlaşılır "çakışma" | Idempotency + `updated_at` kontrolü |

---

## 11. Bir sonraki adım

`MOBIL_API_SOZLESMESI_2026-10-21.md` içindeki "Doğrulama sorguları" bloğu sunucuda bir kez çalıştırılır. Çıkan şema dökümü mobil ekibe verilir. Ondan sonra F1 başlar.