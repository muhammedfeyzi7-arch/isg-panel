# İSGDenetim — Güvenlik Migration Test Planı (Faz 5)

> **Kapsam:** GUV-01, GUV-02, GUV-06, GUV-07, GUV-11 migration'larının **kontrollü/izole
> bir Supabase test ortamında** doğrulanması. Bu doküman test senaryolarını ve beklenen
> sonuçları tanımlar. **Üretim veritabanına hiçbir şey uygulanmaz.**

## Durum gösterimi
- **Düzeltildi** — dosya güncellendi.
- **Test edildi** — çalıştırıldı ve sonuç kanıtlı.
- **Test edilmedi** — izole ortam olmadığı için çalıştırılmadı.
- **Engellendi** — bu ortamda yapılamadı (yetki/erişim yok).

## Test ortamı hazırlığı
İzole test projesi + iki OSGB ve kullanıcılar:

| Kod | Rol | osgb_id | firma_id | Açıklama |
|---|---|---|---|---|
| `admin` | admin | (yok) | (yok) | Platform yöneticisi |
| `A1` | osgb_admin | OSGB-A | (yok) | A yöneticisi |
| `A2` | uzman | OSGB-A | (yok) | A'da aktif ataması olan uzman |
| `F1` | firma | OSGB-A | Firma-A1 | A'nın bir firmasının panel kullanıcısı |
| `F2` | firma | OSGB-A | Firma-A2 | A'nın BAŞKA firmasının kullanıcısı |
| `B1` | osgb_admin | OSGB-B | (yok) | B yöneticisi |
| `anon` | — | — | — | JWT yok (anon key) |

---

## 1) GUV-01 — Storage tenant izolasyonu

**Test yöntemi:** `supabase.storage.from(bucket).list()` + `createSignedUrl()` + `upload()`
her rol için; sonuçlar izole ortamda kaydedilir.

| # | Aktör | Bucket | İşlem | Beklenen |
|---|---|---|---|---|
| 1.1 | A1 | atama-belgeleri | A1'in kendi `uid/` klasörüne upload + read | **Başarılı** |
| 1.2 | A1 | atama-belgeleri | A1 kendi dosyası createSignedUrl | **Başarılı** |
| 1.3 | B1 | atama-belgeleri | A1 dosyası createSignedUrl | **HATA (403/400)** |
| 1.4 | A2 | personel-foto | A'nın personel fotoğrafı (ilişkisel kayıt var) | **Başarılı** |
| 1.5 | F1 | personel-foto | Firma-A1 personel fotoğrafı | **Başarılı** |
| 1.6 | F1 | personel-foto | Firma-A2 personel fotoğrafı (aynı OSGB!) | **HATA** (firma kapsamı) |
| 1.7 | F2 | personel-foto | Firma-A1 personel fotoğrafı | **HATA** |
| 1.8 | B1 | personel-foto | A personel fotoğrafı | **HATA** |
| 1.9 | anon | noter-defteri | list + createSignedUrl | **HATA** (artık `{public}` değil) |
| 1.10 | A1 | noter-defteri | kendi dosyası | **Başarılı** |
| 1.11 | herhangi authenticated | hazop-kanitlari | BAŞKA `uid/` klasörüne upload | **HATA** (klasör = auth.uid zorunlu) |
| 1.12 | A1 | hazop-kanitlari | kendi `uid/` klasörüne upload | **Başarılı** |
| 1.13 | sahibi dışı | herhangi | ilişkisel kaydı OLMAYAN (orphan) dosya | **HATA** (varsayılan DENY) |
| 1.14 | admin | hepsi | tüm dosyalar | **Başarılı** |

**Ek doğrulama:** upload'lar `upsert:true` ile aynı yola tekrar yapıldığında UPDATE
politikası (sahip/admin) nedeniyle **Başarılı** olmalı.

**Idempotency:** Migration iki kez çalıştırma → hatasız (CREATE OR REPLACE + DROP IF EXISTS).
**Veri kaybı:** Yok (politika değişikliği veri silmez). **Rollback:** rollback dosyası eski davranışa döndürür.

**Bu ortamdaki durum:** **Test edilmedi** (izole iki-OSGB ortamı yok). Sözdizimi + şema uyumu doğrulandı.

---

## 2) GUV-02 — handle_new_user rol yükseltmesi

| # | Senaryo | Beklenen |
|---|---|---|
| 2.1 | signUp metadata `{role:'admin', osgb_id:'X', firma_id:'Y'}` | profiles: `role='pending'`, osgb_id/firma_id BOŞ |
| 2.2 | signUp metadata `{role:'osgb_admin'}` | `role='pending'` |
| 2.3 | accept-invite (uzman/hekim/osgb_admin/firma) | rol **davet kaydından** doğru atanır (regresyon) |
| 2.4 | `info@isgdenetim.com.tr` | `role='admin'` |
| 2.5 | DASHBOARD: Auth self-signup | **KAPALI** olmalı (koddan doğrulanamaz) |

**Idempotency:** CREATE OR REPLACE ✅ · **Rollback:** orijinal gövde geri kurulur · **Veri kaybı:** Yok.
**Bu ortamdaki durum:** **Test edilmedi**. Davet akışı kod incelemesiyle doğrulandı (rolü `davetler.role`'den yazar → trigger'a bağımlı değil).

---

## 3) GUV-06 — teklifler RESTRICTIVE

| # | Aktör | İşlem | Beklenen |
|---|---|---|---|
| 3.1 | A1 | SELECT teklifler | Yalnızca A |
| 3.2 | B1 | SELECT teklifler | Yalnızca B |
| 3.3 | A1 | doğrudan INSERT osgb_id=A | Kabul |
| 3.4 | A1 | doğrudan INSERT osgb_id=B | Red (0 satır) |
| 3.5 | A1 | UPDATE B satırı | 0 satır |
| 3.6 | A1 | RPC `teklif_kaydet` (kendi) | Başarılı (SECURITY DEFINER regresyon) |
| 3.7 | A1 | RPC `teklif_sil` (kendi) | Başarılı |

**Not:** Mevcut permissive politikalar zaten tenant-scoped olduğundan **aktif sızma
doğrulanamadı**; bu madde defense-in-depth. **Idempotency:** ✅ · **Rollback:** DROP restrictive · **Veri kaybı:** Yok.
**Bu ortamdaki durum:** **Test edilmedi**.

---

## 4) GUV-07 — osgb_access_ok() sertleştirme

| # | Aktör | Beklenen |
|---|---|---|
| 4.1 | osgb_id BOŞ 'uzman' | atamalar/evraklar/firmalar/personeller → 0 satır |
| 4.2 | admin | tümü |
| 4.3 | Geçerli OSGB osgb_admin | kendi kapsamı |
| 4.4 | **firma (osgb_id dolu)** | kendi firması görünür (YENİ regresyon testi) |
| 4.5 | OSGB `is_active=false` / `erisim_bitis` geçmiş / `deleted_at` dolu | erişim YOK |
| 4.6 | anon | erişim YOK |

**Idempotency:** CREATE OR REPLACE ✅ · **Rollback:** NULL dalı geri kurulur · **Veri kaybı:** Yok.
**Bu ortamdaki durum:** **Test edilmedi**. Regresyon riski kod+canlı DB ile analiz edildi (firma kullanıcıları osgb_id dolu → bozulmaz).

---

## 5) GUV-11 — anon EXECUTE izinleri

| # | Aktör | Çağrı | Beklenen |
|---|---|---|---|
| 5.1 | anon | `rpc('announcement_audit')` | permission denied |
| 5.2 | anon | `rpc('auth_role')` | permission denied |
| 5.3 | anon | `rpc('next_tutanak_no')` | permission denied |
| 5.4 | anon | `rpc('teklif_sil', {...})` | permission denied |
| 5.5 | authenticated | `rpc('auth_role')` | Başarılı |
| 5.6 | authenticated | `rpc('teklif_kaydet', ...)` | Başarılı |
| 5.7 | anon | `rpc('teklif_public_get', {token})` | **Başarılı** (public akış korunur) |
| 5.8 | trigger akışları | announcement/atama insert-update | hatasız |

**Idempotency:** REVOKE/GRANT ✅ · **Rollback:** PUBLIC grant geri kurulur · **Veri kaybı:** Yok.
**Bu ortamdaki durum:** **Test edilmedi**.

---

## 6) GUV-13 — anon/PUBLIC SECURITY DEFINER RPC EXECUTE daraltma (Faz 6)

Canlı ölçüm: anon'un EXECUTE edebildiği definer fonksiyon **159**; trigger olmayan/çağrılabilir **104**.

| # | Aktör | Çağrı | Beklenen |
|---|---|---|---|
| 6.1 | anon | `rpc('auto_close_ziyaretler')` | permission denied |
| 6.2 | anon | `rpc('delete_osgb_permanent', {...})` | permission denied |
| 6.3 | anon | `rpc('admin_dashboard_summary')` | permission denied |
| 6.4 | anon | `rpc('atama_list', {...})` | permission denied |
| 6.5 | authenticated | `rpc('atama_list', {...})` | Başarılı (panel korunur) |
| 6.6 | service_role (edge) | RPC çağrıları | Başarılı (grant verildi) |
| 6.7 | anon | `rpc('teklif_public_get', {token})` | **Başarılı** (public akış korunur) |

**Idempotency:** dinamik `DO` + `REVOKE/GRANT` ✅ · **Rollback:** `GRANT ... TO PUBLIC, anon` · **Veri kaybı:** Yok.
**Bu ortamdaki durum:** **Test edilmedi**.

## 7) GUV-14 — SECURITY DEFINER search_path sabitleme (Faz 6)

Canlı: 4 definer fonksiyon search_path'siz (`custom_field_definition_set_osgb`,
`custom_field_value_set_scope`, `firma_evrak_klasorleri_set_scope`, `ziyaret_auto_close_due`).

| # | Kontrol | Beklenen |
|---|---|---|
| 7.1 | search_path'siz definer fonksiyon sorgusu (uygulama sonrası) | **0 satır** |
| 7.2 | `custom_field_*` trigger akışları | hatasız |
| 7.3 | `ziyaret_auto_close_due()` çağrısı | hatasız |

**Idempotency:** dinamik `DO` ✅ · **Rollback:** `RESET search_path` · **Veri kaybı:** Yok.
**Bu ortamdaki durum:** **Test edilmedi**.

---

## Genel test özet tablosu

| Kontrol | Sonuç |
|---|---|
| Migration sözdizimi (statik) | ✅ Geçti |
| Rollback dosyaları mevcut | ✅ 5/5 |
| İzole ortam A/B testleri | ⛔ **Test edilmedi** (ortam yok) |
| CORS preflight | ⛔ **Test edilmedi** (allowlist deploy edilmedi) |
| `npm audit` / bağımlılık taraması | ⛔ **Engellendi** (komut yürütücü yok) |
| Auth Dashboard (self-signup/parola/rate limit) | ⛔ **Doğrulanamadı** (Dashboard erişimi) |
| HSTS / nosniff / frame-ancestors | ⛔ **Engellendi** (hosting katmanı gerekir) |

> Bu plan resmî TSE onaylı sızma testinin yerine geçmez. Test ortamı sağlandığında her
> satır çalıştırılıp kanıtla (ekran/RPC yanıtı) işaretlenmelidir.

---

## 8) Faz 7 · Çalıştırılabilir izole test seti

Yukarıdaki senaryolar artık **çalıştırılabilir SQL test dosyaları** olarak hazırlandı:

| Dosya | Kapsam |
|---|---|
| `supabase/tests/security/README.md` | İzole ortam kurulumu + çalıştırma |
| `supabase/tests/security/00_harness.sql` | `security_test` şeması + `set_user/as_anon/reset_user/try_sql` + `create_fixtures()` |
| `supabase/tests/security/guv01_storage_isolation.test.sql` | Storage bucket × işlem × rol |
| `supabase/tests/security/guv02_role_escalation.test.sql` | Metadata rol yükseltme |
| `supabase/tests/security/guv06_teklif_tenant.test.sql` | teklifler/teklif_hizmetleri tenant |
| `supabase/tests/security/guv07_osgb_access.test.sql` | osgb_access_ok NULL tenant |
| `supabase/tests/security/guv11_guv13_anon_execute.test.sql` | anon/PUBLIC EXECUTE |
| `supabase/tests/security/guv14_search_path.test.sql` | SECURITY DEFINER search_path |

**Önemli:** Bu dosyalar **production'a bağlanmaz**; tüm fixture verisi transaction içinde
üretilip `rollback` ile temizlenir. Base şema proje klasöründe olmadığı için testler bu
turda **ÇALIŞTIRILMADI → BLOCKED**. Sonuçlar: `SECURITY_TEST_RESULTS_PHASE7.md`.

### 8.1 Faz 7 ek bulgular (test planına eklenen senaryolar)
- **GUV-13 kapsam açığı:** hedef listesi dışındaki 23 anon-çağrılabilir definer fonksiyon
  (bakım/özet olanlar) daraltılmalı → kod incelemesi gerekli.
- **GUV-14 kapsam dışı:** `log_system_event` boş `search_path` → ayrı senaryo.
- Testler `has_function_privilege('anon'|'authenticated'|'service_role', …)` ile grant
  düzeyini katalog üzerinden de doğrular.

---

## 9) Faz 8 · GUV-13b + GUV-15 kapsam tamamlama testleri

### 9.1 GUV-13b — 19 definer RPC anon daraltma

Dosya: `supabase/migrations/20260101000800_guv13b_anon_definer_scope.sql` · Test:
`supabase/tests/security/guv13b_guv15_coverage.test.sql`

| # | Aktör | Çağrı | Beklenen |
|---|---|---|---|
| 9.1 | anon | `rpc('operasyon_bakim_hatirlatma')` | permission denied |
| 9.2 | authenticated | `rpc('operasyon_bakim_hatirlatma')` | permission denied (yalnız service_role) |
| 9.3 | anon | `rpc('personel_atama_sure_plan')` | permission denied |
| 9.4 | anon | `rpc('personel_firma_id', {…})` | permission denied |
| 9.5 | anon | `rpc('atama_firma_durum_ozet')` | permission denied |
| 9.6 | authenticated | `rpc('atama_firma_durum_ozet')` | Başarılı (panel korunur) |
| 9.7 | authenticated | `rpc('hazard_change_detect', {…})` | Başarılı |
| 9.8 | authenticated | `rpc('mesajlasma_unread_count')` | Başarılı |
| 9.9 | anon | SELECT (policy `mesajlasma_is_participant` çağırır) | hata DEĞİL → 0 satır (helper korunur) |
| 9.10 | service_role | `rpc('project_myk_requirements')` | Başarılı |

**Idempotency:** ✅ · **Rollback:** `GRANT ... TO PUBLIC, anon` · **Veri kaybı:** Yok.
**Bu ortamdaki durum:** **Test edilmedi** (izole ortam yok).

### 9.2 GUV-15 — search_path boş/NULL tamamlama

Dosya: `supabase/migrations/20260101000900_guv15_search_path_completion.sql`

| # | Kontrol | Beklenen |
|---|---|---|
| 9.11 | NULL search_path'li definer fonksiyon sorgusu (uygulama sonrası) | **0 satır** |
| 9.12 | 7 niteliksiz-boş fonksiyonun search_path'i | `public, pg_temp` set |
| 9.13 | `log_system_event` ve tam-nitelikli boş fonksiyonlar | **DEĞİŞMEDİ** (`search_path=""`) |
| 9.14 | `firmalar`/`personeller` trigger akışları (firma_isg_girdi_degisim, lock, prevent_delete, personel_normalize) | hatasız |
| 9.15 | `request_context()` çağrısı | hatasız |

**Idempotency:** ✅ · **Rollback:** `RESET search_path` · **Veri kaybı:** Yok.
**Bu ortamdaki durum:** **Test edilmedi** (izole ortam yok). ⚠️ Trigger regresyonu izole
ortamda doğrulanmalıdır.

### 9.3 Faz 8 test ortamı notu
Base şema proje klasöründe yok → tüm DB runtime testleri **BLOCKED**. İzole ortam için
en kısa yol ve sorumlu girdi: **`SECURITY_TEST_ENV_PLAN_PHASE8.md`**.
### 9.4 Faz 8 test seti kalite denetimi
Ayrıntı: **`SECURITY_TEST_RESULTS_PHASE8.md` §C** (harness `auth.users` kolon riski, fixture
kolon uyumu, GUV-13b/15 testi eklendi).