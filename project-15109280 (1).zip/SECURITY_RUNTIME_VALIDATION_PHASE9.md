# İSGDenetim — Faz 9: İzole Veritabanı Kurulumu ve Migration Runtime Doğrulaması

> **Yöntem:** (a) 9 migration + 9 rollback + harness + 7 test dosyasının tam içeriği okundu,
> (b) canlı Supabase'de **yalnızca salt-okuma** `SELECT` (information_schema / pg_proc /
> storage.buckets / has_function_privilege), (c) harness + guv01 testi gerçek şemaya göre
> düzeltildi, (d) production build.
>
> ⛔ **ÜRETİM SINIRI (açık doğrulama):** Canlı veritabanına **hiçbir DDL/DML uygulanmadı**,
> **hiçbir migration çalıştırılmadı**, **hiçbir deploy yapılmadı**, canlı RLS/Storage/grant
> değiştirilmedi, gerçek kullanıcı verisi kopyalanmadı/değiştirilmedi, hiçbir gizli anahtar
> rapora yazılmadı. Raporlanan her DB gözlemi **salt-okuma metadata** sorgusudur.
>
> **Dürüstlük notu:** Bu turda **DB runtime testi ÇALIŞTIRILMADI** (izole ortam yok) →
> ilgili tüm satırlar **BLOCKED**. Hiçbir migration için **PASS** yazılmadı. Yalnız
> gerçekten çalıştırılan **production build** ve **katalog/statik kontroller** kanıtlıdır.

---

## A. Özet

- **Bu turda yapılan gerçek iş:** harness/test kolon uyumu düzeltmesi + gerçek bağımlılık
  sırası analizi + teslimat dokümanı. Yeni güvenlik migration'ı üretilmedi (talimat gereği).
- **Gerçekten çalıştırılan test:** 1 → **PASS** (production build).
- **DB runtime testleri:** **0 çalıştırıldı → tamamı BLOCKED** (izole test DB yok).
- **Kod incelemesi + canlı salt-okuma:** kapsamlı (10+ sorgu).
- **Canlı sisteme müdahale:** ❌ HİÇ YOK.

### A.1 Canlı durum teyidi (bu tur, salt-okuma)

| Kontrol | Canlı sonuç | Anlam |
|---|---|---|
| `anon`'un EXECUTE edebildiği definer fonksiyon | **159** | GUV-11/13/13b uygulanmadı |
| `search_path IS NULL` definer fonksiyon | **4** | GUV-14/15 uygulanmadı |
| `search_path = ""` (boş) definer fonksiyon | **34** | boş desen hâlâ yaygın |
| `atama-belgeleri` / `personel-foto` / `hazop-kanitlari` / `noter-defteri` bucket | **hepsi private (public=false)** | RLS tek kapı |
| `storage_tenant_ok` fonksiyonu | **YOK** | GUV-01 uygulanmadı |

> **Sonuç:** 9 güvenlik migration'ının **hiçbiri canlıya uygulanmamıştır.** Veri katmanı
> hâlâ açıktır; dosya varlığı açığı kapatmaz.

---

## B. Madde 1 — Test ortamı için gerekli girdi

**Durum: İzole test ortamı MEVCUT DEĞİLDİR.** Canlı Supabase bağlıdır ve **yalnızca
salt-okuma şema kaynağı** olarak kullanılabilir; testler canlıda ASLA çalıştırılmaz.

### B.1 Minimum kurulum adımları ve sorumlu girdi

| # | Adım | Sorumlu | Gerekli yetki/karar | Bu ortamdaki durum |
|---|---|---|---|---|
| 1 | Canlıdan **bağımsız** yeni bir Supabase test projesi aç | Proje sahibi | Supabase Dashboard | **BLOCKED** (Dashboard girdisi) |
| 2 | Base şemayı **şema-only (VERİSİZ)** klonla: `supabase db dump --db-url "$PROD_DB_URL" --schema public,auth,storage --data-only=false > base_schema.sql` | DB erişimi olan | Canlı DB **okuma** connection string (env değişkeni, sohbete yazılmaz) | **BLOCKED** |
| 3 | Base şemayı izole projeye yükle: `psql "$TEST_DB_URL" -f base_schema.sql` | Geliştirici | İzole DB erişimi | **BLOCKED** |
| 4 | 4 private bucket oluştur (`atama-belgeleri`, `personel-foto`, `hazop-kanitlari`, `noter-defteri`) | Geliştirici | İzole DB erişimi | **BLOCKED** |
| 5 | Harness yükle: `psql "$TEST_DB_URL" -f supabase/tests/security/00_harness.sql` | Geliştirici | İzole DB | **HAZIR** (dosya) / **BLOCKED** (ortam) |
| 6 | Testleri çalıştır: `supabase test db` veya `psql -f guv*.test.sql` | Geliştirici | İzole DB | **BLOCKED** |

### B.2 Neden canlı kullanılamıyor

- Canlıya test DDL/DML yazmak **güvenlik sınırları gereği yasaktır** (gerçek kullanıcı/veri).
- Base şema migration'ları bu proje klasöründe **YOK** → yerel Supabase kurulumu `auth_role()`
  vb. eksikliğinde durur.
- **Uydurma `auth_role()` veya tablo oluşturulmadı.** Şema-only dump (verisiz) alınana kadar
  DB runtime testleri **BLOCKED** kalır.

---

## C. Madde 2 — Gerçek bağımlılık sırası (dosya numarasına körlemesine değil)

Ayrıntı: **`SECURITY_MIGRATION_DEPENDENCIES.md` §11**. Özet:

### C.1 Gerçekten ZORUNLU olan sıralama kısıtları (yalnız 3)

1. **Base şema + yardımcı nesneler** (`auth_role`, `auth_osgb_id`, `auth_firma_id`,
   `has_active_firma_assignment`, `osgb_access_ok`'un 4 guard policy'si, ilgili tablolar)
   → **GUV-01/06/07/11 öncesinde var olmalı.** (Canlıda mevcut ✅)
2. **GUV-14 → GUV-15(1)** : GUV-15'in NULL bloğu GUV-14 ile aynı kümeyi hedefler; GUV-14
   önce uygulanırsa GUV-15(1) **no-op** olur. (Ters sırada hata olmaz ama önerilir.)
3. **GUV-11 imza katılığı** : statik `REVOKE ... (imza)` kullanır; hedef imza yoksa **hata
   verir**. Yalnız imzaların tam mevcut olduğu base şemada çalıştırılmalı.

### C.2 Sıra SERBEST olanlar

GUV-02, GUV-06, GUV-07, GUV-13, GUV-13b **birbirinden bağımsız** nesneleri değiştirir.
Dosya numarası sırası **teknik zorunluluk değil**, denetlenebilirlik kolaylığıdır.

**Önerilen (zorunlu değil) sıra:**
`GUV-02 → GUV-07 → GUV-06 → GUV-01 → GUV-11 → GUV-13 → GUV-13b → GUV-14 → GUV-15`

### C.3 Çakışma / tekrar çalıştırma / rollback

- GUV-14 ⟷ GUV-15(1): idempotent kesişir, çakışma yok.
- GUV-11 ⟷ GUV-13/13b: kesişen fonksiyonlarda `REVOKE`+`GRANT` idempotent → tekrar güvenli.
- **Tüm migration'lar tekrar çalıştırılabilir** (CREATE OR REPLACE / DROP IF EXISTS / dinamik DO).
- **Hiçbir rollback tablo/satır silmez**; yalnız policy/fonksiyon/grant geri alır.

### C.4 Meşru erişimi bozabilecek kritik noktalar (izole test ŞART)

| Migration | Risk | Neden |
|---|---|---|
| GUV-11 | `service_role` RPC erişimi | teklif RPC grant'ı yalnız `authenticated`'e verilir → `service_role` ayrı doğrulanmalı |
| GUV-15 | trigger regresyonu | boş `search_path`'li 7 fonksiyonun gövdesi niteliksiz → `public, pg_temp`'e bağlanması doğrulanmalı |
| GUV-01 | hazop/noter yükleme akışı | INSERT artık `folder[1]=auth.uid()` + rol ister; mevcut kodla uyum doğrulanmalı |

---

## D. Madde 3 — Test harness düzeltmeleri

### D.1 Bulunan gerçek kolon uyumsuzlukları (canlı salt-okuma kanıtı)

| Tablo | Testin KULLANDIĞI | Gerçek ZORUNLU (NOT NULL, defaultsuz) | Durum |
|---|---|---|---|
| `atama_belgeleri` | id, osgb_id, firma_id, dosya_path | **osgb_id, firma_id, atama_id, personel_id, belge_turu, belge_adi** | ❌ 4 kolon eksik → insert hata |
| `noter_defteri_ekleri` | id, osgb_id, firma_id, storage_path | **kayit_id (FK), osgb_id, firma_id** | ❌ kayit_id + FK parent eksik |
| `hazop_kanitlari` | id, osgb_id, firma_id, storage_path | **degerlendirme_id, firma_id, dosya_adi, storage_path** | ❌ degerlendirme_id + dosya_adi eksik |
| `storage.objects` | id, bucket_id, name, owner | (zorunlu kolon YOK) | ✅ OK |
| `atamalar` | id, osgb_id, firma_id, personel_id, atama_turu, baslangic_tarihi, is_active | osgb_id, firma_id, personel_id, atama_turu, baslangic_tarihi | ✅ OK |
| `teklifler` | id, osgb_id, teklif_no | osgb_id, teklif_no | ✅ OK |
| `teklif_hizmetleri` | id, teklif_id, osgb_id | teklif_id, osgb_id | ✅ OK |
| `osgb` / `firmalar` / `personeller` / `profiles` / `auth.users` | mevcut fixture kolonları | (uyumlu) | ✅ OK |

**Not:** `atama_belgeleri.atama_id` ve `hazop_kanitlari.degerlendirme_id` için **FK yok** →
sahte UUID serbest. `noter_defteri_ekleri.kayit_id` için **FK VAR** →
`noter_defteri_kayitlari` parent satırı zorunlu.

### D.2 Yapılan düzeltme

- **`00_harness.sql`**: yeni fonksiyon **`security_test.create_storage_relational_fixtures()`**
  eklendi. Gerçek şemadaki tüm zorunlu kolonlarla (yukarıdaki kanıtlı liste) çocuk satırları
  ve `noter_defteri_kayitlari` FK parent'ını üretir.
- **`guv01_storage_isolation.test.sql`**: bozuk 3 ham `INSERT` bloğu kaldırıldı; yerine
  `SELECT security_test.create_storage_relational_fixtures();` çağrısı eklendi.
- **`README.md`**: fixture kolon listesi gerçek şemaya göre düzeltildi + yeni fonksiyon belgelendi.

### D.3 Hâlâ doğrulanamayan noktalar (dürüst)

- `atamalar.atama_turu = 'uzman'` değerinin **enum/check** uyumu (base şema yok) → izole
  ortamda doğrulanmalı.
- `auth.users(id, email)` inser'i: canlıda yalnız `id` zorunlu görünüyor, ancak Supabase
  `auth.users` trigger/constraint'leri izole ortamda birebir doğrulanmalı.
- Diğer base-şema NOT NULL/FK constraint'leri izole ortamda `\d` ile teyit edilmeli.

> **Idempotency & temizlik korundu:** Tüm test dosyaları `BEGIN; … ROLLBACK;` ile sarılıdır;
> fixture'lar transaction içinde üretilip geri alınır → izole ortamda bile kalıcı iz bırakmaz.

---

## E. Madde 4 — Runtime testleri

**İzole test veritabanı hazır OLMADIĞI için migration'lar ve testler ÇALIŞTIRILMADI.**
Aşağıdaki tablo, izole ortam sağlandığında çalıştırılacak liste ve **gerçek durum**:

| # | Test | Beklenen | Gerçek | Sonuç |
|---|---|---|---|---|
| T0 | Production build | Başarılı | Build successful | **PASS** |
| T1 | OSGB A/B SELECT tenant izolasyonu (GUV-06) | 0 cross-tenant satır | Çalıştırılmadı | **BLOCKED** |
| T2 | OSGB A/B INSERT/UPDATE/DELETE tenant (GUV-06) | 0 satır / 42501 | Çalıştırılmadı | **BLOCKED** |
| T3 | anon → `auto_close_ziyaretler`/`delete_osgb_permanent` (GUV-13) | permission denied | Çalıştırılmadı | **BLOCKED** |
| T4 | anon → `operasyon_bakim_hatirlatma` (GUV-13b) | permission denied | Çalıştırılmadı | **BLOCKED** |
| T5 | service_role → grup2 RPC (GUV-13b) | Başarılı | Çalıştırılmadı | **BLOCKED** |
| T6 | NULL search_path definer = 0 (GUV-14/15) | 0 satır | Çalıştırılmadı | **BLOCKED** |
| T7 | boş-niteliksiz 7 fonksiyon `public` set (GUV-15) | set | Çalıştırılmadı | **BLOCKED** |
| T8 | `log_system_event` DEĞİŞMEDİ (GUV-15) | `search_path=""` korunur | Çalıştırılmadı | **BLOCKED** |
| T9 | Metadata ile rol yükseltme engeli (GUV-02) | rol=`pending` | Çalıştırılmadı | **BLOCKED** |
| T10 | `osgb_access_ok()` NULL tenant → false (GUV-07) | false | Çalıştırılmadı | **BLOCKED** |
| T11 | Storage cross-tenant okuma engeli (GUV-01) | hata/0 satır | Çalıştırılmadı | **BLOCKED** |
| T12 | Trigger/Auth davranışları (GUV-02/15) | hatasız | Çalıştırılmadı | **BLOCKED** |

### E.1 Gerçekten çalıştırılan statik/katalog kontrolleri ✅

| Kontrol | Sonuç | Kanıt |
|---|---|---|
| Production build | **PASS** | build tool |
| canlı `anon` definer EXECUTE | 159 | `has_function_privilege` |
| canlı `search_path IS NULL` definer | 4 | `pg_proc.proconfig` |
| canlı bucket public durumları | hepsi `false` | `storage.buckets` |
| fixture kolon uyumu | 3 tablo düzeltildi | `information_schema.columns` |
| FK tespiti | `noter_defteri_ekleri.kayit_id` → `noter_defteri_kayitlari` | `information_schema` |

---

## F. Değiştirilen / oluşturulan dosyalar (Faz 9)

| Dosya | Durum | Kapsam |
|---|---|---|
| `SECURITY_RUNTIME_VALIDATION_PHASE9.md` | **Yeni** | Bu rapor |
| `supabase/tests/security/00_harness.sql` | **Güncellendi** | `create_storage_relational_fixtures()` eklendi |
| `supabase/tests/security/guv01_storage_isolation.test.sql` | **Güncellendi** | Bozuk 3 INSERT → harness fonksiyonu |
| `supabase/tests/security/README.md` | **Güncellendi** | Gerçek kolon listesi + yeni fonksiyon |
| `SECURITY_MIGRATION_DEPENDENCIES.md` | **Güncellendi** | §11 gerçek bağımlılık sırası |

> `src/**` uygulama kodu ve `supabase/migrations/**` migration içerikleri **DEĞİŞTİRİLMEDİ.**

---

## G. Retest sonuçları

- Düzeltme sonrası **uygulanabilir tek retest = production build** → **PASS**.
- Harness/guv01 düzeltmeleri **sözdizimi kontrolünden** geçti (SQL parser).
- DB runtime retestleri **izole ortam olmadığı için yapılamadı** → **BLOCKED**.

---

## H. Üretime geçiş engelleri (bloker listesi)

1. **İzole test ortamı + base şema (şema-only dump)** yok → tüm DB runtime testleri **BLOCKED**
   (bkz. `SECURITY_TEST_ENV_PLAN_PHASE8.md`).
2. **9 migration canlıda hâlâ uygulanmadı** (GUV-01/02/06/07/11/13/13b/14/15).
3. **GUV-15 trigger regresyon doğrulaması** gerekli (niteliksiz referans varsayımı).
4. **GUV-11 `service_role` RPC grant tutarlılığı** izole testte doğrulanmalı.
5. **GUV-01 hazop/noter yükleme akışı** `folder=auth.uid()` kuralıyla uyumlu olmalı.
6. **Fixture enum/constraint doğrulaması** (`atamalar.atama_turu`, `auth.users`) — base şema ile.
7. CORS/`_shared` (GUV-04/03), hosting başlıkları (GUV-10), Auth Dashboard self-signup →
   ortam/yetki gerekli.

### H.1 Eksik kanıtlar
- Hiçbir RLS/grant/storage/search_path davranışı **gerçek DB'de çalıştırılarak** kanıtlanmadı.
- CORS preflight, `npm audit`, Auth Dashboard ayarları doğrulanmadı.

---

## I. Üretim güvenliği (açık doğrulama)

- ✅ Canlı veritabanına **hiçbir DDL/DML uygulanmadı** (yalnız salt-okuma SELECT).
- ✅ Gerçek kullanıcı/veri/hesap **kopyalanmadı, değiştirilmedi, silinmedi.**
- ✅ Production migration **çalıştırılmadı**, Edge Function **deploy edilmedi**, secret değişmedi.
- ✅ Hiçbir test sonucu uydurulmadı; çalıştırılamayanlar **BLOCKED** işaretlendi.

---

## J. Son karar: **Üretime hazır değil**

Statik inceleme, bağımlılık analizi ve test-harness kolon düzeltmesi **TAMAMLANDI**; ancak
**veri katmanı canlıda hâlâ açık** (9 migration uygulanmadı) ve **tüm DB runtime testleri
BLOCKED** olduğundan bu hâliyle **üretime hazır değildir.** Bu çalışma resmî TSE onaylı
sızma testinin yerine geçmez.