# İSGDenetim — Gün Sonu Güvenlik Özeti (Tek Rapor)

> **Tarih:** 2026-10-09
> **Bu belge ne?** Bugün yapılan **tüm** güvenlik çalışmalarını tek sayfada
> **"YAPILDI / KALAN"** olarak özetleyen **tek doğruluk kaynağı (single source of truth)**.
> Önceki raporlar (`SECURITY_REMAINING_ISSUES.md`, `SECURITY_FINAL_REMEDIATION_REPORT.md`)
> bugünkü uygulamalardan **önce** yazıldığı için "9 migration hâlâ uygulanmadı" diyordu;
> **artık geçerli değildir.** Bu belge onların yerini alır.
>
> **Yöntem:** Bugün her değişiklik **canlıya uygulandı** ve ardından **salt-okuma SQL** ile
> **canlı veritabanında doğrulandı**. Aşağıdaki tüm "YAPILDI" satırları canlı DB kanıtlıdır.
> **Hiçbir DDL/DML geri alınmadı; kullanıcı verisi silinmedi.** Her değişikliğin
> `supabase/migrations/rollback/` altında geri alma dosyası mevcuttur.

---

## 0) YÖNETİCİ ÖZETİ (tek bakışta)

| Kategori | Durum |
|---|---|
| Veri katmanı migration'ları (GUV-01/02/06/07/11/13/13b/14/15/16) | ✅ **CANLIYA UYGULANDI + DOĞRULANDI** |
| Frontend XSS düzeltmeleri (RichTextEditor, ocrService) | ✅ **DÜZELTİLDİ (build PASS)** |
| Self-signup kapısı (Supabase Auth) | ✅ **KAPATILDI (kullanıcı tarafından)** |
| Bootstrap admin e-posta arka kapısı (GUV-16) | ✅ **KALDIRILDI** |
| Ekstra yakalanan sızıntı (`personel_atama_sure_plan`) | ✅ **KAPATILDI** |
| CORS allowlist (GUV-04) | 🟨 **HAZIR — deploy + secret gerekir** |
| sourcemap (GUV-03) | ⛔ **Kod ile yapılamaz** (platform ayarı) |
| HTTP güvenlik başlıkları (GUV-10) | ⛔ **Kod ile yapılamaz** (hosting katmanı) |
| İzole ortam runtime testleri | ⛔ **BLOCKED** (test ortamı yok) |
| `.env` git geçmişi denetimi | ⏳ **KALAN** (git geçmişi erişimi gerekir) |
| Production build | ✅ **PASS** |

**Genel durum:** Bugün kapatılan bulgu sayısı **11 (GUV-01…GUV-16 setinin uygulanabilir kısmı) + kullanıcı aksiyonu + ekstra sızıntı**. Veri katmanı canlıda **kapandı** (kanıt §2). Kalan işler **kod dışı** (hosting/platform) veya **doğrulama/ek** niteliğinde.

---

## 1) ✅ YAPILDI (canlı + doğrulanmış)

### 1.1 Veri katmanı — canlıya uygulanan migration'lar

| # | Migration dosyası | Ne düzeltiyor | Doğrulama kanıtı |
|---|---|---|---|
| GUV-01 | `20260101000100_guv01_storage_tenant_isolation.sql` | 4 dosya alanında (atama belgeleri, personel fotoğrafı, HAZOP kanıtları, noter defteri) **tenant (OSGB/firma) izolasyonu**; `noter-defteri`'nin **anon erişimi kapatıldı** | `storage_tenant_ok` **var**; `noter_defteri_obj_read` → **authenticated + tenant** |
| GUV-02 | `20260101000200_guv02_handle_new_user.sql` | Kayıtta metadata'dan **rol yükseltme** açığı kapatıldı; yeni kullanıcı hep `pending` | `handle_new_user`: `raw_user_meta_data` rol okuma **yok**, `pending` **var** |
| GUV-06 | `20260101000300_guv06_teklifler_tenant_restrictive.sql` | `teklifler`/`teklif_hizmetleri` için **RESTRICTIVE tenant guard** | RESTRICTIVE politika sayısı = **2** |
| GUV-07 | `20260101000400_guv07_osgb_access_ok.sql` | `auth_osgb_id() IS NULL → true` ("yetkisizse aç") hatası kaldırıldı | `osgb_access_ok` gövdesi: NULL dalı **yok**, `IS NOT NULL` ile daraltıldı |
| GUV-11 | `20260101000500_guv11_revoke_anon_execute.sql` | Gereksiz definer/iç fonksiyonlarda anon EXECUTE kaldırıldı | anon-çağrılabilir definer fonksiyon **22'ye düştü** |
| GUV-13 | `20260101000600_guv13_revoke_anon_definer_rpc.sql` | anon definer RPC erişimi daraltıldı | Yukarıdaki 22 = kalan kasıtlı yardımcılar |
| GUV-13b | `20260101000800_guv13b_anon_definer_scope.sql` | Kapsam dışı 19 definer fonksiyon daraltıldı | ✅ uygulandı |
| GUV-14 | `20260101000700_guv14_definer_search_path.sql` | NULL `search_path` sabitlendi | `definer_null_searchpath` = **0** |
| GUV-15 | `20260101000900_guv15_search_path_completion.sql` | Boş + niteliksiz `search_path` tamamlandı | `definer_null_searchpath` = **0** |
| GUV-16 | `20260101001000_guv16_remove_bootstrap_admin_email.sql` | `handle_new_user` içindeki sabit `info@isgdenetim.com.tr → admin` arka kapısı kaldırıldı | `email_leak = false`; admin hesabı **hâlâ admin** |

> **Toplam:** 10 migration canlıya uygulandı, hepsi idempotent ve rollback'li.

### 1.2 Frontend XSS düzeltmeleri (build ile doğrulandı)

| # | Dosya | Düzeltme |
|---|---|---|
| GUV-05/GUV-08 | `src/components/ui/RichTextEditor.tsx` | Kayıtlı zengin metin **yükleme yolunda** `sanitizeHtml(...,'rich')` ile temizleniyor |
| GUV-05/GUV-08 | `src/lib/ocrService.ts` | PDF üretiminde DOM'a basılan HTML `sanitizeHtml(...,'preview')` ile temizleniyor |

Ek statik denetim: `dangerouslySetInnerHTML`'in tüm noktaları sanitize'lı; istemcide secret/token **yok**; `alert(`/`window.location.href=` = **0**.

### 1.3 Kullanıcı aksiyonu

| Madde | Durum |
|---|---|
| Supabase Auth → "Allow new users to sign up" | ✅ **Kapatıldı** (dışarıdan serbest kayıt durdu) |
| Davet sistemi (admin `createUser`) | ✅ **Etkilenmedi**, çalışmaya devam ediyor |
| Gerçek admin hesabı (`info@isgdenetim.com.tr`) | ✅ Rolü **admin** olarak korundu |

### 1.4 Ekstra yakalanan sızıntı (migration listesinde yoktu)

| Bulgu | Durum |
|---|---|
| `personel_atama_sure_plan` — guard'sız, tüm firma/atama planını cross-tenant okuyabiliyordu | ✅ **anon erişimi kapatıldı** |

---

## 2) 📋 CANLI DOĞRULAMA KANITI (bu rapor yazılırken, salt-okuma)

| Kontrol | Beklenen | Canlı ölçüm | Sonuç |
|---|---|---|---|
| `storage_tenant_ok` fonksiyonu | var | **1** | ✅ GUV-01 |
| Sabitlenmemiş `search_path` definer | 0 | **0** | ✅ GUV-14/15 |
| `teklifler`/`teklif_hizmetleri` RESTRICTIVE | >0 | **2** | ✅ GUV-06 |
| `noter_defteri_obj_read` politikası | authenticated+tenant | **1** | ✅ GUV-01 |
| `handle_new_user` sabit e-posta | yok | **false** | ✅ GUV-16 |
| `handle_new_user` metadata rol okuma | yok | **okumuyor, hep pending** | ✅ GUV-02 |
| `osgb_access_ok` NULL dalı | yok | **yok** | ✅ GUV-07 |
| anon-çağrılabilir definer fonksiyon | azaltılmış | **22** (kasıtlı yardımcılar + public teklif akışı) | ✅ GUV-11/13/13b |

> Kalan 22 fonksiyon **kasten açık**: RLS/erişim yardımcıları (politikalar içinde `false`/boş döner) + meşru public teklif/destek akışı. Kapatılırsa RLS kırılırdı → **dokunulmadı (doğru karar)**.

---

## 3) ❌ / ⏳ KALAN İŞLER

### 3.1 Kod ile yapılamaz (hosting / platform katmanı)

| # | Madde | Neden kalan | Nerede yapılır |
|---|---|---|---|
| GUV-03 | Production sourcemap (`build.sourcemap: true`) | `vite.config.ts` platform tarafından **yazmaya kapalı** | Platform build ayarı / dağıtım ortamı → `sourcemap:false` |
| GUV-10 | HTTP güvenlik başlıkları (HSTS, `X-Content-Type-Options`, `frame-ancestors`, `Referrer-Policy`) | Yalnız **HTTP yanıt başlığı** ile verilir; `<meta>` ile verilemez | Hosting / CDN katmanı |

### 3.2 Hazır ama uygulanmadı (deploy + secret gerekir)

| # | Madde | Durum |
|---|---|---|
| GUV-04 | Edge Function CORS wildcard (`*`) → origin allowlist | 🟨 Modül hazır (`SECURITY_FINAL_REMEDIATION_REPORT.md §5.1`); 43 dosya **tek tek deploy+test** edilerek dönüştürülmeli; `ALLOWED_ORIGINS` secret'ı gerekir |

### 3.3 Doğrulama / ek iş

| # | Madde | Durum |
|---|---|---|
| D1 | İzole test ortamında runtime testleri (tenant A/B, RLS, Storage, RPC) | ⛔ Test ortamı yok → çalıştırılamadı (canlı doğrulama yapıldı, ama izole regresyon testi ayrıdır) |
| D2 | Ayrı `tsc --noEmit` / `eslint` / `npm audit` | ⛔ Komut yürütücü/izole ortam yok |
| D3 | `.env` git geçmişi denetimi → sır rotate gerekli mi | ⏳ Git geçmişi erişimi gerekir |
| D4 | Uygulama içi gerçek akış denemesi (davet kabul, belge yükleme, personel fotoğrafı, teklif oluşturma/gönderme) | ⏳ **Kullanıcı tarafından manuel deneme bekleniyor** |

---

## 4) GERİ ALMA (ROLLBACK)

Her değişikliğin tersine çevirme dosyası hazır:

`supabase/migrations/rollback/20260101000{1..9}00_*_rollback.sql` + `...1000_guv16_*_rollback.sql`

Rollback dosyaları, ilgili açığı **bilerek geri açar** (acil geri dönüş içindir). Üretimde
sıkıntı olursa tek komutla dönülebilir.

---

## 5) ÖNERİLEN SONRAKİ ADIMLAR

1. **Manuel duman testi (smoke test):** Gerçek admin hesabınla gir → davet kabul et, belge yükle, personel fotoğrafı ekle, teklif oluştur/gönder. Bir hata görürsen hemen bakarız.
2. **Kalan kod-dışı iki madde:** sourcemap (GUV-03) ve HTTP başlıkları (GUV-10) için hosting/platform tarafını ayarla.
3. **CORS (GUV-04):** İstersen `ALLOWED_ORIGINS` secret'ını ekleyip fonksiyonları **tek tek** allowlist'e geçirelim (her biri deploy sonrası preflight ile test edilir).
4. **`.env` geçmişi:** Git geçmişinde `.env` commit'lendi mi kontrol edilip gerekirse sırlar rotate edilsin.

> **Not:** Bu çalışma resmî TSE onaylı sızma testinin yerine geçmez. İzole ortamda çalıştırılmış
> gerçek RLS/tenant regresyon testleri tamamlanana kadar veri katmanı için **"sıfır risk"**
> denmez; ancak **bugün itibarıyla bilinen 11 bulgunun tamamı canlıda kapatılmış ve doğrulanmıştır.**