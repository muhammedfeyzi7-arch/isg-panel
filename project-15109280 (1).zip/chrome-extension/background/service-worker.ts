/**
 * Background / Service Worker — İSG-KATİP orkestrasyonu (FAZ 6K).
 *
 * Görevler:
 *  1. Content script'ten gelen isteği, sekmenin MAIN world'ünde çalışan ve KATİP SPA'nın
 *     KENDİ gerçek isteklerinin response'unu SALT GÖZLEMLE yakalayan bellekten OKUR.
 *     İKİNCİ bir authenticated HTTP isteği ATILMAZ.
 *  2. Normalize payload'u İSGDenetim sync endpoint'ine gönderir (opsiyonel;
 *     yalnızca OSGB kapsamlı yapılandırma mevcutsa).
 *
 * GÜVENLİK: token/Authorization/cookie hiçbir yerde OKUNMAZ, TAŞINMAZ, YAZILMAZ ve
 * backend'e GÖNDERİLMEZ. Yalnızca NORMALİZE veri gider.
 */
import {
  ISGDENETIM_SYNC_FUNCTION,
  type ExtensionSyncConfig,
  type KatipCapturedRequestMessage,
  type KatipCapturedResponseMessage,
} from '../shared/messages';
import { readCapturedRows } from '../shared/katipBridge';
import { getSettings, runAutoSyncOnce } from '../shared/katipAutoSync';

/**
 * MAIN world'de çalışan, KENDİ KENDİNE YETERLİ okuma fonksiyonu.
 * `chrome.scripting.executeScript` tarafından serialize edilir; DIŞ kapsama (closure)
 * REFERANS VEREMEZ. Bu yüzden tamamen izole yazılmıştır.
 *
 * `content/katip-main-hook.ts` tarafından YALNIZCA pencere belleğinde tutulan SON gerçek
 * KATİP response'unu OKUR. Hiçbir ağ isteği YAPMAZ; hiçbir başlık (token/Authorization)
 * OKUMAZ, taşımaz, loglamaz.
 */
function mainWorldReadCaptured(path: string) {
  const store = (window as unknown as {
    __ISG_KATIP_CAPTURED__?: Record<string, { status?: number | null; json?: unknown; rows?: unknown }>;
  }).__ISG_KATIP_CAPTURED__;
  const entry = store ? store[path] : undefined;
  if (!entry) {
    // Henüz gözlemlenmiş gerçek response yok → güvenli durum (token/raw veri YOK).
    return {
      ok: false,
      captured: false,
      code: 'NOT_CAPTURED',
      message:
        'KATİP ekranındaki verinin yüklenmesi bekleniyor. İlgili KATİP listesini ' +
        '(İSG Hizmet / Personel Sözleşmeleri) açın veya yenileyin; KATİP listeyi ' +
        'yüklediğinde veri otomatik yakalanır.',
    };
  }
  // AGGREGATED: MAIN hook'un birleştirdiği (tüm sayfalar + dedup) satırlar.
  // Yoksa (geriye dönük) ham json'dan güvenli biçimde çıkarılır.
  let rows: unknown[] = Array.isArray(entry.rows) ? entry.rows : [];
  if (rows.length === 0 && entry.json != null && typeof entry.json === 'object') {
    const j = entry.json as { body?: { tableData?: unknown }; tableData?: unknown };
    if (j.body && Array.isArray(j.body.tableData)) rows = j.body.tableData as unknown[];
    else if (Array.isArray(j.tableData)) rows = j.tableData as unknown[];
  }
  return {
    ok: true,
    captured: true,
    status: typeof entry.status === 'number' ? entry.status : undefined,
    json: { body: { tableData: rows } },
  };
}

/** Sekmenin MAIN world'ünde YAKALANAN gerçek KATİP response'unu okur (yeni istek YOK). */
async function handleReadCaptured(
  tabId: number | undefined,
  msg: KatipCapturedRequestMessage,
): Promise<KatipCapturedResponseMessage> {
  if (tabId == null) {
    return { ok: false, captured: false, code: 'NO_TAB', message: 'Aktif İSG-KATİP sekmesi bulunamadı.' };
  }
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      args: [msg.path],
      func: mainWorldReadCaptured,
    });
    return (results?.[0]?.result as KatipCapturedResponseMessage) ?? {
      ok: false,
      captured: false,
      code: 'NO_RESULT',
      message: 'İSG-KATİP yanıtı okunamadı.',
    };
  } catch (e: unknown) {
    return {
      ok: false,
      captured: false,
      code: 'READ_ERROR',
      message: e instanceof Error ? e.message : 'Enjeksiyon başarısız.',
    };
  }
}

/** Mesaj yönlendirici (content ↔ service worker). */
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const msg = message as { type?: string } | undefined;
  if (msg?.type === 'ISG_KATIP_CAPTURED_REQUEST') {
    handleReadCaptured(sender.tab?.id, message as KatipCapturedRequestMessage).then(sendResponse);
    return true; // asenkron yanıt
  }
  // FAZ 6J.3 — İSGDenetim iç-rölesi sayfa yüklendiğinde varlığını bildirir; tab lifecycle
  // kaydı güncellenir (yan etkisiz; popup hedefi daima chrome.tabs.query ile tazelenir).
  // GÜVENLİK: payload'daki tabId'ye GÜVENİLMEZ; sender.tab.id kullanılır ve sender URL'si
  // İSGDenetim exact origin'i ile doğrulanır. Yalnızca eşleşirse PRESENT yazılır.
  if (msg?.type === 'ISG_DENETIM_PRESENT' && sender.tab?.id != null) {
    if (isIsgDenetimUrl(sender.tab.url)) {
      isgDenetimTabs.set(sender.tab.id, { present: true, lastSeen: Date.now() });
    }
  }
  // FAZ 6J.4 — İSGDenetim rölesinden gelen talep: KATİP sekmesindeki GERÇEK yakalanmış
  // (READ-ONLY interception) satırları oku ve SPA'ya döndür (New Firma "İSG-KATİP'ten Aktar").
  // 🔒 YENİ KATİP HTTP isteği YOK; token/cookie/JWT okunmaz/taşınmaz; hiçbir yazma yapılmaz.
  if (msg?.type === 'ISG_KATIP_RELAY_CAPTURED_REQUEST') {
    readCapturedRows()
      .then((rows) =>
        sendResponse({
          ok: true,
          captured: rows.captured,
          hizmetRows: rows.hizmetRows,
          personelRows: rows.personelRows,
          capturedAt: new Date().toISOString(),
          dataset: rows.dataset,
          error: rows.error,
        }),
      )
      .catch((e: unknown) =>
        sendResponse({
          ok: false,
          captured: false,
          hizmetRows: [],
          personelRows: [],
          error: e instanceof Error ? e.message : 'İSG-KATİP verisi okunamadı.',
        }),
      );
    return true; // asenkron yanıt
  }
  return false;
});

/* -------------------------------------------------------------------------- */
/* FAZ 6J.3 — İSGDenetim TAB LIFECYCLE (gerçek tab yaşam döngüsü)              */
/*                                                                            */
/* Yalnızca MİNİMUM runtime state tutulur (tabId → present/lastSeen). STALE    */
/* tabId KULLANILMAZ: tab kapanınca (onRemoved) ve navigasyon/reload başlayınca */
/* (onUpdated status='loading') kayıt temizlenir/geçersizlenir; yeni röle READY */
/* mesajı beklenir. Popup'ın hedef çözümü bu state'e bağlı DEĞİLDİR (o, her     */
/* seferinde chrome.tabs.query ile taze kaynaktan çözer) → service worker       */
/* restart olsa bile doğru çalışır.                                             */
/* -------------------------------------------------------------------------- */
const isgDenetimTabs = new Map<number, { present: boolean; lastSeen: number }>();

/** İSGDenetim production origin'i (manifest host_permissions ile birebir). */
const ISG_DENETIM_ORIGIN = 'https://app.isgdenetim.com.tr';

/** Bir URL tam olarak İSGDenetim origin'ine mi ait? (hoisted function — yukarıda kullanılır) */
function isIsgDenetimUrl(url: string | undefined): boolean {
  if (!url) return false;
  try {
    return new URL(url).origin === ISG_DENETIM_ORIGIN;
  } catch {
    return false;
  }
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  const url = changeInfo.url ?? tab.url;
  // Yalnızca İSGDenetim sekmesini izle. URL İSGDenetim DEĞİLSE state tutma; ayrıca sekme
  // İSGDenetim'den başka bir adrese gittiyse stale kaydı temizle.
  if (!isIsgDenetimUrl(url)) {
    if (changeInfo.url || changeInfo.status === 'loading') isgDenetimTabs.delete(tabId);
    return;
  }
  if (changeInfo.status === 'loading') {
    // Navigasyon/reload (F5) → eski röle artık geçersiz; eski PRESENT'i READY sayma.
    // Yeni document gerçekten röle PRESENT mesajı gönderdiğinde tekrar PRESENT olur.
    isgDenetimTabs.set(tabId, { present: false, lastSeen: Date.now() });
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  isgDenetimTabs.delete(tabId);
});

/**
 * Normalize payload'u İSGDenetim'e gönderir.
 * Yalnızca extension'ın backend ile temas noktasıdır; yalnızca NORMALİZE veri gider.
 */
export async function pushToIsgDenetim(
  config: ExtensionSyncConfig,
  payload: unknown,
): Promise<{ ok: boolean; status: number; body: unknown }> {
  const url = `${config.supabaseUrl}/functions/v1/${ISGDENETIM_SYNC_FUNCTION}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      apikey: config.supabaseAnonKey,
      Authorization: `Bearer ${config.authToken}`,
    },
    body: JSON.stringify({ mode: 'sync', payload }),
  });
  const body = await res.json().catch(() => null);
  return { ok: res.ok, status: res.status, body };
}

/**
 * Toolbar tıklamasında aktif sekmeden toplama tetikler.
 * Backend'e gönderim, OSGB kapsamlı yapılandırma mevcutsa ayrıca yapılır; bu fazda
 * import motoru PASİF olduğu için gönderim yalnızca doğrulama amaçlıdır.
 */
chrome.action.onClicked.addListener(async (tab) => {
  if (tab?.id == null) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'ISG_KATIP_COLLECT_REQUEST' });
  } catch {
    // Content script yüklü değilse sessizce çık (İSG-KATİP sayfası değil).
  }
});

/* -------------------------------------------------------------------------- */
/* v1.0.0 — OTOMATİK ÇALIŞAN SAYISI SENKRONİZASYONU (chrome.alarms)            */
/*                                                                            */
/* `chrome.alarms` periyodik tetikler → runAutoSyncOnce() → İSGDenetim SPA      */
/* köprüsüne "eşleşmiş firmaların çalışan sayısını senkronize et" isteği gider. */
/* Gerçek okuma + yazma İSGDenetim SPA'sında (Supabase oturumu + RLS) yapılır.  */
/* Yan panel (side panel) KALDIRILDI. 🔒 token/cookie/JWT taşınmaz.             */
/* -------------------------------------------------------------------------- */
const AUTO_SYNC_ALARM = 'isgKatipAutoSync';

/** Periyodik alarmı kullanıcı ayarına göre (yeniden) planlar. */
async function scheduleAutoSync(): Promise<void> {
  try {
    const settings = await getSettings();
    await chrome.alarms.clear(AUTO_SYNC_ALARM);
    if (settings.autoSync) {
      chrome.alarms.create(AUTO_SYNC_ALARM, {
        periodInMinutes: Math.max(1, settings.intervalMinutes),
      });
    }
  } catch {
    // yoksay: alarms API erişilemezse akış bozulmaz.
  }
}

chrome.runtime.onInstalled.addListener(() => {
  void scheduleAutoSync();
  void runAutoSyncOnce('startup');
});
chrome.runtime.onStartup.addListener(() => {
  void scheduleAutoSync();
  void runAutoSyncOnce('startup');
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === AUTO_SYNC_ALARM) void runAutoSyncOnce('alarm');
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const msg = message as { type?: string } | undefined;
  if (msg?.type === 'ISG_KATIP_AUTO_SYNC_SETTINGS_CHANGED') {
    void scheduleAutoSync().then(() => sendResponse({ ok: true }));
    return true; // asenkron yanıt
  }
  if (msg?.type === 'ISG_KATIP_AUTO_SYNC_RUN_NOW') {
    void runAutoSyncOnce('manual').then(() => sendResponse({ ok: true }));
    return true; // asenkron yanıt
  }
  return false;
});