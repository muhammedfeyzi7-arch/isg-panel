/**
 * FAZ 6L — KATİP Sync çalışma alanı SESSION STATE PERSISTENCE.
 *
 * AMAÇ: Side Panel popup'tan bağımsız, kalıcı çalışma alanıdır. Pilot/Dry Run/WRITE/Verify
 * workflow state'i React/DOM memory'de bırakılmaz; `chrome.storage.session` ile PERSIST edilir
 * (tarayıcı oturumu boyunca; tarayıcı kapanınca otomatik temizlenir).
 *
 * 🔒 KESİNLİKLE SAKLANMAZ: Token · Cookie · JWT · Authorization header · KATİP session secret ·
 * TC Kimlik No. Bu dosyada yalnızca workflow state/result/maskeli kimlik saklanır.
 * KATİP response interception BELLEK-İÇİ kalır (buraya ASLA yazılmaz).
 */

/** Seçili KATİP pilot firması (worksiteId bir işyeri kimliğidir; session secret DEĞİL). */
export interface PersistedPilotSelection {
  worksiteId: string;
  worksiteIdMasked: string | null;
  title: string;
  katipCalisanSayisi: number | null;
}

/** Persist edilen güvenli workflow state'i (PII/session secret İÇERMEZ). */
export interface KatipSyncSessionState {
  /** Kaba workflow adımı (UI geri yükleme için). */
  workflowStep: string | null;
  selectedKatipPilotFirm: PersistedPilotSelection | null;
  selectedIsgDenetimFirm: string | null;
  pilotSource: 'AUTO' | 'MANUAL' | null;
  /** Otomatik resolver sonucu (LoosePilot; PII maskeli). */
  pilotResult: unknown | null;
  /** İki taraflı manuel önizleme (KatipManualPilotPreview; PII maskeli). */
  manualPreview: unknown | null;
  /** Salt-okuma write planı snapshot'ı. */
  pilotWritePlan: unknown | null;
  /** Pilot WRITE sonucu (LooseApply; PII İÇERMEZ). */
  pilotApplyResult: unknown | null;
  /** Verify sonucu (apply içinden; özet). */
  pilotVerifyResult: unknown | null;
  lastPilotCorrelationId: string | null;
  /** FAZ 6J.3 — Pilot Dry Run operation state (bağlantı state'inden AYRI). */
  pilotDryRunState: string | null;
  /** Pilot Dry Run sonucu (LooseDryRun; PII İÇERMEZ). */
  pilotDryRunResult: unknown | null;
  /** Pilot Dry Run hata bilgisi (stage/code/message; PII İÇERMEZ). */
  pilotDryRunError: unknown | null;
}

export const KATIP_SESSION_KEY = 'isgKatipSyncWorkspace';

/** Boş state üretir. */
export function emptySessionState(): KatipSyncSessionState {
  return {
    workflowStep: null,
    selectedKatipPilotFirm: null,
    selectedIsgDenetimFirm: null,
    pilotSource: null,
    pilotResult: null,
    manualPreview: null,
    pilotWritePlan: null,
    pilotApplyResult: null,
    pilotVerifyResult: null,
    lastPilotCorrelationId: null,
    pilotDryRunState: null,
    pilotDryRunResult: null,
    pilotDryRunError: null,
  };
}

/**
 * `chrome.storage.session` API'si bu tarayıcıda var mı? (Defansif; tip/uyumluluk için cast.)
 */
function sessionArea(): chrome.storage.StorageArea | null {
  try {
    const s = chrome.storage as unknown as { session?: chrome.storage.StorageArea };
    return s.session ?? null;
  } catch {
    return null;
  }
}

/**
 * Session state'i yükler. Yoksa/bozuksa `null` döner (güvenli başlangıç; asla çökmez).
 */
export async function loadSessionState(): Promise<KatipSyncSessionState | null> {
  const area = sessionArea();
  if (!area) return null;
  try {
    const raw = await area.get(KATIP_SESSION_KEY);
    const value = raw?.[KATIP_SESSION_KEY];
    if (!value || typeof value !== 'object') return null;
    // Bozuk/eksik state'i güvenli biçimde boş state ile harmanla (kısmi restore).
    return { ...emptySessionState(), ...(value as Partial<KatipSyncSessionState>) };
  } catch {
    return null;
  }
}

/**
 * Verilen patch'i mevcut session state ile birleştirip yazar. Yazma hatası workflow'u
 * KIRMAZ (state best-effort'tur); sessizce yutulur.
 */
export async function saveSessionState(
  patch: Partial<KatipSyncSessionState>,
): Promise<void> {
  const area = sessionArea();
  if (!area) return;
  try {
    const current = (await loadSessionState()) ?? emptySessionState();
    const next: KatipSyncSessionState = { ...current, ...patch };
    await area.set({ [KATIP_SESSION_KEY]: next });
  } catch {
    // best-effort: sessizce yoksay.
  }
}

/** Session state'i tamamen temizler (corrupt/stale state için). */
export async function clearSessionState(): Promise<void> {
  const area = sessionArea();
  if (!area) return;
  try {
    await area.remove(KATIP_SESSION_KEY);
  } catch {
    // yoksay.
  }
}