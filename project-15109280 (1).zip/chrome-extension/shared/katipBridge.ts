/**
 * FAZ 6L — İSG-KATİP extension PAYLAŞILAN KÖPRÜ ÇEKİRDEĞİ.
 *
 * Popup (hızlı durum) ve Side Panel (kalıcı sync çalışma alanı) bu modülü ORTAK kullanır.
 * Davranış FAZ 6J/6K ile BİREBİR aynıdır; yalnızca kod popup.ts'ten buraya TAŞINMIŞTIR.
 *
 * ⛔ DEĞİŞMEYEN SÖZLEŞMELER:
 *  - bridge.ts postMessage protokolü (HELLO / HELLO_ACK / DATA / RESULT / PILOT / APPLY)
 *  - service worker KATİP capture mantığı ve content script'ler
 *  - Discovery endpointleri, response interception, write core, isg-katip-sync / RPC
 *
 * 🔒 GÜVENLİK: token/cookie/JWT/Authorization OKUNMAZ, TAŞINMAZ, YAZILMAZ. İkinci bir
 * authenticated KATİP HTTP isteği ATILMAZ. Yalnızca gözlemlenen (interception) veri okunur.
 *
 * NOT: `func:` ile enjekte edilen fonksiyonlar (aşağıdaki senders) TAMAMEN İZOLE yazılmıştır;
 * dış kapsama (closure) referans VERMEZ — bu zorunludur (serialize edilip sayfada çalışır).
 */
import type { ExtensionMessage } from './messages';
import {
  extractTableData,
  KATIP_HIZMET_SOZLESMESI_PATH,
  KATIP_PERSONEL_SOZLESMESI_PATH,
} from '../../src/lib/isgKatip/endpoints';
import {
  buildDatasetReport,
  resolveOverallDiscoveryStatus,
  summarizeCapture,
  type KatipCaptureSummary,
  type KatipCapturedPageMeta,
  type KatipDatasetReport,
  type KatipOverallDiscoveryStatus,
} from '../../src/lib/isgKatip/capture';

export const KATIP_HOST = 'isgkatip.csgb.gov.tr';
/** İSGDenetim'in GERÇEK yayın origin host'u (manifest host_permissions ile birebir). */
export const ISG_DENETIM_HOST = 'app.isgdenetim.com.tr';

/** Popup/Side Panel açılışında otomatik köprü kurulumu için MAKSİMUM bekleme süresi (ms). */
export const AUTO_CONNECT_TIMEOUT_MS = 5000;
/** Otomatik köprü kurulumunda en fazla kaç kontrollü reconnect denenir (sonsuz döngü YOK). */
export const AUTO_CONNECT_RECONNECTS = 2;

/** Kısa bekleme yardımcısı. */
export function delayMs(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** Popup/Side Panel ↔ köprü kanalı sonucu. */
export interface BridgeChannelResult {
  ok: boolean;
  status: string;
  result?: unknown;
  pilot?: unknown;
  apply?: unknown;
  backfill?: unknown;
  error?: string;
}

/** Dry Run kanalı sender sonucu. */
export interface SpaSenderResult {
  ok: boolean;
  status: string;
  result?: unknown;
  error?: string;
}

/** Pilot kanalı sender sonucu. */
export interface SpaPilotSenderResult {
  ok: boolean;
  status: string;
  pilot?: unknown;
  error?: string;
}

/** Köprüye taşınan normalize edilmiş payload (PII/session secret İÇERMEZ). */
export interface BridgePayload {
  hizmetRows: unknown[];
  personelRows: unknown[];
  capturedAt: string;
  pilotFirmExternalId?: string;
  osgbIdHint?: string | null;
  /** FAZ A/B — pilot kapsam kaynağı (AUTO/MANUAL). */
  pilotSource?: 'AUTO' | 'MANUAL';
  /** FAZ A/B — seçilen KATİP firma unvanı (yalnızca rapor). */
  pilotFirmTitle?: string | null;
  /** FAZ 3 — KATİP veri toplama TAMAMLANDI mı (WRITE kapısı; false → blok). */
  datasetComplete?: boolean;
}

/** Okunan gerçek KATİP satırları (READ-ONLY interception belleği). */
export interface CapturedRows {
  hizmetRows: Record<string, unknown>[];
  personelRows: Record<string, unknown>[];
  captured: boolean;
  error?: string;
  /** FAZ 6J.6 — yakalanan veri setinin sayfa/tamamlanma özeti (PII'siz). */
  dataset?: { hizmet: KatipCaptureSummary; personel: KatipCaptureSummary };
  /** FAZ 1 — kanonik veri toplama durumu (state + pagination + overall). PII İÇERMEZ. */
  report?: {
    hizmet: KatipDatasetReport;
    personel: KatipDatasetReport;
    overall: KatipOverallDiscoveryStatus;
  };
}

export async function getActiveTab(): Promise<chrome.tabs.Tab | null> {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0] ?? null;
}

export function isKatipUrl(url: string | undefined): boolean {
  if (!url) return false;
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    return host === KATIP_HOST || host.endsWith(`.${KATIP_HOST}`);
  } catch {
    return false;
  }
}

/**
 * FAZ 6J.3 — İSGDenetim hedefini GERÇEK tarayıcı registry'sinden çözer (AKTİF sekmeye BAĞLI DEĞİL).
 * `chrome.tabs.query({ url })` her çağrıda TAZE sonuç verir → stale tabId riski YOK.
 */
export async function resolveIsgDenetimTab(): Promise<chrome.tabs.Tab | null> {
  const tabs = await chrome.tabs.query({ url: `https://${ISG_DENETIM_HOST}/*` });
  return tabs.find((t) => t.id != null) ?? null;
}

/**
 * "İSGDenetim'i Aç" gerçek aksiyonu: açık bir İSGDenetim sekmesi varsa onu odaklar; yoksa
 * yeni bir sekmede İSGDenetim uygulamasını açar. Yeni KATİP isteği ATMAZ; token taşımaz.
 */
export async function openIsgDenetimApp(): Promise<void> {
  try {
    const existing = await resolveIsgDenetimTab();
    if (existing?.id != null) {
      await chrome.tabs.update(existing.id, { active: true });
      if (existing.windowId != null) {
        try {
          await chrome.windows.update(existing.windowId, { focused: true });
        } catch {
          // windows API yoksa/izin yoksa yoksay.
        }
      }
      return;
    }
    await chrome.tabs.create({ url: `https://${ISG_DENETIM_HOST}/` });
  } catch {
    // chrome API erişilemezse sessizce çık (buton görselde kalır, çökme YOK).
  }
}

/** Popup/Side Panel ↔ içerik betiği mesaj sonucu. `lastError` GİZLENMEZ (kök neden teşhisi). */
export interface SendResult<T> {
  res?: T;
  lastError?: string;
}

/**
 * Sekmeye mesaj gönderir. `chrome.runtime.lastError` YUTULMAZ; çağırana taşınır.
 */
export function sendToTab<T>(tabId: number, message: ExtensionMessage): Promise<SendResult<T>> {
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, (res: T) => {
      const err = chrome.runtime.lastError;
      if (err) {
        resolve({ lastError: err.message });
        return;
      }
      resolve({ res });
    });
  });
}

/** İçerik betiği bu sekmeye bağlı mı? (Ping — veri çekmez.) */
export async function pingContentScript(tabId: number): Promise<boolean> {
  const { res } = await sendToTab<ExtensionMessage & { ready?: boolean }>(tabId, {
    type: 'ISG_KATIP_STATUS_REQUEST',
  });
  return Boolean(res && res.type === 'ISG_KATIP_STATUS_RESULT');
}

/**
 * İçerik betiğinin sekmeye bağlı olduğundan emin olur. Bağlı değilse güvenle yeniden enjekte eder.
 */
export async function ensureContentScript(
  tabId: number,
): Promise<{ ok: boolean; error?: string; injected?: boolean }> {
  if (await pingContentScript(tabId)) return { ok: true, injected: false };
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ['content/katip-content.js'],
    });
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : 'İçerik betiği enjekte edilemedi.',
    };
  }
  for (let i = 0; i < 6; i += 1) {
    // eslint-disable-next-line no-await-in-loop
    await delayMs(80);
    // eslint-disable-next-line no-await-in-loop
    if (await pingContentScript(tabId)) return { ok: true, injected: true };
  }
  return { ok: false, injected: true, error: 'İçerik betiği enjekte edildi ancak yanıt vermedi.' };
}

/** Bir sekmeye röle mesajı gönderir; listener yoksa (lastError) `undefined` döner. */
export function sendRelayMessage(
  tabId: number,
  message: Record<string, unknown>,
): Promise<BridgeChannelResult | undefined> {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, message, (r: BridgeChannelResult) => {
        if (chrome.runtime.lastError) {
          resolve(undefined);
          return;
        }
        resolve(r);
      });
    } catch {
      resolve(undefined);
    }
  });
}

/* -------------------------------------------------------------------------- */
/* Enjekte edilen (self-contained) fonksiyonlar                                */
/* NOT: `chrome.scripting.executeScript({ func })` ile serialize edilir;         */
/* DIŞ kapsama referans VEREMEZLER. Tamamen izole yazılmalıdır.                  */
/* -------------------------------------------------------------------------- */

/** İSG-KATİP sekmesinin MAIN world belleğinden iki endpoint'in SON gerçek response JSON'unu okur. */
function readKatipRawCaptured(paths: string[]): Record<string, unknown> {
  const store = (window as unknown as {
    __ISG_KATIP_CAPTURED__?: Record<
      string,
      {
        json?: unknown;
        rows?: unknown;
        meta?: unknown;
        reportedTotal?: unknown;
        capturedAt?: unknown;
        status?: unknown;
        pagination?: unknown;
        sessionId?: unknown;
      }
    >;
  }).__ISG_KATIP_CAPTURED__;
  const out: Record<string, unknown> = {};
  for (let i = 0; i < paths.length; i += 1) {
    const entry = store ? store[paths[i]] : undefined;
    if (!entry) {
      out[paths[i]] = null;
      continue;
    }
    // AGGREGATED: MAIN hook'un birleştirdiği (tekilleştirilmiş) satırlar.
    // Yoksa (geriye dönük uyumluluk) ham json'dan güvenli biçimde çıkarılır.
    let rows: unknown[] = Array.isArray(entry.rows) ? (entry.rows as unknown[]) : [];
    if (rows.length === 0 && entry.json != null && typeof entry.json === 'object') {
      const j = entry.json as { body?: { tableData?: unknown }; tableData?: unknown };
      if (j.body && Array.isArray(j.body.tableData)) rows = j.body.tableData as unknown[];
      else if (Array.isArray(j.tableData)) rows = j.tableData as unknown[];
    }
    out[paths[i]] = {
      status: typeof entry.status === 'number' ? entry.status : null,
      rows,
      meta: Array.isArray(entry.meta) ? entry.meta : [],
      reportedTotal: typeof entry.reportedTotal === 'number' ? entry.reportedTotal : null,
      capturedAt: typeof entry.capturedAt === 'number' ? entry.capturedAt : null,
      pagination:
        entry.pagination && typeof entry.pagination === 'object' ? entry.pagination : null,
      sessionId: typeof entry.sessionId === 'number' ? entry.sessionId : null,
    };
  }
  return out;
}

/** Aktif sekmeye MAIN-world enjekte edilen DRY RUN köprü sender'ı (self-contained). */
async function spaBridgeSender(payload: {
  hizmetRows: unknown[];
  personelRows: unknown[];
  capturedAt: string;
  pilotFirmExternalId?: string;
  pilotSource?: 'AUTO' | 'MANUAL';
  pilotFirmTitle?: string | null;
}): Promise<{ ok: boolean; status: string; result?: unknown; error?: string }> {
  const GLOBAL_KEY = '__ISG_KATIP_SPA_BRIDGE__';
  const HELLO = 'ISG_KATIP_BRIDGE_HELLO';
  const HELLO_ACK = 'ISG_KATIP_BRIDGE_HELLO_ACK';
  const DATA = 'ISG_KATIP_DRY_RUN_DATA';
  const RESULT = 'ISG_KATIP_DRY_RUN_RESULT';
  const V = 1;

  const g = window as unknown as Record<string, unknown>;
  const bridge = g[GLOBAL_KEY] as { install?: () => unknown } | undefined;
  if (!bridge || typeof bridge.install !== 'function') {
    return {
      ok: false,
      status: 'BRIDGE_NOT_READY',
      error: 'Aktif sekmede İSGDenetim köprüsü bulunamadı.',
    };
  }
  try {
    bridge.install();
  } catch {
    // yoksay: listener zaten kurulu olabilir (idempotent).
  }

  const origin = window.location.origin;
  return new Promise<{ ok: boolean; status: string; result?: unknown; error?: string }>((resolve) => {
    let settled = false;
    const finish = (r: { ok: boolean; status: string; result?: unknown; error?: string }): void => {
      if (settled) return;
      settled = true;
      window.removeEventListener('message', onMessage);
      resolve(r);
    };
    const onMessage = (event: MessageEvent): void => {
      if (event.source !== window) return;
      const d = event.data as Record<string, unknown> | null;
      if (!d || typeof d !== 'object') return;
      if (d.channel === HELLO_ACK) {
        window.postMessage(
          {
            channel: DATA,
            v: V,
            hizmetRows: payload.hizmetRows,
            personelRows: payload.personelRows,
            capturedAt: payload.capturedAt,
            pilotFirmExternalId: payload.pilotFirmExternalId,
            pilotSource: payload.pilotSource,
            pilotFirmTitle: payload.pilotFirmTitle,
          },
          origin,
        );
        return;
      }
      if (d.channel === RESULT) {
        finish({
          ok: Boolean(d.ok),
          status: typeof d.status === 'string' ? d.status : 'UNKNOWN',
          result: d.result,
          error: typeof d.error === 'string' ? d.error : undefined,
        });
      }
    };
    window.addEventListener('message', onMessage);
    window.postMessage({ channel: HELLO, v: V }, origin);
    window.setTimeout(() => {
      finish({
        ok: false,
        status: 'BRIDGE_NOT_READY',
        error: 'İSGDenetim köprüsü yanıt vermedi (zaman aşımı).',
      });
    }, 12000);
  });
}

/**
 * İSGDenetim sekmesine enjekte edilen KALICI izole-dünya rölesi (self-contained).
 * `chrome.runtime.onMessage` ile popup/Side Panel'den gelen Dry Run / Pilot / Apply isteğini
 * alır; sayfanın MAIN-world köprüsüyle `window.postMessage` el sıkışması yapıp sonucu döndürür.
 * İdempotent: aynı frame'e tekrar enjekte edilirse yeni listener EKLENMEZ.
 */
function denetimRelayInstaller(): boolean {
  const g = globalThis as unknown as Record<string, unknown>;
  if (g.__ISG_KATIP_DENETIM_RELAY__) return true;
  g.__ISG_KATIP_DENETIM_RELAY__ = true;

  const HELLO = 'ISG_KATIP_BRIDGE_HELLO';
  const HELLO_ACK = 'ISG_KATIP_BRIDGE_HELLO_ACK';
  const DATA = 'ISG_KATIP_DRY_RUN_DATA';
  const RESULT = 'ISG_KATIP_DRY_RUN_RESULT';
  const PILOT = 'ISG_KATIP_PILOT_REQUEST';
  const PILOT_RESULT = 'ISG_KATIP_PILOT_RESULT';
  const APPLY = 'ISG_KATIP_PILOT_APPLY_REQUEST';
  const APPLY_RESULT = 'ISG_KATIP_PILOT_APPLY_RESULT';
  const BACKFILL = 'ISG_KATIP_BACKFILL_REQUEST';
  const BACKFILL_RESULT = 'ISG_KATIP_BACKFILL_RESULT';
  const WORKSITES_REQUEST = 'ISG_KATIP_WORKSITES_REQUEST';
  const WORKSITES_RESULT = 'ISG_KATIP_WORKSITES_RESULT';
  const EMP_SYNC_REQUEST = 'ISG_KATIP_EMP_SYNC_REQUEST';
  const EMP_SYNC_RESULT = 'ISG_KATIP_EMP_SYNC_RESULT';
  const V = 1;

  /**
   * FAZ 6J.6 — ROOT CAUSE FIX: SPA → RÖLE "yakalanan KATİP işyerleri" talebi.
   *
   * ⛔ BU HANDLER DAHA ÖNCE BU (scripting ile enjekte edilen) rölede EKSİKTİ; yalnızca
   * declarative `content/denetim-relay.ts` içeriyordu. Side Panel açılınca bu röle kuruluyor
   * (frame bayrağını kapıyor) ama WORKSITES handler'ı olmadığı için New Firma "İSG-KATİP'ten
   * Aktar" köprüsü zaman aşımına düşüyordu. Artık İKİ röle de AYNI kanalları destekler
   * (tek canonical davranış). Yeni KATİP HTTP isteği YOK; token/cookie/JWT taşınmaz.
   */
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const d = event.data as Record<string, unknown> | null;
    if (!d || typeof d !== 'object') return;
    if (d.channel !== WORKSITES_REQUEST || d.v !== V) return;
    const origin = window.location.origin;
    try {
      chrome.runtime.sendMessage({ type: 'ISG_KATIP_RELAY_CAPTURED_REQUEST' }, (res) => {
        void chrome.runtime.lastError;
        const r = (res ?? {}) as {
          ok?: boolean;
          captured?: boolean;
          hizmetRows?: unknown[];
          personelRows?: unknown[];
          capturedAt?: string;
          dataset?: unknown;
          error?: string;
        };
        try {
          window.postMessage(
            {
              channel: WORKSITES_RESULT,
              v: V,
              ok: Boolean(r.ok),
              captured: Boolean(r.captured),
              hizmetRows: r.hizmetRows ?? [],
              personelRows: r.personelRows ?? [],
              capturedAt: r.capturedAt ?? new Date().toISOString(),
              dataset: r.dataset,
              error: r.error,
            },
            origin,
          );
        } catch {
          // yoksay
        }
      });
    } catch {
      // yoksay: service worker yoksa talep sessizce başarısız olur (SPA zaman aşımına düşer).
    }
  });

  function exchange(
    kind: 'dryrun' | 'pilot' | 'apply' | 'backfill',
    payload: {
      hizmetRows: unknown[];
      personelRows: unknown[];
      capturedAt: string;
      pilotFirmExternalId?: string;
      osgbIdHint?: string | null;
      pilotSource?: 'AUTO' | 'MANUAL';
      pilotFirmTitle?: string | null;
      datasetComplete?: boolean;
    },
  ): Promise<{ ok: boolean; status: string; result?: unknown; pilot?: unknown; apply?: unknown; backfill?: unknown; error?: string }> {
    // SELF-HEALING: SPA köprü listener'ı tam sayfa yenilenmesi OLMADAN kaybolmuş olabilir.
    try {
      const gg = window as unknown as Record<string, unknown>;
      const br = gg.__ISG_KATIP_SPA_BRIDGE__ as { install?: () => unknown } | undefined;
      if (br && typeof br.install === 'function') br.install();
    } catch {
      // yoksay
    }
    return new Promise((resolve) => {
      const origin = window.location.origin;
      let settled = false;
      const finish = (r: { ok: boolean; status: string; result?: unknown; pilot?: unknown; apply?: unknown; backfill?: unknown; error?: string }): void => {
        if (settled) return;
        settled = true;
        window.removeEventListener('message', onMessage);
        resolve(r);
      };
      const onMessage = (event: MessageEvent): void => {
        if (event.source !== window) return;
        const d = event.data as Record<string, unknown> | null;
        if (!d || typeof d !== 'object') return;
        if (d.channel === HELLO_ACK) {
          const reqChannel =
            kind === 'apply'
              ? APPLY
              : kind === 'pilot'
                ? PILOT
                : kind === 'backfill'
                  ? BACKFILL
                  : DATA;
          const body: Record<string, unknown> = {
            channel: reqChannel,
            v: V,
            hizmetRows: payload.hizmetRows,
            personelRows: payload.personelRows,
            capturedAt: payload.capturedAt,
          };
          if (kind === 'apply') {
            body.pilotFirmExternalId = payload.pilotFirmExternalId;
            body.osgbIdHint = payload.osgbIdHint ?? null;
            body.datasetComplete = payload.datasetComplete ?? null;
          }
          if (kind === 'backfill') {
            body.osgbIdHint = payload.osgbIdHint ?? null;
          }
          if (kind === 'dryrun') {
            // FAZ A/B — pilot kapsamı kuru çalışmaya taşınır (yalnızca tek firma değerlendirilir).
            if (payload.pilotFirmExternalId) {
              body.pilotFirmExternalId = payload.pilotFirmExternalId;
              body.pilotSource = payload.pilotSource ?? null;
              body.pilotFirmTitle = payload.pilotFirmTitle ?? null;
            }
          }
          window.postMessage(body, origin);
          return;
        }
        if (
          d.channel === RESULT ||
          d.channel === PILOT_RESULT ||
          d.channel === APPLY_RESULT ||
          d.channel === BACKFILL_RESULT
        ) {
          finish({
            ok: Boolean(d.ok),
            status: typeof d.status === 'string' ? d.status : 'UNKNOWN',
            result: d.result,
            pilot: d.pilot,
            apply: d.apply,
            backfill: d.backfill,
            error: typeof d.error === 'string' ? d.error : undefined,
          });
        }
      };
      window.addEventListener('message', onMessage);
      window.postMessage({ channel: HELLO, v: V }, origin);
      window.setTimeout(() => {
        finish({ ok: false, status: 'BRIDGE_NOT_READY', error: 'İSGDenetim köprüsü yanıt vermedi (zaman aşımı).' });
      }, 12000);
    });
  }

  /**
   * v1.0.0 — OTOMATİK ÇALIŞAN SAYISI SENKRONU: MAIN-world SPA köprüsüne "eşleşmiş firmaların
   * çalışan sayısını senkronize et" isteği gönderir. Gerçek okuma + yazma SPA tarafında
   * (Supabase oturumu + RLS) yapılır. Yeni KATİP HTTP isteği ATILMAZ; token/cookie/JWT taşınmaz.
   */
  function exchangeEmpSync(): Promise<{ ok: boolean; status: string; sync?: unknown; error?: string }> {
    try {
      const gg = window as unknown as Record<string, unknown>;
      const br = gg.__ISG_KATIP_SPA_BRIDGE__ as { install?: () => unknown } | undefined;
      if (br && typeof br.install === 'function') br.install();
    } catch {
      // yoksay
    }
    return new Promise((resolve) => {
      const origin = window.location.origin;
      let settled = false;
      const finish = (r: { ok: boolean; status: string; sync?: unknown; error?: string }): void => {
        if (settled) return;
        settled = true;
        window.removeEventListener('message', onMessage);
        resolve(r);
      };
      const onMessage = (event: MessageEvent): void => {
        if (event.source !== window) return;
        const d = event.data as Record<string, unknown> | null;
        if (!d || typeof d !== 'object') return;
        if (d.channel === HELLO_ACK) {
          window.postMessage({ channel: EMP_SYNC_REQUEST, v: V }, origin);
          return;
        }
        if (d.channel === EMP_SYNC_RESULT) {
          finish({
            ok: Boolean(d.ok),
            status: typeof d.status === 'string' ? d.status : 'UNKNOWN',
            sync: d.sync,
            error: typeof d.error === 'string' ? d.error : undefined,
          });
        }
      };
      window.addEventListener('message', onMessage);
      window.postMessage({ channel: HELLO, v: V }, origin);
      window.setTimeout(() => {
        finish({ ok: false, status: 'BRIDGE_NOT_READY', error: 'İSGDenetim köprüsü yanıt vermedi (zaman aşımı).' });
      }, 30000);
    });
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const m = message as
      | {
          type?: string;
          payload?: {
            hizmetRows: unknown[];
            personelRows: unknown[];
            capturedAt: string;
            pilotFirmExternalId?: string;
            osgbIdHint?: string | null;
            pilotSource?: 'AUTO' | 'MANUAL';
            pilotFirmTitle?: string | null;
            datasetComplete?: boolean;
          };
        }
      | undefined;
    if (!m) return false;
    // Hafif ping: gerçek HELLO → HELLO_ACK doğrulanmadan 'BRIDGE_READY' denmez (sahte READY YOK).
    if (m.type === 'ISG_KATIP_RELAY_PING') {
      const pingOrigin = window.location.origin;
      let settled = false;
      const onMessage = (event: MessageEvent): void => {
        if (event.source !== window) return;
        const d = event.data as Record<string, unknown> | null;
        if (!d || d.channel !== HELLO_ACK) return;
        settled = true;
        window.removeEventListener('message', onMessage);
        sendResponse({ ok: true, status: 'BRIDGE_READY' });
      };
      window.addEventListener('message', onMessage);
      window.postMessage({ channel: HELLO, v: V }, pingOrigin);
      window.setTimeout(() => {
        window.removeEventListener('message', onMessage);
        if (!settled) sendResponse({ ok: false, status: 'BRIDGE_NOT_READY' });
      }, 1200);
      return true; // asenkron yanıt
    }
    if (m.type === 'ISG_KATIP_RELAY_EMP_SYNC') {
      void exchangeEmpSync().then(sendResponse);
      return true; // asenkron yanıt
    }
    if (
      m.type !== 'ISG_KATIP_RELAY_DRYRUN' &&
      m.type !== 'ISG_KATIP_RELAY_PILOT' &&
      m.type !== 'ISG_KATIP_RELAY_PILOT_APPLY' &&
      m.type !== 'ISG_KATIP_RELAY_BACKFILL'
    ) {
      return false;
    }
    if (!m.payload) {
      sendResponse({ ok: false, status: 'BRIDGE_NOT_READY', error: 'payload yok' });
      return false;
    }
    const kind: 'dryrun' | 'pilot' | 'apply' | 'backfill' =
      m.type === 'ISG_KATIP_RELAY_PILOT_APPLY'
        ? 'apply'
        : m.type === 'ISG_KATIP_RELAY_PILOT'
          ? 'pilot'
          : m.type === 'ISG_KATIP_RELAY_BACKFILL'
            ? 'backfill'
            : 'dryrun';
    void exchange(kind, m.payload).then(sendResponse);
    return true; // asenkron yanıt
  });
  return true;
}

/** Aktif sekmeye MAIN-world enjekte edilen PİLOT sender'ı (self-contained). */
async function spaPilotSender(payload: {
  hizmetRows: unknown[];
  personelRows: unknown[];
  capturedAt: string;
}): Promise<{ ok: boolean; status: string; pilot?: unknown; error?: string }> {
  const GLOBAL_KEY = '__ISG_KATIP_SPA_BRIDGE__';
  const HELLO = 'ISG_KATIP_BRIDGE_HELLO';
  const HELLO_ACK = 'ISG_KATIP_BRIDGE_HELLO_ACK';
  const PILOT = 'ISG_KATIP_PILOT_REQUEST';
  const PILOT_RESULT = 'ISG_KATIP_PILOT_RESULT';
  const V = 1;

  const g = window as unknown as Record<string, unknown>;
  const bridge = g[GLOBAL_KEY] as { install?: () => unknown } | undefined;
  if (!bridge || typeof bridge.install !== 'function') {
    return {
      ok: false,
      status: 'BRIDGE_NOT_READY',
      error: 'Aktif sekmede İSGDenetim köprüsü bulunamadı.',
    };
  }
  try {
    bridge.install();
  } catch {
    // yoksay: listener zaten kurulu olabilir (idempotent).
  }

  const origin = window.location.origin;
  return new Promise<{ ok: boolean; status: string; pilot?: unknown; error?: string }>((resolve) => {
    let settled = false;
    const finish = (r: { ok: boolean; status: string; pilot?: unknown; error?: string }): void => {
      if (settled) return;
      settled = true;
      window.removeEventListener('message', onMessage);
      resolve(r);
    };
    const onMessage = (event: MessageEvent): void => {
      if (event.source !== window) return;
      const d = event.data as Record<string, unknown> | null;
      if (!d || typeof d !== 'object') return;
      if (d.channel === HELLO_ACK) {
        window.postMessage(
          {
            channel: PILOT,
            v: V,
            hizmetRows: payload.hizmetRows,
            personelRows: payload.personelRows,
            capturedAt: payload.capturedAt,
          },
          origin,
        );
        return;
      }
      if (d.channel === PILOT_RESULT) {
        finish({
          ok: Boolean(d.ok),
          status: typeof d.status === 'string' ? d.status : 'UNKNOWN',
          pilot: d.pilot,
          error: typeof d.error === 'string' ? d.error : undefined,
        });
      }
    };
    window.addEventListener('message', onMessage);
    window.postMessage({ channel: HELLO, v: V }, origin);
    window.setTimeout(() => {
      finish({
        ok: false,
        status: 'BRIDGE_NOT_READY',
        error: 'İSGDenetim köprüsü yanıt vermedi (zaman aşımı).',
      });
    }, 12000);
  });
}

/** MAIN-world köprü KURULUM + HANDSHAKE sondası (self-contained). Sahte READY YOK. */
function spaBridgeProbe(): Promise<{ ready: boolean; found: boolean }> {
  const KEY = '__ISG_KATIP_SPA_BRIDGE__';
  const HELLO = 'ISG_KATIP_BRIDGE_HELLO';
  const HELLO_ACK = 'ISG_KATIP_BRIDGE_HELLO_ACK';
  const V = 1;
  const g = window as unknown as Record<string, unknown>;
  const bridge = g[KEY] as { install?: () => unknown } | undefined;
  if (!bridge || typeof bridge.install !== 'function') {
    return Promise.resolve({ ready: false, found: false });
  }
  try {
    bridge.install();
  } catch {
    // yoksay: listener zaten kurulu olabilir (idempotent).
  }
  return new Promise<{ ready: boolean; found: boolean }>((resolve) => {
    const origin = window.location.origin;
    let settled = false;
    const onMessage = (event: MessageEvent): void => {
      if (event.source !== window) return;
      const d = event.data as Record<string, unknown> | null;
      if (!d || d.channel !== HELLO_ACK) return;
      settled = true;
      window.removeEventListener('message', onMessage);
      resolve({ ready: true, found: true });
    };
    window.addEventListener('message', onMessage);
    window.postMessage({ channel: HELLO, v: V }, origin);
    window.setTimeout(() => {
      window.removeEventListener('message', onMessage);
      if (!settled) resolve({ ready: false, found: true });
    }, 1500);
  });
}

/* -------------------------------------------------------------------------- */
/* Yardımcılar (yardımcı DOM yok; yalnızca chrome + bridge)                      */
/* -------------------------------------------------------------------------- */

/** Kanonik çıkarımı güvenle uygular; kayıt yoksa boş dizi (tahmin/mock YOK). */
export function safeRows(json: unknown): Record<string, unknown>[] {
  try {
    return extractTableData(json) as Record<string, unknown>[];
  } catch {
    return [];
  }
}

/** KATİP sekmesindeki (varsa) gerçek yakalanmış satırları okur. Hiçbir yazma/ağ isteği YOK. */
export async function readCapturedRows(): Promise<CapturedRows> {
  const tabs = await chrome.tabs.query({ url: `https://${KATIP_HOST}/*` });
  const katipTab = tabs.find((t) => t.id != null);
  if (!katipTab?.id) {
    return {
      hizmetRows: [],
      personelRows: [],
      captured: false,
      error: 'İSG-KATİP sekmesi bulunamadı.',
    };
  }
  let raw: Record<string, unknown> | undefined;
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: katipTab.id },
      world: 'MAIN',
      args: [[KATIP_HIZMET_SOZLESMESI_PATH, KATIP_PERSONEL_SOZLESMESI_PATH]],
      func: readKatipRawCaptured,
    });
    raw = results?.[0]?.result as Record<string, unknown> | undefined;
  } catch (e) {
    return {
      hizmetRows: [],
      personelRows: [],
      captured: false,
      error: e instanceof Error ? e.message : 'İSG-KATİP verisi okunamadı.',
    };
  }
  const hizmetRaw = raw?.[KATIP_HIZMET_SOZLESMESI_PATH] as
    | {
        rows?: unknown;
        meta?: unknown;
        reportedTotal?: unknown;
        capturedAt?: unknown;
        pagination?: unknown;
        sessionId?: unknown;
      }
    | null
    | undefined;
  const personelRaw = raw?.[KATIP_PERSONEL_SOZLESMESI_PATH] as
    | {
        rows?: unknown;
        meta?: unknown;
        reportedTotal?: unknown;
        capturedAt?: unknown;
        pagination?: unknown;
        sessionId?: unknown;
      }
    | null
    | undefined;
  const hizmetRows = Array.isArray(hizmetRaw?.rows)
    ? (hizmetRaw?.rows as Record<string, unknown>[])
    : [];
  const personelRows = Array.isArray(personelRaw?.rows)
    ? (personelRaw?.rows as Record<string, unknown>[])
    : [];
  const dataset = {
    hizmet: summarizeCapture(KATIP_HIZMET_SOZLESMESI_PATH, {
      rows: hizmetRows,
      meta: (hizmetRaw?.meta as KatipCapturedPageMeta[]) ?? [],
      reportedTotal: (hizmetRaw?.reportedTotal as number | null) ?? null,
      capturedAt: (hizmetRaw?.capturedAt as number | null) ?? null,
    }),
    personel: summarizeCapture(KATIP_PERSONEL_SOZLESMESI_PATH, {
      rows: personelRows,
      meta: (personelRaw?.meta as KatipCapturedPageMeta[]) ?? [],
      reportedTotal: (personelRaw?.reportedTotal as number | null) ?? null,
      capturedAt: (personelRaw?.capturedAt as number | null) ?? null,
    }),
  };
  // FAZ 1 — KANONİK rapor: her dataset için state + pagination + overall (PII İÇERMEZ).
  const hizmetReport = buildDatasetReport(KATIP_HIZMET_SOZLESMESI_PATH, {
    rows: hizmetRows,
    meta: (hizmetRaw?.meta as KatipCapturedPageMeta[]) ?? [],
    reportedTotal: (hizmetRaw?.reportedTotal as number | null) ?? null,
    capturedAt: (hizmetRaw?.capturedAt as number | null) ?? null,
    pagination:
      (hizmetRaw?.pagination as { totalCount?: number | null; totalPages?: number | null } | null) ??
      null,
    sessionId: (hizmetRaw?.sessionId as number | null) ?? null,
  });
  const personelReport = buildDatasetReport(KATIP_PERSONEL_SOZLESMESI_PATH, {
    rows: personelRows,
    meta: (personelRaw?.meta as KatipCapturedPageMeta[]) ?? [],
    reportedTotal: (personelRaw?.reportedTotal as number | null) ?? null,
    capturedAt: (personelRaw?.capturedAt as number | null) ?? null,
    pagination:
      (personelRaw?.pagination as { totalCount?: number | null; totalPages?: number | null } | null) ??
      null,
    sessionId: (personelRaw?.sessionId as number | null) ?? null,
  });
  const report = {
    hizmet: hizmetReport,
    personel: personelReport,
    overall: resolveOverallDiscoveryStatus(hizmetReport, personelReport),
  };
  return {
    hizmetRows,
    personelRows,
    captured: hizmetRows.length > 0 || personelRows.length > 0,
    dataset,
    report,
  };
}

/** Aktif sekmeye DRY RUN sender enjekte eder (allFrames ile iframe desteği). */
export async function injectSpaSender(
  tabId: number,
  payload: unknown,
  allFrames: boolean,
): Promise<SpaSenderResult | undefined> {
  const results = await chrome.scripting.executeScript({
    target: allFrames ? { tabId, allFrames: true } : { tabId },
    world: 'MAIN',
    args: [payload],
    func: spaBridgeSender,
  });
  const list = (results ?? [])
    .map((r) => r.result as SpaSenderResult | undefined)
    .filter((r): r is SpaSenderResult => Boolean(r));
  return list.find((r) => r.status !== 'BRIDGE_NOT_READY') ?? list[0];
}

/** Aktif sekmeye pilot sender enjekte eder. */
export async function injectPilotSender(
  tabId: number,
  payload: unknown,
  allFrames: boolean,
): Promise<SpaPilotSenderResult | undefined> {
  const results = await chrome.scripting.executeScript({
    target: allFrames ? { tabId, allFrames: true } : { tabId },
    world: 'MAIN',
    args: [payload],
    func: spaPilotSender,
  });
  const list = (results ?? [])
    .map((r) => r.result as SpaPilotSenderResult | undefined)
    .filter((r): r is SpaPilotSenderResult => Boolean(r));
  return list.find((r) => r.status !== 'BRIDGE_NOT_READY') ?? list[0];
}

/** Bir sekmeye kalıcı İSGDenetim rölesi enjekte eder (idempotent). */
export async function ensureDenetimRelay(tabId: number): Promise<boolean> {
  try {
    await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      world: 'ISOLATED',
      func: denetimRelayInstaller,
    });
    return true;
  } catch {
    return false;
  }
}

/**
 * İSGDenetim sekmesine MAIN-world köprü sondasını enjekte eder: köprü listener'ını kurar ve
 * gerçek HELLO→HELLO_ACK el sıkışmasını doğrular. `true` yalnızca ACK gerçekten alınınca döner.
 */
export async function installAndProbeSpaBridge(tabId: number): Promise<boolean> {
  const run = async (allFrames: boolean): Promise<boolean> => {
    try {
      const results = await chrome.scripting.executeScript({
        target: allFrames ? { tabId, allFrames: true } : { tabId },
        world: 'MAIN',
        func: spaBridgeProbe,
      });
      return (results ?? []).some(
        (r) => (r.result as { ready?: boolean } | undefined)?.ready === true,
      );
    } catch {
      return false;
    }
  };
  if (await run(false)) return true;
  return run(true);
}

/**
 * AKTİF SEKMEDEN BAĞIMSIZ KÖPRÜ ARAMA (6J.2).
 * Açık TÜM sekmelerdeki kalıcı rölelere `chrome.tabs.sendMessage` ile ulaşmayı dener.
 */
export async function runViaRelay(
  kind: 'dryrun' | 'pilot' | 'apply' | 'backfill',
  payload: BridgePayload,
): Promise<{ tabId: number; res: BridgeChannelResult } | null> {
  const type =
    kind === 'apply'
      ? 'ISG_KATIP_RELAY_PILOT_APPLY'
      : kind === 'pilot'
        ? 'ISG_KATIP_RELAY_PILOT'
        : kind === 'backfill'
          ? 'ISG_KATIP_RELAY_BACKFILL'
          : 'ISG_KATIP_RELAY_DRYRUN';

  const isgTab = await resolveIsgDenetimTab();
  if (isgTab?.id) {
    const res = await sendRelayMessage(isgTab.id, { type, payload });
    if (res && typeof res.status === 'string' && res.status !== 'BRIDGE_NOT_READY') {
      return { tabId: isgTab.id, res };
    }
  }

  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (!t.id || !t.url || !/^https?:/i.test(t.url)) continue;
    if (isKatipUrl(t.url)) continue;
    if (t.id === isgTab?.id) continue;
    // eslint-disable-next-line no-await-in-loop
    const res = await sendRelayMessage(t.id, { type, payload });
    if (res && typeof res.status === 'string' && res.status !== 'BRIDGE_NOT_READY') {
      return { tabId: t.id, res };
    }
  }
  return null;
}

/** Açık tüm sekmelerdeki kalıcı röleye HAFİF ping atar; SPA köprüsü canlı mı? (yan etkisiz). */
export async function probeSpaRelay(): Promise<boolean> {
  const isgTab = await resolveIsgDenetimTab();
  if (isgTab?.id) {
    const res = await sendRelayMessage(isgTab.id, { type: 'ISG_KATIP_RELAY_PING' });
    if (res && res.status === 'BRIDGE_READY') return true;
  }
  const tabs = await chrome.tabs.query({});
  for (const t of tabs) {
    if (!t.id || !t.url || !/^https?:/i.test(t.url)) continue;
    if (isKatipUrl(t.url)) continue;
    if (t.id === isgTab?.id) continue;
    // eslint-disable-next-line no-await-in-loop
    const res = await sendRelayMessage(t.id, { type: 'ISG_KATIP_RELAY_PING' });
    if (res && res.status === 'BRIDGE_READY') return true;
  }
  return false;
}

/* -------------------------------------------------------------------------- */
/* FAZ-DOC — KATİP BELGE/PDF KEŞİF OKUYUCUSU (READ-ONLY)                        */
/*                                                                            */
/* KATİP sekmesinin MAIN-world belleğindeki belge gözlemlerini okur. YENİ KATİP */
/* HTTP isteği ATILMAZ; token/cookie/JWT taşınmaz. Yalnızca gözlemlenmiş metadata */
/* ve (varsa) bellek-içi gövde base64 olarak ALINIR; hiçbir yere YAZILMAZ.       */
/* -------------------------------------------------------------------------- */

/** Side Panel UI'ının tükettiği, PII'siz belge gözlem özeti. */
export interface CapturedDocMeta {
  id: number;
  source: string;
  method: string;
  /** Query'siz yol (gizli/oturum parametreleri taşınmaz). */
  path: string;
  hasQuery: boolean;
  contentType: string | null;
  status: number | null;
  size: number | null;
  capturedAt: number;
  bodyKind: string;
  fileName: string | null;
  hasBody: boolean;
  bodyTruncated: boolean;
  note: string | null;
}

/** MAIN world'de çalışan, KENDİ KENDİNE YETERLİ belge listesi okuyucusu (closure YOK). */
function readKatipDocs(): { ok: boolean; docs: unknown[]; error?: string } {
  const store = (window as unknown as {
    __ISG_KATIP_DOC_CAPTURED__?: Array<Record<string, unknown>>;
  }).__ISG_KATIP_DOC_CAPTURED__;
  if (!Array.isArray(store)) return { ok: true, docs: [] };
  const docs = store.map((d) => ({
    id: typeof d?.id === 'number' ? d.id : 0,
    source: typeof d?.source === 'string' ? d.source : 'unknown',
    method: typeof d?.method === 'string' ? d.method : 'GET',
    path: typeof d?.path === 'string' ? d.path : '',
    hasQuery: d?.hasQuery === true,
    contentType: typeof d?.contentType === 'string' ? d.contentType : null,
    status: typeof d?.status === 'number' ? d.status : null,
    size: typeof d?.size === 'number' ? d.size : null,
    capturedAt: typeof d?.capturedAt === 'number' ? d.capturedAt : 0,
    bodyKind: typeof d?.bodyKind === 'string' ? d.bodyKind : 'unknown',
    fileName: typeof d?.fileName === 'string' ? d.fileName : null,
    hasBody: typeof d?.bodyB64 === 'string' && d.bodyB64.length > 0,
    bodyTruncated: d?.bodyTruncated === true,
    note: typeof d?.note === 'string' ? d.note : null,
  }));
  return { ok: true, docs };
}

/** MAIN world'de çalışan, KENDİ KENDİNE YETERLİ belge gövdesi okuyucusu (closure YOK). */
function readKatipDocBody(id: number): {
  ok: boolean;
  base64: string | null;
  mime: string | null;
  fileName: string | null;
  error?: string;
} {
  const store = (window as unknown as {
    __ISG_KATIP_DOC_CAPTURED__?: Array<Record<string, unknown>>;
  }).__ISG_KATIP_DOC_CAPTURED__;
  if (!Array.isArray(store)) {
    return { ok: false, base64: null, mime: null, fileName: null, error: 'Belge yakalama belleği bulunamadı.' };
  }
  const doc = store.find((d) => d && d.id === id);
  if (!doc) {
    return { ok: false, base64: null, mime: null, fileName: null, error: 'Belge bulunamadı.' };
  }
  return {
    ok: true,
    base64: typeof doc.bodyB64 === 'string' ? doc.bodyB64 : null,
    mime: typeof doc.contentType === 'string' ? doc.contentType : null,
    fileName: typeof doc.fileName === 'string' ? doc.fileName : null,
  };
}

/** KATİP sekmesinden yakalanan belge gözlemlerinin listesini okur (READ-ONLY). */
export async function readCapturedDocs(): Promise<{
  ok: boolean;
  docs: CapturedDocMeta[];
  error?: string;
}> {
  const tabs = await chrome.tabs.query({ url: `https://${KATIP_HOST}/*` });
  const katipTab = tabs.find((t) => t.id != null);
  if (!katipTab?.id) {
    return { ok: false, docs: [], error: 'İSG-KATİP sekmesi bulunamadı.' };
  }
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: katipTab.id },
      world: 'MAIN',
      func: readKatipDocs,
    });
    const r = results?.[0]?.result as { ok?: boolean; docs?: unknown[]; error?: string } | undefined;
    if (!r?.ok) {
      return { ok: false, docs: [], error: r?.error ?? 'Belge listesi okunamadı.' };
    }
    return { ok: true, docs: (r.docs as CapturedDocMeta[]) ?? [] };
  } catch (e) {
    return {
      ok: false,
      docs: [],
      error: e instanceof Error ? e.message : 'Belge listesi okunamadı.',
    };
  }
}

/** Yakalanan bir belgenin gövdesini (base64) KATİP sekmesi belleğinden okur (READ-ONLY). */
export async function readDocBody(id: number): Promise<{
  ok: boolean;
  base64: string | null;
  mime: string | null;
  fileName: string | null;
  error?: string;
}> {
  const tabs = await chrome.tabs.query({ url: `https://${KATIP_HOST}/*` });
  const katipTab = tabs.find((t) => t.id != null);
  if (!katipTab?.id) {
    return { ok: false, base64: null, mime: null, fileName: null, error: 'İSG-KATİP sekmesi bulunamadı.' };
  }
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: katipTab.id },
      world: 'MAIN',
      args: [id],
      func: readKatipDocBody,
    });
    const r = results?.[0]?.result as
      | { ok?: boolean; base64?: string | null; mime?: string | null; fileName?: string | null; error?: string }
      | undefined;
    if (!r?.ok) {
      return { ok: false, base64: null, mime: null, fileName: null, error: r?.error ?? 'Belge okunamadı.' };
    }
    return { ok: true, base64: r.base64 ?? null, mime: r.mime ?? null, fileName: r.fileName ?? null };
  } catch (e) {
    return {
      ok: false,
      base64: null,
      mime: null,
      fileName: null,
      error: e instanceof Error ? e.message : 'Belge okunamadı.',
    };
  }
}