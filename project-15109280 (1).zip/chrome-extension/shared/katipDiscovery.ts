/**
 * FAZ 6L — Discovery + Dry Run katmanı (popup ve Side Panel ortak).
 *
 * Davranış FAZ 6K/6J.2 ile BİREBİR aynıdır; yalnızca popup.ts'ten TAŞINMIŞTIR.
 * READ-ONLY'dir: DB'ye veri yazmaz, feature flag açmaz.
 * 🔒 token/cookie/JWT OKUMAZ/göstermez; ikinci KATİP isteği ATMAZ.
 */
import { el, setIndicator, setText } from './domUtils';
import type { ExtensionMessage } from './messages';
import { getConnState, connectToIsgDenetim, setSpaStatusExternal } from './katipConnection';
import {
  ensureContentScript,
  ensureDenetimRelay,
  getActiveTab,
  injectSpaSender,
  isKatipUrl,
  readCapturedRows,
  runViaRelay,
  sendToTab,
  type BridgePayload,
} from './katipBridge';

/* -------------------------------------------------------------------------- */
/* Gevşek (loose) tipler — popup.ts'ten birebir taşındı (UI için).             */
/* -------------------------------------------------------------------------- */

export interface LooseDiagnostic {
  endpoint?: string;
  label?: string;
  ok?: boolean;
  errorCode?: string;
  errorMessage?: string;
  rowCount?: number;
}

export interface LooseReport {
  hizmetRowCount?: number;
  personelRowCount?: number;
  roles?: Array<{ id: string | number | null; label: string | null; mappingStatus: string }>;
  warnings?: string[];
  diagnostics?: LooseDiagnostic[];
}

export interface LooseDryRunCounts {
  matched: number;
  new: number;
  conflict: number;
  unresolved: number;
  skipped: number;
}

export interface LooseEmployeeCountRow {
  katipCount: number | null;
  centralCount: number | null;
  diff: number | null;
}

export interface LooseDryRunScope {
  scoped?: boolean;
  source?: string | null;
  firmExternalIdMasked?: string | null;
  firmTitle?: string | null;
  outOfScopeFirms?: number;
  outOfScopeAssignments?: number;
}

export interface LooseDryRun {
  status?: string;
  note?: string;
  firms?: LooseDryRunCounts;
  persons?: LooseDryRunCounts;
  assignments?: LooseDryRunCounts;
  employeeCount?: { rows?: LooseEmployeeCountRow[]; diffCount?: number };
  warnings?: string[];
  dbWrites?: number;
  /** FAZ A/B — pilot kapsam bilgisi (tek firma). */
  scope?: LooseDryRunScope;
}

/* -------------------------------------------------------------------------- */
/* Render yardımcıları                                                         */
/* -------------------------------------------------------------------------- */

/** MATCH / NEW / CONFLICT / UNRESOLVED / SKIPPED sayaçlarını kısa dizgeye çevirir. */
export function formatCounts(c: LooseDryRunCounts | undefined): string {
  if (!c) return '—';
  return `${c.matched}/${c.new}/${c.conflict}/${c.unresolved}/${c.skipped}`;
}

export function renderReport(report: LooseReport | undefined): void {
  const roles = report?.roles ?? [];
  const verified = roles.filter((r) => r.mappingStatus === 'VERIFIED').length;
  const unresolved = roles.filter((r) => r.mappingStatus !== 'VERIFIED').length;

  setText('d-hizmet', report ? `${report.hizmetRowCount ?? 0} kayıt` : 'Bulunamadı');
  setText('d-personel', report ? `${report.personelRowCount ?? 0} kayıt` : 'Bulunamadı');
  setText('d-verified', String(verified));
  setText('d-unresolved', `${unresolved}/${roles.length}`);

  const host = el('roles');
  if (host) {
    host.innerHTML = '';
    for (const r of roles) {
      const row = document.createElement('div');
      row.className = 'role';
      const label = document.createElement('span');
      label.textContent = r.label ?? (r.id != null ? `ID ${r.id}` : 'Bilinmeyen');
      const badge = document.createElement('span');
      const isVerified = r.mappingStatus === 'VERIFIED';
      badge.className = `badge ${isVerified ? 'verified' : 'unresolved'}`;
      badge.textContent = isVerified ? 'DOĞRULANDI' : 'BEKLİYOR';
      row.appendChild(label);
      row.appendChild(badge);
      host.appendChild(row);
    }
  }

  renderDiagnostics(report?.diagnostics);
}

/**
 * FAZ 6K — endpoint-bazlı, PII-İÇERMEYEN teşhisi gösterir.
 * Yalnızca durum/hata kodu + şekil özeti gösterilir; TC / ad-soyad / cookie / token GÖSTERİLMEZ.
 */
export function renderDiagnostics(list: LooseDiagnostic[] | undefined): void {
  const host = el('diagnostics');
  if (!host) return;
  host.innerHTML = '';
  const items = list ?? [];
  if (items.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'diag-msg';
    empty.textContent = 'Henüz çalıştırılmadı.';
    host.appendChild(empty);
    return;
  }
  for (const d of items) {
    const row = document.createElement('div');
    row.className = 'diag';

    const head = document.createElement('div');
    head.className = 'diag-head';

    const name = document.createElement('span');
    name.textContent = d.label === 'personel' ? 'Personel Sözleşmeleri' : 'Hizmet Sözleşmeleri';

    const badge = document.createElement('span');
    badge.className = `badge ${d.ok ? 'verified' : 'unresolved'}`;
    badge.textContent = d.ok ? `OK · ${d.rowCount ?? 0}` : d.errorCode ?? 'HATA';

    head.appendChild(name);
    head.appendChild(badge);
    row.appendChild(head);

    if (!d.ok && d.errorMessage) {
      const msg = document.createElement('p');
      msg.className = 'diag-msg';
      msg.textContent = d.errorMessage;
      row.appendChild(msg);
    }

    host.appendChild(row);
  }
}

export function renderDryRun(result: LooseDryRun | undefined): void {
  if (!result) {
    setText('dryrun-note', 'Dry Run sonucu alınamadı.');
    return;
  }
  if (result.status === 'DRY_RUN_NOT_READY' || result.status === 'LOCAL_SNAPSHOT_NOT_READY') {
    setText('dr-firma', '—');
    setText('dr-personel', '—');
    setText('dr-atama', '—');
    setText('dr-count', '—');
    setText('dr-write', '0');
    setText('dryrun-note', result.note ?? 'Gerçek KATİP verisi bekleniyor (DRY_RUN_NOT_READY).');
    return;
  }
  setText('dr-firma', formatCounts(result.firms));
  setText('dr-personel', formatCounts(result.persons));
  setText('dr-atama', formatCounts(result.assignments));

  const rows = result.employeeCount?.rows ?? [];
  const katipSum = rows.reduce((acc, r) => acc + (typeof r.katipCount === 'number' ? r.katipCount : 0), 0);
  const centralSum = rows.reduce((acc, r) => acc + (typeof r.centralCount === 'number' ? r.centralCount : 0), 0);
  const diffCount = result.employeeCount?.diffCount ?? 0;
  setText('dr-count', `${katipSum} / ${centralSum} / ${diffCount} fark`);
  setText('dr-write', String(result.dbWrites ?? 0));

  const warnings = (result.warnings ?? []).join(' ');
  setText('dryrun-note', warnings || (result.note ?? 'DRY_RUN — UYGULANMADI. Hiçbir veri yazılmadı.'));
}

/* -------------------------------------------------------------------------- */
/* KATİP durum + Discovery                                                     */
/* -------------------------------------------------------------------------- */

/**
 * FAZ 6J.1 — KATİP READY/captured state AKTİF SEKMEDEN BAĞIMSIZDIR.
 * Önce runtime belleğindeki GERÇEK yakalanmış KATİP state kontrol edilir.
 */
export async function refreshKatipStatus(): Promise<void> {
  const captured = await readCapturedRows().catch(() => null);
  if (captured?.captured) {
    setIndicator('conn-dot', 'conn-text', 'ok', 'KATİP Bağlantısı: Hazır');
    setText('note', 'Bu panel yalnızca okur; DB\'ye veri yazmaz, feature flag açmaz.');
    return;
  }

  const tab = await getActiveTab();
  if (!tab?.id || !isKatipUrl(tab.url)) {
    setIndicator('conn-dot', 'conn-text', 'idle', 'KATİP Bağlantısı: KATİP sayfası bekleniyor');
    setText('note', 'İSG-KATİP sekmesi açın ve oturum açın.');
    return;
  }
  const ensure = await ensureContentScript(tab.id);
  if (!ensure.ok) {
    setIndicator('conn-dot', 'conn-text', 'warn', 'KATİP Bağlantısı: Oturum bekleniyor');
    setText('note', `İçerik betiği bu sekmeye bağlanamadı: ${ensure.error ?? 'bilinmiyor'}`);
    return;
  }
  const { res } = await sendToTab<ExtensionMessage & { ready?: boolean }>(tab.id, {
    type: 'ISG_KATIP_STATUS_REQUEST',
  });
  if (res && res.type === 'ISG_KATIP_STATUS_RESULT' && res.ready) {
    setIndicator('conn-dot', 'conn-text', 'ok', 'KATİP Bağlantısı: Hazır');
    setText('note', 'Bu panel yalnızca okur; DB\'ye veri yazmaz, feature flag açmaz.');
  } else {
    setIndicator('conn-dot', 'conn-text', 'warn', 'KATİP Bağlantısı: Oturum bekleniyor');
    setText('note', 'Sayfa hazır ancak içerik betiği yanıt vermedi. Sayfayı yenileyin.');
  }
}

export async function runDiscovery(): Promise<void> {
  const button = el<HTMLButtonElement>('refresh');
  const tab = await getActiveTab();
  if (!tab?.id || !isKatipUrl(tab.url)) {
    setIndicator('conn-dot', 'conn-text', 'idle', 'KATİP Bağlantısı: KATİP sayfası bekleniyor');
    setText('note', 'Discovery için İSG-KATİP sekmesi gerekir.');
    return;
  }
  if (button) button.disabled = true;
  setText('note', 'Discovery çalışıyor (READ-ONLY)…');
  try {
    const ensure = await ensureContentScript(tab.id);
    if (!ensure.ok) {
      setIndicator('conn-dot', 'conn-text', 'warn', 'KATİP Bağlantısı: Oturum bekleniyor');
      setText('note', `Discovery başarısız: ${ensure.error ?? 'içerik betiği bağlanamadı.'}`);
      return;
    }

    const { res, lastError } = await sendToTab<ExtensionMessage>(tab.id, {
      type: 'ISG_KATIP_DISCOVERY_REQUEST',
    });
    if (res && res.type === 'ISG_KATIP_DISCOVERY_RESULT' && res.ok) {
      renderReport(res.report as LooseReport);
      const warnings = ((res.report as LooseReport)?.warnings ?? []).join(' ');
      // FAZ 1 — KANONİK GENEL VERİ DURUMU: hizmet ve personel datasetleri ayrı ayrı
      // tamamlanmadan genel discovery "TAMAMLANDI" sayılmaz (overall READY değildir).
      const captured = await readCapturedRows().catch(() => null);
      const overall = captured?.report?.overall;
      const overallText =
        overall === 'DATA_COMPLETE'
          ? 'VERİ TAMAMLANDI'
          : overall === 'DATA_INCOMPLETE'
            ? 'VERİ TOPLANIYOR (tüm sayfalar henüz alınmadı)'
            : overall === 'ERROR'
              ? 'VERİ TOPLAMA HATASI'
              : 'VERİ BEKLENİYOR';
      setText(
        'note',
        `${overallText}. ${warnings || 'Discovery tamamlandı (READ-ONLY). Hiçbir veri yazılmadı.'}`,
      );
    } else if (res && res.type === 'ISG_KATIP_DISCOVERY_RESULT' && !res.ok) {
      setText('note', `Discovery başarısız: ${res.error}`);
    } else if (lastError) {
      setText(
        'note',
        `Discovery başarısız: içerik betiği bu sekmeye bağlı değil (${lastError}). İSG-KATİP sekmesini yenileyin (F5) ve tekrar deneyin.`,
      );
    } else {
      setText(
        'note',
        'Discovery başarısız: içerik betiği yanıt vermedi. İSG-KATİP sekmesini yenileyin (F5) ve tekrar deneyin.',
      );
    }
  } finally {
    if (button) button.disabled = false;
  }
}

/* -------------------------------------------------------------------------- */
/* TEK KANONİK DRY RUN AKIŞI (SPA köprüsü)                                     */
/* -------------------------------------------------------------------------- */

/**
 * FAZ 6I.1B.2 — TEK KANONİK DRY RUN AKIŞI (SPA köprüsü).
 *  - gerçek KATİP satırlarını okur (6K interception belleği, READ-ONLY),
 *  - kalıcı röle / aktif sekme üzerinden SPA'daki mevcut runIsgDenetimDryRun() sonucunu alır.
 * 🔒 token/cookie taşınmaz; kalıcı saklama YOK; DB'ye yazma YOK.
 */
export async function runCanonicalDryRun(
  triggerId: string,
  override?: { hizmetRows: Record<string, unknown>[]; personelRows: Record<string, unknown>[] },
): Promise<void> {
  const button = el<HTMLButtonElement>(triggerId);
  if (button) button.disabled = true;
  setSpaStatusExternal('warn', 'Bağlantı kuruluyor…');
  setText('spa-note', 'İSG-KATİP verileri okunuyor…');
  setText('dryrun-note', 'Salt-okuma kontrol çalışıyor…');
  try {
    if (getConnState() !== 'READY') {
      await connectToIsgDenetim();
    }
    const rows = override
      ? { hizmetRows: override.hizmetRows, personelRows: override.personelRows, captured: true }
      : await readCapturedRows();
    if (!rows.captured) {
      setSpaStatusExternal('warn', 'Bağlantı bekleniyor');
      setText('spa-note', rows.error ?? 'Gerçek İSG-KATİP verisi henüz yakalanmadı.');
      setText('dryrun-note', 'Gerçek İSG-KATİP verisi henüz yakalanmadı. İSG-KATİP listesini açıp/yenileyin.');
      return;
    }

    const payload: BridgePayload = {
      hizmetRows: rows.hizmetRows,
      personelRows: rows.personelRows,
      capturedAt: new Date().toISOString(),
    };

    let res = (await runViaRelay('dryrun', payload))?.res;
    if (!res) {
      const tab = await getActiveTab();
      if (!tab?.id) {
        setSpaStatusExternal('warn', 'Bağlantı bekleniyor');
        setText('spa-note', 'Aktif sekme bulunamadı.');
        setText('dryrun-note', 'Aktif sekme bulunamadı.');
        return;
      }
      try {
        res = await injectSpaSender(tab.id, payload, false);
        if (!res || res.status === 'BRIDGE_NOT_READY') {
          const scoped = await injectSpaSender(tab.id, payload, true).catch(() => undefined);
          if (scoped && scoped.status !== 'BRIDGE_NOT_READY') res = scoped;
        }
        if (res && res.status !== 'BRIDGE_NOT_READY') {
          await ensureDenetimRelay(tab.id);
        }
      } catch (e) {
        setSpaStatusExternal('warn', 'Bağlantı bekleniyor');
        setText(
          'spa-note',
          `Aktif sekmede İSGDenetim bağlantısı kurulamadı: ${e instanceof Error ? e.message : 'bilinmiyor'}`,
        );
        setText('dryrun-note', 'Aktif sekmede İSGDenetim bağlantısı kurulamadı.');
        return;
      }
    }

    if (!res || res.status === 'BRIDGE_NOT_READY') {
      setSpaStatusExternal('warn', 'Bağlantı bekleniyor');
      setText(
        'spa-note',
        res?.error ??
          "İSGDenetim sekmesi bulunamadı. 'İSGDenetim'i Aç' ile uygulamayı açın.",
      );
      setText('dryrun-note', 'İSGDenetim sekmesi bulunamadı.');
      return;
    }

    renderDryRun(res.result as LooseDryRun | undefined);
    if (res.ok) {
      setSpaStatusExternal('ok', 'Bağlantı hazır');
      setText('spa-note', 'Bağlantı hazır. İşyeri aktarımına başlayabilirsiniz.');
    } else {
      setSpaStatusExternal('warn', 'Bağlantı hazır');
      setText('spa-note', `İSGDenetim bağlantısı kuruldu; kontrol durumu: ${res.status}.`);
    }
  } finally {
    if (button) button.disabled = false;
  }
}