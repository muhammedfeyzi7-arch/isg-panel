/**
 * FAZ-DOC — Side Panel "Sözleşme / Belge Yakalama" yüzeyi (READ-ONLY KEŞİF).
 *
 * KATİP SPA'nın İNDİRDİĞİ/GÖSTERDİĞİ belge (PDF vb.) yanıtlarını listeler ve yakalanan
 * içeriği KULLANICIYA indirtir. Hiçbir veri sunucuya gönderilmez; hiçbir şey KATİP'e yazılmaz.
 * İçerik yalnızca KATİP sekmesinin MAIN-world belleğinden okunur ve tarayıcı indirmesine dönüşür.
 */
import { el, setText } from './domUtils';
import { readCapturedDocs, readDocBody, type CapturedDocMeta } from './katipBridge';

function fmtSize(bytes: number | null): string {
  if (bytes == null) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function kindLabel(kind: string): string {
  if (kind === 'pdf') return 'PDF';
  if (kind === 'image') return 'Görsel';
  if (kind === 'binary') return 'Dosya';
  if (kind === 'text') return 'Metin';
  return 'Bilinmiyor';
}

function sourceLabel(source: string): string {
  if (source === 'xhr') return 'XHR';
  if (source === 'fetch') return 'fetch';
  if (source === 'navigation') return 'indirme adresi';
  return source;
}

function b64ToBytes(b64: string): Uint8Array {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

function guessFileName(meta: CapturedDocMeta): string {
  if (meta.fileName) return meta.fileName;
  const base = meta.path.split('/').filter(Boolean).pop() || 'katip-belge';
  const ext = meta.bodyKind === 'pdf' ? 'pdf' : 'bin';
  return `${base}.${ext}`;
}

/** Yakalanan belgeyi tarayıcı indirmesine dönüştürür (sunucuya gönderim YOK). */
async function saveDoc(meta: CapturedDocMeta, button: HTMLButtonElement): Promise<void> {
  const original = button.textContent;
  button.disabled = true;
  button.textContent = 'Hazırlanıyor…';
  try {
    const res = await readDocBody(meta.id);
    if (!res.ok || !res.base64) {
      setText('doc-note', res.error ?? 'Belge içeriği okunamadı.');
      return;
    }
    const bytes = b64ToBytes(res.base64);
    const blob = new Blob([bytes], { type: res.mime || 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const name = res.fileName || guessFileName(meta);
    a.href = url;
    a.download = name;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    a.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 20000);
    setText('doc-note', `Belge indirildi: ${name}`);
  } catch (e) {
    setText('doc-note', e instanceof Error ? e.message : 'Belge indirilemedi.');
  } finally {
    button.disabled = false;
    button.textContent = original;
  }
}

function renderDocItem(meta: CapturedDocMeta): HTMLElement {
  const item = document.createElement('div');
  item.className = 'doc-item';

  const top = document.createElement('div');
  top.className = 'doc-item-top';
  const path = document.createElement('span');
  path.className = 'doc-path';
  path.textContent = meta.path || '—';
  const tag = document.createElement('span');
  tag.className = 'k-tag k-tag-green';
  tag.textContent = kindLabel(meta.bodyKind);
  top.appendChild(path);
  top.appendChild(tag);
  item.appendChild(top);

  const metaLine = document.createElement('p');
  metaLine.className = 'doc-meta';
  const bits: string[] = [sourceLabel(meta.source), meta.method];
  if (meta.status != null) bits.push(`HTTP ${meta.status}`);
  if (meta.contentType) bits.push(meta.contentType);
  bits.push(fmtSize(meta.size));
  metaLine.textContent = bits.join(' · ');
  item.appendChild(metaLine);

  if (meta.note) {
    const note = document.createElement('p');
    note.className = 'doc-meta';
    note.textContent = meta.note;
    item.appendChild(note);
  }

  const actions = document.createElement('div');
  actions.className = 'doc-actions';
  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'k-btn k-btn-sm';
  btn.textContent = meta.bodyKind === 'pdf' ? 'PDF İndir' : 'Belgeyi İndir';
  btn.addEventListener('click', () => void saveDoc(meta, btn));
  actions.appendChild(btn);
  item.appendChild(actions);

  return item;
}

/** Yakalanan belgeleri Side Panel'e çizer (READ-ONLY). */
export async function renderCapturedDocs(): Promise<void> {
  const host = el('doc-list');
  if (!host) return;
  host.innerHTML = '';
  setText('doc-note', 'Belgeler yükleniyor…');
  const res = await readCapturedDocs();
  if (!res.ok) {
    setText('doc-note', res.error ?? 'Belge listesi okunamadı.');
    return;
  }
  // Yalnızca İÇERİĞİ gerçekten yakalanan belgeler gösterilir. Adres-only gözlemler
  // ("Bilinmiyor" / yalnızca konum kaydı) ürün arayüzünde GÖSTERİLMEZ; bunlar araç
  // davranışının gürültüsüdür ve kullanıcıya yanlış izlenim verir.
  const docs = res.docs.filter((d) => d.hasBody);
  if (docs.length === 0) {
    const empty = document.createElement('p');
    empty.className = 'doc-empty';
    empty.textContent =
      "İçeriği yakalanan belge yok. Belge İSG-KATİP içinde (görüntüleyici/pencere içi) açıldığında otomatik yakalanır; doğrudan indirilen veya yeni sekmede açılan PDF'ler tarayıcı güvenliği gereği yakalanamaz.";
    host.appendChild(empty);
    setText('doc-note', '');
    return;
  }
  // En yeni belge en üstte.
  const sorted = docs.slice().sort((a, b) => b.capturedAt - a.capturedAt);
  for (const d of sorted) host.appendChild(renderDocItem(d));
  setText('doc-note', `${sorted.length} belge yakalandı.`);
}

/** Belge yakalama paneli etkileşimlerini bağlar (idempotent: bir kez çağrılmalı). */
export function initDocCapture(): void {
  el('doc-refresh')?.addEventListener('click', () => void renderCapturedDocs());
}