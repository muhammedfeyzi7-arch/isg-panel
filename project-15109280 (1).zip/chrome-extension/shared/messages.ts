/**
 * Extension ↔ İSGDenetim backend + iç mesaj sözleşmesi (FAZ 6B).
 *
 * Bu sözleşme, `src/lib/isgKatip/types.ts` içindeki `IsgKatipSyncPayload` ile
 * BİREBİR uyumlu tutulmalıdır (tek doğruluk kaynağı orasıdır).
 *
 * Güvenlik: Burada yalnızca NORMALİZE veri taşınır. İSG-KATİP session cookie,
 * e-Devlet kimlik bilgisi veya KATİP token'ı HİÇBİR mesajda bulunmaz.
 */

export const ISG_KATIP_SOURCE = 'ISG_KATIP' as const;

/** İSGDenetim sync endpoint yolu (Supabase functions base URL'e eklenir). */
export const ISGDENETIM_SYNC_FUNCTION = 'isg-katip-sync';

/** Content script ↔ service worker iç mesajları. */
export type ExtensionMessage =
  | { type: 'ISG_KATIP_COLLECT_REQUEST' }
  | { type: 'ISG_KATIP_COLLECT_RESULT'; ok: true; payload: unknown }
  | { type: 'ISG_KATIP_COLLECT_RESULT'; ok: false; error: string }
  // FAZ 6K — popup ↔ content script: bağlantı durumu (READ-ONLY, veri çekmez).
  | { type: 'ISG_KATIP_STATUS_REQUEST' }
  | { type: 'ISG_KATIP_STATUS_RESULT'; isKatip: boolean; ready: boolean }
  // FAZ 6K — popup ↔ content script: READ-ONLY discovery raporu (PII içermez).
  | { type: 'ISG_KATIP_DISCOVERY_REQUEST' }
  | { type: 'ISG_KATIP_DISCOVERY_RESULT'; ok: true; report: unknown }
  | { type: 'ISG_KATIP_DISCOVERY_RESULT'; ok: false; error: string }
  // FAZ 6I — popup ↔ content script: GERÇEK KATİP verisiyle READ-ONLY DRY RUN (yazma YOK).
  | { type: 'ISG_KATIP_DRYRUN_REQUEST' }
  | { type: 'ISG_KATIP_DRYRUN_RESULT'; ok: true; result: unknown }
  | { type: 'ISG_KATIP_DRYRUN_RESULT'; ok: false; error: string };

/**
 * Content script → service worker: MAIN world'de KATİP SPA'nın KENDİ gerçek isteğinden
 * yakalanan response'u OKU. `path` doğrulanmış endpoint yoludur.
 * NOT: Bu mesaj artık bir FETCH TETİKLEMEZ; yalnızca gözlemlenen response'u okur.
 */
export interface KatipCapturedRequestMessage {
  type: 'ISG_KATIP_CAPTURED_REQUEST';
  path: string;
}

/**
 * Service worker → content script: yakalanan GERÇEK KATİP response'u.
 * YALNIZCA discovery için gerekli veri (status + HAM JSON) taşınır.
 * Token / Authorization / cookie DEĞERİ bu sözleşmede YOKTUR; asla gönderilmez.
 */
export interface KatipCapturedResponseMessage {
  ok: boolean;
  /** İlgili endpoint'in response'u yakalandı mı? (false → henüz bekleniyor.) */
  captured: boolean;
  status?: number;
  code?: string;
  message?: string;
  json?: unknown;
}

/**
 * Extension ayarları (chrome.storage.local).
 * authToken = kullanıcının KENDİ İSGDenetim JWT'si (KATİP oturum token'ı DEĞİL).
 */
export interface ExtensionSyncConfig {
  supabaseUrl: string;
  supabaseAnonKey: string;
  authToken: string;
  osgbId: string;
}