/**
 * FAZ 6L — PİLOT WORKFLOW (Side Panel çalışma alanı; popup.ts'ten TAŞINDI).
 *
 * Davranış FAZ 6J.3 ile BİREBİR aynıdır. Tek ek: workflow state'i `chrome.storage.session`
 * ile PERSIST edilir → Side Panel sekme değişiminde / sayfa refresh'inde kaldığı yerden devam eder.
 *
 * ⛔ DEĞİŞMEYENLER: mevcut pilot resolver, matching, APPLY kanalı, write core, isg-katip-sync,
 * isg_katip_apply_pilot RPC, bridge protokolü. Yeni write motoru/matching motoru YOK.
 * 🔒 token/cookie/JWT TAŞINMAZ; WRITE yalnızca EXPLICIT kullanıcı onayıyla çalışır.
 */
import { el, setText, showEl } from './domUtils';
import {
  ensureDenetimRelay,
  getActiveTab,
  injectPilotSender,
  injectSpaSender,
  readCapturedRows,
  runViaRelay,
  type BridgeChannelResult,
  type BridgePayload,
} from './katipBridge';
import { connectToIsgDenetim, getConnState, onConnStateChange } from './katipConnection';
import { formatCounts, type LooseDryRun } from './katipDiscovery';
import {
  loadSessionState,
  saveSessionState,
  type KatipSyncSessionState,
  type PersistedPilotSelection,
} from './katipSession';
import {
  assembleManualPilotResult,
  filterHizmetRowsByWorksite,
  listKatipPilotFirmCandidates,
  type KatipManualPilotPreview,
  type KatipPilotAssignmentPreview,
  type KatipPilotFirmCandidate,
  type KatipPilotPersonPreview,
  type KatipPilotWritePlan,
} from '../../src/lib/isgKatip/pilot';
import { summarizeKatipContractActivity } from '../../src/lib/isgKatip/contractActivity';
import {
  firmMatchLabel,
  fmtCount,
  pilotAssignmentLabel,
  pilotFirmLabel,
  pilotPersonnelLabel,
  pilotStatusLabel,
  personStatusLabel,
  personTagClass,
  trSearchKey,
  type LooseApply,
  type LoosePilot,
} from './katipPilotTypes';

/* -------------------------------------------------------------------------- */
/* Runtime state (popup.ts'ten taşındı; seçim KALICIDIR — render ile sıfırlanmaz) */
/* -------------------------------------------------------------------------- */

let manualPilotSelection: PersistedPilotSelection | null = null;
let manualCandidates: KatipPilotFirmCandidate[] = [];
let manualPreview: KatipManualPilotPreview | null = null;
let selectedIsgFirmId: string | null = null;
/** Son çözümlenen pilot sonucu (AUTO veya MANUAL); persistence için tutulur. */
let currentPilotResult: LoosePilot | null = null;
/** Son apply sonucu; persistence için tutulur. */
let currentApplyResult: LooseApply | null = null;
let lastCorrelationId: string | null = null;

/** FAZ 6J.3 — Pilot Dry Run BAĞIMSIZ operation state (connection state'ten TAMAMEN AYRI). */
export type PilotDryRunState = 'IDLE' | 'RUNNING' | 'SUCCESS' | 'ERROR';
let pilotDryRunState: PilotDryRunState = 'IDLE';
let pilotDryRunResult: LooseDryRun | null = null;
let pilotDryRunError: { stage: string; code: string; message: string } | null = null;
/** Aynı anda TEK dry run/apply çalışır (double-click & concurrency kilidi). */
let pilotDryRunInFlight = false;
let pilotApplyInFlight = false;

/** Pilot Dry Run operation state'ini sıfırlar (yeni firma seçimi / plan değişikliği). */
function resetPilotDryRun(): void {
  pilotDryRunState = 'IDLE';
  pilotDryRunResult = null;
  pilotDryRunError = null;
  renderPilotDryRunPanel();
}

/* -------------------------------------------------------------------------- */
/* Persistence                                                                 */
/* -------------------------------------------------------------------------- */

/** Güvenli workflow state'ini (session secret/PII YOK) persist eder. Best-effort. */
function persistPilotState(): void {
  const state: Partial<KatipSyncSessionState> = {
    selectedKatipPilotFirm: manualPilotSelection,
    selectedIsgDenetimFirm: selectedIsgFirmId,
    pilotSource: manualPilotSelection ? 'MANUAL' : currentPilotResult ? 'AUTO' : null,
    pilotResult: currentPilotResult,
    manualPreview,
    pilotApplyResult: currentApplyResult,
    pilotVerifyResult: currentApplyResult?.verify ?? null,
    lastPilotCorrelationId: lastCorrelationId,
    pilotDryRunState: pilotDryRunState === 'IDLE' ? null : pilotDryRunState,
    pilotDryRunResult,
    pilotDryRunError,
    workflowStep: deriveWorkflowStep(),
  };
  void saveSessionState(state);
  // Stepper'ı her state değişiminde gerçek adımdan türet.
  renderStepper();
}

/** Kaba workflow adımı (UI geri yükleme/teşhis için). */
function deriveWorkflowStep(): string {
  if (currentApplyResult) return currentApplyResult.verify?.pass ? 'APPLIED_VERIFIED' : 'APPLIED';
  if (manualPilotSelection && selectedIsgFirmId && manualPreview) return 'WRITE_PLAN_READY';
  if (manualPilotSelection) return 'MANUAL_FIRM_SELECTED';
  if (currentPilotResult) return 'AUTO_RESOLVED';
  return 'IDLE';
}

/**
 * Ürün stepper'ı: 1 İşyeri Seç → 2 Kontrol Et → 3 Onayla → 4 Tamamla.
 * Adım numarası GERÇEK runtime state'inden türetilir (sahte ilerleme YOK).
 */
function currentStepNumber(): number {
  if (currentApplyResult) return 4;
  if (pilotDryRunState === 'SUCCESS') return 3;
  if ((manualPilotSelection && manualPreview) || currentPilotResult) return 2;
  return 1;
}

/** Stepper'ı mevcut adıma göre (done/active) tazeler. */
function renderStepper(): void {
  const step = currentStepNumber();
  for (let i = 1; i <= 4; i += 1) {
    const node = el(`katip-step-${i}`);
    if (!node) continue;
    node.classList.remove('active', 'done');
    if (i < step) node.classList.add('done');
    else if (i === step) node.classList.add('active');
  }
}

/** FAZ A/B — çözülen pilot kapsamı (tek firma). Hiçbir zaman global dataset değildir. */
interface PilotScope {
  externalId: string;
  title: string | null;
  source: 'AUTO' | 'MANUAL';
  osgbIdHint: string | null;
}

/**
 * FAZ A/B — Aktif pilot kapsamını çözer: MANUEL seçim öncelikli; yoksa OTOMATİK çözümlenen
 * tek pilot firma. Kapsam çözülemezse `null` döner → Dry Run/Apply ÇALIŞMAZ (global değil).
 */
function resolvePilotScope(): PilotScope | null {
  if (manualPilotSelection) {
    const option =
      selectedIsgFirmId && manualPreview
        ? manualPreview.isgFirmOptions.find((o) => o.id === selectedIsgFirmId) ?? null
        : null;
    return {
      externalId: manualPilotSelection.worksiteId,
      title: manualPilotSelection.title,
      source: 'MANUAL',
      osgbIdHint: option?.osgbId ?? null,
    };
  }
  const ext = currentPilotResult?.katipWorksiteId ?? null;
  if (ext) {
    return {
      externalId: ext,
      title: currentPilotResult?.firmTitle ?? null,
      source: 'AUTO',
      osgbIdHint: null,
    };
  }
  return null;
}

/* -------------------------------------------------------------------------- */
/* Render                                                                      */
/* -------------------------------------------------------------------------- */

function setPilotSubStatus(text: string): void {
  const node = el('pilot-substatus');
  if (!node) return;
  node.textContent = text;
  if (text) node.classList.remove('hidden');
  else node.classList.add('hidden');
}

/** Pilot sonucunu (veya durumunu) UI'a yansıtır. Hiçbir zaman fake "AKTİF" gösterilmez. */
function renderPilot(pilot: LoosePilot | undefined): void {
  const status = pilot?.status;
  const ready = status === 'PILOT_CANDIDATE_READY';
  const manual = manualPilotSelection != null;

  setText(
    'pilot-status',
    ready
      ? 'İşyeri aktarıma hazır'
      : status === 'PILOT_DATA_INCOMPLETE'
        ? "İşyeri listesi hazırlanıyor — 'İşyeri Aktar'a tekrar dokunun"
        : status === 'PILOT_AMBIGUOUS'
          ? 'İşyeri doğrulaması çakışıyor'
          : status === 'PILOT_OUT_OF_SCOPE'
            ? 'İşyeri kapsam dışı'
            : status === 'NO_SAFE_PILOT_CANDIDATE'
              ? 'Aktarılabilir işyeri bulunamadı'
              : 'İşyeri listesi bekleniyor',
  );

  showEl('pilot-badge', ready);
  showEl('pilot-detail', ready || manual);
  // FAZ 6J.3 — Pilot Dry Run butonu hem OTOMATİK hem MANUEL akışta görünür (salt-okuma).
  showEl('pilot-dryrun', ready || manual);
  showEl('pilot-dryrun-panel', ready || manual);
  if (!manual) showEl('pilot-match', false);

  const sourceEl = el('pilot-source');
  if (sourceEl) {
    if (manual) {
      sourceEl.textContent = 'SEÇİM: MANUEL';
      sourceEl.classList.remove('hidden');
    } else if (pilot != null) {
      sourceEl.textContent = 'SEÇİM: OTOMATİK';
      sourceEl.classList.remove('hidden');
    } else {
      sourceEl.classList.add('hidden');
    }
  }

  if (ready || manual) {
    const m = manualPilotSelection;
    setText('pilot-firma', (manual ? m?.title : pilot?.firmTitle) || '—');
    setText('pilot-worksite', (manual ? m?.worksiteIdMasked : pilot?.katipWorksiteIdMasked) || '—');
    setText('pilot-firm-match', pilotFirmLabel(pilot?.firmMatch));
    setText('pilot-personnel', pilotPersonnelLabel(pilot?.personnelMatch));
    setText('pilot-assignment', pilotAssignmentLabel(pilot?.assignmentMatch));
    const c = pilot?.employeeCount ?? null;
    const katip =
      c && c.katip != null
        ? String(c.katip)
        : manual && m?.katipCalisanSayisi != null
          ? String(m.katipCalisanSayisi)
          : '—';
    const central = c && c.central != null ? String(c.central) : '—';
    const diff = c && c.diff != null ? String(c.diff) : '—';
    setText('pilot-count', `KATİP: ${katip} · Merkezi: ${central} · Fark: ${diff}`);
  }

  if (ready) {
    setPilotSubStatus('DOĞRULAMA BEKLİYOR');
  } else if (manual) {
    setPilotSubStatus('DOĞRULAMA BEKLİYOR');
  } else {
    setPilotSubStatus('');
  }

  // DATA_INCOMPLETE → kullanıcıya anlaşılır durum mesajı (teknik sayaçlar GÖSTERİLMEZ).
  const incomplete = status === 'PILOT_DATA_INCOMPLETE';
  setText(
    'pilot-desc',
    incomplete
      ? "İşyeri listesi hazırlanıyor. İSG-KATİP'te 'İSG Hizmet Sözleşmeleri' listesini açıp kaydırın, sonra 'İşyeri Aktar'a tekrar dokunun."
      : pilot?.note || 'Aktarım için işyeri seçin; yakalanan işyerleri burada listelenir.',
  );

  // Dry Run panelini mevcut operation state ile tazele (bağlantı göstergesine DOKUNMAZ).
  renderPilotDryRunPanel();
  // Apply kapısını kapsam + Dry Run SUCCESS durumuna göre tazele (AUTO mod dahil).
  updateApplyReadiness();
}

/** Personel önizleme tablosunu (PII maskeli) render eder. */
function renderPersonPreviewList(list: KatipPilotPersonPreview[]): void {
  const host = el('pm-person-list');
  if (!host) return;
  host.innerHTML = '';
  if (list.length === 0) {
    const p = document.createElement('p');
    p.className = 'pm-note';
    p.textContent = 'Seçilen işyerinde görevlendirilmiş kişi bulunamadı.';
    host.appendChild(p);
    return;
  }
  for (const p of list) {
    const row = document.createElement('div');
    row.className = 'pm-item';
    const left = document.createElement('span');
    left.textContent = `${p.adSoyadMasked || 'Kişi'}${p.role ? ` · ${p.role}` : ''}`;
    const tag = document.createElement('span');
    tag.className = `pm-tag ${personTagClass(p.status)}`;
    tag.textContent = personStatusLabel(p.status);
    row.appendChild(left);
    row.appendChild(tag);
    host.appendChild(row);
  }
}

/** Yasal atama önizleme tablosunu (PII maskeli; helper hariç) render eder. */
function renderAssignPreviewList(list: KatipPilotAssignmentPreview[]): void {
  const host = el('pm-assign-list');
  if (!host) return;
  host.innerHTML = '';
  if (list.length === 0) {
    const p = document.createElement('p');
    p.className = 'pm-note';
    p.textContent = 'Bu işyeri için yasal atama bulunamadı.';
    host.appendChild(p);
    return;
  }
  for (const a of list) {
    const row = document.createElement('div');
    row.className = 'pm-item';
    const left = document.createElement('span');
    left.textContent = `Sözleşme ${a.sozlesmeIdMasked || '—'}${a.role ? ` · ${a.role}` : ''}`;
    const tag = document.createElement('span');
    tag.className = `pm-tag ${personTagClass(a.status)}`;
    tag.textContent = personStatusLabel(a.status);
    row.appendChild(left);
    row.appendChild(tag);
    host.appendChild(row);
  }
}

/** İlk WRITE planını (salt okunur) render eder. */
function renderWritePlan(
  preview: KatipManualPilotPreview,
  isgFirmId: string | null,
  katipWorksiteId: string,
): void {
  const host = el('pm-write-plan');
  if (!host) return;
  host.innerHTML = '';
  const result = assembleManualPilotResult(preview, isgFirmId, katipWorksiteId);
  const wp: KatipPilotWritePlan = result.writePlan;
  const rows: Array<[string, string]> = [];
  if (wp.firmaConflict) {
    rows.push(['Firma', 'ÇAKIŞMA → işyeri bağlanmaz']);
  } else {
    rows.push(['Firma: mevcut kayıtla eşleştir', String(wp.firmaLink)]);
  }
  rows.push(['Personel: mevcut kayıtla eşleştir', String(wp.personLink)]);
  rows.push(['Personel: yeni kayıt oluştur', String(wp.personNew)]);
  rows.push(['Yasal Atama: mevcut atamayla eşleştir', String(wp.atamaLink)]);
  rows.push(['Yasal Atama: yeni atama oluştur', String(wp.atamaNew)]);
  const countText = /report|unchanged|same|none|değiş/i.test(String(wp.countAction))
    ? 'Değiştirilmez (rapor)'
    : String(wp.countAction);
  rows.push(['Çalışan Sayısı', countText]);
  for (const [label, value] of rows) {
    const row = document.createElement('div');
    row.className = 'pm-item';
    const l = document.createElement('span');
    l.textContent = label;
    const b = document.createElement('b');
    b.textContent = value;
    row.appendChild(l);
    row.appendChild(b);
    host.appendChild(row);
  }
}

/* -------------------------------------------------------------------------- */
/* FAZ 6J.3-PRE → 6J.3 — PİLOT DRY RUN (bağımsız operation state)              */
/* -------------------------------------------------------------------------- */

/** İki kolonlu PII'siz satır listesini host'a ekler. */
function appendRows(host: HTMLElement, rows: Array<[string, string]>): void {
  for (const [label, value] of rows) {
    const row = document.createElement('div');
    row.className = 'pm-item';
    const l = document.createElement('span');
    l.textContent = label;
    const b = document.createElement('b');
    b.textContent = value;
    row.appendChild(l);
    row.appendChild(b);
    host.appendChild(row);
  }
}

/** Pilot Dry Run durumunu + WRITE'a hazır planı UI'a yansıtır. DB WRITE DAİMA 0. */
function renderPilotDryRunPanel(): void {
  const statusEl = el('pilot-dryrun-status');
  const rowsHost = el('pilot-dryrun-rows');
  const noteEl = el('pilot-dryrun-note');
  if (rowsHost) rowsHost.innerHTML = '';

  const label =
    pilotDryRunState === 'RUNNING'
      ? 'Kontrol ediliyor…'
      : pilotDryRunState === 'SUCCESS'
        ? 'Kontrol tamamlandı'
        : pilotDryRunState === 'ERROR'
          ? 'Kontrol tamamlanamadı'
          : 'Kontrol edilmeye hazır';
  if (statusEl) {
    statusEl.textContent = label;
    statusEl.className = `pm-status ${
      pilotDryRunState === 'SUCCESS' ? 'ready' : pilotDryRunState === 'ERROR' ? 'conflict' : 'wait'
    }`;
  }

  const devHost = el('pilot-apply-dev-rows');

  if (rowsHost && pilotDryRunState === 'ERROR' && pilotDryRunError) {
    const reason =
      pilotDryRunError.code === 'DRY_RUN_DATA_INCOMPLETE'
        ? 'İSG-KATİP verileri henüz tamamlanmadı. Tüm sayfalar alınınca tekrar deneyin.'
        : pilotDryRunError.code === 'BRIDGE_NOT_READY'
          ? 'İSGDenetim bağlantısı kurulamadı. İSGDenetim sekmesini açıp tekrar deneyin.'
          : pilotDryRunError.code === 'DRY_RUN_NOT_READY'
            ? 'Önce İSG-KATİP listesini açıp/yenileyin; veri yakalanınca tekrar deneyin.'
            : 'Bu kayıt için doğrulama tamamlanamadı.';
    appendRows(rowsHost, [['Durum', reason]]);
    if (devHost) {
      devHost.innerHTML = '';
      appendRows(devHost, [
        ['Dry Run aşama', pilotDryRunError.stage],
        ['Dry Run kod', pilotDryRunError.code],
        ['Dry Run mesaj', pilotDryRunError.message],
      ]);
    }
  } else if (rowsHost && pilotDryRunState === 'SUCCESS' && pilotDryRunResult) {
    const rows: Array<[string, string]> = [];
    // Seçilen işyeri (tek firma kapsamı).
    const sc = pilotDryRunResult.scope;
    if (sc?.scoped) {
      rows.push(['Seçilen İşyeri', sc.firmTitle || '—']);
      rows.push(['İşyeri ID', sc.firmExternalIdMasked || '—']);
      rows.push([
        'Seçim',
        sc.source === 'MANUAL' ? 'Manuel' : sc.source === 'AUTO' ? 'Otomatik' : '—',
      ]);
    } else {
      rows.push(['Seçilen İşyeri', 'İşyeri seçilmedi']);
    }
    if (manualPreview && manualPilotSelection) {
      const res = assembleManualPilotResult(
        manualPreview,
        selectedIsgFirmId,
        manualPilotSelection.worksiteId,
      );
      const wp = res.writePlan;
      rows.push([
        'Firma',
        wp.firmaConflict
          ? 'Çakışma → bağlanmaz'
          : wp.firmaLink > 0
            ? 'Mevcut kayıtla eşleşti'
            : 'Yeni kayıt',
      ]);
      rows.push(['Personel', `${wp.personLink} eşleşti / ${wp.personNew} yeni`]);
      rows.push(['Yasal Atama', `${wp.atamaLink} eşleşti / ${wp.atamaNew} yeni`]);
    } else {
      rows.push(['Firma (Eşleşti/Yeni/Çakışma/Belirsiz)', formatCounts(pilotDryRunResult.firms)]);
      rows.push(['Personel (Eşleşti/Yeni/Çakışma/Belirsiz)', formatCounts(pilotDryRunResult.persons)]);
      rows.push(['Yasal Atama (Eşleşti/Yeni/Çakışma/Belirsiz)', formatCounts(pilotDryRunResult.assignments)]);
    }
    const rc = pilotDryRunResult.employeeCount?.rows?.[0];
    rows.push([
      'Çalışan (KATİP / İSGDenetim / Fark)',
      rc ? `${rc.katipCount ?? '—'} / ${rc.centralCount ?? '—'} / ${rc.diff ?? 0}` : '—',
    ]);
    appendRows(rowsHost, rows);
    // Teknik sayaçlar YALNIZCA geliştirici teşhisine yazılır (ürün ekranında GÖRÜNMEZ).
    if (devHost) {
      devHost.innerHTML = '';
      appendRows(devHost, [['DB WRITE', String(pilotDryRunResult.dbWrites ?? 0)]]);
      if (sc?.scoped && ((sc.outOfScopeFirms ?? 0) > 0 || (sc.outOfScopeAssignments ?? 0) > 0)) {
        appendRows(devHost, [
          [
            'Kapsam dışı (teşhis)',
            `${sc.outOfScopeFirms ?? 0} firma · ${sc.outOfScopeAssignments ?? 0} atama`,
          ],
        ]);
      }
    }
  }

  if (noteEl) {
    noteEl.textContent =
      pilotDryRunState === 'SUCCESS'
        ? 'Kontrol tamamlandı. Hiçbir veri yazılmadı; aktarımı onaylayabilirsiniz.'
        : pilotDryRunState === 'ERROR'
          ? 'Kontrol tamamlanamadı; hiçbir veri yazılmadı.'
          : 'Bilgileri kontrol edin; uygunsa aktarım onayı açılır. Hiçbir veri yazılmaz.';
  }
}

/** Zaman aşımı sarmalayıcı (yanıt gelmezse güvenli fallback). */
function withTimeout<T>(p: Promise<T>, ms: number, onTimeout: () => T): Promise<T> {
  return new Promise<T>((resolve) => {
    let done = false;
    const timer = setTimeout(() => {
      if (done) return;
      done = true;
      resolve(onTimeout());
    }, ms);
    p.then((v) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve(v);
    }).catch(() => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      resolve(onTimeout());
    });
  });
}

/** Pilot Dry Run için köprü gönderimi (röle-öncelikli, aktif-sekme yedekli). */
async function sendDryRunBridge(payload: BridgePayload): Promise<BridgeChannelResult | undefined> {
  const relay = await runViaRelay('dryrun', payload);
  if (relay) return relay.res;
  const tab = await getActiveTab();
  if (!tab?.id) return undefined;
  try {
    let res = await injectSpaSender(tab.id, payload, false);
    if (!res || res.status === 'BRIDGE_NOT_READY') {
      const scoped = await injectSpaSender(tab.id, payload, true).catch(() => undefined);
      if (scoped && scoped.status !== 'BRIDGE_NOT_READY') res = scoped;
    }
    if (res && res.status !== 'BRIDGE_NOT_READY') await ensureDenetimRelay(tab.id);
    return res as BridgeChannelResult | undefined;
  } catch {
    return undefined;
  }
}

/** Dry Run hatasını BAĞIMSIZ operation state'e yazar (connection state'e DOKUNMAZ). */
function failPilotDryRun(stage: string, code: string, message: string): void {
  pilotDryRunState = 'ERROR';
  pilotDryRunResult = null;
  pilotDryRunError = { stage, code, message };
  renderPilotDryRunPanel();
  persistPilotState();
}

/**
 * FAZ 6J.3 — Pilot Dry Run: BAĞIMSIZ operation state ile çalışır; bağlantı göstergesini
 * (spa-text) gereksiz yere DEĞİŞTİRMEZ. READ-ONLY'dir; hiçbir yazma yapmaz. Aynı anda tek kez
 * çalışabilir (in-flight kilidi → double-click guard). Gerçek hatayı stage/code/message ile gösterir.
 */
async function runPilotDryRun(): Promise<void> {
  if (pilotDryRunInFlight) return;
  // FAZ A/B — Kapsam ZORUNLU: pilot firma çözülmeden Dry Run ÇALIŞMAZ (global rapor YOK).
  const scope = resolvePilotScope();
  if (!scope) {
    failPilotDryRun(
      'SCOPE',
      'PILOT_SCOPE_UNRESOLVED',
      'Pilot firma kapsamı çözülemedi; önce pilot firma seçin/belirleyin.',
    );
    return;
  }
  pilotDryRunInFlight = true;
  const button = el<HTMLButtonElement>('pilot-dryrun');
  if (button) button.disabled = true;
  pilotDryRunState = 'RUNNING';
  pilotDryRunResult = null;
  pilotDryRunError = null;
  renderPilotDryRunPanel();
  try {
    // Yalnızca HAZIR DEĞİLSE bağlan; mevcut READY bağlantıyı GEREKSİZ yeniden kurma.
    if (getConnState() !== 'READY') {
      await connectToIsgDenetim();
    }
    const rows = await readCapturedRows();
    if (!rows.captured) {
      failPilotDryRun('BRIDGE', 'DRY_RUN_NOT_READY', rows.error ?? 'Gerçek KATİP verisi henüz yakalanmadı.');
      return;
    }
    // FAZ 1 — DATA GATE: KATİP sayfaları tamamlanmadan Dry Run (ve dolayısıyla Apply) ÇALIŞMAZ.
    const hizmetState = rows.report?.hizmet.state;
    if (hizmetState && hizmetState !== 'DATA_COMPLETE') {
      const r = rows.report?.hizmet;
      failPilotDryRun(
        'DATA',
        'DRY_RUN_DATA_INCOMPLETE',
        `KATİP verilerinin tüm sayfaları henüz alınmadı (toplanan ${r?.rowCount ?? 0} · sayfa ${r?.pageCount ?? 0}). ` +
          `Gerekli sayfalar alınınca tekrar deneyin.`,
      );
      return;
    }
    // FAZ A/B — Pilot kapsamı köprüye taşınır; motor YALNIZCA seçilen tek firmayı değerlendirir.
    const payload: BridgePayload = {
      hizmetRows: rows.hizmetRows,
      personelRows: rows.personelRows,
      capturedAt: new Date().toISOString(),
      pilotFirmExternalId: scope.externalId,
      pilotSource: scope.source,
      pilotFirmTitle: scope.title,
    };
    const res = await withTimeout(sendDryRunBridge(payload), 15000, () => undefined);
    if (!res) {
      failPilotDryRun('BRIDGE', 'DRY_RUN_TIMEOUT', 'Dry Run yanıt vermedi (zaman aşımı).');
      return;
    }
    if (res.status === 'BRIDGE_NOT_READY') {
      failPilotDryRun('BRIDGE', 'BRIDGE_NOT_READY', res.error ?? 'İSGDenetim köprüsü hazır değil.');
      return;
    }
    const result = res.result as LooseDryRun | undefined;
    if (!res.ok || !result || result.status !== 'READY') {
      const code = result?.status ?? res.status ?? 'DRY_RUN_ERROR';
      const stage =
        code === 'PILOT_SCOPE_UNRESOLVED'
          ? 'SCOPE'
          : code === 'LOCAL_SNAPSHOT_NOT_READY' || code === 'DRY_RUN_NOT_READY'
            ? 'SNAPSHOT'
            : 'DRY_RUN';
      failPilotDryRun(stage, code, result?.note ?? res.error ?? 'Dry Run tamamlanamadı.');
      return;
    }
    pilotDryRunState = 'SUCCESS';
    pilotDryRunResult = result;
    pilotDryRunError = null;
    renderPilotDryRunPanel();
    persistPilotState();
  } catch (e) {
    failPilotDryRun('BRIDGE', 'DRY_RUN_ERROR', e instanceof Error ? e.message : 'Dry Run hata verdi.');
  } finally {
    pilotDryRunInFlight = false;
    if (button) button.disabled = false;
    updateApplyReadiness();
  }
}

/* -------------------------------------------------------------------------- */
/* FAZ 6J.3 — Pilot WRITE onay + sonuç UI                                      */
/* -------------------------------------------------------------------------- */

/** Pilot WRITE özeti: onay öncesi gösterilecek satırlar (yalnızca tek pilot firma). */
function buildApplySummary(): void {
  const host = el('pilot-apply-summary');
  if (!host) return;
  host.innerHTML = '';
  const scope = resolvePilotScope();
  const rows: Array<[string, string]> = [
    ['İşyeri', scope?.title ?? '—'],
    [
      'İşyeri No',
      currentPilotResult?.katipWorksiteIdMasked ?? manualPilotSelection?.worksiteIdMasked ?? '—',
    ],
  ];
  if (manualPreview && manualPilotSelection && selectedIsgFirmId) {
    const res = assembleManualPilotResult(manualPreview, selectedIsgFirmId, manualPilotSelection.worksiteId);
    const wp = res.writePlan;
    rows.push([
      'Firma',
      wp.firmaConflict ? 'Çakışma → uygulanmaz' : wp.firmaLink > 0 ? 'Mevcut kayıtla eşleşir' : 'Yeni kayıt',
    ]);
    rows.push(['Personel', `${wp.personLink} eşleşir / ${wp.personNew} yeni`]);
    rows.push(['Yasal Atama', `${wp.atamaLink} eşleşir / ${wp.atamaNew} yeni`]);
  } else {
    rows.push(['Kapsam', 'Yalnızca seçilen işyeri']);
  }
  rows.push(['Çalışan Sayısı', 'Değiştirilmez (rapor)']);
  for (const [label, value] of rows) {
    const row = document.createElement('div');
    row.className = 'pm-item';
    const l = document.createElement('span');
    l.textContent = label;
    const b = document.createElement('b');
    b.textContent = value;
    row.appendChild(l);
    row.appendChild(b);
    host.appendChild(row);
  }
}

/** Pilot write yalnızca GÜVENLİ doğrulanmış kapsam + Dry Run SUCCESS ise açılır. */
function updateApplyReadiness(): void {
  let ready = false;
  if (pilotDryRunState === 'SUCCESS') {
    if (manualPilotSelection && selectedIsgFirmId && manualPreview) {
      const res = assembleManualPilotResult(manualPreview, selectedIsgFirmId, manualPilotSelection.worksiteId);
      // FAZ 6J.3 — Apply yalnızca plan hazır VE pilot Dry Run BAŞARILI olduğunda açılır.
      ready = res.pilotStatus === 'PILOT_DRY_RUN_READY';
    } else if (currentPilotResult?.katipWorksiteId) {
      // FAZ C — AUTO modda pilot kapsamı çözülmüş + Dry Run BAŞARILI → Apply açılır.
      ready = true;
    }
  }
  showEl('pilot-apply', ready);
  if (!ready) {
    showEl('pilot-apply-confirm', false);
    showEl('pilot-apply-result', false);
  }
}

function setApplyResultText(text: string, cls: string): void {
  const node = el('pilot-apply-result-text');
  if (node) {
    node.textContent = text;
    node.className = `pm-note ${cls}`;
  }
}

/** Sonuç kartını başarı/başarısızlık durumuna göre (gerçek) günceller. */
function setResultCard(ok: boolean): void {
  const card = el('katip-result-card');
  const icon = el('katip-result-icon');
  const title = el('katip-result-title');
  if (card) card.classList.toggle('is-fail', !ok);
  if (icon) icon.textContent = ok ? '✓' : '!';
  if (title) title.textContent = ok ? 'Aktarım tamamlandı' : 'Aktarım doğrulanamadı';
  showEl('katip-result-checks', ok);
}

/** Aktarım sonucu için kullanıcı diliyle net mesaj (durum → mesaj; duruma özgü, teknik DEĞİL). */
function applyResultMessage(a: LooseApply, ok: boolean, applied: boolean): string {
  if (ok) return 'Aktarım tamamlandı ve doğrulandı.';
  if (applied) {
    if (a.status === 'PILOT_APPLY_VERIFY_FAILED') {
      return 'Aktarım yapıldı ancak doğrulanamadı; kayıtları kontrol edin.';
    }
    return 'Aktarım kısmen tamamlandı; bazı kayıtlar işlenemedi.';
  }
  switch (a.status) {
    case 'PILOT_DATA_INCOMPLETE':
      return 'İSG-KATİP verileri henüz tamamlanmadı; aktarım yapılmadı.';
    case 'PILOT_APPLY_NOT_AUTHENTICATED':
      return 'Oturum doğrulanamadı. İSGDenetim’e yeniden giriş yapın.';
    case 'PILOT_APPLY_SCOPE_REQUIRED':
      return 'OSGB kapsamı çözülemedi; aktarım yapılamadı.';
    case 'PILOT_APPLY_SCOPE_NOT_ACTIVE':
      return 'Seçilen işyerinin aktif hizmet sözleşmesi yok; aktarım yapılmadı.';
    case 'PILOT_APPLY_FIRM_NOT_FOUND':
      return 'Seçilen işyeri eşleştirilemedi; aktarım yapılmadı.';
    default:
      return 'Aktarım tamamlanamadı — değişiklik yapılmadı.';
  }
}

/** Pilot apply sonucunu (breakdown + verify) UI'a yansıtır. Fake PASS gösterilmez. */
function renderApplyResult(a: LooseApply | undefined): void {
  const rowsHost = el('pilot-apply-result-rows');
  const devHost = el('pilot-apply-dev-rows');
  if (rowsHost) rowsHost.innerHTML = '';
  if (devHost) devHost.innerHTML = '';
  showEl('pilot-apply-result', true);
  if (!a) {
    setResultCard(false);
    setApplyResultText('Aktarım sonucu alınamadı.', 'apply-result-fail');
    return;
  }
  const applied = a.applied === true;
  const verified = a.verify?.pass === true;
  const ok = a.ok === true && applied && verified;
  const partial = applied && !ok;
  setResultCard(ok);
  setApplyResultText(applyResultMessage(a, ok, applied), ok ? 'apply-result-ok' : 'apply-result-fail');
  if (!rowsHost) return;
  const b = a.breakdown ?? {};
  const f = b.firma ?? {};
  const p = b.personel ?? {};
  const at = b.atama ?? {};
  const isError = a.status === 'PILOT_APPLY_ERROR';
  const rows: Array<[string, string]> = [];
  rows.push(['Firma (eşleşti / yeni / değişmedi)', `${f.linked ?? 0} / ${f.created ?? 0} / ${f.noop ?? 0}`]);
  rows.push(['Personel (eşleşti / yeni / değişmedi)', `${p.linked ?? 0} / ${p.created ?? 0} / ${p.noop ?? 0}`]);
  rows.push(['Yasal Atama (eşleşti / yeni / değişmedi)', `${at.linked ?? 0} / ${at.created ?? 0} / ${at.noop ?? 0}`]);
  rows.push(['Doğrulama (firma)', a.verify?.firmLinked ? 'Bağlı' : 'YOK']);
  rows.push(['Doğrulama (personel)', `${a.verify?.personnelLinked ?? 0}/${a.verify?.personnelExpected ?? 0}`]);
  rows.push(['Doğrulama (yasal atama)', `${a.verify?.assignmentLinked ?? 0}/${a.verify?.assignmentExpected ?? 0}`]);
  rows.push(['Çalışan sayısı', (a.employeeCountChanged ?? 0) === 0 ? 'Değişmedi' : 'Değişti']);
  if (!applied) rows.push(['Sonuç', 'Değişiklik yapılmadı.']);
  else if (partial) rows.push(['Sonuç', 'Kısmi tamamlandı — kayıtları kontrol edin.']);
  appendRows(rowsHost, rows);
  // Teknik aşama/kod/mesaj + plan teşhisi YALNIZCA gizli geliştirici teşhisine yazılır.
  if (devHost) {
    const diag: Array<[string, string]> = [];
    if (isError) {
      diag.push(['Aşama', a.stage ?? 'BİLİNMEYEN']);
      diag.push(['Kod', a.errorCode ?? '—']);
      diag.push(['Mesaj', a.errorMessage ?? a.message ?? '—']);
    }
    const plan = a.breakdown?.plan ?? null;
    if (plan) {
      if ((plan.personnelActions ?? 0) === 0) {
        diag.push([
          'Personel planı',
          `aksiyon yok · eşleşen ${plan.personnelMatched ?? 0} · yeni ${plan.personnelNew ?? 0} · belirsiz ${plan.personnelUnresolved ?? 0} · çakışma ${plan.personnelConflict ?? 0}`,
        ]);
      }
      if ((plan.assignmentActions ?? 0) === 0) {
        diag.push(['Atama planı', `aksiyon yok · yeni ${plan.assignmentNew ?? 0}`]);
      }
    }
    diag.push(['Hata', isError ? '1' : String(a.counts?.errors ?? 0)]);
    if (ok) diag.push(['Durum', 'PILOT TAMAMLANDI']);
    appendRows(devHost, diag);
  }
}

/* -------------------------------------------------------------------------- */
/* Bridge gönderim yolları                                                     */
/* -------------------------------------------------------------------------- */

/**
 * Pilot kanalı için TEK gönderim yolu (röle-öncelikli, aktif-sekme yedekli).
 * 🔒 token/cookie/JWT taşımaz; yeni KATİP HTTP isteği ATMAZ; hiçbir yazma yapmaz.
 */
async function sendPilotBridge(payload: BridgePayload): Promise<BridgeChannelResult | undefined> {
  const relay = await runViaRelay('pilot', payload);
  if (relay) return relay.res;
  const tab = await getActiveTab();
  if (!tab?.id) return undefined;
  try {
    let res = await injectPilotSender(tab.id, payload, false);
    if (!res || res.status === 'BRIDGE_NOT_READY') {
      const scoped = await injectPilotSender(tab.id, payload, true).catch(() => undefined);
      if (scoped && scoped.status !== 'BRIDGE_NOT_READY') res = scoped;
    }
    if (res && res.status !== 'BRIDGE_NOT_READY') await ensureDenetimRelay(tab.id);
    return res;
  } catch {
    return undefined;
  }
}

/**
 * Pilot APPLY isteğini kanonik KALICI RÖLE üzerinden İSGDenetim SPA'ya iletir.
 * Röle yoksa canonical bağlantı kurulup tekrar denenir. Global import AÇILMAZ.
 */
async function sendApplyBridge(payload: BridgePayload): Promise<BridgeChannelResult | undefined> {
  let relay = await runViaRelay('apply', payload);
  if (relay) return relay.res;
  await connectToIsgDenetim();
  relay = await runViaRelay('apply', payload);
  return relay?.res;
}

/* -------------------------------------------------------------------------- */
/* Pilot resolve + manuel seçim                                                */
/* -------------------------------------------------------------------------- */

/** "Pilot Adayını Belirle" — gerçek KATİP satırlarını okuyup SPA köprüsü üzerinden çözer. */
async function runPilotResolve(): Promise<void> {
  const button = el<HTMLButtonElement>('pilot-resolve');
  if (button) button.disabled = true;
  manualPilotSelection = null;
  manualPreview = null;
  selectedIsgFirmId = null;
  showEl('pilot-manual', false);
  showEl('pilot-match', false);
  resetPilotDryRun();
  setText('pilot-desc', 'İşyeri doğrulaması yapılıyor…');
  try {
    const rows = await readCapturedRows();
    if (!rows.captured) {
      currentPilotResult = {
        status: 'NO_SAFE_PILOT_CANDIDATE',
        pilotSource: 'AUTO',
        note: rows.error ?? 'Gerçek İSG-KATİP verisi henüz yakalanmadı.',
      };
      renderPilot(currentPilotResult);
      persistPilotState();
      return;
    }
    // FAZ 1 — DATA GATE: KATİP sayfaları tamamlanmadan "güvenli pilot adayı yok" sonucu
    // ÜRETİLMEZ. Veri eksikse PILOT_DATA_INCOMPLETE gösterilir (SPA resolver'a gidilmez).
    const hizmetState = rows.report?.hizmet.state;
    if (hizmetState && hizmetState !== 'DATA_COMPLETE') {
      currentPilotResult = {
        status: 'PILOT_DATA_INCOMPLETE',
        pilotSource: 'AUTO',
        note: "İşyeri listesi hazırlanıyor: İSG-KATİP'teki tüm sayfalar henüz alınmadı.",
      };
      renderPilot(currentPilotResult);
      persistPilotState();
      return;
    }
    const payload: BridgePayload = {
      hizmetRows: rows.hizmetRows,
      personelRows: rows.personelRows,
      capturedAt: new Date().toISOString(),
    };
    const res = await sendPilotBridge(payload);
    if (!res || res.status === 'BRIDGE_NOT_READY') {
      currentPilotResult = {
        status: 'PILOT_OUT_OF_SCOPE',
        pilotSource: 'AUTO',
        note:
          res?.error ??
          'İSGDenetim sekmesi bulunamadı (BRIDGE_NOT_READY). Aktif sekmenin İSGDenetim olduğundan emin olun.',
      };
      renderPilot(currentPilotResult);
      persistPilotState();
      return;
    }
    currentPilotResult = (res.pilot as LoosePilot | undefined) ?? null;
    renderPilot(currentPilotResult ?? undefined);
    persistPilotState();
  } finally {
    if (button) button.disabled = false;
  }
}

/** Yakalanan KATİP firmalarını (PII'siz) listeler. */
function renderManualPilotList(query: string): void {
  const host = el('pilot-manual-list');
  if (!host) return;
  host.innerHTML = '';
  if (manualCandidates.length === 0) {
    setText('pilot-manual-note', 'Yakalanmış İSG-KATİP hizmet sözleşmesi bulunamadı. İSG-KATİP listesini açıp/yenileyin.');
    return;
  }
  const q = trSearchKey(query);
  const items = manualCandidates.filter(
    (c) => !q || trSearchKey(c.title).includes(q) || trSearchKey(c.worksiteIdMasked ?? '').includes(q),
  );
  if (items.length === 0) {
    setText('pilot-manual-note', 'Aramanızla eşleşen işyeri bulunamadı.');
    return;
  }
  setText('pilot-manual-note', `${items.length} işyeri listelendi.`);
  for (const c of items) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'manual-item';

    const top = document.createElement('span');
    top.className = 'manual-item-top';
    const title = document.createElement('span');
    title.className = 'manual-item-title';
    title.textContent = c.title || 'Unvansız işyeri';
    const badge = document.createElement('span');
    badge.className = 'k-tag k-tag-green';
    badge.textContent =
      c.activeContractCount > 1 ? `Aktif · ${c.activeContractCount} sözleşme` : 'Aktif sözleşme';
    top.appendChild(title);
    top.appendChild(badge);

    const meta = document.createElement('span');
    meta.className = 'manual-item-meta';
    const parts: string[] = [];
    if (c.worksiteIdMasked) parts.push(`İşyeri No ${c.worksiteIdMasked}`);
    if (c.katipCalisanSayisi != null) parts.push(`${c.katipCalisanSayisi} çalışan`);
    meta.textContent = parts.join(' · ') || '—';

    btn.appendChild(top);
    btn.appendChild(meta);
    btn.addEventListener('click', () => void selectManualPilot(c));
    host.appendChild(btn);
  }
}

/** "Manuel Seç" — kompakt firma seçim panelini açar ve yakalanan KATİP listesini doldurur. */
async function openManualPilotPanel(): Promise<void> {
  showEl('pilot-manual', true);
  setText('pilot-manual-note', 'İşyeri listesi yükleniyor…');
  const search = el<HTMLInputElement>('pilot-manual-search');
  if (search) search.value = '';
  const rows = await readCapturedRows();
  manualCandidates = listKatipPilotFirmCandidates({ hizmetRows: rows.hizmetRows });
  renderManualPilotList('');
  if (manualCandidates.length === 0) {
    // FAZ 1 — DATA GATE: Veri henüz tamamlanmadıysa "aktif sözleşme bulunamadı" DEME.
    const report = rows.report?.hizmet;
    if (report && report.state !== 'DATA_COMPLETE' && report.rowCount > 0) {
      setText(
        'pilot-manual-note',
        "Liste için İSG-KATİP kayıtları bekleniyor. İSG-KATİP'te 'İSG Hizmet Sözleşmeleri' listesini açıp tüm sayfaları kaydırın, ardından bu panelde 'İşyeri Aktar'a tekrar dokunun.",
      );
    } else {
      // FAZ 6J.5 — PII'siz aktiflik teşhisi: aktif sözleşme yokken NEDEN listelenmediği görünür.
      const summary = summarizeKatipContractActivity(rows.hizmetRows);
      if (summary.rawContracts > 0) {
        setText(
          'pilot-manual-note',
          "Bu işyeri için aktif hizmet sözleşmesi bulunamadı. Geçmiş/sonlandırılmış sözleşmeler aktarım kapsamına alınmaz.",
        );
      } else {
        setText('pilot-manual-note', rows.error ?? 'Gerçek İSG-KATİP verisi henüz yakalanmadı. İSG-KATİP listesini açıp/yenileyin.');
      }
    }
  }
}

/** Kullanıcının listeden seçtiği firmayı runtime durumda tutar ve doğrulamayı başlatır. */
async function selectManualPilot(c: KatipPilotFirmCandidate): Promise<void> {
  manualPilotSelection = {
    worksiteId: c.worksiteId,
    worksiteIdMasked: c.worksiteIdMasked,
    title: c.title,
    katipCalisanSayisi: c.katipCalisanSayisi,
  };
  manualPreview = null;
  selectedIsgFirmId = null;
  showEl('pilot-manual', false);
  resetPilotDryRun();
  persistPilotState();
  await resolveManualPilot();
}

/**
 * Seçilen KATİP firmasını mevcut authenticated İSGDenetim snapshot'ı ile SALT-OKUMA doğrular.
 */
async function resolveManualPilot(): Promise<void> {
  const selection = manualPilotSelection;
  if (!selection) return;
  manualPreview = null;
  selectedIsgFirmId = null;
  resetPilotDryRun();
  setText('pilot-desc', 'Seçilen işyeri için İSGDenetim doğrulaması yapılıyor…');
  const rows = await readCapturedRows();
  if (!rows.captured) {
    currentPilotResult = {
      status: 'NO_SAFE_PILOT_CANDIDATE',
      pilotSource: 'MANUAL',
      note: rows.error ?? 'Gerçek İSG-KATİP verisi henüz yakalanmadı.',
    };
    renderPilot(currentPilotResult);
    renderManualMatch();
    persistPilotState();
    return;
  }
  const filtered = filterHizmetRowsByWorksite(rows.hizmetRows, selection.worksiteId);
  if (filtered.length === 0) {
    currentPilotResult = {
      status: 'NO_SAFE_PILOT_CANDIDATE',
      pilotSource: 'MANUAL',
      note: 'Seçilen işyeri yakalanmış İSG-KATİP verileri arasında bulunamadı.',
    };
    renderPilot(currentPilotResult);
    renderManualMatch();
    persistPilotState();
    return;
  }
  const payload: BridgePayload = {
    hizmetRows: filtered,
    personelRows: rows.personelRows,
    capturedAt: new Date().toISOString(),
  };
  const res = await sendPilotBridge(payload);
  // STALE SEÇİM KORUMASI: async akış sırasında kullanıcı BAŞKA firma seçtiyse eski sonucu YANSITMA.
  if (manualPilotSelection !== selection) return;
  if (!res || res.status === 'BRIDGE_NOT_READY') {
    currentPilotResult = {
      status: 'PILOT_OUT_OF_SCOPE',
      pilotSource: 'MANUAL',
      note:
        res?.error ??
        'İSGDenetim sekmesi bulunamadı (BRIDGE_NOT_READY). Aktif sekmenin İSGDenetim olduğundan emin olun.',
    };
    renderPilot(currentPilotResult);
    renderManualMatch();
    persistPilotState();
    return;
  }
  const pilot = res.pilot as LoosePilot | undefined;
  currentPilotResult = pilot ?? null;
  renderPilot(pilot);
  manualPreview = (pilot?.manualPreview as KatipManualPilotPreview | undefined) ?? null;
  selectedIsgFirmId = null;
  renderManualMatch();
  persistPilotState();
}

/* -------------------------------------------------------------------------- */
/* İki taraflı manuel eşleme bloğu                                             */
/* -------------------------------------------------------------------------- */

/** FAZ 6J.3-PRE.1 — İki taraflı manuel eşleme bloğunu (8 bölüm) render eder. */
function renderManualMatch(): void {
  const preview = manualPreview;
  if (!preview || !manualPilotSelection) {
    showEl('pilot-match', false);
    showEl('pilot-apply', false);
    return;
  }
  showEl('pilot-match', true);
  const sel = manualPilotSelection;
  setText('pm-katip-title', preview.katipFirmTitle || sel.title || '—');
  setText('pm-katip-worksite', preview.katipWorksiteIdMasked || sel.worksiteIdMasked || '—');
  setText('pm-katip-count', fmtCount(preview.katipCalisanSayisi));

  const select = el<HTMLSelectElement>('pm-isg-firm');
  if (select) {
    select.innerHTML = '';
    const none = document.createElement('option');
    none.value = '';
    none.textContent = preview.isgFirmOptions.length
      ? '— İSGDenetim firması seçin —'
      : 'Kapsamda İSGDenetim firması bulunamadı';
    select.appendChild(none);
    for (const o of preview.isgFirmOptions) {
      const opt = document.createElement('option');
      opt.value = o.id;
      const bits = [o.unvan];
      if (o.vergiNoMasked) bits.push(`VN ${o.vergiNoMasked}`);
      if (o.calisanSayisi != null) bits.push(`${o.calisanSayisi} çalışan`);
      if (o.isgKatipLinked) bits.push('bağlı');
      opt.textContent = bits.join(' · ');
      select.appendChild(opt);
    }
    select.value = selectedIsgFirmId ?? '';
  }

  const result = assembleManualPilotResult(preview, selectedIsgFirmId, sel.worksiteId);
  const option = selectedIsgFirmId
    ? preview.isgFirmOptions.find((o) => o.id === selectedIsgFirmId) ?? null
    : null;

  setText('pm-firm-status', firmMatchLabel(result.firmMatchStatus));
  setText(
    'pm-firm-link',
    option ? (option.isgKatipLinked ? `Bağlı (${option.isgKatipIdMasked ?? '—'})` : 'Bağ yok') : '—',
  );

  setText(
    'pm-person-summary',
    `${preview.personnelCounts.match} / ${preview.personnelCounts.new} / ${preview.personnelCounts.conflict} / ${preview.personnelCounts.notFound}`,
  );
  renderPersonPreviewList(preview.personnel);

  setText(
    'pm-assign-summary',
    `${preview.assignmentCounts.match} / ${preview.assignmentCounts.new} / ${preview.assignmentCounts.conflict}`,
  );
  renderAssignPreviewList(preview.assignments);

  const ec = result.employeeCount;
  setText('pm-count', `KATİP: ${fmtCount(ec.katip)} · İSGDenetim: ${fmtCount(ec.central)} · Fark: ${fmtCount(ec.diff)}`);

  const st = el('pm-pilot-status');
  if (st) {
    st.textContent = pilotStatusLabel(result.pilotStatus);
    st.className = `pm-status ${
      result.pilotStatus === 'PILOT_DRY_RUN_READY'
        ? 'ready'
        : result.pilotStatus === 'PILOT_ESLESMESI_CAKISIYOR'
          ? 'conflict'
          : 'wait'
    }`;
  }

  renderWritePlan(preview, selectedIsgFirmId, sel.worksiteId);
  updateApplyReadiness();
}

/* -------------------------------------------------------------------------- */
/* Pilot WRITE (explicit kullanıcı onayı)                                      */
/* -------------------------------------------------------------------------- */

/** "PİLOTU UYGULA" onayı sonrası gerçek server-side pilot write'ı çalıştırır. */
async function runPilotApply(): Promise<void> {
  const scope = resolvePilotScope();
  if (!scope) {
    showEl('pilot-apply-result', true);
    setApplyResultText('İşyeri seçimi bulunamadı; aktarım iptal edildi.', 'apply-result-fail');
    return;
  }
  if (pilotApplyInFlight) return;
  pilotApplyInFlight = true;
  const yesBtn = el<HTMLButtonElement>('pilot-apply-yes');
  if (yesBtn) yesBtn.disabled = true;
  showEl('pilot-apply-confirm', false);
  showEl('pilot-apply-result', true);
  setApplyResultText('Aktarım uygulanıyor…', '');
  try {
    const rows = await readCapturedRows();
    if (!rows.captured) {
      setApplyResultText('Gerçek İSG-KATİP verisi bulunamadı.', 'apply-result-fail');
      return;
    }
    // FAZ 3 — DATA COMPLETE KAPISI: KATİP sayfaları tamamlanmadan WRITE denenmez.
    const hizmetState = rows.report?.hizmet.state;
    if (hizmetState && hizmetState !== 'DATA_COMPLETE') {
      setApplyResultText(
        "İSG-KATİP verileri henüz tamamlanmadı; aktarım iptal edildi.",
        'apply-result-fail',
      );
      return;
    }
    const filtered = filterHizmetRowsByWorksite(rows.hizmetRows, scope.externalId);
    const hizmetRows = filtered.length > 0 ? filtered : rows.hizmetRows;
    lastCorrelationId = `pilot-${Date.now()}`;
    const res = await sendApplyBridge({
      hizmetRows,
      personelRows: rows.personelRows,
      capturedAt: new Date().toISOString(),
      pilotFirmExternalId: scope.externalId,
      osgbIdHint: scope.osgbIdHint,
      datasetComplete: hizmetState ? hizmetState === 'DATA_COMPLETE' : undefined,
    });
    if (!res || res.status === 'BRIDGE_NOT_READY') {
      setApplyResultText(res?.error ?? 'İSGDenetim bağlantısı kurulamadı.', 'apply-result-fail');
      return;
    }
    currentApplyResult = (res.apply as LooseApply | undefined) ?? null;
    renderApplyResult(currentApplyResult ?? undefined);
    persistPilotState();
  } finally {
    pilotApplyInFlight = false;
    if (yesBtn) yesBtn.disabled = false;
  }
}

/* -------------------------------------------------------------------------- */
/* Init + Restore                                                              */
/* -------------------------------------------------------------------------- */

/**
 * Side Panel açıldığında çağrılır: session state'i geri yükler ve UI'ı restore eder.
 * Bridge yeniden hazır olduğunda (onConnStateChange READY) manuel doğrulama kaldığı yerden sürer.
 * ⛔ OTOMATİK WRITE YOKTUR — apply yalnızca explicit kullanıcı action'ı ile çalışır.
 */
export async function restorePilotWorkflow(): Promise<void> {
  const state = await loadSessionState();
  if (!state) return;
  manualPilotSelection = state.selectedKatipPilotFirm ?? null;
  selectedIsgFirmId = state.selectedIsgDenetimFirm ?? null;
  manualPreview = (state.manualPreview as KatipManualPilotPreview | null) ?? null;
  currentPilotResult = (state.pilotResult as LoosePilot | null) ?? null;
  currentApplyResult = (state.pilotApplyResult as LooseApply | null) ?? null;
  lastCorrelationId = state.lastPilotCorrelationId ?? null;
  pilotDryRunState = (state.pilotDryRunState as PilotDryRunState | null) ?? 'IDLE';
  pilotDryRunResult = (state.pilotDryRunResult as LooseDryRun | null) ?? null;
  pilotDryRunError =
    (state.pilotDryRunError as { stage: string; code: string; message: string } | null) ?? null;

  renderPilot(currentPilotResult ?? undefined);
  renderPilotDryRunPanel();
  if (manualPilotSelection && manualPreview) {
    renderManualMatch();
  }
  if (currentApplyResult) renderApplyResult(currentApplyResult);
  renderStepper();
}

/** Pilot workflow event listener'larını bağlar (idempotent: bir kez çağrılmalı). */
export function initPilotWorkflow(): void {
  el('pilot-resolve')?.addEventListener('click', () => void runPilotResolve());
  el('pilot-manual-open')?.addEventListener('click', () => void openManualPilotPanel());

  // ÜRÜN ANA AKSİYONU: "İşyeri Aktar" → gerçek aktarım akışını (işyeri seçimi) başlatır.
  el('katip-start')?.addEventListener('click', () => {
    void (async () => {
      if (getConnState() !== 'READY') {
        await connectToIsgDenetim();
      }
      await openManualPilotPanel();
      el('pilot-manual')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    })();
  });

  // ÜRÜN İLERLEME AKSİYONU: "Devam Et" → gerçek sonraki adıma geçer.
  el('katip-continue')?.addEventListener('click', () => {
    void (async () => {
      if (currentApplyResult || pilotDryRunState === 'SUCCESS') {
        el('pilot-apply')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      if (manualPreview) {
        await runPilotDryRun();
        el('pilot-dryrun-panel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      if (getConnState() !== 'READY') {
        await connectToIsgDenetim();
      }
      await openManualPilotPanel();
      el('pilot-manual')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    })();
  });
  const manualSearch = el<HTMLInputElement>('pilot-manual-search');
  if (manualSearch) {
    manualSearch.addEventListener('input', () => renderManualPilotList(manualSearch.value));
  }

  const isgFirmSelect = el<HTMLSelectElement>('pm-isg-firm');
  if (isgFirmSelect) {
    isgFirmSelect.addEventListener('change', () => {
      selectedIsgFirmId = isgFirmSelect.value || null;
      // Firma seçimi değişti → plan değişti → mevcut Dry Run sonucu GEÇERSİZ olur.
      resetPilotDryRun();
      renderManualMatch();
      persistPilotState();
    });
  }

  el('pilot-apply-btn')?.addEventListener('click', () => {
    showEl('pilot-apply-result', false);
    buildApplySummary();
    showEl('pilot-apply-confirm', true);
  });
  el('pilot-apply-no')?.addEventListener('click', () => {
    showEl('pilot-apply-confirm', false);
  });
  el('pilot-apply-yes')?.addEventListener('click', () => {
    void runPilotApply();
  });

  el('pilot-dryrun')?.addEventListener('click', () => {
    // Pilot Dry Run: BAĞIMSIZ operation state; bağlantı göstergesini (spa-text) BOZMAZ.
    void runPilotDryRun();
  });

  // Bridge yeniden hazır olduğunda (F5/reconnect sonrası) manuel doğrulamayı kaldığı yerden sürdür.
  onConnStateChange((state) => {
    if (state === 'READY' && manualPilotSelection && !manualPreview) {
      void resolveManualPilot();
    }
  });
}