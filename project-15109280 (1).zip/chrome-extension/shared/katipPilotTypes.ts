/**
 * FAZ 6L — PİLOT WORKFLOW: paylaşılan gevşek (loose) tipler + PII'siz etiket yardımcıları.
 *
 * Davranış FAZ 6J/6K ile BİREBİR aynıdır; yalnızca popup.ts'ten TAŞINMIŞTIR.
 * SAF modüldür: DOM/chrome/supabase bağımlılığı YOKTUR. PII İÇERMEZ.
 */
import type {
  KatipManualFirmMatchStatus,
  KatipManualPilotStatus,
} from '../../src/lib/isgKatip/pilot';

/* FAZ 6J.1 — PİLOT FİRMA (SALT-OKUMA). Gerçek tip `src/lib/isgKatip/pilot.ts` içindedir; burada
 * yalnızca UI için gevşek (loose) ayna tutulur; TC/ad-soyad GÖSTERİLMEZ. */
export interface LoosePilotEmployeeCount {
  katip?: number | null;
  central?: number | null;
  diff?: number | null;
}

export interface LoosePilot {
  status?: string;
  firmTitle?: string | null;
  katipWorksiteIdMasked?: string | null;
  /** FAZ A/B — ham KATİP işyeri kimliği (yalnızca pilot kapsam filtresi; UI'da GÖSTERİLMEZ). */
  katipWorksiteId?: string | null;
  firmMatch?: string;
  personnelMatch?: string | null;
  assignmentMatch?: string | null;
  employeeCount?: LoosePilotEmployeeCount | null;
  katipHizmetRowCount?: number;
  katipUniqueWorksiteCount?: number;
  osgbFirmCount?: number;
  pilotSource?: string;
  selectedWorksiteIdMasked?: string | null;
  manualPreview?: unknown;
  note?: string;
}

/* FAZ 6J.3 — Pilot APPLY sonucu (server-side write + verify). PII İÇERMEZ. */
export interface LooseApplyBreakdown {
  linked?: number;
  created?: number;
  noop?: number;
}

/** FAZ 6J.3-DIAG — pilot plan özeti (0 aksiyonun nedeni; PII taşımaz). */
export interface LooseApplyPlanDiag {
  personnelMatched?: number;
  personnelNew?: number;
  personnelUnresolved?: number;
  personnelConflict?: number;
  personnelActions?: number;
  assignmentNew?: number;
  assignmentActions?: number;
}

export interface LooseApplyVerify {
  firmLinked?: boolean;
  personnelLinked?: number;
  personnelExpected?: number;
  assignmentLinked?: number;
  assignmentExpected?: number;
  pass?: boolean;
}

export interface LooseApply {
  ok?: boolean;
  status?: string;
  applied?: boolean;
  counts?: {
    imported?: number;
    updated?: number;
    matched?: number;
    noop?: number;
    conflict?: number;
    unresolved?: number;
    skipped?: number;
    errors?: number;
  };
  breakdown?: {
    firma?: LooseApplyBreakdown;
    personel?: LooseApplyBreakdown;
    atama?: LooseApplyBreakdown;
    plan?: LooseApplyPlanDiag | null;
  } | null;
  verify?: LooseApplyVerify | null;
  employeeCountChanged?: number;
  message?: string;
  /** FAZ 6J.3-DIAG: hatanın gerçekleştiği aşama (BRIDGE|RPC|VERIFY|UNKNOWN). */
  stage?: string | null;
  /** FAZ 6J.3-DIAG: sanitize edilmiş backend hata kodu (ör. 22P02). */
  errorCode?: string | null;
  /** FAZ 6J.3-DIAG: sanitize edilmiş backend hata mesajı. */
  errorMessage?: string | null;
}

/** FAZ-K1 — Mevcut (zaten bağlı) işyerlerinin bilgilerini yenileme sonucu (PII İÇERMEZ). */
export interface LooseBackfill {
  ok?: boolean;
  total?: number;
  updated?: number;
  failed?: number;
  skipped?: number;
  message?: string;
}

/** Firma eşleşme etiketi. */
export function pilotFirmLabel(match: string | undefined): string {
  if (match === 'EXTERNAL_ID') return 'Firma: Doğrulandı';
  if (match === 'TITLE_CANDIDATE') return 'Firma: Aday';
  return 'Firma: —';
}

/** Personel eşleşme etiketi. */
export function pilotPersonnelLabel(m: string | null | undefined): string {
  if (m === 'EXTERNAL_ID_MATCH' || m === 'MATCH') return 'Eşleşti';
  if (m === 'CONFLICT') return 'Çakışma';
  if (m === 'NOT_FOUND') return 'Bulunamadı';
  return '—';
}

/** Yasal atama etiketi. */
export function pilotAssignmentLabel(a: string | null | undefined): string {
  if (a === 'EXISTING_LEGAL_ASSIGNMENT') return 'Mevcut';
  if (a === 'NOT_LINKED_YET') return 'Henüz Bağlı Değil';
  return '—';
}

/** Sayıyı (null güvenli) gösterir. */
export function fmtCount(v: number | null | undefined): string {
  return v == null ? '—' : String(v);
}

/** Firma manuel eşleşme durumu etiketi. */
export function firmMatchLabel(s: KatipManualFirmMatchStatus): string {
  if (s === 'EXTERNAL_ID') return 'İSG-KATİP kimliğiyle eşleşti · doğrulama bekliyor';
  if (s === 'CANDIDATE') return 'MANUEL OLARAK SEÇİLDİ · DOĞRULAMA BEKLİYOR';
  if (s === 'CONFLICT') return 'ÇAKIŞMA · firmaya başka KATİP kimliği bağlı (üzerine yazılmaz)';
  return 'Firma seçilmedi';
}

/** Pilot genel durum etiketi. */
export function pilotStatusLabel(s: KatipManualPilotStatus): string {
  if (s === 'PILOT_DRY_RUN_READY') return 'PİLOT DRY RUN HAZIR';
  if (s === 'FIRMA_ESLESMESI_BEKLIYOR') return 'FİRMA EŞLEŞMESİ BEKLİYOR';
  if (s === 'PILOT_ESLESMESI_CAKISIYOR') return 'PİLOT EŞLEŞMESİ ÇAKIŞIYOR';
  return 'PERSONEL / ATAMA DOĞRULAMASI BEKLİYOR';
}

/** Personel/atama önizleme durumu etiketi. */
export function personStatusLabel(s: string): string {
  if (s === 'MATCH') return 'Eşleşti';
  if (s === 'NEW') return 'Yeni';
  if (s === 'CONFLICT') return 'Çakışma';
  return 'Bulunamadı';
}

/** Durum etiketi CSS sınıfı. */
export function personTagClass(s: string): string {
  if (s === 'MATCH') return 'match';
  if (s === 'NEW') return 'new';
  if (s === 'CONFLICT') return 'conflict';
  return 'not';
}

/** Türkçe karakterleri katlayan, küçük harfli arama anahtarı (unvan substring eşleşmesi). */
const TR_FOLD: Record<string, string> = {
  'İ': 'i', 'I': 'i', 'ı': 'i', 'Ş': 's', 'ş': 's', 'Ğ': 'g', 'ğ': 'g',
  'Ü': 'u', 'ü': 'u', 'Ö': 'o', 'ö': 'o', 'Ç': 'c', 'ç': 'c',
};

export function trSearchKey(value: string): string {
  return value
    .replace(/[İIıŞşĞğÜüÖöÇç]/g, (ch) => TR_FOLD[ch] ?? ch)
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}