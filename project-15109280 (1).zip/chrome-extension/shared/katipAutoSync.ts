/**
 * İSG-KATİP OTOMATİK ÇALIŞAN SAYISI SENKRONİZASYONU — extension tarafı (v1.0.0).
 *
 * NE YAPAR:
 *  - `chrome.alarms` ile periyodik olarak (varsayılan 5 dk) tetiklenir.
 *  - İSG-KATİP sekmesi + İSGDenetim sekmesi AÇIKKEN, İSGDenetim SPA köprüsüne tek bir
 *    "eşleşmiş firmaların çalışan sayısını senkronize et" isteği gönderir.
 *  - Gerçek okuma + yazma İSGDenetim SPA'sınde (Supabase oturumu + RLS) yapılır; extension
 *    yalnızca TETİKLER ve sonuç sayaçlarını saklar.
 *
 * KESİN SINIRLAR:
 *  - YALNIZCA çalışan sayısı güncellenir. Otomatik firma / personel / atama / sözleşme
 *    oluşturulmaz ve eşleştirme yapılmaz.
 *  - Değer değişmemişse yazma YAPILMAZ (SPA tarafında karşılaştırma yapılır).
 *  - KATİP erişilemiyorsa veri UYDURULMAZ; bağlantı durumu dürüstçe gösterilir.
 *  - 🔒 token/cookie/JWT OKUNMAZ, TAŞINMAZ, YAZILMAZ.
 */
import { ISG_DENETIM_HOST, KATIP_HOST } from './katipBridge';

/** Kullanıcı ayarları (chrome.storage.local). */
export interface KatipSettings {
  autoSync: boolean;
  /** Kontrol sıklığı (dakika). */
  intervalMinutes: number;
  /** Güncelleme olduğunda araç çubuğu rozetinde göster. */
  notifications: boolean;
  theme: 'light' | 'dark' | 'system';
}

/** Son işlemler listesi öğesi (PII İÇERMEZ; yalnızca firma unvanı + sayı). */
export interface KatipLogItem {
  kind: 'update' | 'check';
  title: string;
  from: number | null;
  to: number | null;
  at: string;
}

/** Otomatik senkron motorunun son durum özeti (chrome.storage.local). */
export interface KatipStats {
  lastCheck: string | null;
  lastUpdate: string | null;
  matchedFirmCount: number;
  totalKatipEmployees: number;
  /** Son çalışmada kontrol edilen eşleşmiş firma sayısı. */
  checkedFirmCount: number;
  /** Son çalışmada çalışan sayısı gerçekten güncellenen firma sayısı. */
  updatedFirmCount: number;
  /** Son çalışmada değişiklik bulunmayan firma sayısı. */
  unchangedCount: number;
  /** Hiç kontrol edilemeyen (KATİP verisi gelmeyen) eşleşmiş firma sayısı. */
  pendingCheckCount: number;
  log: KatipLogItem[];
  /** Bağlantı durumu (SPA sekmesi + KATİP verisi). */
  connection: { spaOpen: boolean; katipCaptured: boolean };
}

/** SPA `ISG_KATIP_EMP_SYNC_RESULT` içindeki özet (PII İÇERMEZ). */
export interface KatipEmpSyncResult {
  ok: boolean;
  status: 'OK' | 'NO_SCOPE' | 'NOT_CAPTURED' | 'DATA_INCOMPLETE' | 'ERROR';
  checked: number;
  changed: number;
  updated: number;
  matchedFirmCount: number;
  totalKatipEmployees: number;
  unchangedCount: number;
  pendingCheckCount: number;
  recent: Array<{ title: string; from: number | null; to: number }>;
  message?: string;
}

const SETTINGS_KEY = 'isgKatipAutoSyncSettings';
const STATS_KEY = 'isgKatipAutoSyncStats';

/** Kontrol sıklığı seçenekleri (UI select için). */
export const INTERVAL_OPTIONS: Array<{ value: number; label: string }> = [
  { value: 5, label: '5 Dakikada Bir (Önerilen)' },
  { value: 10, label: '10 Dakikada Bir' },
  { value: 15, label: '15 Dakikada Bir' },
  { value: 30, label: '30 Dakikada Bir' },
  { value: 60, label: 'Saatte Bir' },
];

export const DEFAULT_SETTINGS: KatipSettings = {
  autoSync: true,
  intervalMinutes: 5,
  notifications: true,
  theme: 'light',
};

export const DEFAULT_STATS: KatipStats = {
  lastCheck: null,
  lastUpdate: null,
  matchedFirmCount: 0,
  totalKatipEmployees: 0,
  checkedFirmCount: 0,
  updatedFirmCount: 0,
  unchangedCount: 0,
  pendingCheckCount: 0,
  log: [],
  connection: { spaOpen: false, katipCaptured: false },
};

/** Ayar deposunu okur (yoksa varsayılan). */
export async function getSettings(): Promise<KatipSettings> {
  try {
    const raw = await chrome.storage.local.get(SETTINGS_KEY);
    const value = raw?.[SETTINGS_KEY];
    if (!value || typeof value !== 'object') return { ...DEFAULT_SETTINGS };
    return { ...DEFAULT_SETTINGS, ...(value as Partial<KatipSettings>) };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

/** Ayar deposunu günceller ve tam ayarı döner. */
export async function saveSettings(patch: Partial<KatipSettings>): Promise<KatipSettings> {
  const current = await getSettings();
  const next: KatipSettings = { ...current, ...patch };
  try {
    await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  } catch {
    // best-effort
  }
  return next;
}

/** Durum deposunu okur. */
export async function getStats(): Promise<KatipStats> {
  try {
    const raw = await chrome.storage.local.get(STATS_KEY);
    const value = raw?.[STATS_KEY];
    if (!value || typeof value !== 'object') return { ...DEFAULT_STATS };
    return { ...DEFAULT_STATS, ...(value as Partial<KatipStats>) };
  } catch {
    return { ...DEFAULT_STATS };
  }
}

/** Durum deposunu kısmi güncelle ve tam durumu döner. */
export async function patchStats(patch: Partial<KatipStats>): Promise<KatipStats> {
  const current = await getStats();
  const next: KatipStats = { ...current, ...patch };
  try {
    await chrome.storage.local.set({ [STATS_KEY]: next });
  } catch {
    // best-effort
  }
  return next;
}

/** Bir host'a ait açık sekme bulur. */
async function findHostTab(host: string): Promise<chrome.tabs.Tab | null> {
  try {
    const tabs = await chrome.tabs.query({ url: `https://${host}/*` });
    return tabs.find((t) => t.id != null) ?? null;
  } catch {
    return null;
  }
}

/** Sekmeye mesaj gönderir (yanıt gelmezse undefined). */
function sendToTab<T>(tabId: number, message: Record<string, unknown>): Promise<T | undefined> {
  return new Promise((resolve) => {
    try {
      chrome.tabs.sendMessage(tabId, message, (res: T) => {
        void chrome.runtime.lastError;
        resolve(res);
      });
    } catch {
      resolve(undefined);
    }
  });
}

/** Son işlemler listesini (en yeni üstte, en fazla 5) birleştirir. */
function mergeLog(prev: KatipLogItem[], next: KatipLogItem[]): KatipLogItem[] {
  const merged = [...next, ...prev];
  return merged.slice(0, 5);
}

/** Araç çubuğu rozetini güncelleme sayısına göre ayarlar (ek izin gerektirmez). */
function updateBadge(changed: number): void {
  try {
    if (changed > 0) {
      void chrome.action.setBadgeText({ text: String(changed) });
      void chrome.action.setBadgeBackgroundColor({ color: '#e11d2a' });
    } else {
      void chrome.action.setBadgeText({ text: '' });
    }
  } catch {
    // yoksay
  }
}

/**
 * OTOMATİK SENKRONUN TEK ÇALIŞMASI.
 * Yalnızca KATİP + İSGDenetim sekmeleri açıkken anlamlı iş yapar; aksi halde bağlantı durumunu
 * dürüstçe kaydeder (veri UYDURMAZ). Her çağrıda "son kontrol" zamanı güncellenir.
 */
export async function runAutoSyncOnce(reason: 'alarm' | 'manual' | 'startup' | 'popup'): Promise<void> {
  // Alarm tetikledi ama kullanıcı otomatik senkronu kapattıysa ÇALIŞMA (manuel yollar etkilenmez).
  if (reason === 'alarm') {
    const s = await getSettings();
    if (!s.autoSync) return;
  }
  const nowIso = new Date().toISOString();
  const isgTab = await findHostTab(ISG_DENETIM_HOST);
  const katipTab = await findHostTab(KATIP_HOST);

  if (!isgTab?.id) {
    await patchStats({ lastCheck: nowIso, connection: { spaOpen: false, katipCaptured: Boolean(katipTab?.id) } });
    return;
  }
  if (!katipTab?.id) {
    await patchStats({ lastCheck: nowIso, connection: { spaOpen: true, katipCaptured: false } });
    return;
  }

  const response = await sendToTab<{ ok?: boolean; status?: string; sync?: KatipEmpSyncResult }>(
    isgTab.id,
    { type: 'ISG_KATIP_RELAY_EMP_SYNC', reason },
  );

  const sync = response?.sync;
  if (!sync) {
    await patchStats({ lastCheck: nowIso, connection: { spaOpen: true, katipCaptured: true } });
    return;
  }

  const prev = await getStats();
  const at = nowIso;
  const newLog: KatipLogItem[] = [];
  for (const r of sync.recent ?? []) {
    newLog.push({ kind: 'update', title: r.title, from: r.from, to: r.to, at });
  }
  if (sync.ok && sync.changed === 0) {
    newLog.push({ kind: 'check', title: 'KATİP verileri kontrol edildi', from: null, to: null, at });
  }

  const changedCount = sync.updated > 0 ? sync.updated : sync.changed;
  updateBadge(changedCount);

  await patchStats({
    lastCheck: at,
    lastUpdate: changedCount > 0 ? at : prev.lastUpdate,
    matchedFirmCount: sync.matchedFirmCount,
    totalKatipEmployees: sync.totalKatipEmployees,
    checkedFirmCount: sync.checked,
    updatedFirmCount: changedCount,
    unchangedCount: sync.unchangedCount,
    pendingCheckCount: sync.pendingCheckCount,
    log: newLog.length > 0 ? mergeLog(prev.log, newLog) : prev.log,
    connection: { spaOpen: true, katipCaptured: sync.status !== 'NOT_CAPTURED' },
  });
}

/** ISO zaman damgasını "28.09.2026 01:32" biçiminde gösterir. Yoksa "—". */
export function formatStamp(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  try {
    return d.toLocaleString('tr-TR', {
      day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
    });
  } catch {
    return '—';
  }
}

/** Saati "01:31" biçiminde gösterir. */
export function formatTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  try {
    return d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
  } catch {
    return '';
  }
}