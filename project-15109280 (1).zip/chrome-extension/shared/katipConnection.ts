/**
 * FAZ 6L — İSGDenetim KÖPRÜ BAĞLANTI STATE MACHINE (paylaşılan).
 *
 * Popup ve Side Panel AYNI bu canonical connect akışını kullanır (üç ayrı algoritma YOK).
 *
 * KURALLAR:
 *  - NOT_CONNECTED durumunda MANUEL "İSGDenetim'e Bağlan" butonu ASLA disabled OLMAZ.
 *  - Buton yalnızca kullanıcının bastığı MANUEL attempt sürerken geçici disabled olur.
 *  - READY / NOT_CONNECTED / IDLE hallerinde buton HER ZAMAN aktiftir.
 *  - AUTO CONNECT / F5 reconnect / MANUEL — hepsi AYNI `connectToIsgDenetim()`'i çağırır.
 *
 * 🔒 token/cookie/JWT TAŞINMAZ; yeni KATİP isteği ATILMAZ; DB'ye yazılmaz. Sahte READY YOK.
 */
import { el, setText } from './domUtils';
import {
  AUTO_CONNECT_RECONNECTS,
  AUTO_CONNECT_TIMEOUT_MS,
  delayMs,
  ensureDenetimRelay,
  installAndProbeSpaBridge,
  probeSpaRelay,
  resolveIsgDenetimTab,
} from './katipBridge';

export type ConnState = 'IDLE' | 'CONNECTING' | 'READY' | 'NOT_CONNECTED';

let connState: ConnState = 'IDLE';
/** Aynı anda TEK connect attempt çalışsın diye in-flight kilidi (duplicate/sonsuz loop YOK). */
let connectingPromise: Promise<boolean> | null = null;
/** Bu attempt kullanıcının MANUEL bastığı bir attempt mi? */
let manualAttempt = false;

/** State değişince tetiklenen dinleyiciler (ör. Side Panel pilot UI re-render). */
type ConnListener = (state: ConnState, note: string) => void;
const listeners: ConnListener[] = [];

export function onConnStateChange(cb: ConnListener): void {
  listeners.push(cb);
}

export function getConnState(): ConnState {
  return connState;
}

/** İSGDenetim durum noktasını + metnini günceller. */
function setSpaStatus(state: 'ok' | 'warn' | 'idle', text: string): void {
  const dot = el('spa-dot');
  if (dot) dot.className = `dot${state === 'ok' ? ' ok' : state === 'warn' ? ' warn' : ''}`;
  setText('spa-text', text);
}

/** Dry Run akışı gibi dış modüllerin durum noktasını güncellemesi için (state machine dışı). */
export function setSpaStatusExternal(state: 'ok' | 'warn' | 'idle', text: string): void {
  setSpaStatus(state, text);
}

/** Connect butonunun enabled durumunu state'e göre ayarlar.
 * KURAL: 'BAĞLI DEĞİL' / READY / IDLE halinde buton ASLA disabled olmaz. */
export function syncConnectButton(): void {
  const btn = el<HTMLButtonElement>('connect');
  if (!btn) return;
  btn.disabled = connState === 'CONNECTING' && manualAttempt;
}

/** Connection state'i TEK noktadan değiştirir; UI metni + buton durumu tutarlı kalır. */
function setConnState(state: ConnState, note?: string): void {
  connState = state;
  if (state === 'READY') {
    setSpaStatus('ok', 'Bağlantı hazır');
  } else if (state === 'CONNECTING') {
    setSpaStatus('warn', 'Bağlantı kuruluyor…');
  } else if (state === 'NOT_CONNECTED') {
    setSpaStatus('idle', 'İSG-KATİP bağlantısı bekleniyor');
  } else {
    setSpaStatus('idle', 'Bağlantı kontrol ediliyor…');
  }
  syncConnectButton();
  if (note != null) setText('spa-note', note);
  for (const cb of listeners) cb(state, note ?? '');
}

/**
 * TEK CANONICAL CONNECT AKIŞI.
 *   resolveIsgDenetimTab → ensureDenetimRelay → GERÇEK handshake → READY/NOT_CONNECTED.
 * Bounded: ilk deneme en fazla 5 sn + en fazla 2 kontrollü reconnect. SONSUZ loop YOK.
 */
export async function connectToIsgDenetim(): Promise<boolean> {
  if (connectingPromise) return connectingPromise;
  connectingPromise = doConnect().finally(() => {
    connectingPromise = null;
  });
  return connectingPromise;
}

async function doConnect(): Promise<boolean> {
  const isgTab = await resolveIsgDenetimTab().catch(() => null);
  if (!isgTab?.id) {
    setConnState('NOT_CONNECTED', "İSGDenetim sekmesi bulunamadı. 'İSGDenetim'i Aç' ile uygulamayı açın.");
    return false;
  }

  setConnState('CONNECTING', 'İSGDenetim bağlantısı kuruluyor…');

  await ensureDenetimRelay(isgTab.id);
  let alive = await installAndProbeSpaBridge(isgTab.id).catch(() => false);
  const deadline = Date.now() + AUTO_CONNECT_TIMEOUT_MS;
  while (!alive && Date.now() < deadline) {
    // eslint-disable-next-line no-await-in-loop
    await delayMs(350);
    // eslint-disable-next-line no-await-in-loop
    alive = await installAndProbeSpaBridge(isgTab.id).catch(() => false);
    if (!alive) {
      // eslint-disable-next-line no-await-in-loop
      alive = await probeSpaRelay().catch(() => false);
    }
  }

  for (let i = 0; i < AUTO_CONNECT_RECONNECTS && !alive; i += 1) {
    // eslint-disable-next-line no-await-in-loop
    await ensureDenetimRelay(isgTab.id);
    // eslint-disable-next-line no-await-in-loop
    await delayMs(400);
    // eslint-disable-next-line no-await-in-loop
    alive = await installAndProbeSpaBridge(isgTab.id).catch(() => false);
    if (!alive) {
      // eslint-disable-next-line no-await-in-loop
      alive = await probeSpaRelay().catch(() => false);
    }
  }

  if (alive) {
    setConnState('READY', 'Bağlantı hazır. İşyeri aktarımına başlayabilirsiniz.');
  } else {
    setConnState(
      'NOT_CONNECTED',
      "İSGDenetim bağlantısı kurulamadı. İSGDenetim sekmesini açın veya yenileyin (F5), sonra 'İSGDenetim'e Bağlan' ile tekrar deneyin.",
    );
  }
  return alive;
}

/** Popup/Side Panel açılışında OTOMATİK bağlantı (bounded; UI'yı kilitlemez). */
export async function autoConnect(): Promise<void> {
  await connectToIsgDenetim();
}

/**
 * MANUEL "İSGDenetim'e Bağlan" — başarısız auto-connect state'ini temizler ve canonical
 * connect'i yeniden çalıştırır. Buton yalnızca bu attempt sürerken geçici disabled olur.
 */
export async function handleManualConnect(): Promise<void> {
  manualAttempt = true;
  syncConnectButton();
  try {
    await connectToIsgDenetim();
  } finally {
    manualAttempt = false;
    syncConnectButton();
  }
}