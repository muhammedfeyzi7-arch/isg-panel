/**
 * FAZ 6L — Popup / Side Panel ortak DOM yardımcıları.
 *
 * Bu modül SAF DOM erişimi sağlar; hiçbir extension API'si çağırmaz, hiçbir veri
 * okumaz/yazmaz. Aynı id şemasını paylaşan popup ve side panel HTML'leri tarafından
 * kullanılır (eksik elemanlar güvenle yoksayılır).
 */

export function el<T extends HTMLElement>(id: string): T | null {
  return document.getElementById(id) as T | null;
}

export function setText(id: string, value: string): void {
  const node = el(id);
  if (node) node.textContent = value;
}

export function showEl(id: string, show: boolean): void {
  const node = el(id);
  if (!node) return;
  if (show) node.classList.remove('hidden');
  else node.classList.add('hidden');
}

/** Renkli durum noktası + metin göstergesini tek noktadan günceller. */
export function setIndicator(
  dotId: string,
  textId: string,
  state: 'ok' | 'warn' | 'idle',
  text: string,
): void {
  const dot = el(dotId);
  if (dot) dot.className = `dot${state === 'ok' ? ' ok' : state === 'warn' ? ' warn' : ''}`;
  setText(textId, text);
}