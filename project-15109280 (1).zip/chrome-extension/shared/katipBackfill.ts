/**
 * FAZ-K1 — MEVCUT (ZATEN BAĞLI) İŞYERLERİNİN İSG-KATİP BİLGİLERİNİ GÜNCELLEME (Side Panel yüzeyi).
 *
 * NE YAPAR: Daha önce aktarılmış işyerlerinin İSG-KATİP bilgilerini (il / NACE kodu /
 * SGK-DETSİS no / çalışan sayısı) yeniler. Bu iş, mevcut kanonik sunucu-taraflı yazma
 * çekirdeği (`runIsgKatipPilotApply`) üzerinden İSGDenetim tarafında yapılır.
 *
 * KESİN SINIRLAR:
 *  - YENİ firma OLUŞTURULMAZ; hiçbir kayıt SİLİNMEZ (yalnızca zaten bağlı firmalar güncellenir).
 *  - KATİP'e HİÇBİR yazma yapılmaz; ekran sürülmez. Token/cookie/JWT taşınmaz.
 *  - Yalnızca KULLANICININ AÇIK ONAYI sonrası çalışır (iki adımlı: buton → onay).
 *  - Veri seti DATA_COMPLETE değilse güncelleme YAPILMAZ.
 */
import { el, showEl, setText } from './domUtils';
import { connectToIsgDenetim, getConnState } from './katipConnection';
import { readCapturedRows, runViaRelay, type BridgeChannelResult } from './katipBridge';
import type { LooseBackfill } from './katipPilotTypes';

/** Aynı anda TEK güncelleme çalışır (double-click & concurrency kilidi). */
let backfillInFlight = false;

/** Backfill isteğini kanonik KALICI RÖLE üzerinden İSGDenetim SPA'ya iletir. */
async function sendBackfillBridge(payload: {
  hizmetRows: Record<string, unknown>[];
  personelRows: Record<string, unknown>[];
  capturedAt: string;
}): Promise<BridgeChannelResult | undefined> {
  if (getConnState() !== 'READY') {
    await connectToIsgDenetim();
  }
  let relay = await runViaRelay('backfill', payload);
  if (relay) return relay.res;
  // Röle geç yüklenmiş olabilir: bir kez daha bağlanıp tekrar denenir.
  await connectToIsgDenetim();
  relay = await runViaRelay('backfill', payload);
  return relay?.res;
}

function appendRow(host: HTMLElement, label: string, value: string): void {
  const row = document.createElement('div');
  row.className = 'pm-item';
  const l = document.createElement('span');
  l.textContent = label;
  const b = document.createElement('b');
  b.textContent = value;
  row.appendChild(l);
  row.appendChild(b);
  host.appendChild(row);
}

/** Güncelleme sonucunu (sayaçlar + özet) UI'a yansıtır. Fake başarı GÖSTERİLMEZ. */
function renderBackfillResult(result: LooseBackfill | undefined): void {
  const text = el('backfill-result-text');
  const rowsHost = el('backfill-result-rows');
  if (rowsHost) rowsHost.innerHTML = '';
  showEl('backfill-result', true);
  if (!result) {
    if (text) text.textContent = 'Güncelleme sonucu alınamadı.';
    return;
  }
  const total = result.total ?? 0;
  const updated = result.updated ?? 0;
  const failed = result.failed ?? 0;
  const skipped = result.skipped ?? 0;

  if (total === 0) {
    if (text) text.textContent = 'Güncellenecek mevcut işyeri bulunamadı.';
    return;
  }
  if (failed === 0) {
    if (text) text.textContent = `${updated} işyerinin İSG-KATİP bilgileri güncellendi.`;
  } else if (updated > 0) {
    if (text) text.textContent = `${updated} işyeri güncellendi, ${failed} işyeri güncellenemedi.`;
  } else {
    if (text) text.textContent = 'Güncelleme tamamlanamadı — hiçbir değişiklik yapılmadı.';
  }
  if (!rowsHost) return;
  appendRow(rowsHost, 'Güncellenen işyeri', String(updated));
  appendRow(rowsHost, 'Güncellenemeyen', String(failed));
  if (skipped > 0) appendRow(rowsHost, 'Atlanan (aktif değil)', String(skipped));
}

/** Onay sonrası güncellemeyi çalıştırır. READ-ONLY veri okur; yalnızca İSGDenetim'e yazar. */
async function runBackfill(): Promise<void> {
  if (backfillInFlight) return;
  backfillInFlight = true;
  const btn = el<HTMLButtonElement>('backfill-run');
  if (btn) btn.disabled = true;
  showEl('backfill-confirm', false);
  const rowsHost = el('backfill-result-rows');
  if (rowsHost) rowsHost.innerHTML = '';
  showEl('backfill-result', true);
  setText('backfill-result-text', 'Güncelleme çalışıyor…');
  try {
    const rows = await readCapturedRows();
    if (!rows.captured) {
      setText('backfill-result-text', rows.error ?? 'Gerçek İSG-KATİP verisi bulunamadı. İSG-KATİP listesini açıp/yenileyin.');
      return;
    }
    // DATA COMPLETE KAPISI: KATİP sayfaları tamamlanmadan güncelleme denenmez.
    const hizmetState = rows.report?.hizmet.state;
    if (hizmetState && hizmetState !== 'DATA_COMPLETE') {
      setText('backfill-result-text', 'İSG-KATİP verileri henüz tamamlanmadı; güncelleme yapılmadı.');
      return;
    }
    const res = await sendBackfillBridge({
      hizmetRows: rows.hizmetRows,
      personelRows: rows.personelRows,
      capturedAt: new Date().toISOString(),
    });
    if (!res || res.status === 'BRIDGE_NOT_READY') {
      setText('backfill-result-text', res?.error ?? 'İSGDenetim bağlantısı kurulamadı. Lütfen tekrar deneyin.');
      return;
    }
    renderBackfillResult(res.backfill as LooseBackfill | undefined);
  } finally {
    backfillInFlight = false;
    if (btn) btn.disabled = false;
  }
}

/** Backfill paneli etkileşimlerini bağlar (idempotent: bir kez çağrılmalı). */
export function initBackfill(): void {
  el('backfill-run')?.addEventListener('click', () => {
    showEl('backfill-result', false);
    showEl('backfill-confirm', true);
  });
  el('backfill-no')?.addEventListener('click', () => {
    showEl('backfill-confirm', false);
  });
  el('backfill-yes')?.addEventListener('click', () => {
    void runBackfill();
  });
}