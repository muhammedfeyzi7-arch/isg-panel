/**
 * FAZ 6G — ROLE DISCOVERY + DRY RUN RAPORU + IMPORT READINESS AUDIT testleri.
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri YOKTUR. Bu dosya uygulama
 * build'ine (src) dahil DEĞİLDİR; tsconfig kapsamı dışındadır.
 *
 * NOT: Bu testler GERÇEK KATİP ekranını GÖRMEZ; rol enum DEĞERLERİ hâlâ BOŞTUR.
 * Burada yalnızca discovery/rapor/checklist MANTIĞI doğrulanır (uydurma yok).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  buildRoleMappingSkeleton,
  collectRoleDiscovery,
  describeRoleMappingReadiness,
  findUnmappedRoleValues,
} from '../../src/lib/isgKatip/roleDiscovery';
import {
  KATIP_EMPLOYEE_COUNT_POLICY,
  KATIP_HIZMET_CONTRACT_FIELDS,
  assessEmployeeCountPolicy,
  buildDryRunReport,
  buildImportReadinessChecklist,
  diffContractFields,
} from '../../src/lib/isgKatip/readiness';
import { buildMatchPlan } from '../../src/lib/isgKatip/matching';
import { ISG_KATIP_IMPORT_DEFAULT_ENABLED } from '../../src/lib/isgKatip/import';
import type {
  IsgKatipLocalSnapshot,
  IsgKatipSyncPayload,
  KatipMappedAssignment,
  KatipMappedFirm,
  KatipMappedPersonel,
  LocalAssignmentRef,
  LocalFirmaRef,
  LocalPersonelRef,
} from '../../src/lib/isgKatip/types';

/* ---------------------------- MASKELENMİŞ FIXTURE ÜRETİCİLERİ ---------------------------- */

function firm(over: Partial<KatipMappedFirm> = {}): KatipMappedFirm {
  return {
    externalId: 'F-1', name: 'MASKED FIRMA', registrationNo: null, taxNumber: null, sgkSicilNo: null,
    il: 'Ankara', naceKodu: null, tehlikeSinifi: 'Tehlikeli', katipCalisanSayisi: 42, ...over,
  };
}
function personel(over: Partial<KatipMappedPersonel> = {}): KatipMappedPersonel {
  return {
    externalId: 'P-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: '00000000000', personelTuru: 'isg_uzmani',
    uzmanlikSinifi: null, sicilNo: null, sertifikaNo: 'SN-1', email: null, telefon: null, ...over,
  };
}
function atama(over: Partial<KatipMappedAssignment> = {}): KatipMappedAssignment {
  return {
    externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1', role: 'isg_uzmani',
    atamaTuru: 'uzman', gorevlendirmeTuru: 'EXTERNAL', baslangicTarihi: '2026-01-01', bitisTarihi: '2026-12-31', ...over,
  };
}
function localFirma(over: Partial<LocalFirmaRef> = {}): LocalFirmaRef {
  return { id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA', vergiNo: null, il: 'Ankara', isgKatipId: null, ...over };
}
function localPersonel(over: Partial<LocalPersonelRef> = {}): LocalPersonelRef {
  return {
    id: 'lp-1', osgbId: 'osgb-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: '00000000000', email: null, telefon: null,
    source: 'MANUAL', isgKatipId: null, isgKatipSicilNo: null, isgKatipSertifikaNo: null, personelTuru: 'isg_uzmani', ...over,
  };
}
function localAtama(over: Partial<LocalAssignmentRef> = {}): LocalAssignmentRef {
  return {
    id: 'la-1', osgbId: 'osgb-1', firmaId: 'lf-1', personelId: 'lp-1', atamaTuru: 'uzman',
    assignmentRole: 'primary', isgKatipId: null, isActive: true, ...over,
  };
}
function snapshot(over: Partial<IsgKatipLocalSnapshot> = {}): IsgKatipLocalSnapshot {
  return { firms: [], personnel: [], assignments: [], ...over };
}
function payload(over: Partial<IsgKatipSyncPayload> = {}): IsgKatipSyncPayload {
  return {
    source: 'ISG_KATIP', syncedAt: '2026-01-01T00:00:00.000Z', context: { osgbId: 'osgb-1', requestId: 'corr-1' },
    firms: [], personnel: [], assignments: [], ...over,
  };
}
function planOf(p: IsgKatipSyncPayload, s: IsgKatipLocalSnapshot) {
  return buildMatchPlan({ payload: p, snapshot: s, createdAt: '2026-01-01T00:00:00.000Z' });
}

/* ========================================================================== */
/* 1 — ROLE DISCOVERY (SALT GÖZLEM)                                            */
/* ========================================================================== */

test('RD1 — gerçek response alanlarından sertifika/sözleşme tipi değerleri GÖZLEMLENİR', () => {
  const d = collectRoleDiscovery({
    hizmetRows: [
      { gorevlendirilenKisiSertifikaTipi: 'MASKED_SERT_X', sozlesmeTipi: 'MASKED_SOZ_A' },
      { gorevlendirilenKisiSertifikaTipi: 'MASKED_SERT_X', sozlesmeTipi: 'MASKED_SOZ_A' },
      { gorevlendirilenKisiSertifikaTipi: 'MASKED_SERT_Y', sozlesmeTipi: 'MASKED_SOZ_A' },
    ],
    personelRows: [{ sozlesmeYapilanKisiSertifikaTipi: 'MASKED_SERT_X' }],
  });

  assert.equal(d.hizmetRowCount, 3);
  assert.equal(d.sertifikaTipi.length, 2); // X ve Y
  assert.equal(d.sertifikaTipi[0].rawValue, 'MASKED_SERT_X'); // en sık
  assert.equal(d.sertifikaTipi[0].count, 2);
  assert.equal(d.sozlesmeTipi.length, 1);
  assert.equal(d.personelSertifikaTipi.length, 1);
  // Çapraz dağılım 2 kombinasyon (X|A iki kez, Y|A bir kez).
  assert.equal(d.combinations.length, 2);
});

test('RD2 — boş alanlar uyarı üretir, değer UYDURULMAZ', () => {
  const d = collectRoleDiscovery({ hizmetRows: [{ sozlesmeId: 1 }] });
  assert.equal(d.sertifikaTipi.length, 0);
  assert.equal(d.sozlesmeTipi.length, 0);
  assert.ok(d.warnings.length >= 2);
});

test('RD3 — haritalar BOŞ olduğu için tüm gözlemlenen değerler "haritalanmamış"tır', () => {
  const d = collectRoleDiscovery({
    hizmetRows: [{ gorevlendirilenKisiSertifikaTipi: 'MASKED_SERT_X', sozlesmeTipi: 'MASKED_SOZ_A' }],
  });
  const unmapped = findUnmappedRoleValues(d);
  assert.deepEqual(unmapped.sertifikaTipi, ['MASKED_SERT_X']);
  assert.deepEqual(unmapped.sozlesmeTipi, ['MASKED_SOZ_A']);

  const skeleton = buildRoleMappingSkeleton(d);
  assert.deepEqual(Object.keys(skeleton.sertifikaTipi), ['MASKED_SERT_X']);
  assert.equal(skeleton.sertifikaTipi.MASKED_SERT_X, null); // değer UYDURULMADI
});

test('RD4 — roleMapping: FAZ 6K ile en az bir DOĞRULANMIŞ kayıt var; tam değil', () => {
  const r = describeRoleMappingReadiness();
  // FAZ 6K: 20002 (C sınıfı) doğrulandı → sertifika haritaları boş DEĞİL.
  assert.equal(r.sertifikaMapEmpty, false);
  assert.equal(r.sertifikaIdMapEmpty, false);
  assert.equal(r.verifiedCount > 0, true);
  // Sözleşme tipi haritası ROL değil → bilinçli boş; mapping TAM değil.
  assert.equal(r.sozlesmeMapEmpty, true);
  assert.equal(r.complete, false);
});

/* ========================================================================== */
/* 6 — DRY RUN RAPORU (alt sayaçlar ayrıştırılmış)                            */
/* ========================================================================== */

test('DRY1 — plan → dry run raporu: imported/updated PLANNED; applied/importEnabled false', () => {
  const plan = planOf(
    payload({
      firms: [firm({ externalId: 'F-1' }), firm({ externalId: 'F-NEW', name: 'YEPYENI FIRMA' })],
      personnel: [personel({ externalId: 'P-1' })],
      assignments: [atama({ externalId: 'S-1' }), atama({ externalId: 'S-H', role: 'helper' as never })],
    }),
    snapshot({
      firms: [localFirma({ isgKatipId: 'F-1' })],
      personnel: [localPersonel({ isgKatipId: 'P-1' })],
      assignments: [localAtama({ isgKatipId: 'S-1' })],
    }),
  );

  const report = buildDryRunReport({ plan });
  assert.equal(report.dryRun, true);
  assert.equal(report.applied, false);
  assert.equal(report.importEnabled, false);
  assert.equal(report.counts.matched, 3); // F-1 + P-1 + S-1
  assert.equal(report.counts.imported, 1); // planlanan CREATE (F-NEW)
  assert.equal(report.counts.skipped, 1); // helper
  assert.equal(report.unresolved.assignments, 1); // helper SKIPPED
  assert.equal(report.counts.conflicts, 0);
});

test('DRY2 — unresolved breakdown rol/firma/personel/atama ayrı raporlanır', () => {
  const plan = planOf(
    payload({
      firms: [firm({ externalId: 'F-3', name: 'MASKED FIRMA' })], // isim benzerliği → UNRESOLVED
      personnel: [personel({ externalId: null, tcKimlikNo: null })], // kimlik yok → UNRESOLVED
    }),
    snapshot({ firms: [localFirma({ id: 'lf-3', unvan: 'MASKED FIRMA', isgKatipId: null })] }),
  );
  const report = buildDryRunReport({ plan, unresolvedRoles: [{ externalId: 'S-9' } as never] });
  assert.equal(report.unresolved.firms, 1);
  assert.equal(report.unresolved.persons, 1);
  assert.equal(report.unresolved.roles, 1);
  assert.equal(report.byEntity.firms.UNRESOLVED, 1);
});

test('DRY3 — sonlandırılmış sözleşme: DELETE üretilmez, yalnızca NOOP', () => {
  const plan = planOf(
    payload({ assignments: [atama({ externalId: 'S-1', bitisTarihi: '2020-01-01' })] }),
    snapshot({ assignments: [localAtama({ isgKatipId: 'S-1', isActive: false })] }),
  );
  assert.ok(!plan.operations.some((o) => (o.action as string) === 'DELETE'));
  const report = buildDryRunReport({ plan });
  assert.equal(report.applied, false);
});

/* ========================================================================== */
/* 5 — ÇALIŞAN SAYISI POLICY                                                   */
/* ========================================================================== */

test('EMP1 — çalışan sayısı KATİP\'ten YAZILMAZ; merkezî kaynak firmalar.calisan_sayisi', () => {
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.autoWriteToFirmalar, false);
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.runtimeSource, 'firmalar.calisan_sayisi');
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.personnelCountFallback, false);
  const a = assessEmployeeCountPolicy();
  assert.equal(a.autoWrite, false);
  assert.equal(a.blocksLiveImport, true);
});

/* ========================================================================== */
/* 11 — CONTRACT ALAN DOĞRULAMA                                                */
/* ========================================================================== */

test('CONTRACT1 — örneklemde görülen/eksik alanlar dürüst raporlanır (uydurma yok)', () => {
  const rows = [
    {
      bsnInterInscId: 1,
      uniqueId: 'U-1',
      sozlesmeSurecId: 7, // FAZ 6G contract listesinde beklendi
      sozlesmeId: 1001,
      hizmetAlanIsyeriId: 9001,
      hizmetAlanIsyeriCalisanSayisi: 42,
      sozlesmeBaslangicTarihi: '01.01.2026',
    },
  ];
  const { present, missing } = diffContractFields(rows);
  assert.ok(present.includes('sozlesmeSurecId'));
  assert.ok(present.includes('sozlesmeSurecId') && present.includes('hizmetAlanIsyeriCalisanSayisi'));
  assert.ok(missing.includes('hizmetVerenIsyeriId'));
  assert.ok(missing.includes('sozlesmeStatu'));
  // FAZ 6H: 'sozlesmeSurecAdi' eklendi → 21'den 22'ye çıktı.
  assert.equal(KATIP_HIZMET_CONTRACT_FIELDS.length, 22);
  assert.ok(KATIP_HIZMET_CONTRACT_FIELDS.includes('sozlesmeSurecAdi'));
});

/* ========================================================================== */
/* 14 — HAZIRLIK CHECKLIST                                                     */
/* ========================================================================== */

test('READY1 — kanıt yokken hiçbir madde PASS DEĞİL; feature flag OFF kalır', () => {
  const { items, readyForLiveImport } = buildImportReadinessChecklist();
  assert.equal(readyForLiveImport, false);
  const flag = items.find((i) => i.key === 'featureFlag');
  assert.ok(flag && flag.status === 'OFF');
  // Geri kalan tüm maddeler PENDING (kanıt verilmedi).
  assert.equal(items.filter((i) => i.status === 'PENDING').length, items.length - 1);
});

test('READY2 — tüm kriterler karşılanınca (flag OFF kalarak) canlı import HAZIR', () => {
  const all = buildImportReadinessChecklist({
    endpointConfirmed: true,
    requestPayloadConfirmed: true,
    responseSchemaConfirmed: true,
    roleValuesConfirmed: true,
    roleMappingComplete: true,
    firmMappingValidated: true,
    personnelIdentityValidated: true,
    legalAssignmentValidated: true,
    helperExclusionValidated: true,
    conflictSafetyValidated: true,
    idempotencyValidated: true,
    osgbScopeValidated: true,
    terminationLifecycleValidated: true,
    extensionBuildPassed: true,
    automatedTestsPassed: true,
    dryRunAgainstRealKatipPassed: true,
    employeeCountPolicyResolved: true,
    browserE2ePassed: true,
  });
  assert.equal(all.readyForLiveImport, true);
  // 'extension build' henüz koşulamadı → varsayılan bu maddede BLOCKED döner.
  const def = buildImportReadinessChecklist({ extensionBuildPassed: false });
  assert.equal(def.items.find((i) => i.key === 'extensionBuild')?.status, 'BLOCKED');
});

/* ========================================================================== */
/* 12 — FEATURE FLAG VARSAYILANI                                               */
/* ========================================================================== */

test('FLAG — merkezî import feature flag varsayılanı KAPALI', () => {
  assert.equal(ISG_KATIP_IMPORT_DEFAULT_ENABLED, false);
});