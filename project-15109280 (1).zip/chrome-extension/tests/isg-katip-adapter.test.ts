/**
 * FAZ 6B — İSG-KATİP adapter / parse / normalize / idempotency / error testleri.
 *
 * ÇALIŞTIRMA (ayrı bir test runner gerekmez, Node built-in test kullanır):
 *   node --test --experimental-strip-types chrome-extension/tests/
 *   (veya bir TS yükleyici ile: `tsx --test chrome-extension/tests/` / vitest)
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) dahil DEĞİLDİR; tsconfig kapsamı dışındadır.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { HttpIsgKatipAdapter } from '../../src/lib/isgKatip/adapter';
import {
  extractTableData,
  fetchAllOngoingRows,
  IsgKatipEndpointError,
  type KatipPageFetcher,
} from '../../src/lib/isgKatip/endpoints';
import { mapHizmetRow, mapPersonelSozlesmesiRow } from '../../src/lib/isgKatip/mapper';
import { buildSyncPayload } from '../../src/lib/isgKatip/normalize';
import { resolveKatipRole, type KatipRoleResolver } from '../../src/lib/isgKatip/roleMapping';
import { validateIsgKatipPayload } from '../../src/lib/isgKatip/validation';
import type { KatipHizmetSozlesmesiRow } from '../../src/lib/isgKatip/types';

/* -------------------------------------------------------------------------- */
/* MASKELENMİŞ FIXTURE'LAR                                                     */
/* -------------------------------------------------------------------------- */

const HIZMET_UZMAN: KatipHizmetSozlesmesiRow = {
  bsnInterInscId: 1,
  uniqueId: 'U-1',
  sozlesmeId: 1001,
  gorevlendirilenKisiUserId: 501,
  gorevlendirilenKisiTckn: '00000000000',
  gorevlendirilenKisiAdSoyad: 'MASKED AD',
  gorevlendirilenKisiSertifikaTipi: 'TEST_SERT_UZMAN',
  gorevlendirilenKisiSertifikaNo: 'SN-1',
  sozlesmeTipi: 'TEST_SOZ_UZMAN',
  hizmetAlanIsyeriId: 9001,
  hizmetAlanIsyeriUnvani: 'MASKED FIRMA A',
  hizmetAlanIsyeriSgkDetSisNo: '1234567',
  hizmetAlanIsyeriIli: 'Ankara',
  hizmetAlanIsyeriNaceKodu: '01.11.01',
  hizmetAlanIsyeriTehlikeSinifi: 'Tehlikeli',
  hizmetAlanIsyeriCalisanSayisi: 42,
  sozlesmeBaslangicTarihi: '01.01.2026',
  sozlesmeBitisTarihi: '31.12.2026',
  sozlesmeOnayDurumu: 'ONAYLANDI',
  sozlesmeStatu: 'AKTIF',
};

/** Test-only rol çözümleyici: enum değerlerini doğrulanmış gibi taklit EDER (sadece testte). */
const testResolver: KatipRoleResolver = (sert, soz) => {
  const s = String(sert ?? '');
  if (s === 'TEST_SERT_UZMAN') return { role: 'isg_uzmani', source: 'SERTIFIKA_TIPI', rawValue: s };
  if (s === 'TEST_SERT_HEKIM') return { role: 'isyeri_hekimi', source: 'SERTIFIKA_TIPI', rawValue: s };
  if (s === 'TEST_SERT_DSP') return { role: 'dsp', source: 'SERTIFIKA_TIPI', rawValue: s };
  return resolveKatipRole(sert, soz); // default → UNRESOLVED (uydurma yok)
};

/* -------------------------------------------------------------------------- */
/* 1,3,4 — Hizmet sözleşmesi parse + firma/atama external ID mapping           */
/* -------------------------------------------------------------------------- */

test('1/3/4 — hizmet sözleşmesi: firma & yasal atama external ID eşlemesi doğru', () => {
  const mapped = mapHizmetRow(HIZMET_UZMAN, testResolver);
  assert.equal(mapped.firm?.externalId, '9001'); // hizmetAlanIsyeriId → firma
  assert.equal(mapped.assignment?.externalId, '1001'); // sozlesmeId → atama
  assert.equal(mapped.assignment?.firmaExternalId, '9001');
  assert.equal(mapped.assignment?.personelExternalId, '501');
  assert.equal(mapped.assignment?.role, 'isg_uzmani');
  assert.equal(mapped.assignment?.atamaTuru, 'uzman');
  assert.equal(mapped.assignment?.gorevlendirmeTuru, 'EXTERNAL'); // dışa görevlendirme
  assert.equal(mapped.assignment?.baslangicTarihi, '2026-01-01'); // dd.MM.yyyy → ISO
  assert.equal(mapped.assignment?.bitisTarihi, '2026-12-31');
  assert.equal(mapped.personel?.externalId, '501');
  assert.equal(mapped.personel?.ad, 'MASKED');
  assert.equal(mapped.personel?.soyad, 'AD');
  assert.equal(mapped.firm?.katipCalisanSayisi, 42);
});

test('DSP ve hekim rolleri deterministik atama_turu üretir', () => {
  const hekim = mapHizmetRow(
    { ...HIZMET_UZMAN, uniqueId: 'U-H', sozlesmeId: 1002, gorevlendirilenKisiSertifikaTipi: 'TEST_SERT_HEKIM' },
    testResolver,
  );
  const dsp = mapHizmetRow(
    { ...HIZMET_UZMAN, uniqueId: 'U-D', sozlesmeId: 1003, gorevlendirilenKisiSertifikaTipi: 'TEST_SERT_DSP' },
    testResolver,
  );
  assert.equal(hekim.assignment?.atamaTuru, 'hekim');
  assert.equal(dsp.assignment?.atamaTuru, 'hekim');
  assert.equal(dsp.assignment?.role, 'dsp');
});

/* -------------------------------------------------------------------------- */
/* 2 — Personel sözleşmesi AYRI entity (yasal atama DEĞİL)                     */
/* -------------------------------------------------------------------------- */

test('2 — personel sözleşmesi: ayrı entity, INTERNAL görevlendirme, yasal atama üretmez', () => {
  const entity = mapPersonelSozlesmesiRow({
    uniqueId: 'PU-1',
    sozlesmeId: 2002,
    sozlesmeSurecId: 77,
    sozlesmeYapilanKisiUserId: 601,
    sozlesmeYapilanKisiAdSoyad: 'MASKED PAD',
    sozlesmeYapilanKisiSertifikaTipi: 'TEST_SERT_UZMAN',
    isyeriRowId: 9001,
    isyeriUnvani: 'MASKED OSGB',
    sozlesmeBaslangicTarihi: '05.02.2026',
  });
  assert.equal(entity.externalId, '2002');
  assert.equal(entity.gorevlendirmeTuru, 'INTERNAL'); // içe görevlendirme
  assert.equal(entity.baslangicTarihi, '2026-02-05');
  // Bu entity atamalar listesine girmez; sadece ayrı taşınır.
  assert.ok(!('role' in entity));
});

/* -------------------------------------------------------------------------- */
/* 5 — Helper (Saha Uzmanı) YASAL atama olarak üretilmez                       */
/* -------------------------------------------------------------------------- */

test('5 — hiçbir üretilen rol helper değildir; yasal rollerle sınırlıdır', () => {
  const built = buildSyncPayload({
    ctx: { osgbId: 'osgb-1' },
    hizmetRows: [HIZMET_UZMAN],
    resolveRole: testResolver,
  });
  for (const a of built.payload.assignments) {
    assert.notEqual(a.role, 'helper' as never);
    assert.ok(['isg_uzmani', 'isyeri_hekimi', 'dsp'].includes(a.role));
  }
});

/* -------------------------------------------------------------------------- */
/* 6 — Duplicate external ID tekilleştirilir                                  */
/* -------------------------------------------------------------------------- */

test('6 — aynı sozlesmeId iki kez gelirse tek atama üretilir', () => {
  const built = buildSyncPayload({
    ctx: { osgbId: 'osgb-1' },
    hizmetRows: [HIZMET_UZMAN, { ...HIZMET_UZMAN }],
    resolveRole: testResolver,
  });
  assert.equal(built.payload.assignments.length, 1);
  assert.equal(built.payload.firms.length, 1);
});

/* -------------------------------------------------------------------------- */
/* 7 & 10 — Eksik alan / rol çözülemiyor → conflict (unresolved)              */
/* -------------------------------------------------------------------------- */

test('7 — sozlesmeId eksikse atama üretilmez', () => {
  const mapped = mapHizmetRow({ ...HIZMET_UZMAN, sozlesmeId: null }, testResolver);
  assert.equal(mapped.assignment, null);
  assert.equal(mapped.unresolved, null);
});

test('10 — rol enum çözülemezse yasal atama üretilmez, unresolved olur', () => {
  const built = buildSyncPayload({
    ctx: { osgbId: 'osgb-1' },
    hizmetRows: [{ ...HIZMET_UZMAN, gorevlendirilenKisiSertifikaTipi: 'BILINMEYEN', sozlesmeTipi: 'BILINMEYEN' }],
  });
  assert.equal(built.payload.assignments.length, 0);
  assert.equal(built.unresolved.length, 1);
  assert.equal(built.unresolved[0].rawSertifikaTipi, 'BILINMEYEN');
});

/* -------------------------------------------------------------------------- */
/* 8 — Pagination: kısa sayfada durur + idempotent dedupe                     */
/* -------------------------------------------------------------------------- */

test('8 — pagination: pageSize doluyken devam, kısa sayfada durur; tekrar eden kayıt atlanır', async () => {
  const calls: number[] = [];
  const fetchPage: KatipPageFetcher = async (_path, body) => {
    calls.push(body.pageIndex);
    if (body.pageIndex === 0) {
      const rows = Array.from({ length: 100 }, (_, i) => ({ uniqueId: `U-${i}`, sozlesmeId: 1000 + i }));
      rows[0] = { uniqueId: 'U-0', sozlesmeId: 1000 }; // duplicate (99 unique)
      return { tableData: rows };
    }
    if (body.pageIndex === 1) {
      return { tableData: [{ uniqueId: 'X-1', sozlesmeId: 9001 }, { uniqueId: 'X-2', sozlesmeId: 9002 }, { uniqueId: 'X-3', sozlesmeId: 9003 }] };
    }
    throw new Error('fazla sayfa istenmemeli');
  };

  const rows = await fetchAllOngoingRows(fetchPage, '/x');
  assert.deepEqual(calls, [0, 1]); // yalnızca 2 istek
  assert.equal(rows.length, 102); // 99 unique + 3
});

/* -------------------------------------------------------------------------- */
/* 9 — İkinci sync idempotent (aynı payload, aynı sayaçlar)                    */
/* -------------------------------------------------------------------------- */

test('9 — aynı kayıtlar iki kez sync edilirse aynı normalize sonuç üretilir', () => {
  const args = { ctx: { osgbId: 'osgb-1' }, hizmetRows: [HIZMET_UZMAN], resolveRole: testResolver };
  const first = buildSyncPayload({ ...args, syncedAt: '2026-01-01T00:00:00.000Z' });
  const second = buildSyncPayload({ ...args, syncedAt: '2026-01-01T00:00:00.000Z' });
  assert.deepEqual(first.counts, second.counts);
  assert.deepEqual(
    first.payload.assignments.map((a) => a.externalId),
    second.payload.assignments.map((a) => a.externalId),
  );
});

/* -------------------------------------------------------------------------- */
/* Ek: normalize payload doğrulamadan geçer + store'dan bağımsız               */
/* -------------------------------------------------------------------------- */

test('normalize payload, backend sözleşme doğrulamasından geçer', () => {
  const built = buildSyncPayload({
    ctx: { osgbId: 'osgb-1' },
    hizmetRows: [HIZMET_UZMAN],
    resolveRole: testResolver,
  });
  const result = validateIsgKatipPayload(built.payload);
  assert.equal(result.valid, true, JSON.stringify(result.errors));
});

/* -------------------------------------------------------------------------- */
/* 11 & 12 — HTTP error ve geçersiz JSON kontrollü ele alınır                  */
/* -------------------------------------------------------------------------- */

test('11 — HTTP hatası IsgKatipEndpointError(HTTP_ERROR) olarak yüzeye çıkar', async () => {
  const fetchPage: KatipPageFetcher = async () => {
    throw new IsgKatipEndpointError('HTTP_ERROR', 'İSG-KATİP HTTP 500', 500);
  };
  const adapter = new HttpIsgKatipAdapter(fetchPage, { isIsgKatipPage: true, authenticated: true });
  await assert.rejects(
    () => adapter.getHizmetSozlesmeleri(),
    (e: unknown) => e instanceof IsgKatipEndpointError && e.code === 'HTTP_ERROR',
  );
});

test('12 — tableData yoksa TABLE_DATA_NOT_FOUND fırlatılır (sessiz boş liste YOK)', () => {
  assert.throws(() => extractTableData({ foo: 'bar' }), (e: unknown) => e instanceof IsgKatipEndpointError && e.code === 'TABLE_DATA_NOT_FOUND');
  assert.throws(() => extractTableData(null), (e: unknown) => e instanceof IsgKatipEndpointError && e.code === 'TABLE_DATA_NOT_FOUND');
});

test('array response doğrudan tableData olarak kabul edilir', () => {
  const rows = extractTableData([{ uniqueId: 'A' }, { uniqueId: 'B' }]);
  assert.equal(rows.length, 2);
});