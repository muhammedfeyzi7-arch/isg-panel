/**
 * FAZ 1 — KATİP CANONICAL DATA STATE / PAGINATION META / DATA GATE testleri (TEST A–T).
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) dahil DEĞİLDİR.
 *
 * KAPSAM: canonical state türetimi (IDLE/LOADING/DATA_INCOMPLETE/DATA_COMPLETE/ERROR),
 * pagination meta, overall discovery status, DATA_INCOMPLETE gate matrisi, pilot
 * DATA_INCOMPLETE ve employee-count policy. GERÇEK KATİP oturumu GÖRÜLMEZ; KATİP'e
 * İSTEK ATILMAZ. Yalnızca saf mantık doğrulanır.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  buildDatasetReport,
  deriveKatipDataState,
  isDatasetDecisionReady,
  mergeCapturedPages,
  readReportedPagination,
  resolveOverallDiscoveryStatus,
  summarizeCapture,
  type KatipCapturedPageMeta,
} from '../../src/lib/isgKatip/capture';
import { deriveWorksiteGateView, describeWorksiteGateView } from '../../src/lib/isgKatip/dataGate';
import {
  normalizeKatipContractActivity,
  resolveKatipWorksiteActivity,
  summarizeKatipContractActivity,
} from '../../src/lib/isgKatip/contractActivity';
import { resolveKatipPilotCandidate } from '../../src/lib/isgKatip/pilot';
import { KATIP_EMPLOYEE_COUNT_POLICY, assessEmployeeCountPolicy } from '../../src/lib/isgKatip/readiness';
import type { IsgDenetimDbSnapshot } from '../../src/lib/isgKatip/types';

/* ---------------------------- MASKELENMİŞ FIXTURE ---------------------------- */

const HIZMET_PATH = '/be/bsn-inter-instance/hizmet-sozlesmesi-surec-view/ongoing';
const PERSONEL_PATH = '/be/bsn-inter-instance/personel-sozlesmesi-surec/ongoing';

function row(over: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    uniqueId: 'U-1',
    sozlesmeId: 1001,
    gorevlendirilenKisiUserId: 501,
    gorevlendirilenKisiTckn: '00000000000',
    gorevlendirilenKisiAdSoyad: 'MASKED KISI',
    gorevlendirilenKisiSertifikaTipiId: 20002,
    gorevlendirilenKisiSertifikaTipi: 'C Sınıfı İş Güvenliği Uzmanlığı Sertifikası',
    hizmetAlanIsyeriId: 9001,
    hizmetAlanIsyeriUnvani: 'MASKED FIRMA A',
    hizmetAlanIsyeriCalisanSayisi: 3,
    sozlesmeBaslangicTarihi: '01.01.2026',
    sozlesmeBitisTarihi: '31.12.2099',
    sozlesmeOnayDurumu: 'ONAYLANDI',
    sozlesmeStatu: 'AKTIF',
    ...over,
  };
}

function terminatedRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return row({
    sozlesmeId: 2002,
    sozlesmeStatu: 'SONLANDIRILDI',
    sozlesmeSonlandirilmaNedeni: 'Hizmet alan işyeri talebi',
    ...over,
  });
}

function cancelledRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return row({ sozlesmeId: 3003, sozlesmeStatu: 'IPTAL EDILDI', sozlesmeOnayDurumu: null, ...over });
}

function unknownRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return row({
    sozlesmeId: 5005,
    sozlesmeStatu: null,
    sozlesmeStatuId: null,
    sozlesmeOnayDurumu: null,
    sozlesmeOnayDurumuId: null,
    sozlesmeBitisTarihi: null,
    ...over,
  });
}

function page(n: number, offset: number): Record<string, unknown>[] {
  const out: Record<string, unknown>[] = [];
  for (let i = 0; i < n; i += 1) {
    const idx = offset + i;
    out.push(row({ uniqueId: `U-${idx}`, sozlesmeId: 100000 + idx }));
  }
  return out;
}

function meta(pageIndex: number, pageSize: number, rowCount: number): KatipCapturedPageMeta {
  return { pageIndex, pageSize, rowCount, capturedAt: 1000 + pageIndex };
}

function snap(over: Partial<IsgDenetimDbSnapshot> = {}): IsgDenetimDbSnapshot {
  return {
    source: 'ISGDENETIM_DB',
    readOnly: true,
    scopeValidated: true,
    osgbId: 'osgb-1',
    firms: [],
    personnel: [],
    assignments: [],
    ...over,
  };
}

/* ========================================================================== */
/* TEST A — page0=100, incomplete → DATA_INCOMPLETE, active-empty YOK         */
/* ========================================================================== */

test('TEST A — page0=100 incomplete → DATA_INCOMPLETE; "aktif işyeri yok" üretilmez', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: page(100, 0),
    meta: [meta(0, 100, 100)],
    reportedTotal: 380,
  });
  assert.equal(rep.state, 'DATA_INCOMPLETE');
  const gate = deriveWorksiteGateView({
    bridgeOk: true,
    captured: true,
    hizmetState: rep.state,
    activeWorksiteCount: 0,
  });
  assert.equal(gate, 'DATA_INCOMPLETE');
  assert.notEqual(gate, 'NO_ACTIVE_WORKSPACE');
  assert.equal(isDatasetDecisionReady(rep.state), false);
});

/* ========================================================================== */
/* TEST B — tüm pagination tamam → DATA_COMPLETE                              */
/* ========================================================================== */

test('TEST B — tüm sayfalar tamam → DATA_COMPLETE', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: mergeCapturedPages([{ rows: page(100, 0) }, { rows: page(20, 100) }]),
    meta: [meta(0, 100, 100), meta(1, 100, 20)],
    reportedTotal: null,
  });
  assert.equal(rep.state, 'DATA_COMPLETE');
  assert.equal(rep.terminalPageReached, true);
});

/* ========================================================================== */
/* TEST C — aynı page tekrar → duplicate yok                                  */
/* ========================================================================== */

test('TEST C — aynı sayfa iki kez yakalanınca duplicate üretilmez', () => {
  const p = page(50, 0);
  const rows = mergeCapturedPages([{ rows: p }, { rows: p.slice() }]);
  assert.equal(rows.length, 50);
});

/* ========================================================================== */
/* TEST D/E — DATA_COMPLETE/INCOMPLETE + active=0 gate                        */
/* ========================================================================== */

test('TEST D — DATA_COMPLETE + active=0 → NO_ACTIVE_WORKSPACE gösterilebilir', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: page(20, 0),
    meta: [meta(0, 100, 20)],
    reportedTotal: null,
  });
  assert.equal(rep.state, 'DATA_COMPLETE');
  const gate = deriveWorksiteGateView({ bridgeOk: true, captured: true, hizmetState: rep.state, activeWorksiteCount: 0 });
  assert.equal(gate, 'NO_ACTIVE_WORKSPACE');
});

test('TEST E — DATA_INCOMPLETE + active=0 → NO_ACTIVE_WORKSPACE GÖSTERİLEMEZ', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: page(100, 0),
    meta: [meta(0, 100, 100)],
    reportedTotal: 380,
  });
  const gate = deriveWorksiteGateView({ bridgeOk: true, captured: true, hizmetState: rep.state, activeWorksiteCount: 0 });
  assert.equal(gate, 'DATA_INCOMPLETE');
  const msg = describeWorksiteGateView(gate);
  assert.ok(!msg.title.includes('Aktif İşyeri Bulunamadı'));
});

/* ========================================================================== */
/* TEST F/G/H — worksite aktiflik                                              */
/* ========================================================================== */

test('TEST F — aynı worksite: TERMINATED + ACTIVE → ACTIVE / transferable', () => {
  const w = resolveKatipWorksiteActivity([terminatedRow(), row()]);
  assert.equal(w.status, 'ACTIVE');
  const s = summarizeKatipContractActivity([terminatedRow(), row()]);
  assert.equal(s.transferableWorksites, 1);
});

test('TEST G — aynı worksite: TERMINATED + CANCELLED → transferable değil', () => {
  const w = resolveKatipWorksiteActivity([terminatedRow(), cancelledRow()]);
  assert.equal(w.status, 'INACTIVE');
  const s = summarizeKatipContractActivity([terminatedRow(), cancelledRow()]);
  assert.equal(s.transferableWorksites, 0);
});

test('TEST H — UNKNOWN sözleşme ACTIVE kabul edilmez', () => {
  assert.equal(normalizeKatipContractActivity(unknownRow()).status, 'UNKNOWN');
  assert.equal(resolveKatipWorksiteActivity([unknownRow()]).status, 'UNKNOWN');
  assert.equal(summarizeKatipContractActivity([unknownRow()]).transferableWorksites, 0);
});

/* ========================================================================== */
/* TEST I/S — overall discovery status                                        */
/* ========================================================================== */

test('TEST I — hizmet complete + personel incomplete → overall READY OLAMAZ', () => {
  const hizmet = buildDatasetReport(HIZMET_PATH, { rows: page(20, 0), meta: [meta(0, 100, 20)], reportedTotal: null });
  const personel = buildDatasetReport(PERSONEL_PATH, {
    rows: page(6, 0),
    meta: [meta(0, 100, 6)],
    reportedTotal: 400,
  });
  assert.equal(hizmet.state, 'DATA_COMPLETE');
  assert.equal(personel.state, 'DATA_INCOMPLETE');
  assert.equal(resolveOverallDiscoveryStatus(hizmet, personel), 'DATA_INCOMPLETE');
});

test('TEST S — service complete + personnel incomplete → overall incomplete', () => {
  const hizmet = buildDatasetReport(HIZMET_PATH, { rows: page(20, 0), meta: [meta(0, 100, 20)], reportedTotal: null });
  const personel = buildDatasetReport(PERSONEL_PATH, { rows: page(50, 0), meta: [meta(0, 50, 50)], reportedTotal: null });
  assert.equal(personel.state, 'DATA_INCOMPLETE');
  assert.equal(resolveOverallDiscoveryStatus(hizmet, personel), 'DATA_INCOMPLETE');
  assert.equal(resolveOverallDiscoveryStatus(hizmet, hizmet), 'READY');
  assert.equal(resolveOverallDiscoveryStatus(null, null), 'NOT_READY');
});

/* ========================================================================== */
/* TEST J — employee count policy (auto-write YOK)                            */
/* ========================================================================== */

test('TEST J — KATİP employee count merkezi alana YAZILMAZ', () => {
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.autoWriteToFirmalar, false);
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.runtimeSource, 'firmalar.calisan_sayisi');
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.personnelCountFallback, false);
  assert.equal(assessEmployeeCountPolicy().autoWrite, false);
});

/* ========================================================================== */
/* TEST K/L — timeout davranışı                                               */
/* ========================================================================== */

test('TEST K — timeout + partial data → DATA_INCOMPLETE (ASLA DATA_COMPLETE)', () => {
  const st = deriveKatipDataState({ started: true, rowCount: 100, complete: false, timeout: true });
  assert.equal(st, 'DATA_INCOMPLETE');
});

test('TEST L — timeout + veri yok → ERROR', () => {
  const st = deriveKatipDataState({ started: true, rowCount: 0, complete: false, timeout: true });
  assert.equal(st, 'ERROR');
});

/* ========================================================================== */
/* TEST M/N — sayfa sırası + tekrar                                            */
/* ========================================================================== */

test('TEST M — sayfa sırası 0,2,1 → doğru aggregation (receivedPages sıralı)', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: mergeCapturedPages([{ rows: page(100, 0) }, { rows: page(100, 200) }, { rows: page(100, 100) }]),
    meta: [meta(2, 100, 100), meta(0, 100, 100), meta(1, 100, 100)],
    reportedTotal: 380,
  });
  assert.deepEqual(rep.receivedPages, [0, 1, 2]);
  assert.equal(rep.lastPageIndex, 2);
});

test('TEST N — aynı sayfa tekrar yakalanınca duplicate row yok', () => {
  const p = page(50, 0);
  const rows = mergeCapturedPages([{ rows: p }, { rows: p.slice() }]);
  assert.equal(rows.length, 50);
});

/* ========================================================================== */
/* TEST O/P/Q/R — completeness kuralları                                       */
/* ========================================================================== */

test('TEST O — reportedTotal=380, captured=100 → DATA_INCOMPLETE', () => {
  const rep = buildDatasetReport(HIZMET_PATH, { rows: page(100, 0), meta: [meta(0, 100, 100)], reportedTotal: 380 });
  assert.equal(rep.state, 'DATA_INCOMPLETE');
  assert.equal(rep.complete, false);
});

test('TEST P — reportedTotal=380, captured=380 → DATA_COMPLETE', () => {
  const rows = mergeCapturedPages([
    { rows: page(100, 0) },
    { rows: page(100, 100) },
    { rows: page(100, 200) },
    { rows: page(80, 300) },
  ]);
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows,
    meta: [meta(0, 100, 100), meta(1, 100, 100), meta(2, 100, 100), meta(3, 100, 80)],
    reportedTotal: 380,
  });
  assert.equal(rep.state, 'DATA_COMPLETE');
  assert.equal(rep.rowCount, 380);
});

test('TEST Q — metadata yok + 100 kayıt tek başına COMPLETE değildir', () => {
  const rep = buildDatasetReport(HIZMET_PATH, { rows: page(100, 0), meta: [meta(0, 100, 100)], reportedTotal: null });
  assert.equal(rep.state, 'DATA_INCOMPLETE');
});

test('TEST R — terminal sayfa (80 < 100) → DATA_COMPLETE', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: mergeCapturedPages([{ rows: page(100, 0) }, { rows: page(80, 100) }]),
    meta: [meta(0, 100, 100), meta(1, 100, 80)],
    reportedTotal: null,
  });
  assert.equal(rep.state, 'DATA_COMPLETE');
  assert.equal(rep.terminalPageReached, true);
});

/* ========================================================================== */
/* TEST T — bridge yok → gerçek bağlantı state (boş sonuç değil)              */
/* ========================================================================== */

test('TEST T — bridge yok → BRIDGE_ERROR (aktif işyeri yok DEĞİL)', () => {
  const gate = deriveWorksiteGateView({ bridgeOk: false, captured: false, hizmetState: null, activeWorksiteCount: 0 });
  assert.equal(gate, 'BRIDGE_ERROR');
  assert.notEqual(gate, 'NO_ACTIVE_WORKSPACE');
});

/* ========================================================================== */
/* GATE MATRİSİ                                                                */
/* ========================================================================== */

test('GATE — state matrisi tutarlı', () => {
  const base = { captured: true, activeWorksiteCount: 0 };
  assert.equal(deriveWorksiteGateView({ ...base, bridgeOk: true, hizmetState: 'IDLE' }), 'LOADING');
  assert.equal(deriveWorksiteGateView({ ...base, bridgeOk: true, hizmetState: 'LOADING' }), 'LOADING');
  assert.equal(deriveWorksiteGateView({ ...base, bridgeOk: true, hizmetState: 'DATA_INCOMPLETE' }), 'DATA_INCOMPLETE');
  assert.equal(deriveWorksiteGateView({ ...base, bridgeOk: true, hizmetState: 'ERROR' }), 'ERROR');
  assert.equal(deriveWorksiteGateView({ ...base, bridgeOk: true, hizmetState: 'DATA_COMPLETE' }), 'NO_ACTIVE_WORKSPACE');
  assert.equal(
    deriveWorksiteGateView({ bridgeOk: true, captured: true, hizmetState: 'DATA_COMPLETE', activeWorksiteCount: 3 }),
    'READY',
  );
});

/* ========================================================================== */
/* PAGINATION META                                                             */
/* ========================================================================== */

test('PAGINATION — body.totalElements / totalPages güvenli okunur (yoksa null)', () => {
  assert.deepEqual(readReportedPagination({ body: { totalElements: 380, totalPages: 4 } }), {
    totalCount: 380,
    totalPages: 4,
  });
  assert.deepEqual(readReportedPagination({ body: { tableData: [] } }), { totalCount: null, totalPages: null });
  assert.deepEqual(readReportedPagination(null), { totalCount: null, totalPages: null });
});

test('PAGINATION — totalPages biliniyorsa isLastPage/hasNext türetilir', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: page(100, 0),
    meta: [meta(0, 100, 100)],
    reportedTotal: null,
    pagination: { totalCount: 380, totalPages: 4 },
  });
  assert.equal(rep.pagination.totalPages, 4);
  assert.equal(rep.pagination.pageIndex, 0);
  assert.equal(rep.pagination.isLastPage, false);
  assert.equal(rep.pagination.hasNext, true);
});

/* ========================================================================== */
/* PILOT — PILOT_DATA_INCOMPLETE                                               */
/* ========================================================================== */

test('PILOT-1 — aday yok + DATA_INCOMPLETE → PILOT_DATA_INCOMPLETE (NO_SAFE DEĞİL)', () => {
  const res = resolveKatipPilotCandidate({ hizmetRows: [], personelRows: [], snapshot: snap(), datasetComplete: false });
  assert.equal(res.status, 'PILOT_DATA_INCOMPLETE');
});

test('PILOT-2 — aday yok + DATA_COMPLETE → NO_SAFE_PILOT_CANDIDATE (kesin sonuç)', () => {
  const res = resolveKatipPilotCandidate({ hizmetRows: [], personelRows: [], snapshot: snap(), datasetComplete: true });
  assert.equal(res.status, 'NO_SAFE_PILOT_CANDIDATE');
});

test('PILOT-3 — geçerli aday varsa DATA_INCOMPLETE olsa bile aday DÖNER (downgrade yok)', () => {
  const res = resolveKatipPilotCandidate({
    hizmetRows: [row()],
    personelRows: [],
    snapshot: snap({
      firms: [{ id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA A', vergiNo: null, il: null, isgKatipId: '9001', calisanSayisi: 5 }],
    }),
    datasetComplete: false,
  });
  assert.equal(res.status, 'PILOT_CANDIDATE_READY');
});

test('PILOT-4 — datasetComplete verilmezse MEVCUT davranış korunur (geriye uyumlu)', () => {
  const res = resolveKatipPilotCandidate({ hizmetRows: [], personelRows: [], snapshot: snap() });
  assert.equal(res.status, 'NO_SAFE_PILOT_CANDIDATE');
});

/* ========================================================================== */
/* SUMMARIZE CAPTURE REGRESSION (mevcut davranış bozulmadı)                    */
/* ========================================================================== */

test('REGRESSION — summarizeCapture mevcut davranışı korunuyor', () => {
  const s = summarizeCapture(HIZMET_PATH, { rows: page(100, 0), meta: [meta(0, 100, 100)], reportedTotal: null });
  assert.equal(s.complete, false);
  assert.equal(s.terminalPageReached, false);
});