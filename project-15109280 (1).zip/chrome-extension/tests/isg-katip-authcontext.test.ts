/**
 * FAZ 6K — KATİP auth-context (TOKEN CONTEXT REUSE) testleri.
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * AMAÇ: KATİP SPA'nın KENDİ isteğinde kullandığı auth başlığını güvenli biçimde SEÇEN
 * saf mantığı ve MAIN-world hook'un manifest kaydını doğrulamak. Hiçbir gerçek token
 * DEĞERİ kullanılmaz (MASKELİ); token hard-code EDİLMEZ, hiçbir yere yazılmaz.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import {
  KATIP_AUTH_HEADER_CANDIDATES,
  isKatipAuthHeaderName,
  pickAuthHeader,
} from '../../src/lib/isgKatip/authContext';

const MASKED = '***REDACTED***';

/* ========================================================================== */
/* AUTH — auth başlığı seçimi (saf, PII'siz)                                    */
/* ========================================================================== */

test('AUTH1 — "Token" başlık adı küçük/büyük harf duyarsız tanınır', () => {
  assert.equal(isKatipAuthHeaderName('Token'), true);
  assert.equal(isKatipAuthHeaderName('token'), true);
  assert.equal(isKatipAuthHeaderName('TOKEN'), true);
  assert.equal(isKatipAuthHeaderName('Content-Type'), false);
  assert.equal(isKatipAuthHeaderName(''), false);
  assert.equal(isKatipAuthHeaderName(undefined), false);
});

test('AUTH2 — başlık listesinden Token başlığı seçilir (MASKELİ değer)', () => {
  const picked = pickAuthHeader([
    ['Content-Type', 'application/json'],
    ['Token', `Bearer ${MASKED}`],
  ]);
  assert.deepEqual(picked, { name: 'Token', value: `Bearer ${MASKED}` });
});

test('AUTH3 — aday ÖNCELİK sırası korunur: token > authorization', () => {
  const picked = pickAuthHeader([
    ['Authorization', 'Bearer other'],
    ['Token', MASKED],
  ]);
  assert.equal(picked?.name, 'Token');
  assert.equal(picked?.value, MASKED);
});

test('AUTH4 — uygun aday yoksa veya değer boşsa null döner (uydurma yok)', () => {
  assert.equal(pickAuthHeader([['Content-Type', 'application/json']]), null);
  assert.equal(pickAuthHeader([['Token', '']]), null);
  assert.equal(pickAuthHeader([]), null);
  assert.equal(pickAuthHeader(null), null);
  assert.equal(pickAuthHeader(undefined), null);
});

test('AUTH5 — pickAuthHeader SAF: girdiyi değiştirmez, yalnızca {name,value} döndürür', () => {
  const input: Array<[string, string]> = [['Token', MASKED]];
  const before = JSON.stringify(input);
  const picked = pickAuthHeader(input);
  assert.equal(JSON.stringify(input), before, 'girdi değişmemeli');
  assert.deepEqual(Object.keys(picked ?? {}).sort(), ['name', 'value']);
});

test('AUTH6 — sabit ada listesi yalnızca başlık ADLARI taşır; içinde hiçbir token DEĞERİ yoktur', () => {
  // Hard-code yasağı: sabitler yalnızca başlık adı olabilir, uzun/sır benzeri değer olamaz.
  for (const name of KATIP_AUTH_HEADER_CANDIDATES) {
    assert.ok(name.length <= 20, `başlık adı kısa olmalı: ${name}`);
    assert.ok(!name.includes(' '), `başlık adı boşluk içermemeli: ${name}`);
    assert.ok(!/[.]/.test(name), `başlık adı nokta içermemeli: ${name}`);
  }
  assert.ok((KATIP_AUTH_HEADER_CANDIDATES as readonly string[]).includes('token'));
});

/* ========================================================================== */
/* MANIFEST — MAIN-world hook kaydı + izin daraltma                            */
/* ========================================================================== */

test('MANIFEST1 — MAIN-world hook document_start ve izole content script doğru kayıtlı', () => {
  const manifest = JSON.parse(
    readFileSync(new URL('../manifest.json', import.meta.url), 'utf8'),
  ) as {
    host_permissions?: string[];
    content_scripts?: Array<{
      matches?: string[];
      js?: string[];
      run_at?: string;
      world?: string;
    }>;
  };

  const scripts = manifest.content_scripts ?? [];
  const mainHook = scripts.find((s) => s.js?.includes('content/katip-main-hook.js'));
  assert.ok(mainHook, 'MAIN-world hook content_scripts içinde olmalı');
  assert.equal(mainHook?.world, 'MAIN');
  assert.equal(mainHook?.run_at, 'document_start');
  assert.deepEqual(mainHook?.matches, ['https://isgkatip.csgb.gov.tr/*']);

  const isolated = scripts.find((s) => s.js?.includes('content/katip-content.js'));
  assert.ok(isolated, 'izole content script kayıtlı olmalı');
  assert.equal(isolated?.world, undefined);

  assert.deepEqual(manifest.host_permissions, [
    'https://isgkatip.csgb.gov.tr/*',
    'https://app.isgdenetim.com.tr/*',
  ]);

  // FAZ 6J.3 — İSGDenetim iç-rölesi DECLARATIVE content script olarak kayıtlı olmalı.
  const denetimRelay = scripts.find((s) => s.js?.includes('content/denetim-relay.js'));
  assert.ok(denetimRelay, 'İSGDenetim röle content script kayıtlı olmalı');
  assert.deepEqual(denetimRelay?.matches, ['https://app.isgdenetim.com.tr/*']);
});