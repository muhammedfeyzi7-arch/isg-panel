/**
 * FAZ 6J.5 — KATİP AKTİF SÖZLEŞME MOTORU testleri.
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) dahil DEĞİLDİR.
 *
 * KAPSAM: kanonik sözleşme aktiflik çözümü, işyeri gruplama/çözüm, aktarılabilir işyeri
 * hesabı, preview aktif-filtresi ve APPLY gate. GERÇEK KATİP oturumu GÖRÜLMEZ; yalnızca
 * saf karar mantığı doğrulanır.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  normalizeKatipContractActivity,
  resolveKatipWorksiteActivity,
  summarizeKatipContractActivity,
  isKatipContractActive,
} from '../../src/lib/isgKatip/contractActivity';
import {
  listKatipPilotFirmCandidates,
  filterActiveHizmetRowsByWorksite,
  buildKatipManualPilotPreview,
  maskKatipExternalId,
} from '../../src/lib/isgKatip/pilot';
import { buildKatipImportPlan } from '../../src/lib/isgKatip/newFirmaImport';
import type { IsgDenetimDbSnapshot } from '../../src/lib/isgKatip/types';

/* ---------------------------- MASKELENMİŞ FIXTURE ÜRETİCİLERİ ---------------------------- */

/** Maskelenmiş hizmet sözleşmesi satırı. Varsayılan: AKTİF (statü metni "AKTIF"). */
function row(over: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    uniqueId: 'U-1',
    sozlesmeId: 1001,
    gorevlendirilenKisiUserId: 501,
    gorevlendirilenKisiTckn: '00000000000',
    gorevlendirilenKisiAdSoyad: 'MASKED KISI',
    gorevlendirilenKisiSertifikaTipiId: 20002,
    gorevlendirilenKisiSertifikaTipi: 'C Sınıfı İş Güvenliği Uzmanlığı Sertifikası',
    hizmetAlanIsyeriId: 9001,
    hizmetAlanIsyeriUnvani: 'MASKED FIRMA A',
    hizmetAlanIsyeriCalisanSayisi: 3,
    sozlesmeBaslangicTarihi: '01.01.2026',
    sozlesmeBitisTarihi: '31.12.2099',
    sozlesmeOnayDurumu: 'ONAYLANDI',
    sozlesmeStatu: 'AKTIF',
    ...over,
  };
}

/** Sonlandırılmış sözleşme (gerçek sonlandırma nedeni alanı dolu). */
function terminatedRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return row({
    sozlesmeId: 2002,
    sozlesmeStatu: 'SONLANDIRILDI',
    sozlesmeSonlandirilmaNedeni: 'Hizmet alan işyeri talebi',
    ...over,
  });
}

/** İptal edilmiş sözleşme (status metni). */
function cancelledRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return row({ sozlesmeId: 3003, sozlesmeStatu: 'IPTAL EDILDI', sozlesmeOnayDurumu: null, ...over });
}

/** Süresi dolmuş sözleşme (status metni). */
function expiredRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return row({ sozlesmeId: 4004, sozlesmeStatu: 'SURESI DOLDU', sozlesmeOnayDurumu: null, ...over });
}

/** Belirsiz sözleşme (hiçbir belirleyici işaret yok). */
function unknownRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return row({
    sozlesmeId: 5005,
    sozlesmeStatu: null,
    sozlesmeStatuId: null,
    sozlesmeOnayDurumu: null,
    sozlesmeOnayDurumuId: null,
    sozlesmeBitisTarihi: null,
    ...over,
  });
}

function snapshotFirmsEmpty(): IsgDenetimDbSnapshot {
  return {
    source: 'ISGDENETIM_DB',
    readOnly: true,
    scopeValidated: true,
    osgbId: 'osgb-1',
    firms: [],
    personnel: [],
    assignments: [],
  };
}

function snapshot(over: Partial<IsgDenetimDbSnapshot> = {}): IsgDenetimDbSnapshot {
  return { ...snapshotFirmsEmpty(), ...over };
}

/** Minimal manuel önizleme (ACTIVE gate testleri için). */
function preview(over: Record<string, unknown> = {}): any {
  return {
    katipFirmTitle: 'MASKED FIRMA A',
    katipWorksiteIdMasked: maskKatipExternalId('9001'),
    katipCalisanSayisi: 3,
    isgFirmOptions: [],
    personnel: [],
    assignments: [],
    personnelCounts: { match: 0, new: 0, conflict: 0, notFound: 0 },
    assignmentCounts: { match: 0, new: 0, conflict: 0, notFound: 0 },
    dbWrites: 0,
    applied: false,
    importEnabled: false,
    ...over,
  };
}

function planFor(rows: Record<string, unknown>[], activityStatus: 'ACTIVE' | 'TERMINATED' | 'CANCELLED' | 'EXPIRED' | 'PENDING' | 'UNKNOWN') {
  return buildKatipImportPlan({
    preview: preview(),
    firmMode: 'new',
    selectedFirmId: null,
    katipWorksiteId: '9001',
    activityStatus,
  });
}

/* ========================================================================== */
/* KANONİK AKTİFLİK ÇÖZÜMÜ                                                     */
/* ========================================================================== */

test('ACTIVITY-1 — status metni AKTIF olan sözleşme ACTIVE', () => {
  assert.equal(normalizeKatipContractActivity(row()).status, 'ACTIVE');
  assert.equal(isKatipContractActive(row()), true);
});

test('ACTIVITY-2 — sonlandırma nedeni dolu → TERMINATED (status metnine rağmen)', () => {
  const r = row({ sozlesmeSonlandirilmaNedeni: 'Görevlendirilen kişi talebi', sozlesmeStatu: 'AKTIF' });
  assert.equal(normalizeKatipContractActivity(r).status, 'TERMINATED');
});

test('ACTIVITY-3 — iptal status metni → CANCELLED', () => {
  assert.equal(normalizeKatipContractActivity(cancelledRow()).status, 'CANCELLED');
});

test('ACTIVITY-4 — süresi doldu status metni → EXPIRED', () => {
  assert.equal(normalizeKatipContractActivity(expiredRow()).status, 'EXPIRED');
});

test('ACTIVITY-5 — bitiş tarihi geçmiş → EXPIRED (tarih kanıtı)', () => {
  const r = row({ sozlesmeStatu: null, sozlesmeOnayDurumu: null, sozlesmeBitisTarihi: '01.01.2000' });
  assert.equal(normalizeKatipContractActivity(r).status, 'EXPIRED');
});

test('ACTIVITY-6 — belirleyici işaret yok → UNKNOWN (AKTİF KABUL EDİLMEZ)', () => {
  const r = unknownRow();
  assert.equal(normalizeKatipContractActivity(r).status, 'UNKNOWN');
  assert.equal(isKatipContractActive(r), false);
});

/* ========================================================================== */
/* İŞYERİ (WORKSITE) ÇÖZÜMÜ                                                    */
/* ========================================================================== */

test('WORKSITE-1 — aynı işyeri TERMINATED + ACTIVE → ACTIVE (transferable)', () => {
  const w = resolveKatipWorksiteActivity([terminatedRow(), row()]);
  assert.equal(w.status, 'ACTIVE');
  assert.equal(w.active, 1);
  assert.equal(w.terminated, 1);
});

test('WORKSITE-2 — aynı işyeri TERMINATED + CANCELLED → INACTIVE', () => {
  const w = resolveKatipWorksiteActivity([terminatedRow(), cancelledRow()]);
  assert.equal(w.status, 'INACTIVE');
});

test('WORKSITE-3 — aynı işyeri UNKNOWN + TERMINATED → UNKNOWN (güvenli taraf)', () => {
  const w = resolveKatipWorksiteActivity([unknownRow(), terminatedRow()]);
  assert.equal(w.status, 'UNKNOWN');
});

/* ========================================================================== */
/* AKTARILABİLİR İŞYERİ LİSTESİ                                                 */
/* ========================================================================== */

test('LIST-1 — ACTIVE işyeri listede görünür, TERMINATED görünmez', () => {
  const list = listKatipPilotFirmCandidates({
    hizmetRows: [
      row({ hizmetAlanIsyeriId: 9001 }),
      terminatedRow({ hizmetAlanIsyeriId: 9002, hizmetAlanIsyeriUnvani: 'MASKED FIRMA B' }),
    ],
  });
  assert.deepEqual(list.map((c) => c.worksiteId), ['9001']);
  assert.equal(list[0].activityStatus, 'ACTIVE');
});

test('LIST-2 — CANCELLED ve EXPIRED işyerleri listede görünmez', () => {
  const list = listKatipPilotFirmCandidates({
    hizmetRows: [
      cancelledRow({ hizmetAlanIsyeriId: 9101 }),
      expiredRow({ hizmetAlanIsyeriId: 9102 }),
      unknownRow({ hizmetAlanIsyeriId: 9103 }),
    ],
  });
  assert.equal(list.length, 0);
});

test('LIST-3 — 100 ham sözleşme, 0 aktif → 0 aktarılabilir işyeri', () => {
  const rows = Array.from({ length: 100 }, (_, i) =>
    terminatedRow({ hizmetAlanIsyeriId: 7000 + i, uniqueId: `U-${i}`, sozlesmeId: 90000 + i }),
  );
  const list = listKatipPilotFirmCandidates({ hizmetRows: rows });
  assert.equal(list.length, 0);
  const summary = summarizeKatipContractActivity(rows);
  assert.equal(summary.rawContracts, 100);
  assert.equal(summary.transferableWorksites, 0);
  assert.equal(summary.terminated, 100);
});

test('LIST-4 — 100 ham, 5 benzersiz işyeri, 3 aktif → 3 aktarılabilir işyeri', () => {
  const rows: Record<string, unknown>[] = [];
  // Her işyeri için 20 satır (toplam 100).
  for (let w = 0; w < 5; w += 1) {
    for (let k = 0; k < 20; k += 1) {
      const wsId = 8000 + w;
      const uid = `U-${w}-${k}`;
      const sid = 100000 + w * 100 + k;
      if (w < 3) rows.push(row({ hizmetAlanIsyeriId: wsId, uniqueId: uid, sozlesmeId: sid }));
      else rows.push(terminatedRow({ hizmetAlanIsyeriId: wsId, uniqueId: uid, sozlesmeId: sid }));
    }
  }
  const list = listKatipPilotFirmCandidates({ hizmetRows: rows });
  assert.equal(list.length, 3);
  const summary = summarizeKatipContractActivity(rows);
  assert.equal(summary.rawContracts, 100);
  assert.equal(summary.uniqueWorksites, 5);
  assert.equal(summary.transferableWorksites, 3);
});

/* ========================================================================== */
/* PREVIEW — AKTİF FİLTRE + PERSONEL EŞLEŞMESİ                                 */
/* ========================================================================== */

test('PREVIEW-1 — aktif işyeri + personel MATCH → normal önizleme', () => {
  const snap = snapshot({
    personnel: [
      { id: 'lp-1', osgbId: 'osgb-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: '00000000000', isgKatipId: '501' },
    ],
  } as unknown as Partial<IsgDenetimDbSnapshot>);
  const prev = buildKatipManualPilotPreview({ hizmetRows: [row()], snapshot: snap });
  assert.equal(prev.personnel.length, 1);
  assert.equal(prev.personnel[0].status, 'MATCH');
});

test('PREVIEW-2 — TERMINATED sözleşme yasal atama önizlemesine GİRMEZ', () => {
  const activeMasked = maskKatipExternalId('1001');
  const prev = buildKatipManualPilotPreview({
    hizmetRows: [
      terminatedRow({ sozlesmeId: 5005 }),
      row({ sozlesmeId: 1001 }),
    ],
    snapshot: snapshot(),
  });
  // Yalnızca aktif satırın yasal ataması (sozlesmeId=1001) kalır.
  assert.equal(prev.assignments.length, 1);
  assert.equal(prev.assignments[0].sozlesmeIdMasked, activeMasked);
});

test('PREVIEW-3 — filterActiveHizmetRowsByWorksite yalnızca aktif satırları döndürür', () => {
  const rows = [
    terminatedRow({ hizmetAlanIsyeriId: 9001, uniqueId: 'T' }),
    row({ hizmetAlanIsyeriId: 9001, uniqueId: 'A' }),
    row({ hizmetAlanIsyeriId: 9002, uniqueId: 'OTHER' }),
  ];
  const active = filterActiveHizmetRowsByWorksite(rows, '9001');
  assert.equal(active.length, 1);
  assert.equal((active[0] as Record<string, unknown>).uniqueId, 'A');
});

/* ========================================================================== */
/* APPLY GATE                                                                  */
/* ========================================================================== */

test('GATE-1 — ACTIVE işyeri + yeni firma → plan READY (CREATE)', () => {
  const plan = planFor([row()], 'ACTIVE');
  assert.equal(plan.ready, true);
  assert.equal(plan.firmAction, 'CREATE');
  assert.equal(plan.activityStatus, 'ACTIVE');
});

test('GATE-2 — UNKNOWN aktiflik → APPLY DISABLED (plan.ready false)', () => {
  const plan = planFor([unknownRow()], 'UNKNOWN');
  assert.equal(plan.ready, false);
});

test('GATE-3 — TERMINATED aktiflik → APPLY DISABLED (plan.ready false)', () => {
  const plan = planFor([terminatedRow()], 'TERMINATED');
  assert.equal(plan.ready, false);
});

/* ========================================================================== */
/* IDEMPOTENCY (saf, yazma yok)                                                */
/* ========================================================================== */

test('IDEMPOTENCY-1 — aynı girdi iki kez → aynı aktarılabilir işyeri kümesi', () => {
  const rows = [row(), terminatedRow({ hizmetAlanIsyeriId: 9002 })];
  const a = listKatipPilotFirmCandidates({ hizmetRows: rows }).map((c) => c.worksiteId);
  const b = listKatipPilotFirmCandidates({ hizmetRows: rows }).map((c) => c.worksiteId);
  assert.deepEqual(a, b);
});