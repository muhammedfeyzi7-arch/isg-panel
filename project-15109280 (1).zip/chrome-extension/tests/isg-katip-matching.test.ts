/**
 * FAZ 6C — İSG-KATİP EŞLEŞTİRME + CONFLICT-SAFE UPSERT HAZIRLIĞI testleri.
 *
 * ÇALIŞTIRMA (ayrı bir test runner gerekmez, Node built-in test kullanır):
 *   node --test --experimental-strip-types chrome-extension/tests/
 *   (veya bir TS yükleyici ile: `tsx --test chrome-extension/tests/` / vitest)
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) dahil DEĞİLDİR; tsconfig kapsamı dışındadır.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  assessSyncScope,
  buildFirmaSafePatch,
  buildMatchPlan,
  buildPersonelSafePatch,
  matchAssignments,
  matchFirms,
  matchPersonnel,
} from '../../src/lib/isgKatip/matching';
import type {
  IsgKatipLocalSnapshot,
  IsgKatipSyncPayload,
  KatipMappedAssignment,
  KatipMappedFirm,
  KatipMappedPersonel,
  LocalAssignmentRef,
  LocalFirmaRef,
  LocalPersonelRef,
} from '../../src/lib/isgKatip/types';

/* -------------------------------------------------------------------------- */
/* MASKELENMİŞ FIXTURE ÜRETİCİLERİ                                             */
/* -------------------------------------------------------------------------- */

function firm(over: Partial<KatipMappedFirm> = {}): KatipMappedFirm {
  return {
    externalId: 'F-1',
    name: 'MASKED FIRMA',
    registrationNo: null,
    taxNumber: null,
    sgkSicilNo: null,
    il: 'Ankara',
    naceKodu: null,
    tehlikeSinifi: 'Tehlikeli',
    katipCalisanSayisi: 42,
    ...over,
  };
}

function personel(over: Partial<KatipMappedPersonel> = {}): KatipMappedPersonel {
  return {
    externalId: 'P-1',
    ad: 'MASKED',
    soyad: 'KISI',
    tcKimlikNo: '00000000000',
    personelTuru: 'isg_uzmani',
    uzmanlikSinifi: null,
    sicilNo: null,
    sertifikaNo: 'SN-1',
    email: null,
    telefon: null,
    ...over,
  };
}

function atama(over: Partial<KatipMappedAssignment> = {}): KatipMappedAssignment {
  return {
    externalId: 'S-1',
    firmaExternalId: 'F-1',
    personelExternalId: 'P-1',
    role: 'isg_uzmani',
    atamaTuru: 'uzman',
    gorevlendirmeTuru: 'EXTERNAL',
    baslangicTarihi: '2026-01-01',
    bitisTarihi: '2026-12-31',
    ...over,
  };
}

function localFirma(over: Partial<LocalFirmaRef> = {}): LocalFirmaRef {
  return { id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA', vergiNo: null, il: 'Ankara', isgKatipId: null, ...over };
}

function localPersonel(over: Partial<LocalPersonelRef> = {}): LocalPersonelRef {
  return {
    id: 'lp-1',
    osgbId: 'osgb-1',
    ad: 'MASKED',
    soyad: 'KISI',
    tcKimlikNo: null,
    email: null,
    telefon: null,
    source: 'MANUAL',
    isgKatipId: null,
    isgKatipSicilNo: null,
    isgKatipSertifikaNo: null,
    personelTuru: 'isg_uzmani',
    ...over,
  };
}

function localAtama(over: Partial<LocalAssignmentRef> = {}): LocalAssignmentRef {
  return {
    id: 'la-1',
    osgbId: 'osgb-1',
    firmaId: 'lf-1',
    personelId: 'lp-1',
    atamaTuru: 'uzman',
    assignmentRole: 'uzman',
    isgKatipId: null,
    isActive: true,
    ...over,
  };
}

function snapshot(over: Partial<IsgKatipLocalSnapshot> = {}): IsgKatipLocalSnapshot {
  return { firms: [], personnel: [], assignments: [], ...over };
}

function payload(over: Partial<IsgKatipSyncPayload> = {}): IsgKatipSyncPayload {
  return {
    source: 'ISG_KATIP',
    syncedAt: '2026-01-01T00:00:00.000Z',
    context: { osgbId: 'osgb-1', requestId: 'corr-1' },
    firms: [],
    personnel: [],
    assignments: [],
    ...over,
  };
}

/* -------------------------------------------------------------------------- */
/* FİRMA                                                                       */
/* -------------------------------------------------------------------------- */

test('F1 — exact external ID → MATCHED', () => {
  const items = matchFirms([firm({ externalId: 'F-1' })], [localFirma({ isgKatipId: 'F-1' })], null);
  assert.equal(items.length, 1);
  assert.equal(items[0].status, 'MATCHED');
  assert.equal(items[0].matchedBy, 'EXTERNAL_ID');
  assert.equal(items[0].localId, 'lf-1');
});

test('F2 — duplicate external ID → CONFLICT', () => {
  const items = matchFirms(
    [firm({ externalId: 'F-1' })],
    [localFirma({ id: 'a', isgKatipId: 'F-1' }), localFirma({ id: 'b', isgKatipId: 'F-1' })],
    'corr-1',
  );
  assert.equal(items[0].status, 'CONFLICT');
  assert.equal(items[0].conflict?.reason, 'DUPLICATE_EXTERNAL_ID');
});

test('F3 — external ID yok + güvenilir kimlik (vergi no) → MATCHED', () => {
  const items = matchFirms(
    [firm({ externalId: 'F-2', taxNumber: '1111111' })],
    [localFirma({ id: 'lf-9', isgKatipId: null, vergiNo: '1111111' })],
    null,
  );
  assert.equal(items[0].status, 'MATCHED');
  assert.equal(items[0].matchedBy, 'VERGI_NO');
  assert.equal(items[0].localId, 'lf-9');
});

test('F4 — external ID yok + isim benzerliği → UNRESOLVED (otomatik eşleşme YOK)', () => {
  const items = matchFirms(
    [firm({ externalId: 'F-3', name: 'MASKED FIRMA' })],
    [localFirma({ id: 'lf-3', isgKatipId: null, unvan: 'MASKED FIRMA' })],
    null,
  );
  assert.equal(items[0].status, 'UNRESOLVED');
  assert.equal(items[0].conflict?.reason, 'NAME_REQUIRES_REVIEW');
  assert.equal(items[0].localId, null);
});

test('F5 — tamamen yeni firma → NEW (otomatik INSERT YOK)', () => {
  const items = matchFirms([firm({ externalId: 'F-NEW', name: 'YEPYENI' })], [], null);
  assert.equal(items[0].status, 'NEW');
  assert.equal(items[0].requiresReview, true);
});

/* -------------------------------------------------------------------------- */
/* PERSONEL                                                                    */
/* -------------------------------------------------------------------------- */

test('P6 — external ID → MATCHED', () => {
  const items = matchPersonnel([personel({ externalId: 'P-1' })], [localPersonel({ isgKatipId: 'P-1' })], null);
  assert.equal(items[0].status, 'MATCHED');
  assert.equal(items[0].matchedBy, 'EXTERNAL_ID');
});

test('P7 — external ID yok + T.C. → MATCHED', () => {
  const items = matchPersonnel(
    [personel({ externalId: 'P-NEW', tcKimlikNo: '11111111111' })],
    [localPersonel({ id: 'lp-7', isgKatipId: null, tcKimlikNo: '11111111111' })],
    null,
  );
  assert.equal(items[0].status, 'MATCHED');
  assert.equal(items[0].matchedBy, 'TC_KIMLIK_NO');
  assert.equal(items[0].localId, 'lp-7');
});

test('P8 — T.C. aynı fakat external ID farklı → CONFLICT', () => {
  const items = matchPersonnel(
    [personel({ externalId: 'K1', tcKimlikNo: '11111111111' })],
    [localPersonel({ id: 'lp-8', isgKatipId: 'K0', tcKimlikNo: '11111111111' })],
    null,
  );
  assert.equal(items[0].status, 'CONFLICT');
  assert.equal(items[0].conflict?.reason, 'EXTERNAL_ID_TAKEN');
});

test('P9 — external ID aynı fakat T.C. farklı → CONFLICT', () => {
  const items = matchPersonnel(
    [personel({ externalId: 'P-1', tcKimlikNo: '22222222222' })],
    [localPersonel({ id: 'lp-9', isgKatipId: 'P-1', tcKimlikNo: '11111111111' })],
    null,
  );
  assert.equal(items[0].status, 'CONFLICT');
  assert.equal(items[0].conflict?.reason, 'TC_EXTERNAL_MISMATCH');
});

test('P10/P11 — MANUAL personel korunur; KATİP phone/email yoksa yerel değer NULL yapılmaz', () => {
  const local = localPersonel({
    id: 'lp-10',
    isgKatipId: 'P-1',
    source: 'MANUAL',
    email: 'masked@ornek.test',
    telefon: '5000000000',
  });
  const katip = personel({ externalId: 'P-1', email: null, telefon: null });
  const patch = buildPersonelSafePatch(katip, local);
  // Kaynakta olmayan alan NO-OP olmalı.
  assert.ok(!('email' in patch));
  assert.ok(!('telefon' in patch));
  // source hiçbir durumda değiştirilmez.
  assert.ok(!('source' in patch));
});

test('P-ek — external ID yok ve T.C. yok → UNRESOLVED', () => {
  const items = matchPersonnel(
    [personel({ externalId: null, tcKimlikNo: null })],
    [localPersonel()],
    null,
  );
  assert.equal(items[0].status, 'UNRESOLVED');
  assert.equal(items[0].conflict?.reason, 'NO_RELIABLE_IDENTITY');
});

/* -------------------------------------------------------------------------- */
/* ATAMA                                                                       */
/* -------------------------------------------------------------------------- */

test('A12 — sozlesmeId exact → MATCHED', () => {
  const items = matchAssignments([atama({ externalId: 'S-1' })], [localAtama({ isgKatipId: 'S-1' })], null);
  assert.equal(items[0].status, 'MATCHED');
  assert.equal(items[0].localId, 'la-1');
});

test('A13 — yeni sozlesmeId → NEW (pending, INSERT YOK)', () => {
  const items = matchAssignments([atama({ externalId: 'S-NEW' })], [], null);
  assert.equal(items[0].status, 'NEW');
  assert.equal(items[0].requiresReview, true);
});

test('A14 — rol çözülemez/geçersiz → SKIPPED (asla yasal atama üretilmez)', () => {
  const items = matchAssignments([atama({ externalId: 'S-X', role: null as never })], [], null);
  assert.equal(items[0].status, 'SKIPPED');
});

test('A15 — helper (Saha Uzmanı) hiçbir zaman yasal atama olarak üretilmez', () => {
  const items = matchAssignments([atama({ externalId: 'S-H', role: 'helper' as never })], [], null);
  assert.equal(items[0].status, 'SKIPPED');
  assert.ok(items[0].note && items[0].note.includes('helper'));
});

/* -------------------------------------------------------------------------- */
/* PLAN / IDEMPOTENCY                                                          */
/* -------------------------------------------------------------------------- */

test('ID — buildMatchPlan: importEnabled DIAM false; helper sızmaz; idempotent', () => {
  const p = payload({
    firms: [firm({ externalId: 'F-1' })],
    personnel: [personel({ externalId: 'P-1' })],
    assignments: [atama({ externalId: 'S-1' }), atama({ externalId: 'S-H', role: 'helper' as never })],
  });
  const snap = snapshot({
    firms: [localFirma({ isgKatipId: 'F-1' })],
    personnel: [localPersonel({ isgKatipId: 'P-1' })],
    assignments: [localAtama({ isgKatipId: 'S-1' })],
  });

  const first = buildMatchPlan({ payload: p, snapshot: snap, createdAt: '2026-01-01T00:00:00.000Z' });
  const second = buildMatchPlan({ payload: p, snapshot: snap, createdAt: '2026-01-01T00:00:00.000Z' });

  assert.equal(first.importEnabled, false);
  assert.equal(first.counts.matched, 3); // firma + personel + atama
  assert.equal(first.counts.skipped, 1); // helper
  // helper, yasal atama NEW/MATCHED listesine girmez.
  assert.equal(first.assignments.filter((a) => a.status === 'MATCHED' || a.status === 'NEW').length, 1);
  // idempotency: iki çalıştırma aynı planı üretir.
  assert.deepEqual(first.counts, second.counts);
  assert.deepEqual(
    first.assignments.map((a) => a.externalId),
    second.assignments.map((a) => a.externalId),
  );
});

test('ID2 — ikinci sync UNCHANGED: eşleşen kayıtlar için create yok', () => {
  const p = payload({ firms: [firm({ externalId: 'F-1' })] });
  const snap = snapshot({ firms: [localFirma({ isgKatipId: 'F-1' })] });
  const plan = buildMatchPlan({ payload: p, snapshot: snap });
  const firmOps = plan.operations.filter((o) => o.entityType === 'FIRMA');
  assert.equal(firmOps[0].action, 'NOOP'); // zaten bağlı → değişiklik yok, INSERT yok
  assert.ok(!plan.operations.some((o) => o.action === 'CREATE' && o.entityType === 'FIRMA'));
});

/* -------------------------------------------------------------------------- */
/* CONFLICT-SAFE PATCH'LER                                                     */
/* -------------------------------------------------------------------------- */

test('PATCH-F — firma yaması calisan_sayisi YAZMAZ, yalnızca boş isg_katip_id doldurur', () => {
  const patch = buildFirmaSafePatch(firm({ externalId: 'F-1', katipCalisanSayisi: 999 }), localFirma({ isgKatipId: null }));
  assert.deepEqual(patch, { isg_katip_id: 'F-1' });
});

test('PATCH-P — personel yaması yalnızca boş alanları doldurur, mevcutları korur', () => {
  const patch = buildPersonelSafePatch(
    personel({ externalId: 'P-1', tcKimlikNo: '11111111111', email: 'katip@x.test', sertifikaNo: 'SN-K' }),
    localPersonel({ isgKatipId: null, tcKimlikNo: '11111111111', email: 'manual@x.test', isgKatipSertifikaNo: null }),
  );
  assert.equal(patch.isg_katip_id, 'P-1');
  assert.equal(patch.isg_katip_sertifika_no, 'SN-K');
  assert.ok(!('tc_kimlik_no' in patch)); // zaten dolu → dokunulmaz
  assert.ok(!('email' in patch)); // yerel dolu → KATİP ezmez
});

/* -------------------------------------------------------------------------- */
/* SECURITY (scope)                                                            */
/* -------------------------------------------------------------------------- */

test('SEC17 — CROSS_OSGB → reddedilir', () => {
  assert.equal(
    assessSyncScope({ role: 'osgb_admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-2' }),
    'CROSS_OSGB',
  );
});

test('SEC18 — yetkisiz rol (admin/osgb_admin değil) → FORBIDDEN', () => {
  assert.equal(
    assessSyncScope({ role: 'uzman', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-1' }),
    'FORBIDDEN',
  );
});

test('SEC-ek — osgb_admin kendi kapsamı → OK; OSGB kapsamı yok → OSGB_SCOPE_REQUIRED', () => {
  assert.equal(
    assessSyncScope({ role: 'osgb_admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-1' }),
    'OK',
  );
  assert.equal(
    assessSyncScope({ role: 'osgb_admin', callerOsgbId: null, payloadOsgbId: 'osgb-1' }),
    'OSGB_SCOPE_REQUIRED',
  );
});