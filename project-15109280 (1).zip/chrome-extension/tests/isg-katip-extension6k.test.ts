/**
 * FAZ 6K — KATİP Chrome Extension (READ-ONLY discovery) testleri.
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri YOKTUR. Gerçek KATİP ekranına
 * erişilmediği için yalnızca SÖZLEŞME/MANTIK doğrulanır; hiçbir değer uydurulmaz.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  HttpIsgKatipAdapter,
  IsgKatipAdapterNotImplementedError,
  createIsgKatipAdapter,
} from '../../src/lib/isgKatip/adapter';
import {
  KATIP_HIZMET_SOZLESMESI_PATH,
  KATIP_HIZMET_SOZLESMESI_URL,
  KATIP_PERSONEL_SOZLESMESI_PATH,
  KATIP_PAGE_SIZE,
  KATIP_SORT_COLUMN,
  KATIP_SORT_ORDER,
  buildHizmetOngoingRequest,
  buildOngoingRequest,
  extractTableData,
  fetchAllOngoingRows,
  katipFetchEnvelope,
  IsgKatipEndpointError,
  type KatipPageFetcher,
} from '../../src/lib/isgKatip/endpoints';
import { mapHizmetRow } from '../../src/lib/isgKatip/mapper';
import { resolveKatipRole } from '../../src/lib/isgKatip/roleMapping';
import {
  describeRoleMappingReadiness,
  summarizeCertTypeObservations,
} from '../../src/lib/isgKatip/roleDiscovery';
import {
  buildCertTypeDiscoveryLogEntry,
  buildDiscoveryReport,
  containsPii,
} from '../../src/lib/isgKatip/discovery';
import { describeResponseShape, formatResponseShape } from '../../src/lib/isgKatip/responseShape';
import { buildDryRunReport } from '../../src/lib/isgKatip/readiness';
import { buildMatchPlan } from '../../src/lib/isgKatip/matching';
import {
  ISG_KATIP_IMPORT_DEFAULT_ENABLED,
  parseImportFlag,
  resolveEffectiveMode,
} from '../../src/lib/isgKatip/import';
import type { KatipHizmetSozlesmesiRow, IsgKatipSyncPayload } from '../../src/lib/isgKatip/types';

/* ========================================================================== */
/* 1 — ENDPOINT TANIMA                                                         */
/* ========================================================================== */

test('EP1 — doğrulanmış KATİP endpoint yolları tanınıyor', () => {
  assert.equal(KATIP_HIZMET_SOZLESMESI_PATH, '/be/bsn-inter-instance/hizmet-sozlesmesi-surec-view/ongoing');
  assert.equal(KATIP_PERSONEL_SOZLESMESI_PATH, '/be/bsn-inter-instance/personel-sozlesmesi-surec/ongoing');
  assert.equal(KATIP_HIZMET_SOZLESMESI_URL, `https://isgkatip.csgb.gov.tr${KATIP_HIZMET_SOZLESMESI_PATH}`);
});

/* ========================================================================== */
/* 2 — ADAPTER INITIALIZATION                                                  */
/* ========================================================================== */

test('AD1 — taşıma enjekte edilmezse adapter sahte veri ÜRETMEZ, açık hata fırlatır', async () => {
  const adapter = createIsgKatipAdapter();
  await assert.rejects(
    () => adapter.getHizmetSozlesmeleri(),
    (e: unknown) => e instanceof IsgKatipAdapterNotImplementedError,
  );
});

test('AD2 — taşıma enjekte edilirse adapter gerçek GET akışını döndürür', async () => {
  const fetchPage: KatipPageFetcher = async () => ({ tableData: [] });
  const adapter = new HttpIsgKatipAdapter(fetchPage, { isIsgKatipPage: true, authenticated: true });
  assert.deepEqual(await adapter.getHizmetSozlesmeleri(), []);
  assert.deepEqual(await adapter.getPersonelSozlesmeleri(), []);
});

/* ========================================================================== */
/* 3 — RESPONSE PARSING                                                        */
/* ========================================================================== */

test('RESP1 — body.tableData (gerçek kök) ve üst düzey tableData çözülür; eksikse sessiz boş liste YOK', () => {
  // FAZ 6K HOTFIX — doğrulanmış gerçek kök: response.body.tableData
  assert.deepEqual(extractTableData({ body: { tableData: [{ uniqueId: 'A' }] } }).length, 1);
  // Geriye dönük uyumluluk: üst düzey tableData
  assert.deepEqual(extractTableData({ tableData: [{ uniqueId: 'A' }] }).length, 1);
  assert.throws(() => extractTableData({ foo: 1 }), /tableData/);
});

/* ========================================================================== */
/* 3.1 — FAZ 6K HOTFIX: GERÇEK KATİP RESPONSE ROOT (body.tableData)            */
/* ========================================================================== */

/**
 * Gerçek Chrome testinde doğrulanmış KATİP /hizmet-sozlesmesi-surec-view/ongoing
 * response yapısı. Sadece teknik/maskelenmiş alanlar (PII YOK).
 */
const GERCEK_HIZMET_RESPONSE = {
  body: {
    tableData: [
      {
        bsnInterInscId: 8924260,
        uniqueId: '18703743_8924260',
        sozlesmeId: 18703743,
        gorevlendirilenKisiUserId: 14590424,
        gorevlendirilenKisiSertifikaTipiId: 20002,
        gorevlendirilenKisiSertifikaTipi: 'C Sınıfı İş Güvenliği Uzmanlığı Sertifikası',
      },
    ],
  },
};

test('HOTFIX1 — body.tableData başarıyla çıkarılır ve kayıt sayısı 1 olur', () => {
  const rows = extractTableData(GERCEK_HIZMET_RESPONSE);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].sozlesmeId, 18703743);
});

test('HOTFIX2 — çıkarılan kayıt gerçek alanları AYNEN korur (uydurma yok)', () => {
  const [row] = extractTableData(GERCEK_HIZMET_RESPONSE);
  assert.equal(row.bsnInterInscId, 8924260);
  assert.equal(row.uniqueId, '18703743_8924260');
  assert.equal(row.sozlesmeId, 18703743);
  assert.equal(row.gorevlendirilenKisiUserId, 14590424);
  assert.equal(row.gorevlendirilenKisiSertifikaTipiId, 20002);
  assert.equal(row.gorevlendirilenKisiSertifikaTipi, 'C Sınıfı İş Güvenliği Uzmanlığı Sertifikası');
});

test('HOTFIX3 — body.tableData fixture → 20002 → isg_uzmani + uzmanlikSinifi C', () => {
  const [row] = extractTableData(GERCEK_HIZMET_RESPONSE);
  const mapped = mapHizmetRow(row as unknown as KatipHizmetSozlesmesiRow);
  assert.equal(mapped.assignment?.role, 'isg_uzmani');
  assert.equal(mapped.personel?.uzmanlikSinifi, 'C');
});

test('HOTFIX4 — bilinmeyen rol davranışı korunur → UNRESOLVED (uydurma yok)', () => {
  const rows = extractTableData({
    body: {
      tableData: [
        {
          sozlesmeId: 424242,
          gorevlendirilenKisiSertifikaTipiId: 99999,
          gorevlendirilenKisiSertifikaTipi: 'GORULMEMIS SINIF',
        },
      ],
    },
  });
  const mapped = mapHizmetRow(rows[0] as unknown as KatipHizmetSozlesmesiRow);
  assert.equal(mapped.assignment, null);
  assert.equal(mapped.unresolved?.reason, 'ROLE_UNRESOLVED');
});

test('HOTFIX5 — rastgele alan adları (data/content/...) artık KABUL EDİLMEZ', () => {
  assert.throws(
    () => extractTableData({ data: { content: [{ sozlesmeId: 1 }] } }),
    (e: unknown) => e instanceof IsgKatipEndpointError && e.code === 'TABLE_DATA_NOT_FOUND',
  );
});

test('HOTFIX6 — body.tableData PII-güvenli discovery raporuna aynen girer (write yok)', () => {
  const rows = extractTableData(GERCEK_HIZMET_RESPONSE) as unknown as KatipHizmetSozlesmesiRow[];
  const report = buildDiscoveryReport({
    hizmetRows: rows,
    personelRows: [],
    generatedAt: '2026-01-01T00:00:00.000Z',
  });
  assert.equal(report.piiExposed, false);
  assert.equal(containsPii(report), false);
  // no-write garantisi: rapor sadece alan/benzersiz değer/sayı taşır.
  assert.equal(typeof report.generatedAt, 'string');
});

/* ========================================================================== */
/* 3.2 — FAZ 6K RUNTIME DEBUG: ŞEKİL TEŞHİSİ (PII'siz) + RUNTIME FORMATLARI    */
/* ========================================================================== */

test('SHAPE1 — desteklenen gerçek kök (A) şekli: body.tableData dizi olarak görülür', () => {
  const shape = describeResponseShape({ body: { tableData: [{ sozlesmeId: 1 }] } });
  assert.equal(shape.rootType, 'object');
  assert.equal(shape.isArray, false);
  assert.ok(shape.body && shape.body.tableDataIsArray);
  assert.equal(shape.body?.tableDataLength, 1);
  assert.equal(shape.extractable, true);
  assert.equal(shape.jsonStringDetected, false);
});

test('SHAPE2 — JSON STRING (B) runtime değeri: string TESPİT edilir, OTOMATİK PARSE EDİLMEZ (tahmin yok)', () => {
  const jsonString = '{"body":{"tableData":[{"sozlesmeId":1}]}}';
  const shape = describeResponseShape(jsonString);
  assert.equal(shape.rootType, 'string');
  assert.equal(shape.jsonStringDetected, true);
  assert.equal(shape.jsonStringLength, jsonString.length);
  assert.equal(shape.extractable, false);
  // Fallback EKLENMEDİ: JSON string hâlâ TABLE_DATA_NOT_FOUND fırlatır + şekil teşhisi iliştirilir.
  assert.throws(
    () => extractTableData(jsonString),
    (e: unknown) =>
      e instanceof IsgKatipEndpointError &&
      e.code === 'TABLE_DATA_NOT_FOUND' &&
      e.shape?.jsonStringDetected === true,
  );
});

test('SHAPE3 — yabancı sarmalayıcı (C) şekli: alan adları görünür, çıkarılamaz (rastgele fallback YOK)', () => {
  const shape = describeResponseShape({ data: { content: [{ a: 1 }] } });
  assert.deepEqual(shape.rootKeys, ['data']);
  assert.equal(shape.body, null);
  assert.equal(shape.extractable, false);
  assert.throws(
    () => extractTableData({ data: { content: [{ a: 1 }] } }),
    (e: unknown) =>
      e instanceof IsgKatipEndpointError &&
      e.code === 'TABLE_DATA_NOT_FOUND' &&
      e.shape?.rootKeys.includes('data') === true,
  );
});

test('SHAPE4 — taşıma sarmalayıcısı ({ok,status,json}) doğrudan KATİP kökü sayılmaz; şekil gösterir', () => {
  const transportEnvelope = { ok: true, status: 200, json: { body: { tableData: [] } } };
  const shape = describeResponseShape(transportEnvelope);
  assert.deepEqual(shape.rootKeys, ['ok', 'status', 'json']);
  assert.equal(shape.body, null);
  assert.equal(shape.extractable, false);
  assert.ok(formatResponseShape(shape).includes('rootKeys=[ok, status, json]'));
});

test('SHAPE5 — tableData bir dizi DEĞİLSE (object) teşhis bunu açıkça gösterir', () => {
  const shape = describeResponseShape({ body: { tableData: { rows: [] } } });
  assert.ok(shape.body && shape.body.tableDataFound === true);
  assert.equal(shape.body?.tableDataIsArray, false);
  assert.equal(shape.extractable, false);
});

test('DIAG1 — discovery raporu endpoint teşhisini (PII\'siz) taşır', () => {
  const report = buildDiscoveryReport({
    hizmetRows: [],
    personelRows: [],
    diagnostics: [
      { endpoint: KATIP_HIZMET_SOZLESMESI_PATH, label: 'hizmet', ok: true, rowCount: 0 },
      {
        endpoint: KATIP_PERSONEL_SOZLESMESI_PATH,
        label: 'personel',
        ok: false,
        errorCode: 'TABLE_DATA_NOT_FOUND',
        errorMessage: 'şekil: root=object; rootKeys=[data]',
        rowCount: 0,
        shape: describeResponseShape({ data: { content: [] } }),
      },
    ],
    generatedAt: '2026-01-01T00:00:00.000Z',
  });
  assert.equal(report.diagnostics.length, 2);
  assert.equal(report.diagnostics[1].ok, false);
  assert.equal(report.diagnostics[1].shape?.rootKeys[0], 'data');
  assert.equal(report.piiExposed, false);
  assert.equal(containsPii(report), false);
});

/* ========================================================================== */
/* 3.3 — FAZ 6K: REQUEST PAYLOAD (DevTools birebir) + SARMA ZARFI TEŞHİSİ       */
/* ========================================================================== */

test('REQ1 — buildHizmetOngoingRequest DevTools DOĞRULANMIŞ payload ile BİREBİR aynı', () => {
  assert.equal(KATIP_SORT_ORDER, 'DESC');
  assert.equal(KATIP_SORT_COLUMN, 'sozlesmeId');
  assert.equal(KATIP_PAGE_SIZE, 100);
  assert.deepEqual(buildHizmetOngoingRequest(0), {
    sortOrder: 'DESC',
    pageIndex: 0,
    pageSize: 100,
    filters: [],
    sortColumn: 'sozlesmeId',
  });
});

test('REQ2 — sayfa ilerledikçe yalnızca pageIndex değişir; alan adları sabit kalır', () => {
  assert.deepEqual(buildHizmetOngoingRequest(1), {
    sortOrder: 'DESC',
    pageIndex: 1,
    pageSize: 100,
    filters: [],
    sortColumn: 'sozlesmeId',
  });
  assert.deepEqual(Object.keys(buildOngoingRequest(2)).sort(), [
    'filters',
    'pageIndex',
    'pageSize',
    'sortColumn',
    'sortOrder',
  ]);
});

test('REQ3 — personel endpoint gerçek payload\'ı DOĞRULANMADIĞI için aynı kanonik builder kullanılır (uydurma YOK)', () => {
  // Ayrı bir personel payload'ı UYDURULMAZ; kanonik builder aynen kullanılır.
  assert.deepEqual(buildOngoingRequest(0), buildHizmetOngoingRequest(0));
});

test('SHAPE6 — KATİP uygulama-seviyesi sarma zarfı (messages/responseStatus/warnings) PII\'siz teşhis edilir', () => {
  const wrapper = {
    messages: [{ code: 'SESSION_INVALID', message: 'gizli metin' }],
    responseStatus: { code: 'ERROR' },
    warnings: [],
  };
  const shape = describeResponseShape(wrapper, { httpStatus: 200 });
  assert.equal(shape.httpStatus, 200);
  assert.ok(shape.wrapper);
  assert.equal(shape.wrapper?.messagesIsArray, true);
  assert.equal(shape.wrapper?.messagesLength, 1);
  assert.deepEqual(shape.wrapper?.messagesItemKeys, ['code', 'message']);
  assert.ok(shape.wrapper?.messagesItemCodes.includes('code=SESSION_INVALID'));
  assert.deepEqual(shape.wrapper?.responseStatusKeys, ['code']);
  assert.equal(shape.wrapper?.warningsIsArray, true);
  assert.equal(shape.wrapper?.warningsLength, 0);
  assert.equal(shape.extractable, false);
  const text = formatResponseShape(shape);
  assert.ok(text.includes('httpStatus=200'));
  assert.ok(text.includes('messages=dizi(1)'));
  assert.ok(text.includes('responseStatus=keys[code]'));
  assert.ok(text.includes('warnings=dizi(0)'));
  // Serbest mesaj METNİ şekle GİRMEZ (yalnızca güvenli kısa kod).
  assert.ok(!text.includes('gizli metin'));
});

test('WRAP1 — taşıma zarfıyla gelen sarma yanıtı TABLE_DATA_NOT_FOUND + httpStatus + endpoint teşhisi üretir', async () => {
  const wrapper = { messages: [], responseStatus: { code: 'ERROR' }, warnings: [] };
  const fetchPage: KatipPageFetcher = async () => katipFetchEnvelope(200, wrapper);
  await assert.rejects(
    () => fetchAllOngoingRows(fetchPage, KATIP_HIZMET_SOZLESMESI_PATH),
    (e: unknown) => {
      assert.ok(e instanceof IsgKatipEndpointError);
      const err = e as IsgKatipEndpointError;
      assert.equal(err.code, 'TABLE_DATA_NOT_FOUND');
      assert.equal(err.shape?.httpStatus, 200);
      assert.equal(err.shape?.wrapper?.responseStatusKeys[0], 'code');
      assert.equal(err.endpoint, KATIP_HIZMET_SOZLESMESI_PATH);
      assert.ok(err.message.includes('httpStatus=200'));
      assert.ok(err.message.includes(`endpoint: ${KATIP_HIZMET_SOZLESMESI_PATH}`));
      return true;
    },
  );
});

test('WRAP2 — taşıma zarfı çözülür; başarılı body.tableData aynen korunur (status akışı bozmaz)', async () => {
  const fetchPage: KatipPageFetcher = async (_path, body) =>
    body.pageIndex === 0
      ? katipFetchEnvelope(200, { body: { tableData: [{ uniqueId: 'A', sozlesmeId: 1 }] } })
      : katipFetchEnvelope(200, { body: { tableData: [] } });
  const rows = await fetchAllOngoingRows(fetchPage, KATIP_HIZMET_SOZLESMESI_PATH);
  assert.equal(rows.length, 1);
  assert.equal(rows[0].sozlesmeId, 1);
});

test('DIAG2 — personel endpoint teşhisi BAĞIMSIZ raporlanır (hizmet başarısı varsayılmaz)', () => {
  const report = buildDiscoveryReport({
    hizmetRows: [{ sozlesmeId: 1 }],
    personelRows: [],
    diagnostics: [
      { endpoint: KATIP_HIZMET_SOZLESMESI_PATH, label: 'hizmet', ok: true, rowCount: 1 },
      {
        endpoint: KATIP_PERSONEL_SOZLESMESI_PATH,
        label: 'personel',
        ok: false,
        errorCode: 'TABLE_DATA_NOT_FOUND',
        errorMessage: 'şekil: root=object; rootKeys=[messages, responseStatus, warnings]',
        rowCount: 0,
        shape: describeResponseShape({ messages: [], responseStatus: null, warnings: [] }, { httpStatus: 200 }),
      },
    ],
    generatedAt: '2026-01-01T00:00:00.000Z',
  });
  assert.equal(report.diagnostics[0].ok, true);
  assert.equal(report.diagnostics[1].ok, false);
  assert.equal(report.diagnostics[1].shape?.httpStatus, 200);
  assert.equal(report.diagnostics[1].shape?.wrapper?.messagesIsArray, true);
  assert.equal(report.piiExposed, false);
  assert.equal(containsPii(report), false);
});

/* ========================================================================== */
/* 4/5/6/7 — ROL MAPPING (20002 → C → isg_uzmani)                              */
/* ========================================================================== */

const HIZMET_C: KatipHizmetSozlesmesiRow = {
  bsnInterInscId: 1,
  uniqueId: 'U-C-1',
  sozlesmeId: 1001,
  gorevlendirilenKisiUserId: 501,
  gorevlendirilenKisiTckn: '00000000000',
  gorevlendirilenKisiAdSoyad: 'MASKED AD',
  gorevlendirilenKisiSertifikaTipiId: 20002,
  gorevlendirilenKisiSertifikaTipi: 'C Sınıfı İş Güvenliği Uzmanlığı Sertifikası',
  gorevlendirilenKisiSertifikaNo: 'SN-1',
  hizmetAlanIsyeriId: 9001,
  hizmetAlanIsyeriUnvani: 'MASKED FIRMA',
  sozlesmeBaslangicTarihi: '01.01.2026',
};

test('ROLE1 — 20002 (C sınıfı) → isg_uzmani + uzmanlikSinifi C (VERIFIED, gerçek ID)', () => {
  const mapped = mapHizmetRow(HIZMET_C); // Varsayılan (gerçek) resolver.
  assert.equal(mapped.assignment?.role, 'isg_uzmani');
  assert.equal(mapped.assignment?.atamaTuru, 'uzman');
  assert.equal(mapped.personel?.uzmanlikSinifi, 'C');
  assert.equal(mapped.assignment?.externalId, '1001');
});

test('ROLE2 — ID yoksa dahi etiket "C Sınıfı İş Güvenliği Uzmanlığı Sertifikası" çözülür', () => {
  const onlyLabel = { ...HIZMET_C, gorevlendirilenKisiSertifikaTipiId: null };
  assert.equal(mapHizmetRow(onlyLabel).assignment?.role, 'isg_uzmani');
});

test('ROLE3 — bilinmeyen sertifika tipi UYDURULMAZ → UNRESOLVED (atama üretilmez)', () => {
  const unknown = {
    ...HIZMET_C,
    gorevlendirilenKisiSertifikaTipiId: 99999,
    gorevlendirilenKisiSertifikaTipi: 'BILINMEYEN SINIF',
  };
  const mapped = mapHizmetRow(unknown);
  assert.equal(mapped.assignment, null);
  assert.equal(mapped.unresolved?.reason, 'ROLE_UNRESOLVED');
});

test('ROLE4 — sözleşme tipi ("Kısmi Süreli") ROL değildir → UNRESOLVED', () => {
  const res = resolveKatipRole(null, 'Kısmi Süreli');
  assert.equal(res.role, null);
  assert.equal(res.source, 'UNRESOLVED');
});

test('ROLE5 — sertifika tipi enum gözlemi VERIFIED/UNRESOLVED üretir', () => {
  const obs = summarizeCertTypeObservations({
    hizmetRows: [
      HIZMET_C,
      { gorevlendirilenKisiSertifikaTipiId: 99999, gorevlendirilenKisiSertifikaTipi: 'BILINMEYEN' },
    ],
  });
  const verified = obs.find((o) => o.id === 20002);
  assert.ok(verified && verified.mappingStatus === 'VERIFIED' && verified.role === 'isg_uzmani');
  const unknown = obs.find((o) => o.id === 99999);
  assert.ok(unknown && unknown.mappingStatus === 'UNRESOLVED' && unknown.role === null);
});

test('ROLE6 — readiness: en az bir doğrulanmış kayıt var; sözleşme haritası bilinçli boş', () => {
  const r = describeRoleMappingReadiness();
  assert.equal(r.verifiedCount, 2); // ID haritası (20002) + etiket haritası
  assert.equal(r.sertifikaMapEmpty, false);
  assert.equal(r.sertifikaIdMapEmpty, false);
  assert.equal(r.sozlesmeMapEmpty, true);
  assert.equal(r.complete, false); // tüm enum değerleri doğrulanana kadar tam sayılmaz
});

/* ========================================================================== */
/* 5.1 / 12 — PII GÜVENLİĞİ                                                    */
/* ========================================================================== */

test('PII1 — discovery raporu PII İÇERMEZ (TC/ad soyad değeri taşınmaz)', () => {
  const report = buildDiscoveryReport({
    hizmetRows: [HIZMET_C],
    personelRows: [],
    generatedAt: '2026-01-01T00:00:00.000Z',
  });
  assert.equal(report.piiExposed, false);
  assert.ok(report.redactedFields.includes('gorevlendirilenKisiTckn'));
  assert.ok(report.redactedFields.includes('gorevlendirilenKisiAdSoyad'));

  const serialized = JSON.stringify(report);
  assert.ok(!serialized.includes('00000000000'), 'TC değeri rapora sızmamalı');
  assert.ok(!serialized.includes('MASKED AD'), 'ad/soyad değeri rapora sızmamalı');
  assert.equal(containsPii(report), false);
});

test('PII2 — sertifika tipi log kaydı yalnızca id/label/mappingStatus taşır', () => {
  const roles = summarizeCertTypeObservations({ hizmetRows: [HIZMET_C] });
  const entry = buildCertTypeDiscoveryLogEntry(roles);
  assert.equal(entry.source, 'ISG_KATIP');
  assert.equal(entry.mode, 'DISCOVERY');
  assert.equal(entry.uniqueValues[0].id, 20002);
  assert.equal(entry.uniqueValues[0].mappingStatus, 'VERIFIED');
  assert.equal(containsPii(entry), false);
});

/* ========================================================================== */
/* 11 — NO-WRITE GARANTİSİ + FEATURE FLAG OFF                                  */
/* ========================================================================== */

test('WRITE1 — dry run raporu: applied=false, importEnabled=false', () => {
  const payload: IsgKatipSyncPayload = {
    source: 'ISG_KATIP',
    syncedAt: '2026-01-01T00:00:00.000Z',
    context: { osgbId: 'osgb-1', requestId: 'corr-1' },
    firms: [{ externalId: 'F-1', name: 'MASKED FIRMA', registrationNo: null, taxNumber: null, sgkSicilNo: null }],
    personnel: [],
    assignments: [],
  };
  const plan = buildMatchPlan({
    payload,
    snapshot: { firms: [], personnel: [], assignments: [] },
    createdAt: '2026-01-01T00:00:00.000Z',
  });
  const report = buildDryRunReport({ plan });
  assert.equal(report.dryRun, true);
  assert.equal(report.applied, false);
  assert.equal(report.importEnabled, false);
});

test('FLAG1 — merkezî import flag varsayılanı KAPALI; gate kapalıyken mod DRY_RUN', () => {
  assert.equal(ISG_KATIP_IMPORT_DEFAULT_ENABLED, false);
  assert.equal(parseImportFlag(undefined), false);
  assert.equal(parseImportFlag('false'), false);
  assert.equal(resolveEffectiveMode('FULL_CONTROLLED_IMPORT', false), 'DRY_RUN');
});