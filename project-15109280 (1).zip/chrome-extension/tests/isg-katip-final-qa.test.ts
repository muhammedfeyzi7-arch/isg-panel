/**
 * FAZ 4/4 — KATİP FINAL KAPANIŞ QA testleri (TEST X–AO).
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ DÜRÜST KAPSAM SINIRI:
 *   Bu dosya YALNIZCA saf/kural (pure logic) katmanını doğrular. Şunlar GERÇEK ÇALIŞMA
 *   ORTAMI gerektirir ve burada KOŞULMAZ — dolayısıyla PASS SAYILMAZ:
 *     - Gerçek Chrome E2E (KATİP login + pagination capture + DATA_COMPLETE)
 *     - Atomik RPC `isg_katip_apply_pilot` (WRITE rollback / second-run NOOP/LINK)
 *     - Fresh RLS VERIFY (`verifyPilotApply` → `fetchIsgDenetimDbSnapshot`)
 *   Bu testler; yukarıdaki gerçek akışları YÖNETEN saf KARAR kurallarını doğrular.
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC/ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) DAHİL DEĞİLDİR. KATİP'e İSTEK ATILMAZ; DB'YE YAZILMAZ.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  buildDatasetReport,
  mergeCapturedPages,
  resolveOverallDiscoveryStatus,
  type KatipCapturedPageMeta,
} from '../../src/lib/isgKatip/capture';
import { deriveWorksiteGateView } from '../../src/lib/isgKatip/dataGate';
import {
  normalizeKatipContractActivity,
  resolveKatipWorksiteActivity,
} from '../../src/lib/isgKatip/contractActivity';
import { resolveKatipPilotCandidate } from '../../src/lib/isgKatip/pilot';
import {
  buildPilotLifecycleItems,
  evaluatePilotApplyGate,
  scopeLifecycleItems,
} from '../../src/lib/isgKatip/pilotLifecycle';
import { KATIP_EMPLOYEE_COUNT_POLICY } from '../../src/lib/isgKatip/readiness';
import { assessSyncScope, matchAssignments } from '../../src/lib/isgKatip/matching';
import { assessOsgbKatipScope, resolveAtamaKatipStatus } from '../../src/lib/isgKatip/osgbIntegration';
import type { IsgDenetimDbSnapshot } from '../../src/lib/isgKatip/types';

/* ---------------------------- MASKELENMİŞ FIXTURE ---------------------------- */

const HIZMET_PATH = '/be/bsn-inter-instance/hizmet-sozlesmesi-surec-view/ongoing';
const PERSONEL_PATH = '/be/bsn-inter-instance/personel-sozlesmesi-surec/ongoing';

function hizmetRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    uniqueId: 'U-1',
    sozlesmeId: 1001,
    gorevlendirilenKisiUserId: 501,
    gorevlendirilenKisiTckn: '11111111111',
    gorevlendirilenKisiAdSoyad: 'MASKED KISI',
    gorevlendirilenKisiSertifikaTipiId: 20002,
    hizmetAlanIsyeriId: 9001,
    hizmetAlanIsyeriUnvani: 'MASKED FIRMA A',
    hizmetAlanIsyeriCalisanSayisi: 20,
    sozlesmeBaslangicTarihi: '01.01.2026',
    sozlesmeBitisTarihi: '31.12.2099',
    sozlesmeOnayDurumu: 'ONAYLANDI',
    sozlesmeStatu: 'AKTIF',
    ...over,
  };
}

function terminatedRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return hizmetRow({
    sozlesmeId: 2002,
    sozlesmeStatu: 'SONLANDIRILDI',
    sozlesmeSonlandirilmaNedeni: 'Hizmet alan işyeri talebi',
    ...over,
  });
}

function unknownRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return hizmetRow({
    sozlesmeId: 5005,
    sozlesmeStatu: null,
    sozlesmeStatuId: null,
    sozlesmeOnayDurumu: null,
    sozlesmeOnayDurumuId: null,
    sozlesmeBitisTarihi: null,
    ...over,
  });
}

function page(n: number, offset: number): Record<string, unknown>[] {
  const out: Record<string, unknown>[] = [];
  for (let i = 0; i < n; i += 1) {
    const idx = offset + i;
    out.push(hizmetRow({ uniqueId: `U-${idx}`, sozlesmeId: 100000 + idx }));
  }
  return out;
}

function meta(pageIndex: number, pageSize: number, rowCount: number): KatipCapturedPageMeta {
  return { pageIndex, pageSize, rowCount, capturedAt: 1000 + pageIndex };
}

function snap(over: Partial<IsgDenetimDbSnapshot> = {}): IsgDenetimDbSnapshot {
  return {
    source: 'ISGDENETIM_DB',
    readOnly: true,
    scopeValidated: true,
    osgbId: 'osgb-1',
    firms: [],
    personnel: [],
    assignments: [],
    ...over,
  };
}

/* ========================================================================== */
/* TEST X — page 0 → DATA_INCOMPLETE                                          */
/* ========================================================================== */

test('TEST X — ilk sayfa (100, reportedTotal=380) → DATA_INCOMPLETE', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: page(100, 0),
    meta: [meta(0, 100, 100)],
    reportedTotal: 380,
  });
  assert.equal(rep.state, 'DATA_INCOMPLETE');
});

/* ========================================================================== */
/* TEST Y — son sayfa → DATA_COMPLETE                                         */
/* ========================================================================== */

test('TEST Y — terminal sayfa (80 < 100) → DATA_COMPLETE', () => {
  const rep = buildDatasetReport(HIZMET_PATH, {
    rows: mergeCapturedPages([{ rows: page(100, 0) }, { rows: page(80, 100) }]),
    meta: [meta(0, 100, 100), meta(1, 100, 80)],
    reportedTotal: null,
  });
  assert.equal(rep.state, 'DATA_COMPLETE');
  assert.equal(rep.terminalPageReached, true);
});

/* ========================================================================== */
/* TEST Z / AA — pilot adayı (ACTIVE=0 vs ACTIVE>0)                            */
/* ========================================================================== */

test('TEST Z — ACTIVE=0 + DATA_COMPLETE → pilot adayı YOK', () => {
  const res = resolveKatipPilotCandidate({
    hizmetRows: [terminatedRow()],
    personelRows: [],
    snapshot: snap(),
    datasetComplete: true,
  });
  assert.equal(res.status, 'NO_SAFE_PILOT_CANDIDATE');
});

test('TEST AA — ACTIVE>0 + DATA_COMPLETE → pilot adayı READY', () => {
  const res = resolveKatipPilotCandidate({
    hizmetRows: [hizmetRow()],
    personelRows: [],
    snapshot: snap({
      firms: [{ id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA A', vergiNo: null, il: null, isgKatipId: '9001', calisanSayisi: 5 }],
    }),
    datasetComplete: true,
  });
  assert.equal(res.status, 'PILOT_CANDIDATE_READY');
});

/* ========================================================================== */
/* TEST AB/AC/AD — WRITE rollback / fresh VERIFY / second-run (RUNTIME ONLY)   */
/*                                                                            */
/* Bu üç senaryonun TRANSACTION tarafı gerçek atomik RPC + fresh RLS gerektirir */
/* ve bu ortamda KOŞULMAZ. Aşağıda yalnızca bunları YÖNETEN saf kapı doğrulanır. */
/* ========================================================================== */

test('TEST AB (gate) — çakışma varken apply kapısı BLOKLAR (transaction RPC koşulmadı)', () => {
  const g = evaluatePilotApplyGate({
    datasetComplete: true,
    worksiteActive: true,
    personnelBlocking: true,
  });
  assert.equal(g.allowed, false);
  // NOT: Gerçek ROLLBACK davranışı atomik RPC içindedir (relation çözülemezse raise exception).
  // Bu ortamda RPC KOŞULMADI → gerçek rollback kanıtı yok.
});

test('TEST AC (gate) — ALLOW yalnızca veri+aktiflik+çakışmasızlık birlikte sağlanınca', () => {
  const g = evaluatePilotApplyGate({
    datasetComplete: true,
    worksiteActive: true,
    firmBlocking: false,
    personnelBlocking: false,
    assignmentBlocking: false,
    orphanAssignments: 0,
  });
  assert.equal(g.allowed, true);
  // NOT: Fresh RLS VERIFY (verifyPilotApply) bu ortamda KOŞULMADI.
});

test('TEST AD (gate) — ikinci çalıştırma NOOP/LINK bekler; saf tarafta idempotent dedupe doğrulanır', () => {
  // Aynı sozlesmeId iki kez → tek kayıt (dedupe). Gerçek NOOP/LINK atomik RPC + unique index işidir.
  const rows = mergeCapturedPages([{ rows: [hizmetRow()] }, { rows: [hizmetRow()] }]);
  assert.equal(rows.length, 1);
});

/* ========================================================================== */
/* TEST AE — terminated → assignment DEACTIVATE (DELETE YOK)                  */
/* ========================================================================== */

test('TEST AE — sonlandırılmış sözleşme → lifecycle DEACTIVATE (fiziksel silme YOK)', () => {
  const items = buildPilotLifecycleItems([hizmetRow(), terminatedRow()], '9001');
  assert.equal(items.length, 1);
  assert.equal(items[0].action, 'DEACTIVATE');
  assert.equal(items[0].externalId, '2002');
});

/* ========================================================================== */
/* TEST AF — aynı worksite başka ACTIVE → assignment aktif KALIR               */
/* ========================================================================== */

test('TEST AF — aynı worksite: TERMINATED + ACTIVE → aktiflik korunur (Aktif sozlesme pasifleştirilmez)', () => {
  const rows = [terminatedRow(), hizmetRow()];
  assert.equal(resolveKatipWorksiteActivity(rows).status, 'ACTIVE');
  const items = buildPilotLifecycleItems(rows, '9001');
  // Yalnızca sonlandırılmış olan pasifleştirilir; aktif sözleşme lifecycle'a GİRMEZ.
  assert.equal(items.length, 1);
  assert.equal(items[0].externalId, '2002');
});

/* ========================================================================== */
/* TEST AG — employee count merkezi alana YAZILMAZ                            */
/* ========================================================================== */

test('TEST AG — KATİP çalışan sayısı merkezi firmalar.calisan_sayisi alanını DEĞİŞTİRMEZ', () => {
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.autoWriteToFirmalar, false);
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.runtimeSource, 'firmalar.calisan_sayisi');
});

/* ========================================================================== */
/* TEST AH — cross-firm BLOKE                                                  */
/* ========================================================================== */

test('TEST AH — tek-firma kapsamı dışındaki lifecycle kayıtları ATILIR', () => {
  const items = buildPilotLifecycleItems(
    [terminatedRow({ hizmetAlanIsyeriId: 9001 }), terminatedRow({ sozlesmeId: 2003, hizmetAlanIsyeriId: 9002 })],
    '9001',
  );
  const scoped = scopeLifecycleItems(items, '9001');
  assert.equal(scoped.length, 1);
  assert.equal(scoped[0].firmaExternalId, '9001');
});

/* ========================================================================== */
/* TEST AI — cross-OSGB BLOKE                                                  */
/* ========================================================================== */

test('TEST AI — CROSS_OSGB reddedilir (sync + osgb entegrasyon)', () => {
  assert.equal(
    assessSyncScope({ role: 'osgb_admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-2' }),
    'CROSS_OSGB',
  );
  assert.equal(assessOsgbKatipScope({ role: 'osgb_admin', callerOsgbId: 'osgb-1', targetOsgbId: 'osgb-2' }), 'CROSS_OSGB');
});

/* ========================================================================== */
/* TEST AJ — helper (Saha Uzmanı) yasal KATİP ataması DEĞİL                    */
/* ========================================================================== */

test('TEST AJ — helper yasal atama olarak üretilmez/sayılmaz', () => {
  const items = matchAssignments(
    [
      {
        externalId: 'S-H',
        firmaExternalId: 'F-1',
        personelExternalId: 'P-1',
        role: 'helper' as never,
        atamaTuru: 'uzman',
        baslangicTarihi: null,
        bitisTarihi: null,
      },
    ],
    [],
    null,
  );
  assert.equal(items[0].status, 'SKIPPED');
  assert.equal(resolveAtamaKatipStatus('la-helper', 'helper', null), null);
});

/* ========================================================================== */
/* TEST AK / AL — DATA_INCOMPLETE / UNKNOWN → apply kapalı                     */
/* ========================================================================== */

test('TEST AK — DATA_INCOMPLETE → apply BLOKE (PILOT_DATA_INCOMPLETE)', () => {
  const g = evaluatePilotApplyGate({ datasetComplete: false, worksiteActive: true });
  assert.equal(g.allowed, false);
  assert.equal(g.code, 'PILOT_DATA_INCOMPLETE');
});

test('TEST AL — UNKNOWN aktivite → apply BLOKE (AKTİF sayılmaz)', () => {
  assert.equal(normalizeKatipContractActivity(unknownRow()).status, 'UNKNOWN');
  const activity = resolveKatipWorksiteActivity([unknownRow()]);
  const g = evaluatePilotApplyGate({ datasetComplete: true, worksiteActive: activity.status === 'ACTIVE' });
  assert.equal(g.allowed, false);
});

/* ========================================================================== */
/* TEST AM / AN — duplicate page / duplicate contract                          */
/* ========================================================================== */

test('TEST AM — aynı sayfa iki kez yakalanınca satır duplicate üretilmez', () => {
  const p = page(50, 0);
  assert.equal(mergeCapturedPages([{ rows: p }, { rows: p.slice() }]).length, 50);
});

test('TEST AN — aynı sozlesmeId farklı sayfalarda → tek kayıt', () => {
  const rows = mergeCapturedPages([
    { rows: [hizmetRow({ sozlesmeId: 777 })] },
    { rows: [hizmetRow({ sozlesmeId: 777, uniqueId: 'U-dup' })] },
  ]);
  assert.equal(rows.length, 1);
});

/* ========================================================================== */
/* TEST AO — captureSessionId eski/yeni veri karışmasını engeller              */
/* ========================================================================== */

test('TEST AO — yeni capture oturumu yeni dataset olarak değerlendirilir (eski sayfalar taşınmaz)', () => {
  // Eski oturum TAMAMLANMIŞTI (terminal sayfa). Yeni oturumun page-0'ı ALINDI.
  const newSession = buildDatasetReport(HIZMET_PATH, {
    rows: page(100, 0),
    meta: [meta(0, 100, 100)],
    reportedTotal: 380,
    sessionId: 2,
  });
  assert.equal(newSession.sessionId, 2);
  // Yeni oturum tek sayfa → INCOMPLETE (önceki oturumun "complete" bilgisi TAŞINMAZ).
  assert.equal(newSession.state, 'DATA_INCOMPLETE');
});

/* ========================================================================== */
/* REGRESSION — overall discovery (hizmet + personel ayrı)                     */
/* ========================================================================== */

test('REGRESSION — personel incomplete iken overall READY OLAMAZ', () => {
  const hizmet = buildDatasetReport(HIZMET_PATH, { rows: page(20, 0), meta: [meta(0, 100, 20)], reportedTotal: null });
  const personel = buildDatasetReport(PERSONEL_PATH, { rows: page(6, 0), meta: [meta(0, 100, 6)], reportedTotal: 400 });
  assert.equal(hizmet.state, 'DATA_COMPLETE');
  assert.equal(personel.state, 'DATA_INCOMPLETE');
  assert.equal(resolveOverallDiscoveryStatus(hizmet, personel), 'DATA_INCOMPLETE');
});

test('REGRESSION — DATA_INCOMPLETE iken "Aktif İşyeri Bulunamadı" gösterilemez', () => {
  const rep = buildDatasetReport(HIZMET_PATH, { rows: page(100, 0), meta: [meta(0, 100, 100)], reportedTotal: 380 });
  const gate = deriveWorksiteGateView({
    bridgeOk: true,
    captured: true,
    hizmetState: rep.state,
    activeWorksiteCount: 0,
  });
  assert.equal(gate, 'DATA_INCOMPLETE');
  assert.notEqual(gate, 'NO_ACTIVE_WORKSPACE');
});