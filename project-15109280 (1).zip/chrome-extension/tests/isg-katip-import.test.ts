/**
 * FAZ 6D/6E/6F — KONTROLLÜ GERÇEK DB IMPORT testleri (firma + personel + yasal atama).
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *   (veya bir TS yükleyici ile: `tsx --test chrome-extension/tests/`)
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) dahil DEĞİLDİR; tsconfig kapsamı dışındadır.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { buildMatchPlan } from '../../src/lib/isgKatip/matching';
import {
  assessImportAuthz,
  buildAssignmentInsert,
  buildFirmaInsert,
  buildPersonelInsert,
  executeImportPlan,
  parseImportFlag,
  resolveEffectiveMode,
} from '../../src/lib/isgKatip/import';
import type {
  IsgKatipLocalSnapshot,
  IsgKatipSyncPayload,
  KatipMappedAssignment,
  KatipMappedFirm,
  KatipMappedPersonel,
  KatipWriteGateway,
  LocalAssignmentRef,
  LocalFirmaRef,
  LocalPersonelRef,
} from '../../src/lib/isgKatip/types';

/* -------------------------------------------------------------------------- */
/* MASKELENMİŞ FIXTURE ÜRETİCİLERİ                                             */
/* -------------------------------------------------------------------------- */

function firm(over: Partial<KatipMappedFirm> = {}): KatipMappedFirm {
  return {
    externalId: 'F-1', name: 'MASKED FIRMA', registrationNo: null, taxNumber: null, sgkSicilNo: null,
    il: 'Ankara', naceKodu: null, tehlikeSinifi: 'Tehlikeli', katipCalisanSayisi: 42, ...over,
  };
}
function personel(over: Partial<KatipMappedPersonel> = {}): KatipMappedPersonel {
  return {
    externalId: 'P-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: '00000000000', personelTuru: 'isg_uzmani',
    uzmanlikSinifi: null, sicilNo: null, sertifikaNo: 'SN-1', email: null, telefon: null, ...over,
  };
}
function atama(over: Partial<KatipMappedAssignment> = {}): KatipMappedAssignment {
  return {
    externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1', role: 'isg_uzmani',
    atamaTuru: 'uzman', gorevlendirmeTuru: 'EXTERNAL', baslangicTarihi: '2026-01-01', bitisTarihi: '2026-12-31', ...over,
  };
}
function localFirma(over: Partial<LocalFirmaRef> = {}): LocalFirmaRef {
  return { id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA', vergiNo: null, il: 'Ankara', isgKatipId: null, ...over };
}
function localPersonel(over: Partial<LocalPersonelRef> = {}): LocalPersonelRef {
  return {
    id: 'lp-1', osgbId: 'osgb-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: null, email: null, telefon: null,
    source: 'MANUAL', isgKatipId: null, isgKatipSicilNo: null, isgKatipSertifikaNo: null, personelTuru: 'isg_uzmani', ...over,
  };
}
function localAtama(over: Partial<LocalAssignmentRef> = {}): LocalAssignmentRef {
  return { id: 'la-1', osgbId: 'osgb-1', firmaId: 'lf-1', personelId: 'lp-1', atamaTuru: 'uzman', assignmentRole: 'primary', isgKatipId: null, isActive: true, ...over };
}
function snapshot(over: Partial<IsgKatipLocalSnapshot> = {}): IsgKatipLocalSnapshot {
  return { firms: [], personnel: [], assignments: [], ...over };
}
function payload(over: Partial<IsgKatipSyncPayload> = {}): IsgKatipSyncPayload {
  return { source: 'ISG_KATIP', syncedAt: '2026-01-01T00:00:00.000Z', context: { osgbId: 'osgb-1', requestId: 'corr-1' }, firms: [], personnel: [], assignments: [], ...over };
}

/* ---------------------------- SAHTE (in-memory) GATEWAY ---------------------------- */

interface FakeState { firmalar: Record<string, unknown>[]; personeller: Record<string, unknown>[]; atamalar: Record<string, unknown>[]; }

function createFakeGateway() {
  const state: FakeState = { firmalar: [], personeller: [], atamalar: [] };
  const stats = { insert: 0, update: 0, deletes: 0 };
  let seq = 1;
  const gateway: KatipWriteGateway = {
    async insertFirma(fields) { stats.insert += 1; state.firmalar.push(fields); return { id: `nf-${seq++}` }; },
    async updateFirma(_id, fields) { stats.update += 1; state.firmalar.push({ __update: fields }); },
    async insertPersonel(fields) { stats.insert += 1; state.personeller.push(fields); return { id: `np-${seq++}` }; },
    async updatePersonel(_id, fields) { stats.update += 1; state.personeller.push({ __update: fields }); },
    async insertAssignment(fields) { stats.insert += 1; state.atamalar.push(fields); return { id: `na-${seq++}` }; },
    async updateAssignment(_id, fields) { stats.update += 1; state.atamalar.push({ __update: fields }); },
  };
  return { state, stats, gateway };
}

async function run(args: {
  payload: IsgKatipSyncPayload;
  snapshot: IsgKatipLocalSnapshot;
  mode?: 'DRY_RUN' | 'SAFE_IMPORT' | 'FULL_CONTROLLED_IMPORT';
  importEnabled?: boolean;
}) {
  const fake = createFakeGateway();
  const plan = buildMatchPlan({ payload: args.payload, snapshot: args.snapshot, createdAt: '2026-01-01T00:00:00.000Z' });
  const result = await executeImportPlan({
    plan,
    snapshot: args.snapshot,
    mode: args.mode ?? 'FULL_CONTROLLED_IMPORT',
    importEnabled: args.importEnabled ?? true,
    osgbId: 'osgb-1',
    gateway: fake.gateway,
    createdAt: '2026-01-01T00:00:00.000Z',
  });
  return { result, fake };
}

/* ========================================================================== */
/* FİRMA                                                                       */
/* ========================================================================== */

test('F1 — exact external ID → NOOP (değişiklik yok, yazma yok)', async () => {
  const { result, fake } = await run({
    payload: payload({ firms: [firm({ externalId: 'F-1' })] }),
    snapshot: snapshot({ firms: [localFirma({ isgKatipId: 'F-1' })] }),
  });
  assert.equal(result.counts.matched, 1);
  assert.equal(result.counts.noop, 1);
  assert.equal(fake.stats.insert + fake.stats.update, 0);
});

test('F2 — exact external ID + eksik isg_katip_id → UPDATE (güvenli yama)', async () => {
  const { result, fake } = await run({
    // vergi no ile eşleşir; yerelde isg_katip_id boş → yama doldurur.
    payload: payload({ firms: [firm({ externalId: 'F-9', taxNumber: '1111111' })] }),
    snapshot: snapshot({ firms: [localFirma({ id: 'lf-9', vergiNo: '1111111', isgKatipId: null })] }),
  });
  assert.equal(result.counts.updated, 1);
  assert.equal(fake.stats.update, 1);
  assert.equal((fake.state.firmalar[0] as Record<string, unknown>).isg_katip_id, 'F-9');
});

test('F3 — NEW → CREATE', async () => {
  const { result, fake } = await run({
    payload: payload({ firms: [firm({ externalId: 'F-NEW', name: 'YEPYENI FIRMA' })] }),
    snapshot: snapshot(),
  });
  assert.equal(result.counts.imported, 1);
  assert.equal(fake.stats.insert, 1);
  assert.equal((fake.state.firmalar[0] as Record<string, unknown>).isg_katip_id, 'F-NEW');
});

test('F4 — duplicate external ID → CONFLICT (yazma YOK)', async () => {
  const { result, fake } = await run({
    payload: payload({ firms: [firm({ externalId: 'F-1' })] }),
    snapshot: snapshot({ firms: [localFirma({ id: 'a', isgKatipId: 'F-1' }), localFirma({ id: 'b', isgKatipId: 'F-1' })] }),
  });
  assert.equal(result.counts.conflict, 1);
  assert.equal(fake.stats.insert + fake.stats.update, 0);
});

test('F5 — belirsiz eşleşme (isim) → UNRESOLVED (yazma YOK)', async () => {
  const { result, fake } = await run({
    payload: payload({ firms: [firm({ externalId: 'F-3', name: 'MASKED FIRMA' })] }),
    snapshot: snapshot({ firms: [localFirma({ id: 'lf-3', unvan: 'MASKED FIRMA', isgKatipId: null })] }),
  });
  assert.equal(result.counts.unresolved, 1);
  assert.equal(fake.stats.insert + fake.stats.update, 0);
});

test('F6 — KATİP çalışan sayısı yeni firmaya YAZILIR (boş firmayı doldurur)', async () => {
  const insert = buildFirmaInsert(firm({ externalId: 'F-NEW', katipCalisanSayisi: 999 }), 'osgb-1');
  assert.equal(insert?.calisan_sayisi, 999); // KATİP değeri doldurulur
  const { fake } = await run({
    payload: payload({ firms: [firm({ externalId: 'F-9', taxNumber: '1111111', katipCalisanSayisi: 999 })] }),
    snapshot: snapshot({ firms: [localFirma({ id: 'lf-9', vergiNo: '1111111' })] }),
  });
  // Mevcut firmanın güncelleme yamasında calisan_sayisi bulunmamalıdır (üzerine yazılmaz).
  const upd = fake.state.firmalar.find((r) => '__update' in r) as { __update: Record<string, unknown> } | undefined;
  assert.ok(!upd || !('calisan_sayisi' in upd.__update));
});

/* ========================================================================== */
/* PERSONEL                                                                    */
/* ========================================================================== */

test('P7 — external ID → MATCHED/NOOP', async () => {
  const { result, fake } = await run({
    payload: payload({ personnel: [personel({ externalId: 'P-1' })] }),
    snapshot: snapshot({ personnel: [localPersonel({ isgKatipId: 'P-1' })] }),
  });
  assert.equal(result.counts.matched, 1);
  assert.equal(result.counts.noop, 1);
  assert.equal(fake.stats.insert + fake.stats.update, 0);
});

test('P8 — T.C. ile → MATCHED (yerelde isg_katip_id boş → UPDATE)', async () => {
  const { result, fake } = await run({
    payload: payload({ personnel: [personel({ externalId: 'P-NEW', tcKimlikNo: '11111111111' })] }),
    snapshot: snapshot({ personnel: [localPersonel({ id: 'lp-8', isgKatipId: null, tcKimlikNo: '11111111111' })] }),
  });
  assert.equal(result.counts.matched, 1);
  assert.equal(result.counts.updated, 1);
  assert.equal((fake.state.personeller[0] as Record<string, unknown>).isg_katip_id, 'P-NEW');
});

test('P9 — yeni KATİP personeli → CREATE (source=ISG_KATIP)', async () => {
  const { result, fake } = await run({
    payload: payload({ personnel: [personel({ externalId: 'P-NEW', tcKimlikNo: '22222222222' })] }),
    snapshot: snapshot(),
  });
  assert.equal(result.counts.imported, 1);
  assert.equal((fake.state.personeller[0] as Record<string, unknown>).source, 'ISG_KATIP');
});

test('P10 — MANUAL personel → source KORUNUR (yama source içermez)', async () => {
  const { result, fake } = await run({
    payload: payload({ personnel: [personel({ externalId: 'P-1', email: null, telefon: null })] }),
    snapshot: snapshot({ personnel: [localPersonel({ isgKatipId: null, tcKimlikNo: '00000000000', source: 'MANUAL' })] }),
  });
  const upd = fake.state.personeller.find((r) => '__update' in r) as { __update: Record<string, unknown> } | undefined;
  assert.equal(result.counts.matched, 1);
  if (upd) assert.ok(!('source' in upd.__update));
});

test('P11 — KATİP phone/email yok → yerel değer korunur (yama phone/email içermez)', async () => {
  const { fake } = await run({
    payload: payload({ personnel: [personel({ externalId: 'P-1', email: null, telefon: null })] }),
    snapshot: snapshot({ personnel: [localPersonel({ isgKatipId: null, tcKimlikNo: '00000000000', email: 'manual@x.test', telefon: '5000000000' })] }),
  });
  const upd = fake.state.personeller.find((r) => '__update' in r) as { __update: Record<string, unknown> } | undefined;
  assert.ok(upd);
  assert.ok(!('email' in upd.__update));
  assert.ok(!('telefon' in upd.__update));
});

test('P12 — external ID çakışması (farklı TC) → CONFLICT', async () => {
  const { result } = await run({
    payload: payload({ personnel: [personel({ externalId: 'P-1', tcKimlikNo: '22222222222' })] }),
    snapshot: snapshot({ personnel: [localPersonel({ isgKatipId: 'P-1', tcKimlikNo: '11111111111' })] }),
  });
  assert.equal(result.counts.conflict, 1);
});

test('P13 — TC çakışması (yerel farklı KATİP kimliğine bağlı) → CONFLICT', async () => {
  const { result } = await run({
    payload: payload({ personnel: [personel({ externalId: 'K1', tcKimlikNo: '11111111111' })] }),
    snapshot: snapshot({ personnel: [localPersonel({ isgKatipId: 'K0', tcKimlikNo: '11111111111' })] }),
  });
  assert.equal(result.counts.conflict, 1);
});

/* ========================================================================== */
/* YASAL ATAMA                                                                 */
/* ========================================================================== */

test('A14 — exact sozlesmeId → NOOP', async () => {
  const { result, fake } = await run({
    payload: payload({ assignments: [atama({ externalId: 'S-1' })] }),
    snapshot: snapshot({ assignments: [localAtama({ isgKatipId: 'S-1' })] }),
  });
  assert.equal(result.counts.matched, 1);
  assert.equal(fake.stats.insert, 0);
});

test('A15 — yeni yasal atama → CREATE (assignment_role=primary)', async () => {
  const { result, fake } = await run({
    payload: payload({
      firms: [firm({ externalId: 'F-1' })],
      personnel: [personel({ externalId: 'P-1', tcKimlikNo: '00000000000' })],
      assignments: [atama({ externalId: 'S-NEW' })],
    }),
    snapshot: snapshot({
      firms: [localFirma({ id: 'lf-1', isgKatipId: 'F-1' })],
      personnel: [localPersonel({ id: 'lp-1', isgKatipId: 'P-1', tcKimlikNo: '00000000000' })],
    }),
    mode: 'SAFE_IMPORT',
  });
  assert.equal(result.counts.imported, 1);
  assert.equal((fake.state.atamalar[0] as Record<string, unknown>).assignment_role, 'primary');
  assert.equal((fake.state.atamalar[0] as Record<string, unknown>).atama_turu, 'uzman');
});

test('A16 — bilinmeyen/geçersiz rol → üretilmez (SKIPPED), yazma YOK', async () => {
  const { result, fake } = await run({
    payload: payload({ assignments: [atama({ externalId: 'S-X', role: null as never })] }),
    snapshot: snapshot(),
  });
  assert.equal(result.counts.skipped, 1);
  assert.equal(result.counts.imported, 0);
  assert.equal(fake.stats.insert, 0);
});

test('A17 — helper (Saha Uzmanı) → SKIPPED, asla yasal atama üretilmez', async () => {
  const { result, fake } = await run({
    payload: payload({ assignments: [atama({ externalId: 'S-H', role: 'helper' as never })] }),
    snapshot: snapshot(),
  });
  assert.equal(result.counts.skipped, 1);
  assert.equal(fake.stats.insert, 0);
});

test('A18 — firma çözülemedi → assignment CREATE YOK (INVALID_RELATION)', async () => {
  const { result, fake } = await run({
    payload: payload({
      personnel: [personel({ externalId: 'P-1', tcKimlikNo: '00000000000' })],
      assignments: [atama({ externalId: 'S-NEW', firmaExternalId: 'F-YOK' })],
    }),
    snapshot: snapshot({ personnel: [localPersonel({ id: 'lp-1', isgKatipId: 'P-1', tcKimlikNo: '00000000000' })] }),
  });
  assert.equal(fake.stats.insert, 0);
  assert.equal(result.counts.imported, 0);
});

test('A19 — personel çözülemedi → assignment CREATE YOK (INVALID_RELATION)', async () => {
  const { result, fake } = await run({
    payload: payload({
      firms: [firm({ externalId: 'F-1' })],
      assignments: [atama({ externalId: 'S-NEW', personelExternalId: 'P-YOK' })],
    }),
    snapshot: snapshot({ firms: [localFirma({ id: 'lf-1', isgKatipId: 'F-1' })] }),
  });
  assert.equal(fake.stats.insert, 0);
  assert.equal(result.counts.imported, 0);
});

test('A20 — sonlandırılmış sözleşme → DELETE YOK', async () => {
  const { fake } = await run({
    payload: payload({ assignments: [atama({ externalId: 'S-1', bitisTarihi: '2020-01-01' })] }),
    snapshot: snapshot({ assignments: [localAtama({ isgKatipId: 'S-1', isActive: false })] }),
  });
  assert.equal(fake.stats.deletes, 0); // hiçbir silme çağrısı yok
});

/* ========================================================================== */
/* SECURITY                                                                    */
/* ========================================================================== */

test('SEC21 — JWT yok → UNAUTHORIZED', () => {
  assert.equal(assessImportAuthz({ hasJwt: false, role: 'admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-1' }), 'UNAUTHORIZED');
});

test('SEC22 — yetkisiz rol → FORBIDDEN', () => {
  assert.equal(assessImportAuthz({ hasJwt: true, role: 'uzman', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-1' }), 'FORBIDDEN');
});

test('SEC23 — OSGB kapsamı yok → OSGB_SCOPE_REQUIRED', () => {
  assert.equal(assessImportAuthz({ hasJwt: true, role: 'osgb_admin', callerOsgbId: null, payloadOsgbId: 'osgb-1' }), 'OSGB_SCOPE_REQUIRED');
});

test('SEC24 — CROSS_OSGB → reddedilir', () => {
  assert.equal(assessImportAuthz({ hasJwt: true, role: 'osgb_admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-2' }), 'CROSS_OSGB');
  assert.equal(assessImportAuthz({ hasJwt: true, role: 'osgb_admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-1' }), 'OK');
});

/* ========================================================================== */
/* IDEMPOTENCY / DRY RUN / FLAG                                                */
/* ========================================================================== */

test('ID25 — aynı payload iki kez → ikinci koşuda CREATE yok (NOOP)', async () => {
  const p = payload({ firms: [firm({ externalId: 'F-NEW', name: 'YENI FIRMA' })] });
  const empty = snapshot();
  const first = await run({ payload: p, snapshot: empty });
  assert.equal(first.result.counts.imported, 1);

  // İkinci koşu: oluşturulan kayıt artık snapshot'ta (aynı external ID) → CREATE yok.
  const after = snapshot({ firms: [localFirma({ id: 'nf-1', isgKatipId: 'F-NEW' })] });
  const second = await run({ payload: p, snapshot: after });
  assert.equal(second.result.counts.imported, 0);
  assert.equal(second.fake.stats.insert + second.fake.stats.update, 0);
});

test('DR26 — DRY_RUN → hiçbir DB write YOK', async () => {
  const { result, fake } = await run({
    payload: payload({
      firms: [firm({ externalId: 'F-NEW' })],
      personnel: [personel({ externalId: 'P-NEW', tcKimlikNo: '33333333333' })],
    }),
    snapshot: snapshot(),
    mode: 'DRY_RUN',
    importEnabled: true,
  });
  assert.equal(fake.stats.insert + fake.stats.update, 0);
  assert.equal(result.applied, false);
  assert.equal(result.mode, 'DRY_RUN');
});

test('FLAG27 — importEnabled=false → hiçbir DB write YOK (mod SAFE_IMPORT olsa bile)', async () => {
  const { result, fake } = await run({
    payload: payload({ firms: [firm({ externalId: 'F-NEW' })] }),
    snapshot: snapshot(),
    mode: 'SAFE_IMPORT',
    importEnabled: false,
  });
  assert.equal(fake.stats.insert + fake.stats.update, 0);
  assert.equal(result.applied, false);
  assert.equal(result.mode, 'DRY_RUN');
});

/* ========================================================================== */
/* FLAG / MOD / INSERT BUILDER BİRİM TESTLERİ                                  */
/* ========================================================================== */

test('parseImportFlag yalnızca tam "true" değerini açık sayar', () => {
  assert.equal(parseImportFlag('true'), true);
  assert.equal(parseImportFlag(' TRUE '), true);
  assert.equal(parseImportFlag('false'), false);
  assert.equal(parseImportFlag(''), false);
  assert.equal(parseImportFlag(undefined), false);
});

test('resolveEffectiveMode: gate kapalı → daima DRY_RUN', () => {
  assert.equal(resolveEffectiveMode('FULL_CONTROLLED_IMPORT', false), 'DRY_RUN');
  assert.equal(resolveEffectiveMode('SAFE_IMPORT', true), 'SAFE_IMPORT');
  assert.equal(resolveEffectiveMode('gecersiz', true), 'DRY_RUN');
});

test('SAFE_IMPORT, bu koşuda oluşturulmuş parent ile assignment oluşturmaz', async () => {
  const { result, fake } = await run({
    payload: payload({
      firms: [firm({ externalId: 'F-NEW' })],
      personnel: [personel({ externalId: 'P-NEW', tcKimlikNo: '44444444444' })],
      assignments: [atama({ externalId: 'S-NEW', firmaExternalId: 'F-NEW', personelExternalId: 'P-NEW' })],
    }),
    snapshot: snapshot(),
    mode: 'SAFE_IMPORT',
  });
  // firma + personel oluşturulur ama assignment (yeni parent) oluşturulmaz.
  assert.equal(result.counts.imported, 2);
  assert.equal(result.counts.skipped, 1);
  assert.equal(fake.state.atamalar.length, 0);
});

test('buildAssignmentInsert: baslangic_tarihi yoksa null (uydurma tarih YOK)', () => {
  assert.equal(buildAssignmentInsert(atama({ baslangicTarihi: null }), 'f1', 'p1', 'osgb-1'), null);
});

test('buildPersonelInsert: kimlik yoksa (external ID ve TC yok) null', () => {
  assert.equal(buildPersonelInsert(personel({ externalId: null, tcKimlikNo: null }), 'osgb-1'), null);
});