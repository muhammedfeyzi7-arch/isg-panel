/**
 * FAZ 3 — TEK FİRMA KATİP PİLOT WRITE KAPISI + LIFECYCLE testleri (TEST A–W).
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) DAHİL DEĞİLDİR. GERÇEK KATİP oturumu GÖRÜLMEZ;
 * KATİP'e İSTEK ATILMAZ; DB'YE YAZILMAZ. Yalnızca SAF karar mantığı doğrulanır.
 *
 * KAPSAM SINIRI (dürüst not): `runIsgKatipPilotApply` (supabase çağırır) ve atomik RPC
 * (`isg_katip_apply_pilot`) GERÇEK ortam gerektirdiğinden burada KOŞULMAZ. Burada test
 * edilenler: write kapısı kararları (gate), lifecycle pasifleştirme listesi türetimi,
 * tek-firma kapsam filtresi ve değişmeyen güvenlik sözleşmeleri (employee count / helper /
 * CROSS_OSGB).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  buildPilotLifecycleItems,
  evaluatePilotApplyGate,
  scopeLifecycleItems,
} from '../../src/lib/isgKatip/pilotLifecycle';
import {
  normalizeKatipContractActivity,
  resolveKatipWorksiteActivity,
} from '../../src/lib/isgKatip/contractActivity';
import { KATIP_EMPLOYEE_COUNT_POLICY } from '../../src/lib/isgKatip/readiness';
import { assessSyncScope } from '../../src/lib/isgKatip/matching';

/* ---------------------------- MASKELENMİŞ FIXTURE ---------------------------- */

function hizmetRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    uniqueId: 'U-1',
    sozlesmeId: 1001,
    gorevlendirilenKisiUserId: 501,
    gorevlendirilenKisiAdSoyad: 'MASKED KISI',
    gorevlendirilenKisiSertifikaTipiId: 20002,
    hizmetAlanIsyeriId: 9001,
    hizmetAlanIsyeriUnvani: 'MASKED FIRMA A',
    hizmetAlanIsyeriCalisanSayisi: 3,
    sozlesmeBaslangicTarihi: '01.01.2026',
    sozlesmeBitisTarihi: '31.12.2099',
    sozlesmeOnayDurumu: 'ONAYLANDI',
    sozlesmeStatu: 'AKTIF',
    ...over,
  };
}

function terminatedRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return hizmetRow({
    sozlesmeId: 2002,
    sozlesmeStatu: 'SONLANDIRILDI',
    sozlesmeSonlandirilmaNedeni: 'Hizmet alan işyeri talebi',
    ...over,
  });
}

function unknownRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return hizmetRow({
    sozlesmeId: 5005,
    sozlesmeStatu: null,
    sozlesmeStatuId: null,
    sozlesmeOnayDurumu: null,
    sozlesmeOnayDurumuId: null,
    sozlesmeBitisTarihi: null,
    ...over,
  });
}

/* ========================================================================== */
/* TEST A — DATA_INCOMPLETE → Apply BLOKE                                      */
/* ========================================================================== */

test('TEST A — DATA_INCOMPLETE → apply bloke (PILOT_DATA_INCOMPLETE)', () => {
  const g = evaluatePilotApplyGate({ datasetComplete: false, worksiteActive: true });
  assert.equal(g.allowed, false);
  assert.equal(g.code, 'PILOT_DATA_INCOMPLETE');
});

test('TEST A2 — datasetComplete verilmezse bu kural UYGULANMAZ (geriye uyumlu)', () => {
  const g = evaluatePilotApplyGate({ worksiteActive: true });
  assert.equal(g.allowed, true);
});

/* ========================================================================== */
/* TEST B/C/D — ACTIVE=0 / TERMINATED / UNKNOWN → pilot write bloke            */
/* ========================================================================== */

test('TEST B — işyerinde AKTİF sözleşme yok → apply bloke', () => {
  const activity = resolveKatipWorksiteActivity([terminatedRow()]);
  assert.equal(activity.status, 'INACTIVE');
  const g = evaluatePilotApplyGate({ datasetComplete: true, worksiteActive: activity.status === 'ACTIVE' });
  assert.equal(g.allowed, false);
  assert.equal(g.code, 'PILOT_WRITE_SCOPE_NOT_ACTIVE');
});

test('TEST C — yalnızca TERMINATED → pilot write bloke', () => {
  const activity = resolveKatipWorksiteActivity([terminatedRow(), terminatedRow({ sozlesmeId: 2003 })]);
  assert.equal(activity.status, 'INACTIVE');
  assert.equal(evaluatePilotApplyGate({ worksiteActive: false }).allowed, false);
});

test('TEST D — yalnızca UNKNOWN → pilot write bloke (AKTİF sayılmaz)', () => {
  const activity = resolveKatipWorksiteActivity([unknownRow()]);
  assert.equal(activity.status, 'UNKNOWN');
  assert.equal(evaluatePilotApplyGate({ worksiteActive: activity.status === 'ACTIVE' }).allowed, false);
});

/* ========================================================================== */
/* TEST E — ACTIVE + DATA_COMPLETE → gate açık                                 */
/* ========================================================================== */

test('TEST E — ACTIVE + DATA_COMPLETE → gate açık (ALLOW)', () => {
  const activity = resolveKatipWorksiteActivity([hizmetRow()]);
  assert.equal(activity.status, 'ACTIVE');
  const g = evaluatePilotApplyGate({
    datasetComplete: true,
    worksiteActive: true,
    firmBlocking: false,
    personnelBlocking: false,
    assignmentBlocking: false,
    orphanAssignments: 0,
  });
  assert.equal(g.allowed, true);
  assert.equal(g.code, 'ALLOW');
});

/* ========================================================================== */
/* TEST F/G — CONFLICT / UNRESOLVED bloke                                      */
/* ========================================================================== */

test('TEST F — CONFLICT personel → apply bloke', () => {
  const g = evaluatePilotApplyGate({ datasetComplete: true, worksiteActive: true, personnelBlocking: true });
  assert.equal(g.allowed, false);
  assert.equal(g.code, 'PILOT_WRITE_PERSONNEL_BLOCKED');
});

test('TEST G — UNRESOLVED yasal atama → apply bloke', () => {
  const g = evaluatePilotApplyGate({ datasetComplete: true, worksiteActive: true, assignmentBlocking: true });
  assert.equal(g.allowed, false);
  assert.equal(g.code, 'PILOT_WRITE_ASSIGNMENT_BLOCKED');
});

test('TEST G2 — yetim yasal atama (personele bağlanamıyor) → apply bloke', () => {
  const g = evaluatePilotApplyGate({ datasetComplete: true, worksiteActive: true, orphanAssignments: 1 });
  assert.equal(g.allowed, false);
  assert.equal(g.code, 'PILOT_WRITE_ASSIGNMENT_ORPHAN');
});

/* ========================================================================== */
/* TEST H — yeni firma + yeni personel + yeni atama → tek plan (lifecycle boş) */
/* ========================================================================== */

test('TEST H — AKTİF işyeri için lifecycle listesi BOŞ (yazma planı kirlenmez)', () => {
  const items = buildPilotLifecycleItems([hizmetRow()], '9001');
  assert.equal(items.length, 0);
});

/* ========================================================================== */
/* TEST Q — TERMINATED sözleşme → lifecycle DEACTIVATE (DELETE YOK)            */
/* ========================================================================== */

test('TEST Q — sonlandırılmış sözleşme → DEACTIVATE lifecycle öğesi (delete değil)', () => {
  const items = buildPilotLifecycleItems([hizmetRow(), terminatedRow()], '9001');
  assert.equal(items.length, 1);
  assert.equal(items[0].action, 'DEACTIVATE');
  assert.equal(items[0].externalId, '2002');
  assert.equal(items[0].firmaExternalId, '9001');
});

test('TEST Q2 — lifecycle öğesi yalnızca KESİN sonlandırma kanıtında üretilir (UNKNOWN hariç)', () => {
  const items = buildPilotLifecycleItems([unknownRow()], '9001');
  assert.equal(items.length, 0);
});

test('TEST Q3 — aynı sozlesmeId AKTİF ise lifecycle üretilmez (çift yön yok)', () => {
  const aktif = hizmetRow({ sozlesmeId: 4004 });
  const items = buildPilotLifecycleItems([aktif, terminatedRow({ sozlesmeId: 4004 })], '9001');
  assert.equal(items.length, 0);
});

/* ========================================================================== */
/* TEST R — aynı worksite başka AKTİF sözleşme → aktiflik korunur              */
/* ========================================================================== */

test('TEST R — aynı worksite: TERMINATED + ACTIVE → aktiflik KORUNUR', () => {
  const activity = resolveKatipWorksiteActivity([terminatedRow(), hizmetRow()]);
  assert.equal(activity.status, 'ACTIVE');
  // ve lifecycle yalnızca sonlandırılmış sözleşme için üretilir.
  const items = buildPilotLifecycleItems([terminatedRow(), hizmetRow()], '9001');
  assert.equal(items.length, 1);
  assert.equal(items[0].externalId, '2002');
});

/* ========================================================================== */
/* TEST S — CROSS_OSGB bloke                                                    */
/* ========================================================================== */

test('TEST S — CROSS_OSGB reddedilir', () => {
  assert.equal(
    assessSyncScope({ role: 'osgb_admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-2' }),
    'CROSS_OSGB',
  );
  assert.equal(
    assessSyncScope({ role: 'osgb_admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-1' }),
    'OK',
  );
});

/* ========================================================================== */
/* TEST T — cross-firm: lifecycle tek firma kapsamına indirgenir               */
/* ========================================================================== */

test('TEST T — lifecycle tek firma kapsamına indirgenir (kapsam dışı ATILIR)', () => {
  const items = buildPilotLifecycleItems(
    [terminatedRow({ hizmetAlanIsyeriId: 9001 }), terminatedRow({ sozlesmeId: 2003, hizmetAlanIsyeriId: 9002 })],
    '9001',
  );
  // Her ikisi de kendi firma kimliğini taşır; kapsam 9001'e daraltılınca 9002 düşer.
  const scoped = scopeLifecycleItems(items, '9001');
  assert.equal(scoped.length, 1);
  assert.equal(scoped[0].firmaExternalId, '9001');
});

/* ========================================================================== */
/* TEST O — employee count merkezi değer değişmez                              */
/* ========================================================================== */

test('TEST O — KATİP employee count merkezi alana yazılmaz (policy)', () => {
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.autoWriteToFirmalar, false);
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.runtimeSource, 'firmalar.calisan_sayisi');
});

/* ========================================================================== */
/* TEST W — inactive worksite manuel bypass edilemez                           */
/* ========================================================================== */

test('TEST W — işyeri kanonik AKTİF değilse manuel seçim BYPASS EDEMEZ', () => {
  const activity = resolveKatipWorksiteActivity([terminatedRow()]);
  // Manuel seçim yalnızca satır kümesini daraltır; aktiflik kuralı BYPASS EDİLMEZ.
  const g = evaluatePilotApplyGate({ datasetComplete: true, worksiteActive: activity.status === 'ACTIVE' });
  assert.equal(g.allowed, false);
});

/* ========================================================================== */
/* REGRESYON — contractActivity kanonik davranışı bozulmadı                    */
/* ========================================================================== */

test('REGRESSION — normalizeKatipContractActivity öncelik sırası korunuyor', () => {
  assert.equal(normalizeKatipContractActivity(hizmetRow()).status, 'ACTIVE');
  assert.equal(normalizeKatipContractActivity(terminatedRow()).status, 'TERMINATED');
  assert.equal(normalizeKatipContractActivity(unknownRow()).status, 'UNKNOWN');
});