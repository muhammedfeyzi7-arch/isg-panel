/**
 * FAZ 2 — OSGB PERSONEL + ATAMA ↔ İSG-KATİP ENTEGRASYON testleri (A–O).
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) DAHİL DEĞİLDİR. GERÇEK KATİP oturumu GÖRÜLMEZ;
 * KATİP'e İSTEK ATILMAZ. Yalnızca saf mantık doğrulanır (DB WRITE = 0).
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  buildOsgbKatipIntegration,
  resolvePersonelKatipStatus,
  resolveAtamaKatipStatus,
  isFirmaKatipLinked,
  assessOsgbKatipScope,
} from '../../src/lib/isgKatip/osgbIntegration';
import { summarizeCapture, buildDatasetReport } from '../../src/lib/isgKatip/capture';
import { buildSyncPayload } from '../../src/lib/isgKatip/normalize';
import { matchAssignments } from '../../src/lib/isgKatip/matching';
import { KATIP_EMPLOYEE_COUNT_POLICY } from '../../src/lib/isgKatip/readiness';
import type { IsgDenetimDbSnapshot } from '../../src/lib/isgKatip/types';

/* ---------------------------- MASKELENMİŞ FIXTURE ---------------------------- */

const HIZMET_PATH = '/be/bsn-inter-instance/hizmet-sozlesmesi-surec-view/ongoing';
const PERSONEL_PATH = '/be/bsn-inter-instance/personel-sozlesmesi-surec/ongoing';

function hizmetRow(over: Record<string, unknown> = {}): Record<string, unknown> {
  return {
    uniqueId: 'U-1',
    sozlesmeId: 1001,
    gorevlendirilenKisiUserId: 501,
    gorevlendirilenKisiTckn: '11111111111',
    gorevlendirilenKisiAdSoyad: 'MASKED KISI',
    gorevlendirilenKisiSertifikaTipiId: 20002,
    gorevlendirilenKisiSertifikaTipi: 'C Sınıfı İş Güvenliği Uzmanlığı Sertifikası',
    hizmetAlanIsyeriId: 9001,
    hizmetAlanIsyeriUnvani: 'MASKED FIRMA A',
    hizmetAlanIsyeriCalisanSayisi: 3,
    sozlesmeBaslangicTarihi: '01.01.2026',
    sozlesmeBitisTarihi: '31.12.2099',
    sozlesmeOnayDurumu: 'ONAYLANDI',
    sozlesmeStatu: 'AKTIF',
    ...over,
  };
}

/** Tek sayfalı, terminal (bitti) dataset özeti. */
function captured(rows: Array<Record<string, unknown>>, path: string) {
  return summarizeCapture(path, {
    rows,
    meta: [{ pageIndex: 0, pageSize: 100, rowCount: rows.length, capturedAt: 1 }],
    reportedTotal: null,
  });
}

/** Hiç başlamamış dataset özeti (yakalanan sayfa yok). */
function notStarted(path: string) {
  return summarizeCapture(path, { rows: [], meta: [], reportedTotal: null });
}

/** Pagination'ı TAMAMLANMAMIŞ (incomplete) dataset özeti. */
function incomplete(rows: Array<Record<string, unknown>>, path: string) {
  return summarizeCapture(path, {
    rows,
    meta: [{ pageIndex: 0, pageSize: 100, rowCount: rows.length, capturedAt: 1 }],
    reportedTotal: 380,
  });
}

function snap(over: Partial<IsgDenetimDbSnapshot> = {}): IsgDenetimDbSnapshot {
  return {
    source: 'ISGDENETIM_DB',
    readOnly: true,
    scopeValidated: true,
    osgbId: 'osgb-1',
    firms: [],
    personnel: [],
    assignments: [],
    ...over,
  };
}

function localPersonel(over: Record<string, unknown> = {}) {
  return {
    id: 'lp-1',
    osgbId: 'osgb-1',
    ad: 'ALI',
    soyad: 'VELI',
    tcKimlikNo: null,
    email: null,
    telefon: null,
    source: 'MANUAL',
    isgKatipId: null,
    isgKatipSicilNo: null,
    isgKatipSertifikaNo: null,
    personelTuru: 'isg_uzmani',
    ...over,
  };
}

function localAtama(over: Record<string, unknown> = {}) {
  return {
    id: 'la-1',
    osgbId: 'osgb-1',
    firmaId: 'lf-1',
    personelId: 'lp-1',
    atamaTuru: 'uzman',
    assignmentRole: 'primary',
    isgKatipId: null,
    isActive: true,
    ...over,
  };
}

function integrate(opts: {
  hizmetRows?: Array<Record<string, unknown>>;
  personelRows?: Array<Record<string, unknown>>;
  hizmetDataset?: ReturnType<typeof summarizeCapture>;
  personelDataset?: ReturnType<typeof summarizeCapture>;
  bridgeOk?: boolean;
  captured?: boolean;
  snapshot?: IsgDenetimDbSnapshot | null;
}) {
  const hizmetRows = opts.hizmetRows ?? [];
  const personelRows = opts.personelRows ?? [];
  return buildOsgbKatipIntegration({
    hizmetRows,
    personelRows,
    dataset: {
      hizmet: opts.hizmetDataset ?? captured(hizmetRows, HIZMET_PATH),
      personel: opts.personelDataset ?? notStarted(PERSONEL_PATH),
    },
    bridgeOk: opts.bridgeOk ?? true,
    captured: opts.captured ?? (hizmetRows.length > 0 || personelRows.length > 0),
    snapshot: opts.snapshot ?? snap(),
    generatedAt: '2026-01-01T00:00:00.000Z',
  });
}

/* ========================================================================== */
/* TEST A — DATA_INCOMPLETE personelinde kesin MATCH üretilmez                 */
/* ========================================================================== */

test('TEST A — DATA_INCOMPLETE → kesin MATCH YOK (INCOMPLETE)', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow()],
    hizmetDataset: incomplete([hizmetRow()], HIZMET_PATH),
    snapshot: snap({ personnel: [localPersonel({ isgKatipId: '501' })] }),
  });
  assert.equal(integration.ready, false);
  assert.equal(resolvePersonelKatipStatus('lp-1', integration), 'INCOMPLETE');
  assert.equal(integration.personel.counts.match, 0);
});

/* ========================================================================== */
/* TEST B — DATA_COMPLETE + TC + isim uyumlu → MATCH                          */
/* ========================================================================== */

test('TEST B — TC + isim uyumlu → MATCH', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow()],
    snapshot: snap({ personnel: [localPersonel({ tcKimlikNo: '11111111111' })] }),
  });
  assert.equal(integration.ready, true);
  assert.equal(integration.personel.counts.match, 1);
  assert.equal(resolvePersonelKatipStatus('lp-1', integration), 'MATCH');
});

/* ========================================================================== */
/* TEST C — TC aynı + isim uyuşmaz → CONFLICT                                  */
/* ========================================================================== */

test('TEST C — TC aynı + isim farklı → CONFLICT', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow()],
    snapshot: snap({ personnel: [localPersonel({ ad: 'AYSE', soyad: 'YILMAZ', tcKimlikNo: '11111111111' })] }),
  });
  assert.equal(integration.personel.counts.conflict, 1);
  assert.equal(resolvePersonelKatipStatus('lp-1', integration), 'CONFLICT');
});

/* ========================================================================== */
/* TEST D — KATİP personel yok → MANUAL personel değişmez                       */
/* ========================================================================== */

test('TEST D — KATİP personel yoksa mevcut MANUAL personel etkilenmez', () => {
  // Görevlendirilen kişi bilgisi olmayan hizmet satırı → personel/atama üretilmez.
  const firmOnly = hizmetRow({
    gorevlendirilenKisiUserId: null,
    gorevlendirilenKisiTckn: null,
    gorevlendirilenKisiAdSoyad: null,
  });
  const integration = integrate({
    hizmetRows: [firmOnly],
    snapshot: snap({ personnel: [localPersonel({ tcKimlikNo: '11111111111' })] }),
  });
  assert.equal(integration.ready, true);
  assert.equal(integration.personel.counts.match, 0);
  assert.equal(integration.personel.counts.new, 0);
  assert.equal(resolvePersonelKatipStatus('lp-1', integration), null);
});

/* ========================================================================== */
/* TEST E — isg_katip_id mevcut → external ID öncelikli MATCH                  */
/* ========================================================================== */

test('TEST E — isg_katip_id mevcut → external ID öncelikli MATCH', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow()],
    snapshot: snap({ personnel: [localPersonel({ isgKatipId: '501', tcKimlikNo: null })] }),
  });
  assert.equal(integration.personel.counts.match, 1);
  assert.equal(resolvePersonelKatipStatus('lp-1', integration), 'MATCH');
});

/* ========================================================================== */
/* TEST F — ACTIVE hizmet sözleşmesi → yasal atama adayı                       */
/* ========================================================================== */

test('TEST F — ACTIVE hizmet sözleşmesi → yasal atama adayı (NEW)', () => {
  const integration = integrate({ hizmetRows: [hizmetRow()], snapshot: snap() });
  assert.equal(integration.assignment.counts.new, 1);
});

/* ========================================================================== */
/* TEST G/H — TERMINATED / UNKNOWN aktif aday DEĞİL                            */
/* ========================================================================== */

test('TEST G — TERMINATED → aktif yasal atama adayı değil', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow({ sozlesmeStatu: 'SONLANDIRILDI', sozlesmeSonlandirilmaNedeni: 'talep' })],
    snapshot: snap(),
  });
  assert.equal(integration.assignment.counts.new, 0);
  assert.equal(integration.assignment.counts.match, 0);
});

test('TEST H — UNKNOWN → aktif yasal atama adayı değil', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow({ sozlesmeStatu: null, sozlesmeStatuId: null, sozlesmeOnayDurumu: null, sozlesmeOnayDurumuId: null, sozlesmeBitisTarihi: null })],
    snapshot: snap(),
  });
  assert.equal(integration.assignment.counts.new, 0);
});

/* ========================================================================== */
/* TEST I — helper (Saha Uzmanı) yasal atama DEĞİL                             */
/* ========================================================================== */

test('TEST I — helper yasal atama olarak üretilmez/sayılmaz', () => {
  const items = matchAssignments(
    [{ externalId: 'S-H', firmaExternalId: 'F-1', personelExternalId: 'P-1', role: 'helper' as never, atamaTuru: 'uzman', baslangicTarihi: null, bitisTarihi: null }],
    [],
    null,
  );
  assert.equal(items[0].status, 'SKIPPED');
  // helper yerel atama için KATİP durumu DAİMA null.
  assert.equal(resolveAtamaKatipStatus('la-helper', 'helper', null), null);
});

/* ========================================================================== */
/* TEST J — personel sözleşmesi ID'si yasal atama ID'si olarak KULLANILMAZ      */
/* ========================================================================== */

test('TEST J — personel sözleşmesi ID legal assignment ID olarak kullanılmaz', () => {
  const built = buildSyncPayload({
    ctx: { osgbId: 'osgb-1' },
    hizmetRows: [],
    personelRows: [
      { sozlesmeId: 7777, sozlesmeYapilanKisiUserId: 501, sozlesmeYapilanKisiAdSoyad: 'MASKED KISI' },
    ],
  });
  // Personel sözleşmesi ayrı entity; YASAL atama ÜRETİLMEZ.
  assert.equal(built.payload.assignments.length, 0);
  assert.equal(built.personelSozlesmeleri.length, 1);
});

/* ========================================================================== */
/* TEST K — KATİP employee count merkezi sayıya yazılmaz                       */
/* ========================================================================== */

test('TEST K — KATİP employee count merkezi alana YAZILMAZ (policy)', () => {
  assert.equal(KATIP_EMPLOYEE_COUNT_POLICY.autoWriteToFirmalar, false);
});

/* ========================================================================== */
/* TEST L — CROSS_OSGB kabul edilmez                                           */
/* ========================================================================== */

test('TEST L — CROSS_OSGB reddedilir', () => {
  assert.equal(
    assessOsgbKatipScope({ role: 'osgb_admin', callerOsgbId: 'osgb-1', targetOsgbId: 'osgb-2' }),
    'CROSS_OSGB',
  );
});

/* ========================================================================== */
/* TEST M — gerçek KATİP verisi yoksa sahte kayıt yok                          */
/* ========================================================================== */

test('TEST M — köprü verisi yoksa sahte kayıt/karar üretilmez', () => {
  const integration = integrate({ bridgeOk: false, captured: false, hizmetRows: [], snapshot: null });
  assert.equal(integration.ready, false);
  assert.equal(integration.personel.counts.match, 0);
  assert.equal(Object.keys(integration.personel.byLocalId).length, 0);
  assert.equal(Object.keys(integration.assignment.byLocalId).length, 0);
});

/* ========================================================================== */
/* TEST N — DATA_INCOMPLETE → yeni personel/yasal atama kesin kararı YOK        */
/* ========================================================================== */

test('TEST N — DATA_INCOMPLETE → yeni personel/atama kesin kararı yok', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow()],
    hizmetDataset: incomplete([hizmetRow()], HIZMET_PATH),
    snapshot: snap(),
  });
  assert.equal(integration.ready, false);
  assert.equal(integration.personel.counts.new, 0);
  assert.equal(integration.assignment.counts.new, 0);
});

/* ========================================================================== */
/* TEST O — captureSessionId eski/yeni veri karışmasını engeller               */
/* ========================================================================== */

test('TEST O — captureSessionId dataset raporunda taşınır (izolasyon metadata)', () => {
  const first = buildDatasetReport(HIZMET_PATH, {
    rows: [hizmetRow()],
    meta: [{ pageIndex: 0, pageSize: 100, rowCount: 1, capturedAt: 1 }],
    reportedTotal: null,
    sessionId: 7,
  });
  assert.equal(first.sessionId, 7);
  assert.equal(first.state, 'DATA_COMPLETE');
});

/* ========================================================================== */
/* EK — firma düzeyi KATİP bağlantısı                                          */
/* ========================================================================== */

test('EK — AKTİF işyeri, isg_katip_id ile bağlı yerel firmayı işaretler', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow()],
    snapshot: snap({
      firms: [
        { id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA A', vergiNo: null, il: null, isgKatipId: '9001', calisanSayisi: 5 },
        { id: 'lf-2', osgbId: 'osgb-1', unvan: 'MASKED FIRMA B', vergiNo: null, il: null, isgKatipId: null, calisanSayisi: 2 },
      ],
    }),
  });
  assert.equal(isFirmaKatipLinked('lf-1', integration), true);
  assert.equal(isFirmaKatipLinked('lf-2', integration), false);
});

test('EK — veri eksik olsa da isg_katip_id bağı gösterilir (DB gerçeği)', () => {
  const integration = integrate({
    hizmetRows: [hizmetRow()],
    hizmetDataset: incomplete([hizmetRow()], HIZMET_PATH),
    snapshot: snap({
      firms: [{ id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA A', vergiNo: null, il: null, isgKatipId: '9001', calisanSayisi: 5 }],
    }),
  });
  // Bağ, `firmalar.isg_katip_id` DB gerçeğine dayanır; veri-tamamlama kapısına BAĞLI DEĞİLDİR.
  assert.equal(isFirmaKatipLinked('lf-1', integration), true);
});

test('EK — yakalanan aktİF işyeri yoksa isg_katip_id BAĞI korunur; sonlandırılmışsa gösterilmez', () => {
  const terminated = integrate({
    hizmetRows: [hizmetRow({ sozlesmeStatu: 'SONLANDIRILDI', sozlesmeSonlandirilmaNedeni: 'talep' })],
    snapshot: snap({
      firms: [{ id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA A', vergiNo: null, il: null, isgKatipId: '9001', calisanSayisi: 5 }],
    }),
  });
  assert.equal(isFirmaKatipLinked('lf-1', terminated), false);

  const notCaptured = integrate({
    hizmetRows: [],
    snapshot: snap({
      firms: [{ id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA A', vergiNo: null, il: null, isgKatipId: '9001', calisanSayisi: 5 }],
    }),
  });
  assert.equal(isFirmaKatipLinked('lf-1', notCaptured), true);
});