/**
 * FAZ 6J.6 — KATİP CAPTURE / PAGINATION AGGREGATOR testleri.
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) dahil DEĞİLDİR.
 *
 * KAPSAM: çok-sayfalı birleştirme, duplicate sayfa yakalama, kimlik tekilleştirme,
 * sayfa tamamlanma (completeness) kuralları. GERÇEK KATİP oturumu GÖRÜLMEZ; yalnızca
 * SAF aggregation mantığı doğrulanır. KATİP'e İSTİK ATILMAZ.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  dedupeRows,
  mergeCapturedPages,
  readReportedTotal,
  summarizeCapture,
  captureRowIdentity,
  type KatipCapturedPageMeta,
} from '../../src/lib/isgKatip/capture';

/* ---------------------------- MASKELENMİŞ FIXTURE ÜRETİCİLERİ ---------------------------- */

/** Maskelenmiş hizmet sözleşmesi satırı (verilen uniqueId/sozlesmeId/worsite ile). */
function row(uniqueId: string, sozlesmeId: number, worksiteId = 9001): Record<string, unknown> {
  return {
    uniqueId,
    sozlesmeId,
    hizmetAlanIsyeriId: worksiteId,
    hizmetAlanIsyeriUnvani: `MASKED FIRMA ${worksiteId}`,
    sozlesmeStatu: 'AKTIF',
  };
}

/** Ardışık N benzersiz satır üretir. */
function page(n: number, offset: number, worksiteOf?: (i: number) => number): Record<string, unknown>[] {
  const out: Record<string, unknown>[] = [];
  for (let i = 0; i < n; i += 1) {
    const idx = offset + i;
    out.push(row(`U-${idx}`, 100000 + idx, worksiteOf ? worksiteOf(idx) : 9001));
  }
  return out;
}

function meta(pageIndex: number, pageSize: number, rowCount: number): KatipCapturedPageMeta {
  return { pageIndex, pageSize, rowCount, capturedAt: 1000 + pageIndex };
}

const PATH = '/be/bsn-inter-instance/hizmet-sozlesmesi-surec-view/ongoing';

/* ========================================================================== */
/* KİMLİK + TEKİLLEŞTİRME                                                      */
/* ========================================================================== */

test('CAP-1 — captureRowIdentity uniqueId öncelikli', () => {
  assert.equal(captureRowIdentity({ uniqueId: 'U-1', sozlesmeId: 5 }), 'uniqueId:U-1');
  assert.equal(captureRowIdentity({ sozlesmeId: 5 }), 'sozlesmeId:5');
  assert.equal(captureRowIdentity({}), null);
});

test('CAP-2 — duplicate satır tekilleştirilir, kimliksiz satır korunur', () => {
  const rows: Record<string, unknown>[] = [
    { uniqueId: 'A' },
    { uniqueId: 'A' },
    { sozlesmeId: 1 },
    { noId: true },
    { noId: true },
  ];
  const out = dedupeRows(rows);
  // 2 benzersiz kimlikli + 2 kimliksiz korunur = 4
  assert.equal(out.length, 4);
});

/* ========================================================================== */
/* PAGINATION BİRLEŞTİRME                                                      */
/* ========================================================================== */

test('P1 — 100 + 100 + 100 + 80 → 380 benzersiz sözleşme', () => {
  const rows = mergeCapturedPages([
    { rows: page(100, 0) },
    { rows: page(100, 100) },
    { rows: page(100, 200) },
    { rows: page(80, 300) },
  ]);
  assert.equal(rows.length, 380);
});

test('P2 — aynı sayfa duplicate yakalanınca toplam değişmez', () => {
  const pages = [
    { rows: page(100, 0) },
    { rows: page(100, 100) },
    { rows: page(100, 0) }, // sayfa 0 tekrar (duplicate capture)
  ];
  const rows = mergeCapturedPages(pages);
  assert.equal(rows.length, 200);
});

test('P3 — iki sayfada AYNI işyeri → satırlar korunur (işyeri tekilliği ayrı katman)', () => {
  // Aynı worksite iki farklı sözleşme (farklı sozlesmeId) → 2 satır.
  const rows = mergeCapturedPages([
    { rows: [row('U-1', 1001, 9001)] },
    { rows: [row('U-2', 1002, 9001)] },
  ]);
  assert.equal(rows.length, 2);
});

test('P16 — duplicate sayfa capture → duplicate işyeri/row üretmez', () => {
  const p = page(50, 0);
  const rows = mergeCapturedPages([{ rows: p }, { rows: p.slice() }]);
  assert.equal(rows.length, 50);
});

/* ========================================================================== */
/* COMPLETENESS                                                                */
/* ========================================================================== */

test('P6 — tek sayfa, pageSize değerine EŞİT satır → DATA_INCOMPLETE', () => {
  const s = summarizeCapture(PATH, { rows: page(100, 0), meta: [meta(0, 100, 100)], reportedTotal: null });
  assert.equal(s.complete, false);
  assert.equal(s.terminalPageReached, false);
});

test('P7 — metadata total=380, captured=100 → incomplete', () => {
  const s = summarizeCapture(PATH, {
    rows: page(100, 0),
    meta: [meta(0, 100, 100)],
    reportedTotal: 380,
  });
  assert.equal(s.complete, false);
});

test('P8 — metadata total=380, captured=380 → complete', () => {
  const rows = mergeCapturedPages([
    { rows: page(100, 0) },
    { rows: page(100, 100) },
    { rows: page(100, 200) },
    { rows: page(80, 300) },
  ]);
  const s = summarizeCapture(PATH, {
    rows,
    meta: [meta(0, 100, 100), meta(1, 100, 100), meta(2, 100, 100), meta(3, 100, 80)],
    reportedTotal: 380,
  });
  assert.equal(s.complete, true);
  assert.equal(s.rowCount, 380);
  assert.equal(s.pageCount, 4);
});

test('P6b — son sayfa pageSize\'dan az (metadata yok) → complete (terminal sayfa)', () => {
  const s = summarizeCapture(PATH, {
    rows: mergeCapturedPages([{ rows: page(100, 0) }, { rows: page(40, 100) }]),
    meta: [meta(0, 100, 100), meta(1, 100, 40)],
    reportedTotal: null,
  });
  assert.equal(s.complete, true);
  assert.equal(s.lastPageRowCount, 40);
});

test('P7b — 100 100 100 100 (metadata yok) → tamamlandı DEME', () => {
  const s = summarizeCapture(PATH, {
    rows: mergeCapturedPages([{ rows: page(100, 0) }, { rows: page(100, 100) }, { rows: page(100, 200) }, { rows: page(100, 300) }]),
    meta: [meta(0, 100, 100), meta(1, 100, 100), meta(2, 100, 100), meta(3, 100, 100)],
    reportedTotal: null,
  });
  assert.equal(s.complete, false);
});

test('P9 — raw=380, aktif=0 → transferable=0 (aggregation sonrası işyeri çözümü ayrı katman)', () => {
  // Bu test yalnızca aggregation sayılarını doğrular; aktiflik motoru 6J.5 testlerinde.
  const rows = mergeCapturedPages([
    { rows: page(100, 0, () => 9001) },
    { rows: page(100, 100, () => 9002) },
    { rows: page(100, 200, () => 9003) },
    { rows: page(80, 300, () => 9003) },
  ]);
  assert.equal(rows.length, 380);
});

/* ========================================================================== */
/* readReportedTotal                                                           */
/* ========================================================================== */

test('TOTAL-1 — body.totalElements / totalCount okunur', () => {
  assert.equal(readReportedTotal({ body: { totalElements: 380, tableData: [] } }), 380);
  assert.equal(readReportedTotal({ totalCount: '250' }), 250);
});

test('TOTAL-2 — toplam alanı yoksa null (tahmin yok)', () => {
  assert.equal(readReportedTotal({ body: { tableData: [] } }), null);
  assert.equal(readReportedTotal(null), null);
});