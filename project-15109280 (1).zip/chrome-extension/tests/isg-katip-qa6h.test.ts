/**
 * FAZ 6H — GERÇEK KATİP ROLE DISCOVERY + QA + IMPORT READINESS testleri.
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) dahil DEĞİLDİR; tsconfig kapsamı dışındadır.
 *
 * KAPSAM: rol discovery audit + dry-run ayrıştırılmış sayaçlar + idempotency +
 * termination (DELETE yok) + helper exclusion + OSGB scope + contract alan + checklist.
 * GERÇEK KATİP enum değerleri HÂLÂ BOŞTUR (doğrulanmadı) → UYDURMA YOK.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import { collectRoleDiscovery, summarizeRoleDiscovery } from '../../src/lib/isgKatip/roleDiscovery';
import {
  KATIP_HIZMET_CONTRACT_FIELDS,
  buildDryRunReport,
  buildImportReadinessChecklist,
} from '../../src/lib/isgKatip/readiness';
import { buildMatchPlan, assessSyncScope } from '../../src/lib/isgKatip/matching';
import { executeImportPlan } from '../../src/lib/isgKatip/import';
import type {
  IsgKatipLocalSnapshot,
  IsgKatipSyncPayload,
  KatipMappedAssignment,
  KatipMappedFirm,
  KatipMappedPersonel,
  KatipWriteGateway,
  LocalAssignmentRef,
  LocalFirmaRef,
  LocalPersonelRef,
} from '../../src/lib/isgKatip/types';

/* ---------------------------- MASKELENMİŞ FIXTURE ÜRETİCİLERİ ---------------------------- */

function firm(over: Partial<KatipMappedFirm> = {}): KatipMappedFirm {
  return {
    externalId: 'F-1', name: 'MASKED FIRMA', registrationNo: null, taxNumber: null, sgkSicilNo: null,
    il: 'Ankara', naceKodu: null, tehlikeSinifi: null, katipCalisanSayisi: 42, ...over,
  };
}
function personel(over: Partial<KatipMappedPersonel> = {}): KatipMappedPersonel {
  return {
    externalId: 'P-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: '00000000000', personelTuru: 'isg_uzmani',
    uzmanlikSinifi: null, sicilNo: null, sertifikaNo: 'SN-1', email: null, telefon: null, ...over,
  };
}
function atama(over: Partial<KatipMappedAssignment> = {}): KatipMappedAssignment {
  return {
    externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1', role: 'isg_uzmani',
    atamaTuru: 'uzman', gorevlendirmeTuru: 'EXTERNAL', baslangicTarihi: '2026-01-01', bitisTarihi: '2026-12-31', ...over,
  };
}
function localFirma(over: Partial<LocalFirmaRef> = {}): LocalFirmaRef {
  return { id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA', vergiNo: null, il: 'Ankara', isgKatipId: null, ...over };
}
function localPersonel(over: Partial<LocalPersonelRef> = {}): LocalPersonelRef {
  return {
    id: 'lp-1', osgbId: 'osgb-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: '00000000000', email: null, telefon: null,
    source: 'MANUAL', isgKatipId: null, isgKatipSicilNo: null, isgKatipSertifikaNo: null, personelTuru: 'isg_uzmani', ...over,
  };
}
function localAtama(over: Partial<LocalAssignmentRef> = {}): LocalAssignmentRef {
  return { id: 'la-1', osgbId: 'osgb-1', firmaId: 'lf-1', personelId: 'lp-1', atamaTuru: 'uzman', assignmentRole: 'primary', isgKatipId: null, isActive: true, ...over };
}
function snapshot(over: Partial<IsgKatipLocalSnapshot> = {}): IsgKatipLocalSnapshot {
  return { firms: [], personnel: [], assignments: [], ...over };
}
function payload(over: Partial<IsgKatipSyncPayload> = {}): IsgKatipSyncPayload {
  return { source: 'ISG_KATIP', syncedAt: '2026-01-01T00:00:00.000Z', context: { osgbId: 'osgb-1', requestId: 'corr-1' }, firms: [], personnel: [], assignments: [], ...over };
}
function planOf(p: IsgKatipSyncPayload, s: IsgKatipLocalSnapshot) {
  return buildMatchPlan({ payload: p, snapshot: s, createdAt: '2026-01-01T00:00:00.000Z' });
}
function noWriteGateway() {
  const stats = { writes: 0 };
  const g: KatipWriteGateway = {
    async insertFirma() { stats.writes += 1; return { id: 'x' }; },
    async updateFirma() { stats.writes += 1; },
    async insertPersonel() { stats.writes += 1; return { id: 'x' }; },
    async updatePersonel() { stats.writes += 1; },
    async insertAssignment() { stats.writes += 1; return { id: 'x' }; },
    async updateAssignment() { stats.writes += 1; },
  };
  return { stats, g };
}

/* ========================================================================== */
/* A) ROLE DISCOVERY AUDIT                                                     */
/* ========================================================================== */

test('QA-RD — discovery audit: gözlemlenen değerler + haritalanmamış + BOŞ harita (uydurma yok)', () => {
  const discovery = collectRoleDiscovery({
    hizmetRows: [
      { gorevlendirilenKisiSertifikaTipi: 'MASKED_SERT_X', sozlesmeTipi: 'MASKED_SOZ_A' },
      { gorevlendirilenKisiSertifikaTipi: 'MASKED_SERT_Y', sozlesmeTipi: 'MASKED_SOZ_A' },
    ],
    personelRows: [{ sozlesmeYapilanKisiSertifikaTipi: 'MASKED_SERT_X' }],
  });
  const audit = summarizeRoleDiscovery(discovery);

  assert.equal(audit.observedRoleValueCount, 3); // X, Y (sertifika) + A (sözleşme)
  assert.deepEqual(audit.unmapped.sertifikaTipi.sort(), ['MASKED_SERT_X', 'MASKED_SERT_Y']);
  assert.deepEqual(audit.unmapped.sozlesmeTipi, ['MASKED_SOZ_A']);
  // Haritalar BOŞ → rol çözülemez; değerler UYDURULMADI (null).
  assert.equal(audit.readiness.complete, false);
  assert.equal(audit.mappingSkeleton.sertifikaTipi.MASKED_SERT_X, null);
});

/* ========================================================================== */
/* F) DRY RUN — AYRIŞTIRILMIŞ SAYAÇLAR                                         */
/* ========================================================================== */

test('QA-DRY-BREAKDOWN — helper/duplicate/missingStartDate/invalidExternalId/crossOsgb ayrı raporlanır', () => {
  const plan = planOf(
    payload({
      firms: [
        firm({ externalId: 'F-DUP', name: 'MASKED FIRMA' }),      // → duplicate external ID → CONFLICT
        firm({ externalId: '', name: 'ISIMSIZ YENI' }),           // → NEW ama external ID yok → invalidExternalId
      ],
      personnel: [personel({ externalId: 'P-1' })],
      assignments: [
        atama({ externalId: 'S-H', role: 'helper' as never }),    // → helper → SKIPPED
        atama({ externalId: 'S-NODATE', baslangicTarihi: null,    // → NEW ama başlangıç yok → missingStartDate
          firmaExternalId: 'F-1', personelExternalId: 'P-1' }),
      ],
    }),
    snapshot({
      firms: [
        localFirma({ id: 'a', isgKatipId: 'F-DUP' }),
        localFirma({ id: 'b', isgKatipId: 'F-DUP' }),
      ],
      personnel: [localPersonel({ isgKatipId: 'P-1' })],
      assignments: [],
    }),
  );

  const report = buildDryRunReport({ plan, crossOsgbRejected: 2 });

  assert.equal(report.dryRun, true);
  assert.equal(report.applied, false);
  assert.equal(report.importEnabled, false);
  assert.equal(report.breakdown.helperSkipped, 1);
  assert.equal(report.breakdown.duplicateConflicts, 1);
  assert.equal(report.breakdown.crossOsbgRejected, 2);
  assert.equal(report.breakdown.missingStartDate, 1);
  assert.equal(report.breakdown.invalidExternalId, 1); // external ID'siz NEW firma
});

test('QA-DRY-DEFAULT — breakdown alanları her koşuda mevcuttur (varsayılan 0)', () => {
  const report = buildDryRunReport({ plan: planOf(payload(), snapshot()) });
  assert.deepEqual(report.breakdown, {
    helperSkipped: 0, duplicateConflicts: 0, crossOsbgRejected: 0, missingStartDate: 0, invalidExternalId: 0,
  });
});

/* ========================================================================== */
/* 10 — IDEMPOTENCY (DB write olmadan)                                         */
/* ========================================================================== */

test('QA-IDEMPOTENCY — aynı payload iki kez: 1. NEW, 2. MATCHED (duplicate CREATE yok)', () => {
  const p = payload({ firms: [firm({ externalId: 'F-NEW', name: 'YEPYENI FIRMA' })] });

  const first = planOf(p, snapshot());
  assert.equal(first.firms[0].status, 'NEW');

  // İkinci kez: oluşmuş varsayılan kayıt snapshot'ta (aynı external ID) → MATCHED.
  const second = planOf(p, snapshot({ firms: [localFirma({ id: 'nf-1', isgKatipId: 'F-NEW' })] }));
  assert.equal(second.firms[0].status, 'MATCHED');

  const creates = second.operations.filter((o) => o.action === 'CREATE').length;
  assert.equal(creates, 0);
});

/* ========================================================================== */
/* 16 — TERMINATION (DELETE YOK)                                               */
/* ========================================================================== */

test('QA-TERMINATION — sonlandırılmış sözleşme: DELETE üretilmez, yalnızca NOOP', async () => {
  const s = snapshot({ assignments: [localAtama({ isgKatipId: 'S-1', isActive: false })] });
  const plan = planOf(payload({ assignments: [atama({ externalId: 'S-1', bitisTarihi: '2020-01-01' })] }), s);
  assert.ok(!plan.operations.some((o) => (o.action as string) === 'DELETE'));

  const { stats, g } = noWriteGateway();
  const result = await executeImportPlan({
    plan, snapshot: s, mode: 'FULL_CONTROLLED_IMPORT', importEnabled: true, osgbId: 'osgb-1', gateway: g,
  });
  assert.equal(stats.writes, 0);         // MATCHED → NOOP, yazma yok
  assert.equal(result.counts.imported, 0);
});

/* ========================================================================== */
/* 9 / 21 — HELPER EXCLUSION                                                   */
/* ========================================================================== */

test('QA-HELPER — helper/Saha Uzmanı asla yasal atama olarak üretilmez veya yazılmaz', async () => {
  const s = snapshot();
  const plan = planOf(payload({ assignments: [atama({ externalId: 'S-H', role: 'helper' as never })] }), s);
  assert.equal(plan.assignments[0].status, 'SKIPPED');

  const { stats, g } = noWriteGateway();
  const result = await executeImportPlan({
    plan, snapshot: s, mode: 'FULL_CONTROLLED_IMPORT', importEnabled: true, osgbId: 'osgb-1', gateway: g,
  });
  assert.equal(result.counts.skipped, 1);
  assert.equal(stats.writes, 0);
});

/* ========================================================================== */
/* 7 / 15 — OSGB SCOPE                                                          */
/* ========================================================================== */

test('QA-SCOPE — CROSS_OSGB ve yetkisiz rol reddedilir (sunucu kuralının aynası)', () => {
  assert.equal(assessSyncScope({ role: 'osgb_admin', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-2' }), 'CROSS_OSGB');
  assert.equal(assessSyncScope({ role: 'osgb_admin', callerOsgbId: null, payloadOsgbId: 'osgb-1' }), 'OSGB_SCOPE_REQUIRED');
  assert.equal(assessSyncScope({ role: 'uzman', callerOsgbId: 'osgb-1', payloadOsgbId: 'osgb-1' }), 'FORBIDDEN');
  assert.equal(assessSyncScope({ role: 'admin', callerOsgbId: null, payloadOsgbId: 'osgb-1' }), 'OK');
});

/* ========================================================================== */
/* 3 / 11 — CONTRACT ALAN (sozlesmeSurecAdi additive)                          */
/* ========================================================================== */

test('QA-CONTRACT — hizmet sözleşmesi contract listesi sozlesmeSurecAdi içerir (22 alan)', () => {
  assert.equal(KATIP_HIZMET_CONTRACT_FIELDS.length, 22);
  assert.ok(KATIP_HIZMET_CONTRACT_FIELDS.includes('sozlesmeSurecAdi'));
});

/* ========================================================================== */
/* 8 — ÇALIŞAN SAYISI (KATİP değeri firmalar.calisan_sayisi'na YAZILMAZ)       */
/* ========================================================================== */

test('QA-EMPLOYEE — KATİP çalışan sayısı merkezî alanı EZMEZ (yalnızca metadata taşınır)', () => {
  const s = snapshot({ firms: [localFirma({ id: 'lf-1', vergiNo: '1111111', isgKatipId: null })] });
  const plan = planOf(payload({ firms: [firm({ externalId: 'F-9', taxNumber: '1111111', katipCalisanSayisi: 999 })] }), s);
  const op = plan.operations.find((o) => o.entityType === 'FIRMA');
  assert.ok(op);
  const fields = (op?.fields ?? {}) as Record<string, unknown>;
  assert.ok(!('calisan_sayisi' in fields)); // 999 ASLA yazılmaz
});

/* ========================================================================== */
/* 14 — FEATURE FLAG / CHECKLIST                                               */
/* ========================================================================== */

test('QA-READINESS — kanıt yokken hiçbir madde PASS değil; feature flag OFF kalır', () => {
  const { items, readyForLiveImport } = buildImportReadinessChecklist();
  assert.equal(readyForLiveImport, false);
  assert.equal(items.find((i) => i.key === 'featureFlag')?.status, 'OFF');
  assert.equal(items.filter((i) => i.status === 'PENDING').length, items.length - 1);
});