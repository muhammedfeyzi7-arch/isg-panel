/**
 * FAZ 6I + 6J — GERÇEK KATİP DRY RUN + KONTROLLÜ PİLOT IMPORT testleri.
 *
 * ÇALIŞTIRMA:
 *   node --test --experimental-strip-types chrome-extension/tests/
 *
 * ⚠️ Fixture'lar MASKELENMİŞTİR: gerçek kişisel veri (gerçek TC, gerçek ad) YOKTUR.
 * Bu dosya uygulama build'ine (src) dahil DEĞİLDİR; tsconfig kapsamı dışındadır.
 *
 * NOT: Bu testler GERÇEK KATİP oturumunu GÖRMEZ; role enum DEĞERLERİ hâlâ BOŞTUR
 * (UYDURMA YOK). Burada pilot kapsamı, pre-write kontrol özeti, unknown* sayaçları,
 * idempotency ve write-free davranışı doğrulanır.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';

import {
  applyPilotScope,
  buildPilotPreWriteSummary,
  executeImportPlan,
  ISG_KATIP_IMPORT_DEFAULT_ENABLED,
  resolveEffectiveMode,
} from '../../src/lib/isgKatip/import';
import { buildMatchPlan } from '../../src/lib/isgKatip/matching';
import { buildDryRunReport } from '../../src/lib/isgKatip/readiness';
import type {
  IsgKatipLocalSnapshot,
  IsgKatipSyncPayload,
  KatipMappedAssignment,
  KatipMappedFirm,
  KatipMappedPersonel,
  KatipWriteGateway,
  LocalAssignmentRef,
  LocalFirmaRef,
  LocalPersonelRef,
} from '../../src/lib/isgKatip/types';

/* ---------------------------- MASKELENMİŞ FIXTURE ÜRETİCİLERİ ---------------------------- */

function firm(over: Partial<KatipMappedFirm> = {}): KatipMappedFirm {
  return {
    externalId: 'F-1', name: 'MASKED FIRMA', registrationNo: null, taxNumber: null, sgkSicilNo: null,
    il: 'Ankara', naceKodu: null, tehlikeSinifi: null, katipCalisanSayisi: 42, ...over,
  };
}
function personel(over: Partial<KatipMappedPersonel> = {}): KatipMappedPersonel {
  return {
    externalId: 'P-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: '00000000000', personelTuru: 'isg_uzmani',
    uzmanlikSinifi: null, sicilNo: null, sertifikaNo: 'SN-1', email: null, telefon: null, ...over,
  };
}
function atama(over: Partial<KatipMappedAssignment> = {}): KatipMappedAssignment {
  return {
    externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1', role: 'isg_uzmani',
    atamaTuru: 'uzman', gorevlendirmeTuru: 'EXTERNAL', baslangicTarihi: '2026-01-01', bitisTarihi: '2026-12-31', ...over,
  };
}
function localFirma(over: Partial<LocalFirmaRef> = {}): LocalFirmaRef {
  return { id: 'lf-1', osgbId: 'osgb-1', unvan: 'MASKED FIRMA', vergiNo: null, il: 'Ankara', isgKatipId: null, ...over };
}
function localPersonel(over: Partial<LocalPersonelRef> = {}): LocalPersonelRef {
  return {
    id: 'lp-1', osgbId: 'osgb-1', ad: 'MASKED', soyad: 'KISI', tcKimlikNo: '00000000000', email: null, telefon: null,
    source: 'MANUAL', isgKatipId: null, isgKatipSicilNo: null, isgKatipSertifikaNo: null, personelTuru: 'isg_uzmani', ...over,
  };
}
function localAtama(over: Partial<LocalAssignmentRef> = {}): LocalAssignmentRef {
  return {
    id: 'la-1', osgbId: 'osgb-1', firmaId: 'lf-1', personelId: 'lp-1', atamaTuru: 'uzman',
    assignmentRole: 'primary', isgKatipId: null, isActive: true, ...over,
  };
}
function snapshot(over: Partial<IsgKatipLocalSnapshot> = {}): IsgKatipLocalSnapshot {
  return { firms: [], personnel: [], assignments: [], ...over };
}
function payload(over: Partial<IsgKatipSyncPayload> = {}): IsgKatipSyncPayload {
  return {
    source: 'ISG_KATIP', syncedAt: '2026-01-01T00:00:00.000Z', context: { osgbId: 'osgb-1', requestId: 'corr-1' },
    firms: [], personnel: [], assignments: [], ...over,
  };
}
function planOf(p: IsgKatipSyncPayload, s: IsgKatipLocalSnapshot) {
  return buildMatchPlan({ payload: p, snapshot: s, createdAt: '2026-01-01T00:00:00.000Z' });
}

/** Yazma çağrılarını kaydeden sahte gateway (yalnızca ADET tutar; PII yok). */
function recordingGateway() {
  const calls = { firma: 0, personel: 0, atama: 0 };
  let n = 0;
  const g: KatipWriteGateway = {
    async insertFirma() { calls.firma += 1; n += 1; return { id: `nf-${n}` }; },
    async updateFirma() { calls.firma += 1; },
    async insertPersonel() { calls.personel += 1; n += 1; return { id: `np-${n}` }; },
    async updatePersonel() { calls.personel += 1; },
    async insertAssignment() { calls.atama += 1; n += 1; return { id: `na-${n}` }; },
    async updateAssignment() { calls.atama += 1; },
  };
  return { calls, g };
}

/* ========================================================================== */
/* FAZ 6J — PILOT KAPSAM (TEK FİRMA)                                           */
/* ========================================================================== */

test('PILOT-SCOPE — applyPilotScope yalnızca hedef firma + bağlı personel + yasal atamaları tutar', () => {
  const plan = planOf(
    payload({
      firms: [firm({ externalId: 'F-1' }), firm({ externalId: 'F-2', name: 'DIGER FIRMA' })],
      personnel: [personel({ externalId: 'P-1' }), personel({ externalId: 'P-2' })],
      assignments: [
        atama({ externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1' }),
        atama({ externalId: 'S-2', firmaExternalId: 'F-2', personelExternalId: 'P-2' }),
      ],
    }),
    snapshot(),
  );

  const scoped = applyPilotScope(plan, { firmExternalId: 'F-1' });
  assert.deepEqual(scoped.firms.map((f) => f.externalId), ['F-1']);
  assert.deepEqual(scoped.personnel.map((p) => p.externalId), ['P-1']);
  assert.deepEqual(scoped.assignments.map((a) => a.externalId), ['S-1']);
  // F-2 kümesi tamamen dışarıda.
  assert.ok(!scoped.assignments.some((a) => a.externalId === 'S-2'));
  assert.ok(!scoped.personnel.some((p) => p.externalId === 'P-2'));
});

test('PILOT-SCOPE — bilinmeyen firma ID → güvenli BOŞ plan (tahmin yok)', () => {
  const plan = planOf(payload({ firms: [firm({ externalId: 'F-1' })] }), snapshot());
  const scoped = applyPilotScope(plan, { firmExternalId: 'YOK-BOYLE' });
  assert.equal(scoped.firms.length, 0);
  assert.equal(scoped.personnel.length, 0);
  assert.equal(scoped.assignments.length, 0);
  assert.equal(scoped.operations.length, 0);
});

test('PILOT-WRITE — pilot + FULL_CONTROLLED_IMPORT: yalnızca hedef firmanın kayıtları yazılır', async () => {
  const p = payload({
    firms: [firm({ externalId: 'F-1' }), firm({ externalId: 'F-2', name: 'DIGER FIRMA' })],
    personnel: [personel({ externalId: 'P-1' }), personel({ externalId: 'P-2' })],
    assignments: [
      atama({ externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1' }),
      atama({ externalId: 'S-2', firmaExternalId: 'F-2', personelExternalId: 'P-2' }),
    ],
  });
  const s = snapshot();
  const plan = planOf(p, s);
  const { calls, g } = recordingGateway();

  const result = await executeImportPlan({
    plan, snapshot: s, mode: 'FULL_CONTROLLED_IMPORT', importEnabled: true,
    osgbId: 'osgb-1', gateway: g, pilot: { firmExternalId: 'F-1' },
  });

  assert.equal(result.applied, true);
  assert.deepEqual(result.pilot, { firmExternalId: 'F-1' });
  // Yalnızca F-1 kümesi: 1 firma + 1 personel + 1 yasal atama.
  assert.deepEqual(calls, { firma: 1, personel: 1, atama: 1 });
  assert.equal(result.counts.imported, 3);
});

test('PILOT-DRY — pilot + DRY_RUN: hiçbir yazma yapılmaz (applied false)', async () => {
  const p = payload({
    firms: [firm({ externalId: 'F-1' })],
    personnel: [personel({ externalId: 'P-1' })],
    assignments: [atama({ externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1' })],
  });
  const s = snapshot();
  const plan = planOf(p, s);
  const { calls, g } = recordingGateway();

  const result = await executeImportPlan({
    plan, snapshot: s, mode: 'DRY_RUN', importEnabled: false,
    osgbId: 'osgb-1', gateway: g, pilot: { firmExternalId: 'F-1' },
  });

  assert.equal(result.applied, false);
  assert.deepEqual(calls, { firma: 0, personel: 0, atama: 0 });
  assert.equal(result.counts.imported, 0);
});

test('PILOT-FLAG — gate kapalıyken istenen FULL_CONTROLLED_IMPORT bile DRY_RUN\'a zorlanır', () => {
  assert.equal(resolveEffectiveMode('FULL_CONTROLLED_IMPORT', false), 'DRY_RUN');
  assert.equal(resolveEffectiveMode('SAFE_IMPORT', false), 'DRY_RUN');
  assert.equal(ISG_KATIP_IMPORT_DEFAULT_ENABLED, false);
});

/* ========================================================================== */
/* FAZ 6J — WRITE ÖNCESİ SON KONTROL (madde 12)                                */
/* ========================================================================== */

test('PILOT-PREWRITE — temiz pilot: safeToWrite true, blockingReasons boş', () => {
  const plan = planOf(
    payload({
      firms: [firm({ externalId: 'F-1' })],
      personnel: [personel({ externalId: 'P-1' })],
      assignments: [atama({ externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1' })],
    }),
    snapshot({
      firms: [localFirma({ id: 'lf-1', isgKatipId: 'F-1' })],
      personnel: [localPersonel({ id: 'lp-1', isgKatipId: 'P-1' })],
      assignments: [localAtama({ id: 'la-1', isgKatipId: 'S-1' })],
    }),
  );

  const summary = buildPilotPreWriteSummary(plan, { firmExternalId: 'F-1' });
  assert.equal(summary.safeToWrite, true);
  assert.equal(summary.blockingReasons.length, 0);
  assert.equal(summary.firm?.status, 'MATCHED');
  assert.equal(summary.assignments.rows[0].baslangicTarihi, '2026-01-01');
});

test('PILOT-PREWRITE — personel çakışması varsa safeToWrite false (WRITE YOK)', () => {
  const plan = planOf(
    payload({
      firms: [firm({ externalId: 'F-1' })],
      // ext P-1 ama TC yerel başka İSG-KATİP kimliğine bağlı → CONFLICT (EXTERNAL_ID_TAKEN)
      personnel: [personel({ externalId: 'P-1', tcKimlikNo: '11111111111' })],
      assignments: [atama({ externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1' })],
    }),
    snapshot({
      firms: [localFirma({ id: 'lf-1', isgKatipId: 'F-1' })],
      personnel: [localPersonel({ id: 'lp-1', tcKimlikNo: '11111111111', isgKatipId: 'OTHER' })],
    }),
  );

  const summary = buildPilotPreWriteSummary(plan, { firmExternalId: 'F-1' });
  assert.equal(summary.safeToWrite, false);
  assert.ok(summary.blockingReasons.length > 0);
  assert.equal(summary.personnel.conflict, 1);
});

test('PILOT-PREWRITE — pilot firma planda yoksa safeToWrite false', () => {
  const plan = planOf(payload({ firms: [firm({ externalId: 'F-1' })] }), snapshot());
  const summary = buildPilotPreWriteSummary(plan, { firmExternalId: 'YOK' });
  assert.equal(summary.safeToWrite, false);
  assert.equal(summary.firm, null);
});

/* ========================================================================== */
/* FAZ 6I — DRY RUN SAYAÇLARI (unknown* dahil)                                 */
/* ========================================================================== */

test('DRY6I — rapor unknown* sayaçları unresolved ile aynı ve applied/importEnabled false', () => {
  const plan = planOf(
    payload({
      firms: [firm({ externalId: 'F-3', name: 'MASKED FIRMA' })], // isim benzerliği → UNRESOLVED
      personnel: [personel({ externalId: null, tcKimlikNo: null })], // kimlik yok → UNRESOLVED
    }),
    snapshot({ firms: [localFirma({ id: 'lf-3', unvan: 'MASKED FIRMA', isgKatipId: null })] }),
  );

  const report = buildDryRunReport({ plan, unresolvedRoles: 2 });
  assert.equal(report.applied, false);
  assert.equal(report.importEnabled, false);
  assert.deepEqual(report.unknown, report.unresolved);
  assert.equal(report.unknown.firms, 1);
  assert.equal(report.unknown.persons, 1);
  assert.equal(report.unknown.roles, 2);
});

/* ========================================================================== */
/* FAZ 6J — IDEMPOTENCY (DB write olmadan)                                     */
/* ========================================================================== */

test('PILOT-IDEMPOTENCY — aynı pilot payload 2. kez: duplicate CREATE yok (MATCHED)', async () => {
  const p = payload({
    firms: [firm({ externalId: 'F-1' })],
    personnel: [personel({ externalId: 'P-1' })],
    assignments: [atama({ externalId: 'S-1', firmaExternalId: 'F-1', personelExternalId: 'P-1' })],
  });

  // 1. çalışma: hiçbir yerel kayıt yok → hepsi NEW.
  const first = planOf(p, snapshot());
  assert.equal(first.firms[0].status, 'NEW');

  // 2. çalışma: KATİP id'leri artık yerelde (aynı external ID) → hepsi MATCHED, CREATE yok.
  const second = planOf(
    p,
    snapshot({
      firms: [localFirma({ id: 'lf-1', isgKatipId: 'F-1' })],
      personnel: [localPersonel({ id: 'lp-1', isgKatipId: 'P-1' })],
      assignments: [localAtama({ id: 'la-1', isgKatipId: 'S-1' })],
    }),
  );
  const scoped = applyPilotScope(second, { firmExternalId: 'F-1' });
  assert.equal(scoped.operations.filter((o) => o.action === 'CREATE').length, 0);

  const { calls, g } = recordingGateway();
  const result = await executeImportPlan({
    plan: second, snapshot: snapshot(), mode: 'FULL_CONTROLLED_IMPORT', importEnabled: true,
    osgbId: 'osgb-1', gateway: g, pilot: { firmExternalId: 'F-1' },
  });
  // MATCHED kayıtlar snapshot'ta bulunamazsa bile NOOP'a düşer → yeni INSERT yok.
  assert.equal(result.counts.imported, 0);
  assert.equal(calls.firma + calls.personel + calls.atama, 0);
});