/**
 * Content script (ISOLATED world) — İSGDenetim İÇ-RÖLESİ (FAZ 6J.3).
 *
 * NEDEN VAR: İSGDenetim sekmesi MAIN-world köprü aktivasyon tutamağını
 * (`window.__ISG_KATIP_SPA_BRIDGE__`) her sayfa yüklemesinde (F5 / navigation / SPA reload)
 * yeniden yayınlar. Ancak popup'ın `chrome.tabs.sendMessage` ile ulaşabileceği ISOLATED-world
 * bir röle olmadan bu tutamağa erişilemez. Önceki çözüm röleyi yalnızca `executeScript` +
 * activeTab ile AKTİF sekmeye enjekte ediyordu → F5'te röle yok oluyordu ve arka plandaki
 * sekmeye host izni olmadan yeniden enjekte edilemiyordu.
 *
 * ÇÖZÜM: Bu DECLARATIVE content script yalnızca İSGDenetim origin'inde çalışır ve röleyi
 * HER sayfa yüklemesinde OTOMATİK kurar. Böylece F5 sonrası aktif sekme KATİP olsa bile
 * röle yeniden oluşur; popup aktif sekmeye bağlı KALMADAN köprüye ulaşır.
 *
 * GÜVENLİK: KATİP'e inject EDİLMEZ, KATİP verisine erişmez, token/cookie/session/JWT
 * OKUMAZ/TAŞIMAZ, PII saklamaz, yeni ağ isteği atmaz, DB'ye yazmaz. Yalnızca aynı pencerede
 * `window.postMessage` ile SPA köprüsüne ileti gidip geri alır. KATİP verisi YALNIZCA kısa
 * süreli mesaj gövdesinde, kalıcılaştırılmadan taşınır.
 *
 * İdempotent: aynı frame'e birden fazla enjekte edilirse ikinci bir `onMessage` listener'ı
 * EKLENMEZ (global bayrak). Popup'ın `executeScript` rölesi de AYNI bayrağı kullandığı için
 * çift kurulum olmaz.
 */

const RELAY_FLAG = '__ISG_KATIP_DENETIM_RELAY__';
const relayGlobal = globalThis as unknown as Record<string, unknown>;

if (!relayGlobal[RELAY_FLAG]) {
  relayGlobal[RELAY_FLAG] = true;

  const HELLO = 'ISG_KATIP_BRIDGE_HELLO';
  const HELLO_ACK = 'ISG_KATIP_BRIDGE_HELLO_ACK';
  const DATA = 'ISG_KATIP_DRY_RUN_DATA';
  const RESULT = 'ISG_KATIP_DRY_RUN_RESULT';
  const PILOT = 'ISG_KATIP_PILOT_REQUEST';
  const PILOT_RESULT = 'ISG_KATIP_PILOT_RESULT';
  const APPLY = 'ISG_KATIP_PILOT_APPLY_REQUEST';
  const APPLY_RESULT = 'ISG_KATIP_PILOT_APPLY_RESULT';
  const EMP_SYNC_REQUEST = 'ISG_KATIP_EMP_SYNC_REQUEST';
  const EMP_SYNC_RESULT = 'ISG_KATIP_EMP_SYNC_RESULT';
  const V = 1;

  /**
   * FAZ 6J.2 — TEŞHİS LOGU (yalnızca teknik lifecycle/handshake olayları).
   * KATİP token/cookie/JWT/PII/response body ASLA loglanmaz; yalnızca olay adı + origin
   * gibi teknik bilgi loglanır. Gerçek Chrome testinde handshake'in hangi adımda kesildiğini
   * görebilmek için bırakılmıştır.
   */
  function relayLog(event: string, extra?: Record<string, unknown>): void {
    try {
      // eslint-disable-next-line no-console
      console.debug('[ISG-RELAY]', event, extra ?? '');
    } catch {
      // yoksay: loglama hatası akışı etkilemez.
    }
  }

  interface RelayResult {
    ok: boolean;
    status: string;
    result?: unknown;
    pilot?: unknown;
    apply?: unknown;
    sync?: unknown;
    error?: string;
  }

  /** Payload tipi: dryrun/pilot için satırlar; apply için ek olarak pilot firma kimliği. */
  interface RelayPayload {
    hizmetRows: unknown[];
    personelRows: unknown[];
    capturedAt: string;
    pilotFirmExternalId?: string;
    osgbIdHint?: string | null;
  }

  /** Türden istek/yanıt kanallarını çözer (FAZ 6J.3: apply kanalı eklendi). */
  function channelsFor(kind: 'dryrun' | 'pilot' | 'apply'): { req: string; res: string[] } {
    if (kind === 'apply') return { req: APPLY, res: [APPLY_RESULT] };
    if (kind === 'pilot') return { req: PILOT, res: [PILOT_RESULT] };
    return { req: DATA, res: [RESULT] };
  }

  /**
   * MAIN-world SPA köprüsüyle el sıkışıp Dry Run / Pilot / Pilot APPLY sonucunu getirir.
   * Her çağrıdan önce köprünün idempotent `install()` tutamağı çağrılır (self-healing).
   */
  function exchange(kind: 'dryrun' | 'pilot' | 'apply', payload: RelayPayload): Promise<RelayResult> {
    relayLog('EXCHANGE_START', { kind });
    try {
      const gg = window as unknown as Record<string, unknown>;
      const br = gg.__ISG_KATIP_SPA_BRIDGE__ as { install?: () => unknown } | undefined;
      if (br && typeof br.install === 'function') br.install();
    } catch {
      // yoksay: listener zaten kurulu olabilir (idempotent).
    }

    const ch = channelsFor(kind);
    return new Promise((resolve) => {
      const origin = window.location.origin;
      let settled = false;
      const finish = (r: RelayResult): void => {
        if (settled) return;
        settled = true;
        window.removeEventListener('message', onMessage);
        relayLog('EXCHANGE_DONE', { kind, status: r.status });
        resolve(r);
      };
      const onMessage = (event: MessageEvent): void => {
        if (event.source !== window) return;
        const d = event.data as Record<string, unknown> | null;
        if (!d || typeof d !== 'object') return;
        if (d.channel === HELLO_ACK) {
          const body: Record<string, unknown> = {
            channel: ch.req,
            v: V,
            hizmetRows: payload.hizmetRows,
            personelRows: payload.personelRows,
            capturedAt: payload.capturedAt,
          };
          if (kind === 'apply') {
            body.pilotFirmExternalId = payload.pilotFirmExternalId;
            body.osgbIdHint = payload.osgbIdHint ?? null;
          }
          window.postMessage(body, origin);
          return;
        }
        if (ch.res.includes(String(d.channel))) {
          finish({
            ok: Boolean(d.ok),
            status: typeof d.status === 'string' ? d.status : 'UNKNOWN',
            result: d.result,
            pilot: d.pilot,
            apply: d.apply,
            error: typeof d.error === 'string' ? d.error : undefined,
          });
        }
      };
      window.addEventListener('message', onMessage);
      window.postMessage({ channel: HELLO, v: V }, origin);
      window.setTimeout(() => {
        finish({ ok: false, status: 'BRIDGE_NOT_READY', error: 'İSGDenetim köprüsü yanıt vermedi (zaman aşımı).' });
      }, 12000);
    });
  }

  /**
   * SPA köprüsünün AKTİF olduğunu gerçek HELLO → HELLO_ACK el sıkışmasıyla doğrular.
   * Yalnızca ACK gerçekten alınır SA true döner (sahte READY yok). DATA göndermez.
   */
  function probeBridgeAck(timeoutMs: number): Promise<boolean> {
    return new Promise((resolve) => {
      const origin = window.location.origin;
      let settled = false;
      const onMessage = (event: MessageEvent): void => {
        if (event.source !== window) return;
        const d = event.data as Record<string, unknown> | null;
        if (!d || d.channel !== HELLO_ACK) return;
        settled = true;
        window.removeEventListener('message', onMessage);
        resolve(true);
      };
      window.addEventListener('message', onMessage);
      relayLog('HELLO_SENT');
      window.postMessage({ channel: HELLO, v: V }, origin);
      window.setTimeout(() => {
        window.removeEventListener('message', onMessage);
        if (!settled) resolve(false);
      }, timeoutMs);
    });
  }

  /**
   * v1.0.0 — OTOMATİK ÇALIŞAN SAYISI SENKRONU: MAIN-world SPA köprüsüne "eşleşmiş firmaların
   * çalışan sayısını senkronize et" isteği gönderir. Gerçek okuma + yazma SPA tarafında
   * (Supabase oturumu + RLS) yapılır. Yeni KATİP HTTP isteği ATILMAZ; token/cookie/JWT taşınmaz.
   */
  function exchangeEmpSync(): Promise<RelayResult> {
    relayLog('EMP_SYNC_START');
    try {
      const gg = window as unknown as Record<string, unknown>;
      const br = gg.__ISG_KATIP_SPA_BRIDGE__ as { install?: () => unknown } | undefined;
      if (br && typeof br.install === 'function') br.install();
    } catch {
      // yoksay
    }
    return new Promise((resolve) => {
      const origin = window.location.origin;
      let settled = false;
      const finish = (r: RelayResult): void => {
        if (settled) return;
        settled = true;
        window.removeEventListener('message', onMessage);
        relayLog('EMP_SYNC_DONE', { status: r.status });
        resolve(r);
      };
      const onMessage = (event: MessageEvent): void => {
        if (event.source !== window) return;
        const d = event.data as Record<string, unknown> | null;
        if (!d || typeof d !== 'object') return;
        if (d.channel === HELLO_ACK) {
          window.postMessage({ channel: EMP_SYNC_REQUEST, v: V }, origin);
          return;
        }
        if (d.channel === EMP_SYNC_RESULT) {
          finish({
            ok: Boolean(d.ok),
            status: typeof d.status === 'string' ? d.status : 'UNKNOWN',
            sync: d.sync,
            error: typeof d.error === 'string' ? d.error : undefined,
          });
        }
      };
      window.addEventListener('message', onMessage);
      window.postMessage({ channel: HELLO, v: V }, origin);
      window.setTimeout(() => {
        finish({ ok: false, status: 'BRIDGE_NOT_READY', error: 'İSGDenetim köprüsü yanıt vermedi (zaman aşımı).' });
      }, 30000);
    });
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const m = message as
      | {
          type?: string;
          payload?: {
            hizmetRows: unknown[];
            personelRows: unknown[];
            capturedAt: string;
            pilotFirmExternalId?: string;
            osgbIdHint?: string | null;
          };
        }
      | undefined;
    if (!m) return false;
    // Hafif ping: SPA köprü kurulum tutamağı canlı mı? (yan etkisiz, gerçek state keşfi)
    // SAHTE READY YOK: gerçek HELLO → HELLO_ACK doğrulanmadan 'BRIDGE_READY' denmez.
    if (m.type === 'ISG_KATIP_RELAY_PING') {
      // FAZ 6J.2 — KÖK NEDEN DÜZELTMESİ: SPA köprü tutamağı `window.__ISG_KATIP_SPA_BRIDGE__`
      // MAIN world'de yayınlanır ve İZOLASYON nedeniyle bu izole-dünya rölesinden OKUNAMAZ.
      // Bu yüzden tutamağın varlığını kontrol edip ERKEN DÖNMÜYORUZ; köprü listener'ı popup
      // tarafından MAIN world'de kurulur. Röle yalnızca GERÇEK HELLO→HELLO_ACK el sıkışmasını
      // dener (ACK alınmadan 'BRIDGE_READY' denmez — sahte READY YOK).
      relayLog('PING');
      void probeBridgeAck(1200).then((ack) => {
        relayLog(ack ? 'PONG' : 'NO_ACK');
        sendResponse({ ok: ack, status: ack ? 'BRIDGE_READY' : 'BRIDGE_NOT_READY' });
      });
      return true; // asenkron yanıt
    }
    if (m.type === 'ISG_KATIP_RELAY_EMP_SYNC') {
      void exchangeEmpSync().then(sendResponse);
      return true; // asenkron yanıt
    }
    if (
      m.type !== 'ISG_KATIP_RELAY_DRYRUN' &&
      m.type !== 'ISG_KATIP_RELAY_PILOT' &&
      m.type !== 'ISG_KATIP_RELAY_PILOT_APPLY'
    ) {
      return false;
    }
    if (!m.payload) {
      sendResponse({ ok: false, status: 'BRIDGE_NOT_READY', error: 'payload yok' });
      return false;
    }
    const kind: 'dryrun' | 'pilot' | 'apply' =
      m.type === 'ISG_KATIP_RELAY_PILOT_APPLY'
        ? 'apply'
        : m.type === 'ISG_KATIP_RELAY_PILOT'
          ? 'pilot'
          : 'dryrun';
    void exchange(kind, m.payload).then(sendResponse);
    return true; // asenkron yanıt
  });

  /*
   * FAZ 6J.4 — SPA → RÖLE: yakalanan KATİP işyerlerini iste (New Firma "İSG-KATİP'ten Aktar").
   * ADDITIVE kanaldır: mevcut dry-run/pilot/apply kanallarına DOKUNMAZ. SPA, aynı pencerede
   * `window.postMessage({ channel: 'ISG_KATIP_WORKSITES_REQUEST' })` yayınlar; röle service
   * worker'dan KATİP sekmesindeki READ-ONLY interception satırlarını ister ve aynı pencere/origin'e
   * geri gönderir. 🔒 Yeni KATİP HTTP isteği YOK; token/cookie/JWT taşınmaz.
   */
  const WORKSITES_REQUEST = 'ISG_KATIP_WORKSITES_REQUEST';
  const WORKSITES_RESULT = 'ISG_KATIP_WORKSITES_RESULT';
  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const d = event.data as Record<string, unknown> | null;
    if (!d || typeof d !== 'object') return;
    if (d.channel !== WORKSITES_REQUEST || d.v !== V) return;
    const origin = window.location.origin;
    try {
      chrome.runtime.sendMessage({ type: 'ISG_KATIP_RELAY_CAPTURED_REQUEST' }, (res) => {
        void chrome.runtime.lastError;
        const r = (res ?? {}) as {
          ok?: boolean;
          captured?: boolean;
          hizmetRows?: unknown[];
          personelRows?: unknown[];
          capturedAt?: string;
          dataset?: unknown;
          error?: string;
        };
        relayLog('WORKSITES_RESULT', { ok: Boolean(r.ok), captured: Boolean(r.captured) });
        try {
          window.postMessage(
            {
              channel: WORKSITES_RESULT,
              v: V,
              ok: Boolean(r.ok),
              captured: Boolean(r.captured),
              hizmetRows: r.hizmetRows ?? [],
              personelRows: r.personelRows ?? [],
              capturedAt: r.capturedAt ?? new Date().toISOString(),
              dataset: r.dataset,
              error: r.error,
            },
            origin,
          );
        } catch {
          // yoksay
        }
      });
    } catch {
      // yoksay: service worker yoksa talep sessizce başarısız olur (SPA zaman aşımına düşer).
    }
  });

  relayLog('BOOT', { origin: location.origin });

  // Service worker'a varlığı bildir (gerçek tab lifecycle takibi için; yan etkisiz).
  try {
    chrome.runtime.sendMessage({ type: 'ISG_DENETIM_PRESENT' }, () => {
      // Dinleyici yoksa lastError oluşur; yutulur (yan etkisiz).
      void chrome.runtime.lastError;
      relayLog('PRESENT_SENT');
    });
  } catch {
    // yoksay
  }
}