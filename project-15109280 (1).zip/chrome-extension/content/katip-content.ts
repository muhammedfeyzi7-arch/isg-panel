/**
 * Content script — İSG-KATİP sayfasında çalışan köprü (FAZ 6B → 6K).
 *
 * Görev: KATİP SPA'nın KENDİ gerçek isteklerinden (MAIN-world hook ile READ-ONLY) yakalanan
 * response'ları ham kayıt olarak alıp normalize sync payload'a VE PII-İÇERMEYEN discovery
 * raporuna dönüştürmek. İKİNCİ authenticated istek ATILMAZ; token/cookie hiçbir yerde
 * okunmaz/kopyalanmaz.
 *
 * READ-ONLY: KATİP üzerinde hiçbir yazma işlemi yapılmaz. Discovery yalnızca okur.
 */
import { createIsgKatipContentAdapter, isIsgKatipLocation } from '../adapters/isg-katip-adapter';
import { buildSyncPayload } from '../../src/lib/isgKatip/normalize';
import { collectRoleDiscovery } from '../../src/lib/isgKatip/roleDiscovery';
import { buildDiscoveryReport, type KatipEndpointDiagnostic } from '../../src/lib/isgKatip/discovery';
import {
  IsgKatipEndpointError,
  KATIP_HIZMET_SOZLESMESI_PATH,
  KATIP_PERSONEL_SOZLESMESI_PATH,
} from '../../src/lib/isgKatip/endpoints';
import type { ExtensionMessage } from '../shared/messages';
import type {
  KatipHizmetSozlesmesiRow,
  KatipPersonelSozlesmesiRow,
} from '../../src/lib/isgKatip/types';

/** İSG-KATİP'ten ham kayıtları çeker (READ-ONLY). Kimlik bilgisi TAŞIMAZ. */
async function fetchRows(): Promise<{
  hizmetRows: KatipHizmetSozlesmesiRow[];
  personelRows: KatipPersonelSozlesmesiRow[];
}> {
  if (!isIsgKatipLocation(window.location)) {
    throw new Error('Bu sekme İSG-KATİP sayfası değil.');
  }
  const adapter = createIsgKatipContentAdapter({
    isIsgKatipPage: true,
    // Sayfa yüklüyse oturum vardır; bu yalnızca boolean doğrulamadır, kimlik bilgisi DEĞİL.
    authenticated: true,
  });
  const [hizmetRows, personelRows] = await Promise.all([
    adapter.getHizmetSozlesmeleri(),
    adapter.getPersonelSozlesmeleri(),
  ]);
  return { hizmetRows, personelRows };
}

/**
 * İSG-KATİP'ten ham kayıtları çeker ve normalize eder.
 * `osgbId` burada BOŞ bırakılır: toplama işlemi yereldir; backend'e gönderim
 * (OSGB kapsamlı) ayrı bir adımdır. Import motoru bu fazda PASİFTİR.
 */
async function collect() {
  const { hizmetRows, personelRows } = await fetchRows();

  const built = buildSyncPayload({
    ctx: { osgbId: '', sourceVersion: '0.3.0' },
    hizmetRows,
    personelRows,
  });

  // normalize payload + dürüst ek metadata (unresolved = rol enum'u bekliyor).
  // FAZ 6G: rol discovery — gerçek response'taki enum değerlerini SALT GÖZLEMLE toplar.
  const roleDiscovery = collectRoleDiscovery({ hizmetRows, personelRows });
  return {
    payload: built.payload,
    unresolved: built.unresolved,
    personelSozlesmeleri: built.personelSozlesmeleri,
    counts: built.counts,
    roleDiscovery,
  };
}

/** Bir promise sonucundan PII-İÇERMEYEN endpoint teşhisi üretir (yalnızca kod + şekil özeti). */
function toDiagnostic(
  label: 'hizmet' | 'personel',
  endpoint: string,
  res: PromiseSettledResult<unknown[]>,
  rowCount: number,
): KatipEndpointDiagnostic {
  if (res.status === 'fulfilled') {
    return { endpoint, label, ok: true, rowCount };
  }
  const reason = res.reason;
  const isEndpointError = reason instanceof IsgKatipEndpointError;
  return {
    endpoint,
    label,
    ok: false,
    errorCode: isEndpointError ? reason.code : 'UNKNOWN',
    errorMessage: reason instanceof Error ? reason.message : 'Bilinmeyen hata',
    rowCount,
    shape: isEndpointError ? reason.shape ?? null : null,
  };
}

/**
 * READ-ONLY discovery raporu üretir (PII İÇERMEZ; hiçbir yazma yapmaz).
 * FAZ 6K RUNTIME DEBUG: iki endpoint BAĞIMSIZ okunur (allSettled). Bir endpoint hata verse
 * bile diğeri raporlanır ve hata, PII'siz ŞEKİL TEŞHİSİYLE (tip + alan adları + sayılar) birlikte
 * rapora/dışa taşınır. Böylece runtime'da GELEN GERÇEK DEĞER TAHMİN EDİLMEDEN görülür.
 */
async function discover() {
  if (!isIsgKatipLocation(window.location)) {
    throw new Error('Bu sekme İSG-KATİP sayfası değil.');
  }
  // FAZ 6K — İKİNCİ authenticated istek ATILMAZ. Adapter, KATİP SPA'nın KENDİ gerçek
  // isteğinden (MAIN-world hook) yakalanan response'u okur.
  const adapter = createIsgKatipContentAdapter({
    isIsgKatipPage: true,
    authenticated: true,
  });

  const [hizmetRes, personelRes] = await Promise.allSettled([
    adapter.getHizmetSozlesmeleri(),
    adapter.getPersonelSozlesmeleri(),
  ]);

  const hizmetRows = hizmetRes.status === 'fulfilled' ? hizmetRes.value : [];
  const personelRows = personelRes.status === 'fulfilled' ? personelRes.value : [];

  const diagnostics: KatipEndpointDiagnostic[] = [
    toDiagnostic('hizmet', KATIP_HIZMET_SOZLESMESI_PATH, hizmetRes, hizmetRows.length),
    toDiagnostic('personel', KATIP_PERSONEL_SOZLESMESI_PATH, personelRes, personelRows.length),
  ];

  // İKİ endpoint de başarısızsa, hata mesajını (şekil teşhisi dahil) yüzeye çıkar.
  if (hizmetRes.status === 'rejected' && personelRes.status === 'rejected') {
    // FAZ 6K — Hiçbir gerçek response henüz yakalanmadıysa açık, güvenli bir durum göster.
    if (diagnostics.every((d) => d.errorCode === 'NOT_CAPTURED')) {
      throw new Error(
        'KATİP ekranındaki verinin yüklenmesi bekleniyor. İlgili KATİP listesini ' +
          '(İSG Hizmet / Personel Sözleşmeleri) açın veya yenileyin; KATİP listeyi ' +
          'yüklediğinde veri otomatik yakalanır, ardından tekrar deneyin.',
      );
    }
    const details = diagnostics
      .map((d) => `${d.label}: ${d.errorCode ?? 'HATA'} — ${d.errorMessage ?? ''}`.trim())
      .join(' | ');
    throw new Error(details);
  }

  return buildDiscoveryReport({ hizmetRows, personelRows, diagnostics });
}

/*
 * FAZ 6I.1B.2 — KATİP-SIDE DRY RUN YOLU KALDIRILDI.
 *
 * Önceden burada `readCaptured()` + `dryRun()` vardı ve content script kendi başına
 * `buildKatipDryRun()` çağırıyordu. Bu sayfa bağlamında İSGDenetim OSGB snapshot'ı
 * MEVCUT OLMADIĞI için sonuç DETERMİNİSTİK olarak `LOCAL_SNAPSHOT_NOT_READY` oluyordu.
 *
 * Artık Dry Run için TEK KANONİK YOL İSGDenetim SPA tarafıdır:
 *   KATİP interception → Extension memory → SPA Bridge → runIsgDenetimDryRun()
 *   → fetchIsgDenetimDbSnapshot() → buildKatipDryRun() → RESULT
 *
 * Bu içerik betiği YALNIZCA gerçek KATİP response interception/verisini OKUMA görevinde
 * kalır (6K). Kendi başına Dry Run hesaplamaz; `LOCAL_SNAPSHOT_NOT_READY` üretemez.
 */

/**
 * FAZ 6K RUNTIME FIX — İDEMPOTENCY GUARD.
 * Popup, extension yeniden yüklendikten sonra eski sekmede orphan kalan betiği
 * `chrome.scripting.executeScript` ile YENİDEN enjekte edebilir. Bu durumda aynı frame'e
 * İKİNCİ bir `onMessage` listener'ı eklenmemesi gerekir (çift yanıt → port hatası).
 * Bu yüzden listener kaydı frame-global bir bayrakla BİR KEZ yapılır.
 */
const BRIDGE_FLAG = '__ISG_KATIP_BRIDGE_LOADED__';
const bridgeGlobal = globalThis as unknown as Record<string, unknown>;

if (!bridgeGlobal[BRIDGE_FLAG]) {
  bridgeGlobal[BRIDGE_FLAG] = true;

  chrome.runtime.onMessage.addListener((message: ExtensionMessage, _sender, sendResponse) => {
    // FAZ 6K — bağlantı durumu (veri çekmez; yalnızca sayfa eşleşmesi).
    if (message?.type === 'ISG_KATIP_STATUS_REQUEST') {
      const isKatip = isIsgKatipLocation(window.location);
      sendResponse({ type: 'ISG_KATIP_STATUS_RESULT', isKatip, ready: isKatip } as ExtensionMessage);
      return false; // senkron yanıt
    }

    // FAZ 6K — READ-ONLY discovery (gerçek KATİP oturumu gerekir).
    if (message?.type === 'ISG_KATIP_DISCOVERY_REQUEST') {
      discover()
        .then((report) => {
          sendResponse({ type: 'ISG_KATIP_DISCOVERY_RESULT', ok: true, report } as ExtensionMessage);
        })
        .catch((e: unknown) => {
          sendResponse({
            type: 'ISG_KATIP_DISCOVERY_RESULT',
            ok: false,
            error: e instanceof Error ? e.message : 'Discovery başarısız.',
          } as ExtensionMessage);
        });
      return true; // asenkron yanıt için kanalı açık tut.
    }

    // FAZ 6I.1B.2 — `ISG_KATIP_DRYRUN_REQUEST` handler'ı KALDIRILDI. Bu içerik betiği artık
    // Dry Run çalıştırmaz; Dry Run yalnızca SPA tarafındaki mevcut motorda (runIsgDenetimDryRun)
    // çalışır ve popup'a SPA köprüsü üzerinden döner.

    if (message?.type === 'ISG_KATIP_COLLECT_REQUEST') {
      collect()
        .then((result) => {
          sendResponse({
            type: 'ISG_KATIP_COLLECT_RESULT',
            ok: true,
            payload: result,
          } satisfies ExtensionMessage);
        })
        .catch((e: unknown) => {
          sendResponse({
            type: 'ISG_KATIP_COLLECT_RESULT',
            ok: false,
            error: e instanceof Error ? e.message : 'Toplama başarısız.',
          } satisfies ExtensionMessage);
        });
      return true; // asenkron yanıt için kanalı açık tut.
    }
    return false;
  });
}