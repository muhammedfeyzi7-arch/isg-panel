/**
 * MAIN world RESPONSE-OBSERVER hook'u (FAZ 6K + FAZ-DOC — READ-ONLY).
 *
 * AMAÇ: KATİP SPA'nın KENDİ gerçek XHR/fetch isteklerinin RESPONSE'unu SALT GÖZLEMLE
 * yakalamak. Böylece extension İKİNCİ bir authenticated istek ATMAZ; SPA'nın kendi
 * başarılı cevabını (ör. `body.tableData`) doğrudan discovery pipeline'ına verir.
 *
 * ÖNCEKİ YAKLAŞIM (ARTIK KULLANILMIYOR): SPA'nın auth başlığını yakalayıp kendi isteğine
 * eklemek. Bu yaklaşım auth/session bağlamı nedeniyle GÜVENİLİR DEĞİLDİ → TERK EDİLDİ.
 * Artık hiçbir başlık OKUNMAZ, hiçbir istek TAKLİT EDİLMEZ, hiçbir istek GÖNDERİLMEZ.
 *
 * KESİN KURALLAR:
 *  - SPA'nın ağ akışı BOZULMAZ: orijinal `open`/`send`/`fetch` AYNEN çağrılır.
 *  - İstek ENGELLENMEZ, DEĞİŞTİRİLMEZ, YENİDEN GÖNDERİLMEZ.
 *  - Hiçbir header OKUNMAZ/YAZILMAZ (token/Authorization tamamen kapsam dışıdır).
 *  - Yakalanan ham response YALNIZCA pencere-bağlamı bellek (`window.__ISG_KATIP_CAPTURED__`)
 *    içinde tutulur; sayfa kapanınca kaybolur. storage/log/console/UI/Supabase'e YAZILMAZ.
 *  - Yalnızca İKİ doğrulanmış KATİP endpoint'inin response'u dikkate alınır.
 *
 * FAZ-DOC EK: Aynı SALT-GÖZLEM mantığıyla KATİP'in belge (PDF vb.) yanıtları da
 * `window.__ISG_KATIP_DOC_CAPTURED__` altında (query'siz yol + gövde base64, YALNIZCA
 * bellek-içi) toplanır. Amaç: "sözleşme PDF'i hangi adresten/nasıl geliyor" sorusunu
 * tahmin etmeden KEŞFETMEK. Hiçbir veri hiçbir yere gönderilmez/yazılmaz.
 *
 * Bu betik `manifest.json`'da `world: "MAIN"`, `run_at: "document_start"` ile KATİP
 * origin'inde yüklenir.
 */
import {
  extractTableData,
  KATIP_HIZMET_SOZLESMESI_PATH,
  KATIP_PERSONEL_SOZLESMESI_PATH,
} from '../../src/lib/isgKatip/endpoints';
import {
  dedupeRows,
  readReportedPagination,
  readReportedTotal,
  summarizeCapture,
} from '../../src/lib/isgKatip/capture';

/** İzlenen iki endpoint yolu (yalnızca bu path'lerin response'u dikkate alınır). */
const WATCHED_PATHS: readonly string[] = [
  KATIP_HIZMET_SOZLESMESI_PATH,
  KATIP_PERSONEL_SOZLESMESI_PATH,
];

interface CapturedPage {
  pageIndex: number | null;
  pageSize: number | null;
  rows: Record<string, unknown>[];
  capturedAt: number;
}

interface CapturedPageMeta {
  pageIndex: number | null;
  pageSize: number | null;
  rowCount: number;
  capturedAt: number;
}

interface CapturedResponse {
  status: number | null;
  json: unknown;
  capturedAt: number;
  /** Sayfa-bağımsız BİRLEŞİK (tekilleştirilmiş) gerçek satırlar; okuyucular yalnızca bunu okur. */
  rows: Record<string, unknown>[];
  /** Yakalanan ham sayfalar (pagination aggregation). */
  pages: CapturedPage[];
  /** Okuyucular için PII'siz sayfa metadata'sı. */
  meta: CapturedPageMeta[];
  /** Yanıt metadata'sında toplam kayıt (varsa). Yoksa null. */
  reportedTotal: number | null;
  /** FAZ 1 — yanıt metadata'sından okunan SAYISAL pagination (varsa; PII değil). */
  pagination: { totalCount: number | null; totalPages: number | null } | null;
  /** FAZ 1 — capture oturum (generation) kimliği; navigation sonrası eski veri karışmasın. */
  sessionId: number;
}

/** FAZ-DOC — bir belge yanıtı/gözleminin PII'siz metadata'sı (+ isteğe bağlı bellek-içi gövde). */
interface CapturedDoc {
  id: number;
  source: 'xhr' | 'fetch' | 'navigation';
  method: string;
  /** Query'siz yol (gizli/oturum parametreleri SAKLANMAZ). */
  path: string;
  hasQuery: boolean;
  contentType: string | null;
  status: number | null;
  size: number | null;
  capturedAt: number;
  bodyKind: 'pdf' | 'image' | 'binary' | 'text' | 'unknown';
  fileName: string | null;
  /** Base64 gövde — YALNIZCA pencere belleğinde; hiçbir yere yazılmaz/gönderilmez. */
  bodyB64: string | null;
  bodyTruncated: boolean;
  note: string | null;
}

interface HookWindow {
  __ISG_KATIP_HOOK__?: boolean;
  __ISG_KATIP_CAPTURED__?: Record<string, CapturedResponse>;
  __ISG_KATIP_DOC_CAPTURED__?: CapturedDoc[];
  fetch: typeof fetch;
  open: typeof window.open;
}

(() => {
  const w = window as unknown as HookWindow;
  // İdempotency: yeniden enjeksiyonda ikinci kez patch YAPMA.
  if (w.__ISG_KATIP_HOOK__) return;
  w.__ISG_KATIP_HOOK__ = true;

  const store: Record<string, CapturedResponse> =
    (w.__ISG_KATIP_CAPTURED__ = w.__ISG_KATIP_CAPTURED__ ?? {});

  /* ------------------------------------------------------------------ */
  /* FAZ-DOC — KATİP BELGE/PDF KEŞİF GÖZLEMCİSİ (READ-ONLY, BELLEK-İÇİ)   */
  /* ------------------------------------------------------------------ */
  const DOC_MAX_ENTRIES = 40;
  const DOC_MAX_BODY_BYTES = 12 * 1024 * 1024;
  const DOC_PATH_RE =
    /(pdf|print|yazdir|belge|dokuman|document|sozlesme|indir|download|cikti|rapor|dosya|file|attachment|eklenti)/i;

  const docStore: CapturedDoc[] = Array.isArray(w.__ISG_KATIP_DOC_CAPTURED__)
    ? (w.__ISG_KATIP_DOC_CAPTURED__ as CapturedDoc[])
    : [];
  w.__ISG_KATIP_DOC_CAPTURED__ = docStore;
  let docSeq = docStore.reduce(
    (max, d) => (typeof d?.id === 'number' && d.id > max ? d.id : max),
    0,
  );

  const isKatipHostname = (host: string): boolean =>
    host.includes('isgkatip') && host.endsWith('csgb.gov.tr');

  const parseKatipUrl = (raw: unknown): URL | null => {
    if (typeof raw !== 'string' || raw.length === 0) return null;
    try {
      const u = new URL(raw, window.location.href);
      return isKatipHostname(u.hostname.toLowerCase()) ? u : null;
    } catch {
      return null;
    }
  };

  /** İzlenen iki JSON listesi dışındaki KATİP istekleri belge adayıdır. */
  const resolveDocCandidate = (raw: unknown): URL | null => {
    const u = parseKatipUrl(raw);
    if (!u) return null;
    return WATCHED_PATHS.includes(u.pathname) ? null : u;
  };

  const looksLikeDocPath = (u: URL): boolean =>
    DOC_PATH_RE.test(u.pathname) || DOC_PATH_RE.test(u.search);

  const isJsonLike = (ct: string | null | undefined): boolean => {
    const c = (ct ?? '').toLowerCase();
    if (!c) return false;
    return (
      c.includes('json') ||
      c.includes('javascript') ||
      c.includes('text/html') ||
      c.includes('text/css') ||
      c.includes('text/plain')
    );
  };

  const classifyKind = (
    ct: string | null | undefined,
    bytes: Uint8Array | null,
  ): CapturedDoc['bodyKind'] => {
    const c = (ct ?? '').toLowerCase();
    if (c.includes('pdf')) return 'pdf';
    if (
      bytes &&
      bytes.length >= 5 &&
      bytes[0] === 0x25 &&
      bytes[1] === 0x50 &&
      bytes[2] === 0x44 &&
      bytes[3] === 0x46
    ) {
      return 'pdf';
    }
    if (c.includes('image/')) return 'image';
    if (
      c.includes('octet-stream') ||
      c.includes('zip') ||
      c.includes('msword') ||
      c.includes('excel') ||
      c.includes('officedocument') ||
      c.includes('powerpoint')
    ) {
      return 'binary';
    }
    if (c.includes('text') || c.includes('html') || c.includes('xml') || c.includes('csv')) {
      return 'text';
    }
    return c ? 'binary' : 'unknown';
  };

  const readFileName = (cd: string | null | undefined): string | null => {
    if (!cd) return null;
    const m = /filename\*?=(?:UTF-8''|")?([^";]+)/i.exec(cd);
    if (!m) return null;
    const cleaned = m[1].replace(/"/g, '').trim();
    try {
      return decodeURIComponent(cleaned);
    } catch {
      return cleaned;
    }
  };

  const abToBase64 = (bytes: Uint8Array): string => {
    let binary = '';
    const chunk = 0x8000;
    for (let i = 0; i < bytes.length; i += chunk) {
      binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk) as unknown as number[]);
    }
    return btoa(binary);
  };

  const pushDocMeta = (init: {
    source: CapturedDoc['source'];
    method: string;
    u: URL;
    ct: string | null;
    status: number | null;
    size: number | null;
    cd: string | null;
  }): CapturedDoc => {
    docSeq += 1;
    const doc: CapturedDoc = {
      id: docSeq,
      source: init.source,
      method: (init.method || 'GET').toUpperCase(),
      // QUERY AYRIŞTIRILMAZ: gizli/oturum parametreleri rapora GİRMEZ.
      path: init.u.pathname,
      hasQuery: init.u.search.length > 0,
      contentType: init.ct ?? null,
      status: typeof init.status === 'number' ? init.status : null,
      size: typeof init.size === 'number' ? init.size : null,
      capturedAt: Date.now(),
      bodyKind: classifyKind(init.ct, null),
      fileName: readFileName(init.cd),
      bodyB64: null,
      bodyTruncated: false,
      note: null,
    };
    docStore.push(doc);
    while (docStore.length > DOC_MAX_ENTRIES) docStore.shift();
    return doc;
  };

  const attachDocBody = (doc: CapturedDoc, bytes: Uint8Array, ct: string | null): void => {
    doc.bodyKind = classifyKind(ct, bytes);
    doc.size = bytes.length;
    if (bytes.length > DOC_MAX_BODY_BYTES) {
      doc.bodyTruncated = true;
      doc.note = 'Belge 12 MB sınırını aştığı için içerik saklanmadı.';
      return;
    }
    try {
      doc.bodyB64 = abToBase64(bytes);
    } catch {
      doc.bodyB64 = null;
      doc.note = 'Belge içeriği okunamadı.';
    }
  };

  const captureDocFromBlob = (
    blob: Blob,
    init: {
      source: CapturedDoc['source'];
      method: string;
      u: URL;
      ct: string | null;
      status: number | null;
      cd: string | null;
    },
  ): void => {
    const doc = pushDocMeta({ ...init, size: blob.size });
    const kindGuess = classifyKind(init.ct ?? blob.type ?? null, null);
    if (kindGuess === 'image' || kindGuess === 'text') {
      doc.note = 'Belge içeriği saklanmadı (yalnızca meta).';
      return;
    }
    if (blob.size > DOC_MAX_BODY_BYTES) {
      doc.bodyTruncated = true;
      doc.note = 'Belge 12 MB sınırını aştığı için içerik saklanmadı.';
      return;
    }
    try {
      const fr = new FileReader();
      fr.onload = () => {
        try {
          const res = String(fr.result || '');
          const idx = res.indexOf(',');
          doc.bodyB64 = idx >= 0 ? res.slice(idx + 1) : null;
          doc.bodyKind = classifyKind(init.ct ?? blob.type ?? null, null);
        } catch {
          /* yoksay */
        }
      };
      fr.onerror = () => {
        doc.note = 'Belge içeriği okunamadı.';
      };
      fr.readAsDataURL(blob);
    } catch {
      /* yoksay */
    }
  };

  /** Verilen URL izlenen iki KATİP endpoint'inden biri mi? Eşleşirse path döner. */
  const resolveWatchedPath = (raw: unknown): string | null => {
    if (typeof raw !== 'string' || raw.length === 0) return null;
    try {
      const u = new URL(raw, window.location.href);
      const host = u.hostname.toLowerCase();
      if (!(host.includes('isgkatip') && host.endsWith('csgb.gov.tr'))) return null;
      return WATCHED_PATHS.includes(u.pathname) ? u.pathname : null;
    } catch {
      return null;
    }
  };

  /** Sayısal alanı güvenli okur (yoksa null). */
  const readNum = (v: unknown): number | null => {
    if (typeof v === 'number' && Number.isFinite(v)) return v;
    if (typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v))) return Number(v);
    return null;
  };

  /** İstek gövdesinden pageIndex/pageSize okur (XHR: string|object; fetch: body). Tahmin YOK. */
  const tryParseBody = (raw: unknown): Record<string, unknown> | null => {
    if (raw == null) return null;
    if (typeof raw === 'string') {
      try {
        const p = JSON.parse(raw);
        return p && typeof p === 'object' ? (p as Record<string, unknown>) : null;
      } catch {
        return null;
      }
    }
    if (typeof raw === 'object') return raw as Record<string, unknown>;
    return null;
  };

  /**
   * Yakalanan response'u YALNIZCA pencere belleğine yazar (başka hiçbir yere değil).
   * SAYFA-BAZLI AGGREGATION: KATİP SPA'nın KENDİ pagination istekleri (pageIndex) gözlemlendiği
   * sürece her sayfa BİRİKTİRİLİR ve satırlar KİMLİK (uniqueId/sozlesmeId) ile tekilleştirilir.
   * Aynı sayfa tekrar gelirse ÜZERİNE yazılır (duplicate sayılmaz). Extension KENDİ isteğini ATMAZ.
   */
  const capture = (
    path: string,
    status: number | null,
    json: unknown,
    reqBody: Record<string, unknown> | null,
  ): void => {
    let pageRows: Record<string, unknown>[] = [];
    try {
      pageRows = extractTableData(json) as Record<string, unknown>[];
    } catch {
      pageRows = [];
    }
    const pageIndex = readNum(reqBody?.pageIndex);
    const pageSize = readNum(reqBody?.pageSize);
    const prev = store[path];
    // FAZ 1 — CAPTURE SESSION ISOLATION: Yeni bir sayfa-0 isteği, önceki döngü ZATEN
    // TAMAMLANMIŞSA yeni bir capture oturumu başlatır; eski sayfalar yeni dataset'e
    // taşınmaz. Aynı döngü içindeki sayfa tekrarı ise mevcut sayfayı GÜNCELLER (dedupe).
    let pages: CapturedPage[] = prev?.pages ? prev.pages.slice() : [];
    let sessionId = prev?.sessionId ?? 1;
    if (pageIndex === 0 && prev) {
      const prevComplete = summarizeCapture(path, {
        rows: prev.rows,
        meta: prev.meta,
        reportedTotal: prev.reportedTotal,
        capturedAt: prev.capturedAt,
      }).complete;
      if (prevComplete) {
        pages = [];
        sessionId = (prev.sessionId ?? 1) + 1;
      }
    }
    const page: CapturedPage = { pageIndex, pageSize, rows: pageRows, capturedAt: Date.now() };
    if (pageIndex != null) {
      const idx = pages.findIndex((p) => p.pageIndex === pageIndex);
      if (idx >= 0) pages[idx] = page;
      else pages.push(page);
    } else {
      pages.push(page);
    }
    const merged: Record<string, unknown>[] = [];
    for (const p of pages) for (const r of p.rows) merged.push(r);
    store[path] = {
      status: typeof status === 'number' ? status : null,
      json,
      capturedAt: Date.now(),
      rows: dedupeRows(merged),
      pages,
      meta: pages.map((p) => ({
        pageIndex: p.pageIndex,
        pageSize: p.pageSize,
        rowCount: p.rows.length,
        capturedAt: p.capturedAt,
      })),
      reportedTotal: readReportedTotal(json),
      pagination: readReportedPagination(json),
      sessionId,
    };
  };

  // ---- XMLHttpRequest (Angular HttpClient / axios varsayılan taşıması) ----
  try {
    const proto = XMLHttpRequest.prototype;
    const rawOpen = proto.open;
    const rawSend = proto.send;
    const meta = new WeakMap<
      XMLHttpRequest,
      { path: string | null; doc: URL | null; method: string }
    >();

    proto.open = function open(this: XMLHttpRequest, ...args: unknown[]): void {
      try {
        const method = typeof args[0] === 'string' ? args[0] : 'GET';
        meta.set(this, {
          path: resolveWatchedPath(args[1]),
          doc: resolveDocCandidate(args[1]),
          method,
        });
      } catch {
        /* yoksay */
      }
      (rawOpen as (...a: unknown[]) => void).apply(this, args);
    } as typeof proto.open;

    proto.send = function send(this: XMLHttpRequest, ...args: unknown[]): void {
      try {
        const m = meta.get(this);
        if (m?.path) {
          const path = m.path;
          const reqBody = tryParseBody(args[0]);
          // SALT GÖZLEM: yalnızca bir 'load' dinleyicisi ekleriz; SPA'nın kendi handler'ı
          // korunur, istek değiştirilmez. Yanıt tamamlandığında okunup saklanır.
          this.addEventListener('load', () => {
            try {
              const rt = this.responseType;
              let json: unknown = null;
              if (rt === '' || rt === 'text') {
                const text = this.responseText;
                json = text ? JSON.parse(text) : null;
              } else if (rt === 'json') {
                json = this.response;
              } else {
                return; // arraybuffer/blob/document → parse edilmez (SPA davranışı korunur)
              }
              capture(path, this.status, json, reqBody);
            } catch {
              /* parse hatası → SPA akışına dokunmadan yoksay */
            }
          });
        }
        // FAZ-DOC — belge adayı yanıtları (SALT GÖZLEM; SPA davranışı korunur).
        if (m?.doc) {
          const docUrl = m.doc;
          const docMethod = m.method;
          this.addEventListener('load', () => {
            try {
              const ct = this.getResponseHeader('content-type');
              const cd = this.getResponseHeader('content-disposition');
              const cl = this.getResponseHeader('content-length');
              const sizeHeader = cl != null && Number.isFinite(Number(cl)) ? Number(cl) : null;
              const rt = this.responseType;
              if (rt === 'blob' && this.response instanceof Blob) {
                captureDocFromBlob(this.response as Blob, {
                  source: 'xhr',
                  method: docMethod,
                  u: docUrl,
                  ct: (this.response as Blob).type || ct,
                  status: this.status,
                  cd,
                });
                return;
              }
              if (rt === 'arraybuffer' && this.response instanceof ArrayBuffer) {
                const bytes = new Uint8Array(this.response as ArrayBuffer);
                const doc = pushDocMeta({
                  source: 'xhr',
                  method: docMethod,
                  u: docUrl,
                  ct,
                  status: this.status,
                  size: bytes.length,
                  cd,
                });
                attachDocBody(doc, bytes, ct);
                return;
              }
              if ((rt === '' || rt === 'text') && ct && !isJsonLike(ct)) {
                const doc = pushDocMeta({
                  source: 'xhr',
                  method: docMethod,
                  u: docUrl,
                  ct,
                  status: this.status,
                  size: sizeHeader,
                  cd,
                });
                if (doc.bodyKind === 'text') doc.note = 'Metin yanıtı (içerik saklanmadı).';
              }
            } catch {
              /* yoksay */
            }
          });
        }
      } catch {
        /* yoksay */
      }
      (rawSend as (...a: unknown[]) => void).apply(this, args);
    } as typeof proto.send;
  } catch {
    /* yoksay */
  }

  // ---- fetch (SPA fetch tabanlıysa) ----
  try {
    const rawFetch = w.fetch;
    if (typeof rawFetch === 'function') {
      w.fetch = function patchedFetch(
        input: RequestInfo | URL,
        init?: RequestInit,
      ): Promise<Response> {
        let path: string | null = null;
        let docUrl: URL | null = null;
        let method = 'GET';
        try {
          const url =
            typeof input === 'string'
              ? input
              : input instanceof Request
                ? input.url
                : input instanceof URL
                  ? input.href
                  : '';
          path = resolveWatchedPath(url);
          docUrl = resolveDocCandidate(url);
          method = init?.method ?? (input instanceof Request ? input.method : 'GET');
        } catch {
          path = null;
          docUrl = null;
        }
        const promise = rawFetch.call(w, input, init);
        if (path) {
          const p = path;
          // SALT GÖZLEM: yanıtı CLONE ile okuruz; SPA'nın kendi gövdesi tüketilmez/değişmez.
          promise
            .then((res) => {
              try {
                res
                  .clone()
                  .json()
                  .then((json) => capture(p, res.status, json, tryParseBody(init?.body)))
                  .catch(() => {
                    /* gövde JSON değil → yoksay */
                  });
              } catch {
                /* clone desteklenmiyor → yoksay */
              }
            })
            .catch(() => {
              /* ağ hatası → yoksay */
            });
        }
        // FAZ-DOC — belge adayı yanıtları (SALT GÖZLEM; clone ile okunur).
        if (docUrl) {
          const du = docUrl;
          const dm = method;
          promise
            .then((res) => {
              try {
                const ct = res.headers.get('content-type');
                if (!ct || isJsonLike(ct)) return;
                const cd = res.headers.get('content-disposition');
                const cl = res.headers.get('content-length');
                const sizeHeader = cl != null && Number.isFinite(Number(cl)) ? Number(cl) : null;
                const kindGuess = classifyKind(ct, null);
                if (kindGuess === 'image' || kindGuess === 'text') {
                  pushDocMeta({
                    source: 'fetch',
                    method: dm,
                    u: du,
                    ct,
                    status: res.status,
                    size: sizeHeader,
                    cd,
                  });
                  return;
                }
                res
                  .clone()
                  .arrayBuffer()
                  .then((buf) => {
                    const doc = pushDocMeta({
                      source: 'fetch',
                      method: dm,
                      u: du,
                      ct,
                      status: res.status,
                      size: buf.byteLength,
                      cd,
                    });
                    attachDocBody(doc, new Uint8Array(buf), ct);
                  })
                  .catch(() => {
                    /* gövde okunamadı → yoksay */
                  });
              } catch {
                /* yoksay */
              }
            })
            .catch(() => {
              /* ağ hatası → yoksay */
            });
        }
        return promise;
      } as typeof fetch;
    }
  } catch {
    /* yoksay */
  }

  // ---- Belge indirme navigasyonları (window.open / bağlantı tıklaması) ----
  // Bunlar tarayıcı indirmesi olarak başlatılabilir; GÖVDE yakalanamaz, yalnızca hedef yol
  // (metadata) kaydedilir. Böylece "PDF hangi adresten geliyor" keşfedilir. Salt gözlem.
  try {
    const rawWindowOpen = w.open;
    if (typeof rawWindowOpen === 'function') {
      w.open = function patchedOpen(this: Window, ...args: unknown[]): Window | null {
        try {
          const u = resolveDocCandidate(args[0]);
          if (u && looksLikeDocPath(u)) {
            const doc = pushDocMeta({
              source: 'navigation',
              method: 'GET',
              u,
              ct: null,
              status: null,
              size: null,
              cd: null,
            });
            doc.note = 'Yeni sekmede açıldı (içerik yakalanmadı, yalnızca adres).';
          }
        } catch {
          /* yoksay */
        }
        return (rawWindowOpen as (...a: unknown[]) => Window | null).apply(w, args);
      } as unknown as typeof window.open;
    }
  } catch {
    /* yoksay */
  }

  try {
    document.addEventListener(
      'click',
      (event) => {
        try {
          const target = event.target as Element | null;
          if (!target || typeof target.closest !== 'function') return;
          const anchor = target.closest('a[href]') as HTMLAnchorElement | null;
          if (!anchor) return;
          const href = anchor.href || anchor.getAttribute('href') || '';
          const u = resolveDocCandidate(href);
          if (u && looksLikeDocPath(u)) {
            const doc = pushDocMeta({
              source: 'navigation',
              method: 'GET',
              u,
              ct: null,
              status: null,
              size: null,
              cd: null,
            });
            doc.note = 'Bağlantıya tıklandı (içerik yakalanmadı, yalnızca adres).';
          }
        } catch {
          /* yoksay */
        }
      },
      true,
    );
  } catch {
    /* yoksay */
  }
})();