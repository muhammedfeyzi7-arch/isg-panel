/**
 * İSGDenetim — İSG-KATİP eklentisi POPUP (ürün arayüzü, v1.0.0).
 *
 * Üç ekran: ANA DURUM · SENKRONİZASYON · AYARLAR. Yan panel YOKTUR.
 *
 * - Gerçek bağlantı durumu gösterilir (motorun state machine'i) — sahte "Bağlı" YOK.
 * - Otomatik senkronizasyon ayarı ve durumu (son kontrol / son güncelleme / sayaçlar)
 *   `chrome.storage.local`'daki motor deposundan okunur.
 * - 🔒 token/cookie/JWT OKUNMAZ/gösterilmez/gönderilmez.
 */
import {
  autoConnect,
  getConnState,
  onConnStateChange,
  type ConnState,
} from '../shared/katipConnection';
import { openIsgDenetimApp } from '../shared/katipBridge';
import {
  INTERVAL_OPTIONS,
  formatStamp,
  formatTime,
  getSettings,
  getStats,
  runAutoSyncOnce,
  saveSettings,
  type KatipSettings,
  type KatipStats,
} from '../shared/katipAutoSync';
import { el, setText } from '../shared/domUtils';

type Screen = 'home' | 'sync' | 'settings';

const SCREENS: Record<Screen, string> = {
  home: 'screen-home',
  sync: 'screen-sync',
  settings: 'screen-settings',
};

let currentStats: KatipStats | null = null;
let currentSettings: KatipSettings | null = null;

/** Ekranlar arasında geçiş yapar. */
function showScreen(screen: Screen): void {
  (Object.keys(SCREENS) as Screen[]).forEach((key) => {
    const node = el(SCREENS[key]);
    if (!node) return;
    node.classList.toggle('k-hidden', key !== screen);
  });
}

/** Tema seçimini uygular (kullanıcı seçimi). */
function applyTheme(theme: KatipSettings['theme']): void {
  const prefersDark = typeof matchMedia === 'function' && matchMedia('(prefers-color-scheme: dark)').matches;
  const dark = theme === 'dark' || (theme === 'system' && prefersDark);
  document.body.classList.toggle('k-dark', dark);
}

/** Bağlantı kartını (ana ekran) gerçek state + motor durumundan günceller. */
function applyConnCard(state: ConnState, stats: KatipStats | null): void {
  const card = el('conn-card');
  const title = el('conn-title');
  const pill = el('conn-pill');
  const sub = el('conn-sub');
  if (!card) return;

  const katipCaptured = stats?.connection.katipCaptured === true;
  const ready = state === 'READY';

  card.classList.remove('is-ready', 'is-warn', 'is-off');
  if (ready && katipCaptured) {
    card.classList.add('is-ready');
    if (title) title.textContent = 'Bağlantı hazır';
    if (pill) { pill.textContent = 'Aktif'; pill.className = 'k-pill k-pill-green'; }
    if (sub) sub.textContent = "İSG-KATİP ile otomatik senkronizasyon aktif.";
  } else if (ready) {
    card.classList.add('is-warn');
    if (title) title.textContent = 'Bağlantı hazır';
    if (pill) { pill.textContent = 'Bekliyor'; pill.className = 'k-pill'; }
    if (sub) sub.textContent = "İSGDenetim bağlı. İSG-KATİP sekmesini açıp oturum açın.";
  } else if (state === 'CONNECTING') {
    card.classList.add('is-warn');
    if (title) title.textContent = 'Bağlantı kuruluyor…';
    if (pill) { pill.textContent = 'Bağlanıyor'; pill.className = 'k-pill'; }
    if (sub) sub.textContent = 'İSGDenetim bağlantısı kuruluyor, lütfen bekleyin.';
  } else {
    card.classList.add('is-off');
    if (title) title.textContent = 'Bağlantı bekleniyor';
    if (pill) { pill.textContent = 'Bekliyor'; pill.className = 'k-pill'; }
    if (sub) sub.textContent = "İSG-KATİP ve İSGDenetim sekmelerini açarak başlayın.";
  }
}

/** Son işlemler listesini render eder (ana ekran). */
function renderHomeLog(stats: KatipStats): void {
  const host = el('home-log');
  if (!host) return;
  host.innerHTML = '';
  if (!stats.log || stats.log.length === 0) {
    const p = document.createElement('p');
    p.className = 'k-empty';
    p.textContent = 'Henüz işlem kaydı yok. Otomatik senkronizasyon çalıştığında güncellemeler burada görünür.';
    host.appendChild(p);
    return;
  }
  for (const item of stats.log) {
    const row = document.createElement('div');
    row.className = 'k-log-item';

    const dot = document.createElement('span');
    dot.className = `k-log-dot${item.kind === 'check' ? ' k-log-dot-check' : ''}`;

    const main = document.createElement('div');
    main.className = 'k-log-main';
    const title = document.createElement('div');
    title.className = 'k-log-title';
    title.textContent = item.title || 'İSG-KATİP';
    const sub = document.createElement('div');
    sub.className = 'k-log-sub';
    if (item.kind === 'update') {
      sub.textContent = `Çalışan sayısı güncellendi (${item.from ?? 0} → ${item.to ?? 0})`;
    } else {
      sub.textContent = 'Herhangi bir değişiklik bulunamadı.';
    }
    main.appendChild(title);
    main.appendChild(sub);

    const time = document.createElement('span');
    time.className = 'k-log-time';
    time.textContent = formatStamp(item.at);

    row.appendChild(dot);
    row.appendChild(main);
    row.appendChild(time);
    host.appendChild(row);
  }
}

/** Ana ekranı doldurur. */
function renderHome(stats: KatipStats): void {
  setText('kpi-matched-v', stats.matchedFirmCount > 0 ? String(stats.matchedFirmCount) : '—');
  setText('kpi-emp-v', stats.totalKatipEmployees > 0 ? String(stats.totalKatipEmployees) : '—');
  setText('kpi-upd-v', formatStamp(stats.lastUpdate));
  renderHomeLog(stats);
}

/** Senkronizasyon ekranındaki işlem zaman çizelgesini render eder. */
function renderSyncDetails(stats: KatipStats): void {
  const host = el('sync-details');
  if (!host) return;
  host.innerHTML = '';
  const t1 = formatTime(stats.lastCheck);
  const t2 = stats.updatedFirmCount > 0 ? formatTime(stats.lastUpdate) : formatTime(stats.lastCheck);
  const steps = [
    { title: 'KATİP verileri okundu', sub: 'Hizmet sözleşmesi listesi analiz edildi.', time: t1, done: stats.lastCheck != null },
    { title: `${stats.checkedFirmCount} firma kontrol edildi`, sub: 'Eşleşmiş firmaların verileri karşılaştırıldı.', time: t1, done: stats.lastCheck != null },
    { title: `${stats.updatedFirmCount} firma güncellendi`, sub: 'Çalışan sayısı değişiklikleri aktarıldı.', time: t2, done: stats.updatedFirmCount > 0 },
    { title: 'Gereksinimler yeniden hesaplanıyor', sub: 'Arka planda devam ediyor.', time: t2, done: false },
  ];
  for (const s of steps) {
    const item = document.createElement('div');
    item.className = 'k-tl-item';
    const mark = document.createElement('span');
    mark.className = `k-tl-mark${s.done ? '' : ' pending'}`;
    mark.textContent = s.done ? '✓' : '';
    const body = document.createElement('div');
    body.className = 'k-tl-body';
    const title = document.createElement('div');
    title.className = 'k-tl-title';
    title.textContent = s.title;
    const sub = document.createElement('div');
    sub.className = 'k-tl-sub';
    sub.textContent = s.sub;
    body.appendChild(title);
    body.appendChild(sub);
    const time = document.createElement('span');
    time.className = 'k-tl-time';
    time.textContent = s.time;
    item.appendChild(mark);
    item.appendChild(body);
    item.appendChild(time);
    host.appendChild(item);
  }
}

/** Senkronizasyon ekranını doldurur. */
function renderSync(stats: KatipStats, settings: KatipSettings): void {
  const pill = el('sync-state-pill');
  if (pill) {
    pill.textContent = settings.autoSync ? 'Aktif' : 'Pasif';
    pill.className = `k-pill ${settings.autoSync ? 'k-pill-green' : ''}`;
  }
  setText('sync-last-check', formatStamp(stats.lastCheck));
  setText('sync-last-update', formatStamp(stats.lastUpdate));
  setText('sync-matched-v', stats.matchedFirmCount > 0 ? String(stats.matchedFirmCount) : '—');
  setText('sync-unchanged', String(stats.unchangedCount));
  setText('sync-pending', String(stats.pendingCheckCount));

  const total = stats.matchedFirmCount;
  const bar = el('sync-bar');
  if (bar) {
    const pct = total > 0 ? Math.round((stats.unchangedCount / total) * 100) : 0;
    bar.style.width = `${pct}%`;
  }

  const title = el('sync-summary-title');
  const text = el('sync-summary-text');
  if (stats.lastCheck == null) {
    if (title) title.textContent = 'Son Senkronizasyon';
    if (text) text.textContent = 'Henüz senkronizasyon çalışmadı. Otomatik senkronizasyon ilk kontrolünü yapınca burada görünecek.';
  } else if (stats.updatedFirmCount > 0) {
    if (title) title.textContent = 'Senkronizasyon tamamlandı';
    if (text) {
      text.textContent = `${stats.checkedFirmCount} firma kontrol edildi. ${stats.updatedFirmCount} firmada çalışan sayısı güncellendi.`;
    }
  } else {
    if (title) title.textContent = 'Senkronizasyon tamamlandı';
    if (text) {
      text.textContent = `${stats.checkedFirmCount} firma kontrol edildi. Değişiklik bulunamadı.`;
    }
  }

  renderSyncDetails(stats);
}

/** Ayarlar ekranını doldurur. */
function renderSettings(settings: KatipSettings, stats: KatipStats): void {
  const auto = el<HTMLInputElement>('set-auto');
  if (auto) auto.checked = settings.autoSync;
  const notify = el<HTMLInputElement>('set-notify');
  if (notify) notify.checked = settings.notifications;
  const interval = el<HTMLSelectElement>('set-interval');
  if (interval) interval.value = String(settings.intervalMinutes);
  const theme = el<HTMLSelectElement>('set-theme');
  if (theme) theme.value = settings.theme;

  const version = (() => {
    try {
      return chrome.runtime.getManifest().version;
    } catch {
      return '1.0.0';
    }
  })();
  setText('si-version', `v${version}`);
  setText('home-version', `v${version}`);
  setText('si-last-check', formatStamp(stats.lastCheck));
  setText('si-last-update', formatStamp(stats.lastUpdate));
  setText('si-matched', stats.matchedFirmCount > 0 ? String(stats.matchedFirmCount) : '—');
}

/** Ayar değişikliklerini service worker'a bildirir (alarm yeniden planlanır). */
function notifySettingsChanged(): void {
  try {
    chrome.runtime.sendMessage({ type: 'ISG_KATIP_AUTO_SYNC_SETTINGS_CHANGED' }, () => {
      void chrome.runtime.lastError;
    });
  } catch {
    // yoksay
  }
}

/** Popup'ı tüm veriyle tazeler. */
async function refreshAll(): Promise<void> {
  const [settings, stats] = await Promise.all([getSettings(), getStats()]);
  currentSettings = settings;
  currentStats = stats;
  applyTheme(settings.theme);
  applyConnCard(getConnState(), stats);
  const toggle = el<HTMLInputElement>('auto-sync-toggle');
  if (toggle) toggle.checked = settings.autoSync;
  renderHome(stats);
  renderSync(stats, settings);
  renderSettings(settings, stats);
}

/** Sıklık seçeneklerini bir kez doldurur. */
function buildIntervalOptions(): void {
  const select = el<HTMLSelectElement>('set-interval');
  if (!select || select.options.length > 0) return;
  for (const opt of INTERVAL_OPTIONS) {
    const o = document.createElement('option');
    o.value = String(opt.value);
    o.textContent = opt.label;
    select.appendChild(o);
  }
}

/** Olay bağlantıları. */
function wire(): void {
  // Marka logosu yüklenemezse yerel ikona düş.
  document.querySelectorAll<HTMLImageElement>('.k-emblem').forEach((img) => {
    img.addEventListener('error', () => {
      img.src = '../icons/icon48.png';
    });
  });

  buildIntervalOptions();

  // Ekran geçişleri.
  el('go-settings')?.addEventListener('click', () => showScreen('settings'));
  el('go-sync')?.addEventListener('click', () => showScreen('sync'));
  el('kpi-matched')?.addEventListener('click', () => showScreen('sync'));
  document.querySelectorAll<HTMLElement>('[data-back]').forEach((btn) => {
    btn.addEventListener('click', () => showScreen('home'));
  });
  document.querySelectorAll<HTMLElement>('[data-close]').forEach((btn) => {
    btn.addEventListener('click', () => window.close());
  });

  // İSGDenetim'i aç.
  el('open-denetim')?.addEventListener('click', () => void openIsgDenetimApp());

  // Ana ekran otomatik senkron toggle'ı.
  const homeToggle = el<HTMLInputElement>('auto-sync-toggle');
  homeToggle?.addEventListener('change', () => {
    void (async () => {
      await saveSettings({ autoSync: homeToggle.checked });
      notifySettingsChanged();
      await refreshAll();
    })();
  });

  // Ayarlar ekranı toggle/select.
  el<HTMLInputElement>('set-auto')?.addEventListener('change', (e) => {
    const checked = (e.target as HTMLInputElement).checked;
    void (async () => {
      await saveSettings({ autoSync: checked });
      notifySettingsChanged();
      await refreshAll();
    })();
  });
  el<HTMLInputElement>('set-notify')?.addEventListener('change', (e) => {
    const checked = (e.target as HTMLInputElement).checked;
    void saveSettings({ notifications: checked }).then(() => refreshAll());
  });
  el<HTMLSelectElement>('set-interval')?.addEventListener('change', (e) => {
    const value = Number((e.target as HTMLSelectElement).value) || 5;
    void (async () => {
      await saveSettings({ intervalMinutes: value });
      notifySettingsChanged();
      await refreshAll();
    })();
  });
  el<HTMLSelectElement>('set-theme')?.addEventListener('change', (e) => {
    const value = ((e.target as HTMLSelectElement).value || 'light') as KatipSettings['theme'];
    void (async () => {
      await saveSettings({ theme: value });
      applyTheme(value);
    })();
  });

  // Şimdi kontrol et.
  const runBtn = el<HTMLButtonElement>('sync-run');
  runBtn?.addEventListener('click', () => {
    void (async () => {
      const original = runBtn.textContent;
      runBtn.disabled = true;
      runBtn.textContent = 'Kontrol ediliyor…';
      try {
        await runAutoSyncOnce('manual');
        await refreshAll();
      } finally {
        runBtn.disabled = false;
        runBtn.textContent = original;
      }
    })();
  });

  // Bağlantı state değişince kartı tazele.
  onConnStateChange(() => applyConnCard(getConnState(), currentStats));

  // Sistem teması değişirse (theme = system) uygula.
  if (typeof matchMedia === 'function') {
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
      if (currentSettings) applyTheme(currentSettings.theme);
    });
  }
}

document.addEventListener('DOMContentLoaded', () => {
  wire();
  // Rozeti temizle (kullanıcı popup'ı açtı).
  try {
    void chrome.action.setBadgeText({ text: '' });
  } catch {
    // yoksay
  }
  void (async () => {
    await refreshAll();
    void autoConnect();
  })();
});