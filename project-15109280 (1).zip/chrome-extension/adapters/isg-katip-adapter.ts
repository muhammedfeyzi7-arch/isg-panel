/**
 * İSG-KATİP Chrome Extension adapter'ı (FAZ 6B — GERÇEK implementasyon).
 *
 * Kanonik parse/normalize mantığı `src/lib/isgKatip/` altında TEK kaynaktadır;
 * bu dosya onu RE-EXPORT eder ve yalnızca Chrome'a özgü TAŞIMAYI (page-context
 * fetch köprüsü) ekler. Böylece kod tekrarı YOKTUR.
 *
 * Akış:
 *   content script → bu adapter → chrome.runtime.sendMessage →
 *   service worker → chrome.scripting.executeScript(MAIN world) →
 *   KATİP SPA'nın KENDİ isteğinden yakalanan (READ-ONLY) response → HAM JSON
 *   → parse/normalize (`src/lib/isgKatip`).
 *
 * Güvenlik: İKİNCİ authenticated istek YOKTUR. Yakalanan response yalnızca discovery/
 * normalize için kullanılır; cookie/token hiçbir yere KOPYALANMAZ veya GÖNDERİLMEZ.
 */
import {
  HttpIsgKatipAdapter,
  type IsgKatipAdapter,
} from '../../src/lib/isgKatip/adapter';
import {
  IsgKatipEndpointError,
  katipFetchEnvelope,
  type KatipPageFetcher,
} from '../../src/lib/isgKatip/endpoints';
import type { IsgKatipAdapterContext } from '../../src/lib/isgKatip/types';
import type {
  KatipCapturedRequestMessage,
  KatipCapturedResponseMessage,
} from '../shared/messages';

// Kanonik adapter sözleşmesini (HttpIsgKatipAdapter, error, factory) yeniden yayınla.
export * from '../../src/lib/isgKatip/adapter';

/** Sayfanın gerçekten İSG-KATİP olduğunu doğrular (kimlik bilgisi OKUMAZ). */
export function isIsgKatipLocation(loc: { hostname: string; pathname: string }): boolean {
  const host = String(loc?.hostname ?? '').toLowerCase();
  return host.endsWith('csgb.gov.tr') && host.includes('isgkatip');
}

/**
 * Chrome taşımasını üretir (FAZ 6K — READ-ONLY RESPONSE INTERCEPTION).
 *
 * Her çağrı, service worker → MAIN world üzerinden KATİP SPA'nın KENDİ gerçek isteğinden
 * yakalanan response'u OKUR. İKİNCİ bir authenticated istek ATILMAZ; token/cookie
 * hiçbir yerde okunmaz/kopyalanmaz.
 */
export function createChromeCapturedTransport(): KatipPageFetcher {
  return async (path: string, body): Promise<unknown> => {
    // Gerçek SPA'dan yalnızca TEK bir response gözlemlenir; extension EK sayfa İSTEMEZ.
    // `fetchAllOngoingRows` güvenle durması için pageIndex>0 → boş sayfa döndürülür
    // (bu bir AĞ isteği DEĞİLDİR; yalnızca yerel boş sonuç).
    if (body.pageIndex > 0) {
      return katipFetchEnvelope(200, { body: { tableData: [] } });
    }
    const request: KatipCapturedRequestMessage = { type: 'ISG_KATIP_CAPTURED_REQUEST', path };
    const res = (await chrome.runtime.sendMessage(request)) as KatipCapturedResponseMessage | undefined;
    if (!res || !res.ok) {
      // NOT_CAPTURED → henüz gözlemlenmiş gerçek response yok (güvenli durum; ağ isteği YOK).
      throw new IsgKatipEndpointError(
        (res?.code as never) ?? 'NETWORK_ERROR',
        res?.message ?? 'İSG-KATİP yanıtı okunamadı.',
        res?.status,
      );
    }
    // HTTP status (tam sayı) + HAM JSON. Cookie/token/başlık KOPYALANMAZ.
    return katipFetchEnvelope(res.status, res.json);
  };
}

/** Content script bağlamında GERÇEK adapter'ı üretir (READ-ONLY, ikinci istek YOK). */
export function createIsgKatipContentAdapter(context: IsgKatipAdapterContext): IsgKatipAdapter {
  return new HttpIsgKatipAdapter(createChromeCapturedTransport(), context);
}