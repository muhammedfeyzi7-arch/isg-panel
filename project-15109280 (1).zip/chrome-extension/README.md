# İSGDenetim — İSG-KATİP Chrome Extension (v1.0.0)

> **Durum (v1.0.0):** Yan panel (side panel) KALDIRILDI. Uzantı yalnızca **popup tabanlıdır** ve
> üç ekran sunar: **Ana Durum · Senkronizasyon · Ayarlar**.
> İSG-KATİP'e **YAZMAZ** (READ-ONLY interception). Yalnızca **eşleşmiş firmaların çalışan sayısı**
> değişikliklerini İSGDenetim'e aktarır.
>
> - **Otomatik senkron motoru:** `chrome.alarms` periyodik tetikler → İSGDenetim SPA köprüsü →
>   yakalanan gerçek KATİP satırları → yalnızca eşleşmiş firmaların `isg_katip_calisan_sayisi`
>   alanı → değişmeyene write YOK → gereksinim yeniden hesaplama.
> - Firma / personel / atama / sözleşme OTOMATİK OLUŞTURULMAZ; eşleştirme YAPILMAZ.
> - KATİP erişilemiyorsa veri UYDURULMAZ; bağlantı durumu dürüstçe gösterilir.
> - 🔒 cookie / token / Authorization / e-Devlet bilgisi backend'e GÖNDERİLMEZ, saklanmaz, loglanmaz.

## BU FAZ (FAZ 6K) — READ-ONLY

- KATİP'e **veri YAZMAZ**: firma/personel/atama oluşturmaz, onaylamaz, fesih işlemi yapmaz.
- İSGDenetim (Supabase) DB'sine **KATİP verisi import ETMEZ**.
- Cookie / session / token / Authorization / e-Devlet bilgisi backend'e **GÖNDERİLMEZ**, saklanmaz, loglanmaz.
- Global import flag (`system_settings.isg_katip_import_enabled`) **KAPALI** kalır; pilot execution **KAPALI**.
- Amaç: gerçek Chrome'da **kurulabilir** extension + **READ-ONLY discovery** altyapısı.

## FAZ 6I — GERÇEK KATİP VERİSİYLE AUTHENTICATED DRY RUN (READ-ONLY)

FAZ 6K'nın yakaladığı GERÇEK KATİP response'u artık mevcut canonical mimariden geçirilir:

```
KATİP GERÇEK VERİSİ → NORMALIZE → MATCH → PLAN → RAPOR
```

- Popup'taki **"Dry Run Çalıştır"** butonu, MAIN-world READ-ONLY interception ile yakalanan
  gerçek `body.tableData`'yı kullanır. **İkinci bir authenticated istek ATILMAZ.**
- Çıktı: Firma / Personel / Yasal Atama için **MATCH / NEW / CONFLICT / UNRESOLVED / SKIPPED**
  sayaçları, çalışan sayısı **KATİP / Merkezi / fark**, rol discovery ve **DB WRITE: 0**.
- `applied=false`, `importEnabled=false`, `dbWrites=0` — DEĞİŞMEZ.
- Gerçek response henüz yakalanmadıysa **`DRY_RUN_NOT_READY`** döner (mock/tahmin YOK).
- **İdempotent:** aynı gerçek response iki kez → aynı external ID + aynı MATCH/NEW/CONFLICT
  kararları (timestamp karara DAHİL DEĞİL).
- **PII-safe:** yalnızca external ID, entity type, status, reason code ve sayısal sayaçlar;
  TC/ad-soyad/telefon UI'ya çıkmaz.

> **Bilinen sınır (dürüst):** Extension sayfa bağlamında yerel İSGDenetim DB anlık görüntüsü
> (snapshot) BULUNMAZ. Bu nedenle Dry Run boş snapshot ile değerlendirilir ve tüm yeni kayıtlar
> **NEW/UNRESOLVED** olarak raporlanır (tahmin YOK). Gerçek MATCH için yerel snapshot gerekir;
> bu, Dry Run orkestratörüne `snapshot` parametresi verilerek SPA/backend tarafında da çalıştırılabilir.

## Kurulum (Chrome'a yükleme — adım adım)

1. Build'i üret: `node chrome-extension/build.mjs` → `chrome-extension/dist/` oluşur.
2. Chrome'da `chrome://extensions` adresini aç.
3. Sağ üstten **Geliştirici modu**'nu aç.
4. **Paketlenmemiş öğe yükle**'ye bas.
5. **`chrome-extension/dist/`** klasörünü seç (kök `chrome-extension/` DEĞİL — kökte `.ts` kaynakları vardır).
6. Extension listede görünmeli ("İSGDenetim — İSG-KATİP Aktarım").
7. İSG-KATİP'e (`https://isgkatip.csgb.gov.tr`) oturum aç.
8. Bir KATİP sayfası aç.
9. Toolbar'daki extension ikonuna tıkla ve **"Discovery Verisini Yenile"** butonuna bas.

Panel de: **KATİP Bağlantısı: Hazır / Bekleniyor** + Hizmet/Personel sözleşmesi sayıları + rol eşleme durumu (DOĞRULANDI/BEKLİYOR). Hiçbir teknik Console/Network işlemi gerekmez.

> **Not (orphan content script):** Extension'ı yeniden yükledikten sonra (Rebuild → Reload),
> açık olan KATİP sekmesindeki eski içerik betiği "orphan" kalır ve mesaja yanıt vermez.
> Panel artık bunu tespit eder ve betiği **otomatik yeniden enjekte eder**; hâlâ yanıt gelmezse
> "Discovery başarısız: içerik betiği bu sekmeye bağlı değil (…)" gibi **gerçek gerekçeyi**
> gösterir (eski tek "Bilinmeyen hata" mesajı kaldırıldı). Kesin çözüm için yine de KATİP
> sekmesini (F5) yenilemek en temizidir.

### Beklenen build çıktısı (`chrome-extension/dist/`)

```
dist/
├── manifest.json
├── icons/
│   ├── icon16.png · icon32.png · icon48.png · icon128.png
├── popup/
│   ├── popup.html
│   ├── sidepanel.html
│   ├── katip-ui.css
│   ├── popup.js
│   └── sidepanel.js
├── content/
│   ├── katip-main-hook.js   (MAIN world, document_start — SPA response gözlemcisi)
│   └── katip-content.js
└── background/
    └── service-worker.js
```

`manifest.json` script yolları bu derlenmiş `.js` çıktılarıyla birebir uyumludur
(`action.default_popup` = `popup/popup.html`, `background.service_worker` = `background/service-worker.js`,
`content_scripts` = `content/katip-main-hook.js` (world: MAIN, document_start) +
`content/katip-content.js`). `host_permissions` yalnızca
`https://isgkatip.csgb.gov.tr/*` (KATİP) ve `https://app.isgdenetim.com.tr/*` (İSGDenetim iç-rölesi) — başka geniş izin YOK; wildcard / `<all_urls>` / `externally_connectable` KULLANILMAZ.

## Gerçek endpoint'ler (doğrulanmış)

| Amaç | Endpoint | Kaynak |
|---|---|---|
| İSG Hizmet Sözleşmeleri (yasal dışa görevlendirme) | `POST /be/bsn-inter-instance/hizmet-sozlesmesi-surec-view/ongoing` | Adapter → firma + yasal atama |
| İSG Personel Sözleşmeleri (içe görevlendirme) | `POST /be/bsn-inter-instance/personel-sozlesmesi-surec/ongoing` | Ayrı entity (yasal atama DEĞİL) |

**Host:** `https://isgkatip.csgb.gov.tr` (host izni yalnızca bu origin'e daraltıldı)
**Request gövdesi:** `{ sortOrder, pageIndex, pageSize, filters, sortColumn }`
**Varsayılan:** `pageSize:100`, `sortColumn:"sozlesmeId"`, `filters:[]`

## ÜRÜN ARAYÜZÜ (v0.9.0 — UI Productization)

Popup ve Side Panel, geliştirici/debug ekranından ürün arayüzüne dönüştürüldü. **Teknik motor
DEĞİŞMEDİ** (interception, capture, pagination, DATA gate, contractActivity, matching, pilot,
atomic WRITE, VERIFY, lifecycle, bridge, session, RLS).

- **Paylaşılan stil:** `popup/katip-ui.css` (koyu lacivert zemin · İSGDenetim kırmızısı CTA ·
  yeşil durum · premium kartlar). İkon fontu/SVG YOK (CSP); ikonlar CSS-çizimi + tipografik glif.
- **Gerçek ikonlar:** `build.mjs` içinden `icons/generate-icons.mjs` ile üretilir (saf Node/zlib).
  `manifest.icons` + `action.default_icon` bunlara bağlıdır.
- **Popup:** yalnızca bağlantı durumu + “Yan Paneli Aç” + “İSGDenetim'i Aç” + Ayarlar.
- **Side Panel:** bağlantı kartı, birincil “İşyeri Aktar”, 4 adımlı stepper (İşyeri Seç → Kontrol Et →
  Onayla → Tamamla), işyeri arama/lista, eşleşme önizlemesi, onay ve sonuç ekranı.
- **Terminoloji:** kullanıcıya “Dry Run / Pilot / Apply / Verify / RPC / capture / DATA_COMPLETE”
  gösterilmez. Teknik sayaçlar yalnızca kapalı **Geliştirici teşhisi** bölümündedir.
- **WRITE kuralı DEĞİŞMEDİ:** yalnızca DATA_COMPLETE + ACTIVE + geçerli kapsam + çakışma yok +
  **açık kullanıcı onayı** ile çalışır.

## Mimari

```
İSG-KATİP Browser Session (kullanıcının kendi e-Devlet oturumu)
        ↓
Content Script (content/katip-content.ts)  → normalize payload
        ↓  chrome.runtime.sendMessage
Service Worker (background/service-worker.ts)
        ↓  chrome.scripting.executeScript(world:'MAIN')  → YAKALANAN response'u OKU (yeni istek YOK)
Adapter ../../src/lib/isgKatip/{adapter,endpoints,mapper}   (parse + normalize)
        ↓
İSGDenetim Integration Endpoint → supabase/functions/isg-katip-sync
        ↓  doğrulama + OSGB scope + sunucu-taraflı matching + controlled upsert + sync log
firmalar / personeller / atamalar
```

> **Tek doğruluk kaynağı:** parse/normalize/matching/import mantığı `src/lib/isgKatip/`
> altındadır. Extension bunu `../../src/lib/isgKatip/...` üzerinden **yeniden kullanır**.

## Derleme (MV3 gerçek JS çıktısı)

```bash
node chrome-extension/build.mjs   # esbuild'ı npx ile kullanır (bağımlılık eklenmez)
```

Chrome'a yükleme: `chrome://extensions` → Geliştirici modu → "Paketlenmemiş öğe yükle"
→ **`chrome-extension/dist/`** klasörünü seçin (kök değil).

`manifest.json` script yolları **derlenmiş `.js` çıktısıyla** uyumludur
(`background/service-worker.js`, `content/katip-content.js`).

## Güvenlik (kesin)

- İSG-KATİP session cookie / e-Devlet bilgisi backend'e GÖNDERİLMEZ, hiçbir yerde SAKLANMAZ.
- Otomatik login / e-Devlet bypass YOK; oturum yalnızca `credentials:'include'` ile KULLANILIR.
- **READ-ONLY:** KATİP üzerinde atama oluşturma/silme/onaylama/fesih YOK.
- Yalnızca **normalize edilmiş** payload gönderilir; ham response `system_logs`'a YAZILMAZ.
- `context.osgbId`, backend'de authenticated kullanıcının GERÇEK OSGB'si ile eşleştirilir.

## Kontrollü import (FAZ 6D/6E/6F) — SUNUCU TARAFINDA

Gerçek DB yazma (firma/personel/yasal atama upsert) **sunucuda** yapılır:

- **Merkezî feature gate:** `system_settings.isg_katip_import_enabled` (yoksa env
  `ISG_KATIP_IMPORT_ENABLED`). **Varsayılan KAPALI** → gate kapalıyken hiçbir yazma yoktur.
- **Modlar:** `DRY_RUN` (varsayılan, yazma yok) · `SAFE_IMPORT` · `FULL_CONTROLLED_IMPORT`.
- Yalnızca güvenli `MATCHED`/`NEW` kayıtlar yazılır; `CONFLICT`/`UNRESOLVED`/`SKIPPED` → yazma YOK.
- **DELETE yok.** `firmalar.calisan_sayisi` İSG-KATİP'ten ASLA yazılmaz.
- Saha Uzmanı / helper ASLA üretilmez; yasal atama `assignment_role='primary'`.

## Rol çözümleme (DÜRÜST SINIR)

FAZ 6K'da gerçek KATİP response discovery ile YALNIZCA şu değer doğrulandı:

| KATİP değeri | İSGDenetim rolü | Sınıf | Durum |
|---|---|---|---|
| `gorevlendirilenKisiSertifikaTipiId=20002` (`"C Sınıfı İş Güvenliği Uzmanlığı Sertifikası"`) | `isg_uzmani` | C | **VERIFIED** |

Diğer enum değerleri (A/B sınıfı, İşyeri Hekimi, DSP) **görülmediği için UYDURULMADI** →
çözülemeyen kayıt yasal atama olarak ÜRETİLMEZ → `UNRESOLVED` (Eşleştirme Bekliyor).
`sozlesmeTipi` (ör. "Kısmi Süreli") ROL değil SÜRE niteliğidir → haritalanmaz.
A/B/C sınıfı QUALIFICATION bilgisidir; `uzmanlik_sinifi`'na yazılır, ROL değildir.

## PII güvenliği (KESİN)

Discovery raporu/logu yalnızca `field + unique values + IDs + counts` içerir.
**TC kimlik no, ad/soyad, cookie, token, Authorization, e-Devlet bilgisi ASLA yazılmaz.**
`containsPii()` savunmacı tarayıcı + `redactedFields` ile doğrulanır.

## Runtime teşhis (FAZ 6K debug) — PII'siz şekil teşhisi

Discovery çalışırken iki endpoint **bağımsız** okunur (biri hata verse bile diğeri raporlanır).
Her endpoint için popup'taki **"Teşhis (PII'siz)"** bölümünde şu bilgiler görünür:

- Endpoint başarılı mı (OK · kayıt sayısı) yoksa hata kodu mu (ör. `TABLE_DATA_NOT_FOUND`).
- Hata varsa, runtime'da GELEN değerin **şekil özeti**: `root=object; rootKeys=[...];
  body.type=object; bodyKeys=[...]; body.tableData=yok|dizi(N)`. Yalnızca **alan adları,
  tipler ve sayılar** gösterilir.

Bu sayede "extension DevTools'taki JSON'u mu alıyor, yoksa bir string / farklı bir
sarmalayıcı mı?" sorusu **Console/Network açmadan** cevaplanır. Şekil teşhisi T.C. kimlik no,
ad-soyad, cookie, token veya ham response GÖSTERMEZ.

### FAZ 6K — REQUEST-MISMATCH teşhisi (genişletilmiş)

Gerçek runtime kanıtı: extension'ın aldığı yanıt `rootKeys=[messages, responseStatus, warnings]`
şeklindeydi — yani **KATİP uygulama-seviyesi bir SARMA ZARFI**, `body.tableData` DEĞİL.
Bu yüzden teşhis genişletildi. Popup'taki şekil özeti artık şunları da gösterir:

- `httpStatus=<n>` — taşıma katmanından gelen HTTP durumu (tam sayı; PII değil).
- `responseStatus=<deger|keys[...]>` — zarfın durum alanı (yalnızca primitive değer veya ALAN ADLARI).
- `messages=dizi(N)` / `warnings=dizi(N)` — mesaj/uyarı dizilerinin **sayısı**.
- `messagesKeys=[...]` ve `messagesCodes=[code=...]` — yalnızca ALAN ADLARI ve GÜVENLİ kısa kod
  alanları (code/type/key/level/severity). **Serbest mesaj metni rapora GİRMEZ.**

Böylece "request gerçekten başarılı KATİP isteği mi, yoksa sunucu bir validasyon/oturum zarfı mı
döndü?" sorusu tahmin edilmeden ayırt edilir.

### Doğrulanmış request payload (birebir)

Hizmet `ongoing` isteği, DevTools Network'te doğrulanan payload ile **birebir** aynıdır ve
testle sabitlenmiştir (`REQ1`):

```json
{ "sortOrder": "DESC", "pageIndex": 0, "pageSize": 100, "filters": [], "sortColumn": "sozlesmeId" }
```

Personel endpoint'inin gerçek payload'ı DOĞRULANMADIĞI için ayrı bir payload **UYDURULMAZ**; aynı
kanonik builder kullanılır (`REQ3`). İstek `credentials:'include'` + `Content-Type: application/json`
+ standart `Accept` başlığıyla gönderilir; cookie/token/Authorization ASLA kopyalanmaz.

> Not: Kök neden teşhis EDİLMEDEN parser'a körlemesine yeni fallback EKLENMEZ. Parser yalnızca
> `body.tableData` → `tableData` → doğrudan dizi yollarını kabul eder; diğer alan adları REDDEDİLİR.

### FAZ 6K — READ-ONLY RESPONSE INTERCEPTION (İKİNCİ İSTEK YOK)

**Kök neden (önceki yaklaşım):** KATİP SPA, `Token` başlığını KENDİ HTTP katmanında
(Angular HttpClient / axios interceptor) aktif oturumdan ekliyordu. Extension'ın MAIN-world
`fetch`'i NATIVE fetch olduğu için bu interceptor'a uğramıyordu → Token gitmiyordu → sunucu
`200` ile uygulama-seviyesi bir hata zarfı (`{ messages, responseStatus, warnings }`,
`SESSION_INVALID`) dönüyordu; DevTools'taki başarılı `body.tableData` extension'a hiç gelmiyordu.

**Yeni yaklaşım (bu sürüm):** Auth başlığını TAKLİT ETMEYİ BIRAKTIK. Artık extension İKİNCİ bir
authenticated istek ATMAZ. Bunun yerine `content/katip-main-hook.ts` (MAIN world,
`document_start`):

- KATİP SPA'nın KENDİ gerçek `XMLHttpRequest` ve `fetch` isteklerini **salt gözlemle** izler
  (yalnızca iki endpoint: `hizmet-sozlesmesi-surec-view/ongoing` ve
  `personel-sozlesmesi-surec/ongoing`).
- İsteğin response'u tamamlandığında (XHR `load` / fetch `clone().json()`) gövdeyi **READ-ONLY**
  okur ve YALNIZCA pencere-bağlamı bellekte (`window.__ISG_KATIP_CAPTURED__`) tutar.
- SPA'nın ağ akışı BOZULMAZ: orijinal `open`/`send`/`fetch` AYNEN çağrılır; istek
  ENGELLENMEZ, DEĞİŞTİRİLMEZ, YENİDEN GÖNDERİLMEZ.

Discovery **"Discovery Verisini Yenile"** ile çalıştırıldığında service worker, MAIN world'den
**yakalanan SON gerçek response'u OKUR** (yeni istek ATMAZ) ve mevcut
`extractTableData`/discovery pipeline'ına verir. İlgili endpoint'in response'u henüz
yakalanmadıysa panel açık ve güvenli bir durum gösterir:
**"KATİP ekranındaki verinin yüklenmesi bekleniyor."** İlgili KATİP listesi açıldığında/yenilendiğinde
hook yeni response'u **otomatik** yakalar; ardından tekrar denenir.

**Güvenlik:**
- Token / Authorization / cookie **hiçbir başlık OKUNMAZ, TAŞINMAZ, YAZILMAZ**.
- Yakalanan ham response **storage'a / log'a / console'a / UI'ya / Supabase'e YAZILMAZ**; yalnızca
  sayfa bağlamı belleğinde tutulur ve sayfa kapanınca kaybolur.
- Discovery raporu (popup'a giden) yalnızca alan adları, benzersiz değerler ve sayılar içerir.
- Auth bağlamı gerekmez; `NO_AUTH_HEADER` / token akışı **KALDIRILDI**.

## Testler

```bash
node --test --experimental-strip-types chrome-extension/tests/
```