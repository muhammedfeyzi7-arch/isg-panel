/**
 * İSGDenetim — İSG-KATİP extension için GERÇEK PNG ikon üreticisi (bağımlılık YOK).
 *
 * `chrome-extension/build.mjs` tarafından çağrılır; ikonları `dist/icons/` altına yazar:
 *   icon16.png · icon32.png · icon48.png · icon128.png
 *
 * Tasarım: İSGDenetim kırmızısı yuvarlatılmış kare zemin + beyaz kalkan + kırmızı tik.
 * Saf Node (zlib) ile PNG kodlanır; harici paket/font gerekmez. Emoji/placeholder/SVG YOK.
 */
import { deflateSync } from 'node:zlib';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const PNG_SIGNATURE = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

/** CRC32 (PNG chunk başlığı için). */
function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i += 1) {
    c ^= buf[i];
    for (let k = 0; k < 8; k += 1) c = (c >>> 1) ^ (0xedb88320 & -(c & 1));
  }
  return (c ^ 0xffffffff) >>> 0;
}

/** PNG chunk üretir (uzunluk + tip + veri + CRC). */
function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const body = Buffer.concat([Buffer.from(type, 'latin1'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body), 0);
  return Buffer.concat([len, body, crc]);
}

/** RGBA ham piksel verisini 8-bit RGBA PNG'ye kodlar. */
function encodePng(width, height, rgba) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // color type: RGBA
  ihdr[10] = 0;
  ihdr[11] = 0;
  ihdr[12] = 0;
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let y = 0; y < height; y += 1) {
    raw[y * (stride + 1)] = 0; // filter: none
    rgba.copy(raw, y * (stride + 1) + 1, y * stride, (y + 1) * stride);
  }
  return Buffer.concat([
    PNG_SIGNATURE,
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/** Yuvarlatılmış kare alfa maskesi (x,y ∈ [-1,1]). */
function roundedSquareAlpha(x, y, radius) {
  const ax = Math.abs(x);
  const ay = Math.abs(y);
  if (ax > 1 || ay > 1) return 0;
  const cx = ax - (1 - radius);
  const cy = ay - (1 - radius);
  if (cx > 0 && cy > 0) return Math.hypot(cx, cy) <= radius ? 1 : 0;
  return 1;
}

/** Kalkan alfa maskesi (tepede geniş, altta sivri). */
function shieldAlpha(x, y) {
  const sx = x / 0.6;
  const top = -0.84;
  const bottom = 0.88;
  const t = (y - top) / (bottom - top);
  if (t < 0 || t > 1) return 0;
  let halfW;
  if (t < 0.58) halfW = 1;
  else halfW = Math.max(0, 1 - (t - 0.58) / 0.42);
  const topFade = Math.min(1, t / 0.08); // tepede hafif yuvarlama
  return Math.abs(sx) <= halfW * topFade ? 1 : 0;
}

/** Bir noktanın doğru parçasına uzaklığı. */
function segDist(px, py, ax, ay, bx, by) {
  const vx = bx - ax;
  const vy = by - ay;
  const wx = px - ax;
  const wy = py - ay;
  const c1 = vx * wx + vy * wy;
  const c2 = vx * vx + vy * vy;
  let t = c2 > 0 ? c1 / c2 : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + vx * t), py - (ay + vy * t));
}

/** Kalkan içindeki tik işareti alfa maskesi. */
function checkAlpha(x, y) {
  const w = 0.13;
  const d1 = segDist(x, y, -0.26, 0.0, -0.02, 0.26);
  const d2 = segDist(x, y, -0.02, 0.26, 0.36, -0.3);
  return d1 <= w || d2 <= w ? 1 : 0;
}

/** Normalize koordinatta (x,y ∈ [-1,1]) RGBA örnekler. */
function sample(nx, ny) {
  if (roundedSquareAlpha(nx, ny, 0.24) <= 0) return [0, 0, 0, 0];
  const g = (ny + 1) / 2; // 0 üst .. 1 alt (kırmızı gradyan)
  const r = Math.round(244 + (186 - 244) * g);
  const gg = Math.round(63 + (10 - 63) * g);
  const b = Math.round(75 + (20 - 75) * g);
  if (shieldAlpha(nx, ny) > 0) {
    if (checkAlpha(nx, ny) > 0) return [198, 16, 24, 255]; // kırmızı tik
    return [255, 255, 255, 255]; // beyaz kalkan
  }
  return [r, gg, b, 255];
}

/** Belirli boyut için supersample'lı RGBA tamponu üretir. */
function render(size, ss) {
  const out = Buffer.alloc(size * size * 4);
  const n = ss * ss;
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      let r = 0;
      let g = 0;
      let b = 0;
      let a = 0;
      for (let sy = 0; sy < ss; sy += 1) {
        for (let sx = 0; sx < ss; sx += 1) {
          const nx = ((x + (sx + 0.5) / ss) / size) * 2 - 1;
          const ny = ((y + (sy + 0.5) / ss) / size) * 2 - 1;
          const c = sample(nx, ny);
          const al = c[3] / 255;
          r += c[0] * al;
          g += c[1] * al;
          b += c[2] * al;
          a += al;
        }
      }
      const idx = (y * size + x) * 4;
      const A = a / n;
      out[idx] = A > 0 ? Math.round(r / n / A) : 0;
      out[idx + 1] = A > 0 ? Math.round(g / n / A) : 0;
      out[idx + 2] = A > 0 ? Math.round(b / n / A) : 0;
      out[idx + 3] = Math.round(A * 255);
    }
  }
  return out;
}

/**
 * İkonları verilen klasöre üretir. Dönüş: yazılan dosya yolları.
 * @param {string} outDir hedef klasör (ör. dist/icons)
 */
export async function generateKatipIcons(outDir) {
  await mkdir(outDir, { recursive: true });
  const sizes = [16, 32, 48, 128];
  const written = [];
  for (const size of sizes) {
    const rgba = render(size, 4);
    const png = encodePng(size, size, rgba);
    const file = resolve(outDir, `icon${size}.png`);
    // eslint-disable-next-line no-await-in-loop
    await writeFile(file, png);
    written.push(file);
  }
  return written;
}