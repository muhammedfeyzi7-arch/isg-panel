/**
 * İSGDenetim — İSG-KATİP Chrome Extension (MV3) build betiği.
 *
 * Görev: extension TypeScript dosyalarını ve `src/lib/isgKatip/*` kanonik modüllerini
 * tek paket çıktıya derler; manifest.json'u kopyalar. Çıktı: `chrome-extension/dist/`.
 *
 * Chrome'a yükleme: `chrome://extensions` → Geliştirici modu → "Paketlenmemiş öğe yükle"
 * → **`chrome-extension/dist/`** (kök değil; kökte `.ts` dosyaları vardır).
 *
 * Çalıştırma:
 *   node chrome-extension/build.mjs
 *
 * NOT: Bu projede `scripts` ve `devDependencies` alanları salt-okunurdur; bu yüzden
 * esbuild, package.json'a bağımlılık EKLENMEDEN `npx --yes esbuild` ile çalıştırılır
 * (ilk çalıştırmada esbuild otomatik indirilir). Ana Vite SPA build'i bundan ETKİLENMEZ.
 */
import { execSync } from 'node:child_process';
import { cp, mkdir, rm } from 'node:fs/promises';
import { dirname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { generateKatipIcons } from './icons/generate-icons.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const outdir = resolve(root, 'dist');

/** Tek bir entry'i npx esbuild ile derler. `repoRoot`'tan çalıştırılır (npx bulunması için). */
function bundle(entryRel, outRel, format) {
  const cmd = [
    'npx --yes esbuild',
    `"${entryRel}"`,
    '--bundle',
    `--format=${format}`,
    '--target=chrome110',
    '--log-level=info',
    '--legal-comments=none',
    `--outfile="${outRel}"`,
  ].join(' ');
  execSync(cmd, { stdio: 'inherit', cwd: repoRoot });
}

const repoRoot = resolve(root, '..');

await rm(outdir, { recursive: true, force: true });
await mkdir(resolve(outdir, 'background'), { recursive: true });
await mkdir(resolve(outdir, 'content'), { recursive: true });
await mkdir(resolve(outdir, 'popup'), { recursive: true });

// Gerçek PNG ikonlarını üret (icons/icon16.png · icon32 · icon48 · icon128).
await generateKatipIcons(resolve(outdir, 'icons'));

// Service worker → ESM (manifest: "type": "module").
bundle(
  relative(repoRoot, resolve(root, 'background/service-worker.ts')),
  relative(repoRoot, resolve(outdir, 'background/service-worker.js')),
  'esm',
);

// Content script → IIFE (content script'ler ES module olamaz).
bundle(
  relative(repoRoot, resolve(root, 'content/katip-content.ts')),
  relative(repoRoot, resolve(outdir, 'content/katip-content.js')),
  'iife',
);

// İSGDenetim iç-rölesi (FAZ 6J.3) → IIFE (ISOLATED world declarative content script).
// İSGDenetim sayfası her yüklendiğinde (F5/navigation/SPA reload) röleyi OTOMATİK kurar.
bundle(
  relative(repoRoot, resolve(root, 'content/denetim-relay.ts')),
  relative(repoRoot, resolve(outdir, 'content/denetim-relay.js')),
  'iife',
);

// MAIN world response-observer hook'u (FAZ 6K) → IIFE (MAIN world, document_start).
bundle(
  relative(repoRoot, resolve(root, 'content/katip-main-hook.ts')),
  relative(repoRoot, resolve(outdir, 'content/katip-main-hook.js')),
  'iife',
);

// Popup (FAZ 6K) → IIFE (bağımsız küçük durum paneli).
bundle(
  relative(repoRoot, resolve(root, 'popup/popup.ts')),
  relative(repoRoot, resolve(outdir, 'popup/popup.js')),
  'iife',
);

// Side Panel (FAZ 6L) → v1.0.0'da KALDIRILDI. Uzantı artık yalnızca popup tabanlıdır.

// Manifest'i çıktı köküne kopyala (script yolları dist köküne göre çözülür).
await cp(resolve(root, 'manifest.json'), resolve(outdir, 'manifest.json'));

// Popup HTML'ini kopyala (popup.js'i göreli yükler).
await cp(resolve(root, 'popup/popup.html'), resolve(outdir, 'popup/popup.html'));

// Paylaşılan ürün arayüzü stilleri (popup).
await cp(resolve(root, 'popup/katip-ui.css'), resolve(outdir, 'popup/katip-ui.css'));

// eslint-disable-next-line no-console
console.log('✓ İSG-KATİP extension derlendi → chrome-extension/dist');