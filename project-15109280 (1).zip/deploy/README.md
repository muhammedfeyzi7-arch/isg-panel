# İBYS — Türkiye'de Self-Hosted Supabase Taşıma Kiti

Bu klasör, mevcut SaaS Supabase kurulumunu **Turhost VDS (Türkiye)** üzerinde
çalışan self-hosted Supabase'e taşımak için gereken her şeyi içerir.

> **Amaç:** İBYS'nin "kişisel + sağlık verisi Türkiye'de barındırılacak" ve
> "sabit yurt içi IP" şartlarını karşılamak. Taşımadan sonra hizmet yükü (yedek,
> güncelleme, sertifika) bize aittir.

---

## 1. Sunucu Bilgileri (kayıtlı)

| Alan | Değer |
|---|---|
| Sağlayıcı | Turhost |
| Paket | VDS TR 6 |
| Sunucu adı | `srv.ibys-prod.com` |
| **Sabit IP** | `37.230.105.216` |
| SSH portu | `23422` |
| SSH kullanıcı | `root` |
| İşletim sistemi | Ubuntu 24.04 LTS |
| CPU / RAM / Disk | 6 vCPU / 16384 MB / 300 GB SSD |
| Lokasyon | Türkiye 🇹🇷 |

> ⚠️ **SSH ŞİFRESİ hiçbir yere yazılmaz.** Şifre Turhost müşteri panelindeki
> "Erişim Bilgileri" bölümünden alınır. Şifreyi sohbete / dosyaya / depoya koymayın.

**Sunucuya bağlanma:**
```bash
ssh -p 23422 root@37.230.105.216
```

---

## 2. Kaynak Sistem (taşınacak yer)

- Kaynak Supabase projesi: `https://cmgfalpoiouflnbppjjk.supabase.co`
- Taşınacak bileşenler: **Postgres (şema + veri + `auth.users`)** → **Storage
  dosyaları** → **~50 Edge Function** → **secrets**.

> ⚠️ Kaynak verinin tam yedeği **taşımadan önce** alınır. Hiçbir şey taşınana kadar
> **silinmez**; mevcut sistem kesintiye uğratılmadan çalışmaya devam eder.

---

## 3. Ön Koşullar (sende)

1. **Alan adı + DNS:** İki kayıt gerekir (aşağıda Adım 4). Alan adını ve DNS
   yönetiminin sende olduğunu teyit et.
2. **Kaynak DB bağlantı adresi** (Postgres connection string): Kaynak Supabase
   panelinden alınır (`Settings → Database → Connection string`). Bu olmadan veri
   taşınamaz.
3. **Kaynak + hedef Service Role anahtarları** (Storage taşıma için).
4. **Edge function sırları** (Adım 8 envanteri) — kaynak panelden kopyalanır.

---

## 4. Kurulum — Adım Adım

### Adım 0 — Sunucuya gir
```bash
ssh -p 23422 root@37.230.105.216
```

### Adım 1 — Sunucu hazırlığı (Docker + güvenlik duvarı)
```bash
# Bu depodaki script'i sunucuya kopyaladıktan sonra:
bash deploy/scripts/01-sunucu-hazirla.sh
```
Yaptıkları: sistem güncelleme, Docker + Compose kurulumu, `ufw` (23422/80/443),
`fail2ban`, Supabase self-host deposunu `/opt/ibys/supabase` altına çekme.

### Adım 2 — Sırları üret ve `.env`'i doldur
```bash
# JWT_SECRET için güçlü bir değer üret:
openssl rand -base64 48

# Üretilen gizli anahtarla anon + service_role token'larını üret:
node deploy/scripts/gen-jwt.mjs "<JWT_SECRET>" anon
node deploy/scripts/gen-jwt.mjs "<JWT_SECRET>" service_role
```
Çıkan değerleri `deploy/.env.example` şablonunu örnek alarak
`/opt/ibys/supabase/docker/.env` dosyasına işle.

### Adım 3 — Stack'i başlat
```bash
cd /opt/ibys/supabase/docker
docker compose up -d
docker compose ps     # tüm servisler "healthy" olmalı
```

### Adım 4 — Alan adı + TLS
DNS panelinde şu **A kaydını** oluştur:

| Kayıt | Tip | Değer | TTL |
|---|---|---|---|
| `api.isgdenetim.com.tr` | A | `37.230.105.216` | 300 |
| `app.isgdenetim.com.tr` | A | `37.230.105.216` | 300 |

Sunucuda **Caddy** (otomatik TLS) ile ters proxy kur:
```bash
apt-get install -y caddy
```
`/etc/caddy/Caddyfile`:
```caddyfile
api.isgdenetim.com.tr {
    reverse_proxy 127.0.0.1:8000
}
app.isgdenetim.com.tr {
    root * /var/www/app
    try_files {path} /index.html
    file_server
}
```
```bash
systemctl restart caddy
```
> Studio panelini (`3000`) **dışarı açmayın**; gerektiğinde SSH tüneli ile açın:
> `ssh -p 23422 -L 3000:127.0.0.1:3000 root@37.230.105.216`

### Adım 5 — Veritabanını taşı (şema + veri + auth)

> ⚠️ **Önemli bağlantı notları** (yeni Supabase sürümlerinde zorunlu):
> - **Kaynak:** düz `db.<ref>.supabase.co` adresi IPv6'ya çözülüp
>   `Network is unreachable` verebilir → **IPv4 pooler** kullan ve kullanıcı adına
>   proje ref'ini ekle (`postgres.<ref>`).
> - **Hedef:** `127.0.0.1:5432` önünde **Supavisor** durur, **tenant kimliği
>   zorunludur** → kullanıcı adı `postgres.<POOLER_TENANT_ID>` (`docker/.env`'te yazılı).

```bash
# Kaynak: pooler (IPv4) + proje ref'li kullanıcı
export KAYNAK_DB_URL="postgresql://postgres.<ref>:<SIFRE>@aws-0-<region>.pooler.supabase.com:5432/postgres"

# Hedef: tenant kimliği .env'den otomatik okunur
TENANT="$(grep -E '^POOLER_TENANT_ID=' /opt/ibys/supabase/docker/.env | head -n1 | cut -d= -f2-)"
PW="$(grep -E '^POSTGRES_PASSWORD=' /opt/ibys/supabase/docker/.env | head -n1 | cut -d= -f2-)"
export HEDEF_DB_URL="postgresql://postgres.${TENANT}:${PW}@127.0.0.1:5432/postgres"

bash deploy/scripts/02-db-tasi.sh
```
Script önce kaynaktan **tam yedeği** alır, sonra hedefe geri yükler.

> ⚠️ **Beklenen durum:** Geri yükleme sırasında `auth.*` ve `storage.*` için
> **bolca `must be owner of table ...` / `relation does not exist` hatası** görürsün.
> **Bunlar normaldir ve veri kaybı DEĞİLDİR.** Sebep: self-host Supabase'de bu
> tablolar `postgres` rolüne değil, `supabase_auth_admin` / `supabase_storage_admin`'a
> aittir; ayrıca kaynak GoTrue sürümü biraz yeni olduğu için hedefte bazı tablolar
> (`scim_users` vb.) yoktur. Bu hataların hepsi **yapısal** (index / constraint / RLS)
> ifadelerdir — tablolar zaten hedefte hazırdır.
>
> **`public` şeması ise sorunsuz iner** (uygulama verisi = asıl önemli olan).

#### Adım 5b — Auth kullanıcı verisini ayrıca taşı (DDL'siz)
`auth.users` verisi yukarıdaki hatalar sırasında inmemiş olabilir. Kullanıcı
hesaplarını kesin taşımak için:
```bash
bash deploy/scripts/02b-auth-veri-tasi.sh
```
Bu script yalnızca `auth.users` + `auth.identities` **verisini** çeker (yapısal
ifadeler olmadan) ve yüklemeyi konteyner içindeki gerçek superuser
(`supabase_admin`) ile yapar, böylece sahiplik sorunu ortadan kalkar.
Doğrulama: hedefte `select count(*) from auth.users;` → kaynak ile eşleşmeli.

> ⚠️ **CASCADE yan etkisi (script bunu otomatik telafi eder):** `auth.users`'a FK ile
> bağlı `custom_icons`, `email_signatures`, `mail_connections`, `mail_credentials`,
> `mail_logs`, `mail_oauth_states`, `personel_notlari` tabloları `TRUNCATE ... CASCADE`
> nedeniyle boşalır. Script'in **5. adımı** bu tabloların verisini `02-db-tasi.sh`'in
> aldığı en güncel `kaynak-*.dump` yedeğinden **otomatik geri yükler**, böylece veri
> kaybı olmaz ve script tekrar çalıştırılabilir.

> ℹ️ **Not (bu ortamda doğrulandı):** İlk taşımada bu 7 tablonun kaynak ve hedef
> satır sayıları birebir eşleşti (`mail_connections=1`, `mail_credentials=1`,
> `mail_logs=5`, `mail_oauth_states=14`, diğerleri `0`) → **veri kaybı yok.**

### Adım 6 — Storage dosyalarını taşı
```bash
npm install @supabase/supabase-js ws     # (bir kereye mahsus)
export SRC_URL="https://cmgfalpoiouflnbppjjk.supabase.co"
export SRC_SERVICE_KEY="<KAYNAK_SERVICE_ROLE_KEY>"
export TGT_URL="https://api.isgdenetim.com.tr"
export TGT_SERVICE_KEY="<HEDEF_SERVICE_ROLE_KEY>"
export BUCKETS="public,private"
node --import ./deploy/scripts/ws-preload.mjs deploy/scripts/03-storage-tasi.mjs
```
> ℹ️ **Node.js 20 notu:** Bu sürümde native WebSocket yoktur; `createClient`
> realtime başlatırken "Node.js 20 detected without native WebSocket support"
> hatası verir. `deploy/scripts/ws-preload.mjs` `ws` paketini global WebSocket
> yaparak bunu çözer. Bu yüzden komut `--import` ile çalıştırılır. (Node 22+ için
> `--import` kısmı gerekmez, düz `node deploy/scripts/03-storage-tasi.mjs` yeterlidir.)

### Adım 7 — Edge Function'ları yayınla
```bash
bash deploy/scripts/04-edge-deploy.sh
```
Bu script fonksiyonları self-host fonksiyon dizinine kopyalar ve `functions`
container'ını yeniden başlatır.

**Kaynak dizin seçimi (otomatik):** Script, fonksiyon kaynağını şu sırayla arar ve
ilk bulduğunu kullanır:
1. `$(pwd)/supabase/functions` (normal repo kökü)
2. `$(pwd)/functions`
3. `/opt/ibys/tasima/functions` (sunucuya elle yüklenen kopya)
4. `/opt/ibys/supabase/functions`

Kaynağı **elle** vermek istersen `KAYNAK=...` ile geçebilirsin:
```bash
KAYNAK=/opt/ibys/tasima/functions bash deploy/scripts/04-edge-deploy.sh
```

> ℹ️ Sunucuda `supabase/functions` yoksa (resmi Supabase deposu çekildiği için
> normaldir) script otomatik olarak `tasima/functions`'a düşer — ekstra bir şey
> yapmana gerek yok.

**Doğrulama:**
```bash
cd /opt/ibys/supabase/docker
docker compose ps functions          # "healthy" olmalı
docker compose logs --tail=80 functions
```
`health: starting` durumu ~20-60 sn sürer; bu normaldir. Loglarda hata yoksa
fonksiyonlar yüklenmiştir. Tek tek test: `curl -i https://api.isgdenetim.com.tr/functions/v1/<fonksiyon>`

### Adım 7b — Sunucu güvenlik logu toplayıcısı (SRV-01)
Caddy / docker compose (Kong·PostgREST·GoTrue·storage) / fail2ban katmanındaki
oturumsuz saldırı denemelerini (tarama, 4xx/5xx yoğunluğu, 401-403 yağmuru, ban)
toplayıp admin panelindeki **Sistem Logları → Sunucu Güvenliği** görünümüne taşır.

Önce `SRV-01` migration'ını canlı DB'ye uygula, sonra:
```bash
# 1) Keşif: sunucuda hangi log kaynakları var?  -> /var/log/ibys-log-kesif.txt
sudo bash deploy/scripts/05-server-log-topla.sh --kesif

# 2) Kuru çalıştırma (DB'ye yazmaz, bulunan olayları basar)
sudo bash deploy/scripts/05-server-log-topla.sh --dry-run

# 3) Cron'u kur (2 dakikada bir; idempotent)
sudo bash deploy/scripts/05-server-log-topla.sh --kur-cron

# 4) Doğrula
bash supabase/tests/security/pentest_gunu/10_sunucu_log_dogrula.sh
```
> Durum dosyaları `/var/log/ibys-log-state/`, log/rapor `/var/log/` altında tutulur
> (yazma yetkisi yoksa `/tmp`'e düşer). Toplayıcı `psql`'i `docker compose exec`
> ile çağırır; service-role sırrı istemez. Sır/token/JWT/e-posta metinleri log'a
> yazılmadan önce temizlenir.

### Adım 8 — Sırları (secrets) yeni ortama taşı
Edge function'ların kullandığı sırları `docker/.env` içine işle (bkz. Bölüm 5).
Özellikle şunlar **zorunlu**: `ALLOWED_ORIGINS`, `RESEND_API_KEY`,
`RESEND_FROM_DOMAIN`, `GEMINI_API_KEY`, Google/Microsoft OAuth bilgileri.

### Adım 9 — Uygulamayı yeni adrese çevir
Frontend `.env` (proje kökündeki `.env`):
```
VITE_PUBLIC_SUPABASE_URL="https://api.isgdenetim.com.tr"
VITE_PUBLIC_SUPABASE_ANON_KEY="<üretilen ANON_KEY>"
```
Sonra uygulamayı yeniden derleyip yayınla.

### Adım 10 — Uçtan uca doğrulama
- [ ] Giriş / kayıt / davet akışları
- [ ] RLS: Yetkisiz kullanıcı başka OSGB/firma verisini göremiyor
- [ ] Kritik modüller: personel, sağlık, eğitim, risk, ekipman, mail, davet
- [ ] Storage: dosya yükleme / indirme / önizleme
- [ ] Edge functions: her birine en az bir istek
- [ ] İBYS gönderim akışı (yurt içi IP'den)

---

## 5. Edge Function Sır Envanteri (yeni ortama taşınacak)

| Sır | Kullanan yer(ler) | Zorunlu |
|---|---|---|
| `SUPABASE_URL` / `SUPABASE_ANON_KEY` / `SUPABASE_SERVICE_ROLE_KEY` | tüm fonksiyonlar (self-host'ta otomatik gelir) | ✅ |
| `ALLOWED_ORIGINS` | tüm fonksiyonlar (CORS) | ✅ |
| `RESEND_API_KEY` / `RESEND_FROM_DOMAIN` | firma-davet, osgb-davet, personel-hesap, send-reset-email | ✅ |
| `GEMINI_API_KEY` (veya `GOOGLE_API_KEY`) / `GEMINI_MODEL` | risk-ai, isg-kurulu-*, saha-denetim* | ✅ |
| `AI_SUGGESTION_DAILY_LIMIT` | AI öneri fonksiyonları | ➖ |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` / `GOOGLE_REDIRECT_URI` | mail (OAuth) | ✅ |
| `MICROSOFT_CLIENT_ID` / `MICROSOFT_CLIENT_SECRET` / `MICROSOFT_REDIRECT_URI` / `MICROSOFT_TENANT_ID` | mail (OAuth) | ✅ |
| `SMTP_ALLOWED_HOSTS` / `SMTP_ALLOWED_PORTS` | mail (SSRF guard) | ✅ |
| `SEND_RESET_ALLOWED_ORIGINS` | send-reset-email | ➖ |
| `ISG_KATIP_IMPORT_ENABLED` | isg-katip-sync | ➖ |
| `ShopifyDomain` / `StorefrontAccessToken` | Shopify entegrasyonu (varsa) | ➖ |

> Sır değerleri **kod içine yazılmaz**, yalnızca `docker/.env` içinde tutulur.

---

## 6. Geri Dönüş (Rollback) Planı

- Taşıma öncesi kaynaktan **tam `pg_dump`** alınır (`02-db-tasi.sh` zaten alır).
- Kesinti anında frontend `.env` eski değerlere çevrilir → eski sistem çalışır.
- Kaynak proje, taşıma doğrulanana kadar **silinmez / dondurulmaz**.
- Storage dosyaları kaynakta kalır (kopyalama salt-okunur).

---

## 7. İşletim (Taşıma Sonrası Zorunlu)

- **Günlük yedekleme:** `pg_dump` + storage snapshot → şifreli, en az 2 kopya.
- **Geri yükleme testi:** 3 ayda bir tatbikat.
- **Güncelleme takvimi:** Docker imajları + Ubuntu güvenlik yamaları.
- **İBYS belgeleri:** Yedekleme Prosedürü + Veritabanı Değişiklik Prosedürü.
- **Sızma testi:** Taşıma sonrası nihai sistem üzerinde (bkz. ana plan).

---

## 8. Güvenlik kapanış betikleri (13–19) — NEREDE çalışır

> ⚠️ **Bu betikler Linux/bash betikleridir ve SUNUCUDA çalışır.**
> Windows PowerShell'de `bash deploy/scripts/14_....sh` yazarsanız komut WSL'e
> düşer ve `No such file or directory` alırsınız; `sudo` ise Windows'ta kapalıdır
> (`Sudo is disabled on this machine`). Bu bir dosya/izin sorunu değildir.

### Windows'tan tek komut (önerilen)
```powershell
# Proje kökünde PowerShell:
.\deploy\scripts\20_pentest_kapanis_deploy.ps1
```
Yaptıkları: gerekli dosyaları tek arşivde sunucuya kopyalar (`/root/isg-deploy`,
dizin yapısı korunur), sonra orada sırayla koşar:
`14 → 15 → 17 → 18 (kuru → uygula) → 19`.

Seçenekler:
```powershell
.\deploy\scripts\20_pentest_kapanis_deploy.ps1 -Adim 14,15      # sadece seçili adımlar
.\deploy\scripts\20_pentest_kapanis_deploy.ps1 -AtlaPgtap       # pgTAP uzun sürerse
.\deploy\scripts\20_pentest_kapanis_deploy.ps1 -SadeceYukle     # sadece kopyala
.\deploy\scripts\20_pentest_kapanis_deploy.ps1 -IptablesKalici  # iptables-persistent + save
```

### Zip ile tek komut (indirdiğin proje arşiviyle)

Yerelde dosya toplamak istemiyorsan, indirdiğin proje zip'ini (`project-*.zip`)
doğrudan sunucuya atıp orada açan yol:

```powershell
# PowerShell (proje kökünde olmak zorunda değilsin):
.\deploy\scripts\21_zip_ile_pentest_kapanis.ps1
```
- `-Zip` verilmezse `İndirilenler` / `Masaüstü` içindeki **en yeni** `project-*.zip` seçilir.
- zip + sunucu tarafı çalıştırıcı (`21_zip_runner.sh`) sunucuya kopyalanır,
  `/root/isg-deploy` altına açılır ve sırayla koşar:
  `14 → 15 → 17 → 18 (kuru → uygula → doğrula) → 19`.
- zip'in içinde üst klasör olsa da olmasa da doğru proje kökünü kendisi bulur.
- zip yalnızca arayüz dosyalarını içeriyorsa (içinde `deploy/scripts` yoksa)
  açık bir hata verir; o durumda `20_pentest_kapanis_deploy.ps1` kullanılmalı.

```powershell
.\deploy\scripts\21_zip_ile_pentest_kapanis.ps1 -Zip C:\Users\monst\Downloads\project-15023485.zip
.\deploy\scripts\21_zip_ile_pentest_kapanis.ps1 -Adim 14,15
.\deploy\scripts\21_zip_ile_pentest_kapanis.ps1 -AtlaPgtap -IptablesKalici
```

### 16 numaralı betik ayrı koşulur (interaktif)
`16_ui_sifre_kodu_akisi_test.sh` e-postaya gelen 6 haneli kodu **sorar**. Bu yüzden
interaktif bir SSH oturumunda çalıştırılmalıdır:
```bash
ssh -p 23422 root@37.230.105.216
bash /root/isg-deploy/deploy/scripts/16_ui_sifre_kodu_akisi_test.sh
```
Sonuç: `/root/pentest-kanit/sifre_akisi_<tarih>.log`. Ardından `19` tekrar
koşulursa bu kanıt otomatik olarak kanıt paketine kopyalanır.

### 28 · Zip kur + testleri koş (tek komut, önerilen)

Yeni bir zip indirdiğinde en kısa yol:

```powershell
cd <zip-i-indirdigin-klasor-un-altinda-bu-betik-neredeyse>
.\deploy\scripts\28_zip_kur_test.ps1
```

Yaptıkları:
1. En yeni `project-*.zip`'i bulur, **içeriğini doğrular** (eski zip ise hiç yüklemez),
2. Zip'i sunucuya atar, `/root/isg-deploy` altına **temiz** açar,
3. **Edge Function'ları yayınlar** (`04-edge-deploy.sh`) — BULGU-03/07 düzeltmesi
   burada devreye girer; bu adım olmadan testler eski kodu ölçer,
4. `24` (GUV-43) → `14` (FK) → `15` (cron) → `17` (DNS) → `18` (egress) sırayla koşar,
5. `27` ile BULGU-03 + BULGU-07 **canlı** doğrulamasını yapar (40 MB gövde → 413,
   token/IP limiti → ayırt edilemez `INVALID`),
6. `19` kanıt paketini (`/root/pentest-kanit-<tarih>/00_OZET.md`) üretir.

Seçenekler:

```powershell
.\deploy\scripts\28_zip_kur_test.ps1 -Zip C:\Users\monst\Downloads\project-15025408.zip
.\deploy\scripts\28_zip_kur_test.ps1 -SadeceKur     # zip'i sadece aç, test koşma
.\deploy\scripts\28_zip_kur_test.ps1 -EgressYok     # 18 adımını atla
```

Log ve kanıtlar sunucuda: `/root/isg-kur-test-<tarih>.log`, `/root/pentest-kanit-*`

### Sunucuda elle (SSH içinde) koşmak isterseniz
```bash
cd /root/isg-deploy
bash deploy/scripts/14_fk_guv39_guv32_deploy.sh
bash deploy/scripts/15_sifre_kod_temizlik_cron.sh
bash deploy/scripts/17_mail_dns_dogrula.sh --dogrula
bash deploy/scripts/18_egress_firewall.sh            # kuru
bash deploy/scripts/18_egress_firewall.sh --uygula
bash deploy/scripts/19_pentest_kapanis_kanit.sh
```
> `root` olarak bağlandığınız için sunucuda `sudo` öneki **gerekmez**. Root değilseniz
> `sudo bash ...` kullanın.

---

## 9 · 2. pentest raporunun kapanış araçları (26–29)

2. raporda (BULGU-01…10) kod tarafında açık kalmadı. Kalan kalemler **sunucu
ayarı** ve **kanıt koşusu**dur. Tek birleşik tablo:
`PENTEST_BIRLESIK_KAPANIS_2026-10-20.md`

| Betik / dosya | Ne yapar | Kapatır |
|---|---|---|
| `deploy/caddy/Caddyfile` | `api.*` + `app.*` için HSTS, güvenlik başlıkları, seçili fonksiyonlarda 64 KB gövde sınırı | BULGU-08, BULGU-01/03 platform ayağı |
| `deploy/scripts/29_bulgu_01_05_08_kapat.sh` | `--uygula` (Caddy kur), `--mask-baslat` (maskeleme servisi), parametresiz **ölçüm** | BULGU-08, 05, 03 |
| `deploy/postgrest-mask/` | `/rest/v1` yanıtlarında **kolon/tablo yok** hatalarını genelleştiren vekil | BULGU-05 |
| `deploy/scripts/26_f3_marker_kanit.sh` | auth-log marker gönderip DB'de arar | F3 |
| `deploy/scripts/27_bulgu_03_07_dogrula.sh` | 40 MB gövde + token/IP limiti ölçümü | BULGU-03, 07 |
| `deploy/scripts/38_f1_taze_token_kanit.sh` | GUV-44 kapısını enforce'a alır + **taze token ile gerçek şifre yazma saldırısını** HTTP üzerinden dener | F1 |
| `deploy/scripts/36_guv45_uygula_dogrula.sh` | guv45 migration'ını canlıya uygular, 10 adresi tek tek doğrular | GUV-45 / F5 |
| `deploy/scripts/40_kalan_dort_kalem.sh` | Dördünü sırayla koşar + tek sayfa özet üretir | F1, BULGU-05, GUV-45, F3 |

### 9.0 Kalan dört kalem — tek komut (önerilen)

```bash
cd /root/isg-deploy
F3_EMAIL=test@alanadi.com F3_PASS='MevcutSifre' \
  bash deploy/scripts/40_kalan_dort_kalem.sh
```

Sırasıyla koşar: `36` (GUV-45 canlı uygulama) → `38` (F1 enforce + saldırı kanıtı)
→ `29 --mask-uygula` (BULGU-05) → `26` (F3 marker).
Özet: `/root/pentest-kanit/KALAN_4_KALEM_<tarih>.md`

`--sadece-olc` ile hiçbir şey uygulamadan yalnızca ölçüm alınır, `--atla-mask`
ile maskeleme adımı atlanır.

### 9.1 Sırayla kapanış

```bash
# 1) Caddy sertleştirme (Caddyfile YEDEKLENİR)
sudo bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --uygula

# 2) PostgREST şema ifşası maskeleme (opsiyonel ama önerilir)
bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --mask-baslat
#    → /etc/caddy/Caddyfile içindeki /rest/v1/* bloğunun yorumunu kaldır
sudo caddy validate --config /etc/caddy/Caddyfile --adapter caddyfile
sudo systemctl reload caddy

# 3) Ölç
bash deploy/scripts/29_bulgu_01_05_08_kapat.sh

# 4) F3 kanıtı
bash deploy/scripts/26_f3_marker_kanit.sh <eposta> '<sifre>'

# 5) 03 / 07 canlı doğrulama
export ANON_KEY='<anon key>'
bash deploy/scripts/27_bulgu_03_07_dogrula.sh

# 6) 1. raporun 7 kalemi
bash deploy/scripts/19_pentest_kapanis_kanit.sh
```

**Kapanış koşulu (4 PASS satırı):**

| Bulgu | Beklenen |
|---|---|
| BULGU-08 | `PASS api.* HSTS gönderiyor` |
| BULGU-03 | `PASS auth-log/send-reset-email/accept-invite 413` |
| BULGU-05 | `PASS şema ifşası MASKELENDİ` |
| F3 | `SONUÇ: F3 PASS` |

Bu dört satır arşivde yoksa rapor "kapandı" değil **"düzeltme uygulandı,
doğrulama bekliyor"** demelidir.

### 9.2 Caddyfile hakkında iki uyarı

1. **`root * /var/www/app`** satırı sizin gerçek yayın dizininizle eşleşmeli.
   Yanlışsa site 404 verir; `sudo systemctl reload caddy` sonrası hemen kontrol edin.
2. **Gövde sınırı bilinçli olarak yalnızca üç fonksiyonda**: `auth-log`,
   `send-reset-email`, `accept-invite`. Tüm `/functions/v1/*` yoluna 64 KB
   koymak evrak/dosya yükleyen fonksiyonları kırar.

### 9.3 `auth-log` neden `verify_jwt=true` yapılmıyor

Başarısız giriş olayı oturum **yokken** oluşur. JWT zorunlu yapılırsa
`AUTH_LOGIN_FAILED` hiç yazılamaz — güvenlik logunun en kritik olayı ölür.
Koruma uygulama katmanındadır (32 KB gövde, IP/e-posta hız limiti, event
whitelist, alanlar JWT+header'dan). Rapora "önerilen düzeltme birebir
uygulanmadı, eşdeğer koruma" yazılmalıdır.