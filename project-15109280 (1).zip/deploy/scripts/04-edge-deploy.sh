#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Edge Function Yayınlama: supabase/functions/*  ->  self-host functions dizini
#
# Self-host'ta edge function'lar, "functions" container'ının okuduğu
# volume/functions dizininden servis edilir. Bu script tüm fonksiyonları
# oraya kopyalar ve container'ı yeniden başlatır.
#
# Çalıştır: repo kökünden  ->  bash deploy/scripts/04-edge-deploy.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SUPABASE_DOCKER_DIR="${SUPABASE_DOCKER_DIR:-/opt/ibys/supabase/docker}"
HEDEF="${SUPABASE_DOCKER_DIR}/volumes/functions"

# Kaynak fonksiyon dizini: KAYNAK=... ile elle verilebilir; verilmezse sırayla
# bilinen konumlar denenir (repo kökü, tasima/functions, /opt/ibys/supabase/functions).
if [ -z "${KAYNAK:-}" ]; then
  for aday in \
    "$(pwd)/supabase/functions" \
    "$(pwd)/functions" \
    "/opt/ibys/tasima/functions" \
    "/opt/ibys/supabase/functions"; do
    if [ -d "${aday}" ]; then
      KAYNAK="${aday}"
      break
    fi
  done
fi

if [ ! -d "${KAYNAK}" ]; then
  echo "Hata: ${KAYNAK} bulunamadi. Script'i repo kokunden calistirin." >&2
  exit 1
fi
if [ ! -d "${SUPABASE_DOCKER_DIR}" ]; then
  echo "Hata: ${SUPABASE_DOCKER_DIR} bulunamadi. Once 01-sunucu-hazirla.sh calistirin." >&2
  exit 1
fi

echo "==> Fonksiyonlar kopyalaniyor -> ${HEDEF}"
mkdir -p "${HEDEF}"
cp -R "${KAYNAK}/." "${HEDEF}/"

echo "==> functions container yeniden baslatiliyor"
cd "${SUPABASE_DOCKER_DIR}"
docker compose restart functions

echo "==> Durum"
docker compose ps functions

echo ""
echo "TAMAM. Dogrulama:  curl -i https://api.isgdenetim.com.tr/functions/v1/<fonksiyon>"