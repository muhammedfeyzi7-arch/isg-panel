#!/usr/bin/env bash
# =============================================================================
# 40 · KALAN DÖRT KALEM — tek komut, sırayla uygula + kanıtla + özetle
# =============================================================================
# NEREDE ÇALIŞIR : SELF-HOSTED SUNUCU (root, /root/isg-deploy)
#
# KAPATTIĞI KALEMLER
#   1) F1  · taze token penceresi   → 38 (mod enforce + HTTP saldırı kanıtı)
#   2) BULGU-05 · maskeleme vekili  → 29 --mask-uygula (X-Pgrest-Mask kanıtı)
#   3) guv45 · avatar allowlist     → 36 (canlı uygula + 10 doğrulama)
#   4) F3 · marker PASS satırı      → 26 (deterministik arşiv dosyası)
#
# KULLANIM
#   bash deploy/scripts/40_kalan_dort_kalem.sh
#   F3_EMAIL=test@alan.com F3_PASS='MevcutSifre' bash deploy/scripts/40_kalan_dort_kalem.sh
#
#   --atla-mask   : BULGU-05 adımını atla (maskeleme zaten kuruluysa)
#   --sadece-olc  : hiçbir şey uygulama, yalnızca 38/36/29 ölçüm modlarını koştur
#
# ÜRETTİĞİ ÖZET : /root/pentest-kanit/KALAN_4_KALEM_<stamp>.md
#                 (denetçiye verilecek tek sayfa)
#
# NOT: 29 Caddyfile'ı yedekleyerek değiştirir; maskeleme ölçümü PASS değilse
#      otomatik geri alır. 38/36 yalnızca DB + HTTP okur/yazar (idempotent).
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/../.." && pwd)}"
OUT_DIR="${OUT_DIR:-/root/pentest-kanit}"
STAMP="$(date +%Y%m%d-%H%M)"
OZET="$OUT_DIR/KALAN_4_KALEM_$STAMP.md"
START_TS="$(date +%s)"

ATLA_MASK=0
SADECE_OLC=0
for arg in "$@"; do
  case "$arg" in
    --atla-mask)  ATLA_MASK=1 ;;
    --sadece-olc) SADECE_OLC=1 ;;
    *) printf 'HATA: bilinmeyen parametre: %s\n' "$arg" >&2; exit 2 ;;
  esac
done

F3_EMAIL="${F3_EMAIL:-}"
F3_PASS="${F3_PASS:-}"

c_grn=$'\e[32m'; c_red=$'\e[31m'; c_yel=$'\e[33m'; c_b=$'\e[1m'; c_rst=$'\e[0m'
mkdir -p "$OUT_DIR"

SATIRLAR=()
EKLE() { SATIRLAR+=("$1"); }

adim() {
  local no="$1" isim="$2"; shift 2
  echo
  echo "════════════════════════════════════════════════════════════════════"
  printf '  %s%s%s · %s\n' "$c_b" "$no" "$c_rst" "$isim"
  echo "════════════════════════════════════════════════════════════════════"
  "$@"
  local rc=$?
  printf '  → rc=%s\n' "$rc"
  return $rc
}

# Bu koşuda üretilmiş marker dosyasını bulur (eski kanıtı saymaz).
marker_var() {
  find "$OUT_DIR" -maxdepth 1 -name "$1" -newermt "@$START_TS" -print -quit 2>/dev/null
}

echo "════════════════════════════════════════════════════════════════════"
echo "  KALAN 4 KALEM · $(date '+%Y-%m-%d %H:%M:%S')"
echo "  Repo  : $REPO_ROOT"
echo "  Özet  : $OZET"
echo "════════════════════════════════════════════════════════════════════"

SONUC_F1="BAŞLATILMADI"
SONUC_M05="BAŞLATILMADI"
SONUC_G45="BAŞLATILMADI"
SONUC_F3="BAŞLATILMADI"

# ── 3) guv45 (önce bu: DB tarafı temizlenmeden F5 kapalı sayılmaz) ──────────
if [[ "$SADECE_OLC" = "1" ]]; then
  if adim "3" "guv45 · avatar allowlist (yalnızca doğrula)" bash "$SCRIPT_DIR/36_guv45_uygula_dogrula.sh" --dogrula; then
    SONUC_G45="PASS"
  else
    SONUC_G45="FAIL"
  fi
else
  if adim "3" "guv45 · avatar allowlist (uygula + doğrula)" bash "$SCRIPT_DIR/36_guv45_uygula_dogrula.sh"; then
    SONUC_G45="PASS"
  else
    SONUC_G45="FAIL"
  fi
fi
MK_G45="$(marker_var 'GUV45_PASS_*.txt')"
[[ -n "$MK_G45" ]] && SONUC_G45="PASS"

# ── 1) F1 ──────────────────────────────────────────────────────────────────
if [[ "$SADECE_OLC" = "0" ]]; then
  adim "1a" "F1 · kapıyı enforce moduna al" bash "$SCRIPT_DIR/38_f1_taze_token_kanit.sh" --enforce || true
fi
if adim "1b" "F1 · taze token saldırı kanıtı" bash "$SCRIPT_DIR/38_f1_taze_token_kanit.sh"; then
  SONUC_F1="PASS"
else
  SONUC_F1="FAIL"
fi
MK_F1="$(marker_var 'F1_TAZE_TOKEN_PASS_*.txt')"
[[ -n "$MK_F1" ]] && SONUC_F1="PASS"

# ── 2) BULGU-05 ────────────────────────────────────────────────────────────
if [[ "$ATLA_MASK" = "1" ]]; then
  echo
  echo "  BULGU-05 adımı --atla-mask ile atlandı; yalnızca ölçüm yapılıyor."
  if adim "2" "BULGU-05 · maskeleme ölçümü" bash "$SCRIPT_DIR/29_bulgu_01_05_08_kapat.sh"; then
    SONUC_M05="PASS (ölçüm)"
  else
    SONUC_M05="FAIL"
  fi
elif [[ "$SADECE_OLC" = "1" ]]; then
  if adim "2" "BULGU-05 · maskeleme ölçümü" bash "$SCRIPT_DIR/29_bulgu_01_05_08_kapat.sh"; then
    SONUC_M05="PASS (ölçüm)"
  else
    SONUC_M05="FAIL"
  fi
else
  if adim "2" "BULGU-05 · maskeleme (tek komut: servis + Caddy + ölçüm)" \
      bash "$SCRIPT_DIR/29_bulgu_01_05_08_kapat.sh" --mask-uygula; then
    SONUC_M05="PASS"
  else
    SONUC_M05="FAIL"
  fi
fi
MK_M05="$(marker_var 'BULGU05_PASS_*.txt')"
[[ -n "$MK_M05" ]] && SONUC_M05="PASS"

# ── 4) F3 ──────────────────────────────────────────────────────────────────
if [[ -n "$F3_EMAIL" && -n "$F3_PASS" ]]; then
  if adim "4" "F3 · auth-log marker kanıtı" \
      bash "$SCRIPT_DIR/26_f3_marker_kanit.sh" "$F3_EMAIL" "$F3_PASS"; then
    SONUC_F3="PASS"
  else
    SONUC_F3="FAIL"
  fi
  MK_F3="$(marker_var 'F3_PASS_*.txt')"
  [[ -n "$MK_F3" ]] && SONUC_F3="PASS"
else
  SONUC_F3="SKIP (F3_EMAIL/F3_PASS verilmedi)"
  echo
  echo "  ${c_yel}F3 adımı atlandı${c_rst}: giriş yapabilen bir test hesabı gerekiyor."
  echo "  Tek başına: F3_EMAIL=... F3_PASS='...' bash $0"
fi

# ── ÖZET ───────────────────────────────────────────────────────────────────
{
  echo "# KALAN 4 KALEM · KANIT ÖZETİ"
  echo
  echo "- Tarih: $(date '+%Y-%m-%d %H:%M:%S')"
  echo "- Sunucu: $(hostname 2>/dev/null || echo '?')"
  echo "- Repo: \`$REPO_ROOT\`"
  echo
  echo "| # | Kalem | Sonuç | Arşiv dosyası |"
  echo "|---|---|---|---|"
  echo "| 1 | **F1** taze token penceresi (GUV-44 enforce + HTTP saldırı testi) | $SONUC_F1 | \`${MK_F1:-—}\` |"
  echo "| 2 | **BULGU-05** PostgREST şema ifşası maskeleme | $SONUC_M05 | \`${MK_M05:-—}\` |"
  echo "| 3 | **GUV-45 / F5** avatar_url allowlist sıkılaştırma | $SONUC_G45 | \`${MK_G45:-—}\` |"
  echo "| 4 | **F3** auth-log marker → system_logs | $SONUC_F3 | \`${MK_F3:-—}\` |"
  echo
  echo "## Denetçiye verilecek cümle"
  echo
  if [[ "$SONUC_F1" = "PASS" && "$SONUC_M05" =~ ^PASS && "$SONUC_G45" = "PASS" ]]; then
    echo "> F1 taze-token penceresi kapalı: GUV-44 veritabanı kapısı enforce modda; taze oturum"
    echo "> belirteciyle doğrudan şifre yazımı reddedildi ve şifre değişmedi. BULGU-05 maskeleme"
    echo "> vekili devrede ve uçtan uca doğrulandı. GUV-45 canlıya uygulandı: başka Supabase"
    echo "> projesi / readdy.ai / ngrok adresleri reddediliyor."
  else
    echo "> Düzeltmeler uygulandı; yukarıdaki FAIL satırları için doğrulama bekleniyor."
  fi
  echo
  echo "## Tek tek yeniden koşma"
  echo
  echo '```bash'
  echo "bash deploy/scripts/36_guv45_uygula_dogrula.sh       # GUV-45"
  echo "bash deploy/scripts/38_f1_taze_token_kanit.sh        # F1"
  echo "sudo bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --mask-uygula   # BULGU-05"
  echo "bash deploy/scripts/26_f3_marker_kanit.sh <eposta> '<sifre>'        # F3"
  echo '```'
} > "$OZET"

echo
echo "════════════════════════════════════════════════════════════════════"
echo "  BİRLEŞİK SONUÇ"
echo "────────────────────────────────────────────────────────────────────"
printf '  F1        : %s\n' "$SONUC_F1"
printf '  BULGU-05  : %s\n' "$SONUC_M05"
printf '  GUV-45    : %s\n' "$SONUC_G45"
printf '  F3        : %s\n' "$SONUC_F3"
echo "────────────────────────────────────────────────────────────────────"
echo "  Özet sayfası: $OZET"
echo "════════════════════════════════════════════════════════════════════"

if [[ "$SONUC_F1" = "PASS" && "$SONUC_M05" =~ ^PASS && "$SONUC_G45" = "PASS" ]]; then
  echo
  echo "  ${c_grn}Üç kalem kapandı.${c_rst} F3 için: F3_EMAIL=... F3_PASS='...' bash $0"
  exit 0
fi
echo
echo "  ${c_red}FAIL satırları var${c_rst} — rapora 'kapandı' yazmayın, yukarıdaki yönlendirmeyi uygulayın."
exit 1