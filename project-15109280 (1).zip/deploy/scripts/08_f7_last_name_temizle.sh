#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# PENTEST 2026-10-19 · F7 · Türkçe karakter (mojibake) temizliği
#
# Bulgu: user_metadata.last_name içinde "Aktaş" → "AktaÅ\x9F" (UTF-8'in
# Latin-1 olarak yanlış yorumlanması). profiles tablosu etkilenmemişti.
#
# Bu script VARSAYILAN OLARAK SALT OKUR (dry-run). Hiçbir şeyi değiştirmez.
# Yazmak için:  bash deploy/scripts/08_f7_last_name_temizle.sh --uygula
#
# Kullanım:
#   bash deploy/scripts/08_f7_last_name_temizle.sh
#   bash deploy/scripts/08_f7_last_name_temizle.sh --uygula
#
# Ortam: DB_CONTAINER (varsayılan supabase-db), DB_USER, DB_NAME
# ═══════════════════════════════════════════════════════════════════════════
set -uo pipefail

DB_CONTAINER="${DB_CONTAINER:-supabase-db}"
DB_USER="${DB_USER:-supabase_admin}"
DB_NAME="${DB_NAME:-postgres}"

UYGULA=0
[ "${1:-}" = "--uygula" ] && UYGULA=1

if ! command -v docker >/dev/null 2>&1; then
  echo "❌ docker bulunamadı."
  exit 1
fi

PSQL=(docker exec -i "${DB_CONTAINER}" psql -U "${DB_USER}" -d "${DB_NAME}" -v ON_ERROR_STOP=1)

echo "════════════════════════════════════════════════════════════════"
echo "F7 · MOJIBAKE TARAMASI (salt okuma)"
echo "════════════════════════════════════════════════════════════════"

"${PSQL[@]}" <<'SQL'
-- 1) Etkilenmiş görünen kullanıcılar (mojibake imzası: Ã / Â / Å / Ä)
SELECT
  id,
  raw_user_meta_data->>'first_name' AS ad,
  raw_user_meta_data->>'last_name'  AS soyad_bozuk,
  convert_from(convert_to(raw_user_meta_data->>'last_name', 'LATIN1'), 'UTF8') AS soyad_onerilen
FROM auth.users
WHERE raw_user_meta_data->>'last_name' ~ '[ÃÂÅÄ]'
ORDER BY id;

-- 2) profiles tarafında da aynı sorun var mı?
SELECT id, first_name, last_name
FROM public.profiles
WHERE COALESCE(first_name, '') ~ '[ÃÂÅÄ]'
   OR COALESCE(last_name, '')  ~ '[ÃÂÅÄ]'
ORDER BY id;
SQL

if [ "$UYGULA" -ne 1 ]; then
  echo
  echo "ℹ️  SALT OKUMA modu. Düzeltmek için:  bash $0 --uygula"
  echo "   Önce yedek almanız önerilir:  pg_dump -U ${DB_USER} -d ${DB_NAME} -t auth.users > auth_users_backup.sql"
  exit 0
fi

echo
echo "════════════════════════════════════════════════════════════════"
echo "F7 · DÜZELTME (yalnızca dönüştürülebilen satırlar)"
echo "════════════════════════════════════════════════════════════════"

"${PSQL[@]}" <<'SQL'
BEGIN;

DO $f7$
DECLARE
  r record;
  yeni text;
  sayi int := 0;
  atlanan int := 0;
BEGIN
  FOR r IN
    SELECT id, raw_user_meta_data->>'last_name' AS eski
    FROM auth.users
    WHERE raw_user_meta_data ? 'last_name'
      AND (raw_user_meta_data->>'last_name') ~ '[ÃÂÅÄ]'
  LOOP
    BEGIN
      -- UTF-8 baytları Latin-1 olarak okunmuşsa geri dönüşüm bu şekilde yapılır.
      yeni := convert_from(convert_to(r.eski, 'LATIN1'), 'UTF8');
    EXCEPTION WHEN others THEN
      atlanan := atlanan + 1;
      RAISE NOTICE 'ATLANDI (donusturulemedi): %', r.id;
      CONTINUE;
    END;

    IF yeni IS NULL OR yeni = r.eski THEN
      atlanan := atlanan + 1;
      CONTINUE;
    END IF;

    -- Kontrol: düzeltilmiş değer hâlâ mojibake imzası taşıyor mu?
    IF yeni ~ '[ÃÂÅÄ]' THEN
      atlanan := atlanan + 1;
      RAISE NOTICE 'ATLANDI (imza surdu): %', r.id;
      CONTINUE;
    END IF;

    UPDATE auth.users
       SET raw_user_meta_data = jsonb_set(raw_user_meta_data, '{last_name}', to_jsonb(yeni), true),
           updated_at = now()
     WHERE id = r.id;

    sayi := sayi + 1;
    RAISE NOTICE 'DUZELTILDI % : % -> %', r.id, r.eski, yeni;
  END LOOP;

  RAISE NOTICE 'F7 OZET: duzeltilen=%, atlanan=%', sayi, atlanan;
END
$f7$;

-- profiles tarafı (varsa) aynı mantık
DO $f7p$
DECLARE
  r record;
  yeni text;
  sayi int := 0;
BEGIN
  FOR r IN
    SELECT id, last_name AS eski
    FROM public.profiles
    WHERE last_name ~ '[ÃÂÅÄ]'
  LOOP
    BEGIN
      yeni := convert_from(convert_to(r.eski, 'LATIN1'), 'UTF8');
    EXCEPTION WHEN others THEN
      CONTINUE;
    END;
    IF yeni IS NULL OR yeni = r.eski OR yeni ~ '[ÃÂÅÄ]' THEN CONTINUE; END IF;
    UPDATE public.profiles SET last_name = yeni WHERE id = r.id;
    sayi := sayi + 1;
  END LOOP;
  RAISE NOTICE 'F7 OZET (profiles): duzeltilen=%', sayi;
END
$f7p$;

COMMIT;
SQL

echo
echo "▶ Doğrulama (etkilenmiş satır kalmadı mı?)"
"${PSQL[@]}" -c "
SELECT count(*) FILTER (WHERE raw_user_meta_data->>'last_name' ~ '[ÃÂÅÄ]') AS kalan_bozuk_users
FROM auth.users;"
"${PSQL[@]}" -c "
SELECT count(*) FILTER (WHERE COALESCE(last_name,'') ~ '[ÃÂÅÄ]') AS kalan_bozuk_profiles
FROM public.profiles;"

echo
echo "Not: Yeni kayıtlarda tekrar oluşuyorsa kök neden GoTrue sürümüdür."
echo "     'docker compose pull auth && docker compose up -d auth' ile güncelleyip"
echo "     /auth --version çıktısını pentest kanıtına ekleyin."