#!/usr/bin/env bash
# =============================================================================
# 36 · GUV-45 · F5 avatar_url allowlist SIKILAŞTIRMA — canlı uygula + ispatla
# =============================================================================
# NEREDE ÇALIŞIR : SELF-HOSTED SUNUCU (docker + supabase-db konteyneri)
#
# NEDEN BU BETİK VAR
#   guv45 migration dosyası repoda yazılıydı ama canlı DB'ye UYGULANMAMIŞTI.
#   Uygulanana kadar public.is_allowed_avatar_url() hâlâ `*.supabase.co` ve
#   `*.readdy.ai` jokerlerini kabul ediyordu. Yani saldırgan KENDİ ücretsiz
#   Supabase projesine görsel koyup, kendisini listeleyen herkesin IP /
#   User-Agent bilgisini toplamaya devam edebiliyordu.
#   "webhook.site reddedildi" testi bu senaryoyu KAPSAMAZ.
#
# NE YAPAR
#   1) migration dosyasını bulur ve canlı DB'ye uygular (idempotent: CREATE OR REPLACE)
#   2) 10 ayrı adresi tek tek sorgular ve her biri için PASS/FAIL yazar
#   3) kritik iki adres (başka Supabase projesi + protokol-göreli //evil) REDDEDİLMEZSE
#      betik FAIL döner ve arşiv dosyası YAZILMAZ
#   4) PASS ise /root/pentest-kanit/GUV45_PASS_<stamp>.txt üretir
#
# KULLANIM
#   bash deploy/scripts/36_guv45_uygula_dogrula.sh             # uygula + doğrula
#   bash deploy/scripts/36_guv45_uygula_dogrula.sh --dogrula   # sadece doğrula
#   bash deploy/scripts/36_guv45_uygula_dogrula.sh --kuru      # sadece SQL yazdır
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/../.." && pwd)}"
DB_CONTAINER="${DB_CONTAINER:-supabase-db}"
PGUSER="${PGUSER:-postgres}"
DB_NAME="${DB_NAME:-postgres}"
OUT_DIR="${OUT_DIR:-/root/pentest-kanit}"
MIG="20260101003300_guv45_avatar_url_allowlist_sikilastir.sql"
STAMP="$(date +%Y%m%d-%H%M)"
OUT_LOG="$OUT_DIR/guv45_$STAMP.log"
PASS_FILE="$OUT_DIR/GUV45_PASS_$STAMP.txt"

c_grn=$'\e[32m'; c_red=$'\e[31m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
ok()   { printf '%s %s\n' "${c_grn}PASS${c_rst}" "$*"; }
bad()  { printf '%s %s\n' "${c_red}FAIL${c_rst}" "$*"; }
info() { printf '\n%s\n' "${c_yel}==>${c_rst} $*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

MODE="${1:---uygula}"
case "$MODE" in
  --uygula|--dogrula|--kuru) ;;
  *) die "bilinmeyen parametre: $MODE (--uygula | --dogrula | --kuru)" ;;
esac

MAV=""
for c in "$REPO_ROOT/supabase/migrations/$MIG" "$SCRIPT_DIR/$MIG"; do
  [[ -f "$c" ]] && { MAV="$c"; break; }
done

mkdir -p "$OUT_DIR"
exec > >(tee "$OUT_LOG") 2>&1

echo "════════════════════════════════════════════════════════════════════"
echo "  GUV-45 · F5 avatar_url allowlist sıkılaştırma"
echo "  Tarih : $(date '+%Y-%m-%d %H:%M:%S')"
echo "  Mod   : $MODE"
echo "  Repo  : $REPO_ROOT"
echo "════════════════════════════════════════════════════════════════════"

if [[ -z "$MAV" ]]; then
  die "migration bulunamadı: $MIG (REPO_ROOT=$REPO_ROOT). Dosya sunucuya kopyalanmamış olabilir."
fi
echo "  migration: $MAV"

if [[ "$MODE" = "--kuru" ]]; then
  echo
  sed -n '1,40p' "$MAV"
  echo
  echo "  (--kuru: hiçbir şey uygulanmadı)"
  exit 0
fi

docker ps --format '{{.Names}}' 2>/dev/null | grep -qx "$DB_CONTAINER" \
  || die "$DB_CONTAINER konteyneri çalışmıyor (DB_CONTAINER değişkeniyle adı verebilirsin)."

psql_at() { docker exec -i "$DB_CONTAINER" psql -U "$PGUSER" -d "$DB_NAME" -At -v ON_ERROR_STOP=1 -c "$1" 2>&1; }

# ── Uygula ──────────────────────────────────────────────────────────────────
if [[ "$MODE" = "--uygula" ]]; then
  info "Migration canlı DB'ye uygulanıyor"
  if docker exec -i "$DB_CONTAINER" psql -U "$PGUSER" -d "$DB_NAME" -v ON_ERROR_STOP=1 < "$MAV" > /tmp/guv45_apply.txt 2>&1; then
    ok "migration uygulandı (idempotent: tekrar koşulabilir)"
    grep -E 'NOTICE|ERROR' /tmp/guv45_apply.txt | head -5 | sed 's/^/      /' || true
  else
    bad "migration uygulanamadı — çıktı:"
    sed 's/^/      /' /tmp/guv45_apply.txt | head -30
    die "guv45 uygulanmadı; DB tarafı hâlâ eski joker kurallarını kullanıyor olabilir."
  fi
fi

# ── Doğrula ─────────────────────────────────────────────────────────────────
info "Doğrulama · 10 adres + yetki + tetikleyici"

FAIL=0
kontrol() {
  local etiket="$1" beklenen="$2" ifade="$3" gerekli="${4:-1}"
  local g
  g="$(psql_at "select case when ($ifade) then 't' else 'f' end;" | tr -d '[:space:]')"
  if [[ "$g" = "$beklenen" ]]; then
    printf '  %s izin=%s beklenen=%s  %s\n' "${c_grn}PASS${c_rst}" "$g" "$beklenen" "$etiket"
  else
    if [[ "$gerekli" = "1" ]]; then
      printf '  %s izin=%s beklenen=%s  %s\n' "${c_red}FAIL${c_rst}" "${g:-yok}" "$beklenen" "$etiket"
      FAIL=$((FAIL + 1))
    else
      printf '  %s izin=%s beklenen=%s  %s\n' "${c_yel}UYARI${c_rst}" "${g:-yok}" "$beklenen" "$etiket"
    fi
  fi
}

# Kritik: saldırganın kendi Supabase projesi (F5'in gerçek senaryosu)
kontrol "başka Supabase projesi (*.supabase.co)"        f "public.is_allowed_avatar_url('https://saldirgan-projesi.supabase.co/storage/v1/object/public/x.png')"
kontrol "readdy.ai joker host"                          f "public.is_allowed_avatar_url('https://random.readdy.ai/x.png')"
kontrol "protokol-göreli //evil.example.com"            f "public.is_allowed_avatar_url('//evil.example.com/x.png')"
kontrol "izleme servisi (webhook.site)"                 f "public.is_allowed_avatar_url('https://webhook.site/x')"
kontrol "ngrok tüneli"                                  f "public.is_allowed_avatar_url('https://abc123.ngrok-free.app/x.png')"

# Kendi altyapımız ve meşru yollar
kontrol "kendi storage alan adımız"                     t "public.is_allowed_avatar_url('https://api.isgdenetim.com.tr/storage/v1/object/public/a.png')"
kontrol "kendi app alt alan adı"                        t "public.is_allowed_avatar_url('https://app.isgdenetim.com.tr/avatars/a.png')"
kontrol "göreli uygulama yolu"                          t "public.is_allowed_avatar_url('/avatars/a.png')"
kontrol "gömülü data:image (dış istek yok)"             t "public.is_allowed_avatar_url('data:image/png;base64,iVBORw0KGgo=')"
kontrol "boş / NULL avatar (avatar yok = risk yok)"      t "public.is_allowed_avatar_url(NULL)"

echo
info "Yetki ve tetikleyici"
ANON_EXEC="$(psql_at "select has_function_privilege('anon','public.is_allowed_avatar_url(text)','EXECUTE');" | tr -d '[:space:]')"
if [[ "$ANON_EXEC" = "f" ]]; then ok "anon fonksiyonu ÇAĞIRAMIYOR"; else bad "anon fonksiyonu çağırabiliyor"; FAIL=$((FAIL + 1)); fi

TRG="$(psql_at "select count(*) from pg_trigger where tgrelid='public.profiles'::regclass and tgname='guard_profile_avatar_url_trg' and not tgisinternal;" | tr -d '[:space:]')"
if [[ "$TRG" = "1" ]]; then ok "profiles avatar tetikleyicisi kurulu"; else bad "guard_profile_avatar_url_trg YOK (guv38 uygulanmamış)"; FAIL=$((FAIL + 1)); fi

TRG_EN="$(psql_at "select tgenabled from pg_trigger where tgrelid='public.profiles'::regclass and tgname='guard_profile_avatar_url_trg';" | tr -d '[:space:]')"
if [[ "$TRG_EN" = "O" ]]; then ok "tetikleyici AKTİF"; else bad "tetikleyici kapalı (tgenabled=$TRG_EN)"; FAIL=$((FAIL + 1)); fi

# ── Hüküm ───────────────────────────────────────────────────────────────────
echo
echo "════════════════════════════════════════════════════════════════════"
if [[ "$FAIL" -eq 0 ]]; then
  echo "${c_grn}SONUÇ: GUV-45 PASS${c_rst} — F5 allowlist canlıda sıkı."
  {
    echo "BULGU=GUV-45 (F5)"
    echo "DURUM=PASS"
    echo "MIGRATION=$MIG"
    echo "TEST=10 adres allowlist + anon yetkisi + profiles tetikleyici"
    echo "KANIT=kendi supabase projesi/readdy/ngrok/protokol-goreli -> reddedildi"
    echo "TARIH=$(date '+%Y-%m-%d %H:%M:%S')"
  } > "$PASS_FILE"
  echo "Kanıt dosyası : $OUT_LOG"
  echo "Arşiv satırı  : $PASS_FILE"
  exit 0
fi

echo "${c_red}SONUÇ: GUV-45 KALDI${c_rst} — $FAIL kontrol başarısız. Rapora 'kapandı' yazmayın."
echo "  Kontrol: docker exec -i $DB_CONTAINER psql -U $PGUSER -d $DB_NAME -c \"\\df+ public.is_allowed_avatar_url\""
echo "Kanıt dosyası: $OUT_LOG"
exit 1