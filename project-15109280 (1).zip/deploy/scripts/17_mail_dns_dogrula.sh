#!/usr/bin/env bash
# =============================================================================
# 17 · SPF / DKIM / DMARC (p=reject) — DNS DOĞRULAMA VE KANIT
# =============================================================================
# ÖNEMLİ: DNS kayıtları kodla değiştirilemez. Bu betik:
#   1) Mevcut kayıtları okur (salt okuma),
#   2) Eksik/yanlış olanları ve DNS sağlayıcısına girilecek TAM kayıtları yazar,
#   3) p=none → quarantine → reject geçişi için kademeli plan basar,
#   4) --dogrula modunda rapora konacak NET bir sonuç (GEÇTİ/KALDI) verir.
#
# Kullanım:
#   bash 17_mail_dns_dogrula.sh                         # varsayılan domain
#   DOMAIN=isgdenetim.com.tr bash 17_mail_dns_dogrula.sh
#   DKIM_SELECTOR=resend bash 17_mail_dns_dogrula.sh --dogrula
#
# Çıkış kodu: 0 = hepsi geçti, 1 = eksik var (rapora "KALDI" yazılır)
# =============================================================================
set -uo pipefail

DOMAIN="${DOMAIN:-isgdenetim.com.tr}"
DKIM_SELECTOR="${DKIM_SELECTOR:-resend._domainkey}"
GONDEREN_ALT="${GONDEREN_ALT:-send}"     # Resend return-path alt alanı
MODE="${1:-rapor}"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
ok()   { printf '%s %s\n' "${c_grn}PASS${c_rst}" "$*"; }
bad()  { printf '%s %s\n' "${c_red}KALDI${c_rst}" "$*"; }

command -v dig >/dev/null 2>&1 || { command -v dig >/dev/null 2>&1 || apt-get install -y dnsutils >/dev/null 2>&1 || true; }
if ! command -v dig >/dev/null 2>&1; then
  echo "dig bulunamadı. Kurulum: apt-get install -y dnsutils"; exit 1
fi

# NOT: bir TXT kaydı tek satırdır; satır bazlı okumak ZORUNLU.
# (v=spf1 kaydı boşluk içerdiği için 'boşluktan bölme' kaydı keser.)
txt_lines() { dig +short TXT "$1" 2>/dev/null | tr -d '"' | sed '/^[[:space:]]*$/d'; }
TXT() { txt_lines "$1" | tr '\n' ' '; }
MX()  { dig +short MX "$1" 2>/dev/null | tr '\n' ' '; }

SORUN=0

echo "════════════════════════════════════════════════════════════════"
echo "  E-posta kimlik doğrulama denetimi · domain: $DOMAIN"
echo "  Tarih: $(date '+%Y-%m-%d %H:%M:%S')"
echo "════════════════════════════════════════════════════════════════"

# ── 1) SPF ───────────────────────────────────────────────────────────────────
echo
info "1) SPF (TXT @$DOMAIN)"
KOK_TXT="$(TXT "$DOMAIN")"
SPF="$(txt_lines "$DOMAIN" | grep -i '^v=spf1' | head -1 || true)"
if [[ -z "$SPF" ]]; then
  bad "SPF kaydı YOK"
  echo "     Eklenecek: $DOMAIN  TXT  \"v=spf1 include:_spf.resend.com ~all\""
  SORUN=$((SORUN+1))
else
  ok "SPF: $SPF"
  ADET="$(txt_lines "$DOMAIN" | grep -ic '^v=spf1' || true)"
  ADET="${ADET:-0}"
  [[ "$ADET" -gt 1 ]] && { bad "Birden fazla SPF kaydı ($ADET) — ikinci kayıt SPF'i tamamen geçersiz kılar"; SORUN=$((SORUN+1)); }
  printf '%s' "$SPF" | grep -q -- '-all' && ok "SPF sert bitiş (-all)" || warn "SPF '~all' ile bitiyor — p=reject ile birlikte '-all' önerilir"
fi

# ── 2) DKIM ──────────────────────────────────────────────────────────────────
echo
info "2) DKIM (TXT $DKIM_SELECTOR.$DOMAIN)"
DKIM="$(txt_lines "$DKIM_SELECTOR.$DOMAIN" | grep -i 'p=' | head -1 || true)"
if [[ -z "$DKIM" ]]; then
  bad "DKIM kaydı YOK ($DKIM_SELECTOR.$DOMAIN)"
  echo "     Resend panelinde Domains → ilgili domain → DKIM kaydını kopyalayın."
  echo "     Biçim: <selector>._domainkey.$DOMAIN  TXT  \"p=MIGf...\""
  SORUN=$((SORUN+1))
else
  ok "DKIM mevcut (${#DKIM} karakter)"
  printf '%s' "$DKIM" | grep -q 'p=' && ok "DKIM 'p=' anahtarı var" || { bad "DKIM kaydında 'p=' yok"; SORUN=$((SORUN+1)); }
  printf '%s' "$DKIM" | grep -qi 'p=;' && { bad "DKIM 'p=' BOŞ → anahtar iptal edilmiş"; SORUN=$((SORUN+1)); }
fi

# ── 3) Return-Path / bounce alt alanı ───────────────────────────────────────
echo
info "3) Return-Path alt alanı ($GONDEREN_ALT.$DOMAIN)"
MXR="$(MX "$GONDEREN_ALT.$DOMAIN")"
TXTR="$(txt_lines "$GONDEREN_ALT.$DOMAIN" | grep -i '^v=spf1' | head -1 || true)"
if [[ -z "$MXR" ]]; then
  warn "MX yok ($GONDEREN_ALT.$DOMAIN) — bounce'lar işlenmez, teslim oranı düşer"
  echo "     Resend panelindeki MX kaydını (feedback-smtp...) ekleyin."
else
  ok "MX: $MXR"
fi
[[ -n "$TXTR" ]] && ok "Return-Path SPF: $TXTR" || warn "$GONDEREN_ALT.$DOMAIN TXT (SPF) yok"

# ── 4) DMARC ─────────────────────────────────────────────────────────────────
echo
info "4) DMARC (TXT _dmarc.$DOMAIN)"
DMARC="$(txt_lines "_dmarc.$DOMAIN" | grep -i '^v=DMARC1' | head -1 || true)"
if [[ -z "$DMARC" ]]; then
  bad "DMARC kaydı YOK — p=reject mümkün değil"
  echo "     Başlangıç (2 hafta gözlem):"
  echo "       _dmarc.$DOMAIN  TXT  \"v=DMARC1; p=none; rua=mailto:dmarc@$DOMAIN; ruf=mailto:dmarc@$DOMAIN; fo=1; adkim=s; aspf=s; pct=100\""
  SORUN=$((SORUN+1))
else
  ok "DMARC: $DMARC"
  # DİKKAT: 'aspf=s' içindeki 'p=s' yüzünden naif 'p=[a-z]+' yanlış eşleşir.
  # Bu yüzden yalnızca kayıt başında veya ';' sonrasında gelen p= alınır.
  POL="$(printf '%s' "$DMARC" | grep -oiE '(^|;)[[:space:]]*p=[a-z]+' | head -1 | sed 's/.*p=//I' | tr -d '[:space:]')"
  case "$POL" in
    reject)     ok "Politika p=reject (hedefe ulaşıldı)" ;;
    quarantine)
      if [[ "$MODE" = "--dogrula" ]]; then
        bad     "Politika p=quarantine — hedef p=reject DEĞİL"
        SORUN=$((SORUN+1))
      else
        warn    "Politika p=quarantine — p=reject'e geçiş aşaması"
      fi ;;
    none)
      if [[ "$MODE" = "--dogrula" ]]; then
        bad     "Politika p=none — hedef p=reject DEĞİL"
        SORUN=$((SORUN+1))
      else
        warn    "Politika p=none — sadece gözlem, koruma YOK"
      fi ;;
    *)          bad "Politika okunamadı (p=...)" ; SORUN=$((SORUN+1)) ;;
  esac
  printf '%s' "$DMARC" | grep -q 'rua=' && ok "DMARC raporlama (rua) var" || { warn "rua= yok — körsünüz, rapor gelmez"; }
  printf '%s' "$DMARC" | grep -q 'adkim=s' && ok "adkim=s (strict)" || warn "adkim=s yok — DKIM uyumu gevşek"
  printf '%s' "$DMARC" | grep -q 'aspf=s'  && ok "aspf=s (strict)"  || warn "aspf=s yok — SPF uyumu gevşek"
fi

# ── 5) Altyapı notu ─────────────────────────────────────────────────────────
echo
info "5) Ağ katmanı hatırlatması"
echo "  DMARC p=reject, SPF ve DKIM'e dayanır; ama uygulama içinden yapılan"
echo "  isteklere (SSRF) karşı HİÇBİR koruma sağlamaz. O katman ayrı:"
echo "    → deploy/scripts/18_egress_firewall.sh (169.254.169.254 + özel IP blokajı)"

# ── Kademeli geçiş planı ────────────────────────────────────────────────────
if [[ "$MODE" != "--dogrula" ]]; then
cat <<EOF

════════════════════════════════════════════════════════════════
  p=reject'e KADEMELİ GEÇİŞ PLANI (önerilen takvim)
════════════════════════════════════════════════════════════════
  Aşama 0 · Bugün
    SPF + DKIM + return-path MX/TXT tamamlanır. DMARC p=none + rua açılır.

  Aşama 1 · +7 gün   (p=none, gözlem)
    DMARC raporlarını (rua) incele. Kendi kaynaklarından gelen ve
    DMARC'te FAIL olan var mı? Varsa o kaynağı SPF/DKIM'e ekle.

  Aşama 2 · +14 gün  (p=quarantine; pct=25 → 50 → 100)
    _dmarc.$DOMAIN  TXT  "v=DMARC1; p=quarantine; pct=25; rua=mailto:dmarc@$DOMAIN; adkim=s; aspf=s"
    Her 3-4 günde pct artır. Reddedilen meşru posta var mı izle.

  Aşama 3 · +28 gün  (p=reject)
    _dmarc.$DOMAIN  TXT  "v=DMARC1; p=reject; rua=mailto:dmarc@$DOMAIN; ruf=mailto:dmarc@$DOMAIN; fo=1; adkim=s; aspf=s; pct=100"

  ⚠️ p=reject'e geçmeden önce: tüm gönderim kaynakları (Resend + varsa
     kurumsal SMTP / Google Workspace / imza servisi) SPF veya DKIM'de
     hizalı olmalı. Aksi halde meşru e-postalar reddedilir.
EOF
fi

# ── Sonuç ───────────────────────────────────────────────────────────────────
echo
if [[ "$SORUN" = "0" ]]; then
  echo "${c_grn}SONUÇ: PASS — SPF, DKIM ve DMARC kayıtları yerinde.${c_rst}"
  exit 0
else
  echo "${c_red}SONUÇ: $SORUN kayıt eksik/hatalı — DNS sağlayıcısında düzeltilmeden rapora 'kapandı' yazmayın.${c_rst}"
  exit 1
fi