# =============================================================================
# 30 · WINDOWS'TAN SUNUCUYA PENTEST KAPANIŞI  (PowerShell yardımcısı)
# =============================================================================
# NEDEN VAR:
#   29_ / 26_ betikleri LINUX içindir ve SUNUCUDA çalışır. Windows'ta
#   "sudo" yoktur, "bash deploy/..." de yerelde dosya bulamaz. Bu betik
#   yereldeki dosyaları sunucuya kopyalar ve doğru makinede çalıştırır.
#
# KULLANIM (PowerShell, proje kökünde):
#   .\deploy\scripts\30_uzaktan_kapat.ps1                 # sadece ÖLÇ (hiçbir şey değiştirmez)
#   .\deploy\scripts\30_uzaktan_kapat.ps1 -Adim uygula    # Caddyfile kur + HSTS/gövde limiti
#   .\deploy\scripts\30_uzaktan_kapat.ps1 -Adim mask      # PostgREST maskeleyici
#   .\deploy\scripts\30_uzaktan_kapat.ps1 -Adim f3 -Eposta x@y.com -Sifre '***'
#   .\deploy\scripts\30_uzaktan_kapat.ps1 -Adim hepsi -Eposta x@y.com -Sifre '***'
#
# NOTLAR:
#   * -Adim olc hiçbir yapılandırma değiştirmez, sadece HTTP ölçümü yapar.
#   * -Adim uygula, Caddy kurulu DEĞİLSE durur (nginx/Cloudflare kullanıyorsan
#     Caddyfile yanlış çözüm olur, o yüzden zorlamıyor).
#   * Şifre tek tırnak içinde verilirse komut bozulmaz: 'YeniSifre.2026.Aa1'
#   * Sunucuya SSH anahtarıyla giriş yapılıyorsa şifre sorulmaz.
#   * Sunucuda "git pull" GEREKMEZ. Betik gerekli dosyaları kendisi kopyalar.
#     Self-host kurulumda proje genelde /opt/ibys altındadır; -Repo boş
#     bırakılırsa betik sırayla /opt/ibys, /root/ibys, /root/isg-deploy bakar.
# =============================================================================
[CmdletBinding()]
param(
    [ValidateSet('olc', 'uygula', 'mask', 'f3', 'hepsi')]
    [string]$Adim = 'olc',

    [string]$Server = '37.230.105.216',
    [string]$Port = '23422',
    [string]$User = 'root',

    # Boş bırakılırsa sunucuda otomatik bulunur.
    [string]$Repo = '',

    [string]$Eposta = '',
    [string]$Sifre = '',

    # Caddy kurulu değilse --uygula adımını yine de denemek için.
    [switch]$Zorla
)

$ErrorActionPreference = 'Stop'
$Target = "$User@$Server"
$Yerel = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path

function Baslik([string]$m) {
    Write-Host ''
    Write-Host ('=' * 74) -ForegroundColor DarkGray
    Write-Host "  $m" -ForegroundColor Cyan
    Write-Host ('=' * 74) -ForegroundColor DarkGray
}

function Uzak([string]$cmd) {
    Write-Host "  -> $cmd" -ForegroundColor DarkGray
    & ssh -p $Port $Target $cmd
    return $LASTEXITCODE
}

function UzakCikti([string]$cmd) {
    return (& ssh -p $Port $Target $cmd 2>$null | Out-String).Trim()
}

# ── 0) Bağlantı testi ───────────────────────────────────────────────────────
Baslik '0 · Sunucu bağlantısı'
$kimlik = UzakCikti 'hostname; id -un'
if (-not $kimlik) {
    Write-Host '  SSH bağlantısı kurulamadı. Anahtar/şifre ve port bilgisini kontrol et.' -ForegroundColor Red
    exit 1
}
Write-Host "  OK · $($kimlik -replace "`r?`n", ' / ')" -ForegroundColor Green

# ── 1) Sunucudaki proje dizinini bul ────────────────────────────────────────
Baslik '1 · Sunucudaki proje dizini'
if (-not $Repo) {
    $bulunan = UzakCikti "find / -maxdepth 7 -type f -name '26_f3_marker_kanit.sh' 2>/dev/null | head -1"
    if ($bulunan) {
        # .../deploy/scripts/26_....sh  ->  proje kökü
        $Repo = $bulunan -replace '/deploy/scripts/26_f3_marker_kanit\.sh$', ''
        Write-Host "  bulundu: $Repo" -ForegroundColor Green
    }
    else {
        # Sunucudaki kopya eski olabilir (betik dosyası hiç yok). Bilinen kurulum dizinlerine bak.
        foreach ($aday in @('/opt/ibys', '/root/ibys', '/root/isg-deploy', '/srv/ibys')) {
            if ((UzakCikti "test -d '$aday' && echo var || echo yok") -eq 'var') {
                $Repo = $aday
                Write-Host "  bulundu (bilinen dizin): $Repo" -ForegroundColor Green
                break
            }
        }
        if (-not $Repo) {
            Write-Host '  Sunucuda proje dizini bulunamadı.' -ForegroundColor Red
            Write-Host '  Doğru yolu -Repo "/opt/ibys" gibi vererek belirt.' -ForegroundColor Yellow
            exit 1
        }
    }
}
else {
    Write-Host "  verilen: $Repo" -ForegroundColor Green
}
if ($Repo -eq '/') {
    Write-Host '  Proje kökü "/" çıktı, bu doğru değil. -Repo ile elle ver.' -ForegroundColor Red
    exit 1
}

# ── 2) Dosyaları sunucuya kopyala ───────────────────────────────────────────
Baslik '2 · Gerekli dosyalar sunucuya kopyalanıyor'
$hedefDizinler = @(
    "$Repo/deploy/scripts",
    "$Repo/deploy/caddy",
    "$Repo/deploy/postgrest-mask"
)
foreach ($d in $hedefDizinler) {
    & ssh -p $Port $Target "mkdir -p '$d'" | Out-Null
}

$dosyalar = @(
    @{ Yerel = 'deploy/scripts/29_bulgu_01_05_08_kapat.sh'; Uzak = "$Repo/deploy/scripts/" },
    @{ Yerel = 'deploy/scripts/26_f3_marker_kanit.sh'; Uzak = "$Repo/deploy/scripts/" },
    @{ Yerel = 'deploy/scripts/27_bulgu_03_07_dogrula.sh'; Uzak = "$Repo/deploy/scripts/" },
    @{ Yerel = 'deploy/caddy/Caddyfile'; Uzak = "$Repo/deploy/caddy/" },
    @{ Yerel = 'deploy/docker-compose.postgrest-mask.yml'; Uzak = "$Repo/deploy/" },
    @{ Yerel = 'deploy/postgrest-mask/server.mjs'; Uzak = "$Repo/deploy/postgrest-mask/" },
    @{ Yerel = 'deploy/postgrest-mask/Dockerfile'; Uzak = "$Repo/deploy/postgrest-mask/" },
    @{ Yerel = 'deploy/postgrest-mask/README.md'; Uzak = "$Repo/deploy/postgrest-mask/" },
    @{ Yerel = 'PENTEST_BIRLESIK_KAPANIS_2026-10-20.md'; Uzak = "$Repo/" }
)

$kopya = 0
$atlanan = 0
foreach ($f in $dosyalar) {
    $kaynak = Join-Path $Yerel $f.Yerel
    if (-not (Test-Path $kaynak)) {
        Write-Host "  atlandı (yerelde yok): $($f.Yerel)" -ForegroundColor Yellow
        $atlanan++
        continue
    }
    & scp -P $Port $kaynak "$($Target):$($f.Uzak)" 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  kopyalandı: $($f.Yerel)" -ForegroundColor Green
        $kopya++
    }
    else {
        Write-Host "  HATA: $($f.Yerel)" -ForegroundColor Red
    }
}
Write-Host "  toplam: $kopya kopyalandı, $atlanan atlandı" -ForegroundColor DarkGray

# Sunucuda çalıştırılabilir + CRLF temizliği
& ssh -p $Port $Target "cd '$Repo' && sed -i 's/\r$//' deploy/scripts/29_bulgu_01_05_08_kapat.sh deploy/scripts/26_f3_marker_kanit.sh 2>/dev/null; chmod +x deploy/scripts/*.sh 2>/dev/null; true" | Out-Null

# ── 3) Ölçüm (varsayılan, hiçbir şeyi değiştirmez) ──────────────────────────
function Olcum {
    Baslik '3 · ÖLÇÜM (yapılandırma değiştirilmez)'
    Uzak "cd '$Repo' && bash deploy/scripts/29_bulgu_01_05_08_kapat.sh" | Out-Null
}

# ── 4) Caddy kurulumu ───────────────────────────────────────────────────────
function CaddyUygula {
    Baslik '4 · Caddyfile kurulumu (HSTS + gövde limiti)'
    $varMi = UzakCikti 'command -v caddy || true'
    if (-not $varMi) {
        Write-Host '  Sunucuda "caddy" komutu YOK.' -ForegroundColor Yellow
        Write-Host '  Bu, web sunucusunun Caddy olmadığı anlamına gelir (nginx/Cloudflare olabilir).' -ForegroundColor Yellow
        Write-Host '  Caddyfile yazmak siteyi kırar. Önce şunu çalıştır ve bana çıktıyı gönder:' -ForegroundColor Yellow
        Write-Host "    ssh -p $Port $Target `"command -v nginx; docker ps --format '{{.Names}}' | head -20`"" -ForegroundColor DarkGray
        if (-not $Zorla) {
            Write-Host '  Adım atlandı. Zorlamak için -Zorla ekle.' -ForegroundColor Yellow
            return
        }
        Write-Host '  -Zorla verildi, devam ediliyor.' -ForegroundColor Yellow
    }
    Uzak "cd '$Repo' && bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --uygula" | Out-Null
    Write-Host '  NOT: app.isgdenetim.com.tr bloğundaki "root * /var/www/app" satırı' -ForegroundColor Yellow
    Write-Host '       gerçek yayın dizininle aynı mı? Değilse site 404 verir, düzelt.' -ForegroundColor Yellow
}

# ── 5) PostgREST maskeleyici ────────────────────────────────────────────────
function MaskBaslat {
    Baslik '5 · PostgREST şema ifşası maskeleyici (tek komut)'
    # --mask-uygula: servisi başlatır, Caddyfile'ı kurar, uçtan uca ölçer.
    # Ölçüm PASS değilse Caddyfile'ı kendisi geri alır (site 502'de kalmaz).
    Uzak "cd '$Repo' && bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --mask-uygula" | Out-Null
    Write-Host '  Beklenen satır: PASS BULGU-05 · şema ifşası MASKELENDİ (uçtan uca doğrulandı)' -ForegroundColor Yellow
    Write-Host '  Bu satır gelmezse çıktıyı olduğu gibi paylaş.' -ForegroundColor Yellow
}

# ── 6) F3 marker kanıtı ─────────────────────────────────────────────────────
function F3Kanit {
    Baslik '6 · F3 marker kanıtı (auth-log → system_logs)'
    if (-not $Eposta -or -not $Sifre) {
        Write-Host '  -Eposta ve -Sifre gerekli. Örnek:' -ForegroundColor Red
        Write-Host "    .\deploy\scripts\30_uzaktan_kapat.ps1 -Adim f3 -Eposta isgsaas@outlook.com -Sifre 'YeniSifre.2026.Aa1'" -ForegroundColor DarkGray
        return
    }
    Uzak "cd '$Repo' && bash deploy/scripts/26_f3_marker_kanit.sh '$Eposta' '$Sifre'" | Out-Null
}

# ── Akış ────────────────────────────────────────────────────────────────────
switch ($Adim) {
    'olc'     { Olcum }
    'uygula'  { CaddyUygula; Olcum }
    'mask'    { MaskBaslat; Olcum }
    'f3'      { F3Kanit }
    'hepsi'   { CaddyUygula; MaskBaslat; Olcum; F3Kanit }
}

Baslik 'BİTTİ'
Write-Host '  Kanıt dosyaları sunucuda: /root/pentest-kanit/' -ForegroundColor DarkGray
Write-Host "  Görmek için: ssh -p $Port $Target 'ls -t /root/pentest-kanit | head'" -ForegroundColor DarkGray
Write-Host ''