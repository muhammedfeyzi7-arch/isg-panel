#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# AUTH ŞEMASI — Veri Taşıma (DDL'siz)
#
# Neden ayrı bir script?
#   Self-host Supabase'de auth.* ve storage.* tabloları postgres rolüne AİT DEĞİL;
#   sahipleri supabase_auth_admin / supabase_storage_admin'dir. Bu yüzden tam
#   pg_restore "must be owner of table ..." hataları yağdırır (bunlar VERİ değil,
#   index / constraint / RLS gibi YAPISAL ifadelerdir — zararsızdır).
#
# Bu script:
#   1) Yalnızca kullanıcı HESAP verisini çeker (auth.users + auth.identities)
#   2) Hedefteki auth tablolarını superuser ile tazeler
#   3) Veriyi konteyner içindeki gerçek superuser (supabase_admin) ile yükler
#   4) TRUNCATE ... CASCADE'in boşalttığı public tabloları YEDEKTEN otomatik
#      geri yükler (aşağıdaki "Neden adım 5 var?" notuna bakın)
#
# Çalıştırmadan önce:
#   export KAYNAK_DB_URL="postgresql://postgres.<ref>:<SIFRE>@aws-0-<region>.pooler.supabase.com:5432/postgres"
# Kullanım:
#   bash deploy/scripts/02b-auth-veri-tasi.sh
#
# Neden adım 5 var?
#   auth.users'a FK ile bağlı public tablolar vardır. `TRUNCATE auth.users CASCADE`
#   bu tabloları da boşaltır (veri kaybettirir). Bu yüzden 3. adımdan sonra,
#   02-db-tasi.sh'in aldığı en güncel tam yedekten sadece bu tabloların VERİSİ
#   yeniden yüklenir. Böylece script tekrar çalıştırılsa bile veri kaybolmaz.
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

KAYNAK_DB_URL="${KAYNAK_DB_URL:?KAYNAK_DB_URL tanimli degil}"
DOCKER_DIR="${DOCKER_DIR:-/opt/ibys/supabase/docker}"
COMPOSE_FILE="${DOCKER_DIR}/docker-compose.yml"
GECICI="${GECICI:-/tmp/auth-data.sql}"
YEDEK_DIZIN="${YEDEK_DIZIN:-/opt/ibys/yedekler}"

# auth.users'a FK ile bağlı olduğu için TRUNCATE ... CASCADE ile boşalan public tablolar
ETKILENEN_TABLOLAR=(
  custom_icons
  email_signatures
  mail_connections
  mail_credentials
  mail_logs
  mail_oauth_states
  personel_notlari
)

dpsql() { docker compose -f "${COMPOSE_FILE}" exec -T db psql -U supabase_admin -d postgres "$@"; }

echo "==> 1/5  auth VERISI (users + identities) kaynaktan cekiliyor"
pg_dump "${KAYNAK_DB_URL}" --data-only --no-owner --no-privileges \
  --table=auth.users --table=auth.identities \
  -f "${GECICI}"
echo "    Dosya: ${GECICI} ($(du -h "${GECICI}" | cut -f1))"

if ! grep -q "COPY auth.users" "${GECICI}"; then
  echo "!! UYARI: Dump icinde auth.users COPY blogu bulunamadi. Kaynakta veri bos olabilir."
fi

echo "==> 2/5  Hedef auth tablolari tazeleniyor (superuser)"
echo "    !! DIKKAT: Bu islem, auth.users'a FK ile bagli su public tablolari da BOSALTIR:"
printf '    !!   - %s\n' "${ETKILENEN_TABLOLAR[@]}"
echo "    !! (5. adimda bunlar yedekten otomatik geri yuklenecek)"
dpsql -c "TRUNCATE auth.identities, auth.users CASCADE;"

echo "==> 3/5  Veri yukleniyor (superuser — sahiplik sorunu yok)"
dpsql -v ON_ERROR_STOP=1 < "${GECICI}"

echo "==> 4/5  Dogrulama (auth)"
dpsql -c "select count(*) as kullanici_sayisi from auth.users;"
dpsql -c "select count(*) as kimlik_kaydi from auth.identities;"

echo "==> 5/5  CASCADE ile bosalan public tablolar yedekten geri yukleniyor"
DUMP="$(ls -t "${YEDEK_DIZIN}"/kaynak-*.dump 2>/dev/null | head -n1 || true)"
if [ -z "${DUMP}" ]; then
  echo "    !! UYARI: ${YEDEK_DIZIN} icinde kaynak-*.dump bulunamadi."
  echo "    !!        Asagidaki tablolari elle kontrol edin; bos kalmis olabilirler:"
  printf '    !!   - %s\n' "${ETKILENEN_TABLOLAR[@]}"
else
  echo "    Kullanilan yedek: ${DUMP}"
  ARGS=()
  for t in "${ETKILENEN_TABLOLAR[@]}"; do ARGS+=(--table="${t}"); done
  if pg_restore --no-owner --no-privileges --data-only -f - "${ARGS[@]}" "${DUMP}" \
      | dpsql -v ON_ERROR_STOP=1; then
    echo "    Bu tablolarin geri yukleme dogrulamasi:"
    dpsql -c "$(printf 'select %s;\n' \
      "count(*) as custom_icons from custom_icons" \
      "count(*) as email_signatures from email_signatures" \
      "count(*) as mail_connections from mail_connections" \
      "count(*) as mail_credentials from mail_credentials" \
      "count(*) as mail_logs from mail_logs" \
      "count(*) as mail_oauth_states from mail_oauth_states" \
      "count(*) as personel_notlari from personel_notlari")"
  else
    echo "    !! UYARI: Yedekten veri geri yuklemede hata olustu (yukaridaki cikti)."
    echo "    !!        Script devam ediyor; ilgili tablolari elle kontrol edin."
  fi
fi

echo ""
echo "TAMAM. auth kullanici verisi tasindi.