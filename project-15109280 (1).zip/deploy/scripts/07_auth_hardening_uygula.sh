#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# PENTEST 2026-10-19 · F1 + F6 · AUTH SERTLEŞTİRMEYİ UYGULA (v2)
#
# NEDEN v2:
#   v1, auth bloğunu docker-compose.override.yml içine birleştiriyordu.
#   Ancak saha testinde görüldü ki override dosyası yüklense bile (functions
#   env'leri merge oluyor) auth bloğunun environment'ı config'e/container'a
#   girmiyor. Bu yüzden artık merge'e GÜVENMİYORUZ:
#
#   - Ayarlar AYRI bir dosyada tutulur: docker-compose.auth-hardening.yml
#   - Bu dosya compose zincirine .env içindeki COMPOSE_FILE ile KALICI olarak
#     eklenir (yedek alınır, mevcut değer varsa dokunulmaz)
#   - Doğrulama "docker compose config" çıktısından DEĞİL, çalışan container'ın
#     kendi printenv çıktısından yapılır
#
# Kullanım:
#   bash deploy/scripts/07_auth_hardening_uygula.sh
#   bash deploy/scripts/07_auth_hardening_uygula.sh --dogrula   # sadece kontrol
#   COMPOSE_FILE_KULLAN=0 bash deploy/scripts/07_auth_hardening_uygula.sh
#       → .env'e dokunmaz, sadece açık -f zinciri ile uygular
#
# Geri alma:
#   cd /opt/ibys/supabase/docker
#   cp -p .env.bak.<TARIH> .env
#   rm -f docker-compose.auth-hardening.yml
#   docker compose up -d --force-recreate auth
# ═══════════════════════════════════════════════════════════════════════════
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"
DOCKER_DIR="${DOCKER_DIR:-/opt/ibys/supabase/docker}"
KAYNAK="${REPO_ROOT}/deploy/docker-compose.auth-hardening.yml"
EKLENTI="docker-compose.auth-hardening.yml"
COMPOSE_FILE_KULLAN="${COMPOSE_FILE_KULLAN:-1}"

SADECE_DOGRULA=0
[ "${1:-}" = "--dogrula" ] && SADECE_DOGRULA=1

echo "════════════════════════════════════════════════════════════════"
echo "PENTEST F1 + F6 · AUTH SERTLEŞTİRME (v2)"
echo "  docker dizini : ${DOCKER_DIR}"
echo "  kaynak        : ${KAYNAK}"
echo "════════════════════════════════════════════════════════════════"

if [ "$SADECE_DOGRULA" -eq 1 ]; then
  bash "${SCRIPT_DIR}/06-pentest-auth-kontrol.sh"
  exit $?
fi

if [ ! -f "${KAYNAK}" ]; then
  echo "❌ Override dosyası bulunamadı: ${KAYNAK}"
  exit 1
fi
if [ ! -d "${DOCKER_DIR}" ]; then
  echo "❌ Docker dizini bulunamadı: ${DOCKER_DIR}"
  echo "   DOCKER_DIR=/gercek/yol bash $0 şeklinde çalıştırın."
  exit 1
fi

cd "${DOCKER_DIR}" || exit 1

# ── 1) Ayrı sertleştirme dosyasını yerleştir ───────────────────────────────
if [ -f "${EKLENTI}" ] && grep -q 'GOTRUE_SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION' "${EKLENTI}"; then
  echo "ℹ️  ${EKLENTI} zaten yerinde."
else
  cp "${KAYNAK}" "${EKLENTI}"
  echo "✅ ${DOCKER_DIR}/${EKLENTI} yerleştirildi."
fi

# ── 2) Compose zincirine KALICI olarak ekle ────────────────────────────────
COMPOSE_ARGS=""
MEVCUT_CF=""
if [ -f .env ]; then
  MEVCUT_CF="$(grep -hE '^[[:space:]]*COMPOSE_FILE=' .env | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'" || true)"
fi

# Temel zincir: mevcut COMPOSE_FILE varsa onun üzerine kur, yoksa standart iki dosya
if [ -n "${MEVCUT_CF}" ]; then
  ZINCIR="${MEVCUT_CF}"
else
  ZINCIR="docker-compose.yml"
fi

# docker-compose.override.yml gerçekten duruyorsa ve zincirde yoksa ekle
if [ -f docker-compose.override.yml ] && ! printf '%s' ":${ZINCIR}:" | grep -q ':docker-compose.override.yml:'; then
  ZINCIR="${ZINCIR}:docker-compose.override.yml"
fi

# auth sertleştirme dosyası zincirde yoksa sona ekle
if ! printf '%s' ":${ZINCIR}:" | grep -q ":${EKLENTI}:"; then
  ZINCIR="${ZINCIR}:${EKLENTI}"
fi

if [ "${COMPOSE_FILE_KULLAN}" = "1" ]; then
  if [ ! -f .env ]; then
    echo "⚠️  .env bulunamadı — COMPOSE_FILE yazılamadı, açık -f zinciri kullanılacak."
    COMPOSE_ARGS="-f docker-compose.yml -f docker-compose.override.yml -f ${EKLENTI}"
  elif [ "${ZINCIR}" = "${MEVCUT_CF}" ]; then
    echo "ℹ️  .env → COMPOSE_FILE zaten güncel: ${MEVCUT_CF}"
  else
    ENV_YEDEK=".env.bak.$(date +%Y%m%d_%H%M%S)"
    cp -p .env "${ENV_YEDEK}"

    # Yorum satırlarına dokunmadan, SADECE aktif COMPOSE_FILE satır(lar)ını güncelle
    awk -v yeni="${ZINCIR}" '
      BEGIN { yazildi = 0 }
      /^[[:space:]]*#[[:space:]]*COMPOSE_FILE=/ { print; next }
      /^[[:space:]]*COMPOSE_FILE=/ {
        if (!yazildi) { print "COMPOSE_FILE=" yeni; yazildi = 1 }
        next
      }
      { print }
      END {
        if (!yazildi) {
          print ""
          print "# PENTEST 2026-10-19 · F1+F6 auth sertleştirme dosyası compose zincirine eklendi"
          print "COMPOSE_FILE=" yeni
        }
      }
    ' "${ENV_YEDEK}" > .env

    echo "✅ .env güncellendi (yedek: ${DOCKER_DIR}/${ENV_YEDEK})"
    echo "   ESKİ: COMPOSE_FILE=${MEVCUT_CF:-<yok>}"
    echo "   YENİ: COMPOSE_FILE=${ZINCIR}"
  fi

  # Yazılan zincir tek kaynak olsun
  COMPOSE_ARGS=""
  echo "ℹ️  Kısa yol (docker compose) kullanılacak — .env içindeki COMPOSE_FILE geçerli."
else
  COMPOSE_ARGS="-f docker-compose.yml -f docker-compose.override.yml -f ${EKLENTI}"
  echo "ℹ️  COMPOSE_FILE_KULLAN=0 → yalnızca açık -f zinciri kullanılacak (kalıcı değil)."
fi

# ── 3) Merge kontrolü (bilgi amaçlı, tek başına yeterli DEĞİL) ─────────────
echo
echo "▶ Merge kontrolü (docker compose config)..."
# shellcheck disable=SC2086
if docker compose ${COMPOSE_ARGS} config 2>/dev/null \
   | grep -qE 'GOTRUE_SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION'; then
  echo "  ✅ config çıktısında auth ayarları görünüyor."
else
  echo "  ⚠️  config çıktısında görünmüyor — yine de container içinden doğrulanacak."
fi

# ── 4) Uygula ──────────────────────────────────────────────────────────────
echo
echo "▶ auth container'ı yeniden başlatılıyor..."
# shellcheck disable=SC2086
docker compose ${COMPOSE_ARGS} up -d --force-recreate auth || {
  echo "❌ docker compose başarısız. Loglar:"
  # shellcheck disable=SC2086
  docker compose ${COMPOSE_ARGS} logs --tail 40 auth
  exit 1
}

echo
echo "▶ Container'ın ayağa kalkması bekleniyor..."
sleep 8

# ── 5) Container içi env doğrulaması (ASIL KANIT) ──────────────────────────
echo
echo "▶ Container içi env doğrulaması..."
# shellcheck disable=SC2086
AUTH_ENV="$(docker compose ${COMPOSE_ARGS} exec -T auth printenv 2>/dev/null || true)"
ENV_SORUN=0
for ANAHTAR in \
  GOTRUE_SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION \
  GOTRUE_PASSWORD_MIN_LENGTH \
  GOTRUE_PASSWORD_HIBP_ENABLED
do
  DEGER="$(printf '%s\n' "$AUTH_ENV" | grep "^${ANAHTAR}=" | head -1 | cut -d= -f2-)"
  if [ -n "${DEGER}" ]; then
    echo "  ✅ ${ANAHTAR}=${DEGER}"
  else
    echo "  ❌ ${ANAHTAR} container içinde YOK"
    ENV_SORUN=1
  fi
done

if [ "$ENV_SORUN" -eq 1 ]; then
  echo
  echo "❌ Env hâlâ container'a ulaşmadı. Sırayla bakılacaklar:"
  echo "   1) docker compose config --format json | python3 -c \"import json,sys;d=json.load(sys.stdin);print(sorted(d['services']['auth']['environment']))\""
  echo "   2) ls -la docker-compose*.y*ml"
  echo "   3) grep -n 'COMPOSE_FILE' .env"
  echo "   4) docker compose -f docker-compose.yml -f docker-compose.override.yml -f ${EKLENTI} up -d --force-recreate auth"
  echo "   5) docker compose logs auth --tail 60 | grep -iE 'reauth|unknown|config|warn'"
else
  echo "  ✅ Üç ayar da container içinde yüklü."
fi

# ── 6) Salt-okuma kontrol betiği ───────────────────────────────────────────
echo
bash "${SCRIPT_DIR}/06-pentest-auth-kontrol.sh"
KONTROL=$?

echo
if [ "$ENV_SORUN" -eq 1 ]; then
  echo "❌ Merge sorunu kapanmadan F1/F6 kapanmış sayılmaz."
  exit 1
fi

if [ "$KONTROL" -eq 0 ]; then
  echo "✅ F1 + F6 ayarları container'a yüklendi. Retest (asıl kanıt):"
  echo
  echo "   # mevcut şifre GÖNDERİLMEDEN — beklenen 400 reauthentication_needed"
  echo "   curl -sS -o /dev/null -w '%{http_code}\\n' -X PUT \"\$API/auth/v1/user\" \\"
  echo "     -H \"apikey: \$SB_KEY\" -H \"Authorization: Bearer \$TOKEN\" \\"
  echo "     -H 'Content-Type: application/json' -d '{\"password\":\"PwnedF1.2026!#XyZ\"}'"
  echo
  echo "   # 200 dönerse: GoTrue sürümü ayarı tanımıyor olabilir (F7 ile birleşir)"
  echo "   docker compose logs auth --tail 60 | grep -iE 'reauth|unknown|warn'"
else
  echo "⚠️  Kontrol betiği bazı değerleri kırmızı gösterdi. Yukarıdaki çıktıyı inceleyin."
fi
exit "$KONTROL"