#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# PENTEST 2026-10-19 · F1 RETEST — ŞİFRE DEĞİŞİMİNDE YENİDEN DOĞRULAMA
#
# Ne yapar:
#   1) .env içinden ANON_KEY / SERVICE_ROLE_KEY ve API portunu okur
#   2) --hesap-olustur ile test hesabını (yoksa) oluşturur, varsa şifresini
#      bilinen değere sabitler  → "token 0 geldi" derdi biter
#   3) GERÇEK login yapar, token'ı DECODE eder (iat / exp / session_id / sub)
#   4) --eskit ile SADECE bu oturumun created_at değerini 3 gün geriye çeker
#   5) PUT /auth/v1/user {"password":"..."} çağrısını YALNIZCA token ile atar
#      (mevcut şifre / nonce GÖNDERİLMEZ)
#   6) HTTP kodu + gövdeyi yorumlar
#
# Beklenen sonuç:
#   - Oturum 24 saatten ESKİ ise  → 400 reauthentication_needed  (F1 KAPANDI)
#   - Oturum 24 saatten YENİ ise  → 200 (GoTrue bu eşiğin altında nonce istemez)
#     Bu bir hata değildir; "eski oturum" testi için --eskit kullan.
#
# Kullanım:
#   bash 09_f1_retest.sh --hesap-olustur --eskit
#   bash 09_f1_retest.sh --geri-al
#   bash 09_f1_retest.sh --sifre-sifirla
#
#   Opsiyonel env: EMAIL, PASSWORD, YENI_SIFRE, API_URL, DOCKER_DIR
#   EMAIL varsayılanı: f1.retest@ornek.com
#
# Gereksinimler: docker compose erişimi, python3, curl
# ═══════════════════════════════════════════════════════════════════════════
set -uo pipefail

DOCKER_DIR="${DOCKER_DIR:-/opt/ibys/supabase/docker}"
EMAIL="${EMAIL:-f1.retest@ornek.com}"
PASSWORD="${PASSWORD:-Gecerli.Sifre.2026!Aa}"
YENI_SIFRE="${YENI_SIFRE:-$(python3 -c "import secrets,string;a=string.ascii_letters+string.digits;print('F1'+''.join(secrets.choice(a) for _ in range(18)))" 2>/dev/null)}"
[ -z "$YENI_SIFRE" ] && YENI_SIFRE="F1Test.$(date +%s).Aa9"
API_URL="${API_URL:-}"
HESAP_OLUSTUR=0
ESKIT=0
GERI_AL=0
SIFRE_SIFIRLA=0
VERBOSE=0

for ARG in "$@"; do
  case "$ARG" in
    --hesap-olustur) HESAP_OLUSTUR=1 ;;
    --eskit)         ESKIT=1 ;;
    --geri-al)       GERI_AL=1 ;;
    --sifre-sifirla) SIFRE_SIFIRLA=1 ;;
    --verbose)       VERBOSE=1 ;;
    -h|--help)       sed -n '2,34p' "$0"; exit 0 ;;
    *) echo "❌ Bilinmeyen parametre: $ARG"; exit 2 ;;
  esac
done

if [ ! -d "$DOCKER_DIR" ]; then
  echo "❌ Docker dizini bulunamadı: $DOCKER_DIR"
  exit 1
fi
cd "$DOCKER_DIR" || exit 1

command -v python3 >/dev/null 2>&1 || { echo "❌ python3 gerekli."; exit 1; }

# ── .env oku ───────────────────────────────────────────────────────────────
env_al() {
  grep -hE "^[[:space:]]*$1=" .env 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'"
}

ANON_KEY="${ANON_KEY:-$(env_al ANON_KEY)}"
SERVICE_KEY="${SERVICE_ROLE_KEY:-$(env_al SERVICE_ROLE_KEY)}"
KONG_PORT="${KONG_HTTP_PORT:-$(env_al KONG_HTTP_PORT)}"
KONG_PORT="${KONG_PORT:-8000}"
[ -z "$API_URL" ] && API_URL="http://127.0.0.1:${KONG_PORT}"

if [ -z "$ANON_KEY" ]; then
  echo "❌ ANON_KEY bulunamadı. .env içinde ANON_KEY var mı?"
  exit 1
fi

JSON_AL() {
  # $1 = dosya, $2 = alan adı
  python3 - "$1" "$2" <<'PY'
import json, sys
try:
    with open(sys.argv[1], encoding="utf-8") as f:
        d = json.load(f)
except Exception:
    print("")
    raise SystemExit(0)
print(d.get(sys.argv[2], "") or "")
PY
}

echo "════════════════════════════════════════════════════════════════"
echo "F1 RETEST · şifre değişiminde yeniden doğrulama"
echo "  API      : $API_URL"
echo "  Hesap    : $EMAIL"
echo "  ANON_KEY : ${ANON_KEY:0:12}… (uzunluk ${#ANON_KEY})"
if [ -n "$SERVICE_KEY" ]; then
  echo "  SRV_KEY  : ${SERVICE_KEY:0:12}… (uzunluk ${#SERVICE_KEY})"
else
  echo "  SRV_KEY  : <yok> (--hesap-olustur / --sifre-sifirla çalışmaz)"
fi
echo "════════════════════════════════════════════════════════════════"

# ── Adım 0: container içi env teyidi ───────────────────────────────────────
echo
echo "▶ Adım 0 — auth container'ında ayar gerçekten yüklü mü?"
CONTAINER_ENV="$(docker compose exec -T auth printenv 2>/dev/null || true)"
REAUTH="$(printf '%s\n' "$CONTAINER_ENV" | grep '^GOTRUE_SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION=' | cut -d= -f2- | tr -d '\r')"
MINLEN="$(printf '%s\n' "$CONTAINER_ENV" | grep '^GOTRUE_PASSWORD_MIN_LENGTH=' | cut -d= -f2- | tr -d '\r')"
HIBP="$(printf '%s\n' "$CONTAINER_ENV" | grep '^GOTRUE_PASSWORD_HIBP_ENABLED=' | cut -d= -f2- | tr -d '\r')"
echo "  REAUTHENTICATION = ${REAUTH:-<YOK>}"
echo "  PASSWORD_MIN_LEN = ${MINLEN:-<YOK>}"
echo "  HIBP_ENABLED     = ${HIBP:-<YOK>}"
if [ "$REAUTH" != "true" ]; then
  echo "❌ Ayar container'a ulaşmamış. Önce 07_auth_hardening_uygula.sh çalıştır."
  exit 1
fi

# ── GoTrue sürümü (F7 için lazım) ──────────────────────────────────────────
echo
echo "▶ Adım 0b — GoTrue imaj sürümü"
IMGN="$(docker inspect supabase-auth --format '{{.Config.Image}}' 2>/dev/null || true)"
echo "  image: ${IMGN:-<okunamadı>}"
if [ -n "$IMGN" ]; then
  docker image inspect "$IMGN" \
    --format '  version label: {{index .Config.Labels "org.opencontainers.image.version"}}
  revision     : {{index .Config.Labels "org.opencontainers.image.revision"}}' 2>/dev/null \
    || echo "  (etiket yok)"
fi

# ── --geri-al ──────────────────────────────────────────────────────────────
if [ "$GERI_AL" -eq 1 ]; then
  echo
  echo "▶ --geri-al: test için geriye çekilen oturumlar düzeltiliyor"
  docker compose exec -T db psql -U postgres -d postgres -c \
    "update auth.sessions set created_at = now() where created_at < now() - interval '2 days';" \
    || { echo "❌ Geri alma başarısız."; exit 1; }
  echo "✅ Oturum zamanları normale döndü."
  exit 0
fi

# ── yardımcı: admin API ile hesabı hazırla / şifre sabitle ─────────────────
admin_iletisim() {
  # $1 = method, $2 = path, $3 = body
  curl -sS -o /tmp/f1_admin.json -w '%{http_code}' \
    -X "$1" "$API_URL$2" \
    -H "apikey: $SERVICE_KEY" \
    -H "Authorization: Bearer $SERVICE_KEY" \
    -H 'Content-Type: application/json' \
    ${3:+-d "$3"} 2>/dev/null
}

hesap_hazirla() {
  if [ -z "$SERVICE_KEY" ]; then
    echo "  ⚠️  SERVICE_ROLE_KEY yok — hesap hazırlama atlandı."
    return 0
  fi

  echo "  → kullanıcı aranıyor: $EMAIL"
  KOD="$(curl -sS -o /tmp/f1_users.json -w '%{http_code}' \
    "$API_URL/auth/v1/admin/users?page=1&per_page=200" \
    -H "apikey: $SERVICE_KEY" \
    -H "Authorization: Bearer $SERVICE_KEY" 2>/dev/null)"

  if [ "$KOD" != "200" ]; then
    echo "  ⚠️  admin list HTTP $KOD — gövde:"
    cat /tmp/f1_users.json 2>/dev/null; echo
    return 0
  fi

  UID_="$(python3 - "$EMAIL" <<'PY'
import json, sys
email = sys.argv[1].lower()
try:
    with open("/tmp/f1_users.json", encoding="utf-8") as f:
        d = json.load(f)
except Exception:
    print("")
    raise SystemExit(0)
users = d.get("users") if isinstance(d, dict) else d
for u in users or []:
    if (u.get("email") or "").lower() == email:
        print(u.get("id", ""))
        break
PY
)"

  BODY="$(python3 -c "import json,sys;print(json.dumps({'email':sys.argv[1],'password':sys.argv[2],'email_confirm':True}))" "$EMAIL" "$PASSWORD")"

  if [ -z "$UID_" ]; then
    echo "  → kullanıcı yok, oluşturuluyor"
    KOD="$(admin_iletisim POST /auth/v1/admin/users "$BODY")"
    echo "  HTTP $KOD"
    [ "$VERBOSE" -eq 1 ] && cat /tmp/f1_admin.json
    UID_="$(JSON_AL /tmp/f1_admin.json id)"
  else
    echo "  → kullanıcı var ($UID_), şifre bilinen değere sabitleniyor"
    KOD="$(admin_iletisim PUT "/auth/v1/admin/users/$UID_" \
      "$(python3 -c "import json,sys;print(json.dumps({'password':sys.argv[1],'email_confirm':True}))" "$PASSWORD")")"
    echo "  HTTP $KOD"
    [ "$VERBOSE" -eq 1 ] && cat /tmp/f1_admin.json
  fi

  if [ -n "$UID_" ] && [ -n "$SERVICE_KEY" ]; then
    # e-posta onaylı ve profil tarafı bozulmasın
    echo "  → hesap hazır: $UID_"
  else
    echo "  ⚠️  hesap hazırlanamadı, mevcut şifreyle login denenecek"
  fi
  echo
}

# ── --sifre-sifirla ────────────────────────────────────────────────────────
if [ "$SIFRE_SIFIRLA" -eq 1 ]; then
  echo
  echo "▶ --sifre-sifirla: $EMAIL şifresi bilinen değere döndürülüyor"
  hesap_hazirla
  echo "✅ Bitti. Şimdi normal testi çalıştırabilirsin."
  exit 0
fi

# ── --hesap-olustur ────────────────────────────────────────────────────────
if [ "$HESAP_OLUSTUR" -eq 1 ]; then
  echo
  echo "▶ Adım 1a — test hesabı hazırlanıyor (--hesap-olustur)"
  hesap_hazirla
fi

# ── Adım 1b: login ─────────────────────────────────────────────────────────
echo "▶ Adım 1b — taze login (token alınıyor)"
LOGIN_BODY="$(python3 -c "import json,sys;print(json.dumps({'email':sys.argv[1],'password':sys.argv[2]}))" "$EMAIL" "$PASSWORD")"
LOGIN_KOD="$(curl -sS -o /tmp/f1_login.json -w '%{http_code}' \
  -X POST "$API_URL/auth/v1/token?grant_type=password" \
  -H "apikey: $ANON_KEY" \
  -H 'Content-Type: application/json' \
  -d "$LOGIN_BODY" 2>/dev/null)"

echo "  HTTP: $LOGIN_KOD"
if [ "$LOGIN_KOD" != "200" ]; then
  echo "❌ Login başarısız. Sunucunun cevabı:"
  cat /tmp/f1_login.json 2>/dev/null; echo
  echo
  echo "   Sık nedenler:"
  echo "   • Hesap yok / şifre yanlış  → bash $0 --hesap-olustur"
  echo "   • E-posta onaylanmamış      → aynı komut email_confirm ile düzeltir"
  echo "   • ANON_KEY yanlış .env satırından geliyor → yukarıdaki uzunluğu kontrol et"
  exit 1
fi

TOKEN="$(JSON_AL /tmp/f1_login.json access_token)"
if [ -z "$TOKEN" ]; then
  echo "❌ access_token okunamadı. Gövde:"
  cat /tmp/f1_login.json; echo
  exit 1
fi
echo "  ✅ token alındı (uzunluk ${#TOKEN})"

# claim'leri çöz
python3 - "$TOKEN" <<'PY' > /tmp/f1_claims.txt
import base64, json, sys, time
t = sys.argv[1]
try:
    p = t.split(".")[1]
    p += "=" * (-len(p) % 4)
    d = json.loads(base64.urlsafe_b64decode(p))
except Exception:
    print("IAT="); print("EXP="); print("SID="); print("SUB="); raise SystemExit(0)
print("IAT=%s" % d.get("iat", ""))
print("EXP=%s" % d.get("exp", ""))
print("SID=%s" % d.get("session_id", ""))
print("SUB=%s" % d.get("sub", ""))
PY
IAT="$(grep '^IAT=' /tmp/f1_claims.txt | cut -d= -f2-)"
EXP="$(grep '^EXP=' /tmp/f1_claims.txt | cut -d= -f2-)"
SID="$(grep '^SID=' /tmp/f1_claims.txt | cut -d= -f2-)"
SUB="$(grep '^SUB=' /tmp/f1_claims.txt | cut -d= -f2-)"

SIMDI="$(date +%s)"
if [ -n "$IAT" ]; then
  echo "  iat: $IAT (yaş ≈ $(( (SIMDI - IAT) / 60 )) dk) · exp: ${EXP:-?} · session_id: ${SID:-<yok>}"
fi
[ -z "$SID" ] && echo "  ⚠️  token içinde session_id yok — --eskit çalışmayabilir."

# ── Adım 2 (opsiyonel): oturumu eskit ──────────────────────────────────────
if [ "$ESKIT" -eq 1 ]; then
  echo
  echo "▶ Adım 2 — TEST: bu oturumun created_at değeri 3 gün geriye çekiliyor"
  echo "  ⚠️  Sadece test ortamında. Geri al: bash $0 --geri-al"
  if [ -n "$SID" ]; then
    docker compose exec -T db psql -U postgres -d postgres -c \
      "update auth.sessions set created_at = now() - interval '3 days' where id = '$SID';" \
      || echo "  ⚠️  eskitme başarısız (devam ediliyor)"
  else
    docker compose exec -T db psql -U postgres -d postgres -c \
      "update auth.sessions set created_at = now() - interval '3 days' where user_id = '$SUB';" \
      || echo "  ⚠️  eskitme başarısız (devam ediliyor)"
  fi
  echo "  doğrulama:"
  docker compose exec -T db psql -U postgres -d postgres -t -c \
    "select id, created_at from auth.sessions where user_id = '$SUB' order by created_at desc limit 3;" \
    | sed 's/^/    /'
fi

# ── Adım 3: asıl test ──────────────────────────────────────────────────────
echo
echo "▶ Adım 3 — mevcut şifre / nonce GÖNDERİLMEDEN şifre değiştirme denemesi"
echo "  denenecek yeni şifre: $YENI_SIFRE  (HIBP'te olmayan rastgele değer)"
DEGISIM_BODY="$(python3 -c "import json,sys;print(json.dumps({'password':sys.argv[1]}))" "$YENI_SIFRE")"
KOD="$(curl -sS -o /tmp/f1.json -w '%{http_code}' \
  -X PUT "$API_URL/auth/v1/user" \
  -H "apikey: $ANON_KEY" \
  -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d "$DEGISIM_BODY" 2>/dev/null)"

echo "  HTTP: $KOD"
echo "  Gövde:"
cat /tmp/f1.json 2>/dev/null; echo

# ── Adım 4: yorum ──────────────────────────────────────────────────────────
echo
echo "════════════════════════════════════════════════════════════════"
if [ "$KOD" = "400" ] && grep -qi 'reauthentication_needed' /tmp/f1.json 2>/dev/null; then
  echo "✅ F1 KAPANDI — sunucu reauthentication_needed döndü."
  echo "   Eski oturumla şifre değiştirmek artık mümkün değil."
  exit 0
fi

if [ "$KOD" = "200" ]; then
  echo "ℹ️  200 döndü. GoTrue, 24 saatten YENİ oturumlarda nonce İSTEMEZ."
  echo "   Taze token ile 200 beklenen davranıştır, regresyon değildir."
  if [ "$ESKIT" -eq 1 ]; then
    echo
    echo "   ⚠️  Oturum eskitilmişti ama yine 200 geldi. İki ihtimal:"
    echo "      1) Bu GoTrue sürümü ayarı tanımıyor (F7 sürüm yükseltmesi)"
    echo "      2) Eşik başka bir alandan hesaplanıyor"
    echo "   Log:"
    docker compose logs auth --tail 40 | grep -iE 'reauth|password|unknown|warn|error' || true
    echo
    echo "   Şifre gerçekten değiştiyse geri al: bash $0 --sifre-sifirla"
    exit 1
  fi
  echo
  echo "   Eski oturum senaryosu için: bash $0 --eskit"
  echo "   (şifre değiştiyse: bash $0 --sifre-sifirla)"
  exit 0
fi

if [ "$KOD" = "422" ] && grep -qiE 'weak_password|pwned|hibp' /tmp/f1.json 2>/dev/null; then
  echo "ℹ️  422 weak_password — HIBP/min uzunluk kuralı devreye girdi."
  echo "   Yani istek reauth kontrolüne ulaşmadan şifre politikasına takıldı."
  echo "   Bu F1 kanıtı değildir; rastgele güçlü şifreyle tekrar dene (varsayılan öyle)."
  exit 1
fi

echo "⚠️  Beklenmeyen yanıt ($KOD). Loglar:"
docker compose logs auth --tail 40 | grep -iE 'reauth|password|unknown|warn|error' || true
exit 1