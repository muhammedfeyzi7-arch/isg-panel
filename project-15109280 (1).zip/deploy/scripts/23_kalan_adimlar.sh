#!/usr/bin/env bash
# 23_kalan_adimlar.sh
# 14 (FK/GUV-39 + GUV-32) uygulandiktan sonra kalan pentest kapanis adimlarini sirayla kosar.
# Kullanim (sunucuda):
#   bash deploy/scripts/23_kalan_adimlar.sh
#   ya da: REPO_ROOT=/root/isg-deploy bash /root/isg-deploy/deploy/scripts/23_kalan_adimlar.sh
#
# F3 marker kaniti da kosulsun istersen (opsiyonel):
#   F3_EMAIL=test@alanadi.com F3_PASS='MevcutSifre' bash deploy/scripts/23_kalan_adimlar.sh
#
# Adimlar: 13 (FK envanteri) -> 24 (GUV-43 dogrula+uygula) -> 15 (cron) -> [26 F3] ->
#          17 (DNS) -> 18 (egress kuru/uygula/dogrula) -> 19 (kanit paketi)
#
# Not: 14 BURADA YOKTUR. 14 bir kez uygulanip dogrulandi; tekrar kosulmaz.

set -uo pipefail

SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "${SELF_DIR}/../.." && pwd)}"
COMPOSE_DIR="${COMPOSE_DIR:-/opt/ibys/supabase/docker}"
PGUSER="${PGUSER:-supabase_admin}"
DB_NAME="${DB_NAME:-postgres}"
export REPO_ROOT

# F3 marker kaniti icin giris bilgisi verilirse kosulur (opsiyonel):
#   F3_EMAIL=... F3_PASS='...' bash deploy/scripts/23_kalan_adimlar.sh
F3_EMAIL="${F3_EMAIL:-}"
F3_PASS="${F3_PASS:-}"

cd "${REPO_ROOT}" || { echo "!! proje koku bulunamadi: ${REPO_ROOT}"; exit 4; }
echo "PROJE KOKU: ${REPO_ROOT}"

chmod +x deploy/scripts/*.sh 2>/dev/null || true

SUMMARY=""

run() {
  local label="$1"
  shift
  echo
  echo "============================================================"
  echo ">>> ${label}"
  echo "============================================================"
  "$@"
  local rc=$?
  SUMMARY="${SUMMARY}${label} rc=${rc}
"
  echo "--> rc=${rc}"
  return 0
}

run "13 FK envanteri (salt okuma)" bash -c "cd '${COMPOSE_DIR}' && docker compose exec -T db psql -U '${PGUSER}' -d '${DB_NAME}' < '${REPO_ROOT}/supabase/tests/security/pentest_gunu/13_fk_envanteri_readonly.sql' | tail -20"
run "24a GUV-43 dogrula (salt okuma)" bash deploy/scripts/24_guv43_service_role_truncate.sh --dogrula
run "24b GUV-43 uygula"              bash deploy/scripts/24_guv43_service_role_truncate.sh
run "15 sifre kodu temizlik / cron" bash deploy/scripts/15_sifre_kod_temizlik_cron.sh

if [ -n "${F3_EMAIL}" ] && [ -n "${F3_PASS}" ]; then
  run "26 F3 marker kaniti" bash deploy/scripts/26_f3_marker_kanit.sh "${F3_EMAIL}" "${F3_PASS}"
else
  echo
  echo ">>> 26 F3 marker kaniti ATLANDI (F3_EMAIL / F3_PASS verilmedi)."
  echo "    Ayrica kosmak icin:"
  echo "    F3_EMAIL=... F3_PASS='...' bash deploy/scripts/23_kalan_adimlar.sh"
  echo "    ya da tek basina: bash deploy/scripts/26_f3_marker_kanit.sh <eposta> '<sifre>'"
fi
run "17 mail DNS dogrulama"         bash deploy/scripts/17_mail_dns_dogrula.sh --dogrula
run "18 egress firewall (kuru)"     bash deploy/scripts/18_egress_firewall.sh
run "18 egress firewall (uygula)"   bash deploy/scripts/18_egress_firewall.sh --uygula
run "18 egress firewall (dogrula)"  bash deploy/scripts/18_egress_firewall.sh --dogrula
run "19 pentest kanit paketi"       bash deploy/scripts/19_pentest_kapanis_kanit.sh

echo
echo "================ OZET ================"
printf '%s' "${SUMMARY}"
KANIT="$(ls -dt /root/pentest-kanit-* 2>/dev/null | head -n 1)"
if [ -n "${KANIT}" ]; then
  echo "KANIT KLASORU: ${KANIT}"
  echo "OZET DOSYASI : ${KANIT}/00_OZET.md"
else
  echo "KANIT KLASORU: yok (19 kosmadi ya da basarisiz)"
fi
echo
echo "Hatirlatma: 17'nin 0 disi donmesi normal olabilir (SPF/DKIM/DMARC dis kayit bekliyor)."
echo "Kritik olan 18d (dogrula) ve 19 rc degerleridir."
echo
echo "------------------------------------------------------------"
echo "5. KALEM (elle) — sifre degistirme e-posta kodu akisi"
echo "------------------------------------------------------------"
echo "19 tek basina bunu KAPATAMAZ: test interaktif, e-postaya gelen kod elle girilir."
echo "Sunucuda sirasiyla:"
echo "  1) bash deploy/scripts/16_ui_sifre_kodu_akisi_test.sh"
echo "     (3 dogrulama maili gelir, kodlari sirayla gir)"
echo "  2) bash deploy/scripts/19_pentest_kapanis_kanit.sh"
echo "     (artik 00_OZET.md'de 5. kalem: PASS (PASS=n / FAIL=0) gorunur)"
echo "  3) 16 ciktisindaki YENI sifreyi guvenli bir yere kaydet, test hesabini"
echo "     eski haline dondurmek istersen tekrar 16 kosup sifreyi eski degerine al."
echo
echo "ZORUNLU SON ADIM - egress kaliciligi (yoksa reboot'ta kurallar ucar):"
echo "  DEBIAN_FRONTEND=noninteractive apt-get install -y iptables-persistent netfilter-persistent"
echo "  netfilter-persistent save && systemctl enable netfilter-persistent"
echo "  grep -c 'IBYS-EGRESS' /etc/iptables/rules.v4"