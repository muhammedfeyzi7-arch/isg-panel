#!/usr/bin/env bash
# =============================================================================
# 13b · sifre-dogrulama deploy GERİ DÖNÜŞ
# =============================================================================
# Nerede çalışır : self-hosted sunucu
# Ne yapar      : Edge Function'ı kaldırır + GUV-41 / GUV-40 rollback SQL'lerini uygular
#
# ⚠️  DİKKAT: GUV-40 rollback'i `password_history` tablosunu DROP eder
#     (saklanan şifre geçmişi kaybedilir — kullanıcılar eski şifrelerine dönebilir).
#     Bu yüzden varsayılan olarak SADECE FONKSİYON kaldırılır, SQL geri alınmaz.
#     SQL'i de geri almak için: ROLLBACK_SQL=1 bash 13b_...sh
#
# Kullanım:
#   bash 13b_sifre_dogrulama_rollback.sh            # sadece fonksiyon
#   ROLLBACK_SQL=1 bash 13b_sifre_dogrulama_rollback.sh
# =============================================================================
set -euo pipefail

SUPABASE_DIR="${SUPABASE_DIR:-/opt/ibys/supabase/docker}"
SLUG="sifre-dogrulama"
ROLLBACK_SQL="${ROLLBACK_SQL:-0}"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

[[ -f "$SUPABASE_DIR/docker-compose.yml" ]] || die "compose bulunamadı: $SUPABASE_DIR"
cd "$SUPABASE_DIR"
if docker compose version >/dev/null 2>&1; then DC=(docker compose); else DC=(docker-compose); fi

FN_ID="$("${DC[@]}" ps -q functions | head -n1 || true)"
[[ -n "$FN_ID" ]] || die "functions konteyneri çalışmıyor."
FN_DIR="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/home/deno/functions"}}{{.Source}}{{end}}{{end}}' "$FN_ID")"
[[ -n "$FN_DIR" ]] || die "functions mount bulunamadı."

info "Edge Function kaldırılıyor: $FN_DIR/$SLUG"
rm -rf "${FN_DIR:?}/$SLUG"
"${DC[@]}" restart functions >/dev/null
info "functions yeniden başlatıldı (istemci otomatik olarak eski akışa düşer)."

if [[ "$ROLLBACK_SQL" != "1" ]]; then
  warn "SQL geri alınmadı (bilinçli). Tablolar yerinde kalır, zararsızdır."
  warn "SQL'i de geri almak için: ROLLBACK_SQL=1 bash $0"
  exit 0
fi

warn "SQL rollback modu açık — password_history DROP edilecek. 5 saniye içinde Ctrl+C ile iptal et."
sleep 5

DB_ID="$("${DC[@]}" ps -q db | head -n1)"
BK="/root/isg-yedek/pre_rollback_$(date +%Y%m%d_%H%M%S).dump"
mkdir -p /root/isg-yedek
info "Önce güvenlik yedeği: $BK"
"${DC[@]}" exec -T db pg_dump -U postgres -d postgres -Fc > "$BK"

R1="$(dirname "$0")/../../supabase/migrations/rollback/20260101002900_guv41_sifre_kodlari_rollback.sql"
R2="$(dirname "$0")/../../supabase/migrations/rollback/20260101002800_guv40_sifre_gecmisi_rollback.sql"

for f in "$R1" "$R2"; do
  if [[ -s "$f" ]]; then
    b="$(basename "$f")"
    info "uygulanıyor: $b"
    docker cp "$f" "$DB_ID:/tmp/$b"
    "${DC[@]}" exec -T db psql -U postgres -d postgres -v ON_ERROR_STOP=1 -f "/tmp/$b"
  else
    warn "rollback dosyası yok, atlandı: $f"
  fi
done

info "Geri dönüş tamamlandı. Yedek: $BK"