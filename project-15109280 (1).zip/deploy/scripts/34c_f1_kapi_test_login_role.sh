#!/usr/bin/env bash
# =============================================================================
# 34c - GUV-44 F1 kapi DAVRANIS TESTI (login rol surumu)
# =============================================================================
# NEDEN BU BETIK VAR:
#   Onceki surumler `SET SESSION AUTHORIZATION guv44_probe` kullaniyordu.
#   Bu komut SADECE SUPERUSER'da calisir. Bu imajda `postgres` superuser
#   olmadigi icin test, kapinin kendisini degil kendi kurulumunu test ediyordu
#   ("permission denied to set session authorization").
#
#   Cozum: sonda rolunu LOGIN rolu olarak olustur ve ona DOGRUDAN baglan.
#   Boylece session_user zaten guv44_probe olur; burunme gerekmez.
#   Superuser'a yalnizca "create role + grant" icin ihtiyac var (supabase_admin).
#
# Kullanim (PowerShell, tek blok - onerilen):
#   $s = @'
#   ... bu dosyanin icerigi ...
#   '@
#   $s | ssh -p 23422 root@37.230.105.216 "tr -d '\r' > /tmp/guv44_test.sh && bash /tmp/guv44_test.sh; echo EXIT=$?"
#
# Garanti: betik her durumda sonunda "SONUC:" ve "EXIT=" satiri yazar.
# Temizlik: test kullanicisi silinir, sonda rolu dusurulur, mod eski haline doner.
# NOT: --enforce BURADA kalici olarak acilmaz. Sadece test suresince acilir.
# =============================================================================
set -uo pipefail

SCRIPT_VERSION="guv44-gate-2026-10-20-e"

DB="${DB:-supabase-db}"
ENVF="${ENVF:-/opt/ibys/supabase/docker/.env}"
API="${API:-http://127.0.0.1:8000}"
P="guv44_probe"
PW="Guv44Pr0be$(date +%s)Aa1"

say() { printf '%s\n' "$*"; }
die() { printf 'HATA: %s\n' "$*" >&2; exit 1; }
q()   { timeout 20 docker exec -i "$DB" psql -U postgres -d postgres -At -c "$1" 2>/dev/null | tr -d '[:space:]'; }
su()  { timeout 20 docker exec -i "$DB" psql -U supabase_admin -d postgres -At -v ON_ERROR_STOP=1 -c "$1" 2>&1; }

say "==> betik surumu: $SCRIPT_VERSION"

# -- 0) Kapi kurulu mu -------------------------------------------------------
MOD0="$(q "select mod from public.sifre_kapisi_ayar where id;")"
[ -n "$MOD0" ] || die "GUV-44 kurulu degil (public.sifre_kapisi_ayar yok)."
say "==> mod (once): $MOD0"

TRG="$(q "select count(*) from pg_trigger where tgrelid='auth.users'::regclass and tgname='trg_auth_users_sifre_kapisi' and not tgisinternal;")"
[ "${TRG:-0}" = "1" ] || die "trg_auth_users_sifre_kapisi yok. Migration uygulanmamis."
say "==> trigger (auth.users): 1"

# -- 1) Yonetici baglanti (sadece rol/izin icin) ----------------------------
ADM="$(timeout 20 docker exec -i "$DB" psql -U supabase_admin -d postgres -At -c "select current_user;" 2>/dev/null | tr -d '[:space:]')"
[ "$ADM" = "supabase_admin" ] || die "supabase_admin ile baglanilamadi (=$ADM)."
say "==> yonetici: supabase_admin (rol + izin kurulumu)"

# -- 2) SERVICE_ROLE_KEY ----------------------------------------------------
[ -r "$ENVF" ] || die "env dosyasi okunamadi: $ENVF"
SR="$(grep -hE '^SERVICE_ROLE_KEY=' "$ENVF" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d "\"'" | tr -d '\r')"
[ -n "$SR" ] || die "SERVICE_ROLE_KEY bulunamadi ($ENVF)"
say "==> env: $ENVF (SERVICE_ROLE_KEY okundu)"

# -- 3) Temizlik -----------------------------------------------------------
UID_=""
restore_mod() {
  # mod'u eski haline dondur ve GERCEKTEN dondugunu dogrula.
  # Onceki surumlerde bu adim sessizce patliyordu (psql argumanlari kelime
  # kelime bolunuyordu) ve mod 'enforce' da kalabiliyordu.
  local tries=0 cur=""
  while [ "$tries" -lt 3 ]; do
    timeout 20 docker exec -i "$DB" psql -U postgres -d postgres -At \
      -v ON_ERROR_STOP=1 \
      -c "update public.sifre_kapisi_ayar set mod='$MOD0', guncellenme=now() where id;" >/dev/null 2>&1 || true
    cur="$(timeout 20 docker exec -i "$DB" psql -U postgres -d postgres -At \
      -c "select mod from public.sifre_kapisi_ayar where id;" 2>/dev/null | tr -d '[:space:]')"
    [ "$cur" = "$MOD0" ] && return 0
    tries=$((tries + 1))
    sleep 1
  done
  printf '!! DIKKAT: mod geri alinamadi. Beklenen=%s Simdiki=%s\n' "$MOD0" "${cur:-?}" >&2
  printf '!! Elle duzelt: docker exec supabase-db psql -U postgres -d postgres -c "update public.sifre_kapisi_ayar set mod=chr(108)||chr(111)||chr(103) where id;"\n' >&2
  return 1
}
cleanup() {
  if [ -n "$UID_" ]; then
    curl -sS --max-time 20 -o /dev/null -X DELETE "$API/auth/v1/admin/users/$UID_" \
      -H "apikey: $SR" -H "Authorization: Bearer $SR" || true
  fi
  timeout 20 docker exec -i "$DB" psql -U supabase_admin -d postgres -At \
    -c "drop role if exists $P;" >/dev/null 2>&1 || true
  restore_mod
}
trap cleanup EXIT

# -- 4) Test kullanicisi ---------------------------------------------------
TS="$(date +%s)"
EMAIL="guv44.block.${TS}@pentest.local"
RESP="$(curl -sS --max-time 20 -X POST "$API/auth/v1/admin/users" \
  -H "apikey: $SR" -H "Authorization: Bearer $SR" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"Guv44.Temp.${TS}.Aa1\",\"email_confirm\":true}")"
UID_="$(printf '%s' "$RESP" | sed -n 's/.*"id":[[:space:]]*"\([0-9a-f-]\{36\}\)".*/\1/p' | head -1)"
[ -n "$UID_" ] || die "Test kullanicisi olusturulamadi. Yanit: $RESP"
say "==> test kullanici: $UID_"

# -- 5) Sonda: LOGIN rolu + minimum yetki ----------------------------------
su "drop role if exists $P;" >/dev/null || true
su "create role $P login password '$PW' bypassrls;" >/dev/null || die "sonda rolu olusturulamadi"
su "grant usage on schema auth to $P;" >/dev/null || die "auth sema yetkisi verilemedi"
su "grant select, update on auth.users to $P;" >/dev/null || die "auth.users yetkisi verilemedi"
say "==> sonda rolu hazir: $P (login + bypassrls)"

# -- 6) Dogrudan sonda baglantisi (burunme YOK) ----------------------------
probe() {
  timeout 25 docker exec -i -e PGPASSWORD="$PW" "$DB" \
    psql -w -U "$P" -h 127.0.0.1 -d postgres -At 2>&1
}

PRECHK="$(printf 'select %s;\n' "'SESSION_USER=' || session_user" | probe)"
if ! printf '%s' "$PRECHK" | grep -q 'SESSION_USER=guv44_probe'; then
  printf '%s\n' "$PRECHK" | sed 's/^/    /'
  die "Sonda rolu ile baglanilamadi. pg_hba parola kabul etmiyor olabilir."
fi
say "==> sonda dogrulama: session_user = $P (tamam)"

# -- 7) Hash'ler -----------------------------------------------------------
H1="$(q "select extensions.crypt('Guv44.A.a1.$TS', extensions.gen_salt('bf',10));")"
H2="$(q "select extensions.crypt('Guv44.B.b2.$TS', extensions.gen_salt('bf',10));")"
H3="$(q "select extensions.crypt('Guv44.C.c3.$TS', extensions.gen_salt('bf',10));")"
{ [ -n "$H1" ] && [ -n "$H2" ] && [ -n "$H3" ]; } || die "Hash uretilemedi (pgcrypto?)"

# -- 8) enforce + 4 adim ---------------------------------------------------
q "update public.sifre_kapisi_ayar set mod='enforce', guncellenme=now() where id;" >/dev/null
say "==> mod: enforce (test suresince)"

run_probe() {
  probe <<SQL
begin;
update auth.users set encrypted_password = '$1' where id = '$UID_';
commit;
SQL
}

A=0; B=0; C=0; D=0

OUT1="$(run_probe "$H1")"
if printf '%s' "$OUT1" | grep -q 'PASSWORD_REAUTH_REQUIRED'; then
  say "  [1] izinsiz yazim      REDDEDILDI (PASSWORD_REAUTH_REQUIRED)"; A=1
else
  say "  [1] izinsiz yazim      BEKLENMEYEN"
  printf '%s\n' "$OUT1" | sed 's/^/        /'
fi

q "select 1 from public.sifre_degisim_izni_olustur('$UID_','admin',120);" >/dev/null \
  || die "test izni olusturulamadi"

OUT2="$(run_probe "$H2")"
if printf '%s' "$OUT2" | grep -q 'UPDATE 1'; then
  say "  [2] izinli yazim        GECTI (UPDATE 1)"; B=1
else
  say "  [2] izinli yazim        BEKLENMEYEN"
  printf '%s\n' "$OUT2" | sed 's/^/        /'
fi

CONSUMED="$(q "select count(*) from public.sifre_degisim_izinleri where user_id='$UID_' and consumed_at is not null;")"
if [ "${CONSUMED:-0}" -ge 1 ]; then
  say "  [3] izin tuketildi      EVET (consumed_at dolu)"; C=1
else
  say "  [3] izin tuketildi      HAYIR"
fi

OUT4="$(run_probe "$H3")"
if printf '%s' "$OUT4" | grep -q 'PASSWORD_REAUTH_REQUIRED'; then
  say "  [4] ikinci yazim        REDDEDILDI (tek kullanimlik)"; D=1
else
  say "  [4] ikinci yazim        BEKLENMEYEN"
  printf '%s\n' "$OUT4" | sed 's/^/        /'
fi

IHLAL="$(q "select count(*) from public.sifre_kapisi_ihlalleri where user_id='$UID_';")"
say "  [5] ihlal kaydi         ${IHLAL:-0} satir"

say ""
say "RESULT A=$A B=$B C=$C D=$D"
MOD_SON="$(timeout 20 docker exec -i "$DB" psql -U postgres -d postgres -At -c "select mod from public.sifre_kapisi_ayar where id;" 2>/dev/null | tr -d '[:space:]')"
say "  [6] mod geri dondu     ${MOD_SON:-?} (beklenen: $MOD0)"
if [ "$A$B$C$D" = "1111" ]; then
  say "SONUC: PASS - izinsiz yazim reddediliyor, izinli yazim geciyor, izin tek kullanimlik."
  say "RAPOR SATIRI: GUV-44 davranis testi: izinsiz UPDATE -> PASSWORD_REAUTH_REQUIRED,"
  say "              izinli UPDATE -> 1 satir, izin tuketildi, ikinci kullanim -> reddedildi."
  exit 0
fi
say "SONUC: FAIL - rapora 'kapandi' yazmayin."
exit 1