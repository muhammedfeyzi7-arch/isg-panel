#!/usr/bin/env bash
# =============================================================================
# 18 · EGRESS FIREWALL — container'lardan özel IP + bulut metadata blokajı
# =============================================================================
# Neden: mail Edge Function'ı (ve diğer SSRF yüzeyleri) kullanıcı girdisinden
#        hedef adres alabiliyor. Uygulama katmanındaki allowlist (SMTP_ALLOWED_HOSTS)
#        tek başına yeterli değil; ağ katmanında da kapatılmalı.
#
#       Engellenen hedefler:
#         · 169.254.169.254 / 169.254.0.0/16  → bulut metadata (kimlik bilgisi hırsızlığı)
#         · 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16 → iç ağ / diğer müşteri ağları
#         · 127.0.0.0/8 → container kendi loopback'i (host servislerine sıçrama)
#
#       ⚠️ KRİTİK: Docker kendi konteynerleri arasında da 172.x/10.x kullanır.
#          Bu yüzden önce "docker ağlarının kendi subnet'leri" ACCEPT edilir,
#          SONRA özel aralıklar REJECT edilir. Sıra ters olursa uygulama içi
#          trafik (PostgREST ↔ DB ↔ GoTrue) tamamen kopar.
#
# Kullanım:
#   bash 18_egress_firewall.sh              # KURU ÇALIŞMA (varsayılan)
#   bash 18_egress_firewall.sh --uygula     # gerçekten uygula
#   bash 18_egress_firewall.sh --dogrula    # container içinden test
#   bash 18_egress_firewall.sh --kaldir     # geri al
#
# Geri dönüş: --kaldir (zincir silinir, hiçbir kalıcı iz kalmaz)
# =============================================================================
set -uo pipefail

CHAIN="IBYS-EGRESS"
DOCKER_USER="DOCKER-USER"
MODE="${1:---kuru}"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

[[ "${EUID:-$(id -u)}" = "0" ]] || die "root gerekli (sudo bash $0 $MODE)"
command -v iptables >/dev/null 2>&1 || die "iptables bulunamadı"
command -v docker   >/dev/null 2>&1 || die "docker bulunamadı"

# ── Docker ağ subnet'lerini topla ───────────────────────────────────────────
topla_subnet() {
  local n s
  for n in $(docker network ls -q 2>/dev/null); do
    docker network inspect "$n" --format '{{range .IPAM.Config}}{{.Subnet}}{{"\n"}}{{end}}' 2>/dev/null
  done | grep -E '^[0-9]' | sort -u
}

SUBNETS="$(topla_subnet)"
[[ -n "$SUBNETS" ]] || warn "Hiç docker subnet'i bulunamadı (docker çalışmıyor olabilir)."

# ── Kural üretimi ───────────────────────────────────────────────────────────
uret() {
  echo "# 1) Docker iç ağları — İSTİSNA (önce bunlar)"
  while read -r s; do
    [[ -z "$s" ]] && continue
    echo "iptables -A $CHAIN -d $s -j ACCEPT"
  done <<< "$SUBNETS"

  echo "# 2) Bulut metadata servisi"
  echo "iptables -A $CHAIN -d 169.254.0.0/16 -j REJECT --reject-with icmp-port-unreachable"
  echo "# 3) Host loopback (host servislerine sıçrama)"
  echo "iptables -A $CHAIN -d 127.0.0.0/8 -j REJECT --reject-with icmp-port-unreachable"
  echo "# 4) RFC1918 özel aralıklar"
  echo "iptables -A $CHAIN -d 10.0.0.0/8 -j REJECT --reject-with icmp-port-unreachable"
  echo "iptables -A $CHAIN -d 172.16.0.0/12 -j REJECT --reject-with icmp-port-unreachable"
  echo "iptables -A $CHAIN -d 192.168.0.0/16 -j REJECT --reject-with icmp-port-unreachable"
  echo "# 5) IPv6 link-local (varsa)"
  echo "# ip6tables -A $CHAIN -d fe80::/10 -j REJECT"
}

kaldir() {
  info "Geri alınıyor"
  while iptables -C "$DOCKER_USER" -j "$CHAIN" 2>/dev/null; do
    iptables -D "$DOCKER_USER" -j "$CHAIN"
  done
  if iptables -L "$CHAIN" >/dev/null 2>&1; then
    iptables -F "$CHAIN"
    iptables -X "$CHAIN"
  fi
  info "Zincir kaldırıldı. Egress kısıtı YOK (eski durum)."
}

uygula() {
  info "Uygulanıyor (zincir: $CHAIN → $DOCKER_USER)"
  kaldir >/dev/null 2>&1 || true

  iptables -N "$CHAIN" || die "Zincir oluşturulamadı"
  while IFS= read -r k; do
    [[ -z "$k" ]] && continue
    [[ "$k" = \#* ]] && { echo "  $k"; continue; }
    # shellcheck disable=SC2086
    $k || die "Kural eklenemedi: $k"
    echo "  ${c_dim}$k${c_rst}"
  done < <(uret)

  iptables -I "$DOCKER_USER" 1 -j "$CHAIN" || die "DOCKER-USER'a atlama eklenemedi"
  info "Hazır. Egress kısıtı AKTİF."
  warn "iptables kuralları REBOOT'ta SİLİNİR. Kalıcılık için:"
  warn "  apt-get install -y iptables-persistent && netfilter-persistent save"
  warn "  veya bu betiği systemd unit / cron @reboot ile çağırın."
}

dogrula() {
  local kn="db"
  docker ps --format '{{.Names}}' | grep -q 'supabase-db' && kn="supabase-db"
  docker ps --format '{{.Names}}' | grep -qiE 'functions' && kn="$(docker ps --format '{{.Names}}' | grep -i functions | head -1)"

  info "Container içinden egress testi (konteyner: $kn)"
  tcp_test() { # tcp_test <host> <port> <beklenen: acik|kapali>
    local host="$1" port="$2" bek="$3" rc=0
    docker exec "$kn" bash -lc "timeout 4 bash -c 'cat < /dev/null > /dev/tcp/$host/$port'" >/dev/null 2>&1 || rc=1
    if [[ "$rc" = "0" ]]; then
      [[ "$bek" = "acik" ]] && okk "$host:$port ERİŞİLEBİLİR (beklenen)" || hata "$host:$port ERİŞİLEBİLİR — BLOK ÇALIŞMIYOR"
    else
      [[ "$bek" = "kapali" ]] && okk "$host:$port BLOKLU (beklenen)" || hata "$host:$port erişilemiyor — meşru çıkış da kırılmış olabilir"
    fi
  }
  okk()  { printf '%s %s\n' "${c_grn}PASS${c_rst}" "$*"; }
  hata() { printf '%s %s\n' "${c_red}FAIL${c_rst}" "$*"; }

  tcp_test "169.254.169.254" 80 "kapali"
  tcp_test "10.0.0.1"        443 "kapali"
  tcp_test "192.168.1.1"     443 "kapali"
  tcp_test "api.resend.com"  443 "acik"

  echo
  info "Uygulama içi trafik (bunlar ÇALIŞMAYA DEVAM ETMELİ)"
  docker compose -f /opt/ibys/supabase/docker/docker-compose.yml ps --format '{{.Name}} {{.Status}}' 2>/dev/null | head -20 || true

  echo
  info "Zincir sayaçları (paket düşüyor mu?)"
  iptables -L "$CHAIN" -n -v --line-numbers 2>/dev/null || warn "Zincir yok — önce --uygula"
}

case "$MODE" in
  --kuru|kuru|"")
    echo "════════════════════════════════════════════════════════════════"
    echo "  KURU ÇALIŞMA — hiçbir kural uygulanmadı"
    echo "  Tespit edilen docker subnet'leri:"
    printf '    %s\n' ${SUBNETS:-"(yok)"}
    echo "════════════════════════════════════════════════════════════════"
    echo
    uret
    echo
    warn "Uygulamak için: sudo bash $0 --uygula"
    ;;
  --uygula|uygula)
    uygula
    echo
    dogrula
    ;;
  --dogrula|dogrula)
    dogrula
    ;;
  --kaldir|kaldir)
    kaldir
    ;;
  *)
    die "Bilinmeyen parametre: $MODE (--kuru | --uygula | --dogrula | --kaldir)"
    ;;
esac