#!/usr/bin/env bash
# 10_f2_f5_dogrula.sh
# F2 (ayrıcalıklı user_metadata) + F5 (avatar_url allowlist) guard doğrulaması.
#
# Kullanım (sunucuda):
#   cd /opt/ibys/supabase/docker && bash /yol/10_f2_f5_dogrula.sh
#
# Farklı bir compose dizini için:
#   COMPOSE_DIR=/opt/ibys/supabase/docker bash 10_f2_f5_dogrula.sh
#
# Not: Auth hardening ayrı compose dosyasıyla uygulandıysa COMPOSE_EXTRA_FILE ile ver:
#   COMPOSE_EXTRA_FILE=docker-compose.auth-hardening.yml bash 10_f2_f5_dogrula.sh

set -uo pipefail

COMPOSE_DIR="${COMPOSE_DIR:-/opt/ibys/supabase/docker}"
COMPOSE_EXTRA_FILE="${COMPOSE_EXTRA_FILE:-}"

cd "$COMPOSE_DIR" || {
  echo "HATA: compose dizini bulunamadi -> $COMPOSE_DIR"
  exit 1
}

COMPOSE=(docker compose)
if [ -n "$COMPOSE_EXTRA_FILE" ]; then
  COMPOSE+=( -f docker-compose.yml -f "$COMPOSE_EXTRA_FILE" )
fi

PSQL=("${COMPOSE[@]}" exec -T db psql -U postgres -d postgres -At -v ON_ERROR_STOP=0)

echo "== 0) Baglam =="
echo "dizin      : $(pwd)"
echo "compose    : ${COMPOSE[*]}"
echo

echo "== 1) F2/F5 trigger envanteri (2 satir bekleniyor) =="
"${PSQL[@]}" -c "select tgname from pg_trigger where not tgisinternal and tgrelid in ('auth.users'::regclass,'public.profiles'::regclass) and tgname in ('guard_user_metadata_privileged_trg','guard_profile_avatar_url_trg') order by 1;"
echo

echo "== 2) F5 avatar allowlist (harici=f | ic=t bekleniyor) =="
"${PSQL[@]}" -c "select 'harici=' || public.is_allowed_avatar_url('https://webhook.site/x'), 'ic=' || public.is_allowed_avatar_url('https://api.isgdenetim.com.tr/storage/v1/object/public/a.png');"
echo

echo "== 3) F2/F5 fonksiyonlari mevcut mu (2 satir bekleniyor) =="
"${PSQL[@]}" -c "select proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace where n.nspname = 'public' and proname in ('is_allowed_avatar_url','guard_user_metadata_privileged_keys','guard_profile_avatar_url') order by 1;"
echo

echo "== 3b) Kirlenmis metadata kalmis mi (0 bekleniyor) =="
"${PSQL[@]}" -c "select count(*) as kirlenmis_users from auth.users where jsonb_typeof(raw_user_meta_data) = 'object' and raw_user_meta_data ?| array['role','roles','is_admin','admin','is_superuser','osgb_id','firma_id','tenant_id','permissions','app_metadata'];"
echo

echo "== 4) Auth surumu (retest kaydi icin) =="
"${COMPOSE[@]}" exec -T auth sh -c 'echo GOTRUE_VERSION=${GOTRUE_VERSION:-bilinmiyor}; /usr/local/bin/auth --version 2>/dev/null || true' 2>/dev/null || echo "(auth konteynerine erisilemedi)"
echo

echo "Bitti. Beklenen:"
echo "  adim 1  -> 2 satir (iki trigger)"
echo "  adim 2  -> harici=f | ic=t"
echo "  adim 3  -> en az 2 fonksiyon"
echo "  adim 3b -> kirlenmis_users=0"