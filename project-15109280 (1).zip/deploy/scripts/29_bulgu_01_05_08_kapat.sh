#!/usr/bin/env bash
# ═════════════════════════════════════════════════════════════════════════════
# 29 · PENTEST 2. RAPOR · BULGU-01 / BULGU-03 (platform) / BULGU-05 / BULGU-08
#
# Amaç: kod dışında kalan (Caddy / proxy / PostgREST) kalemleri KUR ve ÖLÇ.
#
# Kullanım:
#   bash deploy/scripts/29_bulgu_01_05_08_kapat.sh                 # sadece ölç
#   sudo bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --uygula   # Caddyfile kur + reload
#   bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --mask-baslat   # BULGU-05 maskeleyici
#   sudo bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --mask-uygula
#        → TEK KOMUT: maskeleyiciyi başlat + Caddy'yi kur + ölç
#          (maskeleme çalışmazsa Caddyfile otomatik geri alınır)
#
# Notlar:
#   * --uygula / --mask-uygula, /etc/caddy/Caddyfile dosyasını YEDEKLEYEREK değiştirir.
#   * Anahtar değerleri ekrana BASILMAZ.
#   * Hiçbir DB yazımı yapılmaz (yalnızca okuma + HTTP ölçümü).
# ═════════════════════════════════════════════════════════════════════════════
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/../.." && pwd)}"
ENVF="${SUPABASE_ENVF:-/opt/ibys/supabase/docker/.env}"
APP_BASE="${APP_BASE:-https://app.isgdenetim.com.tr}"
API_BASE="${API_BASE:-https://api.isgdenetim.com.tr}"
OUT_DIR="${OUT_DIR:-/root/pentest-kanit}"
CADDYFILE_SRC="$REPO_ROOT/deploy/caddy/Caddyfile"
CADDYFILE_DST="${CADDYFILE_DST:-/etc/caddy/Caddyfile}"
MASK_URL="${MASK_URL:-http://127.0.0.1:8001}"

STAMP="$(date +%Y%m%d-%H%M)"
OUT_LOG="$OUT_DIR/bulgu_01_05_08_$STAMP.log"
CADDY_BAK=""

c_grn=$'\e[32m'; c_red=$'\e[31m'; c_yel=$'\e[33m'; c_rst=$'\e[0m'
pass=0; fail=0; skip=0
ok()   { printf '%s %s\n' "${c_grn}PASS${c_rst}" "$*"; pass=$((pass + 1)); }
nok()  { printf '%s %s\n' "${c_red}FAIL${c_rst}" "$*"; fail=$((fail + 1)); }
atla() { printf '%s %s\n' "${c_yel}SKIP${c_rst}" "$*"; skip=$((skip + 1)); }
info() { printf '\n%s\n' "${c_yel}==>${c_rst} $*"; }

SURUM="v3 · 2026-10-20 · api-only Caddyfile + mask-uygula + CORS kirpma"
MOD="${1:---dogrula}"
[[ "$MOD" =~ ^-- ]] || MOD="--dogrula"
case "$MOD" in
  --dogrula|--uygula|--mask-baslat|--mask-uygula) ;;
  *)
    printf 'HATA: bilinmeyen mod: %s\n' "$MOD" >&2
    printf 'Geçerli modlar: --dogrula | --uygula | --mask-baslat | --mask-uygula\n' >&2
    printf 'Sunucudaki dosya ESKİ olabilir: %s\n' "${BASH_SOURCE[0]}" >&2
    exit 2
    ;;
esac

mkdir -p "$OUT_DIR"
exec > >(tee "$OUT_LOG") 2>&1

echo "════════════════════════════════════════════════════════════════════"
echo "  2. RAPOR KAPANIŞ · BULGU-01/03 (platform) · 05 · 08"
echo "  Tarih : $(date '+%Y-%m-%d %H:%M:%S')"
echo "  API   : $API_BASE"
echo "  APP   : $APP_BASE (ölçüm amaçlı · bu sunucudan servis edilmiyor)"
echo "  Mod   : $MOD"
echo "  Sürüm : $SURUM"
echo "════════════════════════════════════════════════════════════════════"

# ── Ortak yardımcılar ───────────────────────────────────────────────────────
env_get() {
  [[ -r "$ENVF" ]] || return 0
  grep -hE "^$1=" "$ENVF" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'" | tr -d '\r'
}
ANON="$(env_get ANON_KEY)"
[[ -z "$ANON" ]] && ANON="$(env_get SUPABASE_ANON_KEY)"
[[ -z "$ANON" ]] && ANON="$(env_get PUBLISHABLE_KEY)"

hsts_of() {
  curl -sS -o /dev/null -D - --max-time 20 "$1" 2>/dev/null \
    | tr -d '\r' | grep -i '^strict-transport-security:' | head -1
}

# ── Caddyfile kurulumu (yedekli + doğrulamalı) ──────────────────────────────
caddy_kur() {
  info "Caddyfile kurulumu (yedekli)"
  if [[ ! -f "$CADDYFILE_SRC" ]]; then
    printf '%s\n' "${c_red}HATA:${c_rst} kaynak yok: $CADDYFILE_SRC"
    return 1
  fi

  # Baz çizgisi: değişiklik öncesi izinli origin AC AO alıyor muydu?
  local baz_ok=0
  if curl -sS -o /dev/null -D - --max-time 15 -X OPTIONS "$API_BASE/functions/v1/auth-log" \
    -H 'Origin: https://app.isgdenetim.com.tr' -H 'Access-Control-Request-Method: POST' 2>/dev/null \
    | tr -d '\r' | grep -qi '^access-control-allow-origin:.*app\.isgdenetim\.com\.tr'; then
    baz_ok=1
  fi
  if [[ -f "$CADDYFILE_DST" ]]; then
    CADDY_BAK="$CADDYFILE_DST.bak-$STAMP"
    cp -a "$CADDYFILE_DST" "$CADDY_BAK" && echo "  yedek: $CADDY_BAK"
  fi
  if ! install -m 644 "$CADDYFILE_SRC" "$CADDYFILE_DST"; then
    echo "  yazılamadı, sudo gerekli"
    return 1
  fi
  echo "  yazıldı: $CADDYFILE_DST"

  if command -v caddy >/dev/null 2>&1; then
    if caddy validate --config "$CADDYFILE_DST" --adapter caddyfile >/tmp/caddy_validate.txt 2>&1; then
      ok "caddy validate (sözdizimi geçerli)"
      systemctl reload caddy 2>/dev/null || systemctl restart caddy
      sleep 2
      ok "caddy yeniden yüklendi"
    else
      nok "caddy validate BAŞARISIZ — ayrıntı: /tmp/caddy_validate.txt"
      [[ -n "$CADDY_BAK" ]] && cp -a "$CADDY_BAK" "$CADDYFILE_DST"
      echo "  eski dosya geri kondu (reload yapılmadı)"
      return 1
    fi
  else
    atla "caddy komutu bulunamadı — doğrulama atlandı"
  fi

  # Kurulan dosya gerçekten api bloğu içeriyor mu? (yanlış dosya kurulmasın)
  if ! grep -q 'api\.isgdenetim\.com\.tr' "$CADDYFILE_DST"; then
    nok "kurulan Caddyfile'da api.* bloğu YOK — geri alınıyor"
    [[ -n "$CADDY_BAK" ]] && cp -a "$CADDY_BAK" "$CADDYFILE_DST"
    systemctl reload caddy 2>/dev/null || systemctl restart caddy
    return 1
  fi
  ok "api.* bloğu yerinde"

  if grep -q '@corsYabanci' "$CADDYFILE_DST"; then
    ok "BULGU-06 · CORS kirpma kurali kuruldu"

    # Pozitif kontrol: kural izinli origin'i kirmadi mi?
    if [[ "$baz_ok" == "1" ]]; then
      if curl -sS -o /dev/null -D - --max-time 15 -X OPTIONS "$API_BASE/functions/v1/auth-log" \
        -H 'Origin: https://app.isgdenetim.com.tr' -H 'Access-Control-Request-Method: POST' 2>/dev/null \
        | tr -d '\r' | grep -qi '^access-control-allow-origin:.*app\.isgdenetim\.com\.tr'; then
        ok "izinli origin CORS'u korunuyor (uygulama etkilenmedi)"
      else
        nok "izinli origin CORS'u KIRILDI — Caddyfile geri aliniyor"
        [[ -n "$CADDY_BAK" ]] && cp -a "$CADDY_BAK" "$CADDYFILE_DST"
        systemctl reload caddy 2>/dev/null || systemctl restart caddy
        return 1
      fi
    else
      atla "baz olcumde izinli origin ACAO yoktu — pozitif kontrol atlandi"
    fi
  else
    atla "CORS kirpma kurali YOK (v2 Caddyfile) — BULGU-06 acik kalir"
  fi

  echo
  echo "  Not: app.isgdenetim.com.tr bu sunucudan servis edilmiyor (Readdy"
  echo "       statik hosting). Bu yüzden Caddyfile'da app bloğu YOK; bu doğru."
  echo
  return 0
}

# ── Maskeleyici servisini başlat ────────────────────────────────────────────
mask_baslat() {
  info "PostgREST maskeleme servisi başlatılıyor"
  if ! command -v docker >/dev/null 2>&1; then
    nok "docker yok — maskeleme servisi başlatılamadı"
    return 1
  fi

  # Derleme bağlamı: compose dosyasındaki sabit yol yerine repo köküne göre
  if [[ ! -f "$REPO_ROOT/deploy/postgrest-mask/Dockerfile" ]]; then
    nok "Dockerfile yok: $REPO_ROOT/deploy/postgrest-mask/Dockerfile"
    return 1
  fi
  if [[ ! -f "$REPO_ROOT/deploy/postgrest-mask/server.mjs" ]]; then
    nok "server.mjs yok: $REPO_ROOT/deploy/postgrest-mask/server.mjs"
    return 1
  fi
  if [[ ! -f "$REPO_ROOT/deploy/docker-compose.postgrest-mask.yml" ]]; then
    nok "compose dosyası yok: $REPO_ROOT/deploy/docker-compose.postgrest-mask.yml"
    nok "Önce kopyalayın: scp deploy\\docker-compose.postgrest-mask.yml ..."
    return 1
  fi
  export MASK_BUILD_CONTEXT="$REPO_ROOT/deploy/postgrest-mask"
  echo "  derleme bağlamı: $MASK_BUILD_CONTEXT"

  COMPOSE_ARGS=(-f /opt/ibys/supabase/docker/docker-compose.yml)
  for extra in docker-compose.override.yml docker-compose.auth-hardening.yml; do
    [[ -f "/opt/ibys/supabase/docker/$extra" ]] && COMPOSE_ARGS+=(-f "/opt/ibys/supabase/docker/$extra")
  done
  COMPOSE_ARGS+=(-f "$REPO_ROOT/deploy/docker-compose.postgrest-mask.yml")

  if ! (cd /opt/ibys/supabase/docker && docker compose "${COMPOSE_ARGS[@]}" up -d postgrest-mask); then
    nok "postgrest-mask başlatılamadı"
    return 1
  fi

  sleep 3
  local code saglik
  code="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$MASK_URL/__saglik" || echo 000)"
  saglik="$(curl -s --max-time 10 "$MASK_URL/__saglik" 2>/dev/null || true)"
  if [[ "$code" == "200" ]]; then
    ok "postgrest-mask 127.0.0.1:8001 ayakta → $saglik"
    return 0
  fi
  nok "postgrest-mask yanıt vermiyor (HTTP $code) — docker logs ibys-postgrest-mask"
  return 1
}

# ── Maskelemenin gerçekten devrede olduğunu ölç ─────────────────────────────
# DİKKAT: Caddy'de failover var (8001 ölü → 8000). Yani maskeleyici çökse bile
# /rest/v1 çalışmaya devam eder ve "PASS" sanılabilir. Bu yüzden önce kanıt
# başlığına (x-pgrest-mask) bakılır: o başlık yoksa yanıt maskeleyiciden GEÇMEMİŞ.
mask_olc() {
  local raw hdr hc
  hdr="$(curl -sS -D - -o /tmp/b29_mask.json --max-time 20 \
    "$API_BASE/rest/v1/profiles?select=kalem29_olmayan_kolon&limit=1" \
    -H "apikey: $ANON" 2>/dev/null | tr -d '\r' || true)"
  raw="$(cat /tmp/b29_mask.json 2>/dev/null || true)"
  echo "  yanıt: $(printf '%s' "$raw" | head -c 260)"

  hc="$(printf '%s' "$hdr" | grep -i '^x-pgrest-mask:' | head -1 || true)"
  if [[ -n "$hc" ]]; then
    echo "  kanıt başlığı: $hc"
  else
    echo "  ${c_yel}!! ${c_rst}x-pgrest-mask başlığı YOK — Caddy failover ile Kong'a düşmüş olabilir"
    echo "     (Bu durumda gövde maskelenmiş görünse bile trafik vekilden geçmiyor.)"
  fi

  if printf '%s' "$raw" | grep -qiE 'does not exist|schema cache|42703'; then
    return 1
  fi
  return 0
}

# BULGU-05 kanıt damgası — 40_kalan_dort_kalem.sh bu dosyayı okur.
bulgu05_marker_yaz() {
  local f="$OUT_DIR/BULGU05_PASS_$STAMP.txt"
  {
    echo "BULGU=BULGU-05"
    echo "DURUM=PASS"
    printf 'TEST=rest/v1 olmayan kolon -> genel hata govdesi (PGRST_GENERIC)\n'
    printf 'KANIT=maskeleme uctan uca dogrulandi\n'
    echo "TARIH=$(date '+%Y-%m-%d %H:%M:%S')"
  } > "$f"
  echo "  arşiv satırı: $f"
}

# ── MOD: --uygula ───────────────────────────────────────────────────────────
if [[ "$MOD" == "--uygula" ]]; then
  caddy_kur || exit 1
fi

# ── MOD: --mask-baslat ──────────────────────────────────────────────────────
if [[ "$MOD" == "--mask-baslat" ]]; then
  mask_baslat || true
  echo
  echo "  Sıradaki adım: sudo bash $0 --mask-uygula  (tek komutta kurulum + ölçüm)"
  echo
fi

# ── MOD: --mask-uygula · BULGU-05 tek komut ─────────────────────────────────
if [[ "$MOD" == "--mask-uygula" ]]; then
  if ! mask_baslat; then
    echo "  Maskeleyici ayakta değil → Caddy'ye DOKUNULMADI (mevcut yapı çalışmaya devam eder)."
    exit 1
  fi
  if ! caddy_kur; then
    echo "  Caddyfile kurulamadı → maskeleme devreye alınmadı."
    exit 1
  fi

  if [[ -z "$ANON" ]]; then
    atla "ANON_KEY yok — maskeleme ölçülemedi, Caddyfile kurulu kaldı"
  else
    sleep 1
    if mask_olc; then
      ok "BULGU-05 · şema ifşası MASKELENDİ (uçtan uca doğrulandı)"
      bulgu05_marker_yaz
    else
      nok "BULGU-05 · maskeleme devrede DEĞİL — Caddyfile geri alınıyor"
      if [[ -n "$CADDY_BAK" ]]; then
        cp -a "$CADDY_BAK" "$CADDYFILE_DST"
        systemctl reload caddy 2>/dev/null || systemctl restart caddy
        echo "  geri alındı: $CADDYFILE_DST <- $CADDY_BAK"
      fi
      exit 1
    fi
  fi
fi

# ── TEST 1-2 · BULGU-08 · HSTS ─────────────────────────────────────────────
info "TEST 1 · BULGU-08 · HSTS (api.isgdenetim.com.tr)"
HDR_API="$(hsts_of "$API_BASE/rest/v1/")"
if [[ -n "$HDR_API" ]]; then
  ok "api.* HSTS gönderiyor → $HDR_API"
  printf '%s' "$HDR_API" | grep -qi 'includeSubDomains' \
    && ok "includeSubDomains mevcut" \
    || nok "includeSubDomains eksik"
  printf '%s' "$HDR_API" | grep -qi 'preload' \
    && ok "preload mevcut" \
    || atla "preload yok (zorunlu değil, preload listesine girmek isterseniz ekleyin)"
else
  nok "api.* üzerinde HSTS YOK — Caddyfile uygulanmamış olabilir (--uygula)"
fi

info "TEST 2 · BULGU-08 · HSTS (app.isgdenetim.com.tr)"
HDR_APP="$(hsts_of "$APP_BASE/")"
if [[ -n "$HDR_APP" ]]; then
  ok "app.* HSTS gönderiyor → $HDR_APP"
else
  nok "app.* üzerinde HSTS YOK"
fi

info "TEST 2b · Sunucu sürümü sızıntısı"
SRV_HDR="$(curl -sS -o /dev/null -D - --max-time 20 "$API_BASE/" 2>/dev/null | tr -d '\r' | grep -i '^server:' | head -1)"
if [[ -z "$SRV_HDR" ]]; then
  ok "Server başlığı gizli"
else
  atla "Server başlığı var → $SRV_HDR (kritik değil)"
fi

# ── TEST 3-5 · BULGU-03 / BULGU-01 · gövde limiti ──────────────────────────
info "TEST 3 · BULGU-03 · 200 KB gövde reddi (auth-log)"
if [[ -z "$ANON" ]]; then
  atla "ANON_KEY okunamadı ($ENVF) — gövde testleri atlandı"
else
  { printf '{"event_type":"AUTH_LOGIN_FAILED","description":"'; \
    head -c 200000 /dev/zero | tr '\0' 'A'; printf '"}'; } > /tmp/b29_big.json
  echo "  üretilen gövde: $(du -h /tmp/b29_big.json | cut -f1)"

  for fn in auth-log send-reset-email accept-invite; do
    code="$(curl -sS -o /tmp/b29_body.txt -w '%{http_code}' --max-time 40 \
      -X POST "$API_BASE/functions/v1/$fn" \
      -H "apikey: $ANON" -H "Authorization: Bearer $ANON" \
      -H 'Content-Type: application/json' \
      --data-binary @/tmp/b29_big.json 2>/dev/null || echo 000)"
    if [[ "$code" == "413" ]]; then
      ok "$fn büyük gövdeyi 413 ile reddetti"
    elif [[ "$code" == "000" ]]; then
      nok "$fn yanıt vermedi (ağ/TLS?)"
    else
      nok "$fn beklenen 413, gelen $code — Caddy request_body kuralı devrede mi?"
      echo "     yanıt: $(head -c 200 /tmp/b29_body.txt)"
    fi
  done
fi

# ── TEST 6 · BULGU-05 · şema ifşası ────────────────────────────────────────
info "TEST 6 · BULGU-05 · PostgREST şema ifşası"
if [[ -z "$ANON" ]]; then
  atla "ANON_KEY yok — şema testi atlandı"
else
  RAW="$(curl -sS --max-time 20 \
    "$API_BASE/rest/v1/profiles?select=kalem29_olmayan_kolon&limit=1" \
    -H "apikey: $ANON" 2>/dev/null || true)"
  echo "  yanıt: $(printf '%s' "$RAW" | head -c 260)"

  if printf '%s' "$RAW" | grep -qiE 'does not exist|schema cache|42703'; then
    nok "şema ifşası AÇIK (ham PostgreSQL hata metni döndü)"
    echo "     Kapatmak için: sudo bash $0 --mask-uygula"
  elif printf '%s' "$RAW" | grep -qi 'PGRST_GENERIC'; then
    ok "şema ifşası MASKELENDİ (genel hata gövdesi döndü)"
  elif printf '%s' "$RAW" | grep -qiE '"code":"[0-9A-Z]{5}"'; then
    atla "farklı bir hata kodu döndü (42703 değil) — maskeleme kapsamı dışı, kabul edilebilir"
  else
    ok "ham şema bilgisi sızmadı"
  fi
fi

# ── TEST 7 · BULGU-06 / CORS regresyon ─────────────────────────────────────
# Negatif kontrol: yabancı origin yansıtılmamalı.
# Pozitif kontrol: izinli origin CORS'u ÇALIŞMAYA DEVAM etmeli (uygulama kırılmasın).
info "TEST 7 · BULGU-06 · CORS yansıması yok (negatif kontrol)"
cors_acao() {
  curl -sS -o /dev/null -D - --max-time 20 -X OPTIONS "$API_BASE/functions/v1/auth-log" \
    -H "Origin: $1" -H 'Access-Control-Request-Method: POST' 2>/dev/null \
    | tr -d '\r' | grep -i '^access-control-allow-origin:' | head -1 || true
}
CORS_ECHO="$(cors_acao https://kotu-site.example)"
if printf '%s' "$CORS_ECHO" | grep -qi 'kotu-site.example'; then
  nok "yabancı origin yansıtıldı → $CORS_ECHO"
  echo "     Kapatmak için: sudo bash $0 --uygula  (v3 Caddyfile · CORS kirpma)"
else
  ok "yabancı origin yansıtılmıyor"
fi

info "TEST 7b · BULGU-06 · izinli origin hâlâ çalışıyor mu (pozitif kontrol)"
CORS_OK="$(cors_acao https://app.isgdenetim.com.tr)"
if printf '%s' "$CORS_OK" | grep -qi 'app.isgdenetim.com.tr'; then
  ok "izinli origin CORS başlığı alıyor → $CORS_OK"
else
  nok "izinli origin CORS başlığı ALAMIYOR — uygulama CORS'a takılır!"
  echo "     Caddyfile'daki @corsYabanci allowlist'ini kontrol edin."
fi

# ── BULGU-01/02 hatırlatması ───────────────────────────────────────────────
info "NOT · BULGU-01 / BULGU-02 · auth-log doğası"
cat <<'EOF'
  auth-log bilinçli olarak verify_jwt=false kalır: başarısız giriş olayı
  oturum yokken oluşur. JWT zorunlu yapılırsa BAŞARISIZ GİRİŞ LOGU TAMAMEN ÖLÜR.

  Bu nedenle koruma uygulama katmanındadır (32 KB gövde, IP 20/5dk,
  e-posta 5/15dk, event whitelist, alanlar JWT+header'dan).
  Rapora "önerilen düzeltme birebir uygulanmadı, eşdeğer koruma uygulandı"
  yazılmalıdır; aksi halde denetçi verify_jwt=true göremeyince bulguyu geri açar.

  Anon hâlâ AUTH_LOGIN_FAILED yazabilir: bu KABUL EDİLEN ARTIK'tır
  (olayın doğası oturumsuz). Hız limiti + severity=warning + 500 karakter
  sınırı ile risk azaltılmıştır.
EOF
skip=$((skip + 1))

# ── ÖZET ───────────────────────────────────────────────────────────────────
echo
echo "────────────────────────────────────────────────────────────────────"
echo "  SONUÇ: PASS=${pass}  FAIL=${fail}  SKIP=${skip}"
echo "  Kanıt : $OUT_LOG"
echo "────────────────────────────────────────────────────────────────────"
if [[ "$fail" -eq 0 ]]; then
  echo "  ${c_grn}BULGU-01/03(platform)/05/06/08 tarafında ölçülebilir açık kalmadı.${c_rst}"
  echo "  Sıradaki: bash deploy/scripts/26_f3_marker_kanit.sh <eposta> <sifre>"
  exit 0
fi
echo "  ${c_red}Kalan FAIL satırları var — yukarıdaki yönlendirmeyi uygulayın.${c_rst}"
exit 1