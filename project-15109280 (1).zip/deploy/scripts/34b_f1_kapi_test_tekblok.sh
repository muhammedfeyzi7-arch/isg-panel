#!/usr/bin/env bash
# =============================================================================
# 34b - GUV-44 F1 kapi DAVRANIS TESTI (tek blok, dosya transferi gerektirmez)
# =============================================================================
# Amac: 34_f1_sifre_kapisi_deploy.sh --test ile ayni kaniti uretmek, ancak
#       yerel makinedeki eski kopya / scp sorunlarindan etkilenmemek.
#
# Kullanim (sunucuda):
#   bash /tmp/guv44_test.sh
#
# Kullanim (Windows PowerShell'den, tek blok - onerilen):
#   $s = @'
#   ... bu dosyanin icerigi ...
#   '@
#   $s | ssh -p 23422 root@37.230.105.216 "tr -d '\r' > /tmp/guv44_test.sh; bash /tmp/guv44_test.sh"
#
# Yaptigi is:
#   1) GUV-44 mod/tetikleyici varligini kontrol eder
#   2) Superuser rolunu bulur (postgres bu imajda superuser DEGIL)
#   3) Sonda rolu (guv44_probe, nologin + bypassrls) + minimum yetki
#   4) Burunme on kontrolu (session_user = guv44_probe)
#   5) Gecici test kullanicisi (admin API)
#   6) enforce modunda 4 adim: izinsiz -> red, izinli -> gec, izin tukendi, ikinci -> red
#   7) Herseyi geri alir (mod, kullanici, rol)
# Not: 34 ana betigindeki --enforce ASLA bu betik tarafindan acik birakilmaz.
# =============================================================================
set -uo pipefail

DB="${DB:-supabase-db}"
ENVF="${ENVF:-/opt/ibys/supabase/docker/.env}"
API="${API:-http://127.0.0.1:8000}"
PROBE="guv44_probe"

say() { printf '%s\n' "$*"; }
err() { printf 'HATA: %s\n' "$*" >&2; }

# -- 0) Kapi kurulu mu -------------------------------------------------------
MOD_BEFORE="$(docker exec -i "$DB" psql -U postgres -d postgres -At -c \
  "select mod from public.sifre_kapisi_ayar where id;" 2>/dev/null | tr -d '[:space:]')"
if [ -z "$MOD_BEFORE" ]; then
  err "GUV-44 kurulu degil (public.sifre_kapisi_ayar yok). Once 34_f1_sifre_kapisi_deploy.sh calistirin."
  exit 1
fi
say "==> mod (once): $MOD_BEFORE"

TRG="$(docker exec -i "$DB" psql -U postgres -d postgres -At -c \
  "select count(*) from pg_trigger where tgrelid='auth.users'::regclass and tgname='trg_auth_users_sifre_kapisi' and not tgisinternal;" 2>/dev/null | tr -d '[:space:]')"
say "==> trigger (auth.users): ${TRG:-?}"
if [ "${TRG:-0}" != "1" ]; then
  err "Tetikleyici yok. Migration uygulanmamis."
  exit 1
fi

# -- 1) Superuser tespiti ----------------------------------------------------
SU=""
for u in supabase_admin postgres; do
  r="$(docker exec -i "$DB" psql -U "$u" -d postgres -At -c \
    "select rolsuper from pg_roles where rolname=current_user;" 2>/dev/null | tr -d '[:space:]')"
  if [ "$r" = "t" ]; then SU="$u"; break; fi
done
if [ -z "$SU" ]; then
  err "Superuser rol bulunamadi (supabase_admin/postgres denendi)."
  exit 1
fi
say "==> superuser (yalnizca test kurulumu): $SU"

su_q()  { docker exec -i "$DB" psql -U "$SU" -d postgres -At -v ON_ERROR_STOP=1 -c "$1"; }
or_q()  { docker exec -i "$DB" psql -U postgres -d postgres -At -v ON_ERROR_STOP=1 -c "$1"; }
su_try(){ docker exec -i "$DB" psql -U "$SU" -d postgres -At 2>&1; }

# -- 2) SERVICE_ROLE_KEY ----------------------------------------------------
if [ ! -r "$ENVF" ]; then
  err "env dosyasi okunamadi: $ENVF"
  exit 1
fi
SR="$(grep -hE '^SERVICE_ROLE_KEY=' "$ENVF" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d "\"'" | tr -d '\r')"
if [ -z "$SR" ]; then
  err "SERVICE_ROLE_KEY bulunamadi ($ENVF)"
  exit 1
fi
say "==> env: $ENVF (SERVICE_ROLE_KEY okundu)"

# -- 3) Temizlik trap -------------------------------------------------------
UID_=""
cleanup() {
  if [ -n "$UID_" ]; then
    curl -sS -o /dev/null -X DELETE "$API/auth/v1/admin/users/$UID_" \
      -H "apikey: $SR" -H "Authorization: Bearer $SR" || true
  fi
  docker exec -i "$DB" psql -U "$SU" -d postgres -At -c "drop role if exists $PROBE;" >/dev/null 2>&1 || true
  docker exec -i "$DB" psql -U postgres -d postgres -At -c \
    "update public.sifre_kapisi_ayar set mod='$MOD_BEFORE', guncellenme=now() where id;" >/dev/null 2>&1 || true
}
trap cleanup EXIT

# -- 4) Gecici test kullanicisi --------------------------------------------
TS="$(date +%s)"
EMAIL="guv44.block.${TS}@pentest.local"
RESP="$(curl -sS -X POST "$API/auth/v1/admin/users" \
  -H "apikey: $SR" -H "Authorization: Bearer $SR" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$EMAIL\",\"password\":\"Guv44.Temp.${TS}.Aa1\",\"email_confirm\":true}")"
UID_="$(printf '%s' "$RESP" | sed -n 's/.*"id":[[:space:]]*"\([0-9a-f-]\{36\}\)".*/\1/p' | head -1)"
if [ -z "$UID_" ]; then
  err "Test kullanicisi olusturulamadi. Yanit: $RESP"
  exit 1
fi
say "==> test kullanici: $UID_"

# -- 5) Sonda rolu + minimum yetki ----------------------------------------
su_q "drop role if exists $PROBE;" >/dev/null || true
su_q "create role $PROBE nologin bypassrls;" >/dev/null || { err "sonda rolu olusturulamadi"; exit 1; }
su_q "grant usage on schema auth to $PROBE;" >/dev/null || { err "auth sema yetkisi verilemedi"; exit 1; }
su_q "grant select, update on auth.users to $PROBE;" >/dev/null || { err "auth.users yetkisi verilemedi"; exit 1; }

HAS_UPD="$(or_q "select has_table_privilege('$PROBE','auth.users','UPDATE');" | tr -d '[:space:]')"
HAS_SEL="$(or_q "select has_table_privilege('$PROBE','auth.users','SELECT');" | tr -d '[:space:]')"
if [ "$HAS_UPD" != "t" ] || [ "$HAS_SEL" != "t" ]; then
  err "sonda yetkileri eksik (select=$HAS_SEL update=$HAS_UPD)"
  exit 1
fi
say "==> sonda yetkileri: select/update auth.users = evet"

# -- 6) Burunme on kontrolu (yanlis FAIL uretmesin) ----------------------
PRE="$(su_try <<SQL
set session authorization $PROBE;
select 'SESSION_USER=' || session_user;
SQL
)"
if ! printf '%s' "$PRE" | grep -q 'SESSION_USER=guv44_probe'; then
  printf '%s\n' "$PRE" | sed 's/^/    /'
  err "Sonda rolune burunulemedi ($SU superuser degil olabilir). Test yapilmadi."
  exit 1
fi
say "==> burunme kontrolu: session_user = $PROBE (tamam)"

# -- 7) Hash'ler -----------------------------------------------------------
H1="$(or_q "select extensions.crypt('Guv44.A.a1.$TS', extensions.gen_salt('bf',10));" | tr -d '[:space:]')"
H2="$(or_q "select extensions.crypt('Guv44.B.b2.$TS', extensions.gen_salt('bf',10));" | tr -d '[:space:]')"
H3="$(or_q "select extensions.crypt('Guv44.C.c3.$TS', extensions.gen_salt('bf',10));" | tr -d '[:space:]')"
if [ -z "$H1" ] || [ -z "$H2" ] || [ -z "$H3" ]; then
  err "Hash uretilemedi (pgcrypto?)"
  exit 1
fi

# -- 8) enforce + 4 adim ---------------------------------------------------
or_q "update public.sifre_kapisi_ayar set mod='enforce', guncellenme=now() where id;" >/dev/null
say "==> mod: enforce (test suresince)"

run_probe() {
  docker exec -i "$DB" psql -U "$SU" -d postgres -At 2>&1 <<SQL
begin;
set session authorization $PROBE;
update auth.users set encrypted_password = '$1' where id = '$UID_';
commit;
SQL
}

A=0; B=0; C=0; D=0

OUT1="$(run_probe "$H1")"
if printf '%s' "$OUT1" | grep -q 'PASSWORD_REAUTH_REQUIRED'; then
  say "  [1] izinsiz yazim      REDDEDILDI (PASSWORD_REAUTH_REQUIRED)"; A=1
else
  say "  [1] izinsiz yazim      BEKLENMEYEN"
  printf '%s\n' "$OUT1" | sed 's/^/        /'
fi

or_q "select public.sifre_degisim_izni_olustur('$UID_','admin',120);" >/dev/null \
  || { err "test izni olusturulamadi"; exit 1; }

OUT2="$(run_probe "$H2")"
if printf '%s' "$OUT2" | grep -q 'UPDATE 1'; then
  say "  [2] izinli yazim        GECTI (UPDATE 1)"; B=1
else
  say "  [2] izinli yazim        BEKLENMEYEN"
  printf '%s\n' "$OUT2" | sed 's/^/        /'
fi

CONSUMED="$(or_q "select count(*) from public.sifre_degisim_izinleri where user_id='$UID_' and consumed_at is not null;" | tr -d '[:space:]')"
if [ "${CONSUMED:-0}" -ge 1 ]; then
  say "  [3] izin tuketildi      EVET (consumed_at dolu)"; C=1
else
  say "  [3] izin tuketildi      HAYIR"
fi

OUT4="$(run_probe "$H3")"
if printf '%s' "$OUT4" | grep -q 'PASSWORD_REAUTH_REQUIRED'; then
  say "  [4] ikinci yazim        REDDEDILDI (tek kullanimlik)"; D=1
else
  say "  [4] ikinci yazim        BEKLENMEYEN"
  printf '%s\n' "$OUT4" | sed 's/^/        /'
fi

IHLAL="$(or_q "select count(*) from public.sifre_kapisi_ihlalleri where user_id='$UID_';" | tr -d '[:space:]')"
say "  [5] ihlal kaydi         ${IHLAL:-0} satir"

say ""
say "RESULT A=$A B=$B C=$C D=$D"
if [ "$A$B$C$D" = "1111" ]; then
  say "SONUC: PASS - izinsiz yazim reddediliyor, izinli yazim geciyor, izin tek kullanimlik."
  say "RAPOR SATIRI: GUV-44 davranis testi: izinsiz UPDATE -> PASSWORD_REAUTH_REQUIRED,"
  say "              izinli UPDATE -> 1 satir, izin tuketildi, ikinci kullanim -> reddedildi."
  exit 0
fi
say "SONUC: FAIL - rapora 'kapandi' yazmayin."
exit 1