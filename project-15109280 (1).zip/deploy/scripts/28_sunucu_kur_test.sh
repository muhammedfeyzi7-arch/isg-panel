#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# 28_sunucu_kur_test.sh  ·  SUNUCU TARAFI
#
# Ne yapar (sırayla):
#   1) zip'i hedef dizine açar (temiz kurulum)
#   2) proje kökünü bulur, betikleri çalıştırılabilir yapar
#   3) EDGE FUNCTION'LARI YAYINLAR  ← BULGU-03/07 düzeltmesi burada devreye girer
#   4) GUV-43 (TRUNCATE) doğrula + uygula
#   5) 14  FK zinciri (GUV-39 → GUV-32)
#   6) 15  şifre kodu temizlik cron'u
#   7) 17  SPF/DKIM/DMARC doğrulama
#   8) 18  egress firewall (kuru → uygula → doğrula)
#   9) 27  BULGU-03 + BULGU-07 canlı doğrulama (40 MB gövde + token/IP limiti)
#  10) 19  kanıt paketi (/root/pentest-kanit-<tarih>/00_OZET.md)
#
# Kullanım (sunucuda, root olarak):
#   bash /root/isg_kur_test.sh /root/isg-paket.zip /root/isg-deploy
#
# Egress firewall'ı atlamak için:
#   EGRESS=0 bash /root/isg_kur_test.sh /root/isg-paket.zip /root/isg-deploy
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

ZIP="${1:-/root/isg-paket.zip}"
DEST="${2:-/root/isg-deploy}"
EGRESS="${EGRESS:-1}"
SUPABASE_DOCKER_DIR="${SUPABASE_DOCKER_DIR:-/opt/ibys/supabase/docker}"
ENV_FILE="${SUPABASE_DOCKER_DIR}/.env"
API_BASE="${API_BASE:-https://api.isgdenetim.com.tr}"

STAMP="$(date +%Y%m%d-%H%M%S)"
LOG="/root/isg-kur-test-${STAMP}.log"
exec > >(tee -a "$LOG") 2>&1

c_grn=$'\e[32m'; c_red=$'\e[31m'; c_yel=$'\e[33m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
err()  { printf '%s\n' "${c_red}XX ${c_rst}$*"; }

echo "════════════════════════════════════════════════════════════"
echo "  İBYS · zip kurulumu + pentest doğrulama"
echo "  zip    : $ZIP"
echo "  hedef  : $DEST"
echo "  egress : $EGRESS  (1=uygula, 0=atla)"
echo "  log    : $LOG"
echo "════════════════════════════════════════════════════════════"

# ── 1) zip kontrolü ────────────────────────────────────────────────────────
if [[ ! -f "$ZIP" ]]; then
  err "zip bulunamadı: $ZIP"
  exit 1
fi
info "zip boyutu: $(du -h "$ZIP" | cut -f1)"

# ── 2) aç ──────────────────────────────────────────────────────────────────
info "1/10 · Arşiv açılıyor → $DEST"
rm -rf "$DEST"
mkdir -p "$DEST"

if command -v unzip >/dev/null 2>&1; then
  unzip -oq "$ZIP" -d "$DEST" || { err "unzip başarısız (bozuk arşiv olabilir)"; exit 1; }
elif command -v python3 >/dev/null 2>&1; then
  python3 - "$ZIP" "$DEST" <<'PY' || { err "python ile açma başarısız"; exit 1; }
import sys, zipfile
zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])
PY
else
  warn "unzip yok, kuruluyor..."
  DEBIAN_FRONTEND=noninteractive apt-get update -qq >/dev/null 2>&1 || true
  DEBIAN_FRONTEND=noninteractive apt-get install -y unzip >/dev/null 2>&1 || true
  command -v unzip >/dev/null 2>&1 || { err "unzip kurulamadı"; exit 1; }
  unzip -oq "$ZIP" -d "$DEST" || { err "unzip başarısız"; exit 1; }
fi

# ── 3) proje kökü ──────────────────────────────────────────────────────────
MARKER="$(find "$DEST" -type f -name '14_fk_guv39_guv32_deploy.sh' -path '*/deploy/scripts/*' 2>/dev/null | head -1)"
if [[ -z "$MARKER" ]]; then
  err "zip içinde deploy/scripts/14_fk_guv39_guv32_deploy.sh yok."
  err "Bu zip sadece arayüz dosyalarını içeriyor olabilir."
  find "$DEST" -maxdepth 2 2>/dev/null | head -30
  exit 2
fi
ROOT="$(cd "$(dirname "$(dirname "$(dirname "$MARKER")")")" && pwd)"
info "2/10 · Proje kökü: $ROOT"
cd "$ROOT" || exit 1
chmod +x deploy/scripts/*.sh 2>/dev/null || true
export REPO_ROOT="$ROOT"

# ── 4) varlık kontrolü ─────────────────────────────────────────────────────
EKSIK=0
for f in \
  "supabase/functions/auth-log/index.ts" \
  "supabase/functions/accept-invite/index.ts" \
  "supabase/functions/send-reset-email/index.ts" \
  "supabase/migrations/20260101003100_guv43_service_role_truncate_revoke.sql" \
  "deploy/scripts/24_guv43_service_role_truncate.sh" \
  "deploy/scripts/27_bulgu_03_07_dogrula.sh"; do
  if [[ ! -f "$ROOT/$f" ]]; then err "eksik dosya: $f"; EKSIK=1; fi
done
if [[ "$EKSIK" -ne 0 ]]; then
  err "Bu zip eski/eksik. Readdy → Code sekmesinden yeni zip indir."
  exit 2
fi
info "zip içeriği doğrulandı (fonksiyonlar + GUV-43 + 24 + 27 var)."

# ── 5) yardımcı ────────────────────────────────────────────────────────────
SONUC=""
KOS() {
  local no="$1" ad="$2" cmd="$3"
  echo
  echo "────────────────────────────────────────────────────────────"
  echo "  $no · $ad"
  echo "────────────────────────────────────────────────────────────"
  ( cd "$ROOT" && bash -c "$cmd" )
  local rc=$?
  if [[ $rc -eq 0 ]]; then
    printf '%s\n' "   ↳ $no çıkış kodu: 0 (başarılı)"
  else
    warn "$no çıkış kodu: $rc — yukarıdaki çıktıya bak"
  fi
  SONUC="$SONUC $no=$rc"
  return 0
}

# ── 6) EDGE FUNCTION YAYINI (kritik) ───────────────────────────────────────
info "3/10 · Edge Function'lar yayınlanıyor (BULGU-03/07 düzeltmesi dahil)"
if [[ -d "$SUPABASE_DOCKER_DIR" ]]; then
  KOS "04" "Edge Function dağıtımı" "bash deploy/scripts/04-edge-deploy.sh"
  echo "   functions container'ının ayağa kalkması bekleniyor (25 sn)..."
  sleep 25
  ( cd "$SUPABASE_DOCKER_DIR" && docker compose ps functions ) || warn "functions durumu okunamadı"
  ( cd "$SUPABASE_DOCKER_DIR" && docker compose logs --tail=25 functions ) || true
else
  err "$SUPABASE_DOCKER_DIR yok — edge deploy atlandı. Testler eski kodu ölçer!"
fi

# ── 7) GUV-43 (TRUNCATE yetkisi) ──────────────────────────────────────────
warn "GUV-43 yalnızca yetki (ACL) değiştirir; veri okumaz/yazmaz."
KOS "24a" "GUV-43 · doğrula (önce, salt okuma)" "bash deploy/scripts/24_guv43_service_role_truncate.sh --dogrula"
KOS "24b" "GUV-43 · uygula" "bash deploy/scripts/24_guv43_service_role_truncate.sh --dogrula >/dev/null 2>&1; bash deploy/scripts/24_guv43_service_role_truncate.sh"

# ── 8) FK zinciri ─────────────────────────────────────────────────────────
warn "14 kısa bir tablo kilidi alır; düşük trafikli saatte idealdir."
KOS "14" "FK zinciri (GUV-39 → GUV-32)" "bash deploy/scripts/14_fk_guv39_guv32_deploy.sh"

# ── 9) cron + DNS ─────────────────────────────────────────────────────────
KOS "15" "Şifre kodu temizlik cron'u" "bash deploy/scripts/15_sifre_kod_temizlik_cron.sh"
KOS "15b" "Şifre kodu temizlik · şimdi bir kez koş" "bash deploy/scripts/15_sifre_kod_temizlik_cron.sh --simdi"
KOS "17" "SPF / DKIM / DMARC doğrulama" "bash deploy/scripts/17_mail_dns_dogrula.sh --dogrula"

# ── 10) egress firewall ───────────────────────────────────────────────────
if [[ "$EGRESS" = "1" ]]; then
  KOS "18a" "Egress firewall · kuru çalışma" "bash deploy/scripts/18_egress_firewall.sh"
  KOS "18b" "Egress firewall · uygula" "bash deploy/scripts/18_egress_firewall.sh --uygula"
  KOS "18c" "Egress firewall · doğrula" "bash deploy/scripts/18_egress_firewall.sh --dogrula"
else
  warn "18 atlandı (EGRESS=0)."
fi

# ── 11) ANON_KEY bul ──────────────────────────────────────────────────────
ANON=""
if [[ -f "$ENV_FILE" ]]; then
  ANON="$(grep -m1 '^ANON_KEY=' "$ENV_FILE" 2>/dev/null | cut -d= -f2- | tr -d '"' | tr -d "'" | xargs || true)"
fi
if [[ -z "$ANON" ]]; then
  warn "ANON_KEY bulunamadı ($ENV_FILE). 27 testi atlanacak."
  warn "Elle koşmak için: export ANON_KEY='...'; bash deploy/scripts/27_bulgu_03_07_dogrula.sh"
else
  info "4/10 · ANON_KEY bulundu (${#ANON} karakter) — 27 testi koşuluyor"
  export ANON_KEY="$ANON"
  export API_BASE
  KOS "27" "BULGU-03 + BULGU-07 canlı doğrulama" "bash deploy/scripts/27_bulgu_03_07_dogrula.sh"
fi

# ── 12) kanıt paketi ──────────────────────────────────────────────────────
KOS "19" "Kanıt paketi (/root/pentest-kanit-<tarih>)" "ATLA_PGTAP=0 bash deploy/scripts/19_pentest_kapanis_kanit.sh"

# ── 13) özet ──────────────────────────────────────────────────────────────
echo
echo "════════════════════════════════════════════════════════════"
echo "  ÇALIŞTIRMA ÖZETİ"
echo "════════════════════════════════════════════════════════════"
echo "  adım çıkış kodları:$SONUC"
echo

SON_PAKET="$(ls -dt /root/pentest-kanit-* 2>/dev/null | head -1 || true)"
if [[ -n "$SON_PAKET" && -f "$SON_PAKET/00_OZET.md" ]]; then
  info "5/10 · Kanıt paketi: $SON_PAKET"
  sed 's/^/  /' "$SON_PAKET/00_OZET.md"
else
  warn "00_OZET.md bulunamadı (19 adımına bak)."
fi

echo
echo "SIRADA (tek elle iş): 16 · e-posta kodlu şifre değişimi testi"
echo "  bash $ROOT/deploy/scripts/16_ui_sifre_kodu_akisi_test.sh"
echo "  (6 haneli kodu elle gireceksin; sonra 19'u tekrar koş.)"
echo
echo "Çalıştırma logu: $LOG"