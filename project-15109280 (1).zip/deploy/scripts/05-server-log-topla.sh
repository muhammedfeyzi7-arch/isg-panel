#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# SRV-01 · Sunucu Güvenlik Logu Toplayıcı (cron)
#
# Ne yapar:
#   1) KEŞİF  → sunucuda hangi log kaynakları var (Caddy / docker / fail2ban),
#               /var/log/ibys-log-kesif.txt raporuna yazar. Yok olanı atlar.
#   2) PARSE  → erişim loglarını + docker compose loglarını yapılandırılmış
#               olaylara çevirir (JSON satır başına jq ile).
#   3) SINIFLA→ SCAN / HTTP_ERROR_BURST / AUTH_ABUSE / RPC_DENIED / BAN ...
#   4) YAZ    → ham olayları public.server_security_events tablosuna (idempotans:
#               dedupe_key UNIQUE + ON CONFLICT DO NOTHING).
#   5) ÖZETLE → "dikkate değer" özetleri (aynı IP'den N×4xx, ban) ayrıca
#               system_logs'a TEK satır olarak yazar (panel Güvenlik ön-ayarı için).
#
# GİZLİLİK: Authorization / apikey / JWT / bearer değerleri ve e-postalar
#   temizlenir (strip_secrets). Ham sır ASLA panele yazılmaz.
#
# KURULUM (repo kökünden):
#   sudo bash deploy/scripts/05-server-log-topla.sh --kur-cron
#   (cron: */2 * * * *  /opt/ibys/deploy/scripts/05-server-log-topla.sh)
#
# Elle çalıştır:  bash deploy/scripts/05-server-log-topla.sh
#   --kesif       → yalnız keşif raporunu üret
#   --dry-run     → DB'ye YAZMAZ, bulunan olayları ekrana basar
#   --kur-cron    → cron satırını kurar (idempotent)
#   --caddy-kur   → Caddy erişim logunu otomatik açar (nano gerekmez, idempotent)
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

SCRIPT_VERSION="srv01-log-topla v5 (caddy-kur+logownership)"

SUPABASE_DOCKER_DIR="${SUPABASE_DOCKER_DIR:-/opt/ibys/supabase/docker}"
ENV_FILE="${ENV_FILE:-${SUPABASE_DOCKER_DIR}/.env}"

# Yazılabilir durum/log dizini seç (yetki yoksa /tmp'e düş).
STATE_DIR="${STATE_DIR:-/var/log/ibys-log-state}"
LOG_DIR="${LOG_DIR:-/var/log}"
if ! mkdir -p "${STATE_DIR}" 2>/dev/null || [ ! -w "${STATE_DIR}" ]; then
  STATE_DIR="/tmp/ibys-log-state"; mkdir -p "${STATE_DIR}"
fi
if ! touch "${LOG_DIR}/ibys-log-topla.log" 2>/dev/null; then
  LOG_DIR="/tmp"
fi

KESIF_RAPOR="${LOG_DIR}/ibys-log-kesif.txt"
UYGUNLUK_LOG="${LOG_DIR}/ibys-log-topla.log"
SON_CALISMA="${STATE_DIR}/last-run"
CADDY_OFFSET_DIR="${STATE_DIR}/caddy-offsets"
mkdir -p "${CADDY_OFFSET_DIR}"

MODE_KESIF=0; MODE_DRY=0; MODE_CRON=0; MODE_CADDY=0
for arg in "$@"; do
  case "$arg" in
    --kesif) MODE_KESIF=1 ;;
    --dry-run) MODE_DRY=1 ;;
    --kur-cron) MODE_CRON=1 ;;
    --caddy-kur) MODE_CADDY=1 ;;
  esac
done

# jq zorunlu (JSON parse). yoksa uyar ve çık.
if ! command -v jq >/dev/null 2>&1; then
  echo "HATA: jq bulunamadi. Kur: apt-get install -y jq" | tee -a "${UYGUNLUK_LOG}"
  exit 1
fi

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" | tee -a "${UYGUNLUK_LOG}"; }
# Bir komut hata verirse hangi satirda patladigini logla (set -e teshisi).
trap 'log "[HATA] satir ${LINENO}: ${BASH_COMMAND}"' ERR
# Çıkışta her durumda görünür bir sonuç satırı bas (sessiz ölmeyi imkânsız kıl).
CLEANUP_PATHS=()
on_exit() {
  local ec=$?
  local p
  for p in "${CLEANUP_PATHS[@]+\"${CLEANUP_PATHS[@]}\"}"; do
    [ -n "$p" ] && rm -f "$p" 2>/dev/null || true
  done
  if [ "$ec" -ne 0 ]; then log "[CIKIS] beklenmeyen durma, cikis kodu=$ec"; fi
}
trap on_exit EXIT

# ── Cron kurulumu ───────────────────────────────────────────────────────────
if [ "${MODE_CRON}" = "1" ]; then
  SCRIPT_PATH="$(readlink -f "$0")"
  CRON_LINE="*/2 * * * * ${SCRIPT_PATH} >/dev/null 2>&1"
  ( crontab -l 2>/dev/null | grep -vF "${SCRIPT_PATH}" ; echo "${CRON_LINE}" ) | crontab -
  echo "TAMAM: cron kuruldu -> ${CRON_LINE}"
  exit 0
fi

# ── Caddy erişim logu otomatik kurulum (nano gerekmez, idempotent) ──────────
caddy_kur() {
  local caddyfile="${CADDYFILE:-/etc/caddy/Caddyfile}"
  local logdir="${CADDY_LOG_DIR:-/var/log/caddy}"
  local ts bak tmp
  ts="$(date +%Y%m%d%H%M%S)"
  if [ ! -f "${caddyfile}" ]; then
    log "HATA: Caddyfile bulunamadı: ${caddyfile} (CADDYFILE degiskeniyle belirtin)"
    return 1
  fi
  mkdir -p "${logdir}" 2>/dev/null || true
  if id caddy >/dev/null 2>&1; then
    chown caddy:caddy "${logdir}" 2>/dev/null || true
    # KRITIK: 'caddy validate' root olarak calistiginda access.log'u root:root 600
    # olusturur → servis (caddy kullanicisi) yazamaz → reload patlar. Var olan
    # log dosyalarini da caddy'ye devret (yoksa da hata vermez).
    find "${logdir}" -maxdepth 1 -type f -name 'access*.log' -exec chown caddy:caddy {} \; 2>/dev/null || true
    find "${logdir}" -maxdepth 1 -type f -name 'access*.log' -exec chmod 640 {} \; 2>/dev/null || true
  fi
  chmod 750 "${logdir}" 2>/dev/null || true

  if grep -q 'access.log' "${caddyfile}" 2>/dev/null; then
    log "BILGI: ${caddyfile} zaten access.log içeriyor, ekleme yapılmadı."
  else
    bak="${caddyfile}.bak.${ts}"
    cp -a "${caddyfile}" "${bak}" 2>/dev/null || true
    tmp="$(mktemp)"
    if awk '
      BEGIN { ins = 0 }
      {
        print
        if (ins == 0 && $0 ~ /^[[:space:]]*[^#[:space:]].*\{[[:space:]]*$/ && $0 !~ /^[[:space:]]*\{[[:space:]]*$/) {
          print "    log {"
          print "        output file /var/log/caddy/access.log {"
          print "            roll_size 50MiB"
          print "            roll_keep 5"
          print "        }"
          print "        format json"
          print "    }"
          ins = 1
        }
      }
      END { if (ins == 0) exit 3 }
    ' "${caddyfile}" > "${tmp}"; then
      install -m 0644 "${tmp}" "${caddyfile}"
      rm -f "${tmp}"
      log "TAMAM: access.log direktifi eklendi -> ${caddyfile} (yedek: ${bak})"
    else
      rm -f "${tmp}"
      log "HATA: ${caddyfile} içinde site blogu (satir sonu '{') bulunamadi; elle düzenlemek gerekebilir."
      return 1
    fi
  fi

  if command -v caddy >/dev/null 2>&1; then
    if caddy validate --config "${caddyfile}" >/dev/null 2>&1; then
      log "TAMAM: Caddy yapılandırması geçerli."
      # validate root olarak log dosyasini (yeniden) olusturmus olabilir → sahiplen.
      if id caddy >/dev/null 2>&1; then
        find "${logdir}" -maxdepth 1 -type f -name 'access*.log' -exec chown caddy:caddy {} \; 2>/dev/null || true
        find "${logdir}" -maxdepth 1 -type f -name 'access*.log' -exec chmod 640 {} \; 2>/dev/null || true
      fi
    else
      log "HATA: Caddy yapılandırması geçersiz! Yedeği geri alin: cp ${caddyfile}.bak.${ts} ${caddyfile}"
      return 1
    fi
  fi

  if systemctl reload caddy >/dev/null 2>&1; then
    log "TAMAM: Caddy yeniden yüklendi."
  else
    # Nedenini saklama: son journal satırlarını göster.
    log "UYARI: 'systemctl reload caddy' başarısız oldu. Neden (son journal):"
    journalctl -xeu caddy.service --no-pager -n 15 2>/dev/null | sed 's/^/    /' >>"${UYGUNLUK_LOG}" 2>&1 || true
    # systemd koruması (ProtectSystem=strict) altında /var/log/caddy salt-okunur
    # olabilir → ReadWritePaths drop-in'i ekleyip reload'ı tekrar dene (zararsız).
    dropin_dir="/etc/systemd/system/caddy.service.d"
    if mkdir -p "${dropin_dir}" 2>/dev/null; then
      printf '%s\n' '[Service]' 'ReadWritePaths=/var/log/caddy' > "${dropin_dir}/ibys-log.conf" 2>/dev/null || true
      systemctl daemon-reload 2>/dev/null || true
      log "BILGI: ReadWritePaths=/var/log/caddy drop-in'i eklendi, reload tekrar deneniyor..."
      if systemctl reload caddy >/dev/null 2>&1; then
        log "TAMAM: Caddy yeniden yüklendi (drop-in sonrası)."
      else
        log "UYARI: reload hâlâ başarısız, tam restart deneniyor (yapı doğrulandı)..."
        journalctl -xeu caddy.service --no-pager -n 25 2>/dev/null | sed 's/^/    /' >>"${UYGUNLUK_LOG}" 2>&1 || true
        if systemctl restart caddy >/dev/null 2>&1; then
          log "TAMAM: Caddy restart edildi (yeni log yapılandırması aktif)."
        else
          log "HATA: restart da başarısız. Neden (son journal):"
          journalctl -xeu caddy.service --no-pager -n 30 2>/dev/null | sed 's/^/    /' >>"${UYGUNLUK_LOG}" 2>&1 || true
        fi
      fi
    fi
  fi
  log "TAMAM: caddy-kur bitti. Test: curl -s -o /dev/null https://<domain>/wp-login.php ; tail -n 3 ${logdir}/access.log"
}
if [ "${MODE_CADDY}" = "1" ]; then caddy_kur; exit $?; fi

# ── Env yükle (psql erişimi için gerekli değil; service-role gerekmez) ───────
: "${POSTGRES_DB:=postgres}"
: "${POSTGRES_USER:=postgres}"

# ─────────────────────────────────────────────────────────────────────────────
# FAZ 0 · KEŞİF
# ─────────────────────────────────────────────────────────────────────────────
kesif() {
  log "== KEŞİF başlıyor =="
  : > "${KESIF_RAPOR}"
  {
    echo "IBYS Sunucu Log Keşif Raporu — $(date '+%Y-%m-%d %H:%M:%S')"
    echo "=========================================================="
    echo ""

    echo "[Caddy erişim logları]"
    CADDY_FOUND=0
    for f in /var/log/caddy/access*.log /var/log/caddy/*access*.log; do
      [ -f "$f" ] && { echo "  VAR: $f ($(wc -l < "$f" 2>/dev/null || echo 0) satır)"; CADDY_FOUND=1; }
    done
    if command -v journalctl >/dev/null 2>&1 && journalctl -u caddy --no-pager -n 1 >/dev/null 2>&1; then
      echo "  VAR: journalctl -u caddy"; CADDY_FOUND=1
    fi
    [ "${CADDY_FOUND}" = "0" ] && echo "  YOK (Caddy log dosyası bulunamadı)"

    echo ""
    echo "[docker compose servisleri]"
    if [ -f "${SUPABASE_DOCKER_DIR}/docker-compose.yml" ] || [ -f "${SUPABASE_DOCKER_DIR}/docker-compose.yaml" ]; then
      (cd "${SUPABASE_DOCKER_DIR}" && docker compose ps --services 2>/dev/null | sed 's/^/  VAR: /') || echo "  (compose ps alınamadı)"
    else
      echo "  YOK (${SUPABASE_DOCKER_DIR} bulunamadı)"
    fi

    echo ""
    echo "[fail2ban]"
    if command -v fail2ban-client >/dev/null 2>&1; then
      echo "  VAR"
      fail2ban-client status 2>/dev/null | sed 's/^/  /' || true
    else
      echo "  YOK"
    fi

    echo ""
    echo "[Cloudflare token]"
    if [ -f "${ENV_FILE}" ] && grep -qiE '^CLOUDFLARE_(API_)?TOKEN=' "${ENV_FILE}" 2>/dev/null; then
      echo "  VAR (opsiyonel toplama açık)"
    else
      echo "  YOK (opsiyonel — diğer katmanlar yine çalışır)"
    fi

    echo ""
    echo "[ufw]"
    command -v ufw >/dev/null 2>&1 && ufw status | sed 's/^/  /' || echo "  YOK"
  } >> "${KESIF_RAPOR}"
  log "== KEŞİF tamam -> ${KESIF_RAPOR} =="
}

if [ "${MODE_KESIF}" = "1" ]; then kesif; exit 0; fi
[ -f "${KESIF_RAPOR}" ] || kesif

# ─────────────────────────────────────────────────────────────────────────────
# Ortak yardımcılar
# ─────────────────────────────────────────────────────────────────────────────

# Sır/token/e-posta temizleme (ham log → panele güvenli metin).
strip_secrets() {
  sed -E \
    -e 's/(authorization|apikey|api[_-]?key|bearer|token|jwt|secret|refresh)[^ ]*/\1=***REDACTED***/Ig' \
    -e 's/eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}/***JWT***/g' \
    -e 's/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/***EMAIL***/g'
}

# Kategori sınıflandırma: path + status → kategori/severity.
classify() {
  local path="$1" status="$2"
  local p; p="$(echo "$path" | tr 'A-Z' 'a-z')"
  case "$p" in
    /wp-login*|/wp-admin*|/xmlrpc.php*|/phpmyadmin*|/pma*|*.env|*/.env*|*/.git*|/vendor/phpunit*|/admin.php*|/cgi-bin*|/shell*|/\.\.*)
      echo "SCAN|warning"; return ;;
  esac
  if [ -n "$status" ] && [ "$status" -ge 400 ] 2>/dev/null; then
    if [ "$status" = "401" ] || [ "$status" = "403" ]; then echo "AUTH_ABUSE|warning"; return; fi
    echo "HTTP_ERROR_BURST|warning"; return
  fi
  echo "INFO|info"
}

# CSV satırı (jq @csv güvenli kaçış). Alanlar: occurred_at,source,category,severity,
# ip,method,host,path,status,ua,description,fingerprint,dedupe_key
emit_row() {
  jq -rn --arg ts "$1" --arg src "$2" --arg cat "$3" --arg sev "$4" --arg ip "$5" \
        --arg m "$6" --arg host "$7" --arg path "$8" --arg st "$9" --arg ua "${10}" \
        --arg desc "${11}" --arg fp "${12}" --arg dk "${13}" \
    '[$ts,$src,$cat,$sev,$ip,$m,$host,$path,($st|if .=="" then null else (tonumber? // null) end),$ua,$desc,$fp,$dk] | @csv'
}

# dedupe_key üret (source|category|ip|path|status|10-dk kova)
dedupe_key() { printf '%s|%s|%s|%s|%s|%s' "$1" "$2" "$3" "$4" "$5" "$6" | md5sum | awk '{print $1}'; }

# ─────────────────────────────────────────────────────────────────────────────
# FAZ 1-2 · CADDY erişim loglarını oku (JSON; değilse common-log fallback)
# ─────────────────────────────────────────────────────────────────────────────
ROWS_FILE="$(mktemp)"; CLEANUP_PATHS+=("${ROWS_FILE}")
OLAY_SAYI=0
IP_4XX_SAYAC="$(mktemp)"; CLEANUP_PATHS+=("${IP_4XX_SAYAC}")

process_caddy() {
  local logfile="$1"
  local state="${CADDY_OFFSET_DIR}/$(echo "$logfile" | md5sum | awk '{print $1}')"
  local offset=0
  [ -f "$state" ] && offset="$(cat "$state" 2>/dev/null || echo 0)"
  local size; size="$(stat -c %s "$logfile" 2>/dev/null || echo 0)"
  # Log rotate edildiyse (küçüldüyse) baştan başla
  [ "$size" -lt "$offset" ] && offset=0
  [ "$size" = "$offset" ] && return 0

  tail -c +"$((offset + 1))" "$logfile" | while IFS= read -r line; do
    [ -z "$line" ] && continue
    local ts src cat_sev cat sev ip m host path st ua desc fp dk
    # Caddy JSON .ts sayısal (unix epoch) gelir → timestamptz'e uygun ISO'ya çevir.
    ts="$(jq -rn --arg l "$line" 'try ($l|fromjson) as $o | if ($o.ts|type)=="number" then ($o.ts|floor|todate) elif ($o.ts|type)=="string" then $o.ts else "" end catch ""')"
    ts="$(echo "$ts" | tr -d ' ')"
    if [ -z "$ts" ] || [ "$ts" = "null" ]; then
      # common-log fallback: IP - - [time] "METHOD path proto" status size
      ip="$(echo "$line" | awk '{print $1}')"
      m="$(echo "$line" | sed -nE 's/.*"(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS) ([^"]*) [^"]*" ([0-9]{3}).*/\1/p')"
      path="$(echo "$line" | sed -nE 's/.*"(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS) ([^"]*) [^"]*" ([0-9]{3}).*/\2/p')"
      st="$(echo "$line" | sed -nE 's/.*"(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS) ([^"]*) [^"]*" ([0-9]{3}).*/\3/p')"
      host=""; ua=""; ts="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    else
      ip="$(jq -rn --arg l "$line" 'try ($l|fromjson|.request.remote_ip // .remote_ip // "-") catch "-"')"
      m="$(jq -rn --arg l "$line" 'try ($l|fromjson|.request.method // "-") catch "-"')"
      host="$(jq -rn --arg l "$line" 'try ($l|fromjson|.request.host // "-") catch "-"')"
      path="$(jq -rn --arg l "$line" 'try ($l|fromjson|.request.uri // "-") catch "-"')"
      st="$(jq -rn --arg l "$line" 'try ($l|fromjson|.status|tostring) catch ""')"
      ua="$(jq -rn --arg l "$line" 'try ($l|fromjson|.request.headers."User-Agent"[0] // "-") catch "-"')"
    fi
    [ -z "$ip" ] && ip="-"
    src="caddy"
    cat_sev="$(classify "$path" "$st")"; cat="${cat_sev%%|*}"; sev="${cat_sev##*|}"
    [ "$cat" = "INFO" ] && continue
    desc="$(printf '%s %s -> %s' "$m" "$path" "$st" | strip_secrets | cut -c1-300)"
    fp="$(printf '%s%s%s' "$ip" "$path" "$st" | md5sum | awk '{print $1}')"
    local kova; kova="$(date -u '+%Y-%m-%dT%H:%M' | cut -c1-15)"
    dk="$(dedupe_key "$src" "$cat" "$ip" "$path" "$st" "$kova")"
    emit_row "$ts" "$src" "$cat" "$sev" "$ip" "$m" "$host" "$path" "$st" "$ua" "$desc" "$fp" "$dk" >> "${ROWS_FILE}"
    if [ -n "$st" ] && [ "$st" -ge 400 ] 2>/dev/null; then
      echo "$ip" >> "${IP_4XX_SAYAC}"
    fi
  done || true
  echo "$size" > "$state"
}

CADDY_HANDLED=0
# Aynı dosya iki glob'a da uyduğu için (access.log hem access*.log hem
# *access*.log) mükerrer işlenmesin → tekilleştir.
while IFS= read -r f; do
  [ -f "$f" ] && { process_caddy "$f" || log "UYARI: Caddy log islenemedi ($f)."; CADDY_HANDLED=1; }
done < <( { ls -1 /var/log/caddy/access*.log /var/log/caddy/*access*.log 2>/dev/null || true; } | sort -u )

if [ "${CADDY_HANDLED}" = "0" ]; then
  log "Caddy erişim log dosyası bulunamadı, atlanıyor. (İpucu: '--caddy-kur' ile otomatik açılır.)"
fi

# ─────────────────────────────────────────────────────────────────────────────
# FAZ 1-2 · docker compose logları (Kong / PostgREST / GoTrue / storage)
# ─────────────────────────────────────────────────────────────────────────────
SINCE="${SON_CALISMA_SINCE:-}"
if [ -f "${SON_CALISMA}" ]; then SINCE="$(cat "${SON_CALISMA}")"; fi
if [ -z "${SINCE}" ]; then SINCE="10m"; fi

process_docker() {
  [ -f "${SUPABASE_DOCKER_DIR}/docker-compose.yml" ] || [ -f "${SUPABASE_DOCKER_DIR}/docker-compose.yaml" ] || return 0
  local pair svc logical out line src catg sev st ip path desc fp dk ts
  # compose-servis-adı : panel-kaynağı  (compose isimleri kuruluma göre değişir;
  # panel filtresi 'kong/postgrest/gotrue/storage' beklediği için eşliyoruz)
  for pair in "api-gw:kong" "rest:postgrest" "auth:gotrue" "storage:storage"; do
    svc="${pair%%:*}"; logical="${pair##*:}"
    # NOT: pipefail altında 'grep eşleşme bulamazsa' pipeline hata verip script'i
    # öldürüyordu → çıktıyı değişkene alıp `|| true` ile nötrlüyoruz.
    out="$( (cd "${SUPABASE_DOCKER_DIR}" && docker compose logs --no-color --since "${SINCE}" "$svc" 2>/dev/null || true) \
             | grep -E '(401|403|permission denied|row-level security|RLS|invalid_grant|Invalid API key|JWT)' || true )"
    [ -z "$out" ] && continue
    while IFS= read -r line; do
      [ -z "$line" ] && continue
      src="$logical"
      case "$line" in
        *"permission denied"*|*"row-level security"*|*"RLS"*) catg="RPC_DENIED" ;;
        *401*|*403*|*"invalid_grant"*|*"Invalid API key"*|*"JWT"*) catg="AUTH_ABUSE" ;;
        *) catg="RPC_DENIED" ;;
      esac
      sev="warning"
      st="$(echo "$line" | grep -oE '\b(40[0-9])\b' | head -1 || true)"
      ip="$(echo "$line" | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' | head -1 || true)"
      path="$(echo "$line" | grep -oE '(/[A-Za-z0-9._/-]{2,80})' | head -1 || true)"
      [ -z "$ip" ] && ip="-"; [ -z "$path" ] && path="-"
      ts="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
      desc="$(echo "$line" | strip_secrets | cut -c1-300)"
      fp="$(printf '%s%s%s' "$src" "$path" "$st" | md5sum | awk '{print $1}')"
      dk="$(dedupe_key "$src" "$catg" "$ip" "$path" "$st" "$(date -u '+%Y-%m-%dT%H:%M' | cut -c1-15)")"
      emit_row "$ts" "$src" "$catg" "$sev" "$ip" "-" "-" "$path" "$st" "-" "$desc" "$fp" "$dk" >> "${ROWS_FILE}"
    done <<< "$out"
  done
}
process_docker || log "UYARI: docker log toplama tamamlanamadi, kalan kaynaklarla devam ediliyor."

# ─────────────────────────────────────────────────────────────────────────────
# FAZ 1-2 · fail2ban ban olayları
# ─────────────────────────────────────────────────────────────────────────────
if command -v fail2ban-client >/dev/null 2>&1; then
  jails="$(fail2ban-client status 2>/dev/null | sed -nE 's/.*Jail list:[[:space:]]*(.*)/\1/p' | tr ',' ' ')"
  for jail in $jails; do
    ips="$(fail2ban-client status "$jail" 2>/dev/null | sed -nE 's/.*Banned IP list:[[:space:]]*(.*)/\1/p')"
    for bip in $ips; do
      cat="BAN"; sev="critical"; src="fail2ban"; st=""
      desc="fail2ban [$jail] IP bloklandı"
      fp="$(printf '%s%s' "$src" "$bip" | md5sum | awk '{print $1}')"
      dk="$(dedupe_key "$src" "$cat" "$bip" "$jail" "" "$(date -u '+%Y-%m-%d')")"
      emit_row "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$src" "$cat" "$sev" "$bip" "-" "-" "-" "$st" "-" "$desc" "$fp" "$dk" >> "${ROWS_FILE}" || true
    done
  done
fi

# ─────────────────────────────────────────────────────────────────────────────
# FAZ 3 · DB'ye yaz (COPY + ON CONFLICT DO NOTHING)
# ─────────────────────────────────────────────────────────────────────────────
COLS="occurred_at,source,category,severity,ip_address,method,host,path,status_code,user_agent,description,raw_fingerprint,dedupe_key"
ROW_COUNT="$(wc -l < "${ROWS_FILE}" 2>/dev/null || echo 0)"

if [ "${MODE_DRY}" = "1" ]; then
  log "DRY-RUN: ${ROW_COUNT} olay bulundu. [${SCRIPT_VERSION}] (DB'ye yazılmadı) İlk 5 satır:"
  head -5 "${ROWS_FILE}" | tee -a "${UYGUNLUK_LOG}"
  exit 0
fi

if [ "${ROW_COUNT}" -gt 0 ]; then
  log "DB'ye yazılıyor: ${ROW_COUNT} aday olay..."
  {
    echo "SET client_min_messages TO warning;"
    # ÖNEMLİ: LIKE ile kurulan geçici tablo NOT NULL kısıtlarını KOPYALAR ama
    # identity/default'u KOPYALAMAZ → 'id' NOT NULL ve default'suz kalır, INSERT
    # "null value in column id" ile patlar. Bu yüzden CTAS + WITH NO DATA
    # kullanıyoruz (kısıt/default kopyalamaz, yalnız tipleri alır).
    echo "CREATE TEMP TABLE stg_srv AS SELECT * FROM public.server_security_events WITH NO DATA;"
    echo "COPY stg_srv (${COLS}) FROM STDIN WITH (FORMAT csv);"
    cat "${ROWS_FILE}"
    echo "\\."
    echo "INSERT INTO public.server_security_events (${COLS})"
    echo "  SELECT ${COLS} FROM stg_srv"
    echo "  ON CONFLICT (dedupe_key) DO NOTHING;"
  } | (cd "${SUPABASE_DOCKER_DIR}" && docker compose exec -T db psql -U "${POSTGRES_USER}" -d "${POSTGRES_DB}" -v ON_ERROR_STOP=1 -q) >>"${UYGUNLUK_LOG}" 2>&1 || \
    log "UYARI: DB yazımı başarısız oldu (migration uygulandı mı? SRV-01)."
fi

# ─────────────────────────────────────────────────────────────────────────────
# FAZ 4 · Dikkate değer özetleri system_logs'a yaz (panel Güvenlik görünümü)
#    · Aynı IP'den pencere içinde >= 20 adet 4xx → SERVER_ABUSE (critical)
#    · fail2ban ban → SERVER_BAN (critical)
#   metadata'ya burst_key koyup 30 dk içinde tekrarını engeller (log flood).
# ─────────────────────────────────────────────────────────────────────────────
if [ -s "${IP_4XX_SAYAC}" ]; then
  log "Özet çıkarılıyor (IP bazlı 4xx yoğunluğu)..."
  sort "${IP_4XX_SAYAC}" | uniq -c | sort -rn | while read -r cnt ipv; do
    [ "${cnt}" -ge 20 ] || continue
    [ "${ipv}" = "-" ] && continue
    local_key="burst_${ipv}_$(date -u '+%Y-%m-%dT%H')"
    {
      echo "SET client_min_messages TO warning;"
      echo "INSERT INTO public.system_logs (user_id, role, event_type, action, description, severity, status, ip_address, metadata)"
      echo "  SELECT NULL, 'system', 'SERVER_ABUSE', 'security',"
      echo "    'Aynı IPden ${cnt} adet hatalı (4xx) istek (son pencere)', 'critical', 'failed', '${ipv}',"
      echo "    jsonb_build_object('burst_key', '${local_key}', 'count', ${cnt});"
      echo "  WHERE NOT EXISTS (SELECT 1 FROM public.system_logs WHERE event_type='SERVER_ABUSE' AND metadata->>'burst_key' = '${local_key}');"
    } | (cd "${SUPABASE_DOCKER_DIR}" && docker compose exec -T db psql -U "${POSTGRES_USER}" -d "${POSTGRES_DB}" -q) >>"${UYGUNLUK_LOG}" 2>&1 || true
  done
fi

# ─────────────────────────────────────────────────────────────────────────────
# Durum kaydet
# ─────────────────────────────────────────────────────────────────────────────
date -u '+%Y-%m-%dT%H:%M:%SZ' > "${SON_CALISMA}"
log "TAMAM. [${SCRIPT_VERSION}] İşlenen aday olay: ${ROW_COUNT}"