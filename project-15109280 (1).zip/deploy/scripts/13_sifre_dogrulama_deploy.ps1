# =============================================================================
# 13 · Windows'tan tek komutla sifre-dogrulama deploy
# =============================================================================
# Nerede çalışır : KENDİ BİLGİSAYARIN (proje kökünde, PowerShell)
# Ne yapar      :
#   1) Gerekli 4 dosyanın varlığını kontrol eder
#   2) Sunucuda /root/isg-deploy dizinini oluşturur
#   3) Dosyaları scp ile sunucuya kopyalar
#   4) Sunucuda 13_sifre_dogrulama_deploy.sh betiğini çalıştırır
#
# Kullanım:
#   .\deploy\scripts\13_sifre_dogrulama_deploy.ps1
#   .\deploy\scripts\13_sifre_dogrulama_deploy.ps1 -SshHost 37.230.105.216 -Port 23422 -SshUser root
#
# Not: Windows 10/11'de OpenSSH istemcisi hazır gelir (ssh.exe / scp.exe).
#      Her adımda SSH parolası sorulur; parola hiçbir yere yazılmaz/loglanmaz.
# =============================================================================
[CmdletBinding()]
param(
  [string]$SshHost = "37.230.105.216",
  [int]$Port = 23422,
  [string]$SshUser = "root",
  [string]$RemoteDir = "/root/isg-deploy"
)

$ErrorActionPreference = "Stop"

function Fail($msg) {
  Write-Host "HATA: $msg" -ForegroundColor Red
  exit 1
}

# --- 1) Proje kökünde miyiz? ------------------------------------------------
if (-not (Test-Path "package.json")) {
  Fail "Proje kökünde değilsin. VS Code'da projeyi aç, Terminal > New Terminal de, tekrar çalıştır."
}

$files = @(
  @{ Local = "deploy\edge-functions\sifre-dogrulama\index.ts";              Remote = "index.ts" },
  @{ Local = "supabase\migrations\20260101002800_guv40_sifre_gecmisi.sql";  Remote = "20260101002800_guv40_sifre_gecmisi.sql" },
  @{ Local = "supabase\migrations\20260101002900_guv41_sifre_kodlari.sql";  Remote = "20260101002900_guv41_sifre_kodlari.sql" },
  @{ Local = "supabase\migrations\20260101003000_guv42_sifre_kodu_atomik.sql"; Remote = "20260101003000_guv42_sifre_kodu_atomik.sql" },
  @{ Local = "deploy\scripts\13_sifre_dogrulama_deploy.sh";                 Remote = "13_sifre_dogrulama_deploy.sh" }
)

foreach ($f in $files) {
  if (-not (Test-Path $f.Local)) { Fail "Dosya bulunamadı: $($f.Local)" }
}

# --- 2) ssh / scp var mı? ---------------------------------------------------
foreach ($exe in @("ssh", "scp")) {
  if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) {
    Fail "$exe bulunamadı. Windows Ayarlar > Uygulamalar > İsteğe bağlı özellikler > OpenSSH Client kur."
  }
}

$target = "$SshUser@$SshHost"

function Invoke-Remote([string]$Command) {
  & ssh -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -o StrictHostKeyChecking=accept-new -p $Port $target $Command
  if ($LASTEXITCODE -ne 0) { Fail "SSH komutu başarısız: $Command" }
}

Write-Host "==> Sunucu: $target (port $Port)" -ForegroundColor Cyan
Write-Host "==> Uzak dizin: $RemoteDir" -ForegroundColor Cyan

# --- 3) Uzak dizini hazırla -------------------------------------------------
Invoke-Remote "mkdir -p $RemoteDir"

# --- 4) Dosyaları kopyala ---------------------------------------------------
foreach ($f in $files) {
  Write-Host "==> Kopyalanıyor: $($f.Local)" -ForegroundColor Cyan
  & scp -o ServerAliveInterval=30 -o StrictHostKeyChecking=accept-new -P $Port $f.Local "${target}:${RemoteDir}/$($f.Remote)"
  if ($LASTEXITCODE -ne 0) { Fail "Kopyalama başarısız: $($f.Local)" }
}

# --- 5) Sunucuda çalıştır ---------------------------------------------------
Write-Host "==> Sunucuda deploy başlıyor (şifre sorulursa sunucu parolanı gir)" -ForegroundColor Yellow
Invoke-Remote "chmod +x $RemoteDir/13_sifre_dogrulama_deploy.sh && bash $RemoteDir/13_sifre_dogrulama_deploy.sh $RemoteDir"

Write-Host ""
Write-Host "Tamamlandı. Tarayıcıda Ctrl+Shift+R ile yenile ve şifre değiştirme formunu test et." -ForegroundColor Green
Write-Host "Kod e-postaya gelmezse: fonksiyon yanıtındaki hata kodunu (MAIL_NOT_CONFIGURED / MAIL_SEND_FAILED) kontrol et." -ForegroundColor Yellow