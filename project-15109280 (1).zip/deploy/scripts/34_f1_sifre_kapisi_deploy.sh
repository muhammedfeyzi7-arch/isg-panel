#!/usr/bin/env bash
# =============================================================================
# 34 · GUV-44 — F1 ŞİFRE DEĞİŞİMİ KAPISI (kademeli açma + davranış kanıtı)
# =============================================================================
# Nerede çalışır : SELF-HOSTED SUNUCU (supabase docker dizini)
#
# Kullanım:
#   bash 34_f1_sifre_kapisi_deploy.sh                 # migration uygula (mod: log)
#   bash 34_f1_sifre_kapisi_deploy.sh --dogrula       # salt-okur durum kontrolü
#   bash 34_f1_sifre_kapisi_deploy.sh --test          # davranış testi (geçici kullanıcı)
#   bash 34_f1_sifre_kapisi_deploy.sh --enforce       # kapıyı ZORUNLU kıl
#   bash 34_f1_sifre_kapisi_deploy.sh --log           # tekrar gözlem moduna al
#
# ÖNERİLEN SIRA (pentest kapanışı için):
#   1) bash 34_...sh                     → log modunda kur
#   2) Uygulamayı yayınla (Edge Function + arayüz)
#   3) bash 34_...sh --test              → reddetme kanıtını al
#   4) 24-48 saat bekle, --dogrula ile ihlal sayacını izle
#   5) bash 34_...sh --enforce           → kapıyı kapat
#   6) bash 34_...sh --dogrula           → son kanıt
#
# GERİ DÖNÜŞ: bash 34_...sh --log  (anında, veri kaybı yok)
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/../.." && pwd)}"
SUPABASE_DIR="${SUPABASE_DIR:-/opt/ibys/supabase/docker}"
PGUSER="${PGUSER:-postgres}"
DB_NAME="${DB_NAME:-postgres}"
DB_CONTAINER="${DB_CONTAINER:-supabase-db}"
AUTH_CONTAINER="${AUTH_CONTAINER:-supabase-auth}"
API="${API:-http://127.0.0.1:8000}"

MIG="20260101003200_guv44_sifre_degisim_kapisi.sql"
# Sürüm damgası: sunucudaki kopyanın gerçekten güncel olduğunu kanıtlar.
SCRIPT_VERSION="guv44-gate-2026-10-20-c"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

MODE="apply"
case "${1:-}" in
  --dogrula) MODE="dogrula" ;;
  --test)    MODE="test" ;;
  --enforce) MODE="enforce" ;;
  --log)     MODE="log" ;;
  ""|--apply) MODE="apply" ;;
  *) die "Bilinmeyen parametre: $1 (kullan: --dogrula | --test | --enforce | --log)" ;;
esac

# ── Ön kontroller ───────────────────────────────────────────────────────────
if ! docker ps --format '{{.Names}}' | grep -qx "$DB_CONTAINER"; then
  die "$DB_CONTAINER konteyneri çalışmıyor (DB_CONTAINER değişkeniyle adı verebilirsin)."
fi

psql_at() { docker exec -i "$DB_CONTAINER" psql -U "$PGUSER" -d "$DB_NAME" -At -v ON_ERROR_STOP=1 -c "$1"; }
psql_try() { docker exec -i "$DB_CONTAINER" psql -U "$PGUSER" -d "$DB_NAME" -At 2>&1; }

# Süperuser yardımcıları — YALNIZCA test sonda rolünün kurulumu için.
# NEDEN: bu imajda 'postgres' SÜPERUSER DEĞİL. SET SESSION AUTHORIZATION
# yalnızca süperuser'da çalışır; bu yüzden rol kurulumu supabase_admin ile yapılır.
SUPERUSER="${SUPERUSER:-supabase_admin}"
psql_su() { docker exec -i "$DB_CONTAINER" psql -U "$SUPERUSER" -d "$DB_NAME" -At -v ON_ERROR_STOP=1 -c "$1"; }

# Sonda (probe) bağlantısı: SET SESSION AUTHORIZATION YALNIZCA süperuser'da
# çalışır. Bu yüzden probe blokları 'postgres' ile DEĞİL, süperuser ile koşulur.
# ON_ERROR_STOP yok: hatayı yakalayıp çıktıda görmek istiyoruz.
psql_su_try() { docker exec -i "$DB_CONTAINER" psql -U "$SUPERUSER" -d "$DB_NAME" -At 2>&1; }

tespit_superuser() {
  local u v
  for u in "$SUPERUSER" postgres supabase_admin; do
    v="$(docker exec -i "$DB_CONTAINER" psql -U "$u" -d "$DB_NAME" -At -c \
      "select rolsuper from pg_roles where rolname = current_user;" 2>/dev/null | tr -d '[:space:]')"
    if [[ "$v" = "t" ]]; then printf '%s\n' "$u"; return 0; fi
  done
  return 1
}

mig_path() {
  local c
  for c in "$REPO_ROOT/supabase/migrations/$MIG" "$SCRIPT_DIR/$MIG"; do
    [[ -f "$c" ]] && { printf '%s\n' "$c"; return 0; }
  done
  return 1
}

mod_oku() { psql_at "select coalesce((select mod from public.sifre_kapisi_ayar where id),'yok');" 2>/dev/null | tr -d '[:space:]'; }

# ── 1) Migration uygula ─────────────────────────────────────────────────────
if [[ "$MODE" = "apply" ]]; then
  SQL="$(mig_path || true)"
  [[ -n "$SQL" ]] || die "Migration bulunamadı: $MIG (REPO_ROOT=$REPO_ROOT)"

  info "Migration uygulanıyor: $SQL (mod: log — hiçbir şeyi engellemez)"
  docker exec -i "$DB_CONTAINER" psql -U "$PGUSER" -d "$DB_NAME" -v ON_ERROR_STOP=1 < "$SQL" \
    || die "Migration uygulanamadı. Yedek alındıysa geri dönülebilir; hata metnini inceleyin."

  info "Kurulum doğrulanıyor"
  T="$(psql_at "select count(*) from pg_trigger where tgrelid='auth.users'::regclass and tgname='trg_auth_users_sifre_kapisi' and not tgisinternal;")"
  [[ "$T" = "1" ]] || die "Trigger kurulmadı (beklenen 1, gelen ${T:-?})."
  info "trigger: kurulu · mod: $(mod_oku)"

  warn "Sıradaki adımlar: 1) Edge Function + arayüzü yayınla  2) --test ile kanıt al"
  warn "               3) 24-48 saat gözlem  4) --enforce ile kapat"
  exit 0
fi

# ── 2) Mod değiştirme ───────────────────────────────────────────────────────
if [[ "$MODE" = "enforce" ]]; then
  CUR="$(mod_oku)"
  [[ "$CUR" = "log" || "$CUR" = "enforce" ]] || die "GUV-44 kurulu değil (mod=$CUR). Önce betiği parametresiz çalıştır."

  # KRİTİK: GoTrue 'postgres' veya 'supabase_admin' ile bağlanıyorsa kapı onu
  # ATLAR (operatör istisnası). Bu durumda enforce hiçbir şey korumaz.
  GT_DB="$(docker exec "$AUTH_CONTAINER" printenv GOTRUE_DB_DATABASE_URL 2>/dev/null || true)"
  if [[ -z "$GT_DB" ]]; then
    warn "GOTRUE_DB_DATABASE_URL okunamadı ($AUTH_CONTAINER). Auth DB kullanıcısını elle doğrulayın:"
    warn "  docker exec $AUTH_CONTAINER printenv | grep GOTRUE_DB_DATABASE_URL"
  else
    GT_USER="$(printf '%s' "$GT_DB" | sed -n 's#^[a-z]*://\([^:]*\).*#\1#p')"
    info "GoTrue DB kullanıcısı: ${GT_USER:-bilinmiyor}"
    case "$GT_USER" in
      postgres|supabase_admin)
        die "GoTrue '$GT_USER' ile bağlanıyor → kapı onu atlar, enforce işe yaramaz.
     GOTRUE_DB_DATABASE_URL'i supabase_auth_admin ile kullanacak şekilde düzeltin,
     sonra bu betiği tekrar çalıştırın. (Bu haliyle enforce AÇILMAMALIDIR.)" ;;
    esac
  fi

  psql_at "update public.sifre_kapisi_ayar set mod='enforce', guncellenme=now() where id;" >/dev/null \
    || die "Mod güncellenemedi."
  info "Mod: log → enforce (şifre yazımı artık izin olmadan REDDEDİLİR)"
  warn "Kurtarma: bash $0 --log"
  exit 0
fi

if [[ "$MODE" = "log" ]]; then
  psql_at "update public.sifre_kapisi_ayar set mod='log', guncellenme=now() where id;" >/dev/null \
    || die "Mod güncellenemedi."
  info "Mod: enforce → log (kapı yalnızca gözlemler, engellemez)"
  exit 0
fi

# ── 3) Durum doğrulama ──────────────────────────────────────────────────────
if [[ "$MODE" = "dogrula" ]]; then
  info "GUV-44 durum özeti (salt okuma)"
  info "betik sürümü: $SCRIPT_VERSION"

  psql_try <<'SQL'
\pset border 2
\echo '--- Kapı modu ---'
select mod, guncellenme from public.sifre_kapisi_ayar where id;

\echo ''
\echo '--- Kapı trigger''ı (auth.users) ---'
select tgname as trigger, case tgenabled when 'O' then 'aktif' when 'D' then 'KAPALI' else tgenabled::text end as durum
  from pg_trigger
 where tgrelid = 'auth.users'::regclass and tgname = 'trg_auth_users_sifre_kapisi' and not tgisinternal;

\echo ''
\echo '--- İhlal kayıtları (izinsiz şifre yazımı denemeleri) ---'
\echo '    NOT: enforce modunda RAISE transaction''ı geri aldığı için bu sayı ARTMAZ;'
\echo '    enforce dönemi denemeleri sunucu logundadır: docker logs supabase-db | grep GUV44_'
select count(*) as toplam_ihlal,
       count(*) filter (where olusma > now() - interval '24 hours') as son_24_saat
  from public.sifre_kapisi_ihlalleri;

\echo ''
\echo '--- Son 10 ihlal (log modu gözlem penceresi) ---'
select to_char(olusma,'YYYY-MM-DD HH24:MI') as zaman, mod, oturum_kullanici, user_id
  from public.sifre_kapisi_ihlalleri
 order by olusma desc limit 10;

\echo ''
\echo '--- Aktif / tüketilmiş izinler ---'
select source,
       count(*) filter (where consumed_at is null and expires_at > now()) as aktif,
       count(*) filter (where consumed_at is not null) as tuketilmis
  from public.sifre_degisim_izinleri
 group by source order by 1;
SQL

  M="$(mod_oku)"
  echo
  if [[ "$M" = "enforce" ]]; then
    info "KAPI KAPALI (enforce) — F1 tam giderildi olarak raporlanabilir."
  elif [[ "$M" = "log" ]]; then
    warn "KAPI GÖZLEM MODUNDA (log) — F1 hâlâ 'kısmen' sayılır. Kapatmak için: --enforce"
  else
    die "GUV-44 kurulu görünmüyor (mod=$M)."
  fi
  exit 0
fi

# ── 4) Davranış testi ───────────────────────────────────────────────────────
if [[ "$MODE" = "test" ]]; then
  ENVF="${SUPABASE_ENVF:-$SUPABASE_DIR/.env}"
  [[ -r "$ENVF" ]] || die "env dosyası okunamadı: $ENVF"
  SR="$(grep -hE '^SERVICE_ROLE_KEY=' "$ENVF" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'" | tr -d '\r')"
  [[ -n "$SR" ]] || die "SERVICE_ROLE_KEY bulunamadı ($ENVF)"

  ONCEKI_MOD="$(mod_oku)"
  [[ "$ONCEKI_MOD" = "log" || "$ONCEKI_MOD" = "enforce" ]] || die "GUV-44 kurulu değil. Önce parametresiz çalıştır."

  PASS1="Guv44.Temp.$(date +%s).Aa1"
  TS="$(date +%s)"
  EMAIL="guv44.test.${TS}@pentest.local"

  cleanup() {
    [[ -n "${UID_:-}" ]] && curl -sS -o /dev/null -X DELETE "$API/auth/v1/admin/users/$UID_" \
      -H "apikey: $SR" -H "Authorization: Bearer $SR" || true
    psql_su "drop role if exists guv44_probe;" >/dev/null 2>&1 || true
    psql_at "update public.sifre_kapisi_ayar set mod='${ONCEKI_MOD}', guncellenme=now() where id;" >/dev/null 2>&1 || true
  }
  trap cleanup EXIT

  info "Test kullanıcısı oluşturuluyor: $EMAIL"
  RESP="$(curl -sS -X POST "$API/auth/v1/admin/users" \
    -H "apikey: $SR" -H "Authorization: Bearer $SR" -H 'Content-Type: application/json' \
    -d "{\"email\":\"$EMAIL\",\"password\":\"$PASS1\",\"email_confirm\":true}")"
  UID_="$(printf '%s' "$RESP" | sed -n 's/.*"id":[[:space:]]*"\([0-9a-f-]\{36\}\)".*/\1/p' | head -1)"
  [[ -n "$UID_" ]] || die "Test kullanıcısı oluşturulamadı. Yanıt: $RESP"
  info "kullanıcı: $UID_"

  # NOT: postgres ile bağlanan psql kapıyı doğal olarak atlar. GoTrue'nun
  # kimliğini taklit etmek için SET SESSION AUTHORIZATION ile süperuser
  # olmayan bir role geçilir; session_user artık 'guv44_probe' olur.
  # Sonda rolü kurulumu süperuser ister (bu imajda 'postgres' süperuser değil).
  SUPERUSER="$(tespit_superuser || true)"
  [[ -n "$SUPERUSER" ]] || die "Süperuser rol bulunamadı (supabase_admin/postgres denendi). Sonda rolü kurulamaz."
  info "Süperuser (yalnızca test kurulumu için): $SUPERUSER"

  info "Betik sürümü: $SCRIPT_VERSION"

  info "Sonda rolü hazırlanıyor (guv44_probe, süperuser değil)"
  psql_su "drop role if exists guv44_probe;" >/dev/null
  # BYPASSRLS: auth.users üzerinde RLS açıksa bile sonda satırı görebilsin.
  # Süperuser olmadan RLS'e takılıp UPDATE 0 satır döner ve test yanlış sonuç verir.
  psql_su "create role guv44_probe nologin bypassrls;" >/dev/null || die "Sonda rolü oluşturulamadı."
  psql_su "grant usage on schema auth to guv44_probe;" >/dev/null || die "auth şema yetkisi verilemedi."
  psql_su "grant select, update on auth.users to guv44_probe;" >/dev/null || die "auth.users yetkisi verilemedi."

  HAS_UPD="$(psql_at "select has_table_privilege('guv44_probe','auth.users','UPDATE');" | tr -d '[:space:]')"
  HAS_SEL="$(psql_at "select has_table_privilege('guv44_probe','auth.users','SELECT');" | tr -d '[:space:]')"
  [[ "$HAS_UPD" = "t" && "$HAS_SEL" = "t" ]] \
    || die "Sonda rolüne auth.users yetkisi verilemedi (select=$HAS_SEL update=$HAS_UPD)."
  info "sonda yetkileri: select/update auth.users = evet"

  # KRİTİK ÖN KONTROL: bürünme gerçekten çalışıyor mu?
  # Çalışmıyorsa aşağıdaki dört adımın hepsi yanlış sonuç verir; burada durmak daha iyi.
  BURUNME="$(psql_su_try <<'SQL'
set session authorization guv44_probe;
select 'SESSION_USER=' || session_user;
SQL
)"
  if ! printf '%s' "$BURUNME" | grep -q 'SESSION_USER=guv44_probe'; then
    printf '%s\n' "$BURUNME" | sed 's/^/      /'
    die "Sonda rolüne bürünülemedi ($SUPERUSER süperuser değil olabilir). Test yapılmadı."
  fi
  info "bürünme kontrolü: session_user = guv44_probe (tamam)"

  H1="$(psql_at "select extensions.crypt('Guv44.A.a1.$(date +%s)', extensions.gen_salt('bf',10));" | tr -d '[:space:]')"
  H2="$(psql_at "select extensions.crypt('Guv44.B.b2.$(date +%s)', extensions.gen_salt('bf',10));" | tr -d '[:space:]')"
  [[ -n "$H1" && -n "$H2" ]] || die "Hash üretilemedi (pgcrypto?)."

  echo
  info "Test enforce modunda yapılır (sonda ${ONCEKI_MOD} moduna geri döner)"
  psql_at "update public.sifre_kapisi_ayar set mod='enforce', guncellenme=now() where id;" >/dev/null

  # ── [1] İZİNSİZ YAZIM → REDDEDİLMELİ ──────────────────────────────────
  OUT1="$(psql_su_try <<SQL
begin;
set session authorization guv44_probe;
select 'PROBE_SESSION=' || session_user;
select 'GORUNEN_SATIR=' || count(*) from auth.users where id = '$UID_';
update auth.users set encrypted_password = '$H1' where id = '$UID_';
commit;
SQL
)"
  if printf '%s' "$OUT1" | grep -q 'PASSWORD_REAUTH_REQUIRED'; then
    printf '  %s[1] izinsiz yazim%s      REDDEDILDI (PASSWORD_REAUTH_REQUIRED)\n' "$c_grn" "$c_rst"
    PASS_A=1
  else
    printf '  %s[1] izinsiz yazim      GECTI / beklenmeyen%s\n' "$c_red" "$c_rst"
    printf '%s\n' "$OUT1" | sed 's/^/      /'
    if printf '%s' "$OUT1" | grep -q 'permission denied to set session authorization'; then
      printf '      İPUCU: SET SESSION AUTHORIZATION süperuser ister — SUPABASE testi supabase_admin ile koşun.\n'
    elif printf '%s' "$OUT1" | grep -q 'permission denied for table users'; then
      printf '      İPUCU: sonda rolünde auth.users UPDATE yetkisi yok (grant doğrulanamadı).\n'
    elif printf '%s' "$OUT1" | grep -q 'UPDATE 0'; then
      printf '      İPUCU: güncellenecek satır görünmedi (RLS/yanlış kullanıcı) — UPDATE 0 = trigger hiç çalışmadı.\n'
    elif ! printf '%s' "$OUT1" | grep -q 'PROBE_SESSION=guv44_probe'; then
      printf '      İPUCU: bürünme bloğu hiç çalışmadı — çıktıyı inceleyin.\n'
    fi
    PASS_A=0
  fi

  # ── [2] İZİNLİ YAZIM → GEÇMELİ ────────────────────────────────────────
  psql_su "select public.sifre_degisim_izni_olustur('$UID_','admin',120);" >/dev/null \
    || die "Test izni oluşturulamadı (sifre_degisim_izni_olustur)."
  OUT2="$(psql_su_try <<SQL
begin;
set session authorization guv44_probe;
update auth.users set encrypted_password = '$H2' where id = '$UID_';
commit;
SQL
)"
  if printf '%s' "$OUT2" | grep -q 'UPDATE 1'; then
    printf '  %s[2] izinli yazim%s        GECTI (UPDATE 1)\n' "$c_grn" "$c_rst"
    PASS_B=1
  else
    printf '  %s[2] izinli yazim        GECMEDI / beklenmeyen%s\n' "$c_red" "$c_rst"
    printf '%s\n' "$OUT2" | sed 's/^/      /'
    PASS_B=0
  fi

  # ── [3] İZİN TÜKETİLDİ Mİ ─────────────────────────────────────────────
  CONSUMED="$(psql_at "select count(*) from public.sifre_degisim_izinleri where user_id='$UID_' and consumed_at is not null;" | tr -d '[:space:]')"
  if [[ "${CONSUMED:-0}" -ge 1 ]]; then
    printf '  %s[3] izin tuketildi%s      EVET (consumed_at dolu)\n' "$c_grn" "$c_rst"
    PASS_C=1
  else
    printf '  %s[3] izin tuketildi      HAYIR / beklenmeyen%s\n' "$c_red" "$c_rst"
    PASS_C=0
  fi

  # ── [4] AYNI İZİNLE İKİNCİ YAZIM → REDDEDİLMELİ ───────────────────────
  H3="$(psql_at "select extensions.crypt('Guv44.C.c3.$(date +%s)', extensions.gen_salt('bf',10));" | tr -d '[:space:]')"
  OUT4="$(psql_su_try <<SQL
begin;
set session authorization guv44_probe;
update auth.users set encrypted_password = '$H3' where id = '$UID_';
commit;
SQL
)"
  if printf '%s' "$OUT4" | grep -q 'PASSWORD_REAUTH_REQUIRED'; then
    printf '  %s[4] ikinci yazim%s        REDDEDILDI (tek kullanimlik)\n' "$c_grn" "$c_rst"
    PASS_D=1
  else
    printf '  %s[4] ikinci yazim        GECTI / beklenmeyen%s\n' "$c_red" "$c_rst"
    printf '%s\n' "$OUT4" | sed 's/^/      /'
    PASS_D=0
  fi

  # ── [5] İhlal kaydı oluştu mu ─────────────────────────────────────────
  IHLAL="$(psql_at "select count(*) from public.sifre_kapisi_ihlalleri where user_id='$UID_';" | tr -d '[:space:]')"
  printf '  %s[5] ihlal kaydi%s         %s satir (log/enforce kaniti)\n' "$c_dim" "$c_rst" "${IHLAL:-0}"

  echo
  if [[ "$PASS_A$PASS_B$PASS_C$PASS_D" = "1111" ]]; then
    info "SONUÇ: PASS — izinsiz yazım reddediliyor, izinli yazım geçiyor, izin tek kullanımlık."
    echo
    echo "  Kanıt olarak saklanacak satır (rapora bu cümle girer):"
    echo "  \"$MIG davranış testi: izinsiz UPDATE → PASSWORD_REAUTH_REQUIRED,"
    echo "   izinli UPDATE → 1 satır, izin tüketildi, ikinci kullanım → reddedildi.\""
    exit 0
  else
    warn "SONUÇ: FAIL (A=$PASS_A B=$PASS_B C=$PASS_C D=$PASS_D) — rapora 'kapandı' yazmayın."
    warn "Olası sebep: sonda rolü kurulamadı, GoTrue 'postgres' ile bağlanıyor ya da migration eksik."
    warn "Teşhis: docker exec $DB_CONTAINER psql -U $PGUSER -d $DB_NAME -c \"select rolsuper from pg_roles where rolname=current_user;\""
    exit 1
  fi
fi