#!/usr/bin/env bash
# =============================================================================
# 26 · F3 · auth-log "yanıltıcı başarı" kanıtı (PENTEST-MARKER)
# =============================================================================
# F3 bulgusu: auth-log edge function'ı 200 {"ok":true} dönüyordu ama
# system_logs tablosuna HİÇ kayıt yazmıyordu (tablo */0 boş).
#
# Bu betik bulgunun GERÇEKTEN kapandığını kanıtlar:
#   1) Geçerli oturumla token alır (auth/v1/token)
#   2) auth-log'a BİLİNEN bir MARKER ile AUTH_LOGIN_SUCCESS gönderir
#   3) Yanıtın HTTP 200 + {"ok":true} + "stored" alanı içerdiğini doğrular
#      (stored="core" ise şema uyumsuzluğu var ama kayıt yine yazılmış demektir)
#   4) Service-role ile system_logs'ta MARKER'ı ARAR
#   5) Markeri bulursa PASS — bulamazsa 500/yanıltıcı başarı geri gelmiş demektir
#
# Kullanım:
#   bash deploy/scripts/26_f3_marker_kanit.sh <eposta> <sifre>
#   bash deploy/scripts/26_f3_marker_kanit.sh <eposta> <sifre> OZEL-MARKER
#   bash deploy/scripts/26_f3_marker_kanit.sh <eposta> <sifre> OZEL-MARKER --temizle
#
# Notlar:
#   * system_logs yazımı SADECE marker'lı test satırıdır; iş verisi yazılmaz.
#   * --temizle verilirse yalnızca o marker satırları silinir (kanıt log'a yazılır).
#   * Anahtar değerleri ekrana BASILMAZ.
# =============================================================================
set -uo pipefail

ENVF="${SUPABASE_ENVF:-/opt/ibys/supabase/docker/.env}"
API="${API_URL:-http://127.0.0.1:8000}"
EMAIL="${1:-}"
PASS="${2:-}"
MARKER="${3:-PENTEST-MARKER-$(date +%Y%m%d%H%M%S)}"
MODE="${4:-}"
OUT_DIR="${OUT_DIR:-/root/pentest-kanit}"
STAMP="$(date +%Y%m%d-%H%M)"
OUT_LOG="$OUT_DIR/f3_marker_$STAMP.log"
# Arşiv satırı: 40_kalan_dort_kalem.sh ve 19_pentest_kapanis_kanit.sh bu dosyayı arar.
# Deterministik ad + tek satır PASS damgası: "PASS satırı arşivde net değil" sorununu kapatır.
MARKER_FILE="$OUT_DIR/F3_PASS_$STAMP.txt"

c_grn=$'\e[32m'; c_red=$'\e[31m'; c_yel=$'\e[33m'; c_rst=$'\e[0m'
ok()   { printf '%s %s\n' "${c_grn}PASS${c_rst}" "$*"; }
bad()  { printf '%s %s\n' "${c_red}FAIL${c_rst}" "$*"; }
info() { printf '%s\n' "${c_yel}==>${c_rst} $*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

if [[ -z "$EMAIL" || -z "$PASS" ]]; then
  cat >&2 <<'EOF'
kullanim: bash 26_f3_marker_kanit.sh <eposta> <sifre> [marker] [--temizle]

  <eposta> : test hesabinin e-postasi (giris yapabilen bir hesap)
  <sifre>  : o hesabin MEVCUT sifresi
  [marker] : istege bagli; varsayilan PENTEST-MARKER-<zaman damgasi>

Ornek:
  bash deploy/scripts/26_f3_marker_kanit.sh isgsaas@outlook.com 'YeniSifre.2026.Aa1'
EOF
  exit 1
fi

[[ -r "$ENVF" ]] || die "env dosyasi okunamadi: $ENVF"
mkdir -p "$OUT_DIR"

env_get() { grep -hE "^$1=" "$ENVF" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'" | tr -d '\r'; }

SR="$(env_get SERVICE_ROLE_KEY)"
ANON="$(env_get ANON_KEY)"
[[ -z "$ANON" ]] && ANON="$(env_get SUPABASE_ANON_KEY)"
[[ -z "$ANON" ]] && ANON="$(env_get ANON_KEY)"
[[ -z "$ANON" ]] && ANON="$(env_get PUBLISHABLE_KEY)"
[[ -n "$SR"   ]] || die "SERVICE_ROLE_KEY okunamadi ($ENVF)"
[[ -n "$ANON" ]] || die "ANON_KEY okunamadi ($ENVF)"

# Aynı çıktıyı hem ekrana hem kanıt dosyasına yaz
exec > >(tee "$OUT_LOG") 2>&1

echo "════════════════════════════════════════════════════════════"
echo "  F3 kanıtı · auth-log → system_logs marker testi"
echo "  Tarih    : $(date '+%Y-%m-%d %H:%M:%S')"
echo "  API      : $API"
echo "  Hesap    : $EMAIL"
echo "  Marker   : $MARKER"
echo "════════════════════════════════════════════════════════════"

SORUN=0

# ── 1) Giriş ────────────────────────────────────────────────────────────────
info "1/5 · Giriş (token alınıyor)"
TOK_JSON="$(curl -sS -X POST "$API/auth/v1/token?grant_type=password" \
  -H "apikey: $ANON" -H 'Content-Type: application/json' \
  -d "$(printf '{"email":"%s","password":"%s"}' "$EMAIL" "$PASS")" 2>/dev/null || true)"

TOK="$(printf '%s' "$TOK_JSON" | sed -n 's/.*"access_token":"\([^"]*\)".*/\1/p' | head -1)"
if [[ -z "$TOK" ]]; then
  bad "Token alınamadı — girisi dogrula."
  printf '%s\n' "$TOK_JSON" | head -c 400
  echo
  echo "  Not: 25_pentest_hesap_sifre_yenile.sh ile sifreyi sabitleyebilirsin:"
  echo "       bash deploy/scripts/25_pentest_hesap_sifre_yenile.sh $EMAIL"
  exit 2
fi
ok "Token alındı"

# ── 2) Marker gönder ────────────────────────────────────────────────────────
info "2/5 · auth-log'a marker gönderiliyor"
HTTP_CODE="$(curl -sS -o /tmp/f3_authlog_resp.json -w '%{http_code}' \
  -X POST "$API/functions/v1/auth-log" \
  -H "apikey: $ANON" -H "Authorization: Bearer $TOK" \
  -H 'Content-Type: application/json' \
  -d "$(printf '{"event_type":"AUTH_LOGIN_SUCCESS","description":"%s"}' "$MARKER")" 2>/dev/null || echo 000)"
RESP="$(cat /tmp/f3_authlog_resp.json 2>/dev/null || true)"

echo "  HTTP $HTTP_CODE · yanıt: $(printf '%s' "$RESP" | head -c 300)"

if [[ "$HTTP_CODE" = "200" ]] && printf '%s' "$RESP" | grep -q '"ok":[[:space:]]*true'; then
  ok "auth-log 200 ok döndü"
  if printf '%s' "$RESP" | grep -q '"stored":"core"'; then
    printf '%s\n' "${c_yel}!! ${c_rst}Kayıt 'core' (indirgenmiş) kolon setiyle yazıldı."
    echo "   Kanıt geçerli, ancak tam satır şeması uyumsuz: canlı system_logs'ta"
    echo "   opsiyonel kolonlar (device_info/entity_type/request_id/metadata vb.) eksik olabilir."
    echo "   Bu bir bulgu değil, şema notu — raporda belirtmekte fayda var."
  elif printf '%s' "$RESP" | grep -q '"stored":"full"'; then
    ok "Kayıt tam kolon setiyle yazıldı (stored=full)"
  fi
else
  bad "auth-log beklenen başarı yanıtını vermedi"
  SORUN=$((SORUN+1))
fi

# ── 3) Marker'ı DB'de ara ───────────────────────────────────────────────────
sleep 1
info "3/5 · system_logs içinde marker aranıyor (service-role)"
# Sorgu parametreleri --data-urlencode ile verilir: marker içinde %, &, + gibi
# karakter olsa bile eşleşme bozulmaz. (Eski sed tabanlı kod yalnızca boşluğu
# çeviriyordu; özel karakterli marker'da YANLIŞ SONUÇ verebiliyordu.)
HITS="$(curl -sS -G "$API/rest/v1/system_logs" \
  --data-urlencode "select=id,event_type,description,created_at" \
  --data-urlencode "description=eq.$MARKER" \
  -H "apikey: $SR" -H "Authorization: Bearer $SR" \
  -H 'Prefer: count=exact' -H 'Range: 0-9' 2>/dev/null || true)"

HIT_COUNT="$(printf '%s' "$HITS" | grep -o '"id"' | wc -l | tr -d '[:space:]')"
HIT_COUNT="${HIT_COUNT:-0}"

if [[ "$HIT_COUNT" -ge 1 ]]; then
  ok "Marker DB'de BULUNDU ($HIT_COUNT kayıt)"
  printf '%s\n' "$HITS" | head -c 600
  echo
else
  bad "Marker DB'de BULUNAMADI — F3 geri gelmiş olabilir (yanıltıcı başarı)"
  echo "  Sorgu yanıtı: $(printf '%s' "$HITS" | head -c 400)"
  SORUN=$((SORUN+1))
fi

# ── 4) Toplam kayıt sayısı ──────────────────────────────────────────────────
info "4/5 · system_logs toplam satır sayısı"
TOT_HEAD="$(curl -sS -D - -o /dev/null "$API/rest/v1/system_logs?select=id&limit=1" \
  -H "apikey: $SR" -H "Authorization: Bearer $SR" \
  -H 'Prefer: count=exact' 2>/dev/null | grep -i '^content-range' | tail -1 || true)"
echo "  ${TOT_HEAD:-content-range okunamadi}"
if printf '%s' "$TOT_HEAD" | grep -qE '\*/0'; then
  bad "Tablo hâlâ BOŞ görünüyor (content-range */0) — bu F3'ün ta kendisi"
  SORUN=$((SORUN+1))
else
  ok "Tablo boş değil (en az bir kayıt var)"
fi

# ── 5) Opsiyonel temizlik ───────────────────────────────────────────────────
info "5/5 · Temizlik"
if [[ "$MODE" = "--temizle" ]]; then
  DEL_CODE="$(curl -sS -o /dev/null -w '%{http_code}' -G -X DELETE \
    "$API/rest/v1/system_logs" \
    --data-urlencode "description=eq.$MARKER" \
    -H "apikey: $SR" -H "Authorization: Bearer $SR" 2>/dev/null || echo 000)"
  echo "  Marker satırları silindi (HTTP $DEL_CODE). Kanıt bu log dosyasında duruyor."
  echo "  Rapora yazarken silme ÖNCESİ kanıtı (yukarıdaki 'BULUNDU' satırı) kullan."
else
  echo "  Temizlik istenmedi. Marker DB'de kanıt olarak kalıyor."
  echo "  Silmek istersen: aynı komutu sonuna --temizle ekleyerek tekrar koş."
fi

# ── Hüküm ───────────────────────────────────────────────────────────────────
echo
echo "════════════════════════════════════════════════════════════"
if [[ "$SORUN" = "0" ]]; then
  echo "${c_grn}SONUÇ: F3 PASS${c_rst} — auth-log yazdığını doğruluyor (marker DB'de)."
  # Deterministik arşiv satırı: tek satır, makine tarafından okunabilir.
  {
    echo "BULGU=F3"
    echo "DURUM=PASS"
    echo "MARKER=$MARKER"
    echo "DB_HIT=$HIT_COUNT"
    printf 'TEST=auth-log marker -> system_logs kaydi\n'
    echo "TARIH=$(date '+%Y-%m-%d %H:%M:%S')"
    echo "LOG=$OUT_LOG"
  } > "$MARKER_FILE"
  echo "Arşiv satırı : $MARKER_FILE"
  echo "  (Bu dosya kanıt paketine kopyalanır: 'F3 PASS' satırı artık arşivde net.)"
  echo "Kanıt dosyası: $OUT_LOG"
  exit 0
else
  echo "${c_red}SONUÇ: F3 KALDI${c_rst} — $SORUN kontrol başarısız."
  echo "Önce edge function loglarına bak:"
  echo "  docker compose -f /opt/ibys/supabase/docker/docker-compose.yml logs --tail=100 functions | grep AUTH_LOG_WRITE_FAILED"
  echo "Kanıt dosyası: $OUT_LOG"
  exit 1
fi