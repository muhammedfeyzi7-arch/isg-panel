# =============================================================================
# 41 - WINDOWS'TAN "KALAN DORT KALEM" KAPANISI
# =============================================================================
# ONEMLI: Bu dosya BILEREK sadece ASCII karakter icerir. Turkce karakterler ve
# kutu cizgileri PowerShell 5.1 tarafindan UTF-8 BOM olmadan yanlis cozulup
# parse hatasi uretiyordu (for ... do satiri komut saniliyordu). Bu yuzden tum
# metinler ASCII'dir. Dosyayi UTF-8 olarak kaydetmek zorunda degilsin.
#
# NE YAPAR
#   Yereldeki betikleri SSH ile sunucuya kopyalar, DOGRU makinede calistirir,
#   sonra kanit dosyalarinin var/yok durumunu ekrana basar.
#
# KALEMLER
#   guv45 : F5 avatar_url allowlist (canli uygula + 10 dogrulama)
#   f1    : F1 taze token penceresi (GUV-44 enforce + HTTP saldiri kaniti)
#   mask  : BULGU-05 PostgREST maskeleme (X-Pgrest-Mask kaniti)
#   f3    : F3 auth-log marker -> system_logs
#
# KULLANIM (proje kokunde, TEK SATIR - geri tirma isareti kullanma)
#   .\deploy\scripts\41_windows_kalan_dort.ps1 -Adim olc
#   .\deploy\scripts\41_windows_kalan_dort.ps1 -Adim hepsi -Eposta isgsaas@outlook.com -Sifre 'Sifre.2026' -KanitIndirme
#   .\deploy\scripts\41_windows_kalan_dort.ps1 -Adim guv45
#   .\deploy\scripts\41_windows_kalan_dort.ps1 -AtlaMask
# =============================================================================
[CmdletBinding()]
param(
    [ValidateSet('olc', 'guv45', 'f1', 'mask', 'f3', 'hepsi')]
    [string]$Adim = 'hepsi',

    [string]$Server = '37.230.105.216',
    [int]$Port = 23422,
    [string]$Kullanici = 'root',

    # Bos birakilirsa sunucuda otomatik bulunur.
    [string]$Repo = '',

    [string]$Eposta = '',
    [string]$Sifre = '',

    # BULGU-05 adimini atla (Caddyfile'a hic dokunulmaz).
    [switch]$AtlaMask,

    # Kanit dosyalarini yerelde .\pentest-kanit altina indir.
    [switch]$KanitIndirme
)

$ErrorActionPreference = 'Stop'
$Target = "$Kullanici@$Server"
$Yerel = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$baslangic = Get-Date

function Baslik([string]$m) {
    Write-Host ''
    Write-Host ('=' * 74) -ForegroundColor DarkGray
    Write-Host ("  " + $m) -ForegroundColor Cyan
    Write-Host ('=' * 74) -ForegroundColor DarkGray
}

function Uzak([string]$cmd) {
    Write-Host ("  -> " + $cmd) -ForegroundColor DarkGray
    & ssh -p $Port $Target $cmd
    return $LASTEXITCODE
}

function UzakCikti([string]$cmd) {
    $out = & ssh -p $Port $Target $cmd 2>$null
    return ((($out | Out-String).Trim()))
}

# --- 0) Yerel dosya on kontrolu ---------------------------------------------
Baslik '0 - Yerel dosya kontrolu'
Write-Host ("  proje koku: " + $Yerel) -ForegroundColor DarkGray

$gerekli = @(
    'deploy/scripts/40_kalan_dort_kalem.sh',
    'deploy/scripts/38_f1_taze_token_kanit.sh',
    'deploy/scripts/36_guv45_uygula_dogrula.sh',
    'deploy/scripts/29_bulgu_01_05_08_kapat.sh',
    'deploy/scripts/26_f3_marker_kanit.sh',
    'supabase/migrations/20260101003300_guv45_avatar_url_allowlist_sikilastir.sql',
    'deploy/postgrest-mask/server.mjs',
    'deploy/postgrest-mask/Dockerfile',
    'deploy/docker-compose.postgrest-mask.yml',
    'deploy/caddy/Caddyfile'
)

$eksik = @()
foreach ($g in $gerekli) {
    if (-not (Test-Path (Join-Path $Yerel $g))) { $eksik += $g }
}

if ($eksik.Count -gt 0) {
    Write-Host ''
    Write-Host '!! BU KLASORDE SU DOSYALAR YOK:' -ForegroundColor Red
    $eksik | ForEach-Object { Write-Host ("   - " + $_) -ForegroundColor Red }
    Write-Host ''
    Write-Host '   Yanlis klasorde olabilirsin. PowerShell basligindaki yol,' -ForegroundColor Yellow
    Write-Host '   zipin ACILDIGI proje koku olmali (deploy\scripts klasorunun iki ustu).' -ForegroundColor Yellow
    exit 2
}
Write-Host '  OK - gerekli dosyalarin hepsi yerelde var' -ForegroundColor Green

# --- 1) Sunucu baglantisi ---------------------------------------------------
Baslik '1 - Sunucu baglantisi'
$kimlik = UzakCikti 'hostname; id -un'
if (-not $kimlik) {
    Write-Host '  SSH baglantisi kurulamadi.' -ForegroundColor Red
    Write-Host ("  Denenen: ssh -p " + $Port + " " + $Target) -ForegroundColor Yellow
    Write-Host '  Anahtar/sifre, port ve IP dogru mu? Elle bir kez dene:' -ForegroundColor Yellow
    Write-Host ("    ssh -p " + $Port + " " + $Target + " hostname") -ForegroundColor DarkGray
    exit 1
}
$kimlikTek = (($kimlik -split "\r?\n") -join ' / ')
Write-Host ("  OK - " + $kimlikTek) -ForegroundColor Green

# --- 2) Sunucudaki proje dizinini bul ---------------------------------------
Baslik '2 - Sunucudaki proje dizini'
if (-not $Repo) {
    $bulunan = UzakCikti "find / -maxdepth 7 -type f -name '40_kalan_dort_kalem.sh' 2>/dev/null | head -1"
    if ($bulunan) {
        $Repo = $bulunan -replace '/deploy/scripts/40_kalan_dort_kalem\.sh$', ''
        Write-Host ("  bulundu: " + $Repo) -ForegroundColor Green
    }
    else {
        foreach ($aday in @('/root/isg-deploy', '/opt/ibys', '/root/ibys', '/srv/ibys', '/root/isg-deploy-yeni')) {
            if ((UzakCikti "test -d '$aday' && echo var || echo yok") -eq 'var') {
                $Repo = $aday
                Write-Host ("  bulundu (bilinen dizin): " + $Repo) -ForegroundColor Green
                break
            }
        }
        if (-not $Repo) {
            Write-Host '  Sunucuda proje dizini bulunamadi.' -ForegroundColor Red
            Write-Host '  Elle ver: -Repo /root/isg-deploy' -ForegroundColor Yellow
            exit 1
        }
    }
}
else {
    Write-Host ("  verilen: " + $Repo) -ForegroundColor Green
}
if ($Repo -eq '/') {
    Write-Host '  Proje koku "/" cikti, dogru degil. -Repo ile elle ver.' -ForegroundColor Red
    exit 1
}

# --- 3) Dosyalari sunucuya kopyala ------------------------------------------
Baslik '3 - Gerekli dosyalar sunucuya kopyalaniyor'

$hedefDizinler = @(
    "$Repo/deploy/scripts",
    "$Repo/deploy/caddy",
    "$Repo/deploy/postgrest-mask",
    "$Repo/supabase/migrations",
    "$Repo/supabase/migrations/rollback",
    "$Repo/supabase/tests/security"
)
foreach ($d in $hedefDizinler) {
    & ssh -p $Port $Target "mkdir -p '$d'" | Out-Null
}

$dosyalar = @(
    @{ Y = 'deploy/scripts/40_kalan_dort_kalem.sh';       U = "$Repo/deploy/scripts/" },
    @{ Y = 'deploy/scripts/38_f1_taze_token_kanit.sh';    U = "$Repo/deploy/scripts/" },
    @{ Y = 'deploy/scripts/36_guv45_uygula_dogrula.sh';   U = "$Repo/deploy/scripts/" },
    @{ Y = 'deploy/scripts/29_bulgu_01_05_08_kapat.sh';   U = "$Repo/deploy/scripts/" },
    @{ Y = 'deploy/scripts/26_f3_marker_kanit.sh';        U = "$Repo/deploy/scripts/" },
    @{ Y = 'deploy/scripts/23_kalan_adimlar.sh';          U = "$Repo/deploy/scripts/" },
    @{ Y = 'deploy/caddy/Caddyfile';                      U = "$Repo/deploy/caddy/" },
    @{ Y = 'deploy/docker-compose.postgrest-mask.yml';    U = "$Repo/deploy/" },
    @{ Y = 'deploy/docker-compose.auth-hardening.yml';    U = "$Repo/deploy/" },
    @{ Y = 'deploy/postgrest-mask/server.mjs';            U = "$Repo/deploy/postgrest-mask/" },
    @{ Y = 'deploy/postgrest-mask/Dockerfile';            U = "$Repo/deploy/postgrest-mask/" },
    @{ Y = 'deploy/postgrest-mask/README.md';             U = "$Repo/deploy/postgrest-mask/" },
    @{ Y = 'supabase/migrations/20260101003300_guv45_avatar_url_allowlist_sikilastir.sql'; U = "$Repo/supabase/migrations/" },
    @{ Y = 'supabase/migrations/rollback/20260101003300_guv45_avatar_url_allowlist_sikilastir_rollback.sql'; U = "$Repo/supabase/migrations/rollback/" },
    @{ Y = 'supabase/tests/security/guv45_avatar_allowlist.test.sql'; U = "$Repo/supabase/tests/security/" },
    @{ Y = 'PENTEST_KALAN_4_KALEM_EK_2026-10-20.md';      U = "$Repo/" }
)

$kopya = 0
$atlanan = 0
foreach ($f in $dosyalar) {
    $kaynak = Join-Path $Yerel $f.Y
    if (-not (Test-Path $kaynak)) {
        Write-Host ("  atlandi (yerelde yok): " + $f.Y) -ForegroundColor Yellow
        $atlanan++
        continue
    }
    & scp -P $Port $kaynak ($Target + ":" + $f.U) 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host ("  kopyalandi: " + $f.Y) -ForegroundColor Green
        $kopya++
    }
    else {
        Write-Host ("  HATA: " + $f.Y) -ForegroundColor Red
    }
}
Write-Host ("  toplam: " + $kopya + " kopyalandi, " + $atlanan + " atlandi") -ForegroundColor DarkGray

# Windows satir sonu temizligi + calistirma izni (CRLF bash'i bozar)
& ssh -p $Port $Target "cd '$Repo' && sed -i 's/\r$//' deploy/scripts/*.sh 2>/dev/null; chmod +x deploy/scripts/*.sh 2>/dev/null; true" | Out-Null

# --- 4) Calistir ------------------------------------------------------------
$maskArg = ''
if ($AtlaMask) { $maskArg = '--atla-mask' }

$f3Env = ''
if ($Eposta -and $Sifre) {
    $e = $Eposta -replace "'", "'\''"
    $s = $Sifre -replace "'", "'\''"
    $f3Env = "F3_EMAIL='$e' F3_PASS='$s' "
}

switch ($Adim) {
    'olc' {
        Baslik '4 - OLCUM (hicbir sey uygulanmaz)'
        Uzak "cd '$Repo' && bash deploy/scripts/40_kalan_dort_kalem.sh --sadece-olc" | Out-Null
    }
    'guv45' {
        Baslik '4 - GUV-45 / F5 - avatar allowlist (uygula + dogrula)'
        Uzak "cd '$Repo' && bash deploy/scripts/36_guv45_uygula_dogrula.sh" | Out-Null
    }
    'f1' {
        Baslik '4 - F1 - taze token penceresi'
        Uzak "cd '$Repo' && bash deploy/scripts/38_f1_taze_token_kanit.sh --enforce" | Out-Null
        Uzak "cd '$Repo' && bash deploy/scripts/38_f1_taze_token_kanit.sh" | Out-Null
    }
    'mask' {
        Baslik '4 - BULGU-05 - PostgREST maskeleyici'
        Uzak "cd '$Repo' && bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --mask-uygula" | Out-Null
    }
    'f3' {
        Baslik '4 - F3 - auth-log marker kaniti'
        if (-not $Eposta -or -not $Sifre) {
            Write-Host '  -Eposta ve -Sifre gerekli.' -ForegroundColor Red
            Write-Host '  Ornek: .\deploy\scripts\41_windows_kalan_dort.ps1 -Adim f3 -Eposta isgsaas@outlook.com -Sifre Sifre.2026' -ForegroundColor DarkGray
        }
        else {
            Uzak "cd '$Repo' && bash deploy/scripts/26_f3_marker_kanit.sh '$Eposta' '$Sifre'" | Out-Null
        }
    }
    'hepsi' {
        Baslik '4 - DORT KALEM - sirayla uygula + kanitla'
        if (-not $Eposta -or -not $Sifre) {
            Write-Host '  NOT: -Eposta/-Sifre verilmedi -> F3 atlanacak, diger ucu kosacak.' -ForegroundColor Yellow
        }
        & ssh -p $Port $Target "cd '$Repo' && ${f3Env}bash deploy/scripts/40_kalan_dort_kalem.sh $maskArg" | Out-Null
    }
}

# --- 5) Kanit durumu --------------------------------------------------------
Baslik '5 - Kanit dosyalari (sunucuda)'

$kanitCmd = 'for p in F1_TAZE_TOKEN_PASS GUV45_PASS BULGU05_PASS F3_PASS; do f=$(ls -t /root/pentest-kanit/${p}_*.txt 2>/dev/null | head -1); if [ -n "$f" ]; then echo "VAR  $p :: $f"; else echo "YOK  $p"; fi; done; ls -t /root/pentest-kanit/KALAN_4_KALEM_*.md 2>/dev/null | head -1'
$kanit = UzakCikti $kanitCmd
Write-Host $kanit

$ozet = UzakCikti "ls -t /root/pentest-kanit/KALAN_4_KALEM_*.md 2>/dev/null | head -1"
if ($ozet) {
    Baslik '6 - OZET SAYFASI'
    Uzak "cat '$ozet'" | Out-Null
}
else {
    Write-Host ''
    Write-Host '  Ozet sayfasi olusmadi. 40 betigi bu dosyayi her kosuda yazar;' -ForegroundColor Yellow
    Write-Host '  yoksa betik hic calismamis demektir (yukaridaki rc satirlarina bak).' -ForegroundColor Yellow
}

# --- 7) Opsiyonel: kanitlari yerel klasore indir ---------------------------
if ($KanitIndirme) {
    Baslik '7 - Kanitlar yerel klasore indiriliyor'
    $yerelKanit = Join-Path $Yerel 'pentest-kanit'
    New-Item -ItemType Directory -Force -Path $yerelKanit | Out-Null
    & scp -P $Port -r ($Target + ":/root/pentest-kanit/*") $yerelKanit 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) {
        Write-Host ("  indirildi: " + $yerelKanit) -ForegroundColor Green
    }
    else {
        Write-Host '  indirme basarisiz (klasor bos olabilir).' -ForegroundColor Yellow
    }
}

Baslik 'BITTI'
$sure = [int]((Get-Date) - $baslangic).TotalSeconds
Write-Host ("  Sure: " + $sure + " sn") -ForegroundColor DarkGray
Write-Host '  KURAL: yukarida YOK yazan kalem KAPANMIS SAYILMAZ.' -ForegroundColor Yellow
Write-Host ("  Elle bakmak icin: ssh -p " + $Port + " " + $Target + " ls -t /root/pentest-kanit") -ForegroundColor DarkGray
Write-Host ''