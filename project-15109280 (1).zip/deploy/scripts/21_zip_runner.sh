#!/usr/bin/env bash
# =============================================================================
# 21 · SUNUCU TARAFI ÇALIŞTIRICI — zip'i açar, pentest kapanış adımlarını koşar
# =============================================================================
# Bu betik SUNUCUDA çalışır. Windows'tan `21_zip_ile_pentest_kapanis.ps1`
# tarafından otomatik kopyalanıp çağrılır; elle çağırman gerekmez.
#
# Kullanım (sunucuda):
#   bash /root/isg_zip_runner.sh <zip-yolu> <hedef-dizin> <adimlar> <atla_pgtap> <iptables_kalici>
#   bash /root/isg_zip_runner.sh /root/isg-paket.zip /root/isg-deploy "14,15,17,18,19" 0 0
#
# Ne yapar:
#   1) zip'i hedef dizine açar (unzip yoksa python3, o da yoksa kurar)
#   2) deploy/scripts/14_... betiğini bularak gerçek proje kökünü tespit eder
#      (zip'in içinde üst klasör olsa da olmasa da çalışır)
#   3) verilen adımları sırayla koşar, çıkış kodlarını toplar
#   4) sonda 00_OZET.md tablosunu ekrana basar
# =============================================================================
set -uo pipefail

ZIP="${1:-/root/isg-paket.zip}"
DEST="${2:-/root/isg-deploy}"
ADIMLAR="${3:-24,15,17,18,19}"
ATLA_PGTAP="${4:-0}"
IPTABLES_KALICI="${5:-0}"

STAMP="$(date +%Y%m%d-%H%M%S)"
RUNLOG="/root/pentest-kanit-run-${STAMP}.log"

c_grn=$'\e[32m'; c_red=$'\e[31m'; c_yel=$'\e[33m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
err()  { printf '%s\n' "${c_red}XX ${c_rst}$*"; }

# Tüm çıktı hem ekrana hem log dosyasına gitsin
exec > >(tee -a "$RUNLOG") 2>&1

echo "════════════════════════════════════════════════════════════"
echo "  Pentest kapanış · zip ile çalıştırma"
echo "  zip     : $ZIP"
echo "  hedef   : $DEST"
echo "  adımlar : $ADIMLAR"
echo "  log     : $RUNLOG"
echo "════════════════════════════════════════════════════════════"

# ── 1) zip var mı? ─────────────────────────────────────────────────────────
if [[ ! -f "$ZIP" ]]; then
  err "zip bulunamadı: $ZIP"
  exit 1
fi

# ── 2) aç ──────────────────────────────────────────────────────────────────
info "1/4 · Arşiv açılıyor → $DEST"
rm -rf "$DEST"
mkdir -p "$DEST"

if command -v unzip >/dev/null 2>&1; then
  unzip -oq "$ZIP" -d "$DEST" || { err "unzip başarısız (bozuk arşiv olabilir)"; exit 1; }
elif command -v python3 >/dev/null 2>&1; then
  python3 - "$ZIP" "$DEST" <<'PY' || { err "python ile açma başarısız"; exit 1; }
import sys, zipfile
zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])
PY
else
  warn "unzip ve python3 yok, unzip kuruluyor..."
  DEBIAN_FRONTEND=noninteractive apt-get update -qq >/dev/null 2>&1 || true
  DEBIAN_FRONTEND=noninteractive apt-get install -y unzip >/dev/null 2>&1 || true
  command -v unzip >/dev/null 2>&1 || { err "unzip kurulamadı"; exit 1; }
  unzip -oq "$ZIP" -d "$DEST" || { err "unzip başarısız"; exit 1; }
fi

# ── 3) proje kökünü bul ────────────────────────────────────────────────────
MARKER="$(find "$DEST" -type f -name '14_fk_guv39_guv32_deploy.sh' -path '*/deploy/scripts/*' 2>/dev/null | head -1)"
if [[ -z "$MARKER" ]]; then
  err "zip içinde deploy/scripts/14_fk_guv39_guv32_deploy.sh bulunamadı."
  echo "--- zip içeriği (ilk 30 giriş) ---"
  find "$DEST" -maxdepth 2 2>/dev/null | head -30
  echo "---------------------------------"
  err "Bu zip büyük olasılıkla yalnızca arayüz dosyalarını içeriyor (deploy/ klasörü yok)."
  err "O durumda proje klasöründen 20_pentest_kapanis_deploy.ps1 çalıştırılmalı."
  exit 2
fi

ROOT="$(cd "$(dirname "$(dirname "$(dirname "$MARKER")")")" && pwd)"
info "2/4 · Proje kökü: $ROOT"
chmod +x "$ROOT"/deploy/scripts/*.sh 2>/dev/null || true

for f in 14_fk_guv39_guv32_deploy.sh 15_sifre_kod_temizlik_cron.sh 17_mail_dns_dogrula.sh 18_egress_firewall.sh 19_pentest_kapanis_kanit.sh 24_guv43_service_role_truncate.sh; do
  [[ -f "$ROOT/deploy/scripts/$f" ]] || warn "eksik betik: $f"
done

# ── SERT ÖN KOŞUL: GUV-43 ──────────────────────────────────────────────────
# 24 adımı istendiği halde betik/migration yoksa DURDUR. Aksi halde izole pgTAP
# klonu fix'siz kurulur ve "not ok 6 - service_role TRUNCATE" aynen tekrar eder.
if [[ "$ADIMLAR" == *",24,"* ]]; then
  if [[ ! -f "$ROOT/deploy/scripts/24_guv43_service_role_truncate.sh" ]]; then
    err "adımlar 24 istiyor ama deploy/scripts/24_guv43_service_role_truncate.sh zipte YOK."
    err "Bu zip ESKİ. GUV-43 uygulanmaz, pgTAP 'not ok 6 - TRUNCATE' tekrar eder."
    exit 2
  fi
  if [[ ! -f "$ROOT/supabase/migrations/20260101003100_guv43_service_role_truncate_revoke.sql" ]]; then
    err "supabase/migrations/20260101003100_guv43_... yok. İzole pgTAP klonu fix'siz kurulur."
    err "Bu zip ESKİ — güncel zip ile tekrar dene."
    exit 2
  fi
  info "GUV-43 dosyaları arşivde doğrulandı (migration + 24 betiği)."
fi

# ── 4) adımları koş ────────────────────────────────────────────────────────
SONUC=""
KOS() {
  local no="$1" ad="$2" cmd="$3"
  echo
  echo "────────────────────────────────────────────────────────────"
  echo "  $no · $ad"
  echo "────────────────────────────────────────────────────────────"
  ( cd "$ROOT" && REPO_ROOT="$ROOT" bash -c "$cmd" )
  local rc=$?
  if [[ $rc -eq 0 ]]; then
    echo "   ↳ $no çıkış kodu: 0 (başarılı)"
  else
    warn "$no çıkış kodu: $rc — yukarıdaki çıktıya bakın"
  fi
  SONUC="$SONUC $no=$rc"
  return 0
}

info "3/4 · Adımlar koşuluyor"

case ",$ADIMLAR," in *",14,"*)
  warn "14 kısa bir tablo kilidi alır. Düşük trafikli saatte çalıştırın."
  KOS "14" "GUV-39 + GUV-32 (FK zinciri + gerçek silme testi)" \
      "bash deploy/scripts/14_fk_guv39_guv32_deploy.sh"
;; esac

case ",$ADIMLAR," in *",24,"*)
  warn "24 · GUV-43 yalnızca yetki (ACL) değiştirir; veri okumaz/yazmaz."
  KOS "24a" "GUV-43 · service_role TRUNCATE — DOĞRULA (önce, salt okuma)" \
      "bash deploy/scripts/24_guv43_service_role_truncate.sh --dogrula"
  KOS "24b" "GUV-43 · service_role TRUNCATE — UYGULA" \
      "bash deploy/scripts/24_guv43_service_role_truncate.sh"
;; esac

case ",$ADIMLAR," in *",15,"*)
  KOS "15" "Şifre kodu temizlik cron'u (kurulum + durum)" \
      "bash deploy/scripts/15_sifre_kod_temizlik_cron.sh"
;; esac

case ",$ADIMLAR," in *",17,"*)
  KOS "17" "SPF / DKIM / DMARC doğrulama" \
      "bash deploy/scripts/17_mail_dns_dogrula.sh --dogrula"
;; esac

case ",$ADIMLAR," in *",18,"*)
  KOS "18a" "Egress firewall — KURU ÇALIŞMA (kural yazılmaz)" \
      "bash deploy/scripts/18_egress_firewall.sh"
  warn "Yukarıdaki listede Docker iç ağları ACCEPT, sonra özel aralıklar REJECT olmalı."
  KOS "18b" "Egress firewall — UYGULA" \
      "bash deploy/scripts/18_egress_firewall.sh --uygula"
  KOS "18c" "Egress firewall — DOĞRULA" \
      "bash deploy/scripts/18_egress_firewall.sh --dogrula"
  if [[ "$IPTABLES_KALICI" = "1" ]]; then
    KOS "18d" "iptables kalıcılığı (iptables-persistent)" \
        "DEBIAN_FRONTEND=noninteractive apt-get install -y iptables-persistent >/dev/null 2>&1; netfilter-persistent save"
  else
    warn "Kurallar reboot'ta silinir. Kalıcı yapmak için -IptablesKalici ile tekrar koş."
  fi
;; esac

case ",$ADIMLAR," in *",19,"*)
  KOS "19" "Kanıt paketi (/root/pentest-kanit-<tarih>)" \
      "ATLA_PGTAP=$ATLA_PGTAP bash deploy/scripts/19_pentest_kapanis_kanit.sh"
;; esac

# ── 5) özet ────────────────────────────────────────────────────────────────
echo
echo "════════════════════════════════════════════════════════════"
echo "  ÇALIŞTIRMA ÖZETİ"
echo "════════════════════════════════════════════════════════════"
echo "  adım çıkış kodları:$SONUC"
echo

SON_PAKET="$(ls -dt /root/pentest-kanit-* 2>/dev/null | head -1 || true)"
if [[ -n "$SON_PAKET" && -f "$SON_PAKET/00_OZET.md" ]]; then
  info "4/4 · Kanıt paketi: $SON_PAKET"
  echo
  sed 's/^/  /' "$SON_PAKET/00_OZET.md"
else
  warn "4/4 · 00_OZET.md bulunamadı. 19 adımını koştunuz mu?"
fi

echo
echo "SIRADA (tek elle iş): 16 · e-posta kodlu şifre değişimi testi"
echo "  bash $ROOT/deploy/scripts/16_ui_sifre_kodu_akisi_test.sh"
echo "Sonra 19'u tekrar koşarsan bu kanıt pakete otomatik eklenir."
echo "Çalıştırma logu: $RUNLOG"