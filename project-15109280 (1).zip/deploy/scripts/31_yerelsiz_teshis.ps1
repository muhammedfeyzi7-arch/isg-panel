# =============================================================================
# 31 · YEREL DOSYA GEREKTIRMEYEN SUNUCU TESHISI  (PowerShell)
# =============================================================================
# NEDEN VAR:
#   29_/30_ betikleri proje klasorunde olmalari gerekir. Kullanici eski bir
#   zip ile calisirsa "No such file or directory" alir. Bu betik HICBIR yerel
#   dosyaya ihtiyac duymaz: bash metnini dogrudan SSH uzerinden sunucuya
#   gonderip orada calistirir. Sadece OKUR, hicbir yapilandirmayi degistirmez.
#
# KULLANIM (PowerShell, bu dosyanin oldugu klasorde):
#   .\deploy\scripts\31_yerelsiz_teshis.ps1
#   .\deploy\scripts\31_yerelsiz_teshis.ps1 -Server 37.230.105.216 -Port 23422
#
# CIKTIYI OLDUGU GIBI PAYLAS. Sunucuda Caddy mi nginx mi var, api blogunda
# HSTS var mi, govde limiti calisiyor mu, proje dizini nerede - hepsi gorunur.
# =============================================================================
[CmdletBinding()]
param(
    [string]$Server = '37.230.105.216',
    [string]$Port = '23422',
    [string]$User = 'root'
)

$ErrorActionPreference = 'Stop'
$Target = "$User@$Server"

# NOT: Bash metni bilerek ASCII tutuldu. Windows PowerShell boru hattina
# Turkce karakter yazilirsa kodlama bozulup betik sozdizimi hatasi verebilir.
$Betik = @'
set -u

echo "=============================================================="
echo " 1) ORTAM"
echo "=============================================================="
hostname
id -un
uname -sr

echo "--- web sunucusu ---"
if command -v caddy >/dev/null 2>&1; then
  echo "caddy: $(caddy version 2>/dev/null | head -1)"
else
  echo "caddy: YOK"
fi
if command -v nginx >/dev/null 2>&1; then echo "nginx: VAR"; else echo "nginx: YOK"; fi
echo "caddy servis: $(systemctl is-active caddy 2>/dev/null || echo -)"
echo "nginx servis: $(systemctl is-active nginx 2>/dev/null || echo -)"

echo "--- dinleyen portlar (80/443/8000/8001/3000) ---"
ss -lntp 2>/dev/null | grep -E ':(80|443|8000|8001|3000)[[:space:]]' || echo "(ss cikti vermedi)"

echo "--- docker konteynerleri ---"
docker ps --format '{{.Names}} {{.Ports}}' 2>/dev/null | head -20 || echo "(docker yok veya yetki yok)"

echo
echo "=============================================================="
echo " 2) CADDYFILE"
echo "=============================================================="
FOUND=0
for f in /etc/caddy/Caddyfile /etc/caddy/Caddyfile.d/*; do
  if [ -f "$f" ]; then
    FOUND=1
    echo "--- $f ---"
    cat "$f"
    echo
  fi
done
[ "$FOUND" -eq 0 ] && echo "(Caddyfile bulunamadi)"

echo
echo "=============================================================="
echo " 3) CANLI BASLIKLAR (BULGU-08)"
echo "=============================================================="
for h in app.isgdenetim.com.tr api.isgdenetim.com.tr; do
  echo "--- $h ---"
  curl -sS -o /dev/null -D - "https://$h/" --max-time 10 2>&1 \
    | grep -iE '^(HTTP/|strict-transport-security|x-content-type-options|referrer-policy|server:)' \
    || echo "(yanit yok)"
done

echo
echo "=============================================================="
echo " 4) GOVDE LIMITI (BULGU-01 / BULGU-03)"
echo "=============================================================="
head -c 1048576 /dev/zero | tr '\0' 'a' > /tmp/isg-big.txt
for f in auth-log send-reset-email accept-invite; do
  code=$(curl -sS -o /dev/null -w '%{http_code}' -X POST \
    "https://api.isgdenetim.com.tr/functions/v1/$f" \
    -H 'content-type: application/json' \
    --data-binary @/tmp/isg-big.txt --max-time 25 || echo "ERR")
  echo "$f 1MB govde -> HTTP $code   (413/400 = limit var, 200 = limit yok)"
done
rm -f /tmp/isg-big.txt

echo
echo "=============================================================="
echo " 5) SEMA IFSA MASKELEYICI (BULGU-05)"
echo "=============================================================="
if ss -lnt 2>/dev/null | grep -qE ':8001[[:space:]]'; then
  echo "8001 dinleniyor: maskeleyici CALISIYOR"
else
  echo "8001 kapali: maskeleyici CALISMIYOR"
fi
echo "--- ornek sizinti testi (olmayan kolon) ---"
curl -sS "https://api.isgdenetim.com.tr/rest/v1/profiles?select=bu_kolon_yok&limit=1" \
  -H 'apikey: anon' --max-time 10 2>&1 | head -c 300
echo

echo
echo "=============================================================="
echo " 6) SUNUCUDAKI PROJE DIZINI"
echo "=============================================================="
find / -maxdepth 7 -type f -name '29_bulgu_01_05_08_kapat.sh' 2>/dev/null | head -3
echo "(cikti bossa sunucudaki proje kopyasi eski - dosyalari gondermek gerekiyor)"

echo
echo "TESHIS BITTI. Bu ciktiyi oldugu gibi paylas."
'@

Write-Host ''
Write-Host ('=' * 74) -ForegroundColor DarkGray
Write-Host "  SUNUCU TESHISI - ${Target}:$Port" -ForegroundColor Cyan
Write-Host "  (salt okunur - hicbir yapilandirma degistirilmez)" -ForegroundColor DarkGray
Write-Host ('=' * 74) -ForegroundColor DarkGray
Write-Host ''

$Betik | & ssh -p $Port $Target "cat > /tmp/isg-teshis.sh; sed -i 's/\r$//' /tmp/isg-teshis.sh; bash /tmp/isg-teshis.sh"

if ($LASTEXITCODE -ne 0) {
    Write-Host ''
    Write-Host 'SSH komutu hata kodu dondurdu. Baglanti/anahtar/port kontrol edilmeli.' -ForegroundColor Red
}