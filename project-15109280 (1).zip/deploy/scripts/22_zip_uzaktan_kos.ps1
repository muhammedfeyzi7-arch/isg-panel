# 22_zip_uzaktan_kos.ps1
# Amac: indirilen proje zip'ini sunucuya atip 14 -> 19 kanit betiklerini sirayla kosturmak.
# Not: 16 (UI sifre kodu testi) bilerek dahil degil, e-postaya gelen kodu elle girmen gerekiyor.
#
# Kullanim:
#   .\deploy\scripts\22_zip_uzaktan_kos.ps1
#   .\deploy\scripts\22_zip_uzaktan_kos.ps1 -Zip "C:\Users\monst\Downloads\project-15023485.zip"
#
param(
  [string]$Zip   = "C:\Users\monst\Downloads\project-15023485.zip",
  [string]$Sunucu = "root@37.230.105.216",
  [int]$Port     = 23422
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $Zip)) { Write-Host "!! Zip bulunamadi: $Zip" -ForegroundColor Red; exit 1 }

# ── Zip ICERIK on kontrolu ─────────────────────────────────────────────────
# NEDEN: eski bir zip gonderilirse GUV-43 fix'i sunucuya hic gitmez, 24 betigi
# bulunamaz ve pgTAP'ta "not ok 6 - service_role TRUNCATE" aynen tekrar eder.
# Bu kontrol bir turun daha bosa gitmesini engeller.
Add-Type -AssemblyName System.IO.Compression.FileSystem

$gerekli = @(
  'supabase/migrations/20260101003100_guv43_service_role_truncate_revoke.sql',
  'deploy/scripts/24_guv43_service_role_truncate.sh',
  'deploy/scripts/14_fk_guv39_guv32_deploy.sh'
)

$entryAdlari = @()
try {
  $zipRef = [System.IO.Compression.ZipFile]::OpenRead((Resolve-Path $Zip).Path)
  $entryAdlari = @($zipRef.Entries | ForEach-Object { $_.FullName -replace '\\', '/' })
  $zipRef.Dispose()
} catch {
  Write-Host "!! Zip okunamadi: $($_.Exception.Message)" -ForegroundColor Red
  exit 1
}

$eksik = @()
foreach ($g in $gerekli) {
  if (-not ($entryAdlari | Where-Object { $_ -like "*$g" })) { $eksik += $g }
}

if ($eksik.Count -gt 0) {
  Write-Host ""
  Write-Host "!! ZIP ESKI / EKSIK — su dosyalar arsivde YOK:" -ForegroundColor Red
  $eksik | ForEach-Object { Write-Host "   - $_" -ForegroundColor Red }
  Write-Host ""
  Write-Host "   Readdy -> Code sekmesinden YENI zip indirip tekrar dene." -ForegroundColor Yellow
  Write-Host "   Bu zip ile devam edersen pgTAP'ta 'not ok 6 - TRUNCATE' aynen tekrar eder." -ForegroundColor Yellow
  exit 2
}

Write-Host "ok  Zip icerigi dogrulandi (GUV-43 migration + 24 + 14 var)." -ForegroundColor Green

$tmpZip = Join-Path $env:TEMP "isg-paket.zip"
$tmpSh  = Join-Path $env:TEMP "isg_kos.sh"

Copy-Item -Force $Zip $tmpZip

# Uzak sunucuda kosacak betik. Satirlar tek tek yaziliyor ki CRLF karismasin.
$L = New-Object System.Collections.Generic.List[string]
$L.Add('set -uo pipefail')
$L.Add('export DEBIAN_FRONTEND=noninteractive')
$L.Add('ZIP=/root/isg-paket.zip')
$L.Add('DEST=/root/isg-deploy')
$L.Add('rm -rf "$DEST"')
$L.Add('mkdir -p "$DEST"')
$L.Add('if ! command -v unzip >/dev/null 2>&1; then apt-get update -qq >/dev/null 2>&1 || true; apt-get install -y unzip >/dev/null 2>&1 || true; fi')
$L.Add('if ! command -v unzip >/dev/null 2>&1; then echo "!! unzip kurulamadi"; exit 3; fi')
$L.Add('unzip -oq "$ZIP" -d "$DEST" || { echo "!! unzip basarisiz"; exit 3; }')
$L.Add('MARKER="$(find "$DEST" -type f -name "14_fk_guv39_guv32_deploy.sh" -path "*/deploy/scripts/*" | head -n 1)"')
$L.Add('if [ -z "$MARKER" ]; then')
$L.Add('  echo "!! zip icinde deploy/scripts/14_fk_guv39_guv32_deploy.sh yok"')
$L.Add('  echo "   Guncel zipi indirip tekrar dene."')
$L.Add('  find "$DEST" -maxdepth 2 | head -n 20')
$L.Add('  exit 2')
$L.Add('fi')
$L.Add('ROOT="$(cd "$(dirname "$(dirname "$(dirname "$MARKER")")")" && pwd)"')
$L.Add('echo "PROJE KOKU: $ROOT"')
$L.Add('cd "$ROOT" || exit 4')
$L.Add('chmod +x deploy/scripts/*.sh 2>/dev/null || true')
$L.Add('export REPO_ROOT="$ROOT"')
$L.Add('run() { echo; echo "===== $1 ====="; shift; "$@"; echo "--> rc=$?"; }')
$L.Add('run "14 FK (GUV-39 -> GUV-32)" bash deploy/scripts/14_fk_guv39_guv32_deploy.sh')
$L.Add('run "15 cron temizlik" bash deploy/scripts/15_sifre_kod_temizlik_cron.sh')
$L.Add('run "17 mail DNS" bash deploy/scripts/17_mail_dns_dogrula.sh --dogrula')
$L.Add('run "18 kuru" bash deploy/scripts/18_egress_firewall.sh')
$L.Add('run "18 uygula" bash deploy/scripts/18_egress_firewall.sh --uygula')
$L.Add('run "18 dogrula" bash deploy/scripts/18_egress_firewall.sh --dogrula')
$L.Add('run "24a GUV-43 truncate dogrula" bash deploy/scripts/24_guv43_service_role_truncate.sh --dogrula')
$L.Add('run "24b GUV-43 truncate uygula" bash deploy/scripts/24_guv43_service_role_truncate.sh')
$L.Add('run "19 kanit" bash deploy/scripts/19_pentest_kapanis_kanit.sh')
$L.Add('echo')
$L.Add('echo "KANIT KLASORU:"')
$L.Add('ls -dt /root/pentest-kanit-* 2>/dev/null | head -n 1')

# LF ile yaz (BOM yok) - bash bunu sorunsuz okur
$enc  = New-Object System.Text.UTF8Encoding($false)
$text = ($L -join "`n") + "`n"
[System.IO.File]::WriteAllText($tmpSh, $text, $enc)

Write-Host ""
Write-Host "1/2  Dosyalar sunucuya gonderiliyor..." -ForegroundColor Cyan
scp -P $Port $tmpZip $tmpSh "${Sunucu}:/root/"
if ($LASTEXITCODE -ne 0) { Write-Host "!! scp basarisiz" -ForegroundColor Red; exit 1 }

Write-Host ""
Write-Host "2/2  Sunucuda kosturuluyor (14 birkac dakika surebilir)..." -ForegroundColor Cyan
ssh -p $Port $Sunucu "bash /root/isg_kos.sh 2>&1 | tee /root/isg-kos.log"
$rc = $LASTEXITCODE

Write-Host ""
Write-Host "Bitti. ssh rc=$rc" -ForegroundColor Yellow
Write-Host "Tam log sunucuda: /root/isg-kos.log" -ForegroundColor Yellow
Write-Host "Indirmek icin:  scp -P $Port -r ${Sunucu}:/root/pentest-kanit-* ." -ForegroundColor Yellow
exit $rc