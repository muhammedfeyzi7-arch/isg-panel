// ─────────────────────────────────────────────────────────────────────────────
// Node.js 20 preload: @supabase/supabase-js, createClient sırasında realtime-js
// üzerinden WebSocket arar. Node 20'de native WebSocket olmadığı için
// "Node.js 20 detected without native WebSocket support" hatası fırlatır.
// Bu dosya "ws" paketini global WebSocket olarak tanımlar ve hatayı önler.
//
// Kurulum:  npm install ws
// Kullanım: node --import ./deploy/scripts/ws-preload.mjs deploy/scripts/03-storage-tasi.mjs
// ─────────────────────────────────────────────────────────────────────────────
import { WebSocket } from 'ws';

globalThis.WebSocket = WebSocket;