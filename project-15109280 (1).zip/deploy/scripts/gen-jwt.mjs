// ─────────────────────────────────────────────────────────────────────────────
// JWT üretici (harici bağımlılık YOK)
// JWT_SECRET ile Supabase anon / service_role token'larını üretir.
//
// Kullanım:
//   node gen-jwt.mjs "<JWT_SECRET>" anon
//   node gen-jwt.mjs "<JWT_SECRET>" service_role
// ─────────────────────────────────────────────────────────────────────────────
import { createHmac } from 'node:crypto';

const [, , secret, role = 'anon', days = '3650'] = process.argv;

if (!secret) {
  console.error('Kullanim: node gen-jwt.mjs "<JWT_SECRET>" [anon|service_role] [gun]');
  process.exit(1);
}
if (!['anon', 'service_role'].includes(role)) {
  console.error('Hata: role yalnizca "anon" veya "service_role" olabilir.');
  process.exit(1);
}

const b64url = (obj) => Buffer.from(JSON.stringify(obj)).toString('base64url');
const iat = Math.floor(Date.now() / 1000);
const exp = iat + Number(days) * 24 * 60 * 60;

const header = { alg: 'HS256', typ: 'JWT' };
const payload = { role, iss: 'supabase', iat, exp };

const data = `${b64url(header)}.${b64url(payload)}`;
const sig = createHmac('sha256', secret).update(data).digest('base64url');

process.stdout.write(`${data}.${sig}\n`);