# =============================================================================
# 28 · ZIP KUR + SUNUCUYA BAĞLAN + TESTLERİ KOŞ  (tek komut)
# =============================================================================
# Nerede çalışır : KENDİ BİLGİSAYARIN (PowerShell). Proje kökünde olmak ZORUNDA DEĞİLSİN.
#
# Ne yapar:
#   1) İndirdiğin en yeni project-*.zip'i bulur (veya -Zip ile verirsin)
#   2) Zip içeriğini kontrol eder (eski/eksik zip ise hiç yüklemeden durur)
#   3) Zip'i + sunucu tarafı çalıştırıcıyı sunucuya kopyalar
#   4) Sunucuda: zip'i açar → EDGE FUNCTION'LARI YAYINLAR → GUV-43, FK, cron,
#      DNS, egress adımlarını koşar → 27 doğrulama testi → 19 kanıt paketi
#   5) Özeti ekrana basar
#
# Kullanım:
#   .\28_zip_kur_test.ps1
#   .\28_zip_kur_test.ps1 -Zip C:\Users\monst\Downloads\project-15025408.zip
#   .\28_zip_kur_test.ps1 -SadeceKur          # zip'i sadece aç, test koşma
#   .\28_zip_kur_test.ps1 -EgressYok          # egress firewall adımını atla
# =============================================================================
[CmdletBinding()]
param(
  [string]$Zip = "",
  [string]$SshHost = "37.230.105.216",
  [int]$Port = 23422,
  [string]$SshUser = "root",
  [string]$RemoteZip = "/root/isg-paket.zip",
  [string]$RemoteDir = "/root/isg-deploy",
  [switch]$SadeceKur,
  [switch]$EgressYok
)

$ErrorActionPreference = "Stop"

function Fail($m) { Write-Host ""; Write-Host "HATA: $m" -ForegroundColor Red; exit 1 }
function Baslik($m) { Write-Host ""; Write-Host "==> $m" -ForegroundColor Cyan }
function Iyi($m) { Write-Host "OK  $m" -ForegroundColor Green }
function Uyari($m) { Write-Host "!!  $m" -ForegroundColor Yellow }

# --- 1) sunucu tarafı çalıştırıcı ------------------------------------------
$runner = Join-Path $PSScriptRoot "28_sunucu_kur_test.sh"
if (-not (Test-Path $runner)) {
  Fail "28_sunucu_kur_test.sh bulunamadı (bu betikle aynı klasörde olmalı): $runner"
}

# --- 2) zip'i bul ----------------------------------------------------------
if (-not $Zip) {
  $klasorler = @(
    (Join-Path $HOME "Downloads"),
    (Join-Path $HOME "Desktop"),
    (Join-Path $HOME "OneDrive\Desktop"),
    $HOME,
    (Get-Location).Path
  ) | Where-Object { Test-Path $_ } | Select-Object -Unique

  $adaylar = @()
  foreach ($k in $klasorler) {
    $adaylar += Get-ChildItem -Path $k -Filter "project-*.zip" -File -ErrorAction SilentlyContinue
  }
  if ($adaylar.Count -eq 0) {
    Fail "zip bulunamadı. -Zip 'tam\yol\project-15025408.zip' ver."
  }
  $Zip = ($adaylar | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
}
if (-not (Test-Path $Zip)) { Fail "zip bulunamadı: $Zip" }

$zipItem = Get-Item $Zip
$zipMb = [math]::Round($zipItem.Length / 1MB, 2)

# --- 3) ssh / scp var mı ---------------------------------------------------
foreach ($exe in @("ssh", "scp")) {
  if (-not (Get-Command $exe -ErrorAction SilentlyContinue)) {
    Fail "$exe bulunamadı. Windows Ayarlar > Uygulamalar > İsteğe bağlı özellikler > OpenSSH Client kur."
  }
}

# --- 4) zip İÇERİK ön kontrolü (boşa tur atmasın) --------------------------
Add-Type -AssemblyName System.IO.Compression.FileSystem

$gerekli = @(
  'supabase/functions/auth-log/index.ts',
  'supabase/functions/accept-invite/index.ts',
  'supabase/functions/send-reset-email/index.ts',
  'supabase/migrations/20260101003100_guv43_service_role_truncate_revoke.sql',
  'deploy/scripts/24_guv43_service_role_truncate.sh',
  'deploy/scripts/14_fk_guv39_guv32_deploy.sh',
  'deploy/scripts/27_bulgu_03_07_dogrula.sh'
)

$entryAdlari = @()
try {
  $zipRef = [System.IO.Compression.ZipFile]::OpenRead($zipItem.FullName)
  $entryAdlari = @($zipRef.Entries | ForEach-Object { $_.FullName -replace '\\', '/' })
  $zipRef.Dispose()
} catch {
  Fail "zip okunamadı: $($_.Exception.Message)"
}

$eksik = @()
foreach ($g in $gerekli) {
  if (-not ($entryAdlari | Where-Object { $_ -like "*$g" })) { $eksik += $g }
}
if ($eksik.Count -gt 0) {
  Write-Host ""
  Write-Host "!! ZIP ESKI / EKSIK — su dosyalar arsivde YOK:" -ForegroundColor Red
  $eksik | ForEach-Object { Write-Host "   - $_" -ForegroundColor Red }
  Write-Host ""
  Uyari "Readdy -> Code sekmesinden YENI zip indirip tekrar dene."
  exit 2
}

$target = "$SshUser@$SshHost"
$sshOpt = @(
  "-o", "ServerAliveInterval=30",
  "-o", "ServerAliveCountMax=3",
  "-o", "StrictHostKeyChecking=accept-new",
  "-p", "$Port"
)

Write-Host ""
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor DarkGray
Write-Host "  ZIP kurulumu + doğrulama" -ForegroundColor White
Write-Host "  zip     : $Zip" -ForegroundColor White
Write-Host "  boyut   : $zipMb MB" -ForegroundColor White
Write-Host "  sunucu  : $target (port $Port)" -ForegroundColor White
Write-Host "  uzak    : $RemoteDir" -ForegroundColor White
Write-Host "════════════════════════════════════════════════════════════" -ForegroundColor DarkGray
Iyi "zip içeriği doğrulandı (fonksiyonlar + GUV-43 + 14 + 27 var)."

# --- 5) kopyala ------------------------------------------------------------
Baslik "1/3 · zip sunucuya kopyalanıyor (sunucu parolası sorulacak)"
& scp -o ServerAliveInterval=30 -o StrictHostKeyChecking=accept-new -P $Port $zipItem.FullName "${target}:${RemoteZip}"
if ($LASTEXITCODE -ne 0) { Fail "zip kopyalanamadı (scp çıkış kodu $LASTEXITCODE)." }
Iyi "zip yüklendi: $RemoteZip"

Baslik "2/3 · sunucu betiği kopyalanıyor"
& scp -o ServerAliveInterval=30 -o StrictHostKeyChecking=accept-new -P $Port $runner "${target}:/root/isg_kur_test.sh"
if ($LASTEXITCODE -ne 0) { Fail "betik kopyalanamadı." }
Iyi "betik yüklendi: /root/isg_kur_test.sh"

if ($SadeceKur) {
  Write-Host ""
  Iyi "Sadece kurulum istendi. Sunucuda açmak için:"
  Write-Host "  ssh -p $Port $target" -ForegroundColor Yellow
  Write-Host "  EGRESS=$(if ($EgressYok) { '0' } else { '1' }) bash /root/isg_kur_test.sh '$RemoteZip' '$RemoteDir'" -ForegroundColor Yellow
  exit 0
}

# --- 6) sunucuda koş -------------------------------------------------------
Baslik "3/3 · Sunucuda kurulum + testler koşuluyor"
Write-Host "   (14 tablo kilidi alır, 19 pgTAP 10-15 dk sürebilir — ekranı kapatma)" -ForegroundColor Gray

$egress = if ($EgressYok) { "0" } else { "1" }
$uzakKomut = "EGRESS=$egress bash /root/isg_kur_test.sh '$RemoteZip' '$RemoteDir'"
& ssh @sshOpt $target $uzakKomut
$rc = $LASTEXITCODE

Write-Host ""
if ($rc -eq 0) { Iyi "sunucu tarafı tamamlandı (çıkış kodu 0)." }
elseif ($rc -eq 2) { Uyari "zip eksik/uyumsuz görünüyor — yukarıdaki çıktıya bak." }
else { Uyari "sunucu tarafı çıkış kodu: $rc — yukarıdaki çıktıya bak." }

Write-Host ""
Write-Host "SIRADA: 16 · e-posta kodlu şifre değişimi testi (elle, kod girilecek)" -ForegroundColor Cyan
Write-Host "  ssh -p $Port $target" -ForegroundColor Yellow
Write-Host "  bash $RemoteDir/deploy/scripts/16_ui_sifre_kodu_akisi_test.sh" -ForegroundColor Yellow
Write-Host ""
Write-Host "Kanıt paketini indirmek için:" -ForegroundColor Gray
Write-Host "  scp -P $Port -r ${target}:/root/pentest-kanit-* ." -ForegroundColor Yellow
Write-Host "  scp -P $Port ${target}:/root/isg-kur-test-*.log ." -ForegroundColor Yellow
Write-Host ""
exit $rc