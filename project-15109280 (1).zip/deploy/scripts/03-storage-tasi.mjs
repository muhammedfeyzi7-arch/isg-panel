// ─────────────────────────────────────────────────────────────────────────────
// Storage Taşıma: Kaynak Supabase Storage -> Hedef (self-host) Storage
//
// Ön koşul: hedef bucket'lar DB taşımasıyla gelir (storage.buckets).
// Bağımlılık: npm install @supabase/supabase-js ws
//
// Ortam değişkenleri:
//   SRC_URL, SRC_SERVICE_KEY   -> kaynak proje
//   TGT_URL, TGT_SERVICE_KEY   -> hedef (self-host) proje
//   BUCKETS                    -> virgülle ayrılmış bucket adları (varsayılan: public,private)
// ─────────────────────────────────────────────────────────────────────────────
import { createClient } from '@supabase/supabase-js';

// ─────────────────────────────────────────────────────────────────────────────
// Node.js 20 native WebSocket içermez. Storage taşıma realtime kullanmasa da
// createClient içindeki realtime-js başlatılırken WebSocket arar ve yoksa hata
// fırlatır ("Node.js 20 detected without native WebSocket support").
// Burada "ws" paketini global WebSocket olarak verip o çökmeyi engelliyoruz.
// (Kurulum: npm install ws)
// ─────────────────────────────────────────────────────────────────────────────
if (typeof globalThis.WebSocket === 'undefined') {
  try {
    const { WebSocket } = await import('ws');
    globalThis.WebSocket = WebSocket;
  } catch {
    console.error(
      'WebSocket saglanamadi. Node 20 icin lutfen once "npm install ws" calistirin.',
    );
    process.exit(1);
  }
}

const SRC_URL = process.env.SRC_URL;
const SRC_KEY = process.env.SRC_SERVICE_KEY;
const TGT_URL = process.env.TGT_URL;
const TGT_KEY = process.env.TGT_SERVICE_KEY;
const BUCKETS = (process.env.BUCKETS || 'public,private')
  .split(',')
  .map((s) => s.trim())
  .filter(Boolean);

if (!SRC_URL || !SRC_KEY || !TGT_URL || !TGT_KEY) {
  console.error('Eksik ortam degiskeni. Gerekli: SRC_URL, SRC_SERVICE_KEY, TGT_URL, TGT_SERVICE_KEY');
  process.exit(1);
}

// Anahtarlar JWT olmali (eyJ...). Placeholder metin ("...BURAYA") veya yeni
// "sb_secret_..." formatli anahtarlar Storage API'de "Invalid Compact JWS"
// hatasi verir. Burada erkenden net bir mesajla duruyoruz.
for (const [label, val] of [
  ['SRC_SERVICE_KEY', SRC_KEY],
  ['TGT_SERVICE_KEY', TGT_KEY],
]) {
  const s = String(val);
  if (!s.startsWith('eyJ')) {
    console.error(
      `${label} gecerli bir JWT gorunmuyor (deger: "${s.slice(0, 12)}...").`,
    );
    console.error(
      'Supabase Dashboard -> Project Settings -> API -> service_role anahtarini kullan (eyJ ile baslar).',
    );
    process.exit(1);
  }
  const parts = s.split('.');
  if (parts.length !== 3 || s.length < 100) {
    console.error(
      `${label} gercek bir JWT'ye benzemiyor (parca: ${parts.length}, uzunluk: ${s.length}).`,
    );
    console.error(
      'Gercek service_role anahtari 200+ karakter ve noktayla ayrilmis 3 parcadan olusur (eyJ...). Yer tutucu/eksik metin kullanmayin.',
    );
    process.exit(1);
  }
}

// Kaynak ve hedef anahtar ayni olamaz. Cok sik yapilan hata: hedefin (self-host)
// anahtarini yanlislikla SRC_SERVICE_KEY'e koymak. Bu durumda Storage API
// "signature verification failed" verir. Burada erken ve net duruyoruz.
if (String(SRC_KEY) === String(TGT_KEY)) {
  console.error(
    'SRC_SERVICE_KEY ile TGT_SERVICE_KEY ayni. Kaynak (SaaS) ve hedef (self-host) anahtarlari farkli olmali.',
  );
  console.error(
    'SRC_SERVICE_KEY gercek KAYNAK projenin service_role anahtari olmali; hedef anahtari orada kullanmayin.',
  );
  process.exit(1);
}

// HTTP header degerleri yalnizca Latin-1 (0-255) kabul eder. Anahtar/URL icine
// yanlislikla Turkce karakter karisirsa (or. noktasiz "i", U+0131 = 305) fetch
// "Cannot convert argument to a ByteString..." hatasi verir. Burada erkenden,
// hangi degiskende kacinci karakterde oldugunu soyleyip net duruyoruz.
function assertLatin1(label, val) {
  const s = String(val);
  for (let i = 0; i < s.length; i += 1) {
    const code = s.charCodeAt(i);
    if (code > 255) {
      const hex = code.toString(16).toUpperCase().padStart(4, '0');
      console.error(`${label} gecersiz karakter iceriyor: index ${i} ("${s[i]}", U+${hex}).`);
      console.error(
        'Anahtar/URL yalnizca ASCII olmali (Turkce karakter karismis olabilir; anahtari duz metin olarak yeniden alin).',
      );
      process.exit(1);
    }
  }
}
for (const [label, val] of [
  ['SRC_URL', SRC_URL],
  ['SRC_SERVICE_KEY', SRC_KEY],
  ['TGT_URL', TGT_URL],
  ['TGT_SERVICE_KEY', TGT_KEY],
]) {
  assertLatin1(label, val);
}

const src = createClient(SRC_URL, SRC_KEY, { auth: { persistSession: false } });
const tgt = createClient(TGT_URL, TGT_KEY, { auth: { persistSession: false } });

async function listAll(bucket, prefix = '') {
  const out = [];
  const limit = 100;
  let offset = 0;
  for (;;) {
    const { data, error } = await src.storage.from(bucket).list(prefix, { limit, offset });
    if (error) throw error;
    if (!data || data.length === 0) break;
    for (const item of data) {
      const path = prefix ? `${prefix}/${item.name}` : item.name;
      if (item.id === null) {
        out.push(...(await listAll(bucket, path))); // klasör
      } else {
        out.push(path);
      }
    }
    if (data.length < limit) break;
    offset += limit;
  }
  return out;
}

for (const bucket of BUCKETS) {
  console.log(`==> Bucket: ${bucket}`);
  let files;
  try {
    files = await listAll(bucket);
  } catch (e) {
    console.warn(`    ! ${bucket} listelenemedi (atlandi): ${e.message}`);
    continue;
  }
  console.log(`    ${files.length} dosya bulundu.`);
  let ok = 0;
  for (const path of files) {
    const { data: blob, error: dErr } = await src.storage.from(bucket).download(path);
    if (dErr) {
      console.warn(`    x indirilemedi: ${path} (${dErr.message})`);
      continue;
    }
    const { error: uErr } = await tgt.storage.from(bucket).upload(path, blob, {
      upsert: true,
      contentType: blob.type || 'application/octet-stream',
    });
    if (uErr) {
      console.warn(`    x yuklenemedi: ${path} (${uErr.message})`);
      continue;
    }
    ok++;
  }
  console.log(`    ${ok}/${files.length} dosya kopyalandi.`);
}

console.log('TAMAM.');