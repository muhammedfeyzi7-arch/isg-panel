# ═══════════════════════════════════════════════════════════════════════════
# 34d · SSH OLMADAN MIGRATION İZİ + BAŞLIK + SELF-SIGNUP KONTROLÜ
#
# Ne yapar:  Migration'ların canlıya uygulanıp uygulanmadığını, HTTP güvenlik
#            başlıklarını ve self-signup kapalı mı diye SADECE API üzerinden
#            yoklar. Hiçbir şeyi DEĞİŞTİRMEZ (salt okuma).
#
# Mantık:    Bir migration tablo/fonksiyon yarattıysa, o nesne REST şemasında
#            görünür:
#              404 + PGRST205 → nesne YOK  → migration UYGULANMAMIŞ
#              401 / 403 + 42501 → nesne VAR, anon yetkisiz → UYGULANMIŞ
#              200            → nesne VAR ve okunabilir  → UYGULANMIŞ
#
# Kullanım:  powershell -ExecutionPolicy Bypass -File .\deploy\scripts\34d_api_migration_probe.ps1
# ═══════════════════════════════════════════════════════════════════════════

$ErrorActionPreference = 'Continue'
$Base = 'https://api.isgdenetim.com.tr'
$Stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$OutDir = Join-Path $PSScriptRoot 'out'
if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }
$OutFile = Join-Path $OutDir "api-migration-probe-$Stamp.txt"

$log = New-Object System.Collections.Generic.List[string]
function Say($t) { $log.Add($t); Write-Host $t }

# ── 1) Anon anahtarını .env dosyasından oku ────────────────────────────────
$envCandidates = @(
  (Join-Path $PSScriptRoot '..\..\.env'),
  (Join-Path $PSScriptRoot '..\.env'),
  (Join-Path (Get-Location) '.env')
)
$envPath = $envCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $envPath) {
  Write-Host '!! .env bulunamadi. Proje kokunde calistir: .\deploy\scripts\34d_api_migration_probe.ps1' -ForegroundColor Red
  exit 1
}

$anonLine = Select-String -Path $envPath -Pattern 'VITE_PUBLIC_SUPABASE_ANON_KEY\s*=\s*"?([^"\r\n]+)"?' | Select-Object -First 1
if (-not $anonLine) {
  Write-Host '!! .env icinde VITE_PUBLIC_SUPABASE_ANON_KEY yok.' -ForegroundColor Red
  exit 1
}
$Anon = $anonLine.Matches[0].Groups[1].Value.Trim()

Say '════════════════════════════════════════════════════════════'
Say "34d · API MIGRATION PROBE · $Stamp"
Say "Kaynak .env : $envPath"
Say "Anon anahtar: $($Anon.Substring(0, [Math]::Min(12, $Anon.Length)))... (uzunluk $($Anon.Length))"
Say '════════════════════════════════════════════════════════════'

if ($Anon.Length -lt 100) {
  Write-Host '!! Anahtar cok kisa gorunuyor, .env satirini kontrol et.' -ForegroundColor Yellow
}

# ── 2) Tablo / nesne izleri ───────────────────────────────────────────────
$Targets = @(
  @{ Ad = 'password_history (guv40)';        Yol = 'password_history?select=id&limit=1' },
  @{ Ad = 'sifre_dogrulama_kodlari (guv41)'; Yol = 'sifre_dogrulama_kodlari?select=id&limit=1' },
  @{ Ad = 'server_security_events (srv01)';  Yol = 'server_security_events?select=id&limit=1' },
  @{ Ad = 'app_settings (varsa)';            Yol = 'app_settings?select=key&limit=1' },
  @{ Ad = 'profiles (kontrol)';              Yol = 'profiles?select=id&limit=1' },
  @{ Ad = 'firmalar (kontrol)';              Yol = 'firmalar?select=id&limit=1' }
)

Say ''
Say '── NESNE İZLERİ ──────────────────────────────────────────────'
$probe = @{}
foreach ($t in $Targets) {
  $url = "$Base/rest/v1/$($t.Yol)"
  $code = (& curl.exe -s -o NUL -w '%{http_code}' $url -H "apikey: $Anon") 2>$null
  $body = ''
  if ($code -eq '404' -or $code -eq '400') {
    $body = (& curl.exe -s $url -H "apikey: $Anon") 2>$null
    if ($body) { $body = ($body -join ' '); if ($body.Length -gt 160) { $body = $body.Substring(0, 160) } }
  }
  $probe[$t.Ad] = $code
  $say = '{0,-36} HTTP {1,-4} {2}' -f $t.Ad, $code, $body
  Say $say
}

# ── 3) HTTP güvenlik başlıkları + maskeleme vekili ────────────────────────
Say ''
Say '── HTTP BAŞLIKLARI (BULGU-05 / D6) ────────────────────────────'
$headers = (& curl.exe -s -D - -o NUL "$Base/rest/v1/" -H "apikey: $Anon") 2>$null
$hText = ($headers -join "`n")
$checks = @(
  @{ Ad = 'x-pgrest-mask';          Var = 'maskeleme vekili AKTİF' },
  @{ Ad = 'strict-transport';       Var = 'HSTS' },
  @{ Ad = 'x-content-type-options'; Var = 'nosniff' },
  @{ Ad = 'x-frame-options';        Var = 'frame koruması' },
  @{ Ad = 'content-security-policy'; Var = 'CSP' }
)
foreach ($c in $checks) {
  if ($hText -match [regex]::Escape($c.Ad)) {
    Say ('{0,-28} VAR    ({1})' -f $c.Var, $c.Ad)
  } else {
    Say ('{0,-28} YOK    ({1})' -f $c.Var, $c.Ad)
  }
}

# ── 4) Self-signup ────────────────────────────────────────────────────────
Say ''
Say '── AUTH / SELF-SIGNUP (GUV-02 · D3) ──────────────────────────'
$settings = (& curl.exe -s "$Base/auth/v1/settings" -H "apikey: $Anon") 2>$null
$sText = ($settings -join '')
if (-not $sText) {
  Say 'ayarlar alinamadi (bos yanit)'
} else {
  $m = [regex]::Match($sText, '"disable_signup"\s*:\s*(true|false)')
  if ($m.Success) {
    Say "disable_signup = $($m.Groups[1].Value)"
  } else {
    Say 'disable_signup alani yanitta yok'
    if ($sText.Length -gt 300) { $sText = $sText.Substring(0, 300) }
    Say "ham yanit: $sText"
  }
}

# ── 5) Karar ──────────────────────────────────────────────────────────────
Say ''
Say '── KARAR ─────────────────────────────────────────────────────'

$ph = $probe['password_history (guv40)']
$sk = $probe['sifre_dogrulama_kodlari (guv41)']

if ($ph -eq '404') {
  Say 'SONUC: password_history YOK → guv40 ve sonrasi UYGULANMAMIS.'
  Say '       SECURITY_REMAINING_ISSUES.md BAYAT DEGIL. Gercek is var.'
} elseif ($ph -eq '401' -or $ph -eq '403' -or $ph -eq '200') {
  Say 'SONUC: password_history VAR → migration zinciri uygulanmis.'
  Say '       SECURITY_REMAINING_ISSUES.md BAYAT → arsive tasinmali.'
} else {
  Say "SONUC: belirsiz (HTTP $ph). Anahtar gecersiz olabilir, tekrar dene."
}

Say ''
Say "Rapor dosyasi: $OutFile"
$log | Out-File -FilePath $OutFile -Encoding utf8