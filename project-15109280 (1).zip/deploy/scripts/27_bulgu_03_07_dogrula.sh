#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# 27_bulgu_03_07_dogrula.sh
#
# PENTEST 2. RAPOR · BULGU-03 (gövde boyutu) ve BULGU-07 (accept-invite limit)
# için canlı doğrulama. Kod değişikliği YAPMAZ, yalnızca ölçer.
#
# Kullanım:
#   export API_BASE="https://api.isgdenetim.com.tr"
#   export ANON_KEY="<anon key>"
#   bash deploy/scripts/27_bulgu_03_07_dogrula.sh
#
# Beklenen sonuçlar:
#   TEST 1  → HTTP 413 (PAYLOAD_TOO_LARGE)   [BULGU-03 kapalı]
#   TEST 2  → 10 istek geçerli cevap, sonrası INVALID (ayırt edilemez) [BULGU-07]
#   TEST 3  → IP limiti devreye girer, 20 istekten sonra INVALID
# ─────────────────────────────────────────────────────────────────────────────
set -uo pipefail

API_BASE="${API_BASE:-https://api.isgdenetim.com.tr}"
ANON_KEY="${ANON_KEY:-}"

if [[ -z "$ANON_KEY" ]]; then
  echo "HATA: ANON_KEY tanımlı değil. Önce: export ANON_KEY='...'"
  exit 1
fi

pass=0
fail=0
ok()   { echo "  PASS  $1"; pass=$((pass + 1)); }
nok()  { echo "  FAIL  $1"; fail=$((fail + 1)); }

post() {
  local url="$1"; local data="$2"
  curl -sS -o /tmp/b27_body.txt -w '%{http_code}' \
    -X POST "$url" \
    -H "apikey: ${ANON_KEY}" \
    -H "Authorization: Bearer ${ANON_KEY}" \
    -H 'Content-Type: application/json' \
    --data-binary "$data"
}

echo "== TEST 1 · BULGU-03 · 40 MB gövde reddi =="
# 40 MB JSON gövdesi: python varsa python, yoksa coreutils (dd/tr) ile üretilir.
if command -v python3 >/dev/null 2>&1; then
  python3 - <<'PY' > /tmp/b27_big.json
import json
print(json.dumps({"event_type": "AUTH_LOGIN_FAILED", "description": "A" * 40_000_000}))
PY
else
  { printf '{"event_type":"AUTH_LOGIN_FAILED","description":"'; \
    head -c 40000000 /dev/zero | tr '\0' 'A'; \
    printf '"}'; } > /tmp/b27_big.json
fi
echo "   gövde boyutu: $(du -h /tmp/b27_big.json | cut -f1)"

code=$(post "${API_BASE}/functions/v1/auth-log" "@/tmp/b27_big.json")
if [[ "$code" == "413" ]]; then
  ok "auth-log büyük gövdeyi 413 ile reddetti"
else
  nok "auth-log beklenen 413, gelen ${code}  → platform max_body_size hâlâ açık olabilir"
fi

code=$(post "${API_BASE}/functions/v1/send-reset-email" "@/tmp/b27_big.json")
if [[ "$code" == "413" ]]; then
  ok "send-reset-email büyük gövdeyi 413 ile reddetti"
else
  nok "send-reset-email beklenen 413, gelen ${code}"
fi

code=$(post "${API_BASE}/functions/v1/accept-invite" "@/tmp/b27_big.json")
if [[ "$code" == "413" ]]; then
  ok "accept-invite büyük gövdeyi 413 ile reddetti"
else
  nok "accept-invite beklenen 413, gelen ${code}"
fi

echo
echo "== TEST 2 · BULGU-07 · Aynı token ile 12 deneme (limit 10/5dk) =="
FAKE="b27selftest-$(date +%s)-$RANDOM"
limited=0
for i in $(seq 1 12); do
  code=$(post "${API_BASE}/functions/v1/accept-invite" \
    "{\"mode\":\"validate\",\"token\":\"${FAKE}\"}")
  body=$(cat /tmp/b27_body.txt)
  echo "   #$(printf '%02d' "$i")  HTTP ${code}  ${body:0:80}"
  # 11. ve 12. istekte de yanıt "INVALID" olmalı (rate limit ayrı sinyal vermez)
  if [[ "$i" -ge 11 && "$body" == *"INVALID"* ]]; then limited=$((limited + 1)); fi
done
if [[ "$limited" -ge 1 ]]; then
  ok "token limiti devreye girdi (ayırt edici sinyal yok)"
else
  nok "token limiti görülmedi — fonksiyon yeniden deploy edildi mi?"
fi

echo
echo "== TEST 3 · BULGU-07 · IP başına 24 farklı token (limit 20/5dk) =="
ipLimited=0
for i in $(seq 1 24); do
  code=$(post "${API_BASE}/functions/v1/accept-invite" \
    "{\"mode\":\"validate\",\"token\":\"b27ip-$(date +%s)-${i}-$RANDOM\"}")
  body=$(cat /tmp/b27_body.txt)
  if [[ "$i" -ge 22 && "$body" == *"INVALID"* ]]; then ipLimited=$((ipLimited + 1)); fi
done
if [[ "$ipLimited" -ge 1 ]]; then
  ok "IP limiti devreye girdi"
else
  nok "IP limiti görülmedi (Cloudflare/proxy arkasında X-Forwarded-For farklı düşüyor olabilir)"
fi

echo
echo "──────────────────────────────"
echo "SONUÇ: PASS=${pass}  FAIL=${fail}"
if [[ "$fail" -eq 0 ]]; then
  echo "BULGU-03 ve BULGU-07 kod tarafında KAPALI."
  echo "Not: \$FAKE token 5 dakika boyunca limitli kalır; bu normaldir."
  exit 0
fi
echo "Eksik kalan var — yukarıdaki FAIL satırlarına bak."
exit 1