#!/usr/bin/env bash
# =============================================================================
# 16 · ŞİFRE DEĞİŞTİRME E-POSTA KODU AKIŞI — UÇTAN UCA TEST
# =============================================================================
# Neyi kanıtlıyor (raporda tek tek işaretlenecek):
#   T1  Yanlış mevcut şifre ile kod istenemiyor          → CURRENT_PASSWORD_INVALID
#   T2  Doğru mevcut şifre ile kod gönderiliyor          → ok:true
#   T3  Zayıf yeni şifre kod TÜKETMEDEN reddediliyor     → PASSWORD_TOO_SHORT
#   T4  Hatalı kod reddediliyor                          → CODE_INVALID
#   T5  Doğru kod ile şifre değişiyor + diğer oturumlar kapanıyor → ok:true
#   T6  Aynı kod ikinci kez kullanılamıyor                → CODE_INVALID
#   T7  Eski şifre artık çalışmıyor (login fail)
#   T8  Yeni şifre çalışıyor (login ok)
#   T9  Yeni kod istendiğinde önceki kod GEÇERSİZ oluyor   → CODE_INVALID
#       (mail sayısı: 3 · toplam süre: ~5 dk)
#
# Kullanım:
#   bash 16_ui_sifre_kodu_akisi_test.sh
#
# ⚠️ Bu betik GERÇEK bir hesabın şifresini değiştirir. Test hesabı kullanın.
# ⚠️ Rate limit: kod isteği kullanıcı başına 15 dakikada 5. Test 4 istiyor.
#    Aynı 15 dakika içinde tekrar koşarsanız RATE_LIMITED alırsınız — bekleyin.
# =============================================================================
set -uo pipefail

SUPABASE_DIR="${SUPABASE_DIR:-/opt/ibys/supabase/docker}"
API="${API:-http://127.0.0.1:8000}"
CIKTI_DIR="${CIKTI_DIR:-/root/pentest-kanit}"
ZAMAN="$(date +%Y%m%d-%H%M%S)"
LOG="$CIKTI_DIR/sifre_akisi_$ZAMAN.log"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
info()  { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn()  { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
fail()  { printf '%s\n' "${c_red}✗${c_rst} $*"; }
pass()  { printf '%s\n' "${c_grn}✓${c_rst} $*"; }

mkdir -p "$CIKTI_DIR"
PASS_N=0; FAIL_N=0

logla() { printf '%s\n' "$*" >> "$LOG"; }

# Özet satırı tek bir yerde ve TEK KEZ yazılır. Betik herhangi bir sebepten
# erken bitse bile (rate limit, boş kod, mail gelmedi...) log dosyasında
# "SONUÇ:" satırı bulunur; 19 bu satırı okuyup kalemi PASS/KALDI işaretler.
OZET_YAZILDI=0
ozet_yaz() {
  local neden="${1:-tamamlandi}"
  [[ "$OZET_YAZILDI" = "1" ]] && return 0
  OZET_YAZILDI=1
  logla "=== SONUÇ: PASS=${PASS_N} FAIL=${FAIL_N} · yeni sifre=${P1:-bilinmiyor} · durum=${neden} ==="
}
trap 'ozet_yaz "betik erken sonlandi (exit)"' EXIT

# ── Bağımlılıklar ────────────────────────────────────────────────────────────
command -v curl >/dev/null 2>&1 || { echo "curl gerekli"; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "python3 gerekli"; exit 1; }
[[ -f "$SUPABASE_DIR/.env" ]] || { echo ".env bulunamadı: $SUPABASE_DIR/.env"; exit 1; }

ANON_KEY="$(grep -hE '^ANON_KEY=' "$SUPABASE_DIR/.env" | tail -1 | cut -d= -f2- | tr -d '"')"
[[ -n "$ANON_KEY" ]] || { echo "ANON_KEY okunamadı"; exit 1; }
FN_URL="$API/functions/v1/sifre-dogrulama"

# SERVICE_ROLE_KEY yalnız T0 öncesi "hesap var mı / onaylı mı / banlı mı"
# kontrolü için kullanılır. Değeri hiçbir yere yazılmaz, ekrana basılmaz.
SR_KEY="$(grep -hE '^SERVICE_ROLE_KEY=' "$SUPABASE_DIR/.env" | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'" | tr -d '\r')"

# hesap_kontrol <email> -> "id|email_onayli|banli|app_role" veya boş satır
hesap_kontrol() {
  local email="$1"
  [[ -n "${SR_KEY:-}" ]] || { printf '%s' ''; return 0; }
  curl -sS -m 25 "$API/auth/v1/admin/users?page=1&per_page=1000" \
    -H "apikey: $SR_KEY" -H "Authorization: Bearer $SR_KEY" 2>/dev/null \
  | python3 -c '
import json, sys
email = sys.argv[1].strip().lower()
try:
    d = json.load(sys.stdin)
except Exception:
    print("")
    sys.exit(0)
users = d.get("users", d) if isinstance(d, dict) else d
for u in users or []:
    if (u.get("email") or "").strip().lower() == email:
        conf = "1" if (u.get("email_confirmed_at") or u.get("confirmed_at")) else "0"
        banned = "1" if u.get("banned_until") else "0"
        role = ((u.get("app_metadata") or {}).get("role")) or ""
        print("%s|%s|%s|%s" % (u.get("id", ""), conf, banned, role))
        break
else:
    print("")
' "$email"
}

jget() { # jget <json> <alan>
  printf '%s' "$1" | python3 -c "
import json,sys
try:
    d = json.load(sys.stdin)
except Exception:
    print(''); sys.exit(0)
v = d
for k in sys.argv[1].split('.'):
    if isinstance(v, dict): v = v.get(k)
    else: v = None
print('' if v is None else v)
" "$2"
}

login() { # login <email> <sifre>
  curl -sS -m 25 -X POST "$API/auth/v1/token?grant_type=password" \
    -H "apikey: $ANON_KEY" -H 'Content-Type: application/json' \
    -d "{\"email\":\"$1\",\"password\":\"$2\"}"
}

api() { # api <token> <json-govde>
  curl -sS -m 40 -X POST "$FN_URL" \
    -H "apikey: $ANON_KEY" -H "Authorization: Bearer $1" \
    -H 'Content-Type: application/json' -d "$2"
}

bekle() { # bekle <etiket> <beklenen|alternatif> <json>   (beklenen "|" ile çoklu olabilir)
  local etiket="$1" beklenen="$2" json="$3" gelen alt
  gelen="$(jget "$json" code)"
  if [[ -z "$gelen" ]] && [[ "$(jget "$json" ok)" = "True" || "$(jget "$json" ok)" = "true" ]]; then
    gelen="ok"
  fi
  logla "[$etiket] beklenen=$beklenen gelen=$gelen :: $json"
  local IFS='|'
  for alt in $beklenen; do
    if [[ "$gelen" = "$alt" ]]; then
      pass "$etiket → $gelen"
      PASS_N=$((PASS_N + 1))
      return 0
    fi
  done
  fail "$etiket → beklenen '$beklenen', gelen '$gelen'"
  printf '  %s\n' "${c_dim}$json${c_rst}"
  FAIL_N=$((FAIL_N + 1))
  return 1
}

sor() { # sor <degisken-adi> <metin>
  local __var="$1" __msg="$2" __val=""
  printf '%s' "$__msg"
  read -r __val
  printf -v "$__var" '%s' "$__val"
}

# ── Girdi ────────────────────────────────────────────────────────────────────
cat <<EOF

════════════════════════════════════════════════════════════════
  Şifre değiştirme e-posta kodu — uçtan uca test
  API     : $API
  Log     : $LOG
  Mail    : 3 adet doğrulama e-postası gönderilecek
════════════════════════════════════════════════════════════════

EOF

sor EMAIL "Test hesabının e-postası       : "
[[ -n "$EMAIL" ]] || { echo "E-posta zorunlu."; exit 1; }

# ── Uyarı: gerçek posta kutusu OLMAYAN alan adları ───────────────────────────
# .test / .invalid / .local / example.com → RFC 2606 ayrılmıştır, MX kaydı yoktur.
# Resend API yine 200 döner (kod üretilir, DB'ye yazılır) ama mail BOUNCE olur.
# Yani kullanıcı "Kod 1:" ekranında kalır; kod DB'de yalnızca SHA-256 özeti
# olarak tutulduğu için oradan da okunamaz.
case "${EMAIL,,}" in
  *.test|*.invalid|*.local|*.example|*@example.com|*@localhost)
    warn "DİKKAT: '$EMAIL' gerçek bir posta kutusuna ait DEĞİL (ayrılmış alan adı)."
    warn "Bu adrese gönderilen kod tarafınıza ULAŞMAZ (Resend 'ok' dese bile bounce olur)."
    echo "    İki çözüm:"
    echo "      1) Kodları Resend panelinden okuyun: Resend → Emails → en son mail → gövdedeki 6 hane"
    echo "         (mail gönderilmiş sayılır, içeriği panelde görünür)"
    echo "      2) ÖNERİLEN: gerçek kutusuna eriştiğiniz ayrı bir test hesabı kullanın."
    echo "         Şifresini bilinen hale getirip girişi doğrulayın:"
    echo "         bash deploy/scripts/25_pentest_hesap_sifre_yenile.sh <gercek-test-epostasi>"
    printf '  %s' "Devam edilsin mi? [e/H]: "
    read -r DEVAM
    case "${DEVAM,,}" in
      e|evet|y|yes) logla "[UYARI] teslim edilemeyen alan adi :: $EMAIL" ;;
      *) warn "İptal edildi. Yukarıdaki 2. seçenekle tekrar koşun."; ozet_yaz "teslim edilemeyen eposta"; exit 3 ;;
    esac
    ;;
esac

# ── Uyarı: tüketici posta kutuları (Outlook/Gmail/Hotmail...) ────────────────
# Bu alan adları GERÇEK kutudur, mail gider; ancak ilk gönderimde spam'e
# düşme ihtimali yüksektir. Kod isteme ekranında bunu hatırlatalım.
case "${EMAIL,,}" in
  *@outlook.com|*@hotmail.com|*@live.com|*@gmail.com|*@yahoo.com|*@icloud.com|*@yandex.com|*@yandex.ru)
    warn "Not: kod 'İstenmeyen E-posta' / 'Spam' / 'Junk' klasörüne düşebilir."
    warn "Mail gelmezse önce oraya bakın, sonra Resend → Emails → son gönderim."
    logla "[NOT] tuketici posta kutusu :: $EMAIL (spam kontrolu hatirlatildi)"
    ;;
esac

# ── Ön kontrol: hesap gerçekten var mı? (şifre sormadan önce) ────────────────
HESAP="$(hesap_kontrol "$EMAIL")"
if [[ -n "$HESAP" ]]; then
  IFS='|' read -r H_ID H_CONF H_BAN H_ROLE <<< "$HESAP"
  printf '  %s\n' "${c_dim}hesap bulundu: id=${H_ID:0:8}…  rol=${H_ROLE:-yok}  e-posta onaylı=${H_CONF}  banlı=${H_BAN}${c_rst}"
  logla "[ONKONTROL] hesap bulundu id=$H_ID role=$H_ROLE confirmed=$H_CONF banned=$H_BAN"
  [[ "$H_CONF" = "0" ]] && warn "E-posta ONAYSIZ görünüyor — giriş 'email_not_confirmed' verebilir (25 betiği onaylar)."
  [[ "$H_BAN" = "1" ]] && warn "Hesap BANLI görünüyor — giriş yapılamaz."
else
  if [[ -n "${SR_KEY:-}" ]]; then
    fail "Bu e-posta auth.users içinde YOK: $EMAIL"
    warn "Hesap açmak için: ONAY=1 bash supabase/tests/security/pentest_gunu/08_test_hesaplari_olustur.sh"
    warn "Var olan bir hesabı kullanacaksanız: bash deploy/scripts/25_pentest_hesap_sifre_yenile.sh <eposta>"
    logla "[ONKONTROL] hesap YOK :: $EMAIL"
    ozet_yaz "hesap bulunamadi"
    exit 2
  fi
  warn "Hesap ön kontrolü yapılamadı (SERVICE_ROLE_KEY yok) — giriş denemesiyle devam ediliyor."
fi

sor P0    "Hesabın MEVCUT şifresi        : "
[[ -n "$P0" ]] || { echo "Şifre zorunlu."; exit 1; }

TS="$(date +%s)"
P1="Retest.${TS}.Aa9"
P2="Ikinci.${TS}.Bb9"
logla "=== TEST $ZAMAN · email=$EMAIL · P1=$P1 (P2 yalnız T9 için) ==="

printf '\n%s\n' "Test şifreleri (kaydedin):"
printf '  yeni şifre (P1) : %s\n' "$P1"
printf '  ikinci (P2)     : %s\n\n' "$P2"

# ── T0: giriş ────────────────────────────────────────────────────────────────
info "T0 · Mevcut şifre ile giriş"
RESP="$(login "$EMAIL" "$P0")"
TOKEN="$(jget "$RESP" access_token)"
if [[ -z "$TOKEN" ]]; then
  fail "T0 · Giriş BAŞARISIZ — hiçbir kod istenmedi, hiçbir şifre değişmedi."
  printf '  %s\n' "${c_dim}$RESP${c_rst}"
  logla "[T0] LOGIN FAIL :: $RESP"
  echo
  warn "Muhtemel sebepler ve çözümleri:"
  echo "    1) Şifre yanlış / daha önce bir test koşusu değiştirdi"
  echo "       → bash deploy/scripts/25_pentest_hesap_sifre_yenile.sh $EMAIL"
  echo "         (bu komut şifreyi 'Pentest.Baslangic.2026.Aa1' yapar ve girişi doğrular)"
  echo "    2) Gerçek/kendi hesabınızı kullanıyorsunuz"
  echo "       → bunun yerine AYRI bir test hesabı kullanın:"
  echo "         ONAY=1 bash supabase/tests/security/pentest_gunu/08_test_hesaplari_olustur.sh"
  echo "         kimlikler: /tmp/pentest_test_hesaplari.txt  (örn. pt.a.uzman@pentest.isgdenetim.test)"
  echo "    3) 15 dakika içinde çok hatalı deneme yaptıysanız kısa bir bekleme gerekebilir."
  ozet_yaz "T0 giris basarisiz"
  exit 1
fi
pass "T0 → token alındı (${#TOKEN} karakter)"
PASS_N=$((PASS_N + 1))

# ── T1: yanlış mevcut şifre ──────────────────────────────────────────────────
info "T1 · Yanlış mevcut şifre ile kod isteme"
bekle "T1 yanlış-mevcut-şifre" "CURRENT_PASSWORD_INVALID" \
  "$(api "$TOKEN" '{"action":"kod-gonder","currentPassword":"Kesinlikle.Yanlis.123"}')"

# ── T2: kod gönder ───────────────────────────────────────────────────────────
info "T2 · Doğru mevcut şifre ile kod gönderme (mail 1)"
R2="$(api "$TOKEN" "{\"action\":\"kod-gonder\",\"currentPassword\":\"$P0\"}")"
if ! bekle "T2 kod-gönder" "ok" "$R2"; then
  warn "Kod gönderilemedi. MAIL_NOT_CONFIGURED / MAIL_SEND_FAILED ise Resend ayarlarına bakın."
  warn "RATE_LIMITED ise 15 dakika bekleyin. Test durduruldu."
  exit 1
fi

printf '\n%s\n' "Mail 1 geldi. 6 haneli kodu girin."
printf '  %s\n' "${c_dim}Kod mailde yoksa: Resend → Emails → en son gönderim → gövdedeki 6 hane${c_rst}"
sor KOD1 "  Kod 1: "
KOD1="$(printf '%s' "$KOD1" | tr -d '[:space:]')"
if [[ -z "$KOD1" ]]; then
  fail "Kod 1 bos girildi — akis test edilemez."
  logla "[FATAL] KOD1 bos"
  ozet_yaz "kod girilmedi"
  exit 1
fi

# ── T3: zayıf şifre (kod tüketilmemeli) ──────────────────────────────────────
info "T3 · Zayıf yeni şifre reddedilmeli (kod tüketilmemeli)"
bekle "T3 zayıf-şifre" "PASSWORD_TOO_SHORT" \
  "$(api "$TOKEN" "{\"action\":\"sifre-degistir\",\"code\":\"$KOD1\",\"newPassword\":\"Kisa.11Chr\",\"currentPassword\":\"$P0\"}")"

# ── T4: hatalı kod ───────────────────────────────────────────────────────────
YANLIS_KOD="000000"; [[ "$KOD1" = "000000" ]] && YANLIS_KOD="111111"
info "T4 · Hatalı kod reddedilmeli"
bekle "T4 hatalı-kod" "CODE_INVALID" \
  "$(api "$TOKEN" "{\"action\":\"sifre-degistir\",\"code\":\"$YANLIS_KOD\",\"newPassword\":\"$P1\",\"currentPassword\":\"$P0\"}")"

# ── T5: gerçek değişim ───────────────────────────────────────────────────────
info "T5 · Doğru kod ile şifre değişimi + diğer oturumların kapanması"
R5="$(api "$TOKEN" "{\"action\":\"sifre-degistir\",\"code\":\"$KOD1\",\"newPassword\":\"$P1\",\"currentPassword\":\"$P0\"}")"
bekle "T5 şifre-değişimi" "ok" "$R5"
if [[ "$(jget "$R5" otherSessionsRevoked)" = "True" || "$(jget "$R5" otherSessionsRevoked)" = "true" ]]; then
  pass "T5b diğer oturumlar kapatıldı"
  PASS_N=$((PASS_N + 1)); logla "[T5b] otherSessionsRevoked=true"
else
  fail "T5b otherSessionsRevoked true değil: $(jget "$R5" otherSessionsRevoked)"
  FAIL_N=$((FAIL_N + 1)); logla "[T5b] otherSessionsRevoked != true :: $R5"
fi

# ── T6: kod tekrar kullanımı ─────────────────────────────────────────────────
info "T6 · Aynı kod ikinci kez kullanılamamalı"
bekle "T6 kod-tekrar" "CODE_INVALID|CODE_NOT_FOUND" \
  "$(api "$TOKEN" "{\"action\":\"sifre-degistir\",\"code\":\"$KOD1\",\"newPassword\":\"$P2\",\"currentPassword\":\"$P1\"}")"

# ── T7: eski şifre çalışmamalı ───────────────────────────────────────────────
info "T7 · Eski şifre ile giriş başarısız olmalı"
TOKEN_ESKI="$(jget "$(login "$EMAIL" "$P0")" access_token)"
if [[ -z "$TOKEN_ESKI" ]]; then
  pass "T7 → eski şifre reddedildi"; PASS_N=$((PASS_N + 1)); logla "[T7] PASS"
else
  fail "T7 → eski şifre HÂLÂ çalışıyor"; FAIL_N=$((FAIL_N + 1)); logla "[T7] FAIL"
fi

# ── T8: yeni şifre çalışmalı ─────────────────────────────────────────────────
info "T8 · Yeni şifre ile giriş başarılı olmalı"
RESP8="$(login "$EMAIL" "$P1")"
TOKEN2="$(jget "$RESP8" access_token)"
if [[ -n "$TOKEN2" ]]; then
  pass "T8 → yeni şifre çalışıyor"; PASS_N=$((PASS_N + 1)); logla "[T8] PASS"
else
  fail "T8 → yeni şifre çalışmıyor: $RESP8"; FAIL_N=$((FAIL_N + 1)); logla "[T8] FAIL :: $RESP8"
  warn "Testin devamı için token yok, duruluyor."
  exit 1
fi

# ── T9: iki kod → ilki geçersiz ──────────────────────────────────────────────
info "T9 · Yeni kod istendiğinde önceki kod geçersiz olmalı (mail 2 ve mail 3)"
R9a="$(api "$TOKEN2" "{\"action\":\"kod-gonder\",\"currentPassword\":\"$P1\"}")"
bekle "T9a kod-A gönderimi" "ok" "$R9a" || { warn "Duruldu."; exit 1; }
printf '\n%s\n' "Mail 2 geldi (kod A). Kodu girin — bu kod geçersiz kılınacak."
printf '  %s\n' "${c_dim}Kod mailde yoksa: Resend → Emails → en son gönderim → gövdedeki 6 hane${c_rst}"
sor KODA "  Kod A: "
KODA="$(printf '%s' "$KODA" | tr -d '[:space:]')"
if [[ -z "$KODA" ]]; then
  fail "Kod A bos girildi — T9 calistirilamaz."
  logla "[FATAL] KODA bos"
  ozet_yaz "kod A girilmedi"
  exit 1
fi

R9b="$(api "$TOKEN2" "{\"action\":\"kod-gonder\",\"currentPassword\":\"$P1\"}")"
bekle "T9b kod-B gönderimi" "ok" "$R9b" || { warn "Duruldu."; exit 1; }
warn "Mail 3 de geldi (kod B). Kod B'yi girmeyin — bilerek kod A'yı deneyeceğiz."

bekle "T9c eski-kod-geçersiz" "CODE_INVALID|CODE_NOT_FOUND" \
  "$(api "$TOKEN2" "{\"action\":\"sifre-degistir\",\"code\":\"$KODA\",\"newPassword\":\"$P2\",\"currentPassword\":\"$P1\"}")"

# ── Özel: hatalı deneme limiti (opsiyonel) ───────────────────────────────────
if [[ "${LIMIT_TEST:-0}" = "1" ]]; then
  info "T10 · 5 hatalı denemeden sonra kilit (opsiyonel)"
  for i in 1 2 3 4 5 6; do
    RJ="$(api "$TOKEN2" "{\"action\":\"sifre-degistir\",\"code\":\"99999$i\",\"newPassword\":\"$P2\",\"currentPassword\":\"$P1\"}")"
    printf '  deneme %s → %s\n' "$i" "$(jget "$RJ" code)"
    logla "[T10] deneme $i :: $RJ"
  done
  warn "6. denemede CODE_ATTEMPTS beklenir. Log'u kontrol edin."
fi

# ── Özet ─────────────────────────────────────────────────────────────────────
cat <<EOF

════════════════════════════════════════════════════════════════
  SONUÇ:  ${c_grn}${PASS_N} PASS${c_rst}  ·  ${c_red}${FAIL_N} FAIL${c_rst}
════════════════════════════════════════════════════════════════
  Hesabın yeni şifresi : $P1
  Kanıt dosyası        : $LOG

EOF

ozet_yaz "elle kosuldu"

if [[ "$FAIL_N" = "0" ]]; then
  pass "Akış uçtan uca doğrulandı. Log dosyasını rapora ekleyin."
  exit 0
else
  fail "Başarısız adım var — $LOG dosyasındaki ilgili satırı inceleyin."
  exit 1
fi