<#
.SYNOPSIS
  Pentest kanit toplayici (Windows PowerShell -> uzak sunucu).
  SALT-OKUR: hicbir servisi, migration'i veya ayari degistirmez.

.DESCRIPTION
  Sunucuda sirayla su kanitlari toplar ve tek tarball halinde geri indirir:
    00_ozet.txt                  konteyner adlari
    01_docker_ps.txt             calisan konteynerler
    02_auth_env.txt              REAUTHENTICATION / PASSWORD_MIN_LENGTH / HIBP
    03a_triggerlar.txt           auth.users + profiles trigger'lari
    03b_kolon_yetkisi.txt        authenticated -> profiles.role UPDATE yetkisi
    03c_schema_migrations.txt    uygulanmis migration listesi
    03d_realtime_publication.txt supabase_realtime publication icerigi
    04a_hsts_api.txt             api.* HSTS ve guvenlik basliklari
    04b_cors_yabanci.txt         yabanci origin CORS testi
    04c_hsts_app.txt             app.* HSTS
    05_cors_tarama.txt           fonksiyon sayisi + wildcard/credentials taramasi
    06_f2_f5.txt                 10_f2_f5_dogrula.sh ciktisi (varsa)

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\deploy\scripts\32_windows_kanit_topla.ps1

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\deploy\scripts\32_windows_kanit_topla.ps1 -Server root@37.230.105.216 -Port 23422
#>

param(
  [string]$Server = 'root@37.230.105.216',
  [int]$Port = 23422,
  [string]$OutDir = './pentest-kanit'
)

$ErrorActionPreference = 'Continue'

if (-not (Test-Path $OutDir)) {
  New-Item -ItemType Directory -Path $OutDir | Out-Null
}
$resolved = (Resolve-Path $OutDir).Path
$localSh = Join-Path $resolved 'kanit_topla.sh'

$remoteScript = @'
#!/usr/bin/env bash
# SALT-OKUR kanit toplayici. Hicbir seyi degistirmez.
set -u

OUT=/root/kanit-out
rm -rf "$OUT" 2>/dev/null
mkdir -p "$OUT"

echo "toplama_zamani=$(date -Is)" > "$OUT/00_ozet.txt"
echo "host=$(hostname)" >> "$OUT/00_ozet.txt"

cd /opt/ibys/supabase/docker 2>/dev/null || true

# --- 01 konteynerler ---
docker ps --format '{{.Names}}|{{.Status}}' > "$OUT/01_docker_ps.txt" 2>&1
AUTH=$(docker ps --format '{{.Names}}' | grep -Ei 'auth' | head -n1)
DB=$(docker ps --format '{{.Names}}' | grep -Ei 'supabase-db|[-_]db$' | head -n1)
echo "AUTH=$AUTH" >> "$OUT/00_ozet.txt"
echo "DB=$DB" >> "$OUT/00_ozet.txt"

# --- 02 auth env ---
if [ -n "${AUTH:-}" ]; then
  docker exec -T "$AUTH" printenv 2>/dev/null \
    | grep -Ei 'REAUTHENTICATION|PASSWORD_MIN_LENGTH|HIBP|SECURITY_UPDATE_PASSWORD' \
    > "$OUT/02_auth_env.txt" 2>&1
  if [ ! -s "$OUT/02_auth_env.txt" ]; then
    echo "auth konteyneri bulundu ama ilgili env degiskeni YOK" > "$OUT/02_auth_env.txt"
  fi
else
  echo "auth konteyneri bulunamadi" > "$OUT/02_auth_env.txt"
fi

# --- 03 veritabani kontrolleri ---
if [ -n "${DB:-}" ]; then
  docker exec -T "$DB" psql -U postgres -d postgres -At -c \
    "select tgname from pg_trigger where not tgisinternal and tgrelid in ('auth.users'::regclass,'public.profiles'::regclass) order by 1;" \
    > "$OUT/03a_triggerlar.txt" 2>&1

  docker exec -T "$DB" psql -U postgres -d postgres -At -c \
    "select has_column_privilege('authenticated','public.profiles','role','UPDATE') as authenticated_role_update;" \
    > "$OUT/03b_kolon_yetkisi.txt" 2>&1

  docker exec -T "$DB" psql -U postgres -d postgres -At -c \
    "select version from supabase_migrations.schema_migrations order by version desc limit 30;" \
    > "$OUT/03c_schema_migrations.txt" 2>&1

  docker exec -T "$DB" psql -U postgres -d postgres -At -c \
    "select pubname, schemaname, tablename from pg_publication_tables order by 1,2,3;" \
    > "$OUT/03d_realtime_publication.txt" 2>&1
else
  echo "db konteyneri bulunamadi" > "$OUT/03_hata.txt"
fi

# --- 04 canli baslik testleri ---
API=https://api.isgdenetim.com.tr
APP=https://app.isgdenetim.com.tr

curl -sSI --max-time 10 "$API" 2>&1 | tr -d '\r' \
  | grep -Ei 'strict-transport-security|x-content-type-options|x-frame-options|referrer-policy|^server' \
  > "$OUT/04a_hsts_api.txt"
[ -s "$OUT/04a_hsts_api.txt" ] || echo "api.* basliklari okunamadi" > "$OUT/04a_hsts_api.txt"

curl -sS -o /dev/null -D - --max-time 10 -H 'Origin: https://kotu-site.example' "$API/rest/v1/" 2>&1 \
  | tr -d '\r' | grep -Ei 'access-control' > "$OUT/04b_cors_yabanci.txt"
[ -s "$OUT/04b_cors_yabanci.txt" ] \
  || echo "TEMIZ: yabanci origin icin Access-Control-* basligi YOK (B-06 lehine)" > "$OUT/04b_cors_yabanci.txt"

curl -sSI --max-time 10 "$APP" 2>&1 | tr -d '\r' \
  | grep -Ei 'strict-transport-security' > "$OUT/04c_hsts_app.txt"
[ -s "$OUT/04c_hsts_app.txt" ] || echo "app.* icin HSTS basligi YOK" > "$OUT/04c_hsts_app.txt"

# --- 05 repo CORS taramasi ---
REPO=""
for R in /opt/ibys /root/ibys /opt/ibys/app; do
  if [ -d "$R/supabase/functions" ]; then REPO="$R"; break; fi
done

if [ -n "$REPO" ]; then
  {
    echo "repo=$REPO"
    echo "fonksiyon_sayisi=$(find "$REPO/supabase/functions" -maxdepth 2 -name index.ts | wc -l)"
    echo "acao_satir_sayisi=$(grep -rn 'Access-Control-Allow-Origin' "$REPO/supabase/functions" --include=index.ts | wc -l)"
    echo "acao_wildcard_sayisi=$(grep -rn 'Access-Control-Allow-Origin' "$REPO/supabase/functions" --include=index.ts | grep -c '\*')"
    echo "allow_credentials_sayisi=$(grep -rn 'Access-Control-Allow-Credentials' "$REPO/supabase/functions" --include=index.ts | wc -l)"
  } > "$OUT/05_cors_tarama.txt" 2>&1
else
  echo "repo bulunamadi" > "$OUT/05_cors_tarama.txt"
fi

# --- 06 repo scripti (varsa) ---
if [ -n "$REPO" ] && [ -f "$REPO/deploy/scripts/10_f2_f5_dogrula.sh" ]; then
  bash "$REPO/deploy/scripts/10_f2_f5_dogrula.sh" > "$OUT/06_f2_f5.txt" 2>&1 \
    || echo "(script sifir olmayan kodla cikti)" >> "$OUT/06_f2_f5.txt"
fi

# --- paketle ---
ls -la "$OUT" > "$OUT/_liste.txt" 2>&1
rm -f /root/kanit-out.tar.gz
tar -czf /root/kanit-out.tar.gz -C /root kanit-out
echo "HAZIR: /root/kanit-out.tar.gz"
'@

$remoteScript = $remoteScript -replace "`r`n", "`n"
[System.IO.File]::WriteAllText($localSh, $remoteScript)

Write-Host "[1/4] Script sunucuya kopyalaniyor..." -ForegroundColor Cyan
scp -P $Port $localSh "${Server}:/root/kanit_topla.sh"
if ($LASTEXITCODE -ne 0) {
  Write-Host "HATA: scp basarisiz. Sunucu adresi / anahtar kontrol et." -ForegroundColor Red
  exit 1
}

Write-Host "[2/4] Sunucuda kanitlar toplaniyor (salt-okur)..." -ForegroundColor Cyan
ssh -p $Port $Server 'bash /root/kanit_topla.sh'

Write-Host "[3/4] Tarball geri indiriliyor..." -ForegroundColor Cyan
scp -P $Port "${Server}:/root/kanit-out.tar.gz" "$resolved\kanit-out.tar.gz"
if ($LASTEXITCODE -ne 0) {
  Write-Host "HATA: tarball indirilemedi." -ForegroundColor Red
  exit 1
}

Write-Host "[4/4] Aciliyor..." -ForegroundColor Cyan
Push-Location $resolved
tar -xzf .\kanit-out.tar.gz
Pop-Location

Write-Host ""
Write-Host "TAMAM. Kanit dosyalari: $resolved\kanit-out" -ForegroundColor Green
Write-Host "Once sunu oku: $resolved\kanit-out\_liste.txt" -ForegroundColor Green