#!/usr/bin/env bash
# 33_auth_env_kanit.sh — PowerShell tırnak belasını bitiren kanıt script'i.
#
# Kullanım (Windows PowerShell):
#   ssh -p 23422 root@37.230.105.216 'bash -s' < .\deploy\scripts\33_auth_env_kanit.sh
#
# Neden böyle: script stdin'den sunucuya aktarılır, PowerShell içindeki
# tırnakları ve boru (|) karakterlerini hiç görmez. Bozulma imkânsız.
#
# SALT-OKUR: hiçbir ayarı, veriyi, container'ı değiştirmez. Sadece okur.

set -uo pipefail

AUTH_CTR="${AUTH_CTR:-supabase-auth}"
DB_CTR="${DB_CTR:-supabase-db}"
API="${API:-https://api.isgdenetim.com.tr}"
OUT="/root/pentest-kanit-$(date +%Y%m%d-%H%M%S)"

mkdir -p "$OUT"

hr() { printf '\n===== %s =====\n' "$1"; }

# Container adı sabit değilse otomatik bul
if ! docker inspect "$AUTH_CTR" >/dev/null 2>&1; then
  AUTH_CTR="$(docker ps --format '{{.Names}}' | grep -iE 'auth' | head -n1)"
fi
if ! docker inspect "$DB_CTR" >/dev/null 2>&1; then
  DB_CTR="$(docker ps --format '{{.Names}}' | grep -iE 'db|postgres|postgrest' | head -n1)"
fi

echo "auth container : ${AUTH_CTR:-BULUNAMADI}"
echo "db container   : ${DB_CTR:-BULUNAMADI}"
echo "api            : $API"
echo "cikti klasoru  : $OUT"

# ---------------------------------------------------------------------------
hr "01 — AUTH ENV (F1 sifre yeniden dogrulama kaniti)"
# ---------------------------------------------------------------------------
{
  docker exec "$AUTH_CTR" printenv \
    | grep -iE 'REAUTHENTICATION|PASSWORD_MIN_LENGTH|PASSWORD_HIBP|HIBP' \
    | sort
} | tee "$OUT/01_auth_env.txt"

if [ ! -s "$OUT/01_auth_env.txt" ]; then
  echo "!! Bos cikti: env degisken adlari farkli olabilir. Ham listeyi de yaziyorum."
  docker exec "$AUTH_CTR" printenv | grep -i 'GOTRUE' | sort | tee "$OUT/01b_auth_env_ham.txt"
fi

# ---------------------------------------------------------------------------
hr "02 — TRIGGERLAR (F2 / F5 kaniti)"
# ---------------------------------------------------------------------------
{
  docker exec "$DB_CTR" psql -U postgres -d postgres -A -F'|' -c \
    "select c.relname as tablo, t.tgname as trigger
       from pg_trigger t join pg_class c on c.oid = t.tgrelid
      where not t.tgisinternal
      order by 1,2;"
} 2>&1 | tee "$OUT/02_triggerlar.txt"

# ---------------------------------------------------------------------------
hr "03 — profiles.role KOLON YETKISI (F5 kaniti)"
# ---------------------------------------------------------------------------
{
  docker exec "$DB_CTR" psql -U postgres -d postgres -A -c \
    "select 'authenticated_role_update=' || has_column_privilege('authenticated','public.profiles','role','UPDATE')::text;"
  docker exec "$DB_CTR" psql -U postgres -d postgres -A -c \
    "select 'authenticated_role_insert=' || has_column_privilege('authenticated','public.profiles','role','INSERT')::text;"
} 2>&1 | tee "$OUT/03_kolon_yetkisi.txt"

# ---------------------------------------------------------------------------
hr "04 — UYGULANAN MIGRATIONLAR (repo'da var != canlida var)"
# ---------------------------------------------------------------------------
{
  docker exec "$DB_CTR" psql -U postgres -d postgres -A -F'|' -c \
    "select version, name from supabase_migrations.schema_migrations order by version;" \
    || docker exec "$DB_CTR" psql -U postgres -d postgres -A -F'|' -c \
    "select version, name from schema_migrations order by version;"
} 2>&1 | tee "$OUT/04_migrations.txt"

# ---------------------------------------------------------------------------
hr "05 — HSTS (B-06 kaniti)"
# ---------------------------------------------------------------------------
curl -sI "$API" 2>&1 | grep -i 'strict-transport' | tee "$OUT/05_hsts.txt"
[ -s "$OUT/05_hsts.txt" ] || echo "!! HSTS basligi YOK — bu bulgu kapanmis sayilmaz." | tee -a "$OUT/05_hsts.txt"

# ---------------------------------------------------------------------------
hr "06 — YABANCI ORIGIN CORS (B-08 kaniti)"
# ---------------------------------------------------------------------------
curl -sI -H 'Origin: https://kotu-site.example' "$API/rest/v1/" 2>&1 \
  | grep -i 'access-control' | tee "$OUT/06_cors_yabanci_origin.txt"
if [ ! -s "$OUT/06_cors_yabanci_origin.txt" ]; then
  echo "OK — yabanci origin'e CORS basligi verilmiyor (bos cikti = iyi haber)." \
    | tee -a "$OUT/06_cors_yabanci_origin.txt"
fi

# ---------------------------------------------------------------------------
hr "07 — SCHEMA_MIGRATIONS KILIDI (guv35)"
# ---------------------------------------------------------------------------
{
  docker exec "$DB_CTR" psql -U postgres -d postgres -A -c \
    "select 'anon_select_schema_migrations=' || has_table_privilege('anon','supabase_migrations.schema_migrations','SELECT')::text;" 2>/dev/null \
  || echo "anon_select_schema_migrations=KONTROL EDILEMEDI"
} 2>&1 | tee "$OUT/07_schema_migrations_kilit.txt"

# ---------------------------------------------------------------------------
hr "OZET"
# ---------------------------------------------------------------------------
echo "01_auth_env.txt icerigi:"
sed 's/^/  /' "$OUT/01_auth_env.txt" 2>/dev/null || true
echo
echo "03_kolon_yetkisi.txt icerigi:"
sed 's/^/  /' "$OUT/03_kolon_yetkisi.txt" 2>/dev/null || true
echo
echo "Tum kanit dosyalari: $OUT"
ls -1 "$OUT"