#!/usr/bin/env bash
# =============================================================================
# 14 · GUV-39 + GUV-32 — profiles ↔ auth.users FK zinciri (KVKK hesap silme)
# =============================================================================
# Nerede çalışır : SELF-HOSTED SUNUCU (Supabase docker compose dizini)
# Kullanım       : bash 14_fk_guv39_guv32_deploy.sh
#                  TEST_SILME=0 bash 14_fk_guv39_guv32_deploy.sh   # davranış testi atla
#
# SIRA KRİTİK:
#   1) GUV-39  → profiles(id)'e bağlı 18 adet NO ACTION FK'yı SET NULL / CASCADE'e çeker.
#   2) GUV-32  → profiles.id → auth.users(id) ON DELETE CASCADE ekler.
#
#   Ters sırayla uygulanırsa: auth kullanıcısı silinmek istendiğinde profiles
#   satırı CASCADE ile gider, ama ona bağlı NOT NULL + NO ACTION kolonlar
#   (evraklar.uploaded_by vb.) 23503 ihlali üretir → TÜM transaction geri alınır
#   → HİÇBİR kullanıcı silinemez. Bu yüzden sıra zorunludur.
#
# Yaptığı işlem sırası:
#   1) Ön kontroller (dosyalar, konteyner, psql)
#   2) Tam veritabanı yedeği
#   3) SALT-OKUMA yayılma analizi (hangi tablolar profiles'a bağlı, ne olacak)
#   4) Yetim profil kontrolü (0 olmalı — GUV-32 zaten kendi içinde kontrol eder)
#   5) GUV-39 uygula + doğrula (bloklayan FK = 0)
#   6) GUV-32 uygula + doğrula (FK = CASCADE)
#   7) GERÇEK SİLME TESTİ: geçici kullanıcı aç → sil → profil de gitti mi?
#   8) Regresyon sorguları (kayıt akışı, mesajlaşma, personel)
#
# YIKICI DEĞİL: hiçbir satır silinmez. Sadece kısıt davranışı + 7 kolonun
# nullability'si değişir. Geçici test kullanıcısı sonda temizlenir.
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/../.." && pwd)}"
SUPABASE_DIR="${SUPABASE_DIR:-/opt/ibys/supabase/docker}"
PGUSER="${PGUSER:-supabase_admin}"
DB_NAME="${DB_NAME:-postgres}"
BACKUP_DIR="${BACKUP_DIR:-/root/isg-yedek}"
TEST_SILME="${TEST_SILME:-1}"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }
step() { printf '\n%s\n' "${c_dim}────────────────────────────────────────────────────────────${c_rst}"; printf '%s\n' "${c_grn}$*${c_rst}"; }

mig_path() {
  local name="$1" c
  for c in "$REPO_ROOT/supabase/migrations/$name" "$SCRIPT_DIR/$name"; do
    if [[ -f "$c" ]]; then printf '%s\n' "$c"; return 0; fi
  done
  return 1
}

# ── 1) Ön kontroller ─────────────────────────────────────────────────────────
step "1/7 · Ön kontroller"

SQL39="$(mig_path 20260101002250_guv39_profiles_fk_delete_behavior.sql || true)"
SQL32="$(mig_path 20260101002300_guv32_profiles_auth_users_fk.sql || true)"
[[ -n "$SQL39" ]] || die "GUV-39 migration bulunamadı. REPO_ROOT=$REPO_ROOT (veya script yanına kopyala)."
[[ -n "$SQL32" ]] || die "GUV-32 migration bulunamadı. REPO_ROOT=$REPO_ROOT (veya script yanına kopyala)."

if [[ ! -f "$SUPABASE_DIR/docker-compose.yml" ]]; then
  for d in /opt/ibys/supabase/docker /opt/supabase/docker /root/supabase/docker /srv/supabase/docker; do
    [[ -f "$d/docker-compose.yml" ]] && { SUPABASE_DIR="$d"; break; }
  done
fi
[[ -f "$SUPABASE_DIR/docker-compose.yml" ]] || die "docker-compose.yml bulunamadı. SUPABASE_DIR=/dogru/yol ver."
cd "$SUPABASE_DIR"

if docker compose version >/dev/null 2>&1; then DC=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then DC=(docker-compose)
else die "docker compose bulunamadı."; fi

"${DC[@]}" ps -q db >/dev/null 2>&1 || true
DB_ID="$("${DC[@]}" ps -q db 2>/dev/null | head -n1 || true)"
[[ -n "$DB_ID" ]] || die "db konteyneri çalışmıyor. Önce: docker compose up -d db"

psql_at() { "${DC[@]}" exec -T db psql -U "$PGUSER" -d "$DB_NAME" -At -v ON_ERROR_STOP=1 -c "$1"; }
psql_f()  { "${DC[@]}" exec -T db psql -U "$PGUSER" -d "$DB_NAME" -v ON_ERROR_STOP=1 "$@"; }

psql_at "select 1" >/dev/null || die "psql bağlantısı başarısız (PGUSER=$PGUSER). PGUSER=postgres deneyin."

info "compose    : $SUPABASE_DIR"
info "PGUSER     : $PGUSER / DB: $DB_NAME"
info "GUV-39     : $SQL39"
info "GUV-32     : $SQL32"

# ── 2) Yedek ────────────────────────────────────────────────────────────────
step "2/7 · Tam veritabanı yedeği"
mkdir -p "$BACKUP_DIR"
BK="$BACKUP_DIR/pre_guv32_$(date +%Y%m%d_%H%M%S).dump"
"${DC[@]}" exec -T db pg_dump -U "$PGUSER" -d "$DB_NAME" -Fc > "$BK"
[[ -s "$BK" ]] || die "Yedek alınamadı: $BK"
info "yedek: $BK ($(du -h "$BK" | cut -f1))"

# ── 3) SALT-OKUMA yayılma analizi ───────────────────────────────────────────
step "3/7 · Yayılma analizi (salt okuma — hiçbir şey değişmez)"

psql_f <<'SQL'
\echo '--- profiles(id) referansina bakan FK dagilimi (ONCE) ---'
select case c.confdeltype
         when 'c' then 'CASCADE'
         when 'n' then 'SET NULL'
         when 'r' then 'RESTRICT'
         when 'a' then 'NO ACTION'
       end as silme_davranisi,
       count(*) as fk_sayisi
  from pg_constraint c
 where c.contype = 'f'
   and c.confrelid = 'public.profiles'::regclass
 group by 1
 order by 2 desc;

\echo ''
\echo '--- Bloklayan (NO ACTION / RESTRICT) FK listesi — GUV-39 bunları kapatacak ---'
select t2.relname as tablo,
       a.attname as kolon,
       case c.confdeltype when 'a' then 'NO ACTION' when 'r' then 'RESTRICT' else c.confdeltype::text end as davranis,
       case when a.attnotnull then 'NOT NULL' else 'nullable' end as null_durumu
  from pg_constraint c
  join pg_class t2 on t2.oid = c.conrelid
  join pg_namespace n2 on n2.oid = t2.relnamespace
  join pg_attribute a on a.attrelid = t2.oid and a.attnum = any (c.conkey)
 where c.contype = 'f'
   and c.confrelid = 'public.profiles'::regclass
   and c.confdeltype in ('a','r')
 order by 1, 2;

\echo ''
\echo '--- Yetim profil sayısı (0 olmalı, GUV-32 aksi halde durur) ---'
select count(*) as yetim_profil
  from public.profiles p
  left join auth.users u on u.id = p.id
 where u.id is null;

\echo ''
\echo '--- Hacim (silme testi için referans) ---'
select 'profiles' as tablo, count(*) from public.profiles
union all select 'auth.users', count(*) from auth.users;
SQL

BLOKLAYAN="$({ psql_at "select count(*) from pg_constraint c where c.contype='f' and c.confrelid='public.profiles'::regclass and c.confdeltype in ('a','r');"; } | tr -d '[:space:]')"
YETIM="$({ psql_at "select count(*) from public.profiles p left join auth.users u on u.id=p.id where u.id is null;"; } | tr -d '[:space:]')"
info "bloklayan FK: ${BLOKLAYAN:-?}  |  yetim profil: ${YETIM:-?}"

if [[ "${YETIM:-1}" != "0" ]]; then
  warn "Yetim profil var (${YETIM}). GUV-32 bunları OTOMATİK SİLMEZ, duracaktır."
  warn "Önce inceleyin: select id, email, role, created_at from public.profiles p"
  warn "                left join auth.users u on u.id=p.id where u.id is null;"
  warn "Bu satırların KVKK kaydı açısından ne olacağına karar vermeden devam etmeyin."
fi

# ── 4) GUV-39 ───────────────────────────────────────────────────────────────
step "4/7 · GUV-39 uygulanıyor (FK silme davranışı temizliği)"

B39="$(basename "$SQL39")"
docker cp "$SQL39" "$DB_ID:/tmp/$B39"
psql_f -f "/tmp/$B39"

KALAN_BLOK="$({ psql_at "select count(*) from pg_constraint c where c.contype='f' and c.confrelid='public.profiles'::regclass and c.confdeltype in ('a','r');"; } | tr -d '[:space:]')"
[[ "$KALAN_BLOK" = "0" ]] || die "GUV-39 sonrası hâlâ $KALAN_BLOK bloklayan FK var. GUV-32 UYGULANMADI. Rollback: supabase/migrations/rollback/20260101002250_..._rollback.sql"
info "GUV-39 doğrulandı: bloklayan FK = 0"

# ── 5) GUV-32 ───────────────────────────────────────────────────────────────
step "5/7 · GUV-32 uygulanıyor (profiles.id → auth.users ON DELETE CASCADE)"

B32="$(basename "$SQL32")"
docker cp "$SQL32" "$DB_ID:/tmp/$B32"
if ! psql_f -f "/tmp/$B32"; then
  die "GUV-32 uygulanamadı (yukarıdaki mesaja bakın). GUV-39 uygulanmış durumda kalır — o zararsızdır ve tek başına silme davranışını İYİLEŞTİRİR. Bilgi verin."
fi

FK_DAVRANIS="$({ psql_at "select coalesce(max(c.confdeltype::text),'-') from pg_constraint c where c.conname='profiles_id_auth_users_fkey';"; } | tr -d '[:space:]')"
[[ "$FK_DAVRANIS" = "c" ]] || die "profiles_id_auth_users_fkey bulunamadı ya da CASCADE değil (confdeltype=$FK_DAVRANIS)."
info "GUV-32 doğrulandı: profiles_id_auth_users_fkey → CASCADE"

psql_f <<'SQL'
\echo ''
\echo '--- SON DURUM: profiles(id) referansina bakan FK dagilimi ---'
select case c.confdeltype when 'c' then 'CASCADE' when 'n' then 'SET NULL'
                           when 'r' then 'RESTRICT' when 'a' then 'NO ACTION' end as davranis,
       count(*)
  from pg_constraint c
 where c.contype='f' and c.confrelid='public.profiles'::regclass
 group by 1 order by 2 desc;
SQL

# ── 6) GERÇEK SİLME TESTİ ───────────────────────────────────────────────────
step "6/7 · Gerçek silme testi (geçici kullanıcı)"

if [[ "$TEST_SILME" != "1" ]]; then
  warn "TEST_SILME=0 → silme testi atlandı. Rapor için bu testin kanıtı GEREKLİ."
else
  API="${API:-http://127.0.0.1:8000}"
  SERVICE_KEY="$(grep -hE '^SERVICE_ROLE_KEY=' "$SUPABASE_DIR/.env" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' || true)"
  [[ -n "$SERVICE_KEY" ]] || die "SERVICE_ROLE_KEY .env içinde bulunamadı; silme testi yapılamaz."

  TS="$(date +%s)"
  TEST_EMAIL="fk.test.${TS}@pentest.local"
  TEST_PW="Fk.Test.${TS}.Aa9!"
  TEST_UID=""

  temizle() {
    if [[ -n "$TEST_UID" ]]; then
      curl -sS -o /dev/null -X DELETE "$API/auth/v1/admin/users/$TEST_UID" \
        -H "apikey: $SERVICE_KEY" -H "Authorization: Bearer $SERVICE_KEY" || true
    fi
  }
  trap temizle EXIT

  RESP="$(curl -sS -X POST "$API/auth/v1/admin/users" \
    -H "apikey: $SERVICE_KEY" -H "Authorization: Bearer $SERVICE_KEY" \
    -H 'Content-Type: application/json' \
    -d "{\"email\":\"$TEST_EMAIL\",\"password\":\"$TEST_PW\",\"email_confirm\":true}")"

  TEST_UID="$(printf '%s' "$RESP" | python3 -c 'import json,sys
 d=json.load(sys.stdin)
 print(d.get("id") or (d.get("user") or {}).get("id") or "")' 2>/dev/null || true)"
  if [[ -z "$TEST_UID" ]]; then
    TEST_UID="$(printf '%s' "$RESP" | sed -n 's/.*"id":[[:space:]]*"\([0-9a-f-]\{36\}\)".*/\1/p' | head -1)"
  fi
  [[ -n "$TEST_UID" ]] || die "Test kullanıcısı oluşturulamadı. Yanıt: $RESP"

  info "test kullanıcısı: $TEST_EMAIL ($TEST_UID)"

  sleep 3   # handle_new_user trigger'ı için
  P_ONCE="$({ psql_at "select count(*) from public.profiles where id='$TEST_UID';"; } | tr -d '[:space:]')"

  DEL_CODE="$(curl -sS -o /dev/null -w '%{http_code}' -X DELETE "$API/auth/v1/admin/users/$TEST_UID" \
    -H "apikey: $SERVICE_KEY" -H "Authorization: Bearer $SERVICE_KEY")"
  TEST_UID=""   # trap tekrar silmesin

  sleep 1
  AUTH_KALAN="$(psql_at "select count(*) from auth.users where email='$TEST_EMAIL';" | tr -d '[:space:]')"
  PROFIL_KALAN="$(psql_at "select count(*) from public.profiles where email='$TEST_EMAIL';" | tr -d '[:space:]')"

  printf '\n  %-28s %s\n' "profil (silmeden önce):" "${P_ONCE:-?}   ${c_dim}(1 bekleniyor = trigger çalışıyor)${c_rst}"
  printf '  %-28s %s\n' "DELETE /admin/users:"     "$DEL_CODE   ${c_dim}(200 bekleniyor)${c_rst}"
  printf '  %-28s %s\n' "auth.users (sonra):"      "$AUTH_KALAN   ${c_dim}(0 bekleniyor)${c_rst}"
  printf '  %-28s %s\n' "profiles (sonra):"        "$PROFIL_KALAN   ${c_dim}(0 bekleniyor — GUV-32 öncesi 1 idi)${c_rst}"

  if [[ "$DEL_CODE" = "200" && "$AUTH_KALAN" = "0" && "$PROFIL_KALAN" = "0" ]]; then
    info "SİLME TESTİ: PASS — KVKK hesap silme artığı üretmiyor."
  else
    warn "SİLME TESTİ: BEKLENEN DIŞI. DELETE=$DEL_CODE auth=$AUTH_KALAN profil=$PROFIL_KALAN"
    warn "DELETE 500 döndüyse GUV-39 bir tabloyu kaçırmış olabilir. Kontrol:"
    warn "  select c.conname, t2.relname, a.attname, c.confdeltype from pg_constraint c"
    warn "  join pg_class t2 on t2.oid=c.conrelid join pg_namespace n2 on n2.oid=t2.relnamespace"
    warn "  join pg_attribute a on a.attrelid=t2.oid and a.attnum=any(c.conkey)"
    warn "  where c.contype='f' and c.confrelid='public.profiles'::regclass and c.confdeltype in ('a','r');"
  fi
fi

# ── 7) Regresyon ────────────────────────────────────────────────────────────
step "7/7 · Regresyon sorguları (salt okuma)"

psql_f <<'SQL'
\echo '--- handle_new_user trigger duruyor mu? ---'
select tgname, tgenabled
  from pg_trigger
 where tgrelid = 'auth.users'::regclass and not tgisinternal
 order by 1;

\echo ''
\echo '--- Nullable hale gelen kritik kolonlar (7 adet) ---'
select table_name, column_name, is_nullable
  from information_schema.columns
 where table_schema='public'
   and (table_name, column_name) in (
     ('announcements','created_by'), ('conversations','created_by'),
     ('messages','sender_id'), ('message_attachments','uploader_id'),
     ('support_attachments','uploaded_by'), ('support_messages','sender_id'),
     ('support_tickets','created_by'))
 order by 1;

\echo ''
\echo '--- Yetim profil (0 olmalı) ---'
select count(*) as yetim from public.profiles p
  left join auth.users u on u.id=p.id where u.id is null;
SQL

warn "UI regresyonu atlanmaz: mesaj gönder/oku, destek talebi aç, evrak yükle, personel işten çıkar, duyuru oluştur."
warn "Silinen kullanıcının mesajı 'bilinmeyen' görünmeli — uygulama hata vermemeli."

cat <<EOF

${c_grn}Tamamlandı.${c_rst}
  Yedek     : $BK
  GUV-39    : uygulandı (bloklayan FK = 0)
  GUV-32    : uygulandı (profiles_id_auth_users_fkey · CASCADE)

Geri dönüş (sadece gerçek kırılma varsa):
  ${DC[*]} exec -T db psql -U $PGUSER -d $DB_NAME -f /tmp/$(basename "$SQL32" .sql)_rollback.sql
  → rollback dosyası: supabase/migrations/rollback/20260101002300_guv32_profiles_auth_users_fk_rollback.sql

${c_yel}Not:${c_rst} GUV-39 rollback'i (02250) FK'ları NO ACTION'a DÖNDÜRÜR; GUV-32 açıkken
uygulanırsa hesap silme yine kırılır. İkisini birlikte geri alın.
EOF