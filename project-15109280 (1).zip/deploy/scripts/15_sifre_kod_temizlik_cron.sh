#!/usr/bin/env bash
# =============================================================================
# 15 · sifre_dogrulama_kodlarini_temizle() — periyodik temizlik job'u
# =============================================================================
# Sorun: GUV-41 ile gelen public.sifre_dogrulama_kodlari tablosu her şifre
#        değişim isteğinde büyür. Fonksiyon var ama HİÇBİR ZAMAN çağrılmıyor.
#        Edge function her kod isteğinde bir kez çağırıyor (2 günden eski,
#        tüketilmiş/süresi geçmiş satırlar) — ama trafik azsa tablo şişer.
#
# Çözüm (iki yol, otomatik seçim):
#   A) pg_cron varsa ve shared_preload_libraries içinde aktifse → DB içi job
#      ('ibys-sifre-kod-temizlik', her gün 04:15)
#   B) Yoksa → host cron (/etc/cron.d/ibys-sifre-kod-temizlik) + docker exec
#
# Kullanım:
#   bash 15_sifre_kod_temizlik_cron.sh              # kur (idempotent)
#   bash 15_sifre_kod_temizlik_cron.sh --durum      # mevcut durum
#   bash 15_sifre_kod_temizlik_cron.sh --simdi      # elle bir kez çalıştır
#   bash 15_sifre_kod_temizlik_cron.sh --kaldir     # kaldır
# =============================================================================
set -euo pipefail

SUPABASE_DIR="${SUPABASE_DIR:-/opt/ibys/supabase/docker}"
PGUSER="${PGUSER:-supabase_admin}"
DB_NAME="${DB_NAME:-postgres}"
JOB_NAME="ibys-sifre-kod-temizlik"
CRON_FILE="/etc/cron.d/$JOB_NAME"
LOG_FILE="/var/log/$JOB_NAME.log"
MODE="${1:-kur}"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

[[ -f "$SUPABASE_DIR/docker-compose.yml" ]] || die "docker-compose.yml bulunamadı: $SUPABASE_DIR"
cd "$SUPABASE_DIR"
if docker compose version >/dev/null 2>&1; then DC=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then DC=(docker-compose)
else die "docker compose bulunamadı."; fi

psql_at() { "${DC[@]}" exec -T db psql -U "$PGUSER" -d "$DB_NAME" -At -v ON_ERROR_STOP=1 -c "$1"; }
psql_q()  { "${DC[@]}" exec -T db psql -U "$PGUSER" -d "$DB_NAME" -q -v ON_ERROR_STOP=1 -c "$1"; }

"${DC[@]}" ps -q db >/dev/null 2>&1 || true
[[ -n "$("${DC[@]}" ps -q db 2>/dev/null | head -n1 || true)" ]] || die "db konteyneri çalışmıyor."

# Fonksiyon gerçekten var mı? (olmayan fonksiyonu zamanlamak anlamsız)
FONK="$({ psql_at "select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname='sifre_dogrulama_kodlarini_temizle';"; } | tr -d '[:space:]')"
if [[ "$FONK" != "1" ]]; then
  die "public.sifre_dogrulama_kodlarini_temizle() yok. Önce GUV-41 migration'ını uygula."
fi

# pg_cron kullanılabilir mi?
PGCRON_VAR="$({ psql_at "select count(*) from pg_proc p join pg_namespace n on n.oid=p.pronamespace where p.proname='schedule' and n.nspname='cron';"; } | tr -d '[:space:]')"
PLIBS="$(psql_at "show shared_preload_libraries;" 2>/dev/null | tr -d '[:space:]' || true)"
PGCRON_OK="0"
if [[ "$PGCRON_VAR" = "1" ]] && printf '%s' "$PLIBS" | grep -qi 'pg_cron'; then PGCRON_OK="1"; fi

durum() {
  echo "── DURUM ─────────────────────────────────────────────"
  echo "  fonksiyon         : var"
  echo "  pg_cron (kullanılabilir): $PGCRON_OK ${PLIBS:-(shared_preload_libraries okunamadı)}"
  if [[ "$PGCRON_OK" = "1" ]]; then
    "${DC[@]}" exec -T db psql -U "$PGUSER" -d "$DB_NAME" -c \
      "select jobid, jobname, schedule, active from cron.job where jobname='$JOB_NAME';" || true
  fi
  if [[ -f "$CRON_FILE" ]]; then
    echo "  host cron         : $CRON_FILE"
    sed 's/^/    /' "$CRON_FILE"
  else
    echo "  host cron         : yok"
  fi
  echo "  tablo satır sayısı: $({ psql_at "select count(*) from public.sifre_dogrulama_kodlari;"; } | tr -d '[:space:]')"
  echo "  son çalışma (host): $([[ -f "$LOG_FILE" ]] && tail -n 2 "$LOG_FILE" || echo 'kayıt yok')"
}

simdi() {
  info "Temizlik şimdi çalıştırılıyor (salt rapor: kaç satır silindi?)"
  psql_at "select public.sifre_dogrulama_kodlarini_temizle() as silinen_satir;"
}

kaldir() {
  if [[ "$PGCRON_OK" = "1" ]]; then
    psql_q "select cron.unschedule(jobid) from cron.job where jobname='$JOB_NAME';" || true
    info "pg_cron job kaldırıldı (varsa)."
  fi
  if [[ -f "$CRON_FILE" ]]; then
    rm -f "$CRON_FILE"; info "host cron kaldırıldı: $CRON_FILE"
  fi
}

kur() {
  if [[ "$PGCRON_OK" = "1" ]]; then
    info "pg_cron aktif → DB içi job kuruluyor"
    psql_q "select cron.unschedule(jobid) from cron.job where jobname='$JOB_NAME';" || true
    psql_q "select cron.schedule('$JOB_NAME', '15 4 * * *', \$\$select public.sifre_dogrulama_kodlarini_temizle();\$\$);"
    info "zamanlandı: her gün 04:15 (sunucu saati) · job='$JOB_NAME'"
  else
    warn "pg_cron kullanılamıyor (extension yok veya shared_preload_libraries'te değil)."
    warn "Host cron kuruluyor — bu da tamamen geçerlidir."
    command -v crontab >/dev/null 2>&1 || apt-get install -y cron >/dev/null 2>&1 || true
    cat > "$CRON_FILE" <<EOF
# İBYS · şifre doğrulama kodları periyodik temizliği (GUV-41)
# Kurulum: deploy/scripts/15_sifre_kod_temizlik_cron.sh
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
15 4 * * * root cd $SUPABASE_DIR && ${DC[*]} exec -T db psql -U $PGUSER -d $DB_NAME -q -c "select public.sifre_dogrulama_kodlarini_temizle();" >> $LOG_FILE 2>&1
EOF
    chmod 644 "$CRON_FILE"
    systemctl is-active --quiet cron || systemctl enable --now cron >/dev/null 2>&1 || true
    info "host cron kuruldu: $CRON_FILE"
  fi
}

case "$MODE" in
  kur|--kur|"")   kur; echo; durum ;;
  --durum|durum)  durum ;;
  --simdi|simdi)  simdi ;;
  --kaldir|kaldir) kaldir; echo; durum ;;
  *) die "Bilinmeyen parametre: $MODE (kur | --durum | --simdi | --kaldir)" ;;
esac

cat <<'EOF'

Doğrulama (rapora konacak):
  · `--durum` çıktısında job görünüyor mu?
  · `--simdi` çalıştırıldığında silinen satır sayısı dönüyor mu? (0 da geçerli)
  · 24 saat sonra tablo satır sayısı artmıyor mu?
EOF