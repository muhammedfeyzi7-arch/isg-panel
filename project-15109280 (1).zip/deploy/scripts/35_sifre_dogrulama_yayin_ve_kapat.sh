#!/usr/bin/env bash
# =============================================================================
# 35 · sifre-dogrulama Edge Function YAYINA ALMA + GUV-44 kapatma
# =============================================================================
# Nerede çalışır : SELF-HOSTED SUNUCU (supabase docker)
# Ön koşul       : /tmp/sifre-dogrulama-index.ts  (güncel fonksiyon kaynağı)
#
# Kullanım:
#   bash 35_sifre_dogrulama_yayin_ve_kapat.sh              # deploy + log modunda uçtan uca test
#   bash 35_sifre_dogrulama_yayin_ve_kapat.sh --dogrula     # salt-okur durum özeti (24-48s gözlem)
#   bash 35_sifre_dogrulama_yayin_ve_kapat.sh --enforce     # kapıyı kapat + kapatma provası
#   bash 35_sifre_dogrulama_yayin_ve_kapat.sh --log         # geri dönüş (enforce → log)
#
# NE YAPAR (sırayla):
#   1) Konteynerleri bulur (db / auth / functions)
#   2) Fonksiyon kaynağını doğrular: 'sifirla-degistir' aksiyonu içeriyor mu?
#   3) Mevcut fonksiyonu yedekler, yenisini kurar, functions'ı yeniden başlatır
#   4) CANLILIK: OPTIONS 200 + tokansız POST 401 (SESSION_EXPIRED) — 404 değil
#   5) UÇTAN UCA SIFIRLAMA TESTİ (posta göndermeden):
#        admin/generate_link(recovery) → /auth/v1/verify(recovery) → amr kontrolü
#        → fonksiyon `sifirla-degistir` → yeni şifreyle password grant
#      Bu, "şifremi unuttum" ekranının gerçekten çalıştığının kanıtıdır.
#   6) --enforce: GoTrue DB kullanıcısı kontrolü (postgres ise DURUR),
#      mod='enforce' yapar, uçtan uca testi TEKRAR koşar.
#      Test geçmezse otomatik olarak log moduna döner ve hata verir.
#
# Test kullanıcısı ve izin kayıtları sonunda temizlenir. Veri silinmez.
# =============================================================================
set -uo pipefail

SCRIPT_VERSION="guv44-release-2026-10-21-b"
SLUG="sifre-dogrulama"
SRC="${SRC:-/tmp/sifre-dogrulama-index.ts}"
SUPABASE_DIR="${SUPABASE_DIR:-/opt/ibys/supabase/docker}"
API="${API:-http://127.0.0.1:8000}"
BACKUP_DIR="${BACKUP_DIR:-/root/isg-yedek}"
APP_ORIGIN="${APP_ORIGIN:-https://app.isgdenetim.com.tr}"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

MODE="deploy"
case "${1:-}" in
  ""|--deploy|--yayinla) MODE="deploy" ;;
  --dogrula)  MODE="dogrula" ;;
  --enforce)  MODE="enforce" ;;
  --log)      MODE="log" ;;
  *) die "Bilinmeyen parametre: $1 (kullan: --dogrula | --enforce | --log)" ;;
esac

# ── Konteyner tespiti ───────────────────────────────────────────────────────
find_container() {
  docker ps --format '{{.Names}}' | grep -E "$1" | head -n1 || true
}
DB="${DB:-$(find_container '^supabase-db$|supabase-db')}"
DB="${DB:-$(find_container 'db')}"
AUTH="${AUTH:-$(find_container '^supabase-auth$|supabase-auth')}"
FUNCS="${FUNCS:-$(find_container 'supabase-functions|_functions_|functions-1')}"
FUNCS="${FUNCS:-$(find_container 'functions')}"

[[ -n "$DB" ]]    || die "DB konteyneri bulunamadı."
[[ -n "$FUNCS" ]] || die "functions konteyneri bulunamadı."

info "betik sürümü : $SCRIPT_VERSION"
info "konteynerler : db=$DB  auth=${AUTH:-?}  functions=$FUNCS"

psql_q()  { docker exec -i "$DB" psql -U postgres -d postgres -At -v ON_ERROR_STOP=1 -c "$1" 2>&1; }
mod_oku() { psql_q "select coalesce((select mod from public.sifre_kapisi_ayar where id),'yok');" | tr -d '[:space:]'; }

# ── --log: geri dönüş ───────────────────────────────────────────────────────
if [[ "$MODE" = "log" ]]; then
  psql_q "update public.sifre_kapisi_ayar set mod='log', guncellenme=now() where id;" >/dev/null \
    || die "Mod güncellenemedi."
  info "Mod → log (kapı yalnızca gözlemler)"
  exit 0
fi

# ── --dogrula: durum özeti ──────────────────────────────────────────────────
if [[ "$MODE" = "dogrula" ]]; then
  if [[ -f "$(dirname "${BASH_SOURCE[0]}")/34_f1_sifre_kapisi_deploy.sh" ]]; then
    exec bash "$(dirname "${BASH_SOURCE[0]}")/34_f1_sifre_kapisi_deploy.sh" --dogrula
  fi
  psql_q "\pset border 2
select mod, guncellenme from public.sifre_kapisi_ayar where id;
select count(*) as toplam_ihlal,
       count(*) filter (where olusma > now() - interval '24 hours') as son_24_saat
  from public.sifre_kapisi_ihlalleri;"
  exit 0
fi

# ── Ortam anahtarları ───────────────────────────────────────────────────────
ENVF="${SUPABASE_ENVF:-$SUPABASE_DIR/.env}"
if [[ -r "$ENVF" ]]; then
  SR="$(grep -hE '^SERVICE_ROLE_KEY=' "$ENVF" | tail -1 | cut -d= -f2- | tr -d '"'"'"'\r')"
  ANON="$(grep -hE '^ANON_KEY=' "$ENVF" | tail -1 | cut -d= -f2- | tr -d '"'"'"'\r')"
  info "env: $ENVF"
else
  warn "env dosyası okunamadı ($ENVF) — anahtarlar fonksiyonun kendi ortamından alınacak."
  SR="$(docker exec "$FUNCS" printenv SUPABASE_SERVICE_ROLE_KEY 2>/dev/null | tr -d '\r' || true)"
  ANON="$(docker exec "$FUNCS" printenv SUPABASE_ANON_KEY 2>/dev/null | tr -d '\r' || true)"
fi
[[ -n "${SR:-}" ]]   || die "SERVICE_ROLE_KEY bulunamadı."
[[ -n "${ANON:-}" ]] || die "ANON_KEY bulunamadı."

# ── GoTrue DB kullanıcısı (enforce için kritik) ─────────────────────────────
gt_user() {
  [[ -n "${AUTH:-}" ]] || return 1
  local u
  u="$(docker exec "$AUTH" printenv GOTRUE_DB_DATABASE_URL 2>/dev/null || true)"
  [[ -n "$u" ]] || return 1
  printf '%s' "$u" | sed -n 's#^[a-z]*://\([^:]*\).*#\1#p'
}
GT_USER="$(gt_user || true)"
if [[ -n "$GT_USER" ]]; then
  info "GoTrue DB kullanıcısı: $GT_USER"
else
  warn "GOTRUE_DB_DATABASE_URL okunamadı — enforce öncesi elle doğrulanmalı."
fi

# ── 1) Fonksiyon kaynağı ────────────────────────────────────────────────────
if [[ "$MODE" = "deploy" ]]; then
  [[ -s "$SRC" ]] || die "Fonksiyon kaynağı yok: $SRC
     Şu komutla gönderin:
       scp -P 23422 \"deploy\\edge-functions\\sifre-dogrulama\\index.ts\" root@SUNUCU:/tmp/sifre-dogrulama-index.ts"
  grep -q "sifirla-degistir" "$SRC" || die "Kaynakta 'sifirla-degistir' aksiyonu YOK — eski dosya gönderilmiş."
  info "kaynak doğrulandı: $(wc -l < "$SRC" | tr -d ' ') satır, 'sifirla-degistir' mevcut"

  FN_DIR="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/home/deno/functions"}}{{.Source}}{{end}}{{end}}' "$FUNCS")"
  [[ -n "$FN_DIR" ]] || die "functions konteynerinde /home/deno/functions mount'u yok."

  mkdir -p "$BACKUP_DIR"
  if [[ -d "$FN_DIR/$SLUG" ]]; then
    BK="$BACKUP_DIR/${SLUG}_$(date +%Y%m%d_%H%M%S)"
    cp -a "$FN_DIR/$SLUG" "$BK" 2>/dev/null && info "yedek: $BK"
  fi
  mkdir -p "$FN_DIR/$SLUG"
  install -m 644 "$SRC" "$FN_DIR/$SLUG/index.ts"
  info "kuruldu: $FN_DIR/$SLUG/index.ts"

  docker restart "$FUNCS" >/dev/null || die "functions yeniden başlatılamadı."
  info "functions yeniden başlatıldı"
else
  FN_DIR="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/home/deno/functions"}}{{.Source}}{{end}}{{end}}' "$FUNCS")"
fi

# ── 2) Mail ortam değişkenleri ──────────────────────────────────────────────
MAIL_STATE="$(docker exec "$FUNCS" sh -lc 'printenv | grep -E "^(RESEND_API_KEY|RESEND_FROM_DOMAIN|ALLOWED_ORIGINS)=" | sed "s/=.*/=<ayarli>/"' 2>/dev/null || true)"
if [[ -n "$MAIL_STATE" ]]; then
  info "mail/ortam değişkenleri:"; printf '%s\n' "$MAIL_STATE" | sed 's/^/     /'
else
  warn "RESEND_API_KEY / RESEND_FROM_DOMAIN görünmüyor → kod-gonder MAIL_NOT_CONFIGURED döner (sıfırlama yolu etkilenmez)."
fi

# ── 3) Canlılık ─────────────────────────────────────────────────────────────
info "canlılık kontrolü (/functions/v1/$SLUG)"
CODE_OPT=""
for _ in $(seq 1 12); do
  CODE_OPT="$(curl -s -o /dev/null -w '%{http_code}' -X OPTIONS "$API/functions/v1/$SLUG" -H "Origin: $APP_ORIGIN" || true)"
  [[ "$CODE_OPT" = "200" ]] && break
  sleep 2
done
[[ "$CODE_OPT" = "200" ]] || die "OPTIONS yanıtı $CODE_OPT (beklenen 200). Fonksiyon yüklenmemiş olabilir: docker logs $FUNCS --tail=50"
info "OPTIONS 200 (CORS ön kontrolü tamam)"

UNAUTH="$(curl -s -X POST "$API/functions/v1/$SLUG" \
  -H "apikey: $ANON" -H 'Content-Type: application/json' \
  -d '{"action":"sifirla-degistir","newPassword":"Guv35.Probe.Aa1#"}' || true)"
if printf '%s' "$UNAUTH" | grep -q 'SESSION_EXPIRED'; then
  info "tokansız istek → 401 SESSION_EXPIRED (fonksiyon yayında)"
else
  warn "tokansız istek beklenen yanıtı vermedi: $UNAUTH"
  printf '%s' "$UNAUTH" | grep -q 'no Route matched' && die "Kong fonksiyonu tanımıyor (404). functions servisi ayakta mı?"
fi

# ── 4) Uçtan uca şifre sıfırlama testi ──────────────────────────────────────
jget() { printf '%s' "$1" | sed -n "s/.*\"$2\":[[:space:]]*\"\([^\"]*\)\".*/\1/p" | head -1; }

jwt_amr() {
  local p
  p="$(printf '%s' "$1" | cut -d. -f2 | tr '_-' '/+')"
  while [ $(( ${#p} % 4 )) -ne 0 ]; do p="${p}="; done
  printf '%s' "$p" | base64 -d 2>/dev/null | sed -n 's/.*"amr":\(\[[^]]*\]\).*/\1/p'
}

E2E_UID=""; E2E_EMAIL=""; E2E_RESULT="FAIL"

cleanup_e2e() {
  if [[ -n "$E2E_UID" ]]; then
    curl -sS -o /dev/null -X DELETE "$API/auth/v1/admin/users/$E2E_UID" \
      -H "apikey: $SR" -H "Authorization: Bearer $SR" || true
  fi
}

run_e2e() {
  local ts email pass1 pass2 resp link th sess at amr out login http
  ts="$(date +%s)"
  email="guv35.e2e.${ts}@pentest.local"
  pass1="Guv35.Temp.${ts}.Aa1"
  pass2="Guv35.Yeni.${ts}.Bb2#"
  E2E_EMAIL="$email"

  resp="$(curl -s -X POST "$API/auth/v1/admin/users" \
    -H "apikey: $SR" -H "Authorization: Bearer $SR" -H 'Content-Type: application/json' \
    -d "{\"email\":\"$email\",\"password\":\"$pass1\",\"email_confirm\":true}")"
  E2E_UID="$(jget "$resp" id)"
  if [[ -z "$E2E_UID" ]]; then
    warn "test kullanıcısı oluşturulamadı: $resp"; E2E_RESULT="FAIL"; return 1
  fi
  printf '     %s· test kullanıcısı: %s%s\n' "$c_dim" "$E2E_UID" "$c_rst"

  # NEGATİF TEST (F1 bekçisi): normal PAROLA oturumu sıfırlama kapısını
  # kullanamamalı. 'otp' kabul edildiği için bu kontrol şart.
  local login pat neg
  login="$(curl -s -X POST "$API/auth/v1/token?grant_type=password" \
    -H "apikey: $ANON" -H 'Content-Type: application/json' \
    -d "{\"email\":\"$email\",\"password\":\"$pass1\"}")"
  pat="$(jget "$login" access_token)"
  if [[ -n "$pat" ]]; then
    neg="$(curl -s -X POST "$API/functions/v1/$SLUG" \
      -H "apikey: $ANON" -H "Authorization: Bearer $pat" -H 'Content-Type: application/json' \
      -d "{\"action\":\"sifirla-degistir\",\"newPassword\":\"$pass2\"}")"
    if printf '%s' "$neg" | grep -q 'FORBIDDEN'; then
      printf '     %s· negatif test: parola oturumu REDDEDİLDİ (F1 kapalı)%s\n' "$c_dim" "$c_rst"
    else
      warn "parola oturumu ile sifirla-degistir FORBIDDEN dönmedi: $neg"
      E2E_RESULT="FAIL"; return 1
    fi
  else
    warn "negatif test için parola oturumu kurulamadı: $login"
  fi

  # recovery bağlantısı üret (mail GÖNDERİLMEZ)
  link="$(curl -s -X POST "$API/auth/v1/admin/generate_link" \
    -H "apikey: $SR" -H "Authorization: Bearer $SR" -H 'Content-Type: application/json' \
    -d "{\"type\":\"recovery\",\"email\":\"$email\"}")"
  th="$(jget "$link" hashed_token)"
  if [[ -z "$th" ]]; then
    warn "generate_link hashed_token dönmedi: $link"; E2E_RESULT="FAIL"; return 1
  fi
  printf '     %s· recovery token üretildi%s\n' "$c_dim" "$c_rst"

  # token_hash ile recovery oturumu kur
  sess="$(curl -s -X POST "$API/auth/v1/verify" \
    -H "apikey: $ANON" -H 'Content-Type: application/json' \
    -d "{\"type\":\"recovery\",\"token_hash\":\"$th\"}")"
  at="$(jget "$sess" access_token)"
  if [[ -z "$at" ]]; then
    warn "recovery oturumu kurulamadı: $sess"; E2E_RESULT="FAIL"; return 1
  fi

  amr="$(jwt_amr "$at")"
  printf '     %s· JWT amr: %s%s\n' "$c_dim" "${amr:-?}" "$c_rst"
  # GoTrue sürüm farkı: bazı sürümler recovery oturumunu 'otp' olarak etiketler.
  # İkisi de e-posta sahipliğini kanıtlar; 'password' etiketi ASLA kabul edilmez.
  if ! printf '%s' "$amr" | grep -Eq '"recovery"|"otp"'; then
    warn "JWT'de recovery/otp metodu YOK → fonksiyon FORBIDDEN döner."
    E2E_RESULT="FAIL"; return 1
  fi

  # fonksiyonun sıfırlama yolu
  out="$(curl -s -X POST "$API/functions/v1/$SLUG" \
    -H "apikey: $ANON" -H "Authorization: Bearer $at" -H 'Content-Type: application/json' \
    -d "{\"action\":\"sifirla-degistir\",\"newPassword\":\"$pass2\"}")"
  printf '     %s· fonksiyon yanıtı: %s%s\n' "$c_dim" "$out" "$c_rst"
  if ! printf '%s' "$out" | grep -q '"ok":true'; then
    warn "sifirla-degistir başarısız. Kod/mesaj yukarıda."
    E2E_RESULT="FAIL"; return 1
  fi

  # yeni şifreyle giriş
  http="$(curl -s -o /dev/null -w '%{http_code}' -X POST "$API/auth/v1/token?grant_type=password" \
    -H "apikey: $ANON" -H 'Content-Type: application/json' \
    -d "{\"email\":\"$email\",\"password\":\"$pass2\"}")"
  if [[ "$http" != "200" ]]; then
    warn "yeni şifreyle giriş HTTP $http (beklenen 200)"; E2E_RESULT="FAIL"; return 1
  fi

  E2E_RESULT="PASS"
  return 0
}

if [[ "$MODE" = "deploy" || "$MODE" = "enforce" ]]; then
  echo
  if [[ "$MODE" = "enforce" ]]; then
    # ── Kapatma öncesi güvenlik kontrolleri ──────────────────────────────
    CUR="$(mod_oku)"
    [[ "$CUR" = "log" || "$CUR" = "enforce" ]] || die "GUV-44 kurulu değil (mod=$CUR)."
    if [[ -z "$GT_USER" ]]; then
      die "GoTrue DB kullanıcısı okunamadı. Elle doğrulayın: docker exec $AUTH printenv | grep GOTRUE_DB_DATABASE_URL"
    fi
    case "$GT_USER" in
      postgres|supabase_admin)
        die "GoTrue '$GT_USER' ile bağlanıyor → kapı onu atlar, enforce işe yaramaz.
     GOTRUE_DB_DATABASE_URL'i supabase_auth_admin ile düzeltin, sonra tekrar deneyin." ;;
    esac
    info "GoTrue ayrı bir DB kullanıcısıyla bağlanıyor ($GT_USER) → kapı devrede"
    psql_q "update public.sifre_kapisi_ayar set mod='enforce', guncellenme=now() where id;" >/dev/null \
      || die "Mod enforce yapılamadı."
    info "mod → enforce (şifre yazımı artık izinsiz REDDEDİLİR)"
  else
    info "mod korunuyor: $(mod_oku) (kapı henüz engellemiyor)"
  fi

  info "uçtan uca şifre sıfırlama testi başlıyor... (gerçek recovery oturumu)"
  if run_e2e; then
    info "UÇTAN UCA TEST: PASS — recovery oturumu + sifirla-degistir + yeni şifreyle giriş"
  else
    if [[ "$MODE" = "enforce" ]]; then
      warn "enforce altında test BAŞARISIZ → güvenli tarafa dönülüyor (log)"
      psql_q "update public.sifre_kapisi_ayar set mod='log', guncellenme=now() where id;" >/dev/null 2>&1 || true
      cleanup_e2e
      die "Kapatma iptal edildi, mod=log. Test çıktısını inceleyip bildirin."
    fi
    warn "uçtan uca test BAŞARISIZ (mod hâlâ log) — şifre sıfırlama yolu kontrol edilmeli."
  fi
  cleanup_e2e

  echo
  info "GUV-44 durum özeti"
  psql_q "select 'mod=' || mod from public.sifre_kapisi_ayar where id;"
  psql_q "select 'ihlal_toplam=' || count(*) from public.sifre_kapisi_ihlalleri;"
  psql_q "select 'aktif_izin=' || count(*) from public.sifre_degisim_izinleri where consumed_at is null and expires_at > now();"

  echo
  if [[ "$MODE" = "enforce" && "$E2E_RESULT" = "PASS" ]]; then
    info "KAPI KAPALI (enforce) ve sıfırlama yolu ÇALIŞIYOR."
    echo "  RAPOR SATIRI: GUV-44 davranış testi PASS; enforce modunda sifre-dogrulama/"
    echo "                sifirla-degistir uçtan uca başarılı (recovery oturumu → şifre → giriş)."
    echo "  Geri dönüş   : bash $0 --log"
    exit 0
  fi
  if [[ "$MODE" = "deploy" ]]; then
    echo "  Sırada:"
    echo "   1) 24-48 saat gözlem : bash $0 --dogrula"
    echo "   2) kapatma           : bash $0 --enforce"
    echo "  Geri dönüş           : bash $0 --log"
    exit 0
  fi
  exit 1
fi

if [[ "$MODE" = "dogrula" ]]; then exec bash "$0" --dogrula; fi
die "Beklenmeyen durum."