#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Veritabanı Taşıma: Kaynak (mevcut Supabase) -> Hedef (self-host Postgres)
#
# Çalıştırmadan önce ortam değişkenlerini export edin.
#
# KAYNAK (SaaS Supabase) → düz db.<ref>.supabase.co adresi IPv6'ya çözülüp
#   "Network is unreachable" verebilir. Bu yüzden IPv4 pooler kullanılır ve
#   kullanıcı adına proje ref'i eklenir (postgres.<ref>):
#     KAYNAK_DB_URL="postgresql://postgres.<ref>:<SIFRE>@aws-0-<region>.pooler.supabase.com:5432/postgres"
#
# HEDEF (bu sunucudaki self-host) → 5432 önünde Supavisor (pooler) durur ve
#   tenant kimliği ZORUNLUDUR (aksi halde "no tenant identifier" hatası).
#   Kullanıcı adı: postgres.<POOLER_TENANT_ID>  (tenant, docker/.env içinde yazılı)
#     HEDEF_DB_URL="postgresql://postgres.<POOLER_TENANT_ID>:<SIFRE>@127.0.0.1:5432/postgres"
#
# Not: pg_dump sürümü, kaynak Postgres sürümünden KÜÇÜK OLMAMALIDIR.
#      (Ubuntu 24.04 → pg_dump 16). Gerekirse: apt-get install postgresql-client-17
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

YEDEK_DIZIN="${YEDEK_DIZIN:-/opt/ibys/yedekler}"
KAYNAK_DB_URL="${KAYNAK_DB_URL:?KAYNAK_DB_URL tanimli degil}"
HEDEF_DB_URL="${HEDEF_DB_URL:?HEDEF_DB_URL tanimli degil}"

mkdir -p "${YEDEK_DIZIN}"
TARIH="$(date +%Y%m%d-%H%M%S)"
YEDEK="${YEDEK_DIZIN}/kaynak-${TARIH}.dump"

echo "==> 1/5  Kaynaktan TAM YEDEK alınıyor (sema + veri)"
pg_dump "${KAYNAK_DB_URL}" \
  --no-owner --no-privileges \
  --schema=public --schema=auth --schema=storage \
  -Fc -f "${YEDEK}"
# --schema=auth  → kullanıcılar / oturum verisi
# --schema=storage → storage.objects kayıtları (dosyaların kendisi 03-storage-tasi.mjs ile)
#
# ⚠ --no-privileges: kaynak SaaS'taki geniş ACL'leri taşımıyoruz. BEDELİ ŞUDUR:
#   hedefte HİÇBİR GRANT oluşmaz — ne tablo/sequence yetkisi ne de
#   ALTER DEFAULT PRIVILEGES. Bu yüzden aşağıdaki 3. adım ZORUNLUDUR ve
#   doğrulanmadan taşıma bitmiş sayılmaz (bkz. GUV-34).

echo "    Yedek: ${YEDEK}  ($(du -h "${YEDEK}" | cut -f1))"

echo "==> 2/5  Hedefe geri yükleniyor"
# --clean: mevcut objeleri temizleyip yeniden oluşturur.
# Tetikleyici kısıtı hatası alırsanız --disable-triggers ekleyip superuser ile çalıştırın.
pg_restore \
  --no-owner --no-privileges \
  --clean --if-exists \
  -d "${HEDEF_DB_URL}" "${YEDEK}" || true

echo "==> 3/5  Yetki düzeltmeleri"
# 🔴 BURADA '|| true' KULLANILMAZ. Eski sürümde vardı ve grant'ler sessizce
#    atlandı; sonuç: 175 tabloda service_role yetkisiz kaldı, Edge Function'lar
#    42501 'permission denied' aldı, kimse fark etmedi (GUV-34).
#    Yetki hatası = taşıma BAŞARISIZ. Script durmalı.
psql "${HEDEF_DB_URL}" -v ON_ERROR_STOP=1 <<'SQL'
GRANT ALL ON SCHEMA public TO postgres;
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- anon/authenticated: RLS'in yönettiği 4 yetki (GUV-17 duruşu).
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO anon, authenticated;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO anon, authenticated;

-- service_role: Edge Function'ların tek rollü. Tablo + sequence + RPC.
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO service_role;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO service_role;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO service_role;

-- Varsayılan yetkiler: BUNDAN SONRA yaratılan nesneler de yetkili doğmalı.
-- pg_dump --no-privileges bunları taşımadığı için açıkça kurulur.
DO $$
DECLARE rol text;
BEGIN
  FOREACH rol IN ARRAY ARRAY['postgres', 'supabase_admin']
  LOOP
    BEGIN
      EXECUTE format('ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                     'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO anon, authenticated', rol);
      EXECUTE format('ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                     'GRANT USAGE, SELECT ON SEQUENCES TO anon, authenticated', rol);
      EXECUTE format('ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                     'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO service_role', rol);
      EXECUTE format('ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                     'GRANT USAGE, SELECT ON SEQUENCES TO service_role', rol);
      EXECUTE format('ALTER DEFAULT PRIVILEGES FOR ROLE %I IN SCHEMA public '
                     'GRANT EXECUTE ON FUNCTIONS TO service_role', rol);
    EXCEPTION WHEN insufficient_privilege THEN
      RAISE WARNING '% icin varsayilan yetki yazilamadi (yetki yok)', rol;
    END;
  END LOOP;
END $$;

NOTIFY pgrst, 'reload schema';
SQL

echo "==> 4/5  Yetki doğrulaması (service_role)"
# Taşıma 'tamam' demeden önce ölçüyoruz. 0 dönmezse script hata ile çıkar.
EKSIK_TABLO="$(psql "${HEDEF_DB_URL}" -tA -c "
  WITH t AS MATERIALIZED (
    SELECT c.oid FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public' AND c.relkind IN ('r','p'))
  SELECT count(*) FROM t
   WHERE NOT (has_table_privilege('service_role', t.oid, 'SELECT')
          AND has_table_privilege('service_role', t.oid, 'INSERT')
          AND has_table_privilege('service_role', t.oid, 'UPDATE')
          AND has_table_privilege('service_role', t.oid, 'DELETE'));")"

# NOT: MATERIALIZED CTE ŞART — alt sorgu YETMİYOR. PostgreSQL alt sorguyu
# flatten edip fonksiyonu relkind filtresinden önce değerlendirebiliyor;
# has_sequence_privilege() bir TOAST tablosu OID'i alınca
# "pg_toast_xxx is not a sequence" hatası verir ve script set -e ile düşer.
EKSIK_SEQ="$(psql "${HEDEF_DB_URL}" -tA -c "
  WITH s AS MATERIALIZED (
    SELECT c.oid FROM pg_class c
    JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public' AND c.relkind = 'S')
  SELECT count(*) FROM s
   WHERE NOT has_sequence_privilege('service_role', s.oid, 'USAGE');")"

if [ "${EKSIK_TABLO}" != "0" ] || [ "${EKSIK_SEQ}" != "0" ]; then
  echo "🔴 HATA: service_role yetkisi eksik — tablo=${EKSIK_TABLO} sequence=${EKSIK_SEQ}"
  echo "   Bu durumda Edge Function'lar 42501 'permission denied' ile duser."
  echo "   Cozum: supabase/migrations/20260101002500_guv34_service_role_grants_repair.sql"
  exit 1
fi
echo "    OK: service_role tum public tablo/sequence icin yetkili"

echo "==> 5/5  Doğrulama (satır sayıları)"
psql "${HEDEF_DB_URL}" -c "\dt public.*" | tail -n +3 | head -n 20

echo ""
echo "TAMAM. Sırada:"
echo "  - storage container'ını yeniden başlat: cd /opt/ibys/supabase/docker && docker compose restart storage auth"
echo "  - Storage dosyalarını taşı: node deploy/scripts/03-storage-tasi.mjs"