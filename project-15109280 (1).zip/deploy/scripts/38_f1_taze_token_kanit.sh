#!/usr/bin/env bash
# =============================================================================
# 38 · F1 · "TAZE TOKEN PENCERESİ" KANITI  (HTTP seviyesinde gerçek saldırı)
# =============================================================================
# NEREDE ÇALIŞIR : SELF-HOSTED SUNUCU (docker + api.isgdenetim.com.tr yanı)
#
# SORUNUN TANIMI
#   F1'in kapanışı "GOTRUE_SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION=true"
#   ile değil, GUV-44 (auth.users.encrypted_password BEFORE UPDATE kapısı) ile olur.
#   Çünkü GoTrue'nun `/auth/v1/reauthenticate` ucu, ele geçirilmiş bir oturum
#   belirteciyle de çağrılabiliyor: saldırgan nonce'u kendisi tetikleyebilir.
#
#   GUV-44 kapısı ise HTTP yolundan bağımsız çalışır: GoTrue `supabase_auth_admin`
#   ile bağlanır, session_user operatör istisnasına girmez, izin yoksa yazım
#   reddedilir. Yani "taze token" fark etmez.
#
#   TEK EKSİK: kapı varsayılan olarak 'log' modunda kurulur (hiçbir şeyi engellemez).
#   Bu betik (a) modu enforce yapar, (b) GERÇEK saldırıyı HTTP üzerinden dener,
#   (c) şifrenin gerçekten değişmediğini ispatlar.
#
# KULLANIM
#   bash deploy/scripts/38_f1_taze_token_kanit.sh            # tam test (geçici kullanıcı)
#   bash deploy/scripts/38_f1_taze_token_kanit.sh --dogrula  # sadece durum
#   bash deploy/scripts/38_f1_taze_token_kanit.sh --enforce  # modu zorunlu kıl
#   bash deploy/scripts/38_f1_taze_token_kanit.sh <eposta> '<sifre>'
#        → mevcut test hesabıyla dener (hesap SİLİNMEZ, şifresi değişmez)
#
# KANIT
#   /root/pentest-kanit/F1_taze_token_<stamp>.log   (tam çıktı)
#   /root/pentest-kanit/F1_TAZE_TOKEN_PASS_<stamp>.txt  (sadece PASS ise, arşiv satırı)
#
# GERİ DÖNÜŞ : bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh --log
# =============================================================================
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="${REPO_ROOT:-$(cd "$SCRIPT_DIR/../.." && pwd)}"
SUPABASE_DIR="${SUPABASE_DIR:-/opt/ibys/supabase/docker}"
ENVF="${SUPABASE_ENVF:-$SUPABASE_DIR/.env}"
API="${API:-http://127.0.0.1:8000}"
DB_CONTAINER="${DB_CONTAINER:-supabase-db}"
PGUSER="${PGUSER:-postgres}"
DB_NAME="${DB_NAME:-postgres}"
OUT_DIR="${OUT_DIR:-/root/pentest-kanit}"
STAMP="$(date +%Y%m%d-%H%M)"
OUT_LOG="$OUT_DIR/F1_taze_token_$STAMP.log"
PASS_FILE="$OUT_DIR/F1_TAZE_TOKEN_PASS_$STAMP.txt"

c_grn=$'\e[32m'; c_red=$'\e[31m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
ok()   { printf '%s %s\n' "${c_grn}PASS${c_rst}" "$*"; }
bad()  { printf '%s %s\n' "${c_red}FAIL${c_rst}" "$*"; }
atla() { printf '%s %s\n' "${c_yel}SKIP${c_rst}" "$*"; }
info() { printf '\n%s\n' "${c_yel}==>${c_rst} $*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

MODE="test"
case "${1:-}" in
  --dogrula) MODE="dogrula" ;;
  --enforce) MODE="enforce" ;;
  --test|"") MODE="test" ;;
  -*) die "bilinmeyen parametre: $1" ;;
  *) MODE="test" ;;
esac
HESAP_EPOSTA="${1:-}"
HESAP_SIFRE="${2:-}"
[[ "$HESAP_EPOSTA" == --* ]] && HESAP_EPOSTA=""

mkdir -p "$OUT_DIR"
exec > >(tee "$OUT_LOG") 2>&1

echo "════════════════════════════════════════════════════════════════════"
echo "  F1 · taze token penceresi · HTTP seviyesinde kanıt"
echo "  Tarih : $(date '+%Y-%m-%d %H:%M:%S')"
echo "  API   : $API"
echo "  Mod   : $MODE"
echo "════════════════════════════════════════════════════════════════════"

env_get() {
  [[ -r "$ENVF" ]] || return 0
  grep -hE "^$1=" "$ENVF" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'" | tr -d '\r'
}
ANON="$(env_get ANON_KEY)"
[[ -z "$ANON" ]] && ANON="$(env_get SUPABASE_ANON_KEY)"
[[ -z "$ANON" ]] && ANON="$(env_get PUBLISHABLE_KEY)"
SR="$(env_get SERVICE_ROLE_KEY)"
[[ -z "$ANON" ]] && die "ANON_KEY okunamadı ($ENVF)"

db_var() { docker ps --format '{{.Names}}' 2>/dev/null | grep -qx "$DB_CONTAINER"; }
psql_at() { docker exec -i "$DB_CONTAINER" psql -U "$PGUSER" -d "$DB_NAME" -At -c "$1" 2>/dev/null; }

mod_oku() {
  if db_var; then psql_at "select coalesce((select mod from public.sifre_kapisi_ayar where id),'yok');" | tr -d '[:space:]'; else printf 'bilinmiyor'; fi
}
kapi_var() {
  if db_var; then psql_at "select count(*) from pg_trigger where tgrelid='auth.users'::regclass and tgname='trg_auth_users_sifre_kapisi' and not tgisinternal;"; else printf '?'; fi
}

# ── Durum ───────────────────────────────────────────────────────────────────
if [[ "$MODE" = "dogrula" ]]; then
  info "GUV-44 kapı durumu"
  echo "  trigger : $(kapi_var) (beklenen 1)"
  echo "  mod     : $(mod_oku)"
  M="$(mod_oku)"
  if [[ "$M" = "enforce" ]]; then
    ok "kapı ZORUNLU modda — taze token şifre yazımı reddedilir"
    exit 0
  fi
  bad "kapı '$M' modunda — F1 hâlâ AÇIK. Kapatmak için: bash $0 --enforce"
  exit 1
fi

if [[ "$MODE" = "enforce" ]]; then
  db_var || die "$DB_CONTAINER çalışmıyor — mod değiştirilemez."
  [[ "$(kapi_var)" = "1" ]] || die "GUV-44 trigger'ı yok. Önce: bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh"

  # GoTrue 'postgres'/'supabase_admin' ile bağlanıyorsa kapı onu atlar → enforce boş.
  AUTH_CONTAINER="${AUTH_CONTAINER:-supabase-auth}"
  GT_DB="$(docker exec "$AUTH_CONTAINER" printenv GOTRUE_DB_DATABASE_URL 2>/dev/null || true)"
  if [[ -n "$GT_DB" ]]; then
    GT_USER="$(printf '%s' "$GT_DB" | sed -n 's#^[a-z]*://\([^:]*\).*#\1#p')"
    echo "  GoTrue DB kullanıcısı: ${GT_USER:-bilinmiyor}"
    case "$GT_USER" in
      postgres|supabase_admin)
        die "GoTrue '$GT_USER' ile bağlanıyor → kapı atlanır. GOTRUE_DB_DATABASE_URL'i supabase_auth_admin yapın." ;;
    esac
  else
    atla "GOTRUE_DB_DATABASE_URL okunamadı — auth DB kullanıcısını elle teyit edin"
  fi

  psql_at "update public.sifre_kapisi_ayar set mod='enforce', guncellenme=now() where id;" >/dev/null \
    || die "mod güncellenemedi"
  ok "mod: enforce (şifre yazımı artık izinsiz REDDEDİLİR)"
  warn_geri() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
  warn_geri "geri dönüş: bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh --log"
  exit 0
fi

# ── Tam test ────────────────────────────────────────────────────────────────
[[ -n "$SR" ]] || die "SERVICE_ROLE_KEY okunamadı ($ENVF) — geçici kullanıcı oluşturulamaz."

P1="F1taze.Bir.$(date +%s).Aa1"
P2="F1taze.Iki.$(date +%s).Bb2"
TS="$(date +%s)"
GECICI=0
if [[ -z "$HESAP_EPOSTA" ]]; then
  HESAP_EPOSTA="f1.taze.${TS}@pentest.local"
  HESAP_SIFRE="$P1"
  GECICI=1
fi
UID_=""

cleanup() {
  if [[ "$GECICI" = "1" && -n "$UID_" ]]; then
    curl -sS -o /dev/null -X DELETE "$API/auth/v1/admin/users/$UID_" \
      -H "apikey: $SR" -H "Authorization: Bearer $SR" 2>/dev/null || true
    echo "  geçici kullanıcı silindi"
  fi
}
trap cleanup EXIT

# ── 1) kapı gerçekten kapalı mı ─────────────────────────────────────────────
info "1/5 · Kapı durumu"
KAPI="$(kapi_var)"; MOD="$(mod_oku)"
echo "  trigger=$KAPI · mod=$MOD"
if [[ "$KAPI" != "1" ]]; then
  bad "GUV-44 trigger'ı YOK — F1 kapalı sayılamaz"
  exit 1
fi
if [[ "$MOD" != "enforce" ]]; then
  bad "mod '$MOD' — kapı sadece gözlemliyor. Önce: bash $0 --enforce"
  echo "  (Bu betik kanıt üretmez, çünkü bu haldeyken saldırı GERÇEKTEN başarılı olur.)"
  exit 1
fi
ok "trigger kurulu + mod enforce"

# ── 2) hesap ────────────────────────────────────────────────────────────────
if [[ "$GECICI" = "1" ]]; then
  info "2/5 · Geçici kullanıcı oluşturuluyor"
  RESP="$(curl -sS -X POST "$API/auth/v1/admin/users" \
    -H "apikey: $SR" -H "Authorization: Bearer $SR" -H 'Content-Type: application/json' \
    -d "{\"email\":\"$HESAP_EPOSTA\",\"password\":\"$HESAP_SIFRE\",\"email_confirm\":true}" 2>/dev/null || true)"
  UID_="$(printf '%s' "$RESP" | sed -n 's/.*"id":[[:space:]]*"\([0-9a-f-]\{36\}\)".*/\1/p' | head -1)"
  [[ -n "$UID_" ]] || die "geçici kullanıcı oluşturulamadı: $(printf '%s' "$RESP" | head -c 300)"
  ok "kullanıcı: $UID_"
else
  info "2/5 · Mevcut test hesabı kullanılıyor: $HESAP_EPOSTA"
  echo "  ${c_dim}(şifresi değişmeyecek; sadece değiştirme DENEMESİ yapılır)${c_rst}"
fi

# ── 3) taze giriş → taze token ──────────────────────────────────────────────
info "3/5 · Taze giriş (saldırganın ele geçirdiği senaryo)"
TOK_JSON="$(curl -sS -X POST "$API/auth/v1/token?grant_type=password" \
  -H "apikey: $ANON" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$HESAP_EPOSTA\",\"password\":\"$HESAP_SIFRE\"}" 2>/dev/null || true)"
TOK="$(printf '%s' "$TOK_JSON" | sed -n 's/.*"access_token":"\([^"]*\)".*/\1/p' | head -1)"
[[ -n "$TOK" ]] || die "giriş başarısız — mevcut şifre hatalı olabilir: $(printf '%s' "$TOK_JSON" | head -c 250)"
ok "taze oturum belirteci alındı"

# ── 4) SALDIRI: taze token + doğrudan şifre yazımı ──────────────────────────
info "4/5 · SALDIRI — GET /auth/v1/user (PUT) ile şifre değiştirme denemesi"
HTTP="$(curl -sS -o /tmp/f1_attack.json -w '%{http_code}' -X PUT "$API/auth/v1/user" \
  -H "apikey: $ANON" -H "Authorization: Bearer $TOK" -H 'Content-Type: application/json' \
  -d "{\"password\":\"$P2\"}" 2>/dev/null || echo 000)"
BODY="$(cat /tmp/f1_attack.json 2>/dev/null | head -c 400)"
echo "  HTTP $HTTP · yanıt: $BODY"

if [[ "$HTTP" = "200" ]]; then
  bad "GoTrue isteği KABUL ETTİ (HTTP 200) — kapı devrede değil"
else
  ok "istek reddedildi (HTTP $HTTP)"
fi
if printf '%s' "$BODY" | grep -qi 'PASSWORD_REAUTH_REQUIRED\|reauthentication_needed\|reauth'; then
  ok "ret sebebi doğrulama kapısı (PASSWORD_REAUTH_REQUIRED / reauthentication_needed)"
else
  atla "ret gövdesinde kapı etiketi yok — asıl kanıt aşağıdaki şifre kontrolü"
fi

# ── 5) KESİN KANIT: şifre gerçekten değişti mi? ─────────────────────────────
info "5/5 · Şifre gerçekten değişti mi? (asıl kanıt)"
ESKI_JSON="$(curl -sS -X POST "$API/auth/v1/token?grant_type=password" \
  -H "apikey: $ANON" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$HESAP_EPOSTA\",\"password\":\"$HESAP_SIFRE\"}" 2>/dev/null || true)"
ESKI_OK=0
printf '%s' "$ESKI_JSON" | grep -q '"access_token"' && ESKI_OK=1

YENI_JSON="$(curl -sS -X POST "$API/auth/v1/token?grant_type=password" \
  -H "apikey: $ANON" -H 'Content-Type: application/json' \
  -d "{\"email\":\"$HESAP_EPOSTA\",\"password\":\"$P2\"}" 2>/dev/null || true)"
YENI_OK=0
printf '%s' "$YENI_JSON" | grep -q '"access_token"' && YENI_OK=1

[[ "$ESKI_OK" = "1" ]] && ok "eski şifre HÂLÂ ÇALIŞIYOR → yazım gerçekleşmedi" \
  || bad "eski şifre çalışmıyor — şifre DEĞİŞMİŞ olabilir!"
[[ "$YENI_OK" = "0" ]] && ok "saldırganın yeni şifresi ÇALIŞMIYOR → hesap ele geçirilmedi" \
  || bad "saldırganın yeni şifresi çalışıyor — HESAP ELE GEÇİRİLDİ!"

echo
echo "════════════════════════════════════════════════════════════════════"
if [[ "$ESKI_OK" = "1" && "$YENI_OK" = "0" ]]; then
  echo "${c_grn}SONUÇ: F1 PASS${c_rst} — taze token ile doğrudan şifre yazımı etkisiz."
  {
    echo "BULGU=F1"
    echo "DURUM=PASS"
    echo "MOD=enforce"
    echo "TEST=taze token + PUT /auth/v1/user password -> sifre degismedi"
    echo "HTTP=$HTTP"
    echo "KANIT=eski sifre calisiyor, saldirganin sifresi calismiyor"
    echo "TARIH=$(date '+%Y-%m-%d %H:%M:%S')"
  } > "$PASS_FILE"
  echo "Kanıt dosyası : $OUT_LOG"
  echo "Arşiv satırı  : $PASS_FILE"
  echo
  echo "  Rapora girecek cümle:"
  echo "  \"F1 · GUV-44 kapısı enforce modda. Taze oturum belirteciyle"
  echo "   PUT /auth/v1/user {\"password\":...} denemesi HTTP $HTTP ile reddedildi;"
  echo "   eski şifre çalışmaya devam etti. Taze token penceresi kapalı.\""
  exit 0
fi

echo "${c_red}SONUÇ: F1 KALDI${c_rst} — yukarıdaki iddialardan biri tutmadı."
echo "  Teşhis: bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh --dogrula"
echo "  Log   : docker logs supabase-db 2>&1 | grep GUV44_"
echo "Kanıt dosyası: $OUT_LOG"
exit 1