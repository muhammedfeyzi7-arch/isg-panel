#!/usr/bin/env bash
# =============================================================================
# 13 · sifre-dogrulama Edge Function + GUV-40 / GUV-41 / GUV-42 migration deploy
# =============================================================================
# Nerede çalışır : SELF-HOSTED SUNUCU (Supabase docker compose dizini)
# Nasıl çalışır  : bash 13_sifre_dogrulama_deploy.sh [/root/isg-deploy]
# Ön koşul       : Aynı dizinde şu 4 dosya olmalı
#                    index.ts
#                    20260101002800_guv40_sifre_gecmisi.sql
#                    20260101002900_guv41_sifre_kodlari.sql
#                    20260101003000_guv42_sifre_kodu_atomik.sql
# Ortam          : SUPABASE_DIR=/opt/ibys/supabase/docker  (gerekirse override)
#
# Yaptığı işlem sırası (hepsi geri alınabilir):
#   1) Ön kontroller (dosya var mı, compose var mı, konteyner çalışıyor mu)
#   2) pg_dump ile TAM yedek  → /root/isg-yedek/
#   3) GUV-40 migration      (şifre geçmişi + atomik güncelleme)
#   4) GUV-41 migration      (doğrulama kodları tablosu)
#   5) GUV-42 migration      (atomik kod doğrulama/tüketim + tek kullanım)
#   6) Doğrulama sorguları   (tablo + yetki kontrolü, salt okunur)
#   7) index.ts → volumes/functions/sifre-dogrulama/index.ts
#   8) functions servisini yeniden başlatma + log
#
# YIKICI HİÇBİR İŞLEM YAPMAZ: DROP/TRUNCATE yok, veri silinmez.
# Geri dönüş: deploy/README veya SECURITY_FAZ11_...md "Geri dönüş" bölümü.
# =============================================================================
set -euo pipefail

SRC_DIR="${1:-/root/isg-deploy}"
SUPABASE_DIR="${SUPABASE_DIR:-/opt/ibys/supabase/docker}"
SLUG="sifre-dogrulama"
BACKUP_DIR="/root/isg-yedek"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
die()  { printf '%s\n' "${c_red}HATA:${c_rst} $*" >&2; exit 1; }

FUNC_SRC="$SRC_DIR/index.ts"
SQL1="$SRC_DIR/20260101002800_guv40_sifre_gecmisi.sql"
SQL2="$SRC_DIR/20260101002900_guv41_sifre_kodlari.sql"
SQL3="$SRC_DIR/20260101003000_guv42_sifre_kodu_atomik.sql"

info "1/8 Ön kontroller"
for f in "$FUNC_SRC" "$SQL1" "$SQL2" "$SQL3"; do
  [[ -s "$f" ]] || die "Dosya bulunamadı veya boş: $f"
done

if [[ ! -f "$SUPABASE_DIR/docker-compose.yml" ]]; then
  for d in /opt/ibys/supabase/docker /opt/supabase/docker /root/supabase/docker /srv/supabase/docker; do
    if [[ -f "$d/docker-compose.yml" ]]; then SUPABASE_DIR="$d"; break; fi
  done
fi
[[ -f "$SUPABASE_DIR/docker-compose.yml" ]] || die "docker-compose.yml bulunamadı. SUPABASE_DIR=/dogru/yol şeklinde ver."
cd "$SUPABASE_DIR"
info "compose dizini: $SUPABASE_DIR"

if docker compose version >/dev/null 2>&1; then
  DC=(docker compose)
elif command -v docker-compose >/dev/null 2>&1; then
  DC=(docker-compose)
else
  die "docker compose bulunamadı."
fi

DB_ID="$("${DC[@]}" ps -q db 2>/dev/null | head -n1 || true)"
[[ -n "$DB_ID" ]] || die "db konteyneri çalışmıyor. Önce: docker compose up -d db"

FN_ID="$("${DC[@]}" ps -q functions 2>/dev/null | head -n1 || true)"
[[ -n "$FN_ID" ]] || die "functions konteyneri çalışmıyor. Önce: docker compose up -d functions"

info "2/8 Veritabanı yedeği alınıyor (bu birkaç dakika sürebilir)"
mkdir -p "$BACKUP_DIR"
BK="$BACKUP_DIR/pre_guv40_$(date +%Y%m%d_%H%M%S).dump"
"${DC[@]}" exec -T db pg_dump -U postgres -d postgres -Fc > "$BK"
[[ -s "$BK" ]] || die "Yedek alınamadı: $BK"
info "yedek: $BK ($(du -h "$BK" | cut -f1))"

info "3/8 GUV-40 uygulanıyor (şifre geçmişi + atomik şifre güncelleme)"
base1="$(basename "$SQL1")"
docker cp "$SQL1" "$DB_ID:/tmp/$base1"
"${DC[@]}" exec -T db psql -U postgres -d postgres -v ON_ERROR_STOP=1 -f "/tmp/$base1"

info "4/8 GUV-41 uygulanıyor (doğrulama kodları tablosu)"
base2="$(basename "$SQL2")"
docker cp "$SQL2" "$DB_ID:/tmp/$base2"
"${DC[@]}" exec -T db psql -U postgres -d postgres -v ON_ERROR_STOP=1 -f "/tmp/$base2"

info "5/8 GUV-42 uygulanıyor (atomik kod doğrulama + tek kullanımlık kod)"
base3="$(basename "$SQL3")"
docker cp "$SQL3" "$DB_ID:/tmp/$base3"
"${DC[@]}" exec -T db psql -U postgres -d postgres -v ON_ERROR_STOP=1 -f "/tmp/$base3"

info "6/8 Doğrulama sorguları (salt okunur)"
"${DC[@]}" exec -T db psql -U postgres -d postgres -c "
select extname, extnamespace::regnamespace as sema
  from pg_extension where extname = 'pgcrypto';"
warn "pgcrypto'nun sema değeri 'extensions' olmalı. Farklıysa migration'daki extensions.crypt çağrıları hata verir."
"${DC[@]}" exec -T db psql -U postgres -d postgres -c "
select table_name from information_schema.tables
 where table_schema='public'
   and table_name in ('password_history','sifre_dogrulama_kodlari')
 order by table_name;"
"${DC[@]}" exec -T db psql -U postgres -d postgres -c "
select grantee, table_name, privilege_type
  from information_schema.role_table_grants
 where table_name in ('password_history','sifre_dogrulama_kodlari')
   and grantee in ('anon','authenticated');"
warn "Üstteki yetki sorgusu 0 satır dönmeli. Satır döndüyse DUR ve bildir."
"${DC[@]}" exec -T db psql -U postgres -d postgres -c "
select proname, proacl from pg_proc
 where proname in ('sifre_guncelle_atomik','sifre_dogrulama_kodlarini_temizle','sifre_kodu_ile_degistir');"
warn "sifre_kodu_ile_degistir satırı görünmeli; proacl içinde anon/authenticated OLMAMALI (yalnızca service_role)."

info "7/8 Edge Function kopyalanıyor"
FN_DIR="$(docker inspect -f '{{range .Mounts}}{{if eq .Destination "/home/deno/functions"}}{{.Source}}{{end}}{{end}}' "$FN_ID")"
[[ -n "$FN_DIR" ]] || die "functions konteynerinde /home/deno/functions mount'u bulunamadı."
mkdir -p "$FN_DIR/$SLUG"
install -m 644 "$FUNC_SRC" "$FN_DIR/$SLUG/index.ts"
info "hedef: $FN_DIR/$SLUG/index.ts"

RESEND_STATE="$("${DC[@]}" exec -T functions sh -lc 'printenv | grep -E "^(RESEND_API_KEY|RESEND_FROM_DOMAIN|ALLOWED_ORIGINS)=" | sed "s/=.*/=<ayarli>/"' || true)"
if [[ -n "$RESEND_STATE" ]]; then
  info "mail ortam değişkenleri:"
  printf '%s\n' "$RESEND_STATE"
else
  warn "RESEND_API_KEY / RESEND_FROM_DOMAIN functions konteynerinde GÖRÜNMÜYOR."
  warn "Bu durumda fonksiyon MAIL_NOT_CONFIGURED döner (yanlış başarı göstermez)."
fi

info "8/8 functions servisi yeniden başlatılıyor"
"${DC[@]}" restart functions >/dev/null
sleep 6
"${DC[@]}" logs --tail=40 functions || true

cat <<EOF

${c_grn}Tamamlandı.${c_rst}
  Yedek            : $BK
  Migration        : GUV-40, GUV-41, GUV-42
  Edge Function    : $FN_DIR/$SLUG/index.ts
  Konteyner        : functions (yeniden başlatıldı)

Sırada:
  1) Tarayıcıda Ctrl+Shift+R ile sert yenile
  2) Şifre değiştirme formunu test et (kod e-postaya gelmeli)
  3) Kod gelmezse: fonksiyon yanıtındaki kodu kontrol et (MAIL_NOT_CONFIGURED / MAIL_SEND_FAILED)

Geri dönüş:
  bash deploy/scripts/rollback_sifre_dogrulama.sh   (varsa)
  veya: rm -rf "$FN_DIR/$SLUG" && ${DC[*]} restart functions
EOF