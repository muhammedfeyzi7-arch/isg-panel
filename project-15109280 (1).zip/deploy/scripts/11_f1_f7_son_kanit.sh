#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════
# PENTEST 2026-10-19 · F1 + F7 SON KANIT
#
# Amaç: iki bulgunun da "gerçekten çalışıyor" kanıtını tek koşuda üretmek.
#
#   F7  → GoTrue'nun Türkçe karakteri BOZMADAN yazdığını gösterir.
#         Test hesabı user_metadata.last_name = "Aktaş" ile oluşturulur,
#         DB'den geri okunur, UTF-8 baytları hex olarak karşılaştırılır.
#         Beklenen hex: 41 6b 74 61 c5 9f  ("Aktaş")
#         Bozuk olsaydı: 41 6b 74 61 c3 85 c2 9f  ("AktaÅ\x9F")
#
#   F1  → deploy/scripts/09_f1_retest.sh'i çağırır (--eskit ile), sonucu
#         raporlar ve ARDINDAN oturum zamanlarını otomatik geri alır.
#
# Kullanım (sunucuda, /opt/ibys/supabase/docker içinde):
#   bash 11_f1_f7_son_kanit.sh
#   bash 11_f1_f7_son_kanit.sh --f7-only
#   bash 11_f1_f7_son_kanit.sh --f1-only
#   bash 11_f1_f7_son_kanit.sh --temizle      # test hesabını sil
#
# Not: F1 adımı mevcut bir oturumun created_at'ini geçici olarak 3 gün geriye
#      çeker ve sonunda düzeltir. Sadece test ortamında çalıştırın.
# ═══════════════════════════════════════════════════════════════════════════
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DOCKER_DIR="${DOCKER_DIR:-/opt/ibys/supabase/docker}"
F7_EMAIL="${F7_EMAIL:-f7.retest@ornek.com}"
F7_PW="${F7_PW:-Gecerli.Sifre.2026Aa9}"
F7_AD="${F7_AD:-Ayşe}"
F7_SOYAD="${F7_SOYAD:-Aktaş}"
BEKLENEN_HEX="416b7461c59f"

ONLY_F1=0
ONLY_F7=0
TEMIZLE=0

for ARG in "$@"; do
  case "$ARG" in
    --f1-only) ONLY_F1=1 ;;
    --f7-only) ONLY_F7=1 ;;
    --temizle) TEMIZLE=1 ;;
    -h|--help) sed -n '2,26p' "$0"; exit 0 ;;
    *) echo "❌ Bilinmeyen parametre: $ARG"; exit 2 ;;
  esac
done

if [ ! -d "$DOCKER_DIR" ]; then
  echo "❌ Docker dizini bulunamadı: $DOCKER_DIR"
  echo "   Sunucuda mısın?  ssh -p 23422 root@srv.ibys-prod.com"
  exit 1
fi
cd "$DOCKER_DIR" || exit 1

command -v python3 >/dev/null 2>&1 || { echo "❌ python3 gerekli."; exit 1; }
command -v curl    >/dev/null 2>&1 || { echo "❌ curl gerekli."; exit 1; }

env_al() {
  grep -hE "^[[:space:]]*$1=" .env 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"' | tr -d "'"
}

ANON_KEY="${ANON_KEY:-$(env_al ANON_KEY)}"
SERVICE_KEY="${SERVICE_ROLE_KEY:-$(env_al SERVICE_ROLE_KEY)}"
KONG_PORT="${KONG_HTTP_PORT:-$(env_al KONG_HTTP_PORT)}"
KONG_PORT="${KONG_PORT:-8000}"
API_URL="${API_URL:-http://127.0.0.1:${KONG_PORT}}"

PSQL=(docker compose exec -T db psql -U postgres -d postgres)

F7_SONUC="ATLANDI"
F1_SONUC="ATLANDI"

echo "════════════════════════════════════════════════════════════════"
echo "F1 + F7 SON KANIT"
echo "  Dizin : $(pwd)"
echo "  API   : $API_URL"
echo "  ANON  : ${ANON_KEY:0:10}… (${#ANON_KEY})"
echo "  SRV   : ${SERVICE_KEY:0:10}… (${#SERVICE_KEY})"
echo "════════════════════════════════════════════════════════════════"

# ═══════════════════════════════════════════════════════════════════
# ADIM 1 · F7 — Türkçe karakter bütünlüğü (uçtan uca)
# ═══════════════════════════════════════════════════════════════════
if [ "$ONLY_F1" -eq 0 ]; then
  echo
  echo "▶ F7 · \"$F7_SOYAD\" içeren test hesabı yazılıyor ve geri okunuyor"

  if [ -z "$SERVICE_KEY" ]; then
    echo "  ❌ SERVICE_ROLE_KEY yok — F7 adımı atlandı."
    F7_SONUC="HATA"
  else
    # kullanıcı var mı?
    curl -sS -o /tmp/f7_users.json \
      "$API_URL/auth/v1/admin/users?page=1&per_page=200" \
      -H "apikey: $SERVICE_KEY" \
      -H "Authorization: Bearer $SERVICE_KEY" 2>/dev/null

    UID_="$(python3 - "$F7_EMAIL" <<'PY'
import json, sys
email = sys.argv[1].lower()
try:
    d = json.load(open("/tmp/f7_users.json", encoding="utf-8"))
except Exception:
    print(""); raise SystemExit(0)
users = d.get("users") if isinstance(d, dict) else d
for u in users or []:
    if (u.get("email") or "").lower() == email:
        print(u.get("id", "")); break
PY
)"

    GOVDE="$(python3 - "$F7_EMAIL" "$F7_PW" "$F7_AD" "$F7_SOYAD" <<'PY'
import json, sys
email, pw, ad, soyad = sys.argv[1:5]
print(json.dumps({
    "email": email,
    "password": pw,
    "email_confirm": True,
    "user_metadata": {"first_name": ad, "last_name": soyad},
}, ensure_ascii=False))
PY
)"

    if [ -z "$UID_" ]; then
      echo "  → hesap yok, oluşturuluyor"
      KOD="$(curl -sS -o /tmp/f7_admin.json -w '%{http_code}' \
        -X POST "$API_URL/auth/v1/admin/users" \
        -H "apikey: $SERVICE_KEY" \
        -H "Authorization: Bearer $SERVICE_KEY" \
        -H 'Content-Type: application/json' \
        -d "$GOVDE" 2>/dev/null)"
    else
      echo "  → hesap var ($UID_), metadata güncelleniyor"
      KOD="$(curl -sS -o /tmp/f7_admin.json -w '%{http_code}' \
        -X PUT "$API_URL/auth/v1/admin/users/$UID_" \
        -H "apikey: $SERVICE_KEY" \
        -H "Authorization: Bearer $SERVICE_KEY" \
        -H 'Content-Type: application/json' \
        -d "$(python3 - "$F7_AD" "$F7_SOYAD" <<'PY'
import json, sys
ad, soyad = sys.argv[1:3]
print(json.dumps({"user_metadata": {"first_name": ad, "last_name": soyad}}, ensure_ascii=False))
PY
)" 2>/dev/null)"
    fi
    echo "  HTTP $KOD"

    SORGU="select coalesce(raw_user_meta_data->>'last_name','<yok>')
                 || '|' || encode(convert_to(coalesce(raw_user_meta_data->>'last_name',''),'UTF8'),'hex')
                 || '|' || (coalesce(raw_user_meta_data->>'last_name','') ~ '[ÃÂÅÄ]')::text
            from auth.users where lower(email)=lower('$F7_EMAIL');"

    OUT="$("${PSQL[@]}" -At -F '|' -c "$SORGU" 2>/dev/null | head -1)"
    echo "  DB (soyad|hex|bozuk): $OUT"

    OKUYAN_SOYAD="${OUT%%|*}"
    KALAN="${OUT#*|}"
    HEX="${KALAN%%|*}"
    BOZUK="${KALAN##*|}"

    echo
    if [ "$HEX" = "$BEKLENEN_HEX" ] && [ "$BOZUK" = "f" ]; then
      echo "  ✅ F7 PASS — soyad '$OKUYAN_SOYAD', hex $HEX (beklenen $BEKLENEN_HEX)"
      F7_SONUC="PASS"
    else
      echo "  ❌ F7 FAIL — hex $HEX (beklenen $BEKLENEN_HEX), bozuk=$BOZUK"
      echo "     Bu çıkarsa GoTrue sürümü/encoding hattı hâlâ bozuyor demektir."
      F7_SONUC="FAIL"
    fi

    # profiles tarafı
    POUT="$("${PSQL[@]}" -At -F '|' -c \
      "select coalesce(last_name,'<yok>') || '|' || (coalesce(last_name,'') ~ '[ÃÂÅÄ]')::text
         from public.profiles where lower(email)=lower('$F7_EMAIL');" 2>/dev/null | head -1)"
    if [ -n "$POUT" ]; then
      echo "  ℹ️  profiles.last_name: $POUT  (bozuk=f beklenir)"
    else
      echo "  ℹ️  profiles satırı yok (trigger kapsamı dışı olabilir, sorun değil)"
    fi

    if [ "$TEMIZLE" -eq 1 ] && [ -n "$UID_" ]; then
      echo
      echo "  ▶ --temizle: test hesabı siliniyor ($UID_)"
      curl -sS -o /dev/null -w '  HTTP %{http_code}\n' \
        -X DELETE "$API_URL/auth/v1/admin/users/$UID_" \
        -H "apikey: $SERVICE_KEY" \
        -H "Authorization: Bearer $SERVICE_KEY" 2>/dev/null
    elif [ -n "$UID_" ]; then
      echo "  ℹ️  Test hesabı duruyor: $F7_EMAIL ($UID_)"
      echo "     Silmek için: bash $0 --temizle"
    fi
  fi
fi

# ═══════════════════════════════════════════════════════════════════
# ADIM 2 · F1 — eski oturumla şifre değişimi reddi
# ═══════════════════════════════════════════════════════════════════
if [ "$ONLY_F7" -eq 0 ]; then
  echo
  echo "▶ F1 · 09_f1_retest.sh çalıştırılıyor (oturum 3 gün eskitilecek)"
  if [ ! -f "$SCRIPT_DIR/09_f1_retest.sh" ]; then
    echo "  ❌ 09_f1_retest.sh bulunamadı: $SCRIPT_DIR"
    F1_SONUC="HATA"
  else
    bash "$SCRIPT_DIR/09_f1_retest.sh" --hesap-olustur --eskit
    K=$?
    if [ "$K" -eq 0 ]; then
      F1_SONUC="PASS"
    else
      F1_SONUC="FAIL (çıkış kodu $K)"
    fi
    echo
    echo "▶ F1 · oturum zamanları geri alınıyor"
    bash "$SCRIPT_DIR/09_f1_retest.sh" --geri-al || true
  fi
fi

# ═══════════════════════════════════════════════════════════════════
# ÖZET
# ═══════════════════════════════════════════════════════════════════
echo
echo "════════════════════════════════════════════════════════════════"
echo "ÖZET"
echo "  F7 (mojibake, uçtan uca)     : $F7_SONUC"
echo "  F1 (eski oturum reauth testi): $F1_SONUC"
echo "════════════════════════════════════════════════════════════════"
echo "Bu çıktıyı olduğu gibi rapora ekleyebilirsin."
echo "F1'in arayüz ayağı ayrı: panelden şifre değiştirme testi (kontrol listesi)."

if [ "$F7_SONUC" = "FAIL" ] || [ "$F1_SONUC" = "FAIL (çıkış kodu 1)" ]; then
  exit 1
fi
exit 0