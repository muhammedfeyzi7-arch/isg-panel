#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# İBYS Self-Hosted Supabase — Sunucu Hazırlık Script'i
# Hedef: Turhost VDS (Ubuntu 24.04 LTS, root)
# Çalıştır: root olarak  ->  bash 01-sunucu-hazirla.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

APP_DIR="/opt/ibys"
SUPABASE_REPO="${APP_DIR}/supabase"

echo "==> 1/6  Sistem güncellemesi"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get upgrade -y

echo "==> 2/6  Temel paketler"
apt-get install -y ca-certificates curl gnupg git ufw fail2ban jq unzip openssl

echo "==> 3/6  Docker + Docker Compose kurulumu"
if ! command -v docker >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
    | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "${VERSION_CODENAME}") stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -y
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi
systemctl enable --now docker

echo "==> 4/6  Güvenlik duvarı (ufw)"
ufw allow 23422/tcp   # SSH (Turhost özel portu)
ufw allow 80/tcp      # HTTP (TLS challenge + yönlendirme)
ufw allow 443/tcp     # HTTPS
ufw --force enable

echo "==> 5/6  fail2ban"
systemctl enable --now fail2ban

echo "==> 6/6  Supabase self-host deposu"
mkdir -p "${APP_DIR}"
if [ ! -d "${SUPABASE_REPO}" ]; then
  git clone --depth 1 https://github.com/supabase/supabase "${SUPABASE_REPO}"
fi

echo ""
echo "TAMAM. Sırada:"
echo "  1) cd ${SUPABASE_REPO}/docker"
echo "  2) .env dosyasını deploy/.env.example şablonuna göre doldur"
echo "  3) docker compose up -d"