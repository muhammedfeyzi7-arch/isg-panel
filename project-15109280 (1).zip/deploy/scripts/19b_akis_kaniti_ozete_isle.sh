#!/usr/bin/env bash
# =============================================================================
# 19b · ŞİFRE AKIŞI KANITINI ÖZETE İŞLE  (pgTAP'i tekrar koşmadan)
# =============================================================================
# Neden var:
#   19_pentest_kapanis_kanit.sh 6-7 dakika pgTAP koşuyor. Şifre akışı kanıtı
#   (16 betiğinin /root/pentest-kanit/sifre_akisi_*.log dosyası) zaten elimizde
#   olduğu hâlde 00_OZET.md'de 5. kalem "koşulmadı" görünüyorsa, tüm paketi
#   baştan koşmak israftır. Bu betik sadece 5. kalemi log'dan yeniden hesaplar,
#   60_sifre_akisi.log'u pakete kopyalar ve 00_OZET.md tablosunu günceller.
#
# Kullanım:
#   bash deploy/scripts/19b_akis_kaniti_ozete_isle.sh              # en yeni paket
#   bash deploy/scripts/19b_akis_kaniti_ozete_isle.sh /root/pentest-kanit-20261020-0540
#
# Salt okunur DEĞİL: yalnızca /root/pentest-kanit-* klasöründeki 00_OZET.md
# dosyasının 5. satırını ve 60_sifre_akisi.log kopyasını yazar. Canlı DB'ye,
# uygulamaya, Edge Function'a dokunmaz.
# =============================================================================
set -uo pipefail

CIKTI_KOK="${CIKTI_KOK:-/root/pentest-kanit}"
OUT="${1:-$(ls -dt /root/pentest-kanit-* 2>/dev/null | head -1 || true)}"

c_red=$'\e[31m'; c_grn=$'\e[32m'; c_yel=$'\e[33m'; c_dim=$'\e[2m'; c_rst=$'\e[0m'
info() { printf '%s\n' "${c_grn}==>${c_rst} $*"; }
warn() { printf '%s\n' "${c_yel}!! ${c_rst}$*"; }
fail() { printf '%s\n' "${c_red}✗${c_rst} $*"; }

echo
info "19b · Şifre akışı kanıtı özete işleniyor"

[[ -n "$OUT" && -d "$OUT" ]] || { fail "Kanıt klasörü bulunamadı: /root/pentest-kanit-* — önce 19'u koşun."; exit 1; }
[[ -f "$OUT/00_OZET.md" ]] || { fail "$OUT/00_OZET.md yok — yanlış klasör?"; exit 1; }

printf '  Paket : %s\n' "$OUT"

# ── 1 · Kanıt log'unu bul ────────────────────────────────────────────────────
AKIS_LOG="$(ls -t "$CIKTI_KOK"/sifre_akisi_*.log 2>/dev/null | head -1 || true)"
if [[ -z "$AKIS_LOG" ]]; then
  fail "Kanıt log'u yok: $CIKTI_KOK/sifre_akisi_*.log"
  warn "Önce 16 betiğini koşun: bash deploy/scripts/16_ui_sifre_kodu_akisi_test.sh"
  exit 1
fi
printf '  Kanıt : %s\n' "$AKIS_LOG"
cp "$AKIS_LOG" "$OUT/60_sifre_akisi.log" 2>/dev/null || true

# Güvenilir olmayan eski log'ları ayırt etmek için sadece son 3 satırı göster.
echo
printf '  %s\n' "${c_dim}log son satırları:${c_rst}"
tail -n 3 "$AKIS_LOG" | sed 's/^/    /'
echo

# ── 2 · PASS / FAIL sayısını çıkar ───────────────────────────────────────────
# 1) Tercih edilen: 16 betiğinin yazdığı özet satırı
#    === SONUÇ: PASS=13 FAIL=0 · yeni sifre=... · durum=elle kosuldu ===
SONUC_SATIR="$(grep -aE 'SONU.*PASS[[:space:]]*=[[:space:]]*[0-9]+' "$AKIS_LOG" 2>/dev/null | tail -1 || true)"
P_CNT="$(printf '%s' "$SONUC_SATIR" | grep -oE 'PASS[[:space:]]*=[[:space:]]*[0-9]+' | grep -oE '[0-9]+' | tail -1 || true)"
F_CNT="$(printf '%s' "$SONUC_SATIR" | grep -oE 'FAIL[[:space:]]*=[[:space:]]*[0-9]+' | grep -oE '[0-9]+' | tail -1 || true)"
DURUM="$(printf '%s' "$SONUC_SATIR" | grep -oE 'durum=[^=]*' | sed 's/^durum=//; s/[[:space:]]*===$//; s/[[:space:]]*$//' || true)"

KAYNAK="özet satırı"
if [[ -z "${P_CNT:-}" || -z "${F_CNT:-}" ]]; then
  # 2) Yedek: eski 16 sürümü özet satırı yazmıyorsa tek tek test satırlarından say
  FB_P=0; FB_F=0
  while IFS= read -r L; do
    [[ -z "$L" ]] && continue
    if [[ "$L" == *"beklenen="* && "$L" == *"gelen="* ]]; then
      FB_BEK="$(printf '%s' "$L" | sed -n 's/.*beklenen=\([^ ]*\).*/\1/p')"
      FB_GEL="$(printf '%s' "$L" | sed -n 's/.*gelen=\([^ ]*\).*/\1/p')"
      FB_HIT=0
      IFS='|' read -ra FB_ALTS <<< "${FB_BEK:-?}"
      for FB_A in "${FB_ALTS[@]}"; do
        [[ "$FB_GEL" = "$FB_A" ]] && FB_HIT=1
      done
      [[ "$FB_HIT" = "1" ]] && FB_P=$((FB_P + 1)) || FB_F=$((FB_F + 1))
    elif [[ "$L" =~ ^\[T[0-9]+[a-z]*\][[:space:]]+(PASS|otherSessionsRevoked=true) ]]; then
      FB_P=$((FB_P + 1))
    fi
  done < <(grep -aE '^\[T' "$AKIS_LOG" 2>/dev/null || true)

  if [[ $((FB_P + FB_F)) -ge 5 ]]; then
    P_CNT="$FB_P"; F_CNT="$FB_F"; KAYNAK="log satırları"
  fi
fi

if [[ -z "${P_CNT:-}" || -z "${F_CNT:-}" ]]; then
  TEST_SAYI="$(grep -acE '\[T[0-9]+|✓ T[0-9]' "$AKIS_LOG" 2>/dev/null || true)"
  fail "Bu log'dan PASS/FAIL sayısı çıkarılamadı (bulunan test satırı: ${TEST_SAYI:-0})."
  warn "Log yarıda kalmış olabilir. 16 betiğini baştan koşun:"
  printf '    %s\n' "bash deploy/scripts/16_ui_sifre_kodu_akisi_test.sh"
  exit 1
fi

if [[ "$F_CNT" = "0" && "$P_CNT" -ge 9 ]]; then
  YENI_DURUM="PASS (PASS=$P_CNT / FAIL=0)"
  RENK="$c_grn"
elif [[ "$F_CNT" = "0" ]]; then
  YENI_DURUM="KALDI — FAIL yok ama test sayısı az (PASS=$P_CNT). 16'yı baştan koşun"
  RENK="$c_yel"
else
  YENI_DURUM="KALDI (PASS=$P_CNT / FAIL=$F_CNT)"
  RENK="$c_red"
fi

# 16 erken sonlandıysa (ör. kod girilmedi) PASS sayısı yüksek olsa da kanıt tamam değildir.
case "${DURUM:-}" in
  ""|elle\ kosuldu|tamamlandi) : ;;
  *) YENI_DURUM="KALDI — $DURUM (PASS=$P_CNT / FAIL=$F_CNT)"; RENK="$c_yel" ;;
esac

info "Hesap: $RENK$YENI_DURUM$c_rst  ${c_dim}($KAYNAK)${c_rst}"

# ── 3 · 00_OZET.md tablosundaki 5. satırı güncelle ───────────────────────────
python3 - "$OUT/00_OZET.md" "$YENI_DURUM" <<'PY'
import io, re, sys

path, durum = sys.argv[1], sys.argv[2]
with io.open(path, "r", encoding="utf-8", errors="replace") as f:
    satirlar = f.readlines()

yeni = []
degisti = False
for s in satirlar:
    if re.match(r"^\|\s*5\s*\|", s):
        yeni.append("| 5 | E-posta kodlu şifre değişimi UI/akış testi | %s | `60_sifre_akisi.log` |\n" % durum)
        degisti = True
    else:
        yeni.append(s)

if not degisti:
    # Tablo satırı beklenen biçimde değilse tabloyu bozmamak için satırı sona ekleme;
    # uyarı verip çık.
    sys.stderr.write("UYARI: 00_OZET.md içinde '| 5 |' satırı bulunamadı, tablo değiştirilmedi.\n")
    sys.exit(4)

with io.open(path, "w", encoding="utf-8") as f:
    f.writelines(yeni)
PY
[[ $? -eq 4 ]] && warn "Tablo satırı güncellenemedi — 19'u tekrar koşmak gerekiyor."

# ── 4 · Diğer kalemlerde KALDI var mı? ───────────────────────────────────────
KALAN="$(grep -aE '^\|\s*[0-9]+\s*\|' "$OUT/00_OZET.md" | grep -c 'KALDI' || true)"
KALAN="${KALAN:-0}"

echo
info "Güncel tablo"
grep -aE '^\|\s*[0-9]+\s*\|' "$OUT/00_OZET.md" | sed 's/^/  /'
echo

if [[ "$YENI_DURUM" == PASS* && "$KALAN" = "0" ]]; then
  printf '%s\n' "${c_grn}SONUÇ: 7/7 KALEM KAPANDI.${c_rst} Rapor kapatılabilir."
  printf '  Paket: %s\n' "$OUT"
  printf '  Özet : %s/00_OZET.md\n' "$OUT"
  exit 0
fi

if [[ "$YENI_DURUM" != PASS* ]]; then
  printf '%s\n' "${c_yel}SONUÇ: 5. kalem PASS değil — 16 betiğini baştan koşun.${c_rst}"
  exit 1
fi

printf '%s\n' "${c_red}SONUÇ: 5. kalem PASS ama başka kalem(ler) KALDI ($KALAN satır).${c_rst}"
printf '  Ayrıntı: %s/00_OZET.md\n' "$OUT"
exit 1