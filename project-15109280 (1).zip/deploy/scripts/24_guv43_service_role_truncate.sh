#!/usr/bin/env bash
# =============================================================================
# 24 · GUV-43 · service_role TRUNCATE/REFERENCES/TRIGGER temizliği
# =============================================================================
# Neden var:
#   pgTAP kapanış koşusunda tek kırık assertion:
#     not ok 6 - service_role → hicbir public tabloda TRUNCATE yok
#   Sebep: Supabase self-host varsayılan yetkileri service_role'a TABLOLARDA
#   "ALL" veriyor (TRUNCATE dahil). GUV-34 yalnızca CRUD GRANT etti, ALL'u geri
#   almadı; sonradan yaratılan tablolar TRUNCATE ile doğdu.
#
# Kullanım:
#   bash deploy/scripts/24_guv43_service_role_truncate.sh            # uygula
#   bash deploy/scripts/24_guv43_service_role_truncate.sh --dogrula  # salt okuma
#   bash deploy/scripts/24_guv43_service_role_truncate.sh --geri-al  # rollback
#
# Canlı 'postgres' DB'sine YALNIZCA bu migration'ı uygular. Veri okumaz/yazmaz.
# =============================================================================
set -uo pipefail

REPO_ROOT="${REPO_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)}"
COMPOSE_DIR="${COMPOSE_DIR:-/opt/ibys/supabase/docker}"
PGUSER="${PGUSER:-supabase_admin}"
DB_NAME="${DB_NAME:-postgres}"

MIG="$REPO_ROOT/supabase/migrations/20260101003100_guv43_service_role_truncate_revoke.sql"
RB="$REPO_ROOT/supabase/migrations/rollback/20260101003100_guv43_service_role_truncate_revoke_rollback.sql"

MOD="uygula"
case "${1:-}" in
  --dogrula) MOD="dogrula" ;;
  --geri-al) MOD="geri-al" ;;
  --uygula|"") MOD="uygula" ;;
  -h|--help) sed -n '2,20p' "$0"; exit 0 ;;
  *) echo "Bilinmeyen arguman: $1"; exit 2 ;;
esac

c_grn=$'\e[32m'; c_red=$'\e[31m'; c_yel=$'\e[33m'; c_rst=$'\e[0m'
ok()   { printf '%s\n' "${c_grn}PASS${c_rst} $*"; }
bad()  { printf '%s\n' "${c_red}FAIL${c_rst} $*"; }
info() { printf '%s\n' "${c_yel}==>${c_rst} $*"; }

[[ -d "$COMPOSE_DIR" ]] || { bad "compose dizini yok: $COMPOSE_DIR"; exit 1; }
cd "$COMPOSE_DIR" || exit 1

DC=(docker compose)
if ! docker compose version >/dev/null 2>&1; then
  DC=(docker-compose)
fi

psql_q() { "${DC[@]}" exec -T db psql -U "$PGUSER" -d "$DB_NAME" -At -v ON_ERROR_STOP=1 -c "$1"; }

# ── Salt okuma doğrulaması ───────────────────────────────────────────────────
dogrula() {
  echo
  info "Doğrulama (salt okuma)"
  local truncate_sayisi crud_eksik seq_eksik
  truncate_sayisi="$(psql_q "
    WITH t AS MATERIALIZED (
      SELECT c.oid FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
       WHERE n.nspname='public' AND c.relkind IN ('r','p'))
    SELECT count(*) FROM t
     WHERE has_table_privilege('service_role', t.oid, 'TRUNCATE');" 2>/dev/null)"
  crud_eksik="$(psql_q "
    WITH t AS MATERIALIZED (
      SELECT c.oid FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
       WHERE n.nspname='public' AND c.relkind IN ('r','p'))
    SELECT count(*) FROM t
     WHERE NOT (has_table_privilege('service_role', t.oid, 'SELECT')
            AND has_table_privilege('service_role', t.oid, 'INSERT')
            AND has_table_privilege('service_role', t.oid, 'UPDATE')
            AND has_table_privilege('service_role', t.oid, 'DELETE'));" 2>/dev/null)"
  seq_eksik="$(psql_q "
    WITH s AS MATERIALIZED (
      SELECT c.oid FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
       WHERE n.nspname='public' AND c.relkind='S')
    SELECT count(*) FROM s
     WHERE NOT has_sequence_privilege('service_role', s.oid, 'USAGE');" 2>/dev/null)"

  echo "  TRUNCATE yetkili tablo : ${truncate_sayisi:-SORGU HATASI}"
  echo "  CRUD eksik tablo       : ${crud_eksik:-SORGU HATASI}"
  echo "  USAGE eksik sequence   : ${seq_eksik:-SORGU HATASI}"

  if [ "${truncate_sayisi:-x}" = "0" ]; then
    ok "service_role hicbir public tabloda TRUNCATE yetkili degil"
  else
    bad "TRUNCATE yetkisi hala var (${truncate_sayisi:-?})"
    echo "  TRUNCATE yetkili tablolar (tablo | sahip | grantor) — ilk 30:"
    psql_q "
      WITH t AS MATERIALIZED (
        SELECT c.oid, c.relname, c.relowner, c.relacl
          FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
         WHERE n.nspname='public' AND c.relkind IN ('r','p'))
      SELECT relname
             || ' | sahip=' || pg_get_userbyid(relowner)
             || ' | grantor=' || COALESCE((
                  SELECT string_agg(DISTINCT pg_get_userbyid(a.grantor), ',')
                    FROM aclexplode(t.relacl) a
                   WHERE a.privilege_type='TRUNCATE'), '(ACL yok → sahip)')
        FROM t
       WHERE has_table_privilege('service_role', t.oid, 'TRUNCATE')
       ORDER BY relname LIMIT 30;" 2>/dev/null | sed 's/^/    - /'
    echo "  Ipuclari:"
    echo "    · grantor != uygulayan rol ise REVOKE yalnizca o grantor adina calisir."
    echo "    · sahip=service_role ise REVOKE ise YARAMAZ (sahip her zaman tam yetkili)."
    echo "    · PUBLIC (grantee=0) yetkisi tum rollere yayilir — migration onu da kesmeli."
    echo "    · Ayrintili teshis: supabase/tests/security/diag/guv43_truncate_teshis.sql"
  fi

  if [ "${crud_eksik:-x}" = "0" ] && [ "${seq_eksik:-x}" = "0" ]; then
    ok "service_role CRUD + sequence USAGE tam (Edge Function'lar calisir)"
  else
    bad "service_role tarafinda eksik yetki var — GUV-34 bozulmus olabilir"
  fi

  [ "${truncate_sayisi:-x}" = "0" ] && [ "${crud_eksik:-x}" = "0" ] && [ "${seq_eksik:-x}" = "0" ]
}

case "$MOD" in
  dogrula)
    dogrula; exit $?
    ;;

  geri-al)
    [[ -f "$RB" ]] || { bad "rollback dosyasi yok: $RB"; exit 1; }
    info "ROLLBACK uygulaniyor (service_role'a TRUNCATE geri verilir)"
    "${DC[@]}" exec -T db psql -U "$PGUSER" -d "$DB_NAME" -v ON_ERROR_STOP=1 < "$RB" || exit 1
    info "Rollback tamam. guv34 testi 6. assertion tekrar 'not ok' olacak — beklenen."
    dogrula || true
    exit 0
    ;;

  uygula)
    [[ -f "$MIG" ]] || { bad "migration dosyasi yok: $MIG"; exit 1; }

    echo "────────────────────────────────────────────────────────────"
    echo "GUV-43 · service_role TRUNCATE temizligi"
    echo "==> compose : $COMPOSE_DIR"
    echo "==> PGUSER  : $PGUSER / DB: $DB_NAME"
    echo "==> migration: $(basename "$MIG")"
    echo "────────────────────────────────────────────────────────────"

    echo
    info "ONCE (mevcut durum)"
    dogrula || true

    echo
    info "Uygulaniyor"
    "${DC[@]}" exec -T db psql -U "$PGUSER" -d "$DB_NAME" -v ON_ERROR_STOP=1 < "$MIG"
    RC=$?
    if [ "$RC" != "0" ]; then
      bad "Migration uygulanamadi (rc=$RC). Dogrulama basarisizsa COMMIT edilmedi — canli etkilenmedi."
      exit "$RC"
    fi

    echo
    info "SONRA (dogrulama)"
    if dogrula; then
      echo
      ok "GUV-43 uygulandi ve dogrulandi."
      echo "  Sonraki adim: pgTAP kapanis kanitini yenile"
      echo "    REPO_ROOT=$REPO_ROOT bash deploy/scripts/19_pentest_kapanis_kanit.sh"
    else
      bad "Dogrulama GECMEDI — migration'i uygulanmis sayma."
      exit 1
    fi
    ;;
esac