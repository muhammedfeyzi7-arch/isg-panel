# PostgREST şema ifşası maskeleyici (BULGU-05)

PENTEST 2. raporunda **BULGU-05 (CVSS 5.3, Orta)** olarak geçen "PostgREST şema
ifşası" bulgusunun sunucu tarafı kapatıcısı.

## Ne yapıyor

`/rest/v1` yanıtlarını inceler. Yalnızca **kolon/tablo yok** ve **schema cache**
sınıfı PostgreSQL hatalarının gövdesini genelleştirir:

```diff
- {"code":"42703","message":"column system_logs.email does not exist"}
+ {"code":"PGRST_GENERIC","message":"invalid request","details":null,"hint":null}
```

Diğer tüm hata kodları (`42501` yetki, `23514` kısıt, `PGRST116` tek satır...)
**aynen geçer**. Uygulama kodu bunları okuyor; bozulmaz.

## Kurulum (tek komut)

```bash
cd /root/isg-deploy
git pull
sudo bash deploy/scripts/29_bulgu_01_05_08_kapat.sh --mask-uygula
```

Bu komut sırayla:

1. maskeleyici container'ı başlatır (`127.0.0.1:8001`, internete kapalı),
2. `http://127.0.0.1:8001/__saglik` ile servisin ayakta olduğunu teyit eder,
3. `/etc/caddy/Caddyfile` dosyasını **yedekleyerek** kurar ve `caddy validate` + reload yapar,
4. uçtan uca ölçer (`?select=olmayan_kolon` → `PGRST_GENERIC` beklenir),
5. ölçüm PASS değilse **Caddyfile'ı otomatik geri alır** — API 502'ye düşmez.

`TEST 6` satırı **PASS · şema ifşası MASKELENDİ** dönerse BULGU-05 kapanır.

### Caddy failover (neden 502 riski yok)

`/rest/v1/*` iki yukarı akışa bağlıdır: `127.0.0.1:8001` (maskeleyici) ve
`127.0.0.1:8000` (Kong). `lb_policy first` + `fail_duration 30s` sayesinde
maskeleyici düşerse trafik Kong'a düşer: maskeleme devre dışı kalır, hizmet kesilmez.

## Doğrudan host'ta çalıştırmak (Docker'sız)

```bash
HOST=127.0.0.1 PORT=8001 UPSTREAM=http://127.0.0.1:8000 \
  node /root/isg-deploy/deploy/postgrest-mask/server.mjs
```

## Geri alma

```bash
# Caddyfile'ı yedekten geri koy (veya /rest/v1 bloğundaki 8001 satırını sil)
sudo cp /etc/caddy/Caddyfile.bak-<tarih> /etc/caddy/Caddyfile
sudo systemctl reload caddy
# servisi durdur
docker stop ibys-postgrest-mask && docker rm ibys-postgrest-mask
```

## Neden proxy, neden panel ayarı değil?

Self-host PostgREST, PostgreSQL hata metnini olduğu gibi döndürür; bunu kapatan
tek bir "expose error details" anahtarı her sürümde garanti değildir. Bu vekil
sürümden bağımsız çalışır ve **içerik bazlı** karar verdiği için uygulamanın
işlediği hata kodlarını bozmaz.

## Sağlık ucu

```bash
curl -s http://127.0.0.1:8001/__saglik
# {"ok":true,"masked":12}   ← masked: o ana kadar maskelenen yanıt sayısı
```

Bu uç yukarı akışa dokunmaz; Kong kapalıyken de 200 döner. Vekilin kendisi
ayakta mı sorusunun tek doğru cevabı budur.

## Kabul edilen risk alternatifi

Proxy kurulmak istenmiyorsa bulgu şu şekilde kapatılır: *"Anon erişimli veri
sızmıyor (RLS korumalı), yalnızca kolon adı öğrenilebiliyor; şema bilgisi tek
başına istismar zinciri kurmuyor. Risk kabul edildi, izleme altında."*
Bu tercih **belgeye açıkça yazılmalıdır**, aksi halde denetçi bulguyu açık sayar.