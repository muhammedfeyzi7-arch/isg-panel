// ═══════════════════════════════════════════════════════════════════════════
// İBYS · PostgREST şema ifşası maskeleyici  (PENTEST 2. RAPOR · BULGU-05)
//
// SORUN
//   PostgREST, olmayan bir kolon/tablo istendiğinde PostgreSQL'in ham hata
//   metnini döndürür:
//     {"code":"42703","message":"column system_logs.email does not exist"}
//   Bu, anon anahtarı olan birine tablo/kolon envanteri çıkarma imkânı verir.
//   Bulgu "veri sızıntısı yok, şema ifşası var" olarak Orta (5.3) işaretli.
//
// ÇÖZÜM
//   /rest/v1 yanıtlarını inceleyen küçük bir vekil. YALNIZCA
//   "kolon/tablo yok" ve "schema cache" sınıfı hataların gövdesini
//   genelleştirir. Diğer tüm hatalar (42501 yetki, 23514 kısıt, PGRST116
//   tek satır vb.) AYNEN geçer — uygulama kodu bunları okuyor.
//
// ÇALIŞTIRMA (host, systemd önerilir):
//   node deploy/postgrest-mask/server.mjs
//   HOST=0.0.0.0 PORT=8001 UPSTREAM=http://127.0.0.1:8000 node ...
//
// Caddy tarafında /rest/v1/* bu servise yönlendirilir (bkz. deploy/caddy/Caddyfile).
// Servis ayakta değilse Caddy 8000'e düşer (failover): maskeleme devre dışı
// kalır ama API 502 vermez.
// ═══════════════════════════════════════════════════════════════════════════

import http from 'node:http';

const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || 8001);
const UPSTREAM = process.env.UPSTREAM || 'http://127.0.0.1:8000';
const MAX_BODY_BYTES = Number(process.env.MAX_BODY_BYTES || 4 * 1024 * 1024);
const UPSTREAM_TIMEOUT_MS = Number(process.env.UPSTREAM_TIMEOUT_MS || 30000);

// Sadece ŞEMA İFŞASI sınıfı. Bilinçli olarak dar tutuldu.
// NOT: PGRST202 (fonksiyon yok) bilinçli olarak dışarıda — istemci tarafında
// "fonksiyon yok" ayrımına ihtiyaç duyan akışları bozmamak için.
const SEMA_IFSA_RE =
  /42703|42P01|PGRST204|column .+ does not exist|relation .+ does not exist|column .+ of relation .+ does not exist|schema cache|Perhaps you meant/i;

const GENEL_HATA = JSON.stringify({
  code: 'PGRST_GENERIC',
  message: 'invalid request',
  details: null,
  hint: null,
});

const HOP_BY_HOP = new Set([
  'connection',
  'keep-alive',
  'proxy-authenticate',
  'proxy-authorization',
  'te',
  'trailer',
  'transfer-encoding',
  'upgrade',
  'host',
]);

let maskelenen = 0;

// Kanıt damgası: yanıtı gerçekten MASKEDEN geçtiyse bu başlık vardır.
// Caddy failover (8001 ölü → 8000) durumunda başlık GÖRÜNMEZ; böylece
// "maskeleme devrede mi?" sorusu tahmine değil ölçüme dayanır.
const MASK_ID = process.env.MASK_ID || 'ibys-pgrest-mask-v1';

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let bitti = false;

    const bitir = (fn, arg) => {
      if (bitti) return;
      bitti = true;
      req.removeListener('data', onData);
      req.removeListener('end', onEnd);
      fn(arg);
    };

    function onData(chunk) {
      if (bitti) return;
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        // DİKKAT: burada req.destroy() ÇAĞRILMAZ. Çağrılırsa soket kapanır ve
        // istemci 413 gövdesini hiç göremez (curl 000 döner).
        bitir(reject, Object.assign(new Error('PAYLOAD_TOO_LARGE'), { code: 'PAYLOAD_TOO_LARGE' }));
        return;
      }
      chunks.push(chunk);
    }

    function onEnd() {
      bitir(resolve, Buffer.concat(chunks));
    }

    req.on('data', onData);
    req.on('end', onEnd);
    req.on('error', (err) => bitir(reject, err));
  });
}

function forwardHeaders(rawHeaders) {
  const out = {};
  for (const [key, value] of Object.entries(rawHeaders)) {
    if (!HOP_BY_HOP.has(key.toLowerCase())) out[key] = value;
  }
  return out;
}

function responseHeaders(upstreamHeaders) {
  const out = {};
  upstreamHeaders.forEach((value, key) => {
    const k = key.toLowerCase();
    if (k === 'content-encoding' || k === 'content-length' || k === 'transfer-encoding') return;
    out[k] = value;
  });
  // Vekil gövdeyi yeniden ürettiği için içerik türü tek kaynaktan yazılır.
  delete out['content-type'];
  return out;
}

function jsonYaz(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8' });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  // Sağlık ucu: Caddy/izleme için. Upstream'e dokunmaz.
  // Her yanıta kanıt başlığı (health dahil). writeHead bunu korur.
  res.setHeader('x-pgrest-mask', MASK_ID);

  if (req.url === '/__saglik' || req.url === '/__saglik/') {
    jsonYaz(res, 200, JSON.stringify({ ok: true, maskId: MASK_ID, masked: maskelenen }));
    return;
  }

  try {
    const body =
      req.method === 'GET' || req.method === 'HEAD' ? undefined : await readBody(req);

    const upstream = await fetch(`${UPSTREAM}${req.url}`, {
      method: req.method,
      headers: forwardHeaders(req.headers),
      body,
      redirect: 'manual',
      signal: AbortSignal.timeout(UPSTREAM_TIMEOUT_MS),
    });

    const contentType = upstream.headers.get('content-type') || '';
    const headers = responseHeaders(upstream.headers);

    // Hata değilse veya JSON değilse dokunmadan geçir.
    if (upstream.status < 400 || !contentType.includes('application/json')) {
      const buffer = Buffer.from(await upstream.arrayBuffer());
      res.writeHead(upstream.status, headers);
      res.end(buffer);
      return;
    }

    const text = await upstream.text();

    if (SEMA_IFSA_RE.test(text)) {
      // Aynı HTTP durumunu koru (uygulama akışı bozulmasın), gövdeyi genelle.
      maskelenen += 1;
      res.writeHead(upstream.status, { ...headers, 'content-type': 'application/json; charset=utf-8' });
      res.end(GENEL_HATA);
      return;
    }

    res.writeHead(upstream.status, { ...headers, 'content-type': contentType });
    res.end(text);
  } catch (err) {
    if (err && err.code === 'PAYLOAD_TOO_LARGE') {
      res.writeHead(413, {
        'content-type': 'application/json; charset=utf-8',
        connection: 'close',
      });
      res.end(JSON.stringify({ code: 'PAYLOAD_TOO_LARGE', message: 'request body too large' }));
      // Gövdenin kalanı okunmadan bağlantı kapatılır; yanıt yukarıda gönderildi.
      setImmediate(() => req.destroy());
      return;
    }
    const zamanAsimi = err && (err.name === 'TimeoutError' || err.name === 'AbortError');
    jsonYaz(res, zamanAsimi ? 504 : 502, JSON.stringify({
      code: zamanAsimi ? 'UPSTREAM_TIMEOUT' : 'UPSTREAM_ERROR',
      message: zamanAsimi ? 'upstream timeout' : 'bad gateway',
    }));
  }
});

server.listen(PORT, HOST, () => {
  // eslint-disable-next-line no-console
  console.log(`[postgrest-mask] ${MASK_ID} ${HOST}:${PORT} -> ${UPSTREAM} (max ${MAX_BODY_BYTES}B)`);
});