import { createClient } from 'npm:@supabase/supabase-js@2';

/**
 * ŞİFRE DEĞİŞTİRME — E-POSTA DOĞRULAMA KODU + SUNUCU TARAFLI ŞİFRE GEÇMİŞİ
 *
 * KURULUM: Bu dosyayı `supabase/functions/sifre-dogrulama/index.ts` konumuna
 * kopyalayıp deploy edin (bkz. SECURITY_FAZ11_OTURUM_SIFRE_EPOSTA_2026-10-19.md).
 *
 * Neden var: GoTrue'nun yerleşik `reauthentication` e-postası self-host SMTP
 * eksikliğinde "Error sending reauthentication email" veriyor ve kullanıcı
 * hiç kod alamıyordu. Kod üretimi, gönderimi ve doğrulaması burada yapılır.
 *
 * GÜVENLİK
 *  - Kod: 6 hane, crypto.getRandomValues; DB'de yalnızca SHA-256 özeti.
 *  - Süre 10 dk (sunucu saati), tek kullanımlık, en fazla 5 hatalı deneme.
 *  - Yeni kod istendiğinde önceki tüm kullanılmamış kodlar GEÇERSİZ olur.
 *  - Mevcut şifre sunucuda doğrulanır (GoTrue password grant).
 *  - Kod doğrulama + tüketim + şifre yazımı TEK transaction'da (GUV-42):
 *    public.sifre_kodu_ile_degistir → aynı kod paralel iki kez kullanılamaz.
 *    Süresi dolmuş kod tüketilir ve asla geçmez; başarılı değişimden sonra
 *    kullanıcının kalan tüm kodları kapatılır.
 *  - Son 3 şifre kontrolü yalnızca sunucuda; özetler auth.users'tan gelir.
 *  - İşlem sonunda diğer oturumların refresh token'ları iptal edilir.
 *  - Anahtar/parola loglanmaz.
 */

const CORS_ALLOWED = [
  'https://app.isgdenetim.com.tr',
  'https://www.isgdenetim.com.tr',
  'https://isgdenetim.com.tr',
  'http://localhost:3000',
  'http://localhost:5173',
  'http://127.0.0.1:3000',
];
const READDY_ORIGIN = /^https:\/\/([a-z0-9-]+\.)*(readdy\.ai|readdy\.site|readdy-site\.link|helloreaddy\.com)$/i;

function corsHeaders(req: Request): Record<string, string> {
  const origin = req.headers.get('origin') || '';
  const envList = (Deno.env.get('ALLOWED_ORIGINS') || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const allowed = !!origin && (CORS_ALLOWED.includes(origin) || envList.includes(origin) || READDY_ORIGIN.test(origin));
  const headers: Record<string, string> = {
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    Vary: 'Origin',
    'X-Content-Type-Options': 'nosniff',
    'Cache-Control': 'no-store',
  };
  if (allowed) headers['Access-Control-Allow-Origin'] = origin;
  return headers;
}

function json(body: unknown, status = 200, req?: Request): Response {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (req) Object.assign(headers, corsHeaders(req));
  return new Response(JSON.stringify(body), { status, headers });
}

/* ─────────────────────────── E-posta şablonu ─────────────────────────── */

const ISG_EMAIL_LOGO =
  'https://static.readdy.ai/image/9a23c36b022e5dee23ad356dbe985840/f12035640d991a27cdd7f34ddcb0302b.png';

function escapeHtml(value: string): string {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

interface EmailOptions {
  title: string;
  intro: string;
  code?: string;
  codeHint?: string;
  note?: string;
  footerNote?: string;
}

/** send-reset-email ile aynı kurumsal tasarım dili (navy + kırmızı accent). */
function renderIsgEmail(options: EmailOptions): string {
  const {
    title,
    intro,
    code,
    codeHint,
    note,
    footerNote = 'Bu e-posta PRO İSGDenetim tarafından güvenli olarak gönderilmiştir.',
  } = options;

  const codeBlock = code
    ? `<tr><td align="center" style="padding:24px 40px 0;">
         <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#0a1120;border:1px solid #22303f;border-radius:10px;">
           <tr><td align="center" style="padding:18px 16px 6px;font-family:Arial,Helvetica,sans-serif;font-size:11px;letter-spacing:1.5px;color:#8296ad;text-transform:uppercase;">Doğrulama Kodunuz</td></tr>
           <tr><td align="center" style="padding:0 16px 18px;font-family:'Courier New',Courier,monospace;font-size:34px;font-weight:bold;letter-spacing:12px;color:#ffffff;">${escapeHtml(code)}</td></tr>
         </table>
         ${codeHint ? `<p style="margin:10px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.6;color:#8296ad;text-align:center;">${escapeHtml(codeHint)}</p>` : ''}
       </td></tr>`
    : '';

  const noteBlock = note
    ? `<tr><td style="padding:26px 40px 0;">
         <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#0a1120;border:1px solid #22303f;border-radius:10px;">
           <tr><td style="padding:14px 16px;font-family:Arial,Helvetica,sans-serif;font-size:12px;line-height:1.65;color:#8296ad;">&#9201;&nbsp; ${escapeHtml(note)}</td></tr>
         </table>
       </td></tr>`
    : '';

  return `<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="dark light">
<title>${escapeHtml(title)} - PRO İSGDenetim</title>
</head>
<body style="margin:0;padding:0;background-color:#070b12;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color:#070b12;">
    <tr><td align="center" style="padding:32px 12px;">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="width:600px;max-width:600px;background-color:#0d1420;border:1px solid #22303f;border-radius:16px;">
        <tr><td align="center" style="padding:34px 32px 4px;">
          <img src="${ISG_EMAIL_LOGO}" width="200" alt="PRO İSGDenetim" style="display:block;width:200px;max-width:70%;height:auto;border:0;">
        </td></tr>
        <tr><td align="center" style="padding:22px 32px 0;">
          <table role="presentation" cellpadding="0" cellspacing="0" border="0"><tr>
            <td align="center" width="60" height="60" bgcolor="#2a0e12" style="width:60px;height:60px;border-radius:30px;border:1px solid #5a1f27;font-size:26px;line-height:60px;color:#ef2b39;">&#128274;</td>
          </tr></table>
        </td></tr>
        <tr><td align="center" style="padding:16px 32px 0;font-family:Arial,Helvetica,sans-serif;">
          <div style="font-size:23px;line-height:1.35;font-weight:bold;color:#ffffff;letter-spacing:-0.3px;">${escapeHtml(title)}</div>
        </td></tr>
        <tr><td align="center" style="padding:18px 44px 0;font-family:Arial,Helvetica,sans-serif;">
          <p style="margin:0 0 8px;font-size:14px;line-height:1.6;color:#c8d3e0;">Merhaba,</p>
          <p style="margin:0;font-size:14px;line-height:1.65;color:#9fb0c4;">${escapeHtml(intro)}</p>
        </td></tr>
        ${codeBlock}
        ${noteBlock}
        <tr><td align="center" style="padding:22px 40px 0;font-family:Arial,Helvetica,sans-serif;">
          <p style="margin:0;font-size:12px;line-height:1.6;color:#8296ad;text-align:center;">
            Bu işlemi siz başlatmadıysanız bu e-postayı dikkate almayın ve hesabınızın şifresini değiştirin.
          </p>
        </td></tr>
        <tr><td align="center" style="padding:30px 40px 0;font-family:Arial,Helvetica,sans-serif;">
          <div style="font-size:14px;font-weight:bold;color:#ffffff;">PRO İSGDenetim</div>
          <div style="font-size:10px;letter-spacing:2px;color:#8296ad;margin-top:4px;">İŞ SAĞLIĞI VE GÜVENLİĞİ</div>
        </td></tr>
        <tr><td align="center" style="padding:16px 40px 34px;">
          <div style="height:1px;background-color:#1b2735;font-size:0;line-height:0;">&nbsp;</div>
          <p style="margin:14px 0 0;font-family:Arial,Helvetica,sans-serif;font-size:11px;line-height:1.6;color:#5b6b80;text-align:center;">
            ${escapeHtml(footerNote)} Doğrulama kodunuzu ve bağlantınızı kimseyle paylaşmayın.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

/* ─────────────────────────────── Yardımcılar ─────────────────────────────── */

const CODE_TTL_MINUTES = 10;
// Hatalı deneme limiti (5) ve süre kontrolü artık SQL tarafında uygulanıyor:
// public.sifre_kodu_ile_degistir (GUV-42).

const LIMITS = {
  requestPerUser: { max: 5, windowMs: 15 * 60 * 1000 },
  requestPerIp: { max: 15, windowMs: 15 * 60 * 1000 },
  verifyPerUser: { max: 15, windowMs: 15 * 60 * 1000 },
};

const COMMON_PASSWORDS = new Set([
  '123456', '1234567', '12345678', '123456789', '1234567890', '123123', '111111', '000000',
  'abc123', 'abc12345', 'password', 'password1', 'password123', 'passw0rd', 'qwerty', 'qwerty123',
  'asdfgh', 'asdfghjkl', 'iloveyou', 'admin', 'admin123', 'welcome', 'welcome123', 'letmein',
  'parola', 'parola123', 'sifre', 'sifre123', 'şifre', 'şifre123', 'isgdenetim', 'isgdenetim123',
  'guvenlik', 'guvenlik123', 'osgb123', 'isg123456',
]);

/** Dönen değer: '' = OK, aksi halde hata kodu. */
function passwordPolicyError(password: string): string {
  if (!password) return 'PASSWORD_TOO_SHORT';
  if (password.length < 12) return 'PASSWORD_TOO_SHORT';
  if (password.length > 128) return 'PASSWORD_TOO_LONG';
  if (!/[a-zçğıöşü]/.test(password)) return 'PASSWORD_WEAK';
  if (!/[A-ZÇĞİÖŞÜ]/.test(password)) return 'PASSWORD_WEAK';
  if (!/[0-9]/.test(password)) return 'PASSWORD_WEAK';
  if (!/[^A-Za-z0-9]/.test(password)) return 'PASSWORD_WEAK';
  if (COMMON_PASSWORDS.has(password.toLowerCase())) return 'PASSWORD_WEAK';
  if (/(.)\1{2,}/.test(password)) return 'PASSWORD_WEAK';
  return '';
}

function generateCode(): string {
  const buffer = new Uint32Array(1);
  crypto.getRandomValues(buffer);
  return String(buffer[0] % 1_000_000).padStart(6, '0');
}

async function sha256Hex(value: string): Promise<string> {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function firstHeader(req: Request, names: string[]): string | null {
  for (const name of names) {
    const value = req.headers.get(name);
    if (value && value.trim()) return value.trim().split(',')[0].trim();
  }
  return null;
}

/**
 * Sabit pencereli hız sınırı. Altyapı hatasında isteği ENGELLEMEZ (fail-open);
 * amaç şifre işlemini kilitlemek değil, kötüye kullanımı sınırlamaktır.
 */
async function allowRequest(
  admin: ReturnType<typeof createClient>,
  scope: string,
  key: string,
  max: number,
  windowMs: number,
): Promise<boolean> {
  try {
    const now = Date.now();
    const { data } = await admin
      .from('auth_abuse_limits')
      .select('window_start, count')
      .eq('scope', scope)
      .eq('bucket_key', key)
      .maybeSingle();
    if (!data || now - new Date(data.window_start).getTime() > windowMs) {
      await admin.from('auth_abuse_limits').upsert({
        scope,
        bucket_key: key,
        window_start: new Date(now).toISOString(),
        count: 1,
        updated_at: new Date(now).toISOString(),
      });
      return true;
    }
    if ((data.count ?? 0) >= max) return false;
    await admin
      .from('auth_abuse_limits')
      .update({ count: (data.count ?? 0) + 1, updated_at: new Date(now).toISOString() })
      .eq('scope', scope)
      .eq('bucket_key', key);
    return true;
  } catch {
    return true;
  }
}

interface MailResult {
  sent: boolean;
  reason?: string;
}

async function sendMail(to: string, subject: string, html: string): Promise<MailResult> {
  const apiKey = Deno.env.get('RESEND_API_KEY');
  const fromDomain = Deno.env.get('RESEND_FROM_DOMAIN');
  if (!apiKey || !fromDomain) return { sent: false, reason: 'not_configured' };

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: `PRO İSGDenetim <noreply@${fromDomain}>`,
        to: [to],
        subject,
        html,
      }),
    });
    if (response.ok) return { sent: true };
    return { sent: false, reason: `provider_${response.status}` };
  } catch {
    return { sent: false, reason: 'network' };
  }
}

/** Mevcut şifreyi GoTrue password grant ile doğrular. */
async function verifyPassword(
  url: string,
  anonKey: string,
  email: string,
  password: string,
): Promise<'ok' | 'invalid' | 'unknown'> {
  try {
    const response = await fetch(`${url}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: { apikey: anonKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    if (response.ok) return 'ok';
    const text = (await response.text()).toLowerCase();
    if (text.includes('invalid_credentials') || text.includes('invalid login credentials')) return 'invalid';
    if (response.status === 400) return 'invalid';
    return 'unknown';
  } catch {
    return 'unknown';
  }
}

/**
 * GUV-44 · JWT'deki `amr` (authentication methods) listesini okur.
 *
 * Neden gerekli: "şifremi unuttum" akışı GoTrue'nun RECOVERY oturumunu kurar.
 * Bu oturum e-posta sahipliğini kanıtlar, bu yüzden ayrı kod adımı istemez.
 * Ama normal (parola ile açılmış) bir oturum da bu uç noktaya gelebilir ve
 * F1'i yeniden açardı. `amr` içinde kabul edilen bir yöntem YOKSA reddedilir.
 *
 * ÖNEMLİ (sürüm farkı): GoTrue, e-posta bağlantısıyla kurulan oturumu her
 * sürümde `recovery` olarak etiketlemiyor. Self-host 2.x bazı sürümlerde
 * `/auth/v1/verify?type=recovery` sonrası `amr` şu biçimde gelir:
 *   [{"method":"otp","timestamp":1792472022}]
 * Bu yüzden `otp` da kabul edilir: OTP/magic-link oturumu da e-posta
 * sahipliğini kanıtlar. Parola ile açılmış oturum `password` etiketi taşır
 * ve burada HER ZAMAN reddedilir (F1 kapalı kalır).
 */
const RECOVERY_AMR_METHODS = ['recovery', 'otp'];

function jwtAmrMethods(token: string): string[] {
  try {
    const part = token.split('.')[1];
    if (!part) return [];
    const b64 = part.replace(/-/g, '+').replace(/_/g, '/');
    const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
    const payload = JSON.parse(atob(padded)) as { amr?: unknown };
    const amr = payload?.amr;
    if (!Array.isArray(amr)) return [];
    return amr
      .map((item) => {
        if (typeof item === 'string') return item;
        const method = (item as { method?: string })?.method;
        return typeof method === 'string' ? method : '';
      })
      .filter(Boolean);
  } catch {
    return [];
  }
}

/** E-posta sahipliğini kanıtlayan bir oturum mu? (recovery veya otp) */
function isRecoverySession(token: string): boolean {
  const methods = jwtAmrMethods(token);
  return methods.some((m) => RECOVERY_AMR_METHODS.includes(m.toLowerCase()));
}

/** Diğer cihazların refresh token'larını sunucuda iptal eder. */
async function revokeOtherSessions(url: string, anonKey: string, token: string): Promise<boolean> {
  try {
    const response = await fetch(`${url}/auth/v1/logout?scope=others`, {
      method: 'POST',
      headers: { apikey: anonKey, Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({}),
    });
    return response.ok || response.status === 204;
  } catch {
    return false;
  }
}

const MESSAGES: Record<string, string> = {
  PASSWORD_TOO_SHORT: 'Şifre en az 12 karakter olmalıdır.',
  PASSWORD_TOO_LONG: 'Şifre en fazla 128 karakter olabilir.',
  PASSWORD_WEAK: 'Şifre büyük harf, küçük harf, rakam ve özel karakter içermelidir.',
  PASSWORD_SAME: 'Yeni şifreniz mevcut şifrenizle aynı olamaz.',
  PASSWORD_REUSED: 'Yeni şifreniz son 3 şifrenizden biriyle aynı olamaz.',
  USER_NOT_FOUND: 'Hesap bulunamadı.',
  CODE_INVALID: 'Doğrulama kodu geçersiz.',
  CODE_EXPIRED: 'Doğrulama kodunun süresi dolmuş.',
  CODE_ATTEMPTS: 'Çok fazla hatalı kod denemesi yapıldı.',
  CODE_NOT_FOUND: 'Aktif doğrulama kodu bulunamadı.',
  RATE_LIMITED: 'Çok fazla istek gönderildi. Lütfen biraz sonra tekrar deneyin.',
  CURRENT_PASSWORD_INVALID: 'Mevcut şifreniz hatalı.',
  MAIL_NOT_CONFIGURED: 'E-posta gönderim ayarları yapılandırılmamış.',
  MAIL_SEND_FAILED: 'Doğrulama e-postası gönderilemedi.',
  SESSION_EXPIRED: 'Oturumunuzun süresi doldu. Lütfen yeniden giriş yapın.',
  FORBIDDEN: 'Bu işlem için yetkiniz bulunmuyor.',
  INVALID_REQUEST: 'Geçersiz istek.',
  SERVER_ERROR: 'İşlem tamamlanamadı. Lütfen tekrar deneyin.',
};

function fail(code: string, status = 400, req?: Request): Response {
  return json({ ok: false, code, message: MESSAGES[code] ?? MESSAGES.SERVER_ERROR }, status, req);
}

/* ─────────────────────────────── Sunucu ─────────────────────────────── */

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders(req) });
  if (req.method !== 'POST') return json({ ok: false, code: 'INVALID_REQUEST' }, 405, req);

  const url = (Deno.env.get('SUPABASE_URL') || '').replace(/\/+$/, '');
  const anonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
  if (!url || !anonKey || !serviceKey) return fail('SERVER_ERROR', 500, req);

  const authorization = req.headers.get('Authorization') || '';
  const token = authorization.replace(/^Bearer\s+/i, '').trim();
  if (!token) return fail('SESSION_EXPIRED', 401, req);

  // Kullanıcı kimliği YALNIZCA doğrulanmış token'dan türetilir; gövdeden gelmez.
  const anon = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: userError } = await anon.auth.getUser(token);
  const user = userData?.user;
  if (userError || !user?.email) return fail('SESSION_EXPIRED', 401, req);

  const admin = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } });

  let body: Record<string, unknown> = {};
  try {
    body = (await req.json()) as Record<string, unknown>;
  } catch {
    return fail('INVALID_REQUEST', 400, req);
  }

  const action = String(body.action || '');
  const ip = firstHeader(req, ['cf-connecting-ip', 'x-real-ip', 'x-forwarded-for', 'x-client-ip']) || 'unknown';

  try {
    /* ── 1. ADIM: kod gönder ── */
    if (action === 'kod-gonder') {
      const currentPassword = String(body.currentPassword || '');
      if (!currentPassword) return fail('CURRENT_PASSWORD_INVALID', 400, req);

      const [userBudget, ipBudget] = await Promise.all([
        allowRequest(admin, 'password_code_user', user.id, LIMITS.requestPerUser.max, LIMITS.requestPerUser.windowMs),
        allowRequest(admin, 'password_code_ip', ip, LIMITS.requestPerIp.max, LIMITS.requestPerIp.windowMs),
      ]);
      if (!userBudget || !ipBudget) return fail('RATE_LIMITED', 429, req);

      const verify = await verifyPassword(url, anonKey, user.email, currentPassword);
      if (verify === 'invalid') return fail('CURRENT_PASSWORD_INVALID', 400, req);

      const code = generateCode();
      const codeHash = await sha256Hex(code);
      const expiresAt = new Date(Date.now() + CODE_TTL_MINUTES * 60 * 1000).toISOString();

      // Süresi geçmiş / tüketilmiş eski kayıtların temizliği (2 günden eski).
      try {
        await admin.rpc('sifre_dogrulama_kodlarini_temizle');
      } catch {
        /* temizlik kritik değil; akışı engellemez */
      }

      // TEK AKTİF KOD KURALI: yeni kod üretildiği anda kullanıcının önceki tüm
      // kullanılmamış kodları geçersiz kılınır (ikinci mail → ilki ölür).
      await admin
        .from('sifre_dogrulama_kodlari')
        .update({ consumed_at: new Date().toISOString() })
        .eq('user_id', user.id)
        .is('consumed_at', null);

      const { error: insertError } = await admin.from('sifre_dogrulama_kodlari').insert({
        user_id: user.id,
        email: user.email,
        code_hash: codeHash,
        expires_at: expiresAt,
        ip,
      });
      if (insertError) return fail('SERVER_ERROR', 500, req);

      const html = renderIsgEmail({
        title: 'Şifre Değiştirme Doğrulaması',
        intro:
          'Hesabınızın şifresini değiştirmek için bir doğrulama isteği aldık. Aşağıdaki kodu uygulamadaki doğrulama alanına girin. Bu kod yalnızca bir kez kullanılabilir.',
        code,
        codeHint: 'Kodu kimseyle paylaşmayın. Kod 10 dakika geçerlidir.',
        note: 'Bu kod 10 dakika boyunca geçerlidir ve yalnızca bir kez kullanılabilir.',
        footerNote: 'Şifre değiştirme doğrulama e-postası.',
      });

      const mail = await sendMail(user.email, 'Şifre Değiştirme Doğrulama Kodu - PRO İSGDenetim', html);

      if (!mail.sent) {
        // Kod gönderilemedi → kullanıcıya YANLIŞ başarı gösterilmez.
        await admin
          .from('sifre_dogrulama_kodlari')
          .update({ consumed_at: new Date().toISOString() })
          .eq('user_id', user.id)
          .eq('code_hash', codeHash);
        if (mail.reason === 'not_configured') return fail('MAIL_NOT_CONFIGURED', 503, req);
        return fail('MAIL_SEND_FAILED', 502, req);
      }

      return json(
        {
          ok: true,
          expiresInMinutes: CODE_TTL_MINUTES,
          currentPasswordVerified: verify === 'ok',
        },
        200,
        req,
      );
    }

    /* ── 2. ADIM: kod + şifre değişimi ── */
    if (action === 'sifre-degistir') {
      const code = String(body.code || '').trim();
      const newPassword = String(body.newPassword || '');
      const currentPassword = String(body.currentPassword || '');

      if (!/^\d{6}$/.test(code)) return fail('CODE_INVALID', 400, req);

      const policyError = passwordPolicyError(newPassword);
      if (policyError) return fail(policyError, 400, req);

      const budget = await allowRequest(
        admin,
        'password_verify_user',
        user.id,
        LIMITS.verifyPerUser.max,
        LIMITS.verifyPerUser.windowMs,
      );
      if (!budget) return fail('RATE_LIMITED', 429, req);

      // Mevcut şifre kontrolü ÖNCE yapılır: yanlış mevcut şifre, geçerli kodu
      // boşa yakmaz (kod yalnızca gerçek bir şifre değişiminde tüketilir).
      if (!currentPassword) return fail('CURRENT_PASSWORD_INVALID', 400, req);
      const verify = await verifyPassword(url, anonKey, user.email, currentPassword);
      if (verify === 'invalid') return fail('CURRENT_PASSWORD_INVALID', 400, req);

      const providedHash = await sha256Hex(code);

      // TEK TRANSACTION (GUV-42):
      //   satır kilidi → süre kontrolü → deneme limiti → özet karşılaştırma
      //   → şifre politikası + son 3 şifre kontrolü + yazım → kodu tüket
      // Paralel iki istek gelirse yalnızca biri kodu tüketebilir.
      const { data: result, error: rpcError } = await admin.rpc('sifre_kodu_ile_degistir', {
        p_user_id: user.id,
        p_code_hash: providedHash,
        p_new_password: newPassword,
      });
      if (rpcError) return fail('SERVER_ERROR', 500, req);

      const outcome = String(result || 'SERVER_ERROR');
      if (outcome !== 'OK') return fail(outcome, outcome === 'CODE_ATTEMPTS' ? 429 : 400, req);

      const revoked = await revokeOtherSessions(url, anonKey, token);

      // Güvenlik bilgilendirmesi (başarısız olsa da şifre değişikliği geri alınmaz).
      const when = new Date().toLocaleString('tr-TR', { timeZone: 'Europe/Istanbul' });
      const notifyHtml = renderIsgEmail({
        title: 'Şifreniz Değiştirildi',
        intro: `Hesabınızın şifresi ${when} tarihinde değiştirildi. Güvenliğiniz için diğer cihazlardaki oturumlar kapatıldı.`,
        note: 'Bu işlemi siz yapmadıysanız hemen şifrenizi sıfırlayın ve sistem yöneticinize bildirin.',
        footerNote: 'Şifre değişikliği bilgilendirmesi.',
      });
      const notification = await sendMail(user.email, 'Şifreniz Değiştirildi - PRO İSGDenetim', notifyHtml);

      return json(
        {
          ok: true,
          otherSessionsRevoked: revoked,
          notificationSent: notification.sent,
        },
        200,
        req,
      );
    }

    /* ── 3. ADIM: şifre sıfırlama (recovery oturumu) ── */
    if (action === 'sifirla-degistir') {
      const newPassword = String(body.newPassword || '');

      const policyError = passwordPolicyError(newPassword);
      if (policyError) return fail(policyError, 400, req);

      // SADECE recovery oturumu: e-posta bağlantısıyla kurulmuş oturum.
      // Normal giriş oturumu bu kapıyı kullanamaz (F1 yeniden açılmasın).
      if (!isRecoverySession(token)) {
        return fail('FORBIDDEN', 403, req);
      }

      const budget = await allowRequest(
        admin,
        'password_reset_user',
        user.id,
        LIMITS.verifyPerUser.max,
        LIMITS.verifyPerUser.windowMs,
      );
      if (!budget) return fail('RATE_LIMITED', 429, req);

      // GUV-44: izin SUNUCUDA üretilir + şifre politikası/geçmiş kontrolü
      // sifre_guncelle_atomik içinde tek transaction'da uygulanır.
      const { data: result, error: rpcError } = await admin.rpc('sifre_sifirlama_ile_degistir', {
        p_user_id: user.id,
        p_new_password: newPassword,
      });
      if (rpcError) return fail('SERVER_ERROR', 500, req);

      const outcome = String(result || 'SERVER_ERROR');
      if (outcome !== 'OK') return fail(outcome, 400, req);

      const revoked = await revokeOtherSessions(url, anonKey, token);

      const when = new Date().toLocaleString('tr-TR', { timeZone: 'Europe/Istanbul' });
      const notifyHtml = renderIsgEmail({
        title: 'Şifreniz Sıfırlandı',
        intro: `Hesabınızın şifresi ${when} tarihinde sıfırlandı. Güvenliğiniz için diğer cihazlardaki oturumlar kapatıldı.`,
        note: 'Bu işlemi siz yapmadıysanız hemen sistem yöneticinize bildirin.',
        footerNote: 'Şifre sıfırlama bilgilendirmesi.',
      });
      const notification = await sendMail(user.email, 'Şifreniz Sıfırlandı - PRO İSGDenetim', notifyHtml);

      return json(
        { ok: true, otherSessionsRevoked: revoked, notificationSent: notification.sent },
        200,
        req,
      );
    }

    return fail('INVALID_REQUEST', 400, req);
  } catch {
    return fail('SERVER_ERROR', 500, req);
  }
});