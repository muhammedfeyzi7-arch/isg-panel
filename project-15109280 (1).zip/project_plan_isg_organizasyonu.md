# İSG Organizasyonu Modülü + Dönemsel Yükümlülük Koşul Düzeltmesi

> Bu doküman `project_plan.md`'nin devamıdır (o dosya 2900+ satır olduğu için ayrı tutuldu).
> Expert Panel → Evraklar → Firma Evrakları → **İSG Organizasyonu** modülünün ve dönemsel motor düzeltmesinin kaydıdır.

## 1. Dönemsel Yükümlülük Motoru — Koşul Düzeltmesi (Bölüm 1)

**Sorun:** `supabase/functions/firma-yukumluluk` (aylık İSG Kurulu dönem motoru) kuralın `conditions` alanını okuyordu YOK; yalnızca `calculation_definition.min_employees` (50) değerine bakıyordu. Bu nedenle `ISG_KURULU` kuralının `{ all: [ { activity_condition: "surekli_is_6ay" } ] }` koşulu hiç değerlendirilmiyordu.

**Çözüm:** Motora `evaluateConditions` eklendi. `gereksinim-hesapla` motoruyla AYNI mantık:
- Doğrulanmamış (`firma_activity_attributes.verified_at IS NULL`) → `dogrulama_gerekli` (yeni durum).
- Doğrulanmış ve değer = false → `zorunlu_degil`.
- Doğrulanmış ve değer = true → çalışan ≥ 50 şartıyla `gerekli`.

**Etkilenen:** `firma-yukumluluk` (deploy edildi), `src/lib/yukumlulukService.ts` (yeni `dogrulama_gerekli` etiketi), `IsgKuruluListesi.tsx` (rozet varyantı).

## 2. İSG Organizasyonu Modülü (Bölüm 2)

**Amaç:** Mevcut Evraklar UI kabuğunu, sol kategori panelini ve Shared UI mimarisini BOZMADAN, sağ içerik alanında organizasyon/gereksinim ekranı sunmak. Sol menü zaten vardı (`evrak_turleri.code = 'ISG_ORGANIZASYONU'`, kategori "İSG Organizasyonu").

**Entegrasyon deseni:** İSG Kurulu / Risk Yönetimi / Eğitim / Planlama modülleriyle BİREBİR aynı: `FirmaEvrakListesi`'ne `isgOrganizasyonIcerik` prop'u + `ISG_ORGANIZASYONU` tür/kategori işleyicisi eklendi. Yeni sayfa/sol menü OLUŞTURULMADI.

### 2.1 Veri Modeli — Tek Veri Kaynağı İlkesi

| Sekme | Veri kaynağı |
|---|---|
| Genel Bakış | `firma_gereksinimleri` + gerçek atamalar + `evraklar` (salt okunur, merkezi) |
| Çalışan Temsilcileri | `isg_organizasyon_atamalari` (YENİ tablo — gerçek kişi ataması) |
| Destek Elemanları | `acil_durum_atamalari` (mevcut merkezi kayıt — çift kayıt yok) |
| İSG Görevlendirmeleri | `atamalar` (OSGB → Firma Atamaları, salt okunur) |
| Görev ve Sorumluluklar | Merkezi görev tanımları (`acilDurumService`) + gerçek atamalar |
| Görevlendirme Belgeleri | `evraklar` (merkezi belge kaydı, salt okunur) |

> **Not (v2):** Acil Durum Ekipleri sihirbazı artık üst sekmede DEĞİL; sol kategori ağacındaki
> `ACIL_DURUM_EKIPLERI` düğümünden açılır. Üst sekmede "Görev ve Sorumluluklar" bulunur (gereksiz sekme yok).

**Kritik karar:** Mevzuatta "Destek Elemanları" ve "Acil Durum Ekipleri" aynı 4 kategoriyi (Söndürme/Kurtarma/Koruma/İlk Yardım) temsil eder. Bu yüzden destek elemanları AYRI tabloya yazılmadı; mevcut `acil_durum_atamalari` merkezi kaydı kullanıldı. Yalnızca **Çalışan Temsilcisi** için yeni tablo açıldı.

### 2.2 Yeni Tablo: `isg_organizasyon_atamalari`

Kolonlar: `id`, `osgb_id`, `firma_id`, `personel_id`, `atama_turu` (calisan_temsilcisi), `rol` (asil/yedek), `requirement_code`, `baslangic_tarihi`, `bitis_tarihi`, `is_active`, `aciklama`, `created_by`, `archived_at`, `arsiv_nedeni`, zaman damgaları.

- `UNIQUE (firma_id, personel_id, atama_turu) WHERE is_active` → çift aktif atama engeli.
- RLS: SELECT kapsam (admin/osgb_admin/firma/uzman-hekim atama); yazma YOK (yalnızca service role edge function).
- Fiziksel silme YOK → arşivleme (`is_active=false` + `archived_at` + `arsiv_nedeni`).

### 2.3 Edge Function `isg-organizasyon`

Aksiyonlar: `list`, `personel` (aktif personel picker), `ata` (scope + aktiflik + çift kayıt kontrolü), `arsivle` (soft arşiv + audit). `firmalar.isg_girdi_degisti=true` bayrağı ile gereksinim motoru yeniden hesabı tetiklenir.

### 2.4 Gereksinim Motoru Entegrasyonu (`gereksinim-hesapla`)

`CALISAN_TEMSILCISI` satırının `current_quantity` değeri artık gerçek aktif atama sayısından (`isg_organizasyon_atamalari`) okunur. Önceki davranış (evrak sayma — yanlış) kaldırıldı. Atama/arşivleme sonrası motor yeniden hesaplanır.

### 2.5 UI Bileşenleri

- `src/pages/uzman/evraklar/components/isgOrganizasyon/IsgOrganizasyonu.tsx` — kabuk + 4 özet kartı + 6 sekme + Genel Bakış düzeni.
- `MevzuatGereksinimOzeti.tsx` — Genel Bakış sol panel (Görev/Görevlendirme, Gereken, Mevcut, Eksik, Durum, Açıklama).
- `SonGorevlendirmelerPanel.tsx` — Genel Bakış sağ panel (Tarih, Kişi, Görev, Başlangıç, Durum).
- `GorevlendirmeBelgeleriTablosu.tsx` — Tarih, Belge Adı, Görev/Tür, Kaynak, Durum, İşlemler (özet + tam).
- `IsgOrgGorevSorumluluklar.tsx` — görev tanımları + gereken/mevcut/eksik + sorumlu kişiler.
- `BelgeYukleModal.tsx` — personel + görev seçip imzalı/kullanıcı belgesi yükleme (merkezi `evraklar`).
- `IsgOrgCalisanTemsilcileri.tsx` — liste + "Çalışan Temsilcisi Ata" modalı + arşivleme.
- `CalisanTemsilcisiAtaModal.tsx` — aktif personel seçimi + rol + tarihler + açıklama.
- `IsgOrgDestekElemanlari.tsx` — 4 kategori kartı (Gereken/Mevcut/Eksik) + ata/kaldır.
- `IsgOrgGorevlendirmeler.tsx` — İSG Uzmanı/Hekim/DSP OSGB atamaları (salt okunur).
- `IsgOrgBelgeler.tsx` — merkezi görevlendirme belgeleri + belge yükleme.
- `src/lib/isgOrganizasyonService.ts` — servis + toplayıcılar (`fetchSonGorevlendirmeler`, `fetchFirmaGorevlendirmeBelgeleri`) + Türkçe hata çevirisi.

### 2.6 Genel Bakış UI (v2 — kullanıcı UI şartnamesi)

Verdiğim referans UI'ye birebir uyum:
- Üstte **4 özet kartı**: Gereken Görevlendirme / Karşılanan / Eksik / İlgili Belge.
- **Mevzuat Gereksinim Özeti** (sol, 2 kolon genişlik) — İSG Uzmanı / İşyeri Hekimi / DSP satırları dahil.
- **Son Görevlendirmeler** (sağ) — tüm atama türleri tek listede.
- **Görevlendirme Belgeleri** (tam genişlik) — "Tümünü Gör" + "Belge Yükle".
- Durum etiketleri mevzuat diline çekildi: Karşılanıyor / Eksik / İnceleme Gerekli / Zorunlu Değil.
- "Mevzuat Bilgi" butonu — gereksinimlerin merkezi motordan geldiğini açıklar.
- Hesaplama YOK; tüm sayılar merkezi gereksinim motorundan ve gerçek atama/belge kayıtlarından okunur.

**Sekme yapısı (6):** Genel Bakış · Çalışan Temsilcileri · Destek Elemanları · İSG Görevlendirmeleri · Görev ve Sorumluluklar · Görevlendirme Belgeleri.

## 3. Kalan / Sonraki Aşamalar

- Çalışan Temsilcisi + Destek Elemanı için **atama yazısı (Word) üretimi** ve **imzalı belge yükleme lifecycle'ı** (mevcut `acilDurumBelge` / `acilDurumGorevlendirme` altyapısı genişletilerek).
- OSGB Atamalar ekranında **İSG-KATİP sözleşme/atama belgesi** yükleme + İSG Görevlendirmeleri sekmesinde gösterme.
- Personel Detay Modalı entegrasyonu (aktif görev rozetleri + görev geçmişi + dijital dosyada belgeler).
- Personel işten çıkışında otomatik atama pasifleştirme + gereksinim yeniden hesabı.