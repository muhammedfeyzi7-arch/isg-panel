# İSGDenetim — Faz 10: Şema Yedeği ve İzole Test Ortamı İçin Kesin Hazırlık

> ⛔ **CANLI DURUM BÖLÜMLERİ GEÇERSİZ:** Bu dokümandaki "9 migration uygulanmadı",
> "`storage_tenant_ok`=YOK", "anon definer exec=159" gibi ifadeler **yazıldığı tarihteki (uygulama
> öncesi) durumu** yansıtır ve **artık geçersizdir.** Migration'lar canlıya uygulanmış ve
> doğrulanmıştır → güncel durum için bkz. **[`PENTEST_READINESS_DOSSIER.md`](./PENTEST_READINESS_DOSSIER.md)**.
>
> ✅ Bu dosyanın **§1–§4 (şema-only dump + izole ortam + komut/sıra) bölümleri HÂLÂ GEÇERLİDİR**
> — pentest öncesi runtime testlerini çalıştırmak için kullanılacak kılavuzdur.

> **Amaç:** Gerçek PostgreSQL/RLS runtime testlerinin çalıştırılabilmesi için eksik olan
> **tek girdiyi** (güvenilir base şema = **şema-only SQL dump**) kesinleştirmek ve test
> ortamı hazır olduğunda izlenecek **birebir komut/sıra** adımlarını dokümante etmek.
>
> **Kapsam:** İnceleme + dokümantasyon + kontrol listesi. **Yeni güvenlik analizi veya yeni
> migration ÜRETİLMEDİ.**
>
> ⛔ **ÜRETİM SINIRI (açık doğrulama):** Canlı veritabanına **hiçbir DDL/DML uygulanmadı**,
> **hiçbir migration çalıştırılmadı**, **hiçbir deploy yapılmadı**, **hiçbir secret
> güncellenmedi**. Canlı DB'ye yalnızca **salt-okuma** `SELECT` ile bakıldı. Gerçek kullanıcı
> verisi kopyalanmadı/değiştirilmedi. Raporda **hiçbir gizli anahtar / bağlantı parolası /
> connection string** yer almaz.
>
> **Dürüstlük notu:** İzole test ortamı ve şema-only dump **mevcut değildir** → **hiçbir DB
> runtime testi ÇALIŞTIRILMADI**, hiçbir migration için **PASS yazılmadı**. Yalnız gerçekten
> çalıştırılan **production build** ve **salt-okuma katalog kontrolleri** kanıtlıdır.

---

## 0) Bulgu özeti — tek satır

> **İzole test ortamı ve şema-only dump YOK → madde 7 gereği işlem BURADA DURDURULDU.**
> Uydurma base şema üretilmedi, canlıya bağlanıp test çalıştırılmadı, üretime migration
> uygulanmadı.

### 0.1 Bu turda incelenen dosyalar (madde 1 & 2)

| Dosya | İnceleme sonucu |
|---|---|
| `SECURITY_RUNTIME_VALIDATION_PHASE9.md` | Faz 9 durumu teyit edildi: 9 migration canlıda uygulanmadı, tüm runtime testler BLOCKED |
| `supabase/tests/security/00_harness.sql` | `security_test` şeması + `set_user/as_anon/reset_user/try_sql` + `create_fixtures()` + **`create_storage_relational_fixtures()`** (Faz 9) mevcut |
| `supabase/tests/security/guv01_storage_isolation.test.sql` | Bozuk ham INSERT'ler kaldırılmış; `create_storage_relational_fixtures()` çağrısı var; `BEGIN…ROLLBACK` ile sarılı |
| `SECURITY_TEST_ENV_PLAN_PHASE8.md` | Şema-only dump yolu tanımlı; sorumlu girdi listelenmiş; test ortamı BLOCKED |

### 0.2 Ortam yapılandırması kontrolü (madde 2 — KESİN)

| Kontrol | Sonuç | Anlam |
|---|---|---|
| `supabase/config.toml` (yerel Supabase projesi) | ❌ **YOK** | Yerel `supabase start`/`db reset` hedefli proje tanımlı değil |
| Herhangi `*.sql` dump / `*.dump` / base şema dosyası | ❌ **YOK** (yalnız `2026010100*` güvenlik migration'ları + test dosyaları var) | Base şema projede değil |
| `.env` | Yalnız `VITE_PUBLIC_SUPABASE_URL` + `VITE_PUBLIC_SUPABASE_ANON_KEY` (public anon; **secret değil**) | Prod connection string **yok/sunulmaz** |
| İzole test projesi | ❌ **YOK** | Test hedefi DB yok |
| Base şema migration'ları (git) | ❌ **YOK** | `auth_role()` vb. yerelde yok |

### 0.3 Canlı durum teyidi (salt-okuma, bu tur)

| Kontrol | Canlı sonuç | Anlam |
|---|---|---|
| `anon`'un EXECUTE edebildiği definer fonksiyon | **159** | GUV-11/13/13b uygulanmadı |
| `search_path` NULL definer fonksiyon | **4** | GUV-14/15 uygulanmadı |
| `storage_tenant_ok` fonksiyonu | **YOK (0)** | GUV-01 uygulanmadı |

> **Sonuç:** 9 güvenlik migration'ının **hiçbiri canlıya uygulanmamıştır.** Veri katmanı
> hâlâ açık; migration dosyalarının varlığı açığı kapatmaz.

---

## 1) Madde 3 — Güvenilir base şemayı elde etmenin en kısa yolu

**Tercih edilen yöntem = yetkili kaynaktan alınmış `şema-only SQL dump`** (veri içermez).
İkinci seçenek = ayrı bir **geliştirme/test veritabanı**. Base şemayı **tahmin etme/uydurma YOK.**

### 1.1 Karar ağacı (en kısa → en uzun)

| Öncelik | Kaynak | Ne zaman | Komut (özet) |
|---|---|---|---|
| **1 (tercih)** | Canlıdan **şema-only dump** (verisiz) | Canlı DB **okuma** connection string mevcut ise | `supabase db dump --schema public,auth,storage --data-only=false` |
| **2** | Ayrı **geliştirme/staging** DB | Yetkili dev DB varsa | Aynı `--schema-only` dump |
| **3** | Uygulama reposundan base `supabase/migrations` | Dump alınamıyorsa | Base migration dosyaları talep edilir |
| **4** | — | Hiçbiri yoksa | **DUR** → testler BLOCKED kalır |

> ⚠️ Connection string / `service_role` key **sohbete yazılmaz**; yalnız yerel terminalde
> ortam değişkeni olarak (`$PROD_DB_URL`, `$TEST_DB_URL`) kullanılır.

### 1.2 En kısa komut seti (yalnız yerel terminal — rapora yazılmaz)

```bash
# A) İzole test projesi (canlıdan BAĞIMSIZ)
#    → Supabase Dashboard'dan yeni proje aç (ücretsiz plan yeterli)

# B) Base şemayı ŞEMA-ONLY klonla (VERİ YOK)
supabase db dump --db-url "$PROD_DB_URL" \
  --schema public,auth,storage --data-only=false > base_schema.sql

#    (alternatif: pg_dump)
# pg_dump "$PROD_DB_URL" --schema-only --no-owner --no-privileges \
#   -n public -n auth -n storage > base_schema.sql

# C) İzole projeye yükle
psql "$TEST_DB_URL" -f base_schema.sql
```

> `--data-only=false` / `--schema-only` = **hiçbir müşteri satırı kopyalanmaz** (bkz. madde 5
> doğrulama adımları).

---

## 2) Madde 4 — Şema dump'ında BULUNMASI GEREKENLER

Aşağıdaki listede ✅ = migration'ların bağımlı olduğu ve dump'ta **mutlaka** bulunması gereken
nesneler. (Kaynak: `SECURITY_MIGRATION_DEPENDENCIES.md` §1–§11.)

### 2.1 Şemalar
- `public`, `auth`, `storage` (+ gerekiyorsa `extensions`).

### 2.2 Yardımcı fonksiyonlar (base — GUV-01/06/07 ön koşulu) ✅
- `public.auth_role()`, `public.auth_osgb_id()`, `public.auth_firma_id()`,
  `public.auth_personel_id()`, `public.auth_personel_bilgi()`
- `public.has_active_firma_assignment(uuid, uuid)`,
  `public.has_active_primary_assignment(uuid, uuid)`,
  `public.has_active_primary_firma_assignment(uuid, uuid)`,
  `public.has_active_uzman_assignment(uuid, uuid)`
- `public.osgb_access_ok()` (GUV-07 gövdeyi değiştirir → **önce** var olmalı)
- `public.audit_log(...)`, `public.log_system_event(text, text)`
- GUV-13/13b hedef kümesindeki tüm **SECURITY DEFINER** fonksiyonlar (imza varyantlarıyla)

### 2.3 Uygulama tabloları + kritik kolonlar ✅
| Tablo | Gereken kolon(lar) | Kullanan |
|---|---|---|
| `osgb` | `id, unvan, is_active, deleted_at, erisim_baslangic, erisim_bitis` | GUV-07 |
| `firmalar` | `id, osgb_id, unvan, calisan_sayisi, …` | GUV-07, harness |
| `personeller` | `id, osgb_id, firma_id, ad, soyad, foto_url` | GUV-01, GUV-07 |
| `profiles` | `id, email, role, osgb_id, firma_id` | GUV-02 |
| `atamalar` | `id, osgb_id, firma_id, personel_id, atama_turu, baslangic_tarihi, is_active` | GUV-01, harness |
| `atama_belgeleri` | `osgb_id, firma_id, atama_id, personel_id, belge_turu, belge_adi, dosya_path` | GUV-01 |
| `hazop_kanitlari` | `degerlendirme_id, firma_id, dosya_adi, storage_path, osgb_id` | GUV-01 |
| `noter_defteri_kayitlari` | `id, osgb_id, firma_id` | GUV-01 (FK parent) |
| `noter_defteri_ekleri` | `kayit_id (FK), osgb_id, firma_id, storage_path` | GUV-01 |
| `teklifler` | `id, osgb_id, teklif_no` | GUV-06 |
| `teklif_hizmetleri` | `id, teklif_id, osgb_id` | GUV-06 |
| `davetler` | `role, osgb_id, …` | GUV-02 regresyon |
| (`+ tüm uygulama tabloları`) | Bkz. canlı tablo listesi | Bütünlük |

### 2.4 Trigger'lar ✅
- `auth.users` → `on_auth_user_created()` → `public.handle_new_user()` (GUV-02 bunu değiştirir)
- `firmalar` / `personeller` üzerindeki lock / prevent_delete / normalize / scope trigger'ları
  (`firma_isg_girdi_degisim`, `firma_lock_osgb`, `firma_prevent_delete`,
  `personel_lock_scope`, `personel_normalize`, `personel_prevent_delete` — GUV-15 etkiler)
- `custom_field_definition_set_osgb`, `custom_field_value_set_scope`,
  `firma_evrak_klasorleri_set_scope`, `ziyaret_auto_close_due` (GUV-14 hedefleri)

### 2.5 RLS politikaları ✅
- `atamalar/evraklar/firmalar/personeller` üzerindeki `*_osgb_access_guard`
  (**RESTRICTIVE**, base'de mevcut → GUV-07 fonksiyonu bunlara bağlı)
- `teklifler` / `teklif_hizmetleri` mevcut **PERMISSIVE** politikaları (GUV-06 bunların
  üzerine RESTRICTIVE ekler)
- `storage.objects` üzerindeki mevcut bucket politikaları (GUV-01 bunları **DROP** edip
  yeniden oluşturur → isimlerin base'de aynı olması gerekir):
  `atama_belgeleri_obj_read`, `personel_foto_obj_read`,
  `hazop_kanit_storage_select/insert/delete`, `noter_defteri_obj_read/insert/delete`

### 2.6 Grant'ler ✅
- Base `GRANT EXECUTE` kayıtları (GUV-11 **statik imza** ile REVOKE eder → imzalar birebir
  olmalı; GUV-13/13b dinamik `regprocedure` ile çözer)
- Tablo/policy çalışması için `authenticated`, `anon`, `service_role` rol grant'leri

### 2.7 Supabase Auth / Storage bağımlılıkları ✅
- `auth.users` tablosu + `auth.uid()` fonksiyonu
- `storage.objects`, `storage.buckets` tabloları + `storage.foldername(text)` fonksiyonu
- 4 private bucket: `atama-belgeleri`, `personel-foto`, `hazop-kanitlari`, `noter-defteri`
  (`public=false`) → **dump bucket satırlarını içermezse ayrıca oluşturulur**

### 2.8 Hariç tutulabilecekler (dump'a gerek yok)
- Supabase-özel şema migration tabloları (`supabase_migrations.*`), `_analytics`, log şemaları.
- **Hiçbir müşteri veri satırı** (bkz. madde 5).

---

## 3) Madde 5 — Şema yedeğinin gerçek kullanıcı verisi İÇERMEDİĞİNİN doğrulaması

> Amaç: `base_schema.sql` dosyasının **veri taşımadığını** kanıtlamak. Aşağıdaki kontroller
> **yerel terminalde** çalıştırılır; **hiçbir gizli değer çıktıya yazılmaz.**

### 3.1 Dosya düzeyinde kontrol (dump alındıktan sonra, yüklemeden önce)
```bash
# (1) Dosyada veri taşıyan (COPY ... FROM stdin / INSERT INTO) blokları var mı?
grep -nE '^COPY .* FROM stdin|^INSERT INTO' base_schema.sql | head
#   → BEKLENEN: yalnız `auth.schema_migrations` veya Supabase-içi kontrol tabloları çıkabilir;
#     uygulama tabloları (public.*) için COPY/INSERT ÇIKMAMALI. Çıkarsa dump VERİ İÇERİYOR → KULLANMA.

# (2) Dosya boyutu makul mü? (şema-only tipik olarak veri dump'ından kat kat küçüktür)
wc -l base_schema.sql
```

### 3.2 Kural: yalnız DDL kalıpları kabul edilir
- ✅ Beklenen kalıplar: `CREATE TABLE`, `CREATE FUNCTION`, `CREATE POLICY`, `CREATE TRIGGER`,
  `ALTER TABLE ... ENABLE ROW LEVEL SECURITY`, `GRANT ...`.
- ❌ Kabul edilmeyen: uygulama tablolarına `INSERT` veya `COPY ... FROM stdin` **veri** blokları.

### 3.3 Yükleme sonrası (izole ortamda) — VERİ YOK teyidi
```sql
-- İzole test DB'de: public şemasındaki kritik tablolar boş olmalı
SELECT 'osgb' t, count(*) FROM public.osgb
UNION ALL SELECT 'firmalar', count(*) FROM public.firmalar
UNION ALL SELECT 'personeller', count(*) FROM public.personeller
UNION ALL SELECT 'profiles', count(*) FROM public.profiles
UNION ALL SELECT 'teklifler', count(*) FROM public.teklifler;
--   → BEKLENEN: hepsi 0 (base şema yüklendi, veri yok).
```

### 3.4 Gizli değer hijyeni
- Connection string / parola / service key **rapora veya sohbete yazılmaz.**
- Dump ve test çıktıları **`/tmp` veya yerel (git-ignore) bir dizinde** tutulur; repoya commit edilmez.
- `.env` yalnız **public anon** anahtar içerir; **secret değildir**, yine de rapora değer
  olarak yazılmaz.

---

## 4) Madde 6 — 9 migration + rollback için komut & sıra (test ortamında)

> **Sıra gerekçesi:** Dosya numarasına körlemesine değil, **gerçek bağımlılığa** dayanır
> (bkz. `SECURITY_MIGRATION_DEPENDENCIES.md` §11). Korunan iki katı kısıt:
> **(a) GUV-14 → GUV-15** (GUV-15'in NULL bloğu GUV-14 ile aynı kümeyi hedefler; önce 14),
> **(b) GUV-11 statik imza** (imza yoksa **hata verir** → base şema tam olmalı).

### 4.1 Uygulama sırası (önerilen — zorunlu olanlar işaretli)
```
GUV-02 → GUV-07 → GUV-06 → GUV-01 → GUV-11 → GUV-13 → GUV-13b → GUV-14 → GUV-15
         (serbest)                            (serbest)          [ZORUNLU: 14 → 15]
```
- **Zorunlu kısıtlar:** (1) base şema tüm GUV-01/06/07/11 öncesi; (2) **GUV-14 önce GUV-15**;
  (3) **GUV-11** yalnız imzalar tam mevcut base şemada.
- **Serbest:** GUV-02/06/07/13/13b birbirinden bağımsız.

### 4.2 Her migration için 4 adımlı protokol
```bash
# Her adımda: (1) önce ROLLBACK provası → (2) migration → (3) test → (4) kanıt
# Örnek (GUV-01):
psql "$TEST_DB_URL" -f supabase/migrations/20260101000100_guv01_storage_tenant_isolation.sql
psql "$TEST_DB_URL" -v ON_ERROR_STOP=1 -f supabase/tests/security/guv01_storage_isolation.test.sql
# Rollback provası (ayrı transaction/oturumda):
psql "$TEST_DB_URL" -f supabase/migrations/rollback/20260101000100_guv01_storage_tenant_isolation_rollback.sql
# Sonra migration'ı yeniden uygula (kalıcı durum) → testi tekrar çalıştır → PASS/FAIL kaydet
```
> `\i` yerine `onerror_stop` kullan: hata olursa transaction geri alınır.

### 4.3 Dosya → komut eşlemesi (9/9)

| # | Migration dosyası | Rollback dosyası | Test dosyası |
|---|---|---|---|
| GUV-01 | `20260101000100_guv01_storage_tenant_isolation.sql` | `rollback/…guv01…_rollback.sql` | `guv01_storage_isolation.test.sql` |
| GUV-02 | `20260101000200_guv02_handle_new_user.sql` | `rollback/…guv02…_rollback.sql` | `guv02_role_escalation.test.sql` |
| GUV-06 | `20260101000300_guv06_teklifler_tenant_restrictive.sql` | `rollback/…guv06…_rollback.sql` | `guv06_teklif_tenant.test.sql` |
| GUV-07 | `20260101000400_guv07_osgb_access_ok.sql` | `rollback/…guv07…_rollback.sql` | `guv07_osgb_access.test.sql` |
| GUV-11 | `20260101000500_guv11_revoke_anon_execute.sql` | `rollback/…guv11…_rollback.sql` | `guv11_guv13_anon_execute.test.sql` |
| GUV-13 | `20260101000600_guv13_revoke_anon_definer_rpc.sql` | `rollback/…guv13…_rollback.sql` | `guv11_guv13_anon_execute.test.sql` |
| GUV-14 | `20260101000700_guv14_definer_search_path.sql` | `rollback/…guv14…_rollback.sql` | `guv14_search_path.test.sql` |
| GUV-13b | `20260101000800_guv13b_anon_definer_scope.sql` | `rollback/…guv13b…_rollback.sql` | `guv13b_guv15_coverage.test.sql` |
| GUV-15 | `20260101000900_guv15_search_path_completion.sql` | `rollback/…guv15…_rollback.sql` | `guv13b_guv15_coverage.test.sql` |

### 4.4 Rollback sırası notu
- **GUV-15 rollback**, **GUV-14 rollback'inden sonra** uygulanmalı (farklı kümeler; karışıklığı önler).
- **GUV-01 rollback** `storage_tenant_ok()`'u `DROP` eder → bağlı başka nesne yok, güvenli.
- **Hiçbir rollback tablo/satır silmez/güncellemez** (yalnız policy/fonksiyon/grant).

### 4.5 Tam çalıştırma script iskeleti (yalnız izole ortamda)
```bash
set -e
TEST="$TEST_DB_URL"
# 0) Base şema + harness
psql "$TEST" -v ON_ERROR_STOP=1 -f base_schema.sql
psql "$TEST" -v ON_ERROR_STOP=1 -f supabase/tests/security/00_harness.sql
# 1) Migration'ları sırayla uygula
for m in 20260101000200_guv02 20260101000400_guv07 20260101000300_guv06 \
         20260101000100_guv01 20260101000500_guv11 20260101000600_guv13 \
         20260101000800_guv13b 20260101000700_guv14 20260101000900_guv15; do
  psql "$TEST" -v ON_ERROR_STOP=1 -f "supabase/migrations/${m}"*.sql
done
# 2) Testleri çalıştır
for t in supabase/tests/security/guv*.test.sql; do
  psql "$TEST" -v ON_ERROR_STOP=1 -f "$t"
done
```

---

## 5) Madde 7 — DURMA noktası (bu tur için geçerli sonuç)

> **Test ortamı VE şema-only dump HÂLÂ YOK.**
> - ❌ Uydurma base şema / `auth_role()` / tablo **üretilmedi.**
> - ❌ Canlıya bağlanıp **test çalıştırılmadı.**
> - ❌ Üretime **migration uygulanmadı**, **deploy** yapılmadı, **secret** değişmedi.
> - ⛔ İşlem **BURADA DURDURULDU.** Testler izole ortam + şema-only dump sağlanana kadar **BLOCKED.**

---

## 6) Madde 8 — İzole test ortamı HAZIR olduğunda izlenecek kesin adımlar

| # | Adım | Sorumlu | Girdi | Durum |
|---|---|---|---|---|
| 1 | Canlıdan bağımsız **izole Supabase projesi** aç | Proje sahibi | Dashboard erişimi | ⛔ BLOCKED (girdi) |
| 2 | **Şema-only dump** al (madde 1.2 komutu) | DB erişimi olan | `$PROD_DB_URL` (yalnız okuma) | ⛔ BLOCKED |
| 3 | Dump **veri içermiyor** mu doğrula (madde 3) | Geliştirici | `base_schema.sql` | ⛔ BLOCKED |
| 4 | Şemayı izole projeye yükle | Geliştirici | `$TEST_DB_URL` | ⛔ BLOCKED |
| 5 | 4 **private bucket** oluştur (dump'ta yoksa) | Geliştirici | İzole DB | ⛔ BLOCKED |
| 6 | `00_harness.sql` yükle | Geliştirici | İzole DB | ✅ dosya hazır / ⛔ ortam |
| 7 | Migration'ları **sırayla** uygula (madde 4.1) | Geliştirici | İzole DB | ⛔ BLOCKED |
| 8 | **Rollback provası** + yeniden uygula | Geliştirici | İzole DB | ⛔ BLOCKED |
| 9 | `guv*.test.sql` testlerini çalıştır | Geliştirici | İzole DB | ⛔ BLOCKED |
| 10 | Her test için **gerçek sonucu** PASS/FAIL kaydet | Geliştirici | Test çıktısı | ⛔ BLOCKED |

### 6.1 PASS/FAIL/BLOCKED sonuç tablosu (bu tur)

| Kontrol | Gerçekleşen | Durum |
|---|---|---|
| Production build | Çalıştırıldı | **PASS** |
| Salt-okuma katalog kontrolleri (anon exec=159, null search_path=4, `storage_tenant_ok` yok) | Çalıştırıldı | **PASS (statik)** |
| GUV-01…GUV-15 DB runtime testleri (12 senaryo seti) | İzole ortam yok → çalıştırılmadı | **BLOCKED** |
| Rollback provaları (9/9) | Çalıştırılmadı | **BLOCKED** |
| Fixture kolon uyumu (gerçek şemada) | İzole ortam yok → doğrulanamadı | **BLOCKED** |

> ⛔ **Hiçbir migration için PASS yazılmadı.** Yalnız gerçekten çalıştırılan item'lar PASS'tir.

---

## 7) Eksik girdiler (özet — test ortamı için gerekli minimum)

1. **İzole test Supabase projesi** (canlıdan bağımsız) — Dashboard/karar sahibi girdisi.
2. **Şema-only SQL dump** (veri içermeyen) — canlı DB **okuma** connection string girdisi.
3. **4 private bucket** (`atama-belgeleri`, `personel-foto`, `hazop-kanitlari`, `noter-defteri`).
4. (Fallback) Uygulama reposundan **base `supabase/migrations`** dosyaları — dump alınamazsa.
5. Auth Dashboard ayarları (self-signup KAPALI, parola politikası, rate limit) — Dashboard girdisi.

---

## 8) Üretim güvenliği (açık doğrulama — bu tur)

- ✅ Canlı DB'ye **hiçbir DDL/DML uygulanmadı** (yalnız salt-okuma SELECT).
- ✅ Gerçek kullanıcı/veri/hesap **kopyalanmadı, değiştirilmedi, silinmedi.**
- ✅ Production migration **çalıştırılmadı**, Edge Function **deploy edilmedi**, secret değişmedi.
- ✅ **Gizli anahtar / connection string rapora yazılmadı.**
- ✅ Hiçbir test sonucu uydurulmadı; çalıştırılamayanlar **BLOCKED** işaretlendi.

---

## 9) Bu turda oluşturulan / değiştirilen dosyalar

| Dosya | Durum |
|---|---|
| `SECURITY_PHASE10_TEST_ENV_CHECKLIST.md` | **Yeni** (bu doküman) |

> `src/**`, `supabase/migrations/**`, test dosyaları ve diğer güvenlik dokümanları
> **DEĞİŞTİRİLMEDİ** (bu tur yalnız inceleme + dokümantasyon).

---

## 10) Son karar

**Statik inceleme + ortam tespiti + test-ortamı kontrol listesi TAMAMLANDI.** Ancak:
- **İzole test ortamı + şema-only dump YOK** → tüm DB runtime testleri **BLOCKED**.
- **9 migration canlıda hâlâ uygulanmadı** → veri katmanı açık.

> **Üretime hazır DEĞİL.** Base şema (şema-only dump) ve izole test projesi sağlanmadan,
> hiçbir migration için PASS iddia edilemez. Bu çalışma resmî TSE onaylı sızma testinin
> yerine geçmez.