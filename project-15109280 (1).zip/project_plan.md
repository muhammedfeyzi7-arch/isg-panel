# ISGDenetim — Shared UI System

## 1. Proje Açıklaması
ISGDenetim (İş Sağlığı ve Güvenliği Denetim Sistemi) için 5 panel (Admin, OSGB, Firma, Uzman, Hekim) tarafından ortaklaşa kullanılacak merkezi, yeniden kullanılabilir Shared UI System ve UI Motorları.

## 2. Sayfa Yapısı
- `/` — Admin UI Referans / Shared UI Bileşenleri Ekranı (mevcut ana sayfa güncellenecek)
- `/not-found` — 404 sayfası (mevcut)

## 3. Çekirdek Özellikler
- [x] Theme Engine (Dark / Light / Auto)
- [x] Layout / Shell (Sidebar + Topbar + Content Area)
- [x] Shared UI Component Library (Button, Input, Badge, Card, Select, Toggle, Checkbox, Radio, Tabs, Search, FilterBar, Pagination, Avatar, Tooltip, FileUpload, DatePicker, TimePicker, Textarea, IconButton, StatCard, PageHeader, Loading, EmptyState, ErrorState, MultiSelect, Autocomplete)
- [x] Modal Motoru (draggable, resizable, yerinde minimize, multi-modal, z-index, keyboard, validation, loading, unsaved changes, dropdown viewport, responsive, dark/light/auto)
- [x] Listing/Table Motoru (search debounce, multi-filter/status/date-range, per-kolon sort, pagination, page size, selection, row actions, sonuç sayısı, loading, empty, error, responsive)
- [x] Detail Modal (Shared Modal Motoru üzerinden açılır — draggable, resizable, yerinde minimize, multi-modal, tabs, action, responsive, tema)
- [x] Toast/Notification Motoru (success, info, warning, error)
- [x] Confirmation Dialog Motoru
- [x] Form Motoru (useForm hook: label, required, validation, error, submit loading, çift submit engelleme, reset + ortak validatorlar required/email/minLength/maxLength/pattern/minValue/maxValue)
- [ ] Global Search (Search componenti hazır; global komut paleti ileride eklenecek)
- [x] Responsive Davranış
- [x] Keyboard / Focus Yönetimi (Modal odak yönetimi — Tab trap, ESC, focus restore)

## 4. Veri Modeli
Bu fazda database gerekmiyor. UI sistemleri mock/demo veriler ile çalışacaktır.

## 5. Backend / Üçüncü Taraf Entegrasyonu
- Database: Şu an gerek yok — UI altyapısı kurulum fazı.
- Shopify: Gerek yok.
- Stripe: Gerek yok.
- Diğer: Gerek yok.

---

# UI MİMARİSİ KİLİDİ (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI UI mimari standardıdır. Yeni ekran/panel/sekme eklenirken aşağıdaki kurallar ZORUNLUDUR. Kilitli görsel referans: `ISGDenetim_UI_Referanslari_4_Gorsel_Kilitli.docx` (Dark Tema, Açık Tema, Dark Modal, Açık Modal).

## A. Merkezi Tek Motor Kuralı

Projede her UI işlevi için TEK motor vardır. İkinci motor / sayfaya özel motor YASAKTIR:

| İşlev | Tek Kaynak |
|---|---|
| Modal | `useModal` + `Modal` + `ModalManager` |
| Listing/Table | `Table` (primitif) + `TableListing` (motor) |
| Pagination | `Pagination` |
| Filter | `FilterBar` |
| Search | `Search` |
| Detail Modal | `useModal` + `Modal` + `ModalManager` (variant: `detail`) |
| Form | `useForm` + `Input/Select/Textarea/Checkbox/Radio/Toggle/MultiSelect/Autocomplete/DatePicker/TimePicker/FileUpload` |
| Button | `Button` + `IconButton` (varyantlı) |
| Badge/Status | `Badge` (varyantlı) |
| Toast | `useToast` + `ToastManager` |
| Confirm | `useConfirm` + `ConfirmDialog` |
| Loading/Empty/Error | `Loading` / `EmptyState` / `ErrorState` |
| Focus/Keyboard | `Modal` odak yönetimi + `useDropdown` |
| Tema | `ThemeContext` (Dark / Light / Auto) |

> Not: `Table` düşük seviyeli sunum primitifidir; `TableListing` bunu `FilterBar` + `Pagination` + durumları (loading/empty/error) ile birleştiren yüksek seviyeli motordur. Bu doğru bir katmanlamadır — DUPLICATE DEĞİLDİR. Üçüncü bir tablo sistemi oluşturulamaz.

## B. Yeni Ekran Protokolü (9 Adım)

Yeni bir UI ihtiyacı oluştuğunda SIRAYLA:

1. Mevcut Shared UI componentleri kontrol et.
2. Uygun ortak component varsa MUTLAKA kullan.
3. Uygun component yoksa sayfaya özel component OLUŞTURMA.
4. Eksik component Shared UI System'e ekle.
5. Dark / Light / Auto desteği ekle.
6. Responsive davranış ekle.
7. Keyboard / Focus davranışı ekle.
8. Component'i reusable yap.
9. İlgili ekranda kullan.

## C. Page-Specific UI Yasağı

Sayfa içinde bağımsız olarak YENİDEN OLUŞTURULAMAZ:
Modal, Table, Pagination, Filter, Search, Form, Button, Input, Badge, File Upload, Date Picker, Time Picker, Toast, Confirmation Dialog.

YANLIŞ: `FirmaPersonelTable`, `FirmaPersonelModal`
DOĞRU: `TableListing` + personel kolon configuration; `Modal` + personel form configuration.

## D. Component Varyant Sistemi

Farklı ihtiyaçlarda component kopyalamak YERİNE mevcut component içinde varyant kullan:
- Button: `primary | secondary | ghost | outline | danger | success | warning | link | icon` + `xs | sm | md | lg`
- Modal: `default | form | wizard | confirmation | detail | large | fullscreen | standard | wide | extraWide` + `bodyLayout: scroll | fill | single | twoColumn | threeColumn | sidebar | split`
- Modal Manager (merkezi): `dedupeKey = modalType + entityId + contextId`. Aynı anahtar tekrar açılırsa İKİNCİ KOPYA AÇILMAZ; mevcut instance öne getirilir (küçültülmüşse geri açılır). Farklı entity/context yeni modal açabilir. Ekranda duran modaller üst üste birebir aynı yerde değil KONTROLLÜ stack offset ile açılır (viewport dışına taşmaz); en son açılan en üst z-index + odak sahibidir, ESC yalnız aktif modalı kapatır.
- Badge / Durum: `StatusBadge` (semantic tone: success/danger/warning/info/neutral) — iş durumu rozetleri TEK kaynaktan
- Segment / durum filtresi: `SegmentedControl` (opsiyonel `count` sayaç + `dotClassName` durum noktası) — sayfalara özel "sayaçlı pill sekmesi" YAZILMAZ
- Liste üst çubuğu: `Toolbar` (`.isg-toolbar-bar`) — filtre/arama/toplu aksiyon satırı TEK sözleşme
- Table: `standard | compact | selectable` (selectable flag ile)
- Risk sihirbazı UI katmanı (`wizardUi.tsx`): artık BAĞIMSIZ katman DEĞİL — `RwButton`/`RwIconButton` → `.isg-btn`+`.isg-btn-icon`, `RwInput`/`RwTextarea` → `.isg-input`+`.isg-form-label`, `RwSelect` → `.isg-input` trigger + `.isg-popover`, `RwCard` → `.isg-card`, `RwStepper` → `WizardStepper`, `RwTabs` → `SegmentedControl`, tarih/saat → `DatePicker`/`TimePicker`. Public API korunur; tüm risk modülü (~30 dosya) tek kaynaktan beslenir. Yerel `Segmented` kopyası (HariciTutanakEkleModal) `SegmentedControl`'e bağlandı.
- Fotoğraf görüntüleme (TEK KAYNAK): `PhotoLightbox` (`src/components/ui/PhotoLightbox.tsx`) — tüm modüllerin thumbnail'e tıklayınca açtığı merkezî tam ekran lightbox (overlay, oran koruyan görüntü, zoom, çoklu galeri ileri/geri + sayaç, ESC, dış tıklama, indir). `PhotoUpload` (boyut presetleri `sm/md/lg`, varsayılan `md`≈72px — gereksiz küçük kare yok) ve `ImageViewer` artık bu tek lightbox'ı kullanır; `SupportConversation`'ın yerel görsel önizlemesi de buraya bağlandı. Sayfaya özel ayrı lightbox ÜRETİLMEZ.
- Tarih seçici (TEK KAYNAK): `DatePicker` başlığında **Ay ve Yıl TIKLANIP seçilebilir** (ay ızgarası + 12'lik yıl listesi); kullanıcı hangi yılda olduğunu net görür ve tek tek ok basmadan yıl/ay atlar. Önceki/sonraki panel-duyarlı çalışır, Bugün/Temizle korunur, gösterim `DD.MM.YYYY`. Native `<input type="date">` hiçbir modülde gösterilmez (`Input`/`RwInput` otomatik delege eder).
- Wizard UI sarmalayıcıları (FINAL CONSOLIDATION): `wizardUi.tsx`'teki `RwInfoBanner` → canonical `Alert` (variant `info`), `RwPagination` → canonical `Pagination` (imza adaptörü) delegasyonuna tamamlandı. Böylece bilgi bantları ve sayfalama da TEK kaynaktan. `RwChip` → canonical **`Chip`** primitive'ine (`src/components/ui/Chip.tsx`, `.isg-chip` token sözleşmesi), `RwSectionTitle` → canonical **`SectionTitle`** primitive'ine (`src/components/ui/SectionTitle.tsx`) delege eder; ikisi de kendi renk/radius/typography tanımı TAŞIMAZ (KİLİTLİ). Böylece risk sihirbazı chip/bölüm-başlığı da TEK kaynaktan. Evrak klasör tile palet rengi (`bg-amber-*`) canonical `warning` token scale'ine çevrildi. **SHARED UI FINAL FREEZE:** Artık `Button/IconButton/Input/Textarea/Select/MultiSelect/DatePicker/TimePicker/DateTimePicker/Checkbox/Radio/Toggle/Badge/StatusBadge/SegmentedControl/Card/Alert/Toolbar/Pagination/WizardStepper/Modal/ModalManager/PhotoUpload/PhotoLightbox/FileUpload/CategoryList/SummaryStats/AiSuggestPanel + Chip + SectionTitle` canonical tek kaynaktır; feature modülü bunların kendi görsel versiyonunu OLUŞTURAMAZ; eksik ihtiyaç önce `SharedUICore`'a eklenir. Native `select/date/time/datetime-local` sıfır (Input/RwInput delege eder); kalan hex/palet renkler yalnızca belge/print yüzeyleri (Excel/PDF/Word önizleme, harita, zengin metin editörü, kroki tuvali) — spec'in izin verdiği istisnalar. Evrak dosya-türü rozeti (`EvrakDosyaTipiBadge`) elle yazılmış `bg-red-50 text-red-600…` renklerinden canonical `Badge` varyantına (danger/info/success/accent/default) bağlandı.
- Tek Kaynak doğrulaması (FINAL): Bir butonun stilini `isg-btn`'de değiştirmek tüm modülleri (risk sihirbazı dahil) etkiler; `DatePicker`/`TimePicker`/`Select`/`Badge`/`Card`/`Modal`/`PhotoLightbox`/`Pagination`/`Alert`/`Toolbar`/Typography için de aynı TEK KAYNAK → TÜM SİSTEM bağı geçerlidir.

## E. Tema Kilidi

Theme Engine merkezi kaynaktır (Dark / Light / Auto). Yeni component üç temada da çalışmalıdır. Component içinde bağımsız tema logic veya hardcoded renk OLUŞTURULMAZ. Renkler yalnızca 5 scale rolünden tüketilir: `background`, `primary`, `accent`, `secondary`, `foreground` (+ status: `success`, `warning`, `danger`, `info`). `slate`/`gray` gibi tasarım dışı paletler kullanılmaz.

## F. Tasarım Tutarlılık Kilidi

Tüm ortak componentlerde aynı değerler korunur: radius (`md`=6px, `lg`=8px), font (Inter), spacing, border, shadow, input/button/table-row yükseklikleri, badge/modal boyutları. Yeni ekran farklı değerler ÜRETMEZ.

## G. Gelecek Panel Kuralı

Bundan sonra OSGB → Firmalar, Firma → Personeller, Uzman → Tutanaklar, Hekim → Muayeneler gibi ekranlar eklendiğinde:
Shared Listing + Filter + Search + Pagination + Modal + Form kullanılır. Detay görüntüleme **Detail Modal** (Shared Modal Motoru) üzerinden yapılır. Sadece veri, kolon, filtre, form alanı ve iş kuralı değişir. UI davranışı ortak sistemden gelir.

---

# FİRMALAR MODÜLÜ — VERİ MODELİ (FAZ 1 / PROMPT 1)

> OSGB Yönetim Paneli Firmalar modülünün production-ready veri altyapısı. UI (Prompt 2) ve İSG Gereksinim Motoru (FAZ 2) bu temeli kullanır. Route: `/osgb-panel/firmalar`.

## A. Tablo: `public.firmalar` (tek kaynak, duplicate yok)

- `osgb_id` → OSGB izolasyonu (RLS + trigger ile kilitli, taşınamaz).
- `unvan`, `vergi_no`, `telefon`, `email`, `il`, `ilce`, `acik_adres`, `yetkili_*` → firma kimlik/iletişim/adres.
- `tehlike_sinifi` → kontrollü değer (`az_tehlikeli | tehlikeli | cok_tehlikeli`), CHECK constraint ile; mevzuat motoruna bağlanabilir.
- `firma_paneli_var` → panel erişimi var/yok. `manuel_calisan_sayisi` (CHECK >= 0) yalnızca panel-yok firmalar için geçerlidir.
- `latitude` / `longitude` / `geofence_radius_meters` → geofence altyapısı (nullable/configurable).
- `is_active` + `deleted_at` → soft archive (fiziksel silme YOK).

## B. Firma Paneli Kullanıcısı

- `profiles.firma_id` (FK) + `auth_firma_id()` helper → firma kullanıcısının firma kapsamı DB'den çözülür.
- Rol mimarisi değişmedi: `firma` rolü mevcut `profiles.role` ile kullanılır.

## C. RLS (gerçek güvenlik katmanı)

- SELECT: admin (tümü) / osgb_admin (kendi OSGB'si) / firma (kendi firması, panel var + aktif + arşivsiz).
- INSERT: osgb_admin için `osgb_id = auth_osgb_id()` zorunlu (cross-OSGB engelli).
- UPDATE: osgb_id değiştirilemez (WITH CHECK + `firma_lock_osgb` trigger).
- DELETE: fiziksel silme yok (`firma_prevent_delete` trigger + soft-delete).

## D. Davet & Edge Functions

- `davetler.firma_id` + `davetler_select_osgb_admin` policy (osgb_admin kendi davetlerini görür).
- `firma-davet` (create/invite/resend) — service role, osgb_id frontend'e güvenilmez.
- `accept-invite` → `role='firma'` dalı: profiles (role=firma + firma_id), osgb_yoneticileri YOK, double-accept ve cross-firma korumalı.

## E. Audit

`firma_audit` trigger (AFTER UPDATE) → `FIRMA_CREATED/UPDATED/ARCHIVED/RESTORED/DEACTIVATED/REACTIVATED/PANEL_ACCESS_CHANGED` + davet olayları `system_logs`'a düşer (mevcut `audit_log` ile).

---

# PERSONELLER MODÜLÜ — VERİ MODELİ (FAZ 1 / PROMPT 3)

> OSGB Yönetim Paneli Personeller modülünün production-ready veri altyapısı. UI (Prompt 4) bu temeli kullanır. Route: `/osgb-panel/personeller`. İlişki zinciri: `OSGB → Firma → Personel`.

## A. Tablolar (tek kaynak, duplicate yok)

1. **`public.personeller`** — personel kaydı (15 kolon): `id`, `osgb_id` (FK → osgb, trigger'dan türetilir), `firma_id` (FK → firmalar), `ad`, `soyad`, `tc_kimlik_no` (nullable, 11 hane CHECK), `email`/`telefon`/`gorev`, `ise_giris_tarihi`/`isten_cikis_tarihi` (`date` — timezone bug yok), `is_active`, `profile_id` (nullable FK → profiles, Auth user bağı), `created_at`/`updated_at`.
2. **`public.personel_egitimleri`** — eğitim kaydı (9 kolon): `personel_id` (FK), `egitim_turu` (FK → egitim_turleri), `egitim_tarihi` (date), `yenileme_tarihi` (nullable — Faz 2 kural motoru doldurur), `gecerlilik_durumu`, `belge_url`, zaman damgaları.
3. **`public.egitim_turleri`** — kontrollü referans (kod/ad/aktif/siralama). Serbest metin DEĞİL, Faz 2 mevzuat motoruna bağlanabilir. Yenileme SÜRESİ hardcode YOK.

## B. Personel ↔ Firma ↔ OSGB İzolasyonu

- `osgb_id` frontend'den ASLA alınmaz — `personel_validate_firma` trigger'ı firmayı okuyup `osgb_id`'yi firmanın OSGB'sinden türetir; firma↔OSGB uyuşmazlığı engellenir.
- Pasif/arşivlenmiş firmaya **yalnızca INSERT** engellenir; UPDATE (ör. işten çıkarma) firma pasifken de çalışır.
- `personel_lock_scope` trigger'ı `osgb_id`/`firma_id` değişimini bloklar (cross-OSGB/cross-firma taşıma yok).
- `personel_prevent_delete` → fiziksel silme yok; işten çıkarma soft state.

## C. İşe Giriş / Çıkış + Durum

- `isten_cikis_tarihi >= ise_giris_tarihi` (CHECK). `isten_cikis_tarihi` set edilip geçmiş/today ise `personel_normalize` trigger'ı `is_active=false` yapar; **gelecek** çıkış tarihi bugünkü aktifliği bozmaz.
- `profile_id` nullable → personel Auth user OLMADAN da geçerli kayıttır (personel ≠ panel kullanıcısı).

## D. RLS (gerçek güvenlik, USING(true) YOK)

- **SELECT:** admin (tümü) / osgb_admin (kendi `osgb_id`) / firma (kendi `firma_id`).
- **INSERT:** admin / osgb_admin (kendi OSGB'si, WITH CHECK).
- **UPDATE:** admin / osgb_admin (kendi OSGB'si; osgb_id/firma_id taşınamaz).
- **DELETE:** hiçbiri (fiziksel silme bloklu).
- `personel_egitimleri` RLS'si `personel_osgb_id()`/`personel_firma_id()` SECURITY DEFINER helper'larıyla kapsamı çözer.

## E. Çalışan Sayısı Kaynağı (Faz 2 hazırlığı)

- Panel YOK → `firmalar.manuel_calisan_sayisi` (mevzuat girdisi).
- Panel VAR → `firma_aktif_personel_sayisi(firma_id)` (aktif personel kayıtları). İkisi KARIŞTIRILMAZ.

## F. Audit

`personel_audit` / `personel_egitim_audit` trigger'ları → `PERSONEL_CREATED/UPDATED/DEACTIVATED/REACTIVATED/EMPLOYMENT_ENDED/TRAINING_CREATED/TRAINING_UPDATED` (`audit_log`, server-side `user_id/role/osgb_id`).

## G. Frontend Servis

`src/lib/personelService.ts` — tip + server-side listeleme (search/filter/sort/pagination), CRUD, eğitim türleri/eğitim kayıtları, aktif personel sayacı. UI Prompt 4'te; yeni modal/listing motoru YOK.

---

## 6. Geliştirme Faz Planı (TAMAMLANDI)

- [x] Faz 1: Theme Engine + CSS Variables + Layout (Shell, Sidebar, Topbar)
- [x] Faz 2: UI Bileşenleri (Temel + Form + Listeleme)
- [x] Faz 3: Modal Motoru + Form Motoru
- [x] Faz 4: Admin UI Referans Ekranı (Home Page)
- [x] Faz 5: Build Kontrol ve Son Test

## 7. QA / Tamamlama Kriteri

- [x] Shared UI System merkezi (src/components/ui + src/components/feature)
- [x] Theme Engine merkezi (Dark / Light / Auto)
- [x] Tek Modal Motoru
- [x] Tek Listing/Table Motoru
- [x] Tek Pagination / Filter / Search sistemi
- [x] Tek Detail Modal (Shared Modal Motoru üzerinden)
- [x] Tek Form Motoru
- [x] Ortak Button / Input / Badge / File Upload / Loading / Empty / Error
- [x] Responsive + Keyboard/Focus (Modal odak yönetimi)
- [x] Duplicate UI yok (tek motor, doğru katmanlama)
- [x] Page-specific UI motoru yok (home page yalnızca componentleri TÜKETİR)
- [x] Admin ekranları ortak motorları kullanıyor
- [x] 4 görsel referansa uyumlu
- [x] Dead code temizlendi (kullanılmayan import/state)

SONUÇ: SHARED UI SYSTEM + UI MOTORLARI KİLİTLENMİŞTİR. Yeni ekranlar yalnızca bu merkezi sistemi kullanır.

---

# ADMIN PANELİ — İŞLEV VE SORUMLULUK TANIMI (KALICI STANDART)

> Bu bölüm İSGDenetim Admin Panelinin KALICI kapsam ve sorumluluk tanımıdır. Admin'in neyi yönetip neyi YÖNETMEDİĞİ burada netleşir. Sonraki paneller (OSGB, Firma, Uzman, Hekim) ayrı fazlarda kurulur.

## A. 5 Panel Yapısı ve Hiyerarşi

1. Admin Paneli
2. OSGB Yönetim Paneli
3. Firma Paneli
4. Uzman Paneli
5. Hekim Paneli

ANA HİYERARŞİ: **ADMIN → OSGB → FİRMA → PERSONEL**
OSGB ayrıca firmalara Uzman ve Hekim atayabilir.

ŞU ANDA YALNIZCA ADMIN PANELİ kapsamındadır. Diğer 4 panel sonraki aşamalarda ayrı ayrı kurulacaktır.

## B. Admin'in Rolü

Admin, sistemin **merkezi yönetim ve kontrol katmanıdır**. Admin:
- OSGB hesaplarını yönetir.
- OSGB erişim sürelerini yönetir.
- OSGB yöneticilerini ve davetlerini yönetir.
- Diğer panellerden gelen destek taleplerini yönetir.
- Sistem duyurularını oluşturur ve yayınlar.
- Sistem loglarını takip eder.
- Sistem ayarlarını ve bakım durumunu yönetir.
- Genel sistem durumunu ve istatistiklerini izler.

Admin **operasyonel İSG personeli DEĞİLDİR**. Admin Firma operasyonlarını, Personel İSG işlemlerini, saha denetimini, risk değerlendirmesini, tutanak oluşturmayı, Uzman operasyonlarını ve Hekim muayenelerini YÖNETMEZ. Bu operasyonlar ilgili paneller tarafından yapılır.

## C. Admin Menüleri

| Menü | Amaç |
|---|---|
| Genel Bakış | Yönetimsel dashboard (istatistik, OSGB dağılımı, aktivite, bitişler, son talepler/duyurular, sistem özeti) |
| OSGB Yönetimi | OSGB hesap + erişim süresi + yönetici/davet yönetimi (4 adımlı Yeni OSGB wizard) |
| Destek Talepleri | Diğer panellerden gelen talepler; konuşma/thread, dosya eki, yanıt, kapat/işleme al/çözüldü |
| Duyurular | Duyuru oluştur/düzenle/yayınla (4 adımlı wizard, hedef kitle: Tümü/OSGB/Firma/Uzman/Hekim) |
| Sistem Logları | Log listeleme + detay + export |
| Ayarlar | Genel / Kullanıcı ve Yetkiler / Güvenlik / Entegrasyon / Sistem Yönetimi |

### OSGB Detayı ve İşlemleri

OSGB detayı **Detail Modal** üzerinden 4 sekmede açılır: **Genel Bilgiler / Yöneticiler / Davet Geçmişi / İşlemler**.

Admin'in OSGB üzerinde yapabildiği işlemler:
- Detay görüntüleme, Düzenleme, Yönetici görüntüleme
- Davet gönderme, Daveti yeniden gönderme, Davet geçmişini görüntüleme
- Erişim süresini uzatma
- Pasifleştirme, Tekrar aktifleştirme, OSGB'yi kapatma

### Destek Talebi ve Log Detayı — MODAL (Drawer YOK)

Destek talebi ve log detayı **Detail Modal** üzerinden açılır. "Sağ detay Drawer" KALDIRILMIŞTIR; kilitli standart ve mevcut kod **Modal Motoru** kullanır. Destek detayı içinde konuşma/thread, dosya ekleri (yükleme, drag & drop, görüntüleme, indirme), yanıt verme, işleme alma, çözüldü işaretleme ve kapatma yer alır.

### Planlı Bakım Detayı

Bakım Modu (Sistem Yönetimi sekmesi) kapsamında yönetilir: bakım başlangıç/bitiş tarihi ve saati, planlı bakım kayıtları, bakım geçmişi, kullanıcı bilgilendirmeleri ve e-posta bildirimi. Bakım sırasında Admin Paneli açık kalır; OSGB/Firma/Uzman/Hekim panelleri geçici olarak kapanır.

## D. Erişim Kontrolü (Paket/Abonelik YOKTUR)

Tek sistem erişimi vardır; paket, abonelik, plan, fiyatlandırma veya ödeme sistemi YOKTUR. Her OSGB için yalnızca: **Başlangıç tarihi/saati, Bitiş tarihi/saati, Aktif/Pasif durumu** yönetilir.

OSGB pasif olduğunda veya erişim süresi sona erdiğinde: **OSGB + OSGB'ye bağlı TÜM kullanıcılar** sisteme erişemez. OSGB tekrar aktif edildiğinde ve geçerli erişim süresi bulunduğunda erişim devam eder. Bu kontrol **merkezi OSGB seviyesinde** uygulanır.

Davet akışı: Admin OSGB oluşturur → yöneticiye davet gönderilir → yönetici daveti kabul eder → şifre oluşturur → OSGB Yönetim Paneline girer. Bir OSGB için **birden fazla** yönetici daveti desteklenir.

## E. Bakım Modu ≠ OSGB Pasifleştirme

İki AYRI sistemdir, karıştırılamaz:
- **Bakım Modu (Maintenance):** Bütün operasyonel panelleri (OSGB, Firma, Uzman, Hekim) GEÇİCİ olarak kapatır. **Admin Paneli açık kalır.** Planlı bakım (başlangıç/bitiş tarih-saat) + bakım geçmişi + kullanıcı e-posta bilgilendirme desteklenir.
- **OSGB Pasif:** Yalnızca ilgili OSGB'yi ve bağlı kullanıcılarının erişimini kapatır.

## F. Tasarım ve UI Kuralları

- Dark Premium UI ana görsel referanstır; **Dark / Light / Auto** desteklenir.
- **Dark Theme Standardı — Near-Black Premium:** Ana zemin siyaha yakın (near-black). Kartlar ve paneller arka plandan çok hafif yüzey farkıyla ayrışır. Borderlar çok düşük kontrast (opacity ~0.18–0.25). Blue-purple accent kontrollü ve sınırlı kullanılır. Yüksek okunabilirlik, minimal görsel gürültü, profesyonel enterprise SaaS görünümü.
- Shared UI sistemi KİLİTLİDİR: yeni UI/modal/tablo/pagination/filter/form sistemi OLUŞTURULMAZ. Mevcut motorlar kullanılır. Detay ekranları tek standartla açılır: **LISTE → DETAIL MODAL → (gerekirse başka MODAL)**. Detail Drawer / sağ detay paneli KALDIRILMIŞTIR.
- Spacing, typography, radius, border, button, badge, input ve layout dili korunur.
- **Aktif menü accent rengi BLUE-PURPLE olmalıdır. KIRMIZI AKTİF MENÜ KULLANILMAZ.** (Mevcut durum: aktif menü `primary-500` kullanır — hue 263, blue-purple — zaten uyumlu.)
- PROFİL: Admin Ad/Soyad/Profil fotoğrafı değiştirebilir; Topbar güncel profil bilgisini gösterir.
- GÜVENLİK: Şifre değiştirme ve güvenlik yönetim işlemleri.

## G. Admin Kapsam Sınırı

Admin sistemin yönetim katmanıdır. Admin tamamlandıktan sonra sıradaki panel **OSGB YÖNETİM PANELİ**dir; sonra Firma → Uzman → Hekim. Admin paneline bu panellerin operasyonel özellikleri EKLENMEZ.

## H. DOSYA YÜKLEME KİLİDİ (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI dosya yükleme standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM sayfa/sekme/form/modal/özellikte aşağıdaki kurallar ZORUNLUDUR.

### H1. Tek Ortak Motor

Dosya yükleme için TEK kaynak vardır: `src/components/ui/FileUpload.tsx` (Shared File Upload Motoru). Sayfaya/panela özel ayrı file upload component OLUŞTURULAMAZ. Yeni dosya yükleme davranışı İCAT EDİLMEZ.

### H2. URL İle Dosya Yükleme YASAKTIR

- Dosya URL'si girme alanı YOKTUR.
- "URL'den yükle", "Dosya URL'si", "Link ile yükle" veya benzeri yöntem YOKTUR.
- Harici URL üzerinden dosya alma özelliği OLUŞTURULMAZ.

ÖZET: URL'den dosya yükleme = YOK. Dosya URL'si = YOK. Harici link ile dosya alma = YOK. Bilgisayardan dosya seç = VAR. Sürükle & Bırak = VAR. Tek ortak Shared File Upload motoru = ZORUNLU.

### H3. Desteklenen Davranışlar (Motor Kapsamı)

- Dosya seç butonu / bilgisayardan dosya seçme
- Drag & Drop (sürükle & bırak, sürüklenirken görsel aktif durum)
- Multi-file desteği (`multiple`)
- Yükleme ilerleme göstergesi (progress)
- Başarılı yükleme / hatalı yükleme durumu
- Yükleme iptali
- Dosya kaldırma
- Dosya değiştirme (replace)
- Dosya adı + boyutu + dosya türü (uzantı) gösterimi
- Güvenlik/doğrulama: uzantı + MIME type + boyut kontrolü (geçersiz dosya reddedilir, nedeni açıkça gösterilir)

### H4. Gelecekteki Tüm Geliştirmeler İçin Kilit

Bundan sonra oluşturulacak HERHANGİ BİR dosya alanı (Evrak, Belge, Rapor, Tutanak, Sertifika, Sağlık evrakı, Ek dosya, Destek eki, Duyuru eki, Personel belgesi, Firma belgesi, Denetim dosyası, Muayene dosyası, diğer tüm dosya alanları) için aynı Shared File Upload sistemi (`FileUpload`) kullanılacaktır.

---

## I. ORTAK SAYFA / LAYOUT MOTORU KİLİDİ (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI sayfa/layout/liste standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM sayfa/sekme/liste için aşağıdaki kurallar ZORUNLUDUR.

### I1. Ortak Motorlar (Tek Kaynak)

| İşlev | Tek Kaynak |
|---|---|
| App Layout | `Shell` (Sidebar + Topbar + içerik alanı) |
| Sidebar | `Sidebar` (sabit, sayfayla kaymaz) |
| Header/Topbar | `Topbar` (sabit) |
| Page Başlığı | `PageHeader` (yalnızca net başlık, açıklama YOK) |
| Liste Motoru | `TableListing` |
| Tablo Primitifi | `Table` (sticky header destekli) |
| Pagination | `Pagination` (10/20/50/100, varsayılan 10) |
| Sayfa Scroll | `main` iç scroll (viewport'a oturur, global scroll YOK) |

### I2. Sayfa Başlığı Kuralı

- BAŞLIK + açıklama metni = YOK. Sayfa başlığı gerekiyorsa yalnızca net başlık gösterilir.
- "sistemde gerçekleşen tüm işlemleri görüntüleyin...", "kullanıcıları yönetin...", "talepleri görüntüleyin...", "duyuruları yönetin..." gibi açıklama satırları KULLANILMAZ.

### I3. Layout / Viewport Kilidi

- Dış kapsayıcı `h-screen overflow-hidden` — body gereksiz uzamaz, global browser scrollbar OLUŞMAZ.
- Sidebar = sabit (sayfa scroll'u ile hareket ETMEZ). Header = sabit.
- İçerik alanı (`main`) `flex-1 min-h-0 overflow-y-auto` — yalnızca içerik gerektiğinde scroll alır.
- Liste sayfaları `h-full flex flex-col` yapısında; header/stat/filtre `flex-shrink-0`, liste `flex-1 min-h-0`.

### I4. Liste / Tablo Kilidi

- Varsayılan kayıt sayısı = 10. Kullanıcı değiştirmedikçe 10'dan fazla kayıt GÖSTERİLMEZ. Seçenekler: 10 / 20 / 50 / 100.
- Tablo gövdesi gerektiğinde kendi içinde scroll alır; Sidebar, Header, Page Toolbar ve Pagination SABİT kalır.
- Tablo başlığı (thead) sticky'dir (solid zemin ile).
- Pagination tablonun kendi alanının altında, sabit.

### I5. Gelecekteki Tüm Geliştirmeler İçin Kilit

Bundan sonra oluşturulacak HER panel + HER sekme + HER liste + HER tablo bu ortak Layout/Page/List motorunu kullanır. Aynı davranış sayfa bazında TEKRAR kodlanmaz.

---

## J. GLOBAL UI MOTORU — TEK KAYNAK MİMARİSİ KİLİDİ (KALICI STANDART)

> Bu bölüm İSGDenetim'in EN ÜST düzey UI mimari standardıdır. Aşağıdaki kurallar A–I bölümlerindeki tüm kilitlerin çatısıdır. Bir çelişki olursa TEK KAYNAK ilkesi önceliklidir.

### J1. Tek Kaynak İlkesi

Bir UI davranışı/tasarımı SADECE BİR kez yazılır, bir kez düzeltilir, tüm panellerde otomatik kullanılır. Bir bug bulunduğunda düzeltme YALNIZCA ilgili Shared motorunda yapılır; panel bazlı lokal CSS veya kopya component YAZILMAZ.

### J2. Global Shared Motorlar (Tek Kaynak Envanteri)

| Katman | Tek Kaynak (Shared) |
|---|---|
| Layout | `Shell` (Topbar + Sidebar + içerik) |
| Topbar / Header | `Topbar` (sabit; tema + bildirim + arama + kullanıcı ortak) |
| Sidebar | `Sidebar` (sabit, genişlet/daralt, baret logosu, ortak aktif menü) |
| Page Container / Başlık | `PageHeader` (yalnızca net başlık) |
| Modal | `useModal` + `Modal` + `ModalManager` |
| Table | `Table` (primitif) + `TableListing` (motor) |
| Pagination | `Pagination` (10/20/50/100, varsayılan 10) |
| Search / Filter | `Search` + `FilterBar` |
| Form | `useForm` + `Input/Select/Textarea/Checkbox/Radio/Toggle/MultiSelect/Autocomplete/DatePicker/TimePicker` |
| Button | `Button` + `IconButton` (primary/secondary/ghost/danger/outline + loading/disabled/icon) |
| Badge / Status | `Badge` |
| Dropdown | `useClickOutside` + `useDropdownDirection` + `Select` |
| Toast | `useToast` + `ToastManager` |
| Confirm | `useConfirm` + `ConfirmDialog` |
| File Upload / D&D | `FileUpload` |
| Loading / Skeleton / Empty / Error | `Loading` / `EmptyState` / `ErrorState` |
| Tooltip | `Tooltip` |
| Card | `Card` |
| Theme | `ThemeContext` (Dark / Light / Auto) |
| Design Tokens | `index.css` `:root` / `.dark` scale değişkenleri |

### J3. Config-Driven UI

Ortak motorlar davranışı CONFIGURATION üzerinden alır, panel tarafından yeniden yazılmaz:
- Table/Listing: `columns`, `data`, `filters`, `search`, `pagination`, `selectable`, `rowActions`, `onRowClick`, `emptyState`, `loading`, `error`.
- Modal: `title`, `content`, `size`/`width`/`height`, `draggable/resizable/minimizable/maximizable/closable`, `steps`. Modal geometrisi KALICI olarak hatırlanmaz; her açılışta viewport merkezinden başlar (kalıcı position/size hafızası YOKTUR).
- Paneller yalnızca VERİ + BUSINESS LOGIC + kolon/filtre/form alanı + iş kuralı tanımlar. UI davranışını (positioning, layout, style, pagination, sidebar, toast, theme, spacing, typography) tanımlamaz.

### J4. Panel Bazlı Kopya YASAĞI

`AdminTable`, `OSGBTable`, `FirmaTable`, `UzmanTable`, `HekimTable`, `ModalA`, `ModalB`, `OSGBModal`, `AdminModal`, `DetailModal` gibi ayrı kopyalar OLUŞTURULMAZ. Aynı işi yapan component tek `Shared` motor altında birleştirilir. Satır tıklaması detay açıyorsa ayrı göz/detay ikonu KULLANILMAZ; ayrı işlem gerekiyorsa action icon kullanılır.

### J5. Design Token Kilidi

font / font-size / line-height / spacing / radius / border / shadow / colors / component heights / transitions / z-index / breakpoints yalnızca merkezi token sisteminden gelir. Component içinde rastgele değer veya hardcoded renk (hex/rgb/hsl/`text-emerald-*` gibi tasarım-dışı Tailwind paleti) ÜRETİLMEZ. Renkler yalnızca 5 rol (`background/primary/accent/secondary/foreground`) + status (`success/warning/danger/info`) scale'inden tüketilir. **Overlay/backdrop opaklığı da TEK kaynaktır:** modal, bottom sheet, belge önizleme tam ekran, rapor tam ekran ve mobil çekmece perdelerinin TAMAMI `.isg-overlay` (↔ `.isg-modal-overlay`) sınıfını kullanır (Light 0.40 / Dark 0.55, animasyonsuz). Bileşen içinde rastgele `bg-black/30..70` perde DEĞERİ YAZILMAZ. (Görsel üzeri silme/zoom rozet scrim'leri ve renkli sekme pill'lerinin `bg-white/20` gibi kullanımları semantik olduğu için kapsam DIŞINDADIR.)

### J6. Toast / Confirm

Tüm bildirim `useToast`+`ToastManager`, tüm onay `useConfirm`+`ConfirmDialog` kullanır. Tarayıcı `alert`/`confirm` KULLANILMAZ.

### J7. Global Düzeltme Kuralı

"X panelindeki modal yanlış" → o panel için CSS YAZILMAZ, `Modal` düzeltilir. "X tablosunda pagination bozuk" → yeni pagination YAZILMAZ, `Pagination` düzeltilir. Bu kural sistem genelinde zorunludur.

### J8. Yeni Ekran Kuralı

Yeni panel/sekme açıldığında YENİ UI COMPONENTİ OLUŞTURULMAZ. Önce Shared motor aranır; uyuyorsa kullanılır, uymuyorsa Shared component geriye dönük uyumlu şekilde GELİŞTİRİLİR (tüm sistemi bozmadan).

---

## K. SIDEBAR + LOGO / BRANDING MOTORU KİLİDİ (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI logo ve sidebar branding standardıdır. Tüm 5 panel (Admin, OSGB, Firma, Uzman, Hekim) ve bundan sonra oluşturulacak TÜM sayfa/sekme aynı Branding motorunu kullanır.

### K1. Tek Ortak Logo Kaynağı

Logo ve mark sisteminin TEK kaynağı vardır: `src/components/feature/BrandLogo.tsx` (Shared Branding Motoru). Panel başına farklı logo veya mark OLUŞTURULMAZ.

### K2. BrandLogo Varyantları

| Varyant | Kullanım | Davranış |
|---|---|---|
| `full` (default) | Geniş sidebar, Topbar mobile, tarayıcı sekmesi başlığı yanı | Tam `İSGDenetim` logosu (baret + kalkan + yazı). Geniş, yatay. |
| `mark` | Daraltılmış sidebar, favicon | Yalnızca `baret + kalkan` amblemi. `object-cover object-left` ile aynı logo görselinden sol kısım kırpılarak elde edilir. Kare konteyner. |

### K3. Sidebar Logo Kuralları

- **Geniş sidebar:** `BrandLogo variant="full"` kullanılır. Logo belirgin ve profesyonel boyuttadır (h-14). Oran korunur, bulanıklaşmaz, sıkıştırılmaz.
- **Daraltılmış sidebar:** `BrandLogo variant="mark"` kullanılır. Yazılı "İSGDenetim" metni KESİNLİKLE gösterilmez. Yalnızca baret + kalkan amblemi ortalanır (h-10 w-10). Oran korunur, kırpılmaz.
- **Geçiş sırasında:** `transition-all duration-200` ile logo zıplamaz, bozulmaz, yeniden boyutlandırılırken kırpılmaz.

### K4. Favicon

Tarayıcı sekmesindeki favicon: `BrandLogo` motorunun `mark` varyantıyla aynı kaynağı (logo görseli) kullanır. `<link rel="icon">` olarak logo PNG'si atanır. Yalnızca baret + kalkan amblemi temsil eder. `vite.svg` gibi yer tutucu favicon KULLANILMAZ.

### K5. Panel Logo Yasağı

Admin, OSGB, Firma, Uzman, Hekim panellerinde AYRI logo veya mark kullanılmaz. Tüm paneller aynı `BrandLogo` motorunu ve aynı logo görsel URL'lerini tüketir. Panel bazlı branding farklılaştırması YAPILMAZ.

### K6. Gelecekteki Tüm Geliştirmeler İçin Kilit

Bundan sonra oluşturulacak HER panel + HER sekme + HER layout aynı `BrandLogo` motorunu kullanır. `variant` prop ile `full` veya `mark` seçilir. Yeni logo/mark asset OLUŞTURULMAZ, mevcut logo görseli dışında başka branding kaynağı KULLANILMAZ.

---

## L. MODAL MOTORU KİLİDİ (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI modal motoru standardıdır. Tüm 5 panel (Admin, OSGB, Firma, Uzman, Hekim) ve bundan sonra oluşturulacak TÜM sayfa/sekme/modal bu motoru kullanır. Modal davranışı tek bir `Modal` componentinde merkezileştirilmiştir; panel başına farklı modal davranışı OLUŞTURULAMAZ.

### L1. Modal Açılış Konumu ve Hareket Alanı (VIEWPORT)

- **Yeni modal HER ZAMAN, İSTİSNASIZ viewport'un GERÇEK matematiksel merkezinden açılır.**
- Sağ altta açılma, önceki modal konumunun yeniden kullanılması ve cascade offset YASAKTIR.
- **ZERO-JUMP konum modeli (iki mod, tek motor):**
  - **MERKEZLİ (varsayılan):** Konum JS ile değil CSS layout ile çözülür — `left/top: 50%` **ve** `transform: translate(-50%, -50%)` birlikte. Modal kendi GERÇEK render boyutuna göre İLK PAINT'te tam viewport merkezindedir. Auto-height içerik (asenkron veri, font/ikon yüklenmesi) paint sonrası değişse bile tarayıcı boyutu AYNI layout geçişinde simetrik uygular — AYRI bir konum-düzeltme adımı (zıplama) OLUŞMAZ. "Önce render et → sonra JS ile merkezle" mantığı YASAKTIR. `transform` yalnızca bu merkezli modda ve yalnızca gerçek merkezi garantilemek için kullanılır (çıplak `top:50%/left:50%` bırakma YASAK).
  - **SERBEST:** Kullanıcı modalı elle taşırsa, boyutlandırırsa veya maximize ederse modal absolute `left`/`top` + `width`/`height` ile konumlanır. Bu pozisyon yalnızca açık oturum içindir; modal kapanınca (yeni `id`) tekrar MERKEZLİ moda döner.
  - **Mod geçişi zıplamasız:** Serbest moda geçiş, pointerdown anında yakalanan GERÇEK `getBoundingClientRect()` değerinden yapılır → `transform` kaldırılıp `left/top` aynı görsel konuma sabitlenir.
- Kalıcı geometry hafızası (localStorage/IndexedDB/context) YOKTUR; her açılış temiz başlar (J3 kilidiyle tutarlı).
- **DİKEY GEOMETRİ — KONTROLLÜ YÜKSEKLİK (Modal.tsx `resolveInitialSize`, Shared UI tek kaynak):** `height` AÇIKÇA verilmişse (belge/görsel/Excel viewer gibi sabit çerçeve gerektiren özel içerikler) o değer korunur. Aksi halde çerçeve yüksekliği `auto` (CONTENT-FIT) DEĞİLDİR; viewport'a göre KONTROLLÜ bir px (`resolveDefaultModalHeight`) kullanılır — dar/küçük modaller (`≤620px`) doğal yükseklikte kalır; içerik yüksekliği ÖLÇÜLMEZ. `minHeight` artık SABİT çerçeve yüksekliği DEĞİL, yalnızca TABAN (CSS `min-height`) olarak uygulanır. **İçerik viewport'a sığıyorsa DİKEY SCROLL OLUŞMAZ** (gereksiz erken scrollbar yok); içerik viewport'u yalnızca FİZİKSEL olarak aşarsa gövde dikey kaydırılır. **Kullanıcı modalı elle küçültürse** (serbest mod → sayısal height) çerçeve sabitlenir; içerik sığmıyorsa gövde dikey kaydırılır, tekrar büyütünce scroll OTOMATİK kalkar. **Tek istisna:** Firma Detay → İSG Gereksinimleri uzun listesi bu motorun viewport sınırı içinde kendi içeriğine göre gösterilir — sayfaya özel width/scroll hack'i YAZILMAZ, karar merkezi motorda verilir. Modalların yatay scroll'u AYNEN yasaktır (aşağıdaki adaptif genişlik + `.isg-modal-body` reflow motoru). Açılışta `animation`/`transition`/scale/slide/fade YOKTUR (`.isg-modal-content` + `.isg-modal-overlay` → `animation:none; transition:none`); overlay ile modal AYNI frame'de mount edilir. Focus `preventScroll` ile alınır → açılışta gövde scroll pozisyonu kaymaz. Modal açılışını animasyonlu hale getiren hiçbir page-specific CSS/hack YAZILMAZ (J7/N4).
- **GEOMETRY LOCK — SEKME/VERİ DEĞİŞİMİNDE DIŞ GEOMETRİ SABİT (Modal.tsx, Shared UI tek kaynak):** Modal AÇILDIĞI ANDA dış geometri (genişlik + yükseklik + merkez) merkezi preset + global tavan + viewport'tan BİR KEZ hesaplanır ve SABİTLENİR. Sekme değişimi, veri yüklenmesi (spinner → veri), API sonucu, loading ve içerik reflow'u modalın KUTUSUNU büyütüp küçültmez — yalnızca İÇERİK değişir; içerik KENDİ gövdesinde akar/sarılır/kaydırılır. Kök neden: `height:auto` (content-fit) + CSS merkezleme birleşince sekme değişimi kutuyu ortadan simetrik "katlıyordu". Çözüm: içerik yüksekliği ARTIK ÖLÇÜLMEZ; kontrollü px sabittir (önceki `ResizeObserver` tabanlı one-shot content-fit kilidi KALDIRILDI → forced-reflow/layout-thrashing YOK). Geometri YALNIZCA kullanıcı resize/drag, minimize/maximize/restore veya gerçek viewport resize ile değişir. Kalıcı geometry hafızası (persistKey/localStorage/sessionStorage/ModalMemory) KESİNLİKLE yoktur ve geri getirilmez; ikinci bir modal/scroll motoru ÜRETİLMEZ. Erken scrollbar/vertical scroll eklemek yerine layout içerik-fit açılır; tek sayfa-özel width/scroll hack'i YASAK (J7/N4).
- **GLOBAL GENİŞLİK TAVANI + MERKEZİ PRESET (Shared UI tek kaynak):** Standart modalın genişliği merkezi preset (`SIZE_PRESETS`) + GLOBAL GENİŞLİK TAVANI (`MODAL_MAX_WIDTH_REFERENCE` = 1080) + kullanılabilir VIEWPORT ile çözülür (`resolveModalWidth` → `modalViewportMaxWidth`). Sayfanın verdiği `width` (ör. `1400`) MUTLAK (100% tasarım px'i) ele alınır ama TAVANI AŞAMAZ — 1120/1200/1240/1280/1400 gibi geniş değerler modalı gereksiz büyütemez. Global yoğunluk (--d-density-scale) modalın DIŞ geometrisini (width/height) KÜÇÜLTMEZ, yalnızca İÇERİĞİN tipografik/spacing ölçüsünü etkiler. **İçerik ölçümü (scrollWidth vb.) ile genişlik BÜYÜTME YAPILMAZ** (önceki paint-öncesi content-aware güvenlik ağı KALDIRILDI); gizli/lazy sekme içeriği, tablo, harita ve grafikler modal genişliğini DEĞİŞTİREMEZ. `fullscreen`/maximize/elle resize istisnadır. **Modal gövdesinde YATAY SCROLL YASAKTIR** (yalnızca dikey scroll normaldir; gerçekten yatay gezinme gereken özel viewer/grid alanları kendi kutusunda `overflow-x-auto` kullanabilir). **Modal içi tablo hücreleri SARILIR:** Shared Table'ın `lg:whitespace-nowrap` kilidi `.isg-modal-body td/th` kapsamında gevşetilir (yoksa uzun açıklama metinli iş tablosu tek satıra zorlanıp tabloyu modal genişliğinin çok üstüne taşırır → yatay scroll). Bu kural sayfa bazlı width hack'i ile DEĞİL, `resolveModalWidth` + `.isg-modal-body` üzerinden GLOBAL çözülür. **NESTED/DUBLICATE SCROLL TEMİZLİĞİ (Shared UI tek kaynak):** Paylaşılan `Table` KENDİ yatay scroll konteynerini kurar (`.isg-table-scroll`). Ancak sayfalarda/modal içeriklerinde tablo sıklıkla İKİNCİ bir `overflow-x-auto` sarmalayıcısı içine alınmıştı → aynı anda iki iç içe scroll kaynağı. Bu, 30+ dosyaya sayfa-özel yama YAPILMADAN tek global kural ile çözülür: `[class*="overflow-x-auto"]:has(> .isg-table-scroll) { overflow-x: visible }` → yalnızca paylaşılan tabloyu saran GEREKSİZ dış sarmalayıcı etkisizleşir, tek scroll kaynağı olarak tablonun kendi konteyneri kalır. Ayrıca gerçek kök (`html`) seviyesine `overflow-x: clip` eklenir (scroll konteyneri oluşturmaz, fixed/sticky bozulmaz) → uygulamanın TAMAMINDA yatay sayfa scroll'u kökten imkânsızdır.
- **Modalın hareket alanı browser viewport'un TAMAMIDIR.** Topbar modalı SINIRLANDIRMAZ; sidebar modalı SINIRLANDIRMAZ. Modal Topbar'ın ve Sidebar'ın ÜZERİNE çıkabilir, ekranın tamamında serbestçe sürüklenebilir.
- `getWorkspaceBounds()` viewport'u (`window.innerWidth/innerHeight`) kullanır; `main` elementine bağlanmaz (bu, modalı topbar altına/sidebar sağına hapseden hatalı davranışı önler).
- Sürükleme sonrası konum aynı modal oturumu içinde korunur. Modal kapatılıp yeniden açıldığında (yeni `id`) tekrar merkezden başlar.

### L2. Modal State'leri

Modalın 3 temel görünüm durumu vardır:

| Durum | Davranış |
|---|---|
| **NORMAL** | Ekran merkezinde. Sürüklenebilir. Yeniden boyutlandırılabilir. Header'dan sürüklenebilir. |
| **BÜYÜTÜLMÜŞ (MAXIMIZED)** | Çalışma alanını (viewport) tamamen kaplar. Header ve kontrol butonları görünür kalır. Restore butonu çalışır. Kapat butonu çalışır. İçerik çalışmaya devam eder. Sürükleme ve resize devre dışıdır. |
| **KÜÇÜLTÜLMÜŞ (MINIMIZED)** | Modal YERİNDE kalır (konum DEĞİŞMEZ). İçerik (body + footer + wizard adımları) gizlenir, yalnızca kompakt başlık görünür kalır. Boyut küçülür. Uygulamanın diğer alanları kullanılmaya devam eder. Başlıktaki geri-aç butonuna veya başlığa tıklayınca normal görünüme döner; konum değişmez. |

### L3. Header Kontrolleri

Her modal başlığında sağ üstte sırasıyla şu kontroller bulunur:

```
[ — ] [ Büyüt/Restore ] [ X ]
```

- **Küçült:** Modalı YERİNDE küçültür (collapse) — içerik gizlenir, yalnızca kompakt başlık kalır, konum DEĞİŞMEZ. Buton DRAG BAŞLATMAZ (pointer event drag sisteminden izole). Minimize edilmişken aynı buton geri-aç (restore) işlevi görür.
- **Büyüt/Restore:** Normal ↔ Büyütülmüş arasında geçiş yapar. Büyütülmüşken sağ alta veya başka konuma sıçramaz. State değişimi sırasında `left`/`top`/`width`/`height` değerleri yanlışlıkla sıfırlanmaz.
- **Kapat:** Modalı kapatır.

### L4. Sürükleme (Drag)

- Sadece **header** alanından sürüklenebilir.
- Büyütülmüş (maximized) modal sürüklenemez; restore sonrası drag TEKRAR çalışır.
- Minimize edilmiş modalın header'ına tıklanması drag DEĞİL restore tetikler.
- **Header'daki kontrol butonları (küçült / büyüt / kapat) DRAG BAŞLATMAZ.** Butonların pointer/mouse event'leri drag sisteminden izole edilir (`stopPropagation` + `closest('button')` kontrolü). Butona basınca modal hareket ETMEZ, yalnızca ilgili işlem çalışır.
- Sürükleme sırasında modal ekran dışına tamamen kaçamaz; en azından header/kontrol alanı görünür kalır.
- `transform` kullanılmaz; doğrudan `left`/`top` güncellenir.

### L5. Yeniden Boyutlandırma (Resize)

- Sadece **NORMAL** durumda yeniden boyutlandırılabilir.
- **4 kenar (üst/alt/sağ/sol) + 4 köşe (nw/ne/sw/se)** olmak üzere 8 yönlü resize desteklenir.
- Minimum `width`/`height` değerleri (`minWidth`/`minHeight`) korunur.
- Viewport dışına taşarsa otomatik olarak görünür alan içine alınır (kenar/köşe yönlerine göre `left`/`top` sınırlanır).
- Resize sonrasında drag çalışmaya devam eder.
- Büyüt → Restore → Resize → Drag kombinasyonlarının tamamı çalışır.

### L6. Modal Açıkken Uygulama Kullanılabilirliği

- Modal açıkken arka plan tamamen kilitlenmez.
- **pointer-events: none** backdrop yalnızca estetik olarak kullanılır; uygulamayı kilitlemez.
- Kullanıcı modal açıkken: sidebar sekmesine basabilir, başka panel açabilir, başka sekmeye geçebilir, header'daki arama alanını kullanabilir, tema ikonuna basabilir, bildirimlere erişebilir, yeni modal açabilir.
- Aktif modal en üstte (en yüksek z-index) olur; diğer modallar ve uygulama arka planı etkileşimlidir.

### L7. Çoklu Modal (Multi-Modal)

- Aynı anda birden fazla modal açık olabilir.
- Her modal kendi `id`, `state`, `position`, `size`, `z-index`, `minimize/maximize` durumu ile çalışır.
- Bir modal diğerinin sistemini bozmaz.
- Tıklanan modal otomatik en üste getirilir (z-index artırılır).

### L8. Tema Butonu Modal Açıkken Çalışır

- Header'daki tema kontrolü (tek ikon, dropdown yok) modal açıkken de çalışır.
- Tek tıklama ile Açık ↔ Koyu geçişi yapılır.

### L9. Gelecekteki Tüm Geliştirmeler İçin Kilit

Bundan sonra oluşturulacak HER panel, HER sekme, HER detay ekranı, HER form ve HER wizard bu `Modal` motorunu kullanır. Panel başına farklı modal davranışı (draggable, resizable, minimize, maximize, z-index, position, keyboard, backdrop) OLUŞTURULAMAZ.

---

## M. TABLO / LİSTE MOTORU KİLİDİ (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI tablo/liste motoru standardıdır. Tüm 5 panel ve bundan sonra oluşturulacak TÜM liste/tablo ekranları `Table` + `TableListing` motorunu kullanır.

### M1. Satır Aksiyonları

- Satırın tamamı tıklanabilir olduğunda (`onRowClick` tanımlı), aynı işlevi yapan ayrı **göz / detay / görüntüle** ikonu KULLANILMAZ.
- Satır tıklaması zaten detay modalı açıyorsa, aksiyon kolonunda sadece **farklı işlevler** (örneğin: Düzenle, Sil) bulunur.
- Aksiyon kolonu gereksiz ikonlarla doldurulmaz; yalnızca gerçekten gerekli aksiyonlar gösterilir.

### M2. Satır Görünümü

- Satır: temiz, sade, okunabilir, tıklanabilir olduğu belli olacak şekilde tasarlanır.
- `cursor-pointer` uygulanır.
- Hover: hafif arka plan değişimi (`isg-table-row:hover`).
- `isg-table-row-selected` seçili satır vurgusu uygulanır.

### M3. Gelecekteki Tüm Geliştirmeler İçin Kilit

Yeni liste ekranı açıldığında `TableListing` motoru kullanılır. Sayfaya özel tablo componenti OLUŞTURULAMAZ. Aksiyon kuralları (M1) ve satır görünümü kuralları (M2) tüm listeler için geçerlidir.

---

## O. GLOBAL MOBİL UI MOTORU KİLİDİ (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI mobil responsive UI standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM sayfa/sekme mobil UI bu motoru kullanır. Panel bazlı farklı mobil UI OLUŞTURULMAZ.

### O1. Mobil Sidebar = YOK

- Sidebar mobilde asla görünmez.
- Hamburger, drawer, daraltılmış sidebar, mobil sidebar alternatifi OLUŞTURULMAZ.
- **Tek mobil navigasyon = `BottomNav` (Global Shared Alt Bar).**

### O2. Global `BottomNav` Kilidi

**Tek kaynak:** `src/components/feature/BottomNav.tsx`

- Her zaman 5 alan: 4 ana sekme + **Daha Fazla**.
- Panel menüsü `BOTTOM_NAV_CONFIG` üzerinden config-driven — panel bazlı BottomNav YAZILMAZ.
- Aktif sekme: `primary` accent (mavi). Badge sistemi dahili.
- `fixed bottom-0` — viewport altında sabit, içerik tarafından kaybolmaz.
- `pb-[env(safe-area-inset-bottom)]` — iOS / Android safe area desteklenir.
- Desktop'ta `lg:hidden` ile gizlenir.

### O3. Global Mobil Modal

- Mobil (`< lg`) ekranlarda her modal `fixed inset-0` (tam ekran 100vw x 100vh).
- Mobilde drag, resize, minimize, maximize **DEVRE DIŞI**.
- Mobil modal başlığında iOS sheet tarzı **gösterge çubuğu** (handle) gösterilir.
- Başlık yalnızca başlık + kapat butonu — platform kontrol butonları (küçült/büyüt) mobilde gizlenir.
- Topbar ve BottomNav modal açıkken gözükmez (modal `z-[1000+]` ile üstte).
- Modal içi scroll `overflow-y-auto` ile yalnızca body alanında.

### O4. Yatay Scroll = ASLA

- Tablo başlıkları (`th`) ve hücreler (`td`) `lg:whitespace-nowrap` — mobilde satır kırılır, yatay scroll OLMAZ.
- `TableListing`'de `mobileCardRenderer` prop — verilirse mobilde kart, desktop'ta tablo.
- Hiçbir container `overflow-x-auto` ile mobilde yatay kaydırma YARATMAZ.

### O5. Mobil Topbar

- Desktop topbar mobilde **hamburger olmadan** gösterilir.
- Logo `BrandLogo` topbarda görünür (sidebar yoktur).
- Arama simgesi / bildirim / profil — referans görsellere uygun.
- Mobil topbar `h-14 sticky top-0` — içerik kaymasına neden olmaz.

### O6. Safe Area ve Padding

- `pb-bottom-nav` utility: `padding-bottom: calc(3.5rem + env(safe-area-inset-bottom))` — içerik BottomNav altında kaybolmaz.
- `main` içeriği `pb-bottom-nav` ile mobile bottom bar clearance alır.

### O7. Z-Index Katman Sistemi

| Katman | Z-Index |
|---|---|
| Sidebar (desktop) | `z-50` |
| Topbar | `z-30` |
| BottomNav (mobile) | `z-[100]` |
| BottomNav "Daha Fazla" popup | `z-[110]` |
| Modal overlay | `z-[900]` |
| Modal | `z-[1000+]` |
| Toast | `z-[1200]` |
| ConfirmDialog | `z-[1300]` |

Modal açıkken topbar ve bottomnav modalın **altında** kalır — modal tam ekranı kaplar.

### O8. Theme Engine Mobil Uyum

- Tema değiştiğinde BottomNav + Topbar + Modal + kartlar + listeler aynı anda değişir.
- `ThemeContext` (Dark / Light / Auto) tek kaynaktır — mobil için ayrı tema sistemi OLUŞTURULMAZ.

### O9. Gelecekteki Tüm Geliştirmeler İçin Kilit

Bundan sonra oluşturulacak HER panel + HER sekme için:
- Mobil navigasyon → `BottomNav` (config üzerinden extensible).
- Mobil modal → `Modal` (mobil `isMobile` flag otomatik aktif).
- Mobil liste → `TableListing` + `mobileCardRenderer`.
- Mobil layout → `Shell` (BottomNav otomatik dahil).
- Yeni mobil-özel component OLUŞTURULMAZ, varolan Shared motorlar kullanılır.

### O10. Prompt 5/5 — Son Kilit Denetimi (KALICI)

Mobil UI son denetim sonucu — aşağıdaki sızıntılar giderilmiş ve KİLİTLENMİŞTİR:

1. **TabBar yatay scroll kaldırıldı** — `TabBar` artık `flex-wrap` kullanır; sekme çubuğu mobilde ASLA yatay kaydırmaz, taşan sekmeler alt satıra iner (OSGB detay, Ayarlar, Destek, Loglar dahil tüm kullanımlar).
2. **Wizard stepper standardı sabitlendi** — Duyuru wizard'ı, OSGB wizard'ıyla aynı "büyük daire + yatay çizgi" stepper'ına geçirildi; `overflow-x-auto` pill stepper KALDIRILDI. Tüm wizard stepper'ları yatay scroll YAPMAZ.
3. **Modal built-in `steps` göstergesi** — `flex-wrap`; yatay scroll yok.
4. **Sidebar mobil drawer kalıntısı temizlendi** — `mobileOpen` / `onCloseMobile` props'u ve `translate-x` drawer mantığı SİLİNDİ. Sidebar mobilde yalnızca `hidden lg:block` ile devre dışıdır; drawer KODU YOKTUR.

Bunlar "yatay scroll ASLA yok" ve "drawer ASLA yok" kilitlerinin son uygulamasıdır.

> Bu bölüm İSGDenetim'in EN SON ve EN ÜST kilit standardıdır. A–M bölümlerindeki tüm kilitlerin denetim (audit) sonucu ve kalıcı "UI Freeze" kuralları burada toplanır. Bir çelişki olursa bu bölüm önceliklidir.

### N1. Audit Sonucu — Onaylanan Tek Kaynak Envanteri

Aşağıdaki motorlar TEK kaynaktır, DUPLICATE YOKTUR ve panel bazlı kopya OLUŞTURULAMAZ:

| Katman | Tek Kaynak |
|---|---|
| Layout / Sidebar / Topbar | `Shell` + `Sidebar` + `Topbar` |
| Branding / Logo / Favicon | `BrandLogo` (`full` / `mark`) |
| Modal | `useModal` + `Modal` + `ModalManager` |
| Sekme Çubuğu (TabBar) | `TabBar` |
| İçerik Sekmeleri (tam content) | `Tabs` |
| Table (primitif) + Listing (motor) | `Table` + `TableListing` |
| Pagination | `Pagination` (10/20/50/100, varsayılan 10) |
| Search / Filter | `Search` + `FilterBar` |
| Form | `useForm` + `Input/Select/Textarea/Checkbox/Radio/Toggle/MultiSelect/Autocomplete/DatePicker/TimePicker` |
| Button | `Button` + `IconButton` |
| Badge / Status | `Badge` |
| Toast | `useToast` + `ToastManager` (`toast.*` singleton) |
| Confirm | `useConfirm` + `ConfirmDialog` |
| File Upload / D&D | `FileUpload` |
| Loading / Empty / Error | `Loading` / `EmptyState` / `ErrorState` |
| Hata Sınırı | `ErrorBoundary` |
| Tooltip / Card | `Tooltip` / `Card` |
| Tema | `ThemeContext` (Dark / Light / Auto) |
| Design Tokens | `index.css` `:root` / `.dark` scale değişkenleri |

### N2. Bu Audit'te Düzeltilenler (Kalıcı Kural)

1. **Gereksiz göz/detay ikonu KALDIRILDI** — satır tıklaması detay açıyorsa ayrı `görüntüle/detay` ikonu YOKTUR (Destek Talepleri, Duyurular, Sistem Logları). Aksiyon kolonunda yalnızca farklı işlevler kalır.
2. **Ortak `TabBar` motoru** — detay modalları ve ayarlar sayfasındaki inline tab çubukları TEK `TabBar` componentine taşındı. Inline tab çubuğu tekrar YAZILMAZ.
3. **Ham `<table>` KALDIRILDI** — Ayarlar → Sistem Yönetimi'ndeki iki ham tablo ortak `Table` motoruna taşındı. Sayfada ham `<table>` markup YAZILMAZ.
4. **Global `ErrorBoundary`** — uygulama köküne sarıldı. Bir hata bütün uygulamayı çökertmez; retry ekranı gösterilir.
5. **404 Türkçeleştirildi** — `NotFound` sayfası Türkçe metin + "Ana Sayfaya Dön" ile güncellendi; Shell içinde doğru layout.

### N3. UI FREEZE — ZORUNLU KURALLAR

YENİ PANEL / SEKME / TABLO / MODAL / FORM / DOSYA ALANI / BUTON / BİLDİRİM / DETAY / TEMA için:
- Yeni panel → `Shared` motor kullanır (veri + business logic + config yalnızca panelde).
- Yeni tablo → `Table` + `TableListing`. Yeni modal → `Modal`. Yeni form → `useForm` + form componentleri. Yeni dosya → `FileUpload`. Yeni buton → `Button`. Yeni bildirim → `useToast`. Yeni detay → `Modal` (variant `detail`). Yeni sekme çubuğu → `TabBar`. Yeni tema → `ThemeContext`.
- AYNI İŞ İÇİN YENİ COMPONENT OLUŞTURULMAZ.
- Panel içine özel UI workaround / lokal CSS ile global problemi gizleme YAPILMAZ.
- Bir UI hatası bulunduğunda → önce Shared motor düzeltilir, sonra tüm panellerde doğrulanır.

### N4. Global Düzeltme Kuralı (Hata → Shared)

"X panelindeki modal yanlış" → `Modal` düzeltilir (panel CSS'i değil). "X tablosu bozuk" → `Table`/`TableListing` düzeltilir. "X'te tab çubuğu bozuk" → `TabBar` düzeltilir. Bu kural tüm sistemde zorunludur.

### N5. Yetki / Routing Notu (Mevcut Faz)

Routing (`react-router`) tüm sekmeler için tanımlıdır: `/`, `/osgb`, `/destek`, `/duyurular`, `/logs`, `/ayarlar`, `/ui-referans`, `*` (404). Refresh / back / forward / direkt URL desteklenir. Panel bazlı YETKİ (Admin/OSGB/Firma/Uzman/Hekim) ve backend-seviye güvenlik kontrolü, veri/backend bağlantısı (`Readdy Backend` veya `SaaS Supabase`) kurulduğu fazda eklenir — şu an UI altyapı fazıdır; yetki kontrolü SADECE UI'da bırakılmaz, backend/RLS ile tamamlanır.

### N6. FİNAL AUDIT — SEKMELER TEK KAYNAKTA BİRLEŞTİRİLDİ (KALICI KURAL)

Son konsolidasyon denetiminde tek DUPLICATE sızıntı tespit edilip kapatıldı:

**`SharedTabs` componenti KALDIRILDI.** Sekme çubuğu için artık TEK kaynak `TabBar`'dır (`Tabs` yalnızca içerik-gömülü/self-managed sekmeler içindir — farklı sorumluluk, duplicate DEĞİL).

- `TabBar` artık `variant` destekler: `underline` (alt çizgi, default) ve `pill` (dolu buton sekmeler + sayı badge).
- `TabBar` her iki varyantta da `flex-wrap` kullanır — **yatay scroll ASLA yok** (O10 kilidiyle tutarlı). `SharedTabs`'ın eski `overflow-x-auto` davranışı iptal edildi.
- `TabBarItem` artık `count` (sayı badge) destekler — pill sekmelerindeki kayıt sayıları aynı motor üzerinden gelir.
- Duyurular ekranı `SharedTabs` yerine `TabBar variant="pill"` kullanır; görsel/veri davranışı aynıdır.

**SONUÇ:** Sekme çubuğu tek kaynak, yatay scroll yok, UI FREEZE korunuyor.

### N7. AYLIK DENETİM / AYLIK KONTROL MODÜLÜ TAMAMEN KALDIRILDI (2026-09-28)

Aylık Denetim / Aylık Kontrol modülü sistemden GİZLENMEDEN, gerçekten SÖKÜLDÜ:
- **UI:** `SahaDenetimListesi`'ndeki `aylik` sekmesi, "Aylık Denetim Başlat" butonu, "Bu Ay Aylık Denetim" KPI'ı ve `AylikDenetimBolumu` render'ı kaldırıldı. Saha Denetimleri artık doğrudan Uygunsuzluklar modülüdür (KPI: Toplam/Açık/Kapatma Talebi Bekleyen/Kapatılan).
- **Component:** `src/components/feature/sahaDenetim/aylik/` klasörü (`AylikDenetimWizard`, `AylikDenetimDetayModal`, `AylikDenetimBolumu`, `AdimKontrolMaddeleri`, `aylikDenetimTypes`) SİLİNDİ.
- **Service:** `src/lib/aylikDenetimService.ts` SİLİNDİ.
- **Edge Function:** `supabase/functions/aylik-denetim` kaynağı platform tarafından kilitli olduğu için tool ile silinemedi; çağrılmıyor (ölü). Supabase panelinden silinecek.
- **DB (tespit edildi, silme platform tarafından bloklu):** `aylik_denetim`, `aylik_denetim_maddeleri`, `aylik_denetim_fotolari`, `aylik_denetim_uygunsuzluklari`, `aylik_denetim_sablon_maddeleri`, `aylik_denetim_aksiyonlari`. TÜM FK'lar bu tabloların kendi arasında; merkezi `uygunsuzluklar` sistemine bağımlılık YOK.
- **KORUNAN:** Merkezi Uygunsuzluk sistemi (`uygunsuzluklar`, `uygunsuzluk_fotograflari`, `saha-denetim` edge function, `SahaDenetimRaporModal`, detay/kapanış/fotoğraf akışı) aynen korunur. Geçmiş uygunsuzluk kayıtları silinmez.

**SONUÇ:** Aylık Denetim = tamamen yok. Saha Denetimleri → Uygunsuzluklar ana akış. Merkezi Uygunsuzluk yapısı bozulmadı.

### N8. GLOBAL DARK MODE RENK SİSTEMİ REFERANSA SABİTLENDİ (2026-09-29)

Dark mode yüzey/tipografi token'ları kilitli referans görsellerine (Firma Detayı modalı + Firmalar ana sayfa) göre GLOBAL olarak sabitlendi. **Sidebar'a, layout'a, navigation'a ve component davranışına DOKUNULMADI**; yalnızca tema/renk katmanı (`SharedUICore` token motoru) güncellendi.

- **Yüzey hiyerarşisi (tek kaynak, `.dark` bloğu):** uygulama zemini `#080D12` → sidebar/topbar `#0B1118` → kart/panel/tablo `#111923` → input/kontrol `#17222D`; kenarlıklar `#24313E` (standart) / `#30404F` (güçlü). Önceki dark kart yüzeyi (`0.238`) referanstan daha açıktı → `0.212` (`#111923`) olarak sıkılaştırıldı.
- **Yeni katman token'ları:** `--surface-nested` (`#151F2A` — kart/modal içi bölüm), `--surface-nested-2` (`#192430` — iç içe bölüm), `--surface-hover` (`#1B2834`), `--border-subtle` (`#1D2935`). `:root` (light korunur) + `.dark` (referans).
- **Modal/popover:** `--surface-modal` = `#111923` (kart ailesi), `--surface-popover` = `#151F2A`; overlay `rgba(0,0,0,0.66)`.
- **Semantic:** primary `#1683F7`, success `#22C55E`, danger `#EF4444`, warning `#F2B233` — warning yalnızca gerçek warning durumunda; tehlike sınıfı badge'i kirli turuncu/kahverengi DEĞİL. Kahverengi/sıcak-gri/muddy tonlar yüzeylerden kaldırıldı.
- **Bağlanan bileşenler:** `.isg-card`, `.isg-section` (+ iç/iç içe), `.isg-input` (+ focus/placeholder), `.isg-btn-secondary`, `.isg-modal-content`, `.isg-popover`/`.isg-toast`, `.isg-table-row(-hover)`/border, `.isg-seg`/`.isg-segmented`, `.isg-divider`; `Table` header/row dark sınıfları; `ThemeContext` `theme-color`.
- **LIGHT MODE DEĞİŞTİRİLMEDİ.** DB / Edge Functions / RLS / RPC / route / auth / storage / business logic'e DOKUNULMADI. Tek kaynak ilkesi korunur; bir token değişince 5 panel + tüm modallar otomatik aynı rengi alır.

---

## P. SHARED UI CORE — TEK GİRİŞ NOKTASI (KALICI STANDART)

> Bu bölüm İSGDenetim'in EN ÜST düzey "tek UI kaynağı" standardının somut giriş noktasıdır. A–O bölümlerindeki tüm kilitlerin çatısı `SharedUICore` ismiyle tek dosyada toplanır.

### P1. Tek Giriş Noktası (Barrel)

Tüm ortak UI'nın ZORUNLU tek import kaynağı:

```
src/components/index.ts   →  Shared UI Core
```

Yeni panel/sekme/ekran şu şekilde import eder:

```ts
import { Button, Modal, TableListing, useModal, useTheme } from '@/components';
```

Bu tek dosya aşağıdaki katmanların TAMAMINI yeniden ihraç eder:
Layout/Shell, Sidebar, Topbar, BottomNav, BrandLogo, PageHeader, Button, IconButton, Input, Select, Textarea, DatePicker, TimePicker, Checkbox, Radio, Toggle, MultiSelect, Autocomplete, FileUpload, Search, FilterBar, Dropdown, ContextMenu, TabBar, Tabs, Card, StatCard, Badge, StatusBadge, Toolbar, SegmentedControl, SummaryStats, CategoryList, AiSuggestPanel, PhotoUpload, Avatar, Table, TableListing, Pagination, SharedListCard, Modal, ModalManager, ActionSheet, WizardStepper, Loading, EmptyState, ErrorState, ErrorBoundary, ConfirmDialog, ToastManager, Tooltip, DonutChart, LineChart + TÜM hook'lar (`useForm`, `useModal`, `useToast`, `useConfirm`, `useBottomSheet`, `useDropdown`, `useLongPress`, `useMediaQuery`) + TÜM context'ler (`ThemeProvider`/`useTheme`, `AdminProfileProvider`/`useAdminProfile`) + validators (`required`, `email`, `minLength`, ...) + `toast` singleton.

### P2. Kullanım Kuralı

- Panel/sekme UI ihtiyacı → **önce `@/components` barrel aranır.**
- Aynı iş için yeni component OLUŞTURULMAZ; mevcut `Shared` motor kullanılır.
- Eksik ihtiyaç varsa → önce Shared UI Core'a eklenir, `index.ts` barrel'a bağlanır, sonra tüketilir. Panel içine özel component GÖMÜLMEZ.
- Panel başına `AdminButton`/`OSGBModal`/`ExpertTable` gibi kopya component OLUŞTURULMAZ.

### P3. Barrel Sorumluluğu

`src/components/index.ts` SADECE yeniden ihraç (re-export) yapar; içinde business logic, state veya yeni component tanımı YOKTUR. Tek işlevi: Shared UI Core'un tamamını tek isim altında toplamak.

### P4. Zorunluluk

Bu barrel `SharedUICore`'un resmî ve TEK giriş noktasıdır. Yeni ekranlar doğrudan bireysel dosya import etmek yerine buradan import eder. Mevcut bireysel import'lar (`@/components/ui/Button` gibi) geriye dönük uyumlu olarak çalışmaya devam eder; yeni kod için barrel önerilir.

---

## Q. GLOBAL INTERACTION + KEYBOARD + TOUCH STANDARDI (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI etkileşim standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM sayfa/sekme/liste/form/modal aynı etkileşim davranışını kullanır.

### Q1. Tek Kaynak (Shared Keyboard/Interaction Motoru)

Tüm klavye/touch etkileşimi TEK kaynaktan yönetilir: `src/hooks/useKeyboardNav.ts`

| İşlev | Tek Kaynak |
|---|---|
| Roving tabindex + arrow navigasyonu (sekmeler/menüler) | `useRovingFocus` |
| Listbox adımı (Select/Autocomplete seçenekleri) | `listboxStep` |
| Uzun basma (long-press) | `useLongPress` |
| Dışarı tıklama (click outside) | `useClickOutside` |
| Viewport-aware dropdown konumu | `useDropdownPosition` |

Panel/sekme içine ayrı klavye/long-press/modal/dropdown hack'i YAZILMAZ.

### Q2. Klavye Davranışları (Standart)

| Tuş | Davranış |
|---|---|
| ESC | Açık modal/dropdown/action sheet kapanır (öncelik: dropdown → modal). Form verisi silinmez; unsaved varsa confirmation sorulur. |
| ENTER | Aktif buton/aksiyon; form submit; search arama; dropdown seçimini onaylar. |
| SPACE | Buton çalıştırır; checkbox/switch değiştirir (native). |
| TAB / SHIFT+TAB | Modal içinde focus kalır (focus trap); modal kapanınca focus açan elemana döner. |
| Arrow / Home / End | Sekmeler (TabBar/Tabs) ve menüler (ContextMenu) arasında gezinme; Select/Autocomplete listelerinde ilk/son. |

### Q3. Satır/Kart Tıklama ve Long-Press

- Satıra tek dokunma → ana action (ör. detay). (`onRowClick`)
- Satır içi checkbox/button/dropdown/⋮/link → `stopPropagation` ile yalnızca kendi işlemi çalışır; satır detayı AÇILMAZ.
- Mobilde uzun basma → `useLongPress` + `ActionSheet` (alttan açılan, animasyonsuz). Kısa dokunma ile ÇAKIŞMAZ (hareket eşiği + timer). Native context menu engellenir.
- ⋮ / Daha Fazla → `ContextMenu` (desktop: popover; mobil: aynı action listesi).

### Q4. Erişilebilirlik (Accessibility)

Tüm etkileşim elemanları: `role`, `aria-label`, `aria-expanded`, `aria-selected`, `aria-haspopup`, `tabIndex` (roving), `disabled`, focus-visible destekler. Sekmeler `role="tablist"` + `role="tab"`, menüler `role="menu"` + `role="menuitem"`, listbox `role="listbox"` + `role="option"` kullanır.

### Q5. Bu Audit'te Eklenenler

1. **`useRovingFocus` motoru** — sekmeler (TabBar/Tabs) ve menüler (ContextMenu) için roving tabindex + arrow/Home/End navigasyonu tek kaynaktan. `TabBar` ve `Tabs` artık klavyeyle (Arrow Left/Right + Home/End) gezilebilir, `aria-selected`/`tabIndex` doğru yönetilir.
2. **Home/End desteği** — Select ve Autocomplete seçenek listelerine `listboxStep` üzerinden Home (ilk) / End (son) eklendi; Arrow/Enter/Esc zaten mevcuttu.
3. **ContextMenu klavye navigasyonu** — ⋮ menüsü açılınca ilk öğeye odaklanır, Arrow Up/Down + Home/End ile gezilir; Enter/Space native click ile seçer, Escape kapatır.

### Q6. Zaten Merkezi Olan Davranışlar (Değiştirilmedi)

Modal (ESC önceliği + focus trap + focus restore + tehlikeli işlem kilidi), Select/Autocomplete (Arrow/Enter/Esc), Search (Enter + debounce + X temizle), `useLongPress` (hareket eşiği + context menu engelleme), `useForm` (çift submit kilidi), BottomSheet (ESC + drag-to-close), `Z_LAYERS` (z-index), `useMediaQuery` (responsive) — tümü önceki kilitlerde zaten merkezileştirilmişti; bu turda bozulmadan korundu.

---

## R. GLOBAL ACCESSIBILITY CORE (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI erişilebilirlik standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM sayfa/sekme/form/liste/modal için aşağıdaki kurallar ZORUNLUDUR. Erişilebilirlik davranışı tek `SharedUICore` üzerinden yönetilir; panel/sekme içine erişilebilirlik hack'i YAZILMAZ.

### R1. Form Label ↔ Input İlişkilendirme (ZORUNLU)

Tüm form kontrolleri (`Input`, `Select`, `Textarea`, `Autocomplete`, `MultiSelect`) `label` aldığında **`htmlFor` + `id` bağıyla** input'a bağlanır. React `useId` üzerinden benzersiz `id` üretilir; kullanıcı `id` prop geçerse o kullanılır. Ekran okuyucu (VoiceOver/TalkBack) label'ı input ile ilişkilendirebilir.

- `Checkbox` / `Radio` / `Toggle` native wrapping `<label>` ile accessible name alır.
- `Select` / `MultiSelect` tetikleyici `<button>` `id` + `aria-haspopup="listbox"` + `aria-expanded` taşır.
- `Autocomplete` input'u `role="combobox"` + `aria-haspopup="listbox"` + `aria-expanded` taşır.

### R2. Hata / Yardım Mesajı İlişkilendirme (ZORUNLU)

Hata mesajları ve yardım metinleri ilgili input ile **`aria-describedby` + `aria-invalid`** üzerinden bağlanır. Hata/yardım `<p>`'leri benzersiz `id` alır; input bu `id`'leri `aria-describedby` ile işaret eder. Hata durumunda `aria-invalid` `true` olur. Ekran okuyucu, odaklanan input'un hata/yardım metnini otomatik okur.

### R3. Icon-Only Button Accessible Name (ZORUNLU)

Yalnızca ikon içeren her buton (`IconButton` `label` prop'u, `NotificationBell`, Sidebar daralt/genişlet, `UserProfile` trigger, `ThemeToggle`, pagination ok butonları, satır checkbox'ları, modal kapat/küçült/büyüt butonları) **`aria-label` (veya `title`) ile erişilebilir ad taşır**. Ekran okuyucuda "buton" olarak değil, işleviyle (ör. "Kapat", "Bildirimler", "Menüyü daralt", "Satırı seç") duyurulur.

### R4. Switch / Checkbox / Radio Semantiği

- `Toggle` `role="switch"` taşır (native checkbox + switch semantiği — `aria-checked` native state'ten gelir).
- `Checkbox` / `Radio` native input'tur; hata mesajı `aria-describedby` ile bağlıdır.
- `Table` satır/başlık checkbox'ları `aria-label` ("Satırı seç"/"Tümünü seç") taşır; `select-all` için `indeterminate` state doğru yönetilir.

### R5. Liste / Tablo Semantiği

- `Table` sıralanabilir kolon başlıkları `aria-sort` taşır (`ascending`/`descending`/`none`).
- `Search` konteyner `role="search"`, input `aria-label` taşır.
- `FilterBar` raw `date`/`text` input'ları `aria-label` (filtre etiketi) taşır.
- `Loading` `role="status"` + `aria-live="polite"` taşır; spinner `aria-hidden`'dır.

### R6. Zaten Merkezi Olan Davranışlar (Değiştirilmedi)

Modal (ESC + focus trap + focus restore + `role="dialog"` + `aria-modal` + `aria-label`), ConfirmDialog (`role="alertdialog"`), BottomSheet (`role="dialog"` + `aria-modal`), ContextMenu (`role="menu"`/`menuitem`), ThemeToggle (`role="menu"`/`menuitemradio`), Select/Autocomplete (`role="listbox"`/`option` + `aria-selected`), TabBar/Tabs (`role="tablist"`/`tab` + `aria-selected` + roving tabindex), focus-visible outline (Light/Dark) — tümü önceki kilitlerde merkezileştirilmişti; bu turda bozulmadan korundu ve form/icon/label bağları ile tamamlandı.

---

## S. GLOBAL UI STATE + FORM CORE (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI loading/empty/error/success ve form standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM ekran/form için aşağıdaki kurallar ZORUNLUDUR. State ve form davranışı tek `SharedUICore` üzerinden yönetilir; panel/sekme içine özel loading/error/form UI YAZILMAZ.

### S1. State Core — Tek Kaynak Envanteri

| Durum | Tek Kaynak |
|---|---|
| Spinner (küçük/satır içi) | `Loading` (full-page spinner YOK, `min-h` ile inline) |
| Liste/Kart iskeleti | `Skeleton` + `SkeletonList` / `SkeletonListCard` / `SkeletonCard` |
| Tablo iskeleti | `SkeletonTable` |
| Metin/Avatar iskeleti | `SkeletonText` / `SkeletonCircle` |
| Boş durum | `EmptyState` (kompakt + opsiyonel "Yeni Ekle"/"Filtreleri Temizle" action) |
| Hata durumu | `ErrorState` (mesaj + `onRetry` "Tekrar Dene") |
| Başarı durumu (ekran-level) | `SuccessState` |
| Başarı/hata bildirimi (anlık) | `useToast` + `ToastManager` (`toast.success/error/...`) |
| Button loading | `Button` `isLoading` (metin korunur, genişlik kaymaz, çift submit engelli) |
| Form aksiyon satırı | `FormActions` (İptal + Kaydet/Gönder, loading + çift submit) |
| Hata sınırı | `ErrorBoundary` |

### S2. State Kuralları

- **Full-screen spinner YASAKTIR.** İçerik yükleme → `Skeleton` (liste/kart/tablo iskeleti) kullanılır; yükleme bitince içerik aynı yere oturur, **layout zıplamaz**. Spinner yalnızca küçük satır-içi işlemlerde (`Loading`).
- **Boş durum** kompakt ve açıklayıcıdır; gereksiz büyük boş alan YOKTUR. Gerekirse tek action ("Yeni Ekle" / "Filtreleri Temizle") gösterilir.
- **Hata durumu** anlaşılır mesaj + "Tekrar Dene" (`onRetry`) taşır. Sayfanın tamamını bozmaz; hatanın geçtiği alan içinde gösterilir. **API hatası ile validation hatası AYRILIR**: validation hatası input altında (`error` prop), API/network hatası `ErrorState`/`Toast` ile.
- **Başarı** anlık işlemlerde `toast.success`, ekran-level kalıcı onay gerektiğinde `SuccessState` kullanılır.

### S3. Form Core — Tek Kaynak Envanteri

| İşlev | Tek Kaynak |
|---|---|
| Form state + validation + submit | `useForm` (çift submit kilidi + `isDirty` + `isSubmitting`) |
| Metin girişi | `Input` (label + error + helpText + `isSuccess` + `isLoading`) |
| Çok satır | `Textarea` (500 karakter limiti + sayaç) |
| Seçim | `Select` (searchable + klavye) |
| Tarih / Saat | `DatePicker` / `TimePicker` |
| Onay / Tek seçim / Switch | `Checkbox` / `Radio` / `Toggle` |
| Çoklu seçim / Otomatik tamamlama | `MultiSelect` / `Autocomplete` |
| E-posta / Telefon / İl / İlçe | `EmailInput` / `PhoneInput` / `ProvinceSelect` / `DistrictSelect` |
| Dosya | `FileUpload` |
| Validasyon | `required` / `email` / `emailDetailed` / `turkeyPhone` / `minLength` / `maxLength` / `pattern` / `minValue` / `maxValue` / `composeValidators` |
| Form aksiyonları | `FormActions` (İptal + Kaydet/Gönder) |

### S4. Form Kuralları

- **Tutarlılık:** label / input yüksekliği / padding / radius / font / focus / error / success / disabled / required tüm form kontrollerinde AYNI değerlerden gelir (token sistemi + `isg-input`/`isg-btn` ortak sınıfları).
- **Validation mesajı input ALTINDA** gösterilir (`error` prop → `aria-invalid` + `aria-describedby`). Hata mesajı layout'u bozmaz, uzun metin taşmaz (`break-words`/wrap).
- **Çift submit** `useForm` `isSubmitting` kilidiyle engellenir; `Button` `isLoading` üzerinden loading gösterilir (metin korunur).
- **Enter** doğru form action'ını tetikler (submit); textarea'da SHIFT+Enter yeni satır. **ESC form verisini yanlışlıkla silmez**; unsaved varsa uyarılır.
- **Kaydedilmemiş değişiklik** (`isDirty`) tespit edilir; kapatma/sıfırlama öncesi uyarı için kullanılır.
- **Mobil:** iOS/Android'de input'a odaklanınca sayfa zoom YAPMAZ (font-size ≥ 16px), keyboard layout'u bozmaz.
- **Desktop:** TAB sırası düzgün, focus doğru, form grid hizalı (`grid grid-cols-1 sm:grid-cols-2`).

### S5. Bu Audit'te Eklenenler

1. **`Skeleton` ailesi** — liste/kart/tablo/metin/avatar iskeletleri tek kaynaktan (`Skeleton`, `SkeletonList`, `SkeletonListCard`, `SkeletonCard`, `SkeletonTable`, `SkeletonText`, `SkeletonCircle`). Tema otomatik (`background` scale), `role="status"` + `aria-live` ile ekran okuyucu uyumlu.
2. **`SuccessState`** — ekran-level başarı durumu (yeşil ikon + opsiyonel action).
3. **`FormActions`** — "İptal + Kaydet/Gönder" buton satırı tek bileşen; `isSubmitting` + çift submit + `extra` (sol butonlar, örn. Temizle/Geri) + hizalama destekli.
4. **`useForm.isDirty`** — kaydedilmemiş değişiklik takibi (başlangıç değerleriyle sığ karşılaştırma); unsaved-changes uyarıları için temel.

### S6. Zaten Merkezi Olan Davranışlar (Değiştirilmedi)

`Loading` (spinner + `role="status"`), `EmptyState` (action'lı), `ErrorState` (retry'lı), `Button` (`isLoading`), `ToastManager` + `useToast` (`toast.success/error/...` + `toast.loading` + `toast.update`), `useForm` (çift submit kilidi + validators) — tümü önceki kilitlerde merkezileştirilmişti; bu turda bozulmadan korundu ve Skeleton/SuccessState/FormActions/isDirty ile tamamlandı.

---

## T. GLOBAL TOAST / NOTIFICATION CORE (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI toast/snackbar/işlem-bildirimi standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM ekran/özellik için aşağıdaki kurallar ZORUNLUDUR. Bildirim davranışı tek `SharedUICore` üzerinden yönetilir; panel/sekme içine özel toast/snackbar sistemi YAZILMAZ.

### T1. Tek Kaynak (Shared Toast/Notification Motoru)

Tüm bildirim (toast, snackbar, işlem bildirimi) TEK kaynaktan yönetilir: `useToast` + `ToastManager` + `toast` singleton (`src/hooks/useToast.tsx` + `src/components/ui/ToastManager.tsx`).

| İşlev | Tek Kaynak |
|---|---|
| Anlık başarı | `toast.success(title, message?)` |
| Anlık hata | `toast.error(title, message?)` |
| Uyarı | `toast.warning(title, message?)` |
| Bilgi | `toast.info(title, message?)` |
| Uzun işlem (progress) | `toast.loading(title, message?)` → `toast.update(id, {...})` |
| Kapatma | `toast.dismiss(id)` |
| Context API | `useToastActions()` (eylem, sabit) + `useToastState()` (state) |

Panel/sekme kendi toast sistemini OLUŞTURMAZ; tarayıcı `alert`/`confirm` KULLANILMAZ (J6 ile tutarlı).

### T2. Davranış Kuralları

- **Durumlar:** `success` / `error` / `warning` / `info` — 4 durum tek `ToastType` üzerinden.
- **Kalabalık engelleme:** aynı anda en fazla `MAX_VISIBLE = 4` görünür; fazlası kuyruğa alınır, biri kapanınca otomatik yükseltilir.
- **Duplicate engelleme:** aynı `type|title|message` imzası `DEDUPE_WINDOW` (800ms) içinde tekrar gelirse atlanır.
- **Layout kayması YOK:** konteyner `fixed` + `pointer-events-none`; her toast `pointer-events-auto`. Sayfa içeriği zıplamaz, scroll etkilenmez.
- **Z-index:** `Z_LAYERS.toast` (9999) — modal/dropdown/confirm üzerinde tek katman kaynağından. Hardcoded z-index YAZILMAZ.
- **Animasyon YOK:** "tak" diye görünür, "tak" diye kaybolur. Giriş/çıkış fade/slide/transition OLUŞTURULMAZ. (Progress bar genişliği DOM'dan güncellenir, CSS transition içermez.)
- **Konum:** Desktop → sağ alt köşe (`sm:right-6 sm:bottom-6`, max-width 380px). Mobil → alt, BottomNav üstünde, `env(safe-area-inset-bottom)` ile safe-area destekli (iOS + Android aynı).
- **Uzun mesaj:** `break-words` + `min-w-0` ile wrap; taşmaz, layout bozulmaz.
- **Close action:** `aria-label="Kapat"` ile erişilebilir; `role="alert"` (error) / `role="status"` (diğer) ile ekran okuyucu duyurur.
- **Auto-dismiss pause:** hem mouse hover hem klavye focus (`onFocus`/`onBlur`) üzerinde timer durur — kullanıcı kapatma/action butonuna odaklanırken toast kaybolmaz.

### T3. Light / Dark Uyum

Toast yüzeyi `isg-toast` sınıfından gelir; Light (`--background-100` + `--background-300` border) ve Dark (`--background-200` + `--background-400` border) tema override'ları `index.css`'te merkezi tanımlıdır. Toast içinde hardcoded renk ÜRETİLMEZ — icon/progress renkleri `success` / `warning` / `danger` / `primary` scale token'larından tüketilir.

### T4. Bu Audit'te Düzeltilenler

1. **Z-index tek kaynağa bağlandı** — `z-[9999]` hardcoded değeri `Z_LAYERS.toast` ile değiştirildi (tek katman motoru).
2. **Klavye focus pause eklendi** — `onFocus`/`onBlur` ile auto-dismiss yalnızca hover'da değil, klavye odağında da durur (close/action erişilebilirliği korunur).

### T5. Zaten Merkezi Olan Davranışlar (Değiştirilmedi)

4 durum (`success/error/warning/info`), `MAX_VISIBLE` kuyruğu, `DEDUPE_WINDOW` duplicate engelleme, `fixed` + `pointer-events-none` (layout kaydırmaz), safe-area, desktop köşe konumu, animasyonsuz görünüm, `break-words` wrap, `aria-label="Kapat"`, `toast.loading/update` (işlem bildirimi) — tümü önceki kilitlerde merkezileştirilmişti; bu turda bozulmadan korundu.

> Not: Spec'teki "SharedNotification" ismini bilinçli AYRI component olarak oluşturmadım — "işlem bildirimleri" (`toast.loading` + progress + `toast.update`) zaten aynı motorun parçası. Boş bir sarmalayıcı eklemek gereksiz abstraction olurdu (S bölümündeki "SharedForm" ilkesiyle aynı). Toast/notification tek `useToast` çatısında birleşiktir.

---

## U. GLOBAL CROSS-BROWSER COMPATIBILITY CORE (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI cross-browser uyumluluk standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM sayfa/sekme/liste/form/modal aynı platform davranışını kullanır. Browser'a ÖZEL farklı UI OLUŞTURULMAZ; iOS hack'i Android'i, Android hack'i iOS'u BOZMAZ. Öncelik sırası: `SharedUICore` → responsive CSS → feature detection → gerektiğinde küçük platform abstraction.

### U1. Desteklenen Ortamlar

- **Desktop:** Chrome / Safari / Firefox / Edge
- **Mobile:** iOS Safari / iOS WebView / Android Chrome / Android WebView

> Not: PWA manifest/install özelliği bu projede DESTEKLENMEZ (React SPA kapsamı). "WebView" ortamları aynı responsive + safe-area + viewport kurallarıyla kapsanır.

### U2. Zaten Merkezi Olan Platform Motorları (Değiştirilmedi)

| Alan | Tek Kaynak / Davranış |
|---|---|
| Viewport meta | `width=device-width, initial-scale=1.0, viewport-fit=cover, interactive-widget=resizes-content` (`index.html`) |
| Safe-area | `env(safe-area-inset-top/bottom)` — `isg-topbar`, BottomNav, modal footer (`pb-safe-footer`) |
| Klavye açılışı | `ViewportManager` — `visualViewport` API + `keyboard-open` class + `scrollIntoView` (polling YOK, rAF throttle) |
| iOS input zoom önleme | `@media (max-width:767px)` içinde `font-size:16px` (otomatik zoom kapatılır, manuel pinch KİLİTLENMEZ) |
| Dynamic viewport | `.h-app-screen` vb. `100vh` fallback + `100dvh` (iOS adres çubuğu/home indicator) |
| Dokunmatik | `touch-action: manipulation` (buton/sekme), `-webkit-tap-highlight-color: transparent` |
| Long-press/native menu bastırma | `useLongPress` (pointer-event + hareket eşiği) + `-webkit-touch-callout`/`-webkit-user-select`/`user-select`/`-webkit-user-drag` (form input'ları DIŞINDA) |
| Yatay taşma koruması | `body overflow-x:hidden` + `max-width:100%` (img/video/iframe/...) + `min-width:0` (input/select/textarea) + `overscroll-behavior-x` |
| Scrollbar | Merkezi premium scrollbar: `--scrollbar-size` token + muted token tabanlı thumb (Light/Dark aynı dil), WebKit inset "yüzen" thumb; `.isg-scroll-pane` = `scrollbar-gutter:stable` + `overscroll-behavior:contain` (modal gövdesi + tüm belge önizleme panelleri) |
| Renk şeması | `color-scheme: light` / `.dark { color-scheme: dark }` (native form kontrolü + scrollbar) |
| Focus | `:focus-visible` outline (Light/Dark görünür); mouse tıklamasını etkilemez |
| İşaretçi birleştirme | Pointer Events (Modal drag/resize + useLongPress) — touch+mouse tek mimari |
| Feature detection | `if (window.visualViewport)`, `typeof ResizeObserver === 'undefined'` guard'ları — eski tarayıcıda crash YOK |
| Native date/time | `type="date"`/`type="time"` + `appearance:none` (isg-input) — tarayıcıya özel render normalize, native picker (iOS wheel/Chrome calendar) korunur |

### U3. Bu Audit'te Düzeltilenler

1. **`theme-color` meta eklendi** — iOS Safari status bar / Android Chrome adres çubuğu / WebView browser-chrome rengi tema ile eşleşir. `index.html` FOUC script'i + `ThemeContext.applyTheme` runtime'ta `#f8fafc` (light) / `#0B0F19` (dark) olarak günceller (auto modda OS temasını da takip eder).
2. **`overscroll-behavior-x: none` eklendi** — `html` + `body` üzerinde yatay rubber-band/pull-to-refresh koruması; "yatay overflow kesinlikle olmayacak" kilidi (O4) tamamlandı.
3. **`DatePicker` / `TimePicker` label↔input bağı tamamlandı** — forwardRef component'leri a11y turunda atlanmıştı; artık `useId` + `htmlFor`/`id` + `aria-invalid` + `aria-describedby` taşır (R1/R2 kilidiyle uyumlu, native input üzerinde).

### U4. Zorunlu Kurallar (Gelecekteki Tüm Geliştirmeler İçin)

- **Browser'a özel farklı UI YOK:** `if (isSafari)`, `if (isIOS)`, `navigator.userAgent` tabanlı farklı render ÜRETİLMEZ. Platform farkı yalnızca responsive CSS (`@media`) + `env()` + feature detection ile kapatılır.
- **iOS hack'i Android'i bozmaz, Android hack'i iOS'u bozmaz:** `env()` zaten Android'de 0 döner (ekstra boşluk yok); `-webkit-` prefix'leri non-WebKit'te yok sayılır; `100dvh` `100vh` fallback ile gelir.
- **Horizontal overflow ASLA yok** (O4 ile tutarlı): `overflow-x:hidden` + `max-width:100%` + `min-width:0` + `overscroll-behavior-x:none` + `flex-wrap`/`lg:whitespace-nowrap`.
- **Masaüstü ve mobil layout birbirini bozmaz:** tek component içinde `useMediaQuery` ile tek varyant render (çift DOM YOK), `lg:` breakpoint'leri ile masaüstü/mobil ayrımı.
- **Yeni platform ihtiyacı** çıkarsa → önce `index.css` global motoruna / `ViewportManager`'a / `useMediaQuery`'ye eklenir; sayfa bazlı yama YAZILMAZ (J7/N4 ilkesi).

### U5. Bu Audit'te Değiştirilmedi (Bilinçli)

OKLCH renk sistemi (`--*-500` kanal değerleri + `oklch(var(--...) / <alpha>)`) StyleSystem zorunlu mimarisi olduğu için değiştirilmedi; 2026 itibarıyla Chrome/Safari/Firefox/Edge + mobil tarayıcılarda tam desteklidir. Eski tarayıcı desteği bu projenin kapsamı DIŞINDADIR. `Tooltip` ayrı component olarak oluşturulmadı — native `title` attribute'ü en cross-browser tooltip çözümüdür (`Z_LAYERS.tooltip` rezerve katman olarak korunur).

---

## V. GLOBAL UI PERFORMANCE CORE (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI performans standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM ekran için aşağıdaki kurallar ZORUNLUDUR. Hedef: mobil/desktop'ta hızlı, stabil, düşük kaynak tüketimli UI. Business logic DEĞİŞTİRİLMEZ — yalnızca render/memory/cpu davranışı iyileştirilir.

### V1. Context Güncelleme Kilidi (Gereksiz Re-render Yasağı)

Action/state context'leri **AYRILMIŞTIR**. Eylemler (aç/kapa/ekle/sil vb.) sabittir (`useCallback` + `useMemo` ile tek kimlik); yalnızca **state** ayrı context'te değişir. Sonuç: bir toast/modal/confirm açıldığında YALNIZCA state tüketicisi re-render olur, eylem tüketicisi olan sayfalar/paneller render'a girmez.

| Provider | Eylem hook (sabit, render tetiklemez) | State hook (yalnızca state tüketicisi) |
|---|---|---|
| `useToast` | `useToastActions` (`addToast`/`removeToast`/`updateToast`) | `useToastState` (`toasts` → `ToastManager`) |
| `useModal` | `useModalActions` (`openModal`/`closeModal`/.../`isMinimized`) | `useModalState` (`state` → `ModalManager`) |
| `useConfirm` | `useConfirmActions` (`confirm`/`close`) | `useConfirmState` (`state` → `ConfirmDialog`) |
| `useAdminProfile` | — (tek value `useMemo` ile memoize) | — |

- Birleşik `useToast()`/`useModal()`/`useConfirm()` hook'ları geriye dönük uyumlu OLARAK korunur, ancak YALNIZCA state'e ihtiyaç duyan nadir tüketiciler içindir. Eylem kullanan yeni kod `useToastActions`/`useModalActions`/`useConfirmActions` tercih eder.
- **KURAL:** Eylem (action) tüketen hiçbir sayfa/panel, o sağlayıcının state'i değiştiğinde re-render olmamalıdır. Yeni provider eklenirken action/state ayrımı ZORUNLUDUR.

### V2. Zaten Merkezi Olan Performans Motorları (Değiştirilmedi)

| Alan | Tek Kaynak / Davranış |
|---|---|
| Responsive tek varyant | `useMediaQuery` — mobil/desktop AYNI component içinde TEK varyant render (çift DOM yok). `Table` yalnızca kart YA tablo basar. |
| Modal drag/resize | `Modal` — `requestAnimationFrame` ile throttle; her pointermove'da state değil, tek frame'e sıkıştırılır. |
| Klavye/viewport | `ViewportManager` — polling YOK, rAF throttle; tüm listener'lar cleanup'lı. |
| Dropdown konumu | `useDropdownPosition` — scroll/resize/ResizeObserver tek `recalc`; konum değişmeyince state güncellenmez (kimlik karşılaştırma). `ResizeObserver` `disconnect` ile temizlenir. |
| Long-press | `useLongPress` — event delegation, liste öğesi başına state/timer yok; tek container tek timer. |
| Toast timer | `ToastManager` — progress genişliği DOM'dan güncellenir (her tick state/render yok); interval cleanup'lı. |
| Tema değişimi | `ThemeContext` — `children` prop (stable element) ile alt ağaç RE-MOUNT olmaz; yalnızca `.dark` class atomik değişir (transition yok). |
| Portal katmanları | `DropdownPanel`/`ModalManager` `createPortal` — modal/dropdown açılışında tüm uygulama re-render olmaz; katmanlar body'ye portal edilir. |
| Animasyon | Modal/dropdown/action-sheet/toast açılış-kapanışında animasyon YOKTUR ("tak" görünür/kaybolur). |

### V3. Bu Audit'te Düzeltilenler

1. **Context action/state ayrıştırması** — `useToast`/`useModal`/`useConfirm` sağlayıcıları sabit-eylem + ayrı-state context'ine bölündü. Önceden her `addToast`/`openModal`/`confirm` state değişiminde tüm tüketici sayfalar re-render oluyordu; artık yalnızca `ToastManager`/`ModalManager`/`ConfirmDialog` state'i görür.
2. **`useAdminProfile` value memoize edildi** — inline `value` objesi ve türetilmiş `fullName` `useMemo`'ya alındı; profil değişmediği sürece tüketici re-render olmaz.
3. **`NotificationBell` çift liste markup'ı birleştirildi** — desktop dropdown ile mobil sheet aynı `NotificationList` bileşenini kullanır; liste render'ı (map) tek kaynağa indirildi, "mark all" butonu duplicate'i kaldırıldı.
4. **`NotificationBell` global `useMediaQuery`'ye geçirildi** — elle `window.resize` listener + `useState` yerine tek responsive motor kullanıldı (listener tek kaynak, gereksiz state yok).

### V4. Zorunlu Kurallar (Gelecekteki Tüm Geliştirmeler İçin)

- **Gereksiz re-render YASAK:** context sağlayıcıları action/state ayrıştırılır; eylemler sabit kimlikte tutulur.
- **Gereksiz useEffect/useMemo/useCallback YOK:** yalnızca gerçek bir yeniden-hesaplama/abonelik maliyeti olduğunda kullanılır.
- **Listener/Observer/Timer leak YOK:** her `addEventListener`/`ResizeObserver`/`setInterval`/`setTimeout` karşılığı cleanup'ta kaldırılır.
- **Scroll sırasında ağır JS YOK:** scroll/resize handler'ları `requestAnimationFrame` ile throttle edilir.
- **Modal/dropdown açılışında tüm uygulama render EDİLMEZ:** katmanlar `createPortal` + action/state ayrımı ile izole edilir.
- **Tema değişiminde alt ağaç RE-MOUNT olmaz:** `children` stable tutulur, yalnızca class değişir.
- **Büyük liste:** `Pagination` (10/20/50/100) zorunludur; çok büyük (> birkaç yüz) sanal-scroll gerektiren listeler için `Table`/`TableListing` virtualization ihtiyacı değerlendirilir — küçük mock/demo listelerde over-engineering YAPILMAZ.
- **Görsel:** lazy loading + uygun boyut + `aspect-ratio` + fallback; çift varyant DOM (mobile kart + desktop tablo birlikte) ÜRETİLMEZ.
- **Animasyon minimum:** açılış/kapanış animasyonları YOK (modal/dropdown/action-sheet/toast).

### V5. Bilinçli Değiştirilmedi (Kapsam Dışı)

`useBottomSheet` tek context olarak bırakıldı — `isOpen`/`options` state'i `BottomNav` ve `NotificationBell` tarafından meşru olarak okunur (aktif sekme/aria-expanded); bu yüzden action/state ayrımı burada gereksiz abstraction olurdu. `Table`'ın `allKeys`/`isAllSelected` hesapları küçük listelerde O(n) olduğundan memoize edilmedi (veri zaten her render değişir). Mock/demo veriler küçük olduğundan listelere virtualization eklenmedi — `Pagination` yeterlidir (I4 kilidi).

---

## W. GLOBAL ASSET + IMAGE CORE (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI görsel/icon/avatar/medya standardıdır. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM ekran için aşağıdaki kurallar ZORUNLUDUR. Görsel kullanımı tek `SharedUICore` üzerinden yönetilir; panel/sekme içine kendi icon/avatar/image sistemi OLUŞTURULMAZ.

### W1. Tek Kaynak Envanteri

| İşlev | Tek Kaynak |
|---|---|
| Avatar (görüntüleme) | `Avatar` (`src` + `name` baş harf fallback + `status`) |
| Avatar (yükleme) | `AvatarUpload` (kırpma/küçültme, tek motor) |
| Baş harf yardımcı | `getInitials` (`Avatar` içinden, tek fonksiyon) |
| Logo / mark | `BrandLogo` (`full` / `mark`, Light+Dark asset) |
| Icon | `Icon` + `FileIcon` (`src/components/ui/Icon.tsx`) + `iconRegistry` (`src/lib/icons/iconRegistry.ts`) — Remix Icon tabanlı TEK ikon kaynağı (ad + boyut + semantic ton) |
| Grafik (donut/line) | `DonutChart` / `LineChart` (SVG `currentColor`, token-aware) |

### W2. Icon Kuralı

- Tüm iconlar **Remix Icon** kütüphanesinden `<i className="ri-...">` ile kullanılır. Ayrı SVG icon dosyası, image-icon, emoji-icon OLUŞTURULMAZ.
- Aynı icon için duplicate asset YOK — aynı `ri-*` sınıfı her yerde tek kaynaktan tüketilir.
- Icon rengi `currentColor` üzerinden token class'larıyla (`text-foreground-500`, `text-primary-500`, ...) belirlenir; hardcoded renk ÜRETİLMEZ.
- Icon-only elemanlarda `aria-label`/`title` zorunludur (R3 kilidi).

### W2b. Merkezî İkon Sistemi (2026-09-29 — KALICI)

Tüm ikonlar TEK merkezden yönetilir: `src/components/ui/Icon.tsx` (`Icon` + `FileIcon`) + `src/lib/icons/iconRegistry.ts`. Panel/sekme kendi ikon listesini OLUŞTURMAZ.

- **API:** `<Icon name="pdf" size="md" />`, `<FileIcon mime={evrak.mimeType} name={evrak.originalFileName} />`. `size` merkezi ölçek (`xs16/sm18/md20/lg24/xl32/2xl40`); `tone` semantik (`primary/secondary/success/warning/danger/info/neutral/muted`).
- **Kayıt grupları:** dosya/doküman · işlem · durum · kullanıcı/organizasyon · İSG modülleri · diğer modüller · iletişim/sistem · hızlı eylem. Yeni ikon SADECE `iconRegistry`'ye eklenir.
- **Dosya-formatı ikonları YEREL VEKTÖR (SVG) bileşenlerdir** (`src/lib/icons/DosyaSvgIkonlari.tsx`): formatın kendisini + marka rengini gösterir (PDF=kırmızı, Word=mavi, Excel=yeşil, PowerPoint=turuncu, XML=amber, arşiv=gri, metin/belge=slate, görsel=slate, klasör=mavi). Kullanıcının sağladığı açık kaynak (svgrepo) SVG'ler birebir yerel vektöre çevrildi; eksik formatlar AYNI görsel ailede tamamlandı. `IconDefinition.component` alanı ile merkezî `<Icon name="pdf" />` üzerinden tüketilir. **Dosya formatı ikonları ASLA `-line` (sade çizgi) olmaz.**
- **Tek dosya-türü çözücü:** `resolveFileIcon(mime, name)` + `dosyaTuruBul`. Evrak (`EvrakDosyaIkonu`/`evrakFileIcon`), mesajlaşma (`fileVisual`), ekipman (`belgeGorunum`), noter defteri (`ekIkon`), personel evrak, tutanak ekleri, global yükleme (`fileUpload.getFileIcon`) ve belge önizleme (`previewKindIcon`) TÜMÜ buraya bağlandı — aynı tür her ekranda AYNI ikon + AYNI renk.
- **Ücretsiz/kaynak kilidi:** Dosya-format ikonları = yerel inline SVG vektör (dış CDN / runtime internet İSTEĞİ YOK, PNG YOK); diğer ikonlar = Remix Icon (ticari kullanıma açık, uygulamada zaten yüklü). Ücretli paket (Iconsax Premium, Hugeicons Pro, Streamline Pro vb.) KULLANILMAZ.
- **UI DEĞİŞMEZ:** Sidebar/Navbar/kart/modal/font/spacing/radius/renk paleti/buton/tablo/badge/logo DOKUNULMAZ — yalnızca ikon katmanı profesyonelleştirildi.

### W3. Görsel Kuralı (Layout Shift + Boyut + Fallback)

- **Layout shift YOK:** her `<img>` ya sabit boyut class'ı (`w-*`/`h-*`) ya `aspect-ratio`/`aspect-square` ya da inline `width/height` taşır. Oran korunur, görsel zıplamaz.
- **Uygun boyut:** avatar/liste görselleri küçük (24–64px), upload `MAX_DIMENSION=512` ile küçültülür — gereksiz büyük görsel kullanılmaz.
- **Kırık görsel global fallback:** `Avatar`/`AvatarUpload` `src` yüklenemezse otomatik baş harfe düşer; `BrandLogo` yüklenemezse metin yer tutucuya düşer. Kırık-resim ikonu GÖSTERİLMEZ.
- **Lazy loading:** alt kısımdaki (below-fold) liste görselleri `loading="lazy"` taşır; LCP olan logo/üst-fold öğeleri lazy EDİLMEZ (eager kalır).

### W4. Theme-Aware SVG

SVG grafik/icon renkleri `stroke="currentColor"` + `fill="currentColor"` + token class (`text-danger-500`, `fill-foreground-400`, ...) üzerinden tüketilir; `fill`/`stroke` içine hex/rgb hardcode EDİLMEZ. Light/Dark otomatik uyum sağlar (`DonutChart`/`LineChart` zaten bu standarda uyar).

### W5. Bu Audit'te Düzeltilenler

1. **Kırık görsel fallback eklendi** — `Avatar` ve `AvatarUpload`'a `onError` → baş harf fallback; `BrandLogo`'ya `onError` → metin yer tutucu. Önceden `src` verilip yüklenemezse kırık-resim ikonu gösteriliyordu.
2. **Lazy loading eklendi** — `Avatar`/`AvatarUpload` önizlemeleri `loading="lazy"` (below-fold listeler için); `BrandLogo` LCP olduğu için bilinçli eager bırakıldı.

### W6. Zaten Merkezi Olanlar (Değiştirilmedi)

`Avatar` (tek görüntüleme avatarı + `getInitials`), `AvatarUpload` (tek yükleme motoru, H bölümüyle tutarlı), `BrandLogo` (tek logo, K bölümüyle tutarlı), Remix Icon CDN (tek icon kaynağı), `DonutChart`/`LineChart` (token-aware SVG) — tümü önceki kilitlerde merkeziydi. "SharedIcon" ismini bilinçli AYRI component olarak oluşturmadım — Remix Icon `<i>` zaten tek kaynak; boş bir sarmalayıcı eklemek gereksiz abstraction olurdu (T bölümündeki "SharedNotification" ilkesiyle aynı).

---

## X. GLOBAL UI CORE FINAL LOCK (KALICI STANDART)

> Bu bölüm İSGDenetim'in EN ÜST ve NİHAİ UI mimari kilididir. Aşağıdaki mimari GLOBAL ve KALICI standart olarak kabul edilmiştir. Bir çelişki olursa bu bölüm önceliklidir.

### X1. Son Mimari

```
                   APPLICATION
                        │
                   SharedUICore   (src/components/index.ts + src/components/ui + src/components/feature + hooks + context)
                        │
      ┌─────────────────┼─────────────────┐
      │                 │                 │
   Desktop           Mobile          Accessibility
      │                 │                 │
      └─────────────────┼─────────────────┘
                        │
      ┌─────────┬───────┼───────┬─────────┐
      │         │       │       │         │
    Admin    Uzman   İşyeri   OSGB    Yeni Paneller
      │         │       │       │         │
      └─────────┴───────┴───────┴─────────┘
```

**PANELLER UI ÜRETMEZ. PANELLER SharedUICore KULLANIR.**

### X2. Kapsanan Tüm Katmanlar (Tek Core)

Layout, Grid, Spacing, Typography, Theme, Color, Button, Icon, Input, Select, Dropdown, Popover, Tooltip, Modal, Action Sheet, Toast, Card, KPI, Listing, Table, Row, Form, Tabs, Search, Filter, Pagination, Loading, Skeleton, Empty, Error, Success, Checkbox, Radio, Switch, DatePicker, Avatar, Header, Sidebar, Bottom Navigation, Keyboard, Touch, Long Press, Accessibility, Responsive, Performance — **TAMAMI TEK `SharedUICore` tarafından yönetilir.**

### X3. 5 Panel + Yeni Paneller Aynı Core

- **5 Panel:** Admin, Uzman, İşyeri, OSGB (+ Firma, Hekim) — hepsi AYNI Core'u kullanır.
- **Yeni sekme:** yeni UI sistemi OLUŞTURMAZ.
- **Yeni panel:** yeni UI sistemi OLUŞTURMAZ.
- **İhtiyaç Core'da yoksa:** önce `SharedUICore`'a eklenir (barrel'a bağlanır), SONRA panelde tüketilir.
- **DUPLICATE UI YASAK:** panel içine global `Button`/`Modal`/`Card`/`Input`/`Dropdown`/`Listing` YAZILMAZ.

### X4. Desktop / Mobile / iOS+Android Tek Kaynak

- **Desktop:** Shared Desktop UI (Sidebar + Topbar + Table + Modal).
- **Mobile:** Shared Mobile UI (BottomNav + Sheet + mobil Modal + kart liste).
- **iOS + Android:** Shared Mobile UI (aynı safe-area + viewport + touch motoru, browser'a özel farklı UI YOK).
- **Aynı Design Token sistemi:** renk/typography/spacing/radius yalnızca `index.css` scale değişkenlerinden (OKLCH) tüketilir.

### X5. Davranış Kilitleri (Kullanıcı + Tema + Animasyon)

- **Kullanıcı:** Light/Dark/Automatic seçimi korunur (`ThemeContext`).
- **Tema:** TAK değişir, animasyon YOK, flash YOK (FOUC script + `color-scheme` + `theme-color`).
- **Modal / Dropdown / Action Sheet:** TAK açılır, TAK kapanır, animasyon YOK.
- **Bottom Navigation:** modal/action-sheet açılışında HAREKET ETMEZ.
- **Listing:** Desktop → yoğun hizalı tablo/liste; Mobile → kompakt kart/liste. AYNI `Table` + `TableListing` + `SharedListCard` motoru (çift varyant DOM YOK).

### X6. Alignment Standardı

Aynı UI elementi her yerde AYNI: yükseklik, genişlik mantığı, spacing, radius, typography, hizalama, renk, interaction değerlerinden gelir. Panel bazlı farklı değer ÜRETİLMEZ (F kilidiyle tutarlı).

### X7. Code Cleanup Kuralı

Kullanılmayan ve GÜVENLİ ŞEKİLDE doğrulanmış component/hook/function/state/effect/CSS/asset/dependency/route/utility temizlenir. **Çalışan kod TAHMİNLE silinmez.** Bu audit'te silinmesi güvenle doğrulanabilen ölü kod bulunmadı — mevcut envanterin tamamı barrel üzerinden tüketiliyor (N1/J2). Boş mock dizileri (`planliBakimListesi`, `bakimGecmisi`) ileride dolacak yer tutuculardır, silinmedi.

### X8. Accessibility + Performance + Compatibility

- **Accessibility:** keyboard + screen reader + focus + contrast standardı global (R + Q bölümleri).
- **Performance:** gereksiz render, memory leak, duplicate request ve ağır UI temizlenir (V bölümü).
- **Compatibility:** Chrome/Safari/Firefox/Edge + iOS/Android kontrol edilir (U bölümü).

### X9. Gelecek Kuralı (Yeni Geliştirici)

Yeni bir geliştirici yeni bir ekran oluşturduğunda **ÖNCE `SharedUICore`'a bakmak ZORUNDADIR.** Mevcut component varsa YENİDEN OLUŞTURAMAZ; yoksa `SharedUICore`'a ekler. Böylece uygulama büyüdükçe UI dağılmaz.

---

## Y. GLOBAL MOBILE FULL-SCREEN MODAL SYSTEM (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI mobil modal kilididir. Admin + OSGB + Firma + Uzman + Hekim panellerinin TAMAMINDA ve bundan sonra oluşturulacak TÜM sayfa/sekme/modal için aşağıdaki kural ZORUNLUDUR. **Mobilde modal ASLA küçük ortalanmış pencere / floating dialog / dar popup / yarım ekran kutu OLMAZ.**

### Y1. Tek Kaynak (Shared Mobile Full-Screen Modal)

| İşlev | Tek Kaynak |
|---|---|
| Global modal motoru | `useModal` + `Modal` + `ModalManager` |
| Onay dialogu | `useConfirm` + `ConfirmDialog` |
| Full-screen geometri | `.isg-modal-mobile-full` (unlayered CSS, `index.css`) |
| Safe-area header | `.isg-modal-mobile-header` (`index.css`) |
| Safe-area footer | `.pb-safe-footer` (`index.css`) |
| Scroll lock | `ModalManager` (`document.body.style.overflow`) |
| Responsive motor | `useMediaQuery` (`(max-width: 1023px)`) |

Panel başına `AdminModal` / `OSGBModal` / `UzmanModal` / `IsyeriModal` / `CustomDetailModal` / `NewModal` / `SpecialModal` gibi duplicate modal sistemi OLUŞTURULMAZ. Eksik modal özelliği varsa önce `SharedUICore`'a eklenir.

### Y2. Mobil Modal Geometrisi (100vw × 100dvh)

Mobil (`< 1024px`) altında açılan her modal — detay, form, edit, create, filter, confirmation, preview, action, information — **full-screen** açılır:

```
inset: 0
width / min-width / max-width : 100vw
height / min-height / max-height : 100vh → 100dvh (fallback)
margin / padding : 0
border-radius : 0
border / box-shadow : none
```

- `100dvh` (iOS dinamik adres çubuğu) + `100vh` fallback — modal ekranın altında/üstünde boşluk bırakmaz, aşağı/yukarı kaymaz.
- Safe-area dört kenarda da dikkate alınır: header üst `env(safe-area-inset-top)` (`.isg-modal-mobile-header`), footer alt `env(safe-area-inset-bottom)` (`.pb-safe-footer`). Home indicator footer butonlarının üzerine BİNMEZ.
- Body `flex-1 min-h-0 overflow-y-auto overflow-x-hidden` — yalnızca modal içeriği scroll eder; modal `100dvh` kalır, içerik modalı büyütmeye ÇALIŞMAZ. Header/footer `flex-shrink-0` ile body'yi ezmez.

### Y3. İç Yapı (Header / Body / Footer)

- **Header:** kompakt, sabit, tek satır; başlık `truncate` (ellipsis, ikinci satır YOK); kapatma butonu `SharedUICore` icon sistemi (`ri-close-line`); tema uyumlu. Scroll sırasında kaybolmaz (flex column içinde `flex-shrink-0`).
- **Body:** uzun form/detay/tablo/tutanak/filtre/kayıt detayı/belge önizleme/sekme — hepsi body içinde scroll eder. Sayfanın kendisi modal açıkken scroll OLMAZ (Y6).
- **Footer:** yalnızca gerektiğinde (İptal/Kaydet, Vazgeç/Onayla); `SharedButton`; safe-area uyumlu; body scroll'undan bağımsız.

### Y4. Scroll Lock

Modal açıldığında (`ModalManager`, `hasOpenModal` = en az bir minimize-EDİLMEMİŞ modal) mobilde `document.body.style.overflow = 'hidden'` uygulanır; kapandığında `''` ile geri alınır. Sonuç: arka sayfa kaymaz, iOS body scroll engellenir, overscroll ile arka sayfaya geçilmez, çift scroll/nested scroll karmaşası olmaz, modal kapanınca kullanıcı aynı scroll pozisyonuna döner. Desktop windowed modal (arka plan kullanılabilir MDI sistemi, L6) BU KURALDAN ETKİLENMEZ.

### Y5. iOS / Android / Klavye

- **iOS Safari / WebView / PWA:** Dynamic Island / notch / home indicator / portrait / landscape / klavye açık-kapalı — modal hiçbir durumda ekran altında kesilmez, header kaybolmaz, footer kesilmez, input klavyenin altında kalmaz, zoom yapmaz (input `font-size:16px`, U2), viewport dışına taşmaz.
- **Android Chrome / WebView / PWA:** gesture nav / nav bar / status bar / farklı ekran oranları / klavye — aynı Shared modal. Android'e özel farklı modal UI YOK; yalnızca teknik safe-area/viewport çözümü.
- **Klavye:** `100dvh` visual-viewport davranışıyla yeniden hesaplanır; global `ViewportManager` kullanılır, sayfa bazlı keyboard hack YOK.

### Y6. Bu Audit'te Düzeltilenler (Kök Neden)

Önceki `Modal` mobil render'ı **tam ekran DEĞİLDİ** — `12px` kenar boşluğu + `calc(100% - 24px)` genişlik + `88dvh` max-height + `rounded-2xl` ile "ortada küçük floating pencere" olarak açılıyordu (O3 kilidi "full-screen" iddia ediyordu ancak kod bunu UYGULAMIYORDU). Kapatılan 3 gerçek boşluk:

1. **`Modal` mobil full-screen geometri** — `isMobile && !minimized` durumunda `.isg-modal-mobile-full` class'ı (inset 0 + 100vw + 100dvh + radius 0) uygulanır; inline style mobilde yalnızca `zIndex` taşır, geometry class'tan gelir. Desktop windowed render (drag/resize/minimize/maximize, L1–L5) BİREBİR korundu.
2. **`ConfirmDialog` mobil full-screen** — `< 1024px` altında `.isg-modal-mobile-full` ile tam ekran; icon+başlık+mesaj üst alanda, İptal/Onay butonları alt footer'da (`pb-safe-footer`). Desktop `max-w-md` ortalanmış dialog değişmedi.
3. **`ModalManager` mobil scroll lock** — `useMediaQuery` + `hasOpenModal` üzerinden body scroll kilidi.

### Y7. Action Sheet / Drawer Ayrımı (Kesin)

- **`BottomSheet` + `ActionSheet`** = kısa aksiyon listeleri, long-press aksiyonları, hızlı seçenekler (A–Q ile tutarlı). Modal DEĞİLDİR, full-screen YAPILMAZ.
- **`Modal` + `ConfirmDialog`** = detay/form/düzenleme/oluşturma/filtre/bilgi/onay/kapsamlı içerik → MOBİLDE FULL-SCREEN.
- **Drawer sistemi KESİNLİKLE geri getirilmez** (O10 kilidiyle tutarlı).

### Y8. Zorunlu Kurallar (Gelecekteki Tüm Geliştirmeler İçin)

- **Mobilde modal = TAM EKRAN, İSTİSNASIZ.** "Bu sayfada daha küçük modal daha güzel olur" mantığıyla farklı mobil modal tasarlanamaz.
- **Animasyon YOK** — modal TAK açılır, TAK kapanır (`animation: none; transition: none;`). Önce küçük görünüp büyüme YASAK.
- **Z-index merkezi** — `Z_LAYERS` (`modalBase:1000`, `confirm:9998`, `toast:9999`) tek kaynak; rastgele `z-9999`/`99999` YAZILMAZ.
- **Erişilebilirlik** — `role="dialog"`/`role="alertdialog"` + `aria-modal` + `aria-label`; focus modal içine taşınır, kapanınca tetikleyiciye döner; dokunma hedefleri erişilebilir boyutta (R bölümü).
- **Business logic / routing / authorization / API / data model DEĞİŞMEZ** — yalnızca UI katmanı full-screen'e taşınır.
- **5-panel mimarisi korunur** — tüm paneller aynı `Modal` motorunu tüketir.

### Y9. Acceptance Criteria (Özet)

Mobilde açılan TÜM modallar full-screen; küçük pencere kalmaz; hepsi `SharedMobileModal` (= `Modal` mobil varyantı) kullanır; header/body/footer standart; body kendi içinde scroll; arka sayfa scroll olmaz; iOS Safari + Android Chrome + WebView/PWA düzgün çalışır; klavye modalı bozmaz; input zoom yapmaz; safe-area düzgün; Dark/Light düzgün; animasyon yok; z-index merkezi; accessibility korunur; desktop modal bozulmaz; business logic değişmez; routing değişmez; authorization değişmez; API/data modeli değişmez; 5-panel mimarisi korunur; drawer geri gelmez; yeni modal SharedUICore dışında UI yazamaz.

---

## Z. GLOBAL UI FINAL AUDIT & FIX (KALICI STANDART)

> Bu bölüm İSGDenetim'in EN SON global UI denetim sonucudur. Tüm paneller / sekmeler / ekranlar SharedUICore seviyesinde denetlenmiş; bulunan ortak kök nedenler merkezi olarak kapatılmıştır. Bir çelişki olursa bu bölüm önceliklidir.

### Z1. Audit Sonucu — Onaylanan Sağlam Katmanlar (Değiştirilmedi)

Tema motoru, buton/icon-buton sistemi, dropdown/portal motoru (`DropdownPanel` + `useDropdownPosition` + `Z_LAYERS.dropdown`), form core, tablo/liste motoru, toast/confirm, modal motoru, accessibility (R), performance (V), asset/image (W), cross-browser (U) — önceki kilitlerde zaten tek kaynaktan kuruluydu. Hardcoded hex/rgb renk SIFIR (yalnızca `ThemeContext` meta `theme-color` `#0B0F19`/`#f8fafc` — tarayıcı chrome rengi, tasarım token'ı DEĞİL). Duplicate `transition-colors`/`animate-pulse`/`animate-spin` kullanımları LEGAL (interaction hover + skeleton + spinner — "açılış animasyonu" değil).

### Z2. Bu Audit'te Kapatılan Kök Nedenler (Tek Kaynak Kuralı)

Tarama **3 gerçek z-index/responsive sızıntısı** çıkardı — hepsi "tek kaynak" (J5/J7/O7) kilidini ihlal ediyordu:

1. **Z-index magic number dağılımı** — `layers.ts` varken `Topbar` (`z-30`), `BottomNav` (`z-[100]`), `BottomSheet` (`z-[150]`/`z-[160]`), `NotificationBell`/`UserProfile`/`Topbar` arama dropdown'ı (`z-50`), `ModalManager` backdrop (`z-[900]`) kendi değerlerini yazıyordu. Ayrıca `Modal`'daki `MINIMIZED_Z_BASE=5000` + `?? 1000` fallback'i ve `useModal`'daki `zCounterRef=useRef(1000)` `Z_LAYERS` ile çakışan kopyalardı. ÇÖZÜM: `Z_LAYERS`'a `topbar:30`, `topbarDropdown:50`, `bottomNav:100`, `bottomSheetOverlay:150`, `bottomSheetPanel:160` eklendi; tüm bu bileşenler `Z_LAYERS.*`'a bağlandı; `MINIMIZED_Z_BASE`/`?? 1000`/`zCounterRef(1000)` → `Z_LAYERS.minimizedModal`/`Z_LAYERS.modalBase`. Artık z-index TEK kaynaktan, rastgele değer YOK.

2. **Çift responsive motor** — `UserProfile` ve `Modal`, global `useMediaQuery` varken kendi `window.innerWidth < 1024` + elle `resize` listener + `useState` tutuyordu. ÇÖZÜM: ikisi de `useMediaQuery('(max-width: 1023px)')`'e geçirildi; elle listener/state kaldırıldı (listener leak riski + gereksiz state giderildi, V kuralıyla tutarlı). `NotificationBell` önceki turda zaten geçirilmişti — şimdi tüm responsive algılama TEK motordan.

3. **Modal'da silinen işlevsel effect'ler geri kondu** — responsive geçişi sırasında yanlışlıkla kaldırılan `ResizeObserver` (maximize modal'ın resize'da viewport'a oturması) ve resize-clamp effect'leri birebir geri eklendi; desktop windowed modal davranışı (L1–L5) korundu.

### Z3. Final UI Regression Cevapları (Evet)

Her mobil modal full-screen (Y); desktop modal ortak (L); buton/input/dropdown/liste/tablo/toast/loading/error/empty ortak (J/N/S/T); header hizalı (I); tüm paneller aynı grid (J/X); Dark/Light/Automatic tutarlı (E/U); kullanıcı tema tercihi korunur; iOS/Android/klavye düzgün (U/Y); long-press/ESC/Enter düzgün (Q); accessibility düzgün (R); horizontal overflow yok (O4); gereksiz animasyon yok (X5); drawer yok (O10); duplicate UI yok; kullanılmayan UI kodu güvenle doğrulanabilir ölçüde yok; performans giderildi (V/Z2).

### Z4. Zorunlu Kurallar (Gelecekteki Tüm Geliştirmeler İçin)

- **Z-index TEK kaynak:** `Z_LAYERS` (`src/utils/layers.ts`) dışında `z-*`/`z-[N]`/`zIndex: N` YAZILMAZ. Yeni katman gerekirse önce `Z_LAYERS`'a eklenir, sonra tüketilir.
- **Responsive TEK kaynak:** breakpoint algılama yalnızca `useMediaQuery` ile. `window.innerWidth` + elle `resize` listener + `useState` responsive flag YAZILMAZ.
- **Business logic / routing / authorization / API / data model DEĞİŞMEZ** — bu audit yalnızca z-index merkezileştirme + responsive tek motor + işlevsel effect restorasyonudur.
- **5-panel mimarisi korunur; drawer geri gelmez; yeni panel/sekme SharedUICore kullanır (X9).**

---

## AA. GLOBAL INTERACTION CORE — FINAL HARDENED LOCK (KALICI STANDART)

> Bu bölüm İSGDenetim'in NİHAİ etkileşim (interaction) standardıdır. Q (keyboard/touch), R (accessibility), S (state/form), U (cross-browser), V (performance), Y (mobil modal), Z (z-index/responsive) bölümlerinin interaction boyutunu TEK çatıda birleştirir. Button / IconButton / Link / Row / Card / TableRow / Modal / Form / Input / Textarea / Select / Dropdown / Popover / Tabs / Checkbox / Radio / Switch / DatePicker / Search / Filter / Pagination / Toast / Confirmation / ActionSheet / BottomNav / DesktopNav — TAMAMI tek `SharedUICore` interaction çekirdeğinden yönetilir. Panel/sekme kendi keyboard/touch/click davranışını YAZMAZ.

### AA1. Tek Kaynak Envanteri (Interaction Motorları)

| İşlev | Tek Kaynak |
|---|---|
| Buton (variant + size + state) | `Button` (`isg-btn` + `primary/secondary/outline/ghost/danger/success/link` × `sm/md/lg`) |
| İkon buton | `IconButton` (`ghost/primary/secondary/danger` × `sm/md/lg` + `aria-label`) |
| Roving tabindex + arrow/Home/End | `useRovingFocus` + `listboxStep` (`useKeyboardNav.ts`) |
| Uzun basma (long-press) | `useLongPress` (pointer-event + hareket eşiği + scroll iptali) |
| Dışarı tıklama + viewport konum | `useClickOutside` + `useDropdownPosition` |
| Responsive algılama | `useMediaQuery` (`(max-width: 1023px)`) — `window.innerWidth`/elle `resize` YAZILMAZ |
| Form submit + çift submit kilidi | `useForm` (`isSubmitting` + `validateAll` + `isDirty`) |
| Modal focus trap + ESC + Enter | `Modal` (FOCUSABLE + DROPDOWN_SELECTOR + `enterLockRef`) |
| Onay (destructive) | `useConfirm` + `ConfirmDialog` (capture-phase ESC + autofocus İPTAL) |
| Z-index katmanı | `Z_LAYERS` (`layers.ts`) — `z-*`/`z-[N]` magic number YAZILMAZ |

### AA2. Button State Matrisi (Zorunlu)

Her `Button`/`IconButton` şu state'leri destekler (hepsi `isg-btn`/`isg-input` token sisteminden):

- **default / hover / active** — `isg-btn*:hover` + `.isg-btn:active:not(:disabled){ filter: brightness(0.94) }`.
- **focus-visible** — `:focus-visible` outline `oklch(var(--primary-500))` (mouse/touch'a agresif ring YOK).
- **disabled** — `disabled={disabled || isLoading}`; tıklanamaz, Enter/Space tetiklemez, TAB zincirine girmez.
- **loading** — `isLoading` → spinner (`ri-loader-4-line`/border spin) + metin korunur + genişlik kaymaz + çift submit engelli.
- **success/error** → `success`/`danger` varyantları (token `--success-*`/`--danger-*`).

**Çift submit koruması (ZORUNLU):** async işlem (`Kaydet/Oluştur/Güncelle/Sil/Onayla/Gönder`) başladığında `isLoading`/`isSubmitting` ile aynı işlem ikinci kez tetiklenemez. Button click + Enter + double click + rapid tap + Enter spam TEK submit fonksiyonuna bağlanır (semantic `<form onSubmit>` korunur; textarea Enter = yeni satır, submit DEĞİL).

### AA3. Enter — Context-Aware Matrisi (Zorunlu)

`Modal` Enter handler'ı kör click YAPMAZ; sırayla şu kontrolleri yapar (`Modal.tsx`):
1. `e.defaultPrevented` → iptal.
2. `target.tagName === 'textarea'` → yeni satır, submit YOK.
3. `target.closest('button')` → native button click'e bırak (çift tetikleme YOK).
4. `target.closest(DROPDOWN_SELECTOR)` (listbox/combobox/menu/option) → dropdown'a bırak.
5. `enterLockRef` (350ms) → Enter spam tek submit.
6. Aksi halde → form submit (`modal.onSubmit`) veya wizard sonraki adım (`goToStep`).

Aynı fiziksel Enter: tek aksiyon. Search input'ta Enter → search; form submit/modal confirm/row-open ikinci aksiyon OLARAK tetiklenmez.

### AA4. ESC — Katman Önceliği Matrisi (Zorunlu)

ESC en üstteki aktif interaction layer'ı kapatır; tek ESC ile TÜM katmanlar birden kapanmaz. Öncelik sırası:

1. **Açık dropdown/popover** — `Select`/`Autocomplete`/`ContextMenu`/`BottomSheet` kendi ESC handler'ı.
2. **Açık date picker** — native `<input type="date">` kendi ESC'yi tarayıcıda tüketir (modal'a sızmaz).
3. **Confirmation** — `ConfirmDialog` `window.addEventListener('keydown', ..., true)` (CAPTURE) + `stopImmediatePropagation` → daima en üst, modal motoruna sızmaz.
4. **Modal** — `Modal` ESC handler'ı önce açık dropdown (`aria-expanded="true"`) kontrol eder, yoksa `handleCloseRequest`; `modal.unsaved` ise `ConfirmDialog` açar (veriyi yanlışlıkla silmez).

### AA5. Space / Tab / Arrow / Home / End (Zorunlu)

- **SPACE** → button activate / checkbox toggle / switch toggle / radio select (native semantic). Scroll yanlışlıkla tetiklenmez.
- **TAB / SHIFT+TAB** → sıradaki/önceki interactive element; gizli/disabled element focus zincirine girmez.
- **Arrow Left/Right + Home/End** → TabBar/Tabs (`useRovingFocus`), Arrow Up/Down + Home/End → ContextMenu/Select/Autocomplete (`listboxStep`).
- **Modal focus trap** → Tab modal dışına kaçmaz; kapanınca focus tetikleyiciye döner (`restoreFocusRef`).

### AA6. Row/Card Click vs Child Interaction (Zorunlu)

- Satır/kart tek dokunuş → detay (`onRowClick`).
- Satır içi **checkbox/button/iconButton/switch/dropdown/link/⋮** → `stopPropagation` ile yalnızca kendi işlemi; row detail AÇILMAZ.
- Standart yer: `SharedListCard` actions `<div onClick={stopPropagation}>`, `Table` checkbox/action `<td onClick={stopPropagation}>`, `ContextMenu` trigger `stopPropagation`. Rastgele `stopPropagation` yama YAZILMAZ — `SharedInteractiveRow/Card` standardına taşınır.
- `onClick` + `onTouchEnd` + `onPointerUp` üçlüsü birden bağlanıp duplicate event OLUŞTURULMAZ; Pointer Events / semantic click kullanılır.

### AA7. Long-Press + Tap Ayrımı (Zorunlu)

- **Short Tap** → detay. **Long Press** → `SharedMobileActionSheet` (alttan, animasyonsuz). İkisi aynı anda TETİKLENMEZ.
- `useLongPress`: `pointerdown` ile timer (500ms default), `pointermove` belirgin hareket (10px eşiği) / `pointerup` erken bırakma / `pointercancel` → timer iptal. Scroll başlarsa long-press İPTAL (Action Sheet yanlış açılmaz, scroll performansı bozulmaz).
- Native iOS/Android context menu / text-selection / callout / image-drag: UI alanında engellenir (`-webkit-touch-callout`/`-webkit-user-select`/`-webkit-user-drag`); **form input/textarea normal selection/copy KORUNUR**.
- Desktop right-click: gerçekten gerekiyorsa `ContextMenu`; gereksiz `preventDefault` ile browser davranışı bozulmaz. Mobile long-press ile desktop right-click karıştırılmaz.

### AA8. Dropdown / Popover / Tabs / Search / Filter / Pagination (Zorunlu)

- **Dropdown mouse:** click open → option click select → outside click close → ESC close → Enter select → Arrow navigate. **Dropdown mobile:** tap open/select, scroll sırasında yanlış option seçilmez, keyboard viewport'u bozmaz.
- **Popover:** trigger click open → outside/ESC close; popover içi işlem parent click tetiklemez.
- **Tabs:** click + Arrow/Enter/Space (roving); tab değiştirmek route/form submit gibi ikinci interaction TETİKLEMEZ.
- **Search:** Enter → search + debounce (300ms); tek request; `role="search"` + `aria-label`.
- **Filter:** Desktop `SharedPopover`/`SharedDesktopModal`, Mobile `SharedMobileModal` FULL SCREEN; açıkken background interaction kilitli.
- **Pagination:** click/tap + keyboard; disabled prev/next gerçekten disabled; sayfa değişiminde duplicate request engelli.

### AA9. Delete / Destructive (Zorunlu)

Destructive işlem (`Sil`/`Kapat`/`Pasif Yap`/`Çözüldü`) doğrudan tetiklenmez → `confirm()` (Shared) ile onay. `ConfirmDialog` autofocus **İPTAL** butonuna gider (Enter yanlışlıkla tehlikeli aksiyonu tetiklemez); primary destructive action (`variant="danger"`) açık görünür. Tarayıcı `alert`/`confirm` KULLANILMAZ.

### AA10. Theme / Interaction Lock

Theme control (Light/Dark/Automatic) `ThemeContext`'e iletir; rapid click/tap UI'yi bozmaz; tema geçişi ANİ (`html.theme-transitioning` kilidi) — animasyon YOK; kullanıcı tercihi persist edilir (`localStorage`). Modal/dropdown/action-sheet/toast açılış-kapanışı "TAK" — fade/slide/scale/spring YOK (`animation:none; transition:none`).

### AA11. Bilinçli Değiştirilmedi / Kapsam Dışı

- **Android hardware back / browser history modal entegrasyonu (spec 48) UYGULANMADI.** Mevcut proje `react-router` + `BrowserRouter(basename)` kullanır; modal açılışında `history.pushState` + `popstate` listener eklemek routing/back/forward davranışını değiştirir. Bu turun kendisi "routing DEĞİŞMEZ" (spec 25/26) kuralıyla çelişir. Modalın kapanışı header kapat/geri + ESC + dışarı tıklama + capture-phase confirm ile zaten sağlanır. History entegrasyonu yalnızca routing-izolasyonlu bir fazda değerlendirilir.
- **"SharedInteractionCore/SharedKeyboardInteraction/... adında boş sarmalayıcı component OLUŞTURULMADI"** — T/S/X bölümlerindeki "SharedForm"/"SharedNotification"/"SharedIcon" ilkesiyle aynı: motor zaten `useKeyboardNav` + `useLongPress` + `useDropdown` + `useMediaQuery` + `useForm` + `Modal`/`ConfirmDialog` olarak somut ve tektir; isim-üstü boş abstraction gereksiz olurdu.

### AA12. Acceptance Criteria (Özet)

Tüm buton/iconButton tek sistem + state matrisi; çift submit engelli; Enter context-aware (textarea/dropdown/button ayrımı); ESC katman önceliği (dropdown→datepicker→confirm→modal); Space/Tab/Arrow/Home/End; focus-visible; modal focus trap + restore; row/card click child interaction'dan izole; long-press hareket eşiği + scroll iptali + tap ayrımı; native context menu bastırılmış (form hariç); dropdown/popover/tabs/search/filter/pagination ortak; destructive confirm; tema ani + persist; animasyon YOK; z-index `Z_LAYERS`; responsive `useMediaQuery`; business logic/routing/auth/API/data model DEĞİŞMEZ; 5-panel mimarisi korunur; drawer geri gelmez.

---

## AB. GLOBAL RUNTIME ERROR PREVENTION & RECOVERY CORE (KALICI STANDART)

> Bu bölüm İSGDenetim'in NİHAİ runtime kararlılık standardıdır. Amaç: uygulama başlangıcında veya herhangi bir ekranda JavaScript/runtime hatası oluştuğunda beyaz ekran / kontrolsüz crash YAŞANMAZ. Hata gizlenmez — önce ROOT CAUSE bulunur/düzeltilir, sonra Error Boundary + Recovery devreye girer.

### AB1. Tek Kaynak Envanteri (Runtime Error Motorları)

| İşlev | Tek Kaynak |
|---|---|
| Merkezi error logger | `errorLogger` (`src/utils/errorLogger.ts`) — `logError` + `subscribeErrorLogger` |
| Global senkron hata yakalayıcı | `installGlobalErrorHandlers` (`window 'error'`) |
| Global async/UnhandledRejection yakalayıcı | `installGlobalErrorHandlers` (`window 'unhandledrejection'`) |
| Root error boundary | `ErrorBoundary` (`src/components/ui/ErrorBoundary.tsx`) |
| Ekran-level hata durumu | `ErrorState` (mesaj + `onRetry` "Tekrar Dene") |
| Retry button | `Button` (`isLoading` + disabled rapid-tap koruması) |

Panel bazlı `AdminErrorBoundary` / `UzmanErrorBoundary` / `OSGBErrorBoundary` OLUŞTURULMAZ. `SharedErrorBoundary` (= `ErrorBoundary`) kullanılır.

### AB2. Boot Sırası ve Global Yakalayıcı Kurulumu

`main.tsx` boot sırası (kalıcı):

1. `import './i18n'` (çeviri init)
2. `import { installGlobalErrorHandlers } from './utils/errorLogger'` → **EN BAŞTA çağrılır** (`installGlobalErrorHandlers()`)
3. `createRoot(...)` → root element yoksa güvenli fallback (beyaz ekran yerine Türkçe "Uygulama başlatılamadı" mesajı)
4. `<StrictMode><App/></StrictMode>`

`installGlobalErrorHandlers` yalnızca LOGLAMA yapar; `preventDefault` ÇAĞRILMAZ (Error Boundary + varsayılan davranış bozulmaz). Idempotent (`installed` guard, çift kurulum yok). Boot sırasındaki bir hata bile loglanır — beyaz ekrana düşmeden yakalanır.

### AB3. Error Logger Kuralları (Zorunlu)

- **Hassas veri filtreleme:** `password`/`token`/`authorization`/`bearer`/`api-key`/`secret`/JWT desenleri loglamadan ÖNCE `[REDACTED]` ile maskelenir. Gerçek değer asla sızmaz.
- **Deduplication:** aynı `severity|component|message` imzası `DEDUPE_WINDOW_MS` (2000ms) içinde tekrar gelirse loglanmaz (yalnızca sayaç artar). Map `MAX_DEDUPE_MAP` (500) ile sınırlı — şişmez.
- **Dev/Prod ayrımı:** Development'ta tam stack + kaynak konumu + component adı korunur; Production'da yalnızca güvenli minimal mesaj (internal değişken adı / file path / stack YOK).
- Logger hiçbir UI component'ine bağımlı DEĞİLDİR (en düşük seviye); dinleyici hatası logging'i çökertmez (try/catch).

### AB4. Error Boundary Kuralları (Zorunlu)

- **Root seviye:** `App` içinde `ErrorBoundary` tüm `Shell`/`AppRoutes`'ı sarar — bir ekran hatası bütün uygulamayı çökertmez.
- **Retry loop guard:** `consecutiveErrors` sayacı; aynı hata `MAX_CONSECUTIVE` (3) kez art arda tekrarlanırsa otomatik full reload'a düşülür (sonsuz load→error→retry döngüsü YOK). Reload TEK SEFERLİK (`setTimeout 150ms`) — sonrası kullanıcı kontrolünde.
- **Rapid-tap koruması:** retry `retrying` flag ile kısa süreli disabled — birden fazla recovery aynı anda başlatılamaz.
- **Dev/Prod UI ayrımı:** Development'ta gerçek `error.message` + component stack konsola/UI'a yansır (root cause analizi); Production'da kullanıcıya teknik/internal mesaj GÖSTERİLMEZ (yalnızca "Beklenmeyen bir hata oluştu" + retry).
- **SharedButton kullanılır:** retry butonu `Button` (`variant="primary"` + `leftIcon` + `isLoading`) — eski `isg-btn` hardcoded class YAZILMAZ.
- Panel/sekme seviyesinde ek izolasyon gerekirse `ErrorBoundary` `name` prop'u ile kullanılır (loglama etiketi + ayrı sınır) — ayrı error UI sistemi OLUŞTURULMAZ.

### AB5. Kök Neden Analizi Sonucu (Bu Audit)

Tarama sonucu — "Cannot access 'X' before initialization" / circular dependency / TDZ kaynaklı bir zincir **tespit edilmedi**:

- `components/index.ts` barrel'ı hiçbir yerden import EDİLMİYOR (circular üretmiyor); hook'lar yalnızca `react` + `@/utils/layers` import ediyor; feature component'leri doğrudan kaynak modül kullanıyor.
- Lazy/dynamic import YOK — route'lar statik (`src/router/config.tsx`), bu yüzden `ChunkLoadError`/stale-bundle riski bu fazda yok (backend/veri bağlandığında lazy code-splitting eklenirse `React.lazy` + `Suspense` + `ErrorBoundary` zorunlu olur).
- Module-scope `const`/`let` TDZ zinciri yok (tüm singleton'lar `useToast`/`useModal`/`useConfirm`'da güvenli init).

Sonuç: mevcut mimari bağımlılık zinciri temiz; bu audit'te asıl iş **güvenlik ağı** (logger + global yakalayıcı + recovery) kuruldu.

> **Takip (sonraki turlar):** "Cannot access 'ie' before initialization" hatasının GERÇEK kök nedeni bulundu — `hasError` değişkeni `const` ile tanımlanmadan ÖNCE okunuyordu (TDZ). Aynı bug İKİ form bileşeninde vardı: `MultiSelect.tsx` (ilk turda düzeltildi) ve `Autocomplete.tsx` (mobil QA turunda düzeltildi). Minify sonrası `hasError` → `ie` gibi kısa bir isme dönüşür; bu yüzden minified stack'te "Cannot access 'ie' before initialization" olarak görünüyordu. Her iki dosyada `const hasError = !!error;` satırı, `errorId` (ilk kullanım) satırından ÖNCE taşındı. Bu sınıf hata artık tüm form kontrollerinde (Input/Select/Textarea/Autocomplete/MultiSelect/DatePicker/TimePicker/Checkbox/Radio) imkânsız.

### AB6. Zorunlu Kurallar (Gelecekteki Tüm Geliştirmeler İçin)

- **Yeni hata UI'ı OLUŞTURULMAZ:** `SharedErrorState`/`SharedErrorBoundary`/`SharedRetry` tek kaynaktır (S + AB bölümleri). Panel bazlı duplicate error component YASAK.
- **Async işlemler** (`API`/`auth`/`config`/`lazy`): try/catch veya merkezi `logError` ile yönetilir; Unhandled Promise Rejection BIRAKILMAZ (global `unhandledrejection` yalnızca son güvenlik ağıdır, yerine geçmez).
- **Kullanıcıya iç hata GÖSTERİLMEZ:** Production'da variable name / stack / file path / API secret / environment value sızmaz (AB3/AB4).
- **Retry sonsuz döngü YAPMAZ:** gerçek bug'da güvenli fallback'e düşülür; `window.location.reload` yalnızca `MAX_CONSECUTIVE` aşımında TEK SEFER kullanılır (AB4).
- **Business logic / routing / authorization / API / data model DEĞİŞMEZ** — bu katman yalnızca error prevention + recovery güvenlik ağıdır. 5-panel mimarisi korunur; drawer geri gelmez.

### AB7. Acceptance Criteria (Özet)

Cold start / refresh / hard refresh açılıyor; iOS Safari + Android Chrome + WebView düzgün; console runtime error yok; "before initialization" yok; ReferenceError/TypeError yok; Unhandled Rejection yakalanıyor; circular init yok; global Error Boundary aktif; screen-level recovery aktif; retry duplicate çalışmıyor; infinite reload yok; API/auth/theme/SharedUICore/router init güvenli; modal/listing/form hatası ana uygulamayı çökertmiyor; Light/Dark/Automatic çalışıyor; 5-panel + routing + authorization + API + business logic korunuyor; drawer geri gelmiyor.

---

## AC. FAZ 2 / PROMPT 1 — İSG GEREKSİNİM MOTORU ALTYAPISI (MEVZUAT + KURAL)

> Faz 2'nin temel altyapısı: NACE, mevzuat kaynak kataloğu, versioned rule engine, gereksinim hesaplama servisi. Bu promptta HENÜZ tam İSG gereksinimleri (eğitim/ilkyardımcı/uzman/hekim/doküman) kodlanmaz; yalnızca altyapı kurulur. KİLİTLİ KURAL: **hiçbir mevzuat oranı/süresi/formülü tahmin edilmez, uydurulmaz**; doğrulanmamış her şey `verification_required` kalır.

### AC1. Yeni Tablolar (tek kaynak, duplicate yok)

1. **`public.nace_kodlari`** — merkezi NACE referansı. Kolonlar: `kod`, `faaliyet_tanimi`, `tehlike_sinifi` (CHECK: az/tehlikeli/cok), `versiyon`, `gecerlilik_baslangic/bitis`, `aktif`, zaman damgaları. `UNIQUE(kod, versiyon)` ile versiyonlama. Frontend dropdown'a HARD-CODE EDİLMEZ; merkezi kaynaktan gelir. Veri doğrulanmış tebliğden ayrıca import edilir (şu an boş).
2. **`public.mevzuat_kaynaklari`** — mevzuat kaynak kataloğu. `mevzuat_kodu/adi/turu`, `resmi_gazete_*`, `madde/fikra/bent`, `kaynak_url`, `effective_from/to`, `status` (verified/verification_required/superseded/inactive), `version`, `notes`.
3. **`public.isg_kurallari`** — versioned rule engine. `rule_code/name`, `requirement_type/subtype`, `legal_source_id` (FK→mevzuat), `legal_article`, `hazard_class`, `employee_count_min/max`, `conditions`, `calculation_type/definition`, `required_quantity`, `validity_duration/unit`, `effective_from/to`, `version`, `priority`, `active`, `status` (verified/verification_required/superseded/draft). `UNIQUE(rule_code, version)`.
4. **`public.isg_gereksinim_snapshot`** — append-only hesaplama geçmişi. `firma_id`, `osgb_id`, `requirement_code/type`, `source_rule_id/version`, `calculated_employee_count/hazard_class`, `required/current/remaining_quantity`, `result` (met/missing/critical/not_applicable/verification_required), `calculated_at`, `metadata`. Eski sonuçlar yeni rule version ile OVERWRITE EDİLMEZ.

### AC2. NACE → Tehlike Sınıfı (authoritative)

- `firmalar.nace_id` (nullable FK → nace_kodlari) eklendi.
- `firma_nace_hazard_sync` trigger'ı: `nace_id` set edilince `tehlike_sinifi` merkezi NACE'den türetilir; geçersiz/pasif NACE `NACE_INVALID_OR_INACTIVE` ile reddedilir. NACE değişince tehlike sınıfı yeniden değerlendirilir, önceki hesaplama geçmişi korunur.
- NACE yoksa firma.manuel `tehlike_sinifi` (mevcut Faz 1 davranışı) geçerli kalır.

### AC3. Authoritative Çalışan Sayısı (Faz 1 kilidi korunur)

- Panel VAR → aktif personel (`personeller` aktif kayıtları) authoritative.
- Panel YOK → `manuel_calisan_sayisi` authoritative.
- İki kaynak KARIŞTIRILMAZ; hesaplama edge function içinde server-side yapılır.

### AC4. Hesaplama Servisi (edge function `gereksinim-hesapla`)

Akış: auth → role doğrula (admin/osgb_admin/firma) → OSGB/firma scope → OSGB erişim penceresi → firma aktiflik → NACE/tehlike sınıfı → çalışan sayısı → yürürlükteki verified aktif rule'ları getir → değerlendir → snapshot persist → audit → sonuç döndür. Frontend'den gelen `employee_count/hazard_class/osgb_id/rule_id/required_quantity` değerlerine GÜVENİLMEZ.

### AC5. RLS / Güvenlik

- NACE/mevzuat/kurallar: SELECT tüm authenticated; INSERT/UPDATE/DELETE yalnızca admin.
- Snapshot: SELECT admin(tümü) / osgb_admin(kendi OSGB) / firma(kendi firma). INSERT/UPDATE/DELETE istemciye kapalı (yalnızca service role edge function).
- `USING(true)` YOK; cross-OSGB / cross-firma / role spoof trigger + scope doğrulamasıyla kapalı.

### AC6. Audit

- `gereksinim-hesapla` `ISG_GEREKSINIM_HESAPLANDI` olayını `system_logs`'a yazar (gerçek user_id/role/osgb_id).
- `firma_nace_hazard_sync` trigger'ı NACE değişikliğini (`FIRMA_NACE_SET`/`FIRMA_NACE_CHANGED`) `audit_log` ile izler.
- Frontend user_id/role/osgb_id spoof edemez.

### AC7. Frontend Servis

- `src/lib/gereksinimService.ts` — tip + `calculateFirmaRequirements(firmaId)` (edge function invoke) + Türkçe sunum etiketleri. Mevzuat oranı/süresi İÇERMEZ.

### AC8. Durum / Kalan

- Tüm referans/veri tabloları BOŞ (uydurma veri yok). NACE + mevzuat + kural verisi, doğrulanmış güncel resmi kaynaklardan (6331 + tebliğler, Resmî Gazete/Mevzuat Bilgi Sistemi) sonraki promptlarda import edilecek.
- `engineState: 'no_verified_rules'` → doğrulanmış aktif kural yokken motor güvenli boş sonuç döner; asla "kesinlikle budur" demez.
- Eğitim/ilkyardımcı/uzman/hekim/doküman gereksinimlerinin TAMAMI sonraki Faz 2 promptlarında doğrulanmış mevzuata bağlanarak eklenir.

---

## AD. FAZ 3 / PROMPT 1 — EVRAK ALTYAPISI + SAHİPLİK + GEREKSİNİM BAĞLANTISI

> Faz 3'ün temel altyapısı: merkezi evrak veri modeli, firma/personel evrakı ayrımı, uploader/owner ayrımı, Faz 2 gereksinim → evrak bağlantısı, storage güvenliği, RLS/scope, evrak geçmişi/version foundation, audit. KİLİTLİ AYRIM: **firma yükümlülüğü ≠ evrak ≠ sahip ≠ yükleyen**. Geçerlilik/bitiş/yaklaşan süre hesaplaması Faz 3 sonraki promptlarında yapılır; hiçbir mevzuat oranı/süresi uydurulmaz.

### AD1. Yeni Tablolar (tek kaynak, duplicate yok)

1. **`public.evrak_turleri`** — merkezi evrak türü kataloğu (frontend'e hardcode EDİLMEZ). `code` (unique), `name`, `description`, `owner_type` (nullable: firma/personel), `active`, `version`. Evrak türü ile mevzuat requirement'ı FARKLI kavramlardır; katalog doğrulanmamış mevzuat zorunluluğu ÜRETMEZ.
2. **`public.firma_gereksinimleri`** — Faz 2 hesaplamasının KALICI stabil çıktısı (append-only snapshot'tan ayrı). `firma_id` + `rule_id` (FK→isg_kurallari) + `osgb_id` + `requirement_code/type/title` + `required/current/remaining_quantity` + `status` (met/missing/critical/not_applicable/verification_required) + `calculated_at`. `UNIQUE(firma_id, rule_id)` → recalc upsert eder, eski sonuç sessizce overwrite edilmez (rule version yeni `rule_id` olduğundan tarih korunur).
3. **`public.evraklar`** — merkezi evrak kaydı. `owner_type` (CHECK: firma/personel), `firma_id`/`personel_id` nullable, `requirement_id` (FK→firma_gereksinimleri), `document_type_id` (FK→evrak_turleri), `title/description`, `storage_path/original_file_name/mime_type/file_size`, `document_date/valid_from/valid_until`, `status` (pending/valid/expiring/expired/rejected/archived/verification_required), `uploaded_by` (FK→profiles).

### AD2. Sahiplik / Scope Kısıtları (DB trigger)

`evrak_validate` (BEFORE INSERT/UPDATE, SECURITY DEFINER):
- `owner_type='firma'` → `firma_id` zorunlu, `personel_id` NULL; `owner_type='personel'` → `personel_id` zorunlu (`firma_id` opsiyonel ilişkisel kapsam).
- `osgb_id` ASLA frontend'den alınmaz; firma/personel kaydından türetilir. firma↔personel OSGB uyuşmazlığı `CROSS_OSGB_OWNER` ile reddedilir.
- `requirement_id` set ise → gereksinimin `osgb_id` evrakla eşleşmeli (`REQUIREMENT_CROSS_OSGB`), firma eşleşmeli (`REQUIREMENT_FIRMA_MISMATCH`).

`evrak_lock_scope` (BEFORE UPDATE): owner_type / firma_id / personel_id / osgb_id / requirement_id değiştirilemez (IDOR ile başka firmaya/personel'e bağlama engelli).
`evrak_prevent_delete` (BEFORE DELETE): fiziksel silme yok — `archived` durumuna geçilir, geçmiş korunur.

### AD3. Yükleyen ≠ Sahip

`uploaded_by` gerçek `auth.uid()`'den belirlenir (edge function); `owner_type`+`firma_id/personel_id` belgenin sahibini tanımlar. Belge yükleyen kullanıcı otomatik olarak sahip OLMAZ (örn. Uzman Ahmet, ABC'nin risk değerlendirmesini yükler → owner=ABC, uploader=Ahmet).

### AD4. RLS / Güvenlik

- `evrak_turleri`: SELECT tüm authenticated; INSERT/UPDATE/DELETE yalnızca admin.
- `firma_gereksinimleri`: SELECT admin(tümü) / osgb_admin+uzman+hekim(kendi osgb) / firma(kendi firma). Yazma yok (service role).
- `evraklar`: SELECT admin(tümü) / osgb_admin+uzman+hekim(kendi osgb) / firma(kendi firma). INSERT/UPDATE/DELETE istemciye kapalı (yalnızca edge function service role).
- `USING(true)` YOK. Cross-OSGB / cross-firma / IDOR / role spoof kapalı.

### AD5. Uzman/Hekim Scope (Atamalar foundation)

`atamalar` tablosu henüz yok (Faz 4). Bu promptta uzman/hekim firma-bazlı değil **OSGB seviyesinde** scope edilir (`osgb_id = auth_osgb_id()`). Firmanın belirli uzman/hekime atanması Faz 4 Atamalar ile sıkılaştırılacak; evrak erişimi o fazda atama scope'una bağlanır.

### AD6. Storage

Özel `evraklar` bucket (private, public=false, 15MB limit). Dosyalar public URL OLMAZ. Yükleme edge function (service role) ile, storage path SUNUCU tarafında üretilir (`{osgb}/{ownerType}/{ownerId}/{uuid}.{ext}`) — frontend storage_path SPOOF edemez. İndirme `createSignedUrl` (edge function scope doğrulaması sonrası). MIME + boyut doğrulaması sunucu tarafında.

### AD7. Edge Function `evrak`

Aksiyonlar: `upload` (base64 dosya + metadata, scope doğrula, path üret, storage'a yaz, evraklar satırı ekle, audit), `url` (imzalı URL, scope doğrula), `archive` (status=archived + audit), `update` (title/description/date/valid_*/status + audit). Auth → profil → rol/scope → OSGB erişim penceresi → firma/personel/requirement kapsam doğrulaması. `owner_type`/`firma_id`/`personel_id`/`requirement_id`/`uploaded_by`/`osgb_id` frontend'e güvenilmez.

### AD8. Audit

`DOCUMENT_UPLOADED` / `DOCUMENT_UPDATED` / `DOCUMENT_ARCHIVED` (edge function, gerçek user_id/role/osgb_id) → `system_logs`. Frontend user_id/role/osgb_id spoof edemez.

### AD9. Frontend Servis

`src/lib/evrakService.ts` — tipler + `fetchEvraklarPage` (RLS'li sunucu-tarafı listeleme: search/filter/sort/pagination, SELECT * yok) + `uploadEvrak` / `getEvrakUrl` / `archiveEvrak` / `updateEvrak` (edge function) + `fetchEvrakTurleri` / `fetchFirmaGereksinimleri` + Türkçe etiketler. Mevzuat oranı/süresi/formülü İÇERMEZ.

### AD10. Durum / Kalan

- Referans/veri tabloları BOŞ (uydurma veri yok); evrak türleri doğrulanmış ihtiyaçlarla sonraki promptlarda doldurulur.
- `gereksinim-hesapla` artık `firma_gereksinimleri`'ne de upsert eder (snapshot tarihsel kalır) → evrak `requirement_id` ile stabil gereksinime bağlanır.
- Otomatik geçerlilik/bitiş/yaklaşan süre hesabı, gelişmiş evrak UI ve tüm mevzuat evraklarının tanımlanması Faz 3 sonraki promptlarında yapılır.

---

## AE. FAZ 3 / PROMPT 4 — EVRAK + GEREKSİNİM ENTEGRASYONU / FULL QA / HARDENING

> Faz 3 altyapısının gerçek kod/DB üzerinden denetimi ve kök neden düzeltmesi. Yeni mimari İCAT EDİLMEZ; mevcut sistem güvenli şekilde düzeltilir/genişletilir. Mevzuat uydurma YOK. KİLİTLİ AYRIM korunur: **kural ≠ firma_gereksinimi ≠ snapshot ≠ evrak ≠ sahip ≠ yükleyen**.

### AE1. Kök Neden Düzeltmeleri (bulunan gerçek bug'lar)

1. **Firma rolü evrak yükleyemiyordu** — `evrak` edge function'ında `firma.osgb_id !== caller.osgb_id` karşılaştırması, firma profilinin `osgb_id` değeri NULL olduğu için hatalı `CROSS_OSGB`/`REQUIREMENT_CROSS_OSGB` reddi üretiyordu. Düzeltme: firma rolü, admin gibi bu OSGB karşılaştırmasından muaf tutuldu (firma zaten `caller.firma_id` ile kendi firmasına kilitli; firma-level kontrol `REQUIREMENT_FIRMA_MISMATCH` ile korunuyor).
2. **`current_quantity` sabit 0'dı** — `gereksinim-hesapla` artık geçerli evrakları TEK aggregate sorguyla (N+1 yok) sayıyor: `requirement_id`'ye bağlı `status IN ('valid','expiring')` evraklar `current_quantity` olur; `remaining = required - current`; `status = met/missing/verification_required`. pending/verification_required sayılmaz (doğrulanmamış), archived/rejected/expired sayılmaz. Bu bir SİSTEM DURUM KURALIDIR — mevzuat oranı/süresi DEĞİLDİR.

### AE2. UI Entegrasyonu (Firma/Uzman/Hekim Evraklar gerçek veriye bağlandı)

- `src/components/feature/evrak/EvrakList.tsx` — ortak liste motoru (Shared `Table` + `FilterBar` + `Pagination` + `SharedListCard` + `Loading`/`EmptyState`/`ErrorState`). Search + durum + sahiplik filtresi. Satır tıklaması `EvrakDetailModal` (Shared `Modal`, variant `detail`).
- `EvrakDetailModal.tsx` — belge bilgileri, sahip, tür, ilgili yükümlülük, geçerlilik, durum, dosya indirme (imzalı URL) ve arşivleme (confirm).
- `EvrakUploadModal.tsx` — role-göre owner seçimi (firma sabit / uzman firma+personel / hekim personel), firma/personel picker (RLS scope'lu, SELECT * yok), evrak türü, ilgili yükümlülük, tarihler, dosya (15MB client-side ön kontrol; MIME/size sunucu tarafında).
- `src/pages/firma/evraklar` / `uzman/evraklar` / `hekim/saglik-evraklari` → `EvrakList` kullanır (placeholder kaldırıldı).
- `src/lib/evrakService.ts` — `fetchFirmaOptions`/`fetchPersonelOptions` picker helper'ları eklendi (explicit kolonlar).

### AE3. Doğrulanan Sağlam Katmanlar (değiştirilmedi)

- `evraklar.requirement_id` → `firma_gereksinimleri.id` FK (snapshot'a DEĞİL). `UNIQUE(firma_id, rule_id)` recalc'ta duplicate üretmez; id stabil kalır, evrak bağlantısı kopmaz.
- 4 trigger (`evrak_validate`/`evrak_lock_scope`/`evrak_prevent_delete`/`evraklar_updated_at`) aktif; RLS 7 tabloda aktif, `USING(true)` yalnızca read-only `evrak_turleri` kataloğunda (güvenli).
- `evraklar` storage bucket private (public=false, 15MB); path sunucu tarafında üretilir.

### AE4. Kalan (sonraki promptlar)

- Otomatik geçerlilik/bitiş/yaklaşan süre hesabı (Faz 3 sonraki prompt), uzman/hekim firma-bazlı atama sıkılaştırması (Faz 4 Atamalar), doğrulanmış mevzuat evraklarının tanımlanması.

---

## AF. FAZ 3 / SON PROMPT — FINALIZATION / HARDENING / PRODUCTION LOCK

> Faz 3'ün kapanış denetimi. Yeni mimari İCAT EDİLMEZ; mevcut sistem gerçek kod/DB/Storage/RLS/UI üzerinden denetlenip kök nedenler kapatılır. Atamalar (Faz 4) OLUŞTURULMAZ. Mevzuat uydurma YOK. KİLİTLİ AYRIM: **kural ≠ firma_gereksinimi ≠ snapshot ≠ evrak ≠ sahip ≠ yükleyen**.

### AF1. Bu Denetimde Kapatılan Kök Nedenler (4 güvenlik/tutarlılık deliği)

1. **RLS firma scope deliği** — `evraklar_select` politikasının firma kolunda `owner_type = 'firma'` kontrolü yoktu. Firma kullanıcısı, `firma_id`'si eşleşen **kişisel/sağlık** evraklarını da görebilirdi (personel evrakı ileride `firma_id` ilişkisel kapsamı taşıyabilir). Düzeltme: firma kolu `(auth_role()='firma') AND (owner_type='firma') AND (firma_id=auth_firma_id())` olarak sıkılaştırıldı — firma artık yalnızca kendi firma evraklarını görür, kişisel/sağlık verisine erişemez.

2. **OSGB erişim penceresi tüm işlemlerde değildi** — `url`/`archive`/`update` aksiyonları `is_active + deleted_at + erisim_baslangic + erisim_bitis` kontrolü yapmıyordu (yalnızca `upload` yapıyordu); firma kullanıcısı hiç kontrol edilmiyordu. Düzeltme: `assertOsgbAccess` merkezileştirildi (firma rolü OSGB'sini kendi firmasından türetir) ve 4 aksiyonun tamamında uygulanır.

3. **Status spoof** — `update` aksiyonu frontend'den gelen `status`'u sorgusuz kabul ediyordu; firma/uzman/hekim belgeyi `valid` yapıp `current_quantity`'yi şişirebilirdi. Düzeltme: status yalnızca `admin`/`osgb_admin` (doğrulama yetkisi) tarafından değiştirilebilir; diğer roller `STATUS_FORBIDDEN` alır. Frontend zaten status göndermiyor — bu savunma katmanı.

4. **Stale requirement** — evrak arşivlenince/durum değişince `firma_gereksinimleri.current_quantity/remaining_quantity/status` güncellenmiyordu (manuel recalc şart). Düzeltme: `recomputeRequirement` yardımcısı, arşivleme ve status-değişimi sonrası ilgili gereksinimi gerçek veriden (`valid`+`expiring` evrak sayımı) yeniden hesaplar ve `REQUIREMENT_RECALCULATED` audit'i yazar.

### AF2. Ek Sıkılaştırma

- `handleUpdate` boş başlığı `null` yazıp NOT NULL ihlali üretmiyor (`TITLE_REQUIRED` döner).
- `fetchEvrak` artık `requirement_id` seçer (recompute bağlantısı için).
- `evrakService.friendlyEvrakError` → `STATUS_FORBIDDEN` Türkçe mesajı eklendi.

### AF3. Doğrulanan Sağlam Katmanlar (değiştirilmedi)

- `evraklar.requirement_id` → `firma_gereksinimleri.id` FK (snapshot'a DEĞİL). `UNIQUE(firma_id, rule_id)`.
- 4 trigger (`evrak_validate`/`evrak_lock_scope`/`evrak_prevent_delete`/`evraklar_updated_at`) aktif; CHECK constraint'ler (owner_type/status) DB seviyesinde.
- `evraklar` storage bucket private (public=false); storage.objects üzerinde HİÇBİR policy yok → anon/authenticated erişim tamamen kapalı, yalnızca edge function (service role) dokunur. İmzalı URL yalnızca scope doğrulaması sonrası.
- Mevzuat uydurma YOK; tüm referans/veri tabloları boş. Geçerlilik süresi/oranı hardcode YOK.

### AF4. Bilinçli Kapsam Dışı (istendiği gibi)

- **Otomatik geçerlilik motoru** (`expiring`/`expired`'ın `valid_until` + eşikten merkezi hesaplanması) — eşiğin mevzuat gibi hardcode edilmemesi gerektiğinden, merkezi configurable bir yapı olmadan üretilmedi. `valid_until` kullanıcının girdiği "belgeye ait açık tarih" olarak kalır (prompt 9 ile tutarlı).
- **Uzman/Hekim firma-bazlı atama sıkılaştırması** — `atamalar` tablosu Faz 4'te; uzman/hekim Faz 3'te OSGB seviyesinde scope (AD5 ile tutarlı).
- **Sağlık verisi domain genişletme** — sağlık evrakları genel evraklarla aynı altyapıda ayrı owner_type ile korunur; firma→kişisel erişimi AF1/1 ile kapatıldı, kalan atama bazlı sıkılaştırma Faz 4'te.

### AF5. Faz 3 SONUÇ

Faz 3 production-ready ve kilitlenebilir durumdadır. Kural/gereksinim/snapshot/evrak/sahip/yükleyen ayrımı korunur; RLS + trigger + storage + edge function scope + audit + UI entegrasyonu bütünleşik çalışır.

---

## AG. FAZ 4 / PROMPT 1 — ATAMALAR (VERİ MODELİ + BACKEND + RLS + AUTHORIZATION FOUNDATION)

> Faz 4'ün temelidir: Uzman/Hekim → Firma operasyonel yetkilendirmesi. Bu promptta yalnızca veri modeli, backend RPC, RLS, scope/security, tarih/durum kuralları, duplicate/overlap kontrolü, audit ve Faz 5 (ziyaret) ile Faz 3 (evrak) için authorization foundation kurulur. **BÜYÜK UI Prompt 2'de; geofence/ziyaret/envanter/zimmet/mesajlaşma OLUŞTURULMAZ.**

### AG1. Kavram Kilidi (bozulmaz)

Atama = mevcut aktif İSG Uzmanı/İşyeri Hekimi personelinin belirli bir firmaya hangi tarih aralığında operasyonel olarak yetkili olduğunu belirler. **Atama ≠ hesap oluşturma ≠ personel kaydı ≠ davet ≠ Auth hesabı.** Firma çalışanı/teknisyen/muhasebeci/admin/OSGB yöneticisi ATANAMAZ. Kabul edilen roller: `uzman` / `hekim` (mevcut `profiles.role` değerleri).

### AG2. Tablo `public.atamalar` (tek kaynak, duplicate yok)

Kolonlar: `id`, `osgb_id` (FK→osgb), `firma_id` (FK→firmalar), `personel_id` (FK→personeller), `atama_turu` (CHECK: uzman/hekim — profiles.role ile birebir), `baslangic_tarihi` (date, zorunlu), `bitis_tarihi` (date, nullable = açık uçlu), `is_active` (default true), `created_by` (trigger'da `auth.uid()`), `notes` (plain text), `created_at`/`updated_at`. CHECK: `bitis_tarihi >= baslangic_tarihi`.

Indexler: `osgb_id`, `firma_id`, `personel_id`, composite `(personel_id, firma_id, atama_turu, is_active)`, `(baslangic_tarihi, bitis_tarihi)`.

### AG3. Trigger'lar (DB seviyesi invariant, RPC'den bağımsız savunma)

- `atama_validate` (BEFORE INSERT/UPDATE): `created_by := auth.uid()` (INSERT'te, spoof engeli); `atama_turu` enum; tarih sırası; **osgb tutarlılığı** — `firma.osgb_id` ve `personel.osgb_id` `NEW.osgb_id` ile eşleşmeli (invariant 1/2/8 → `CROSS_OSGB`).
- `atama_lock_scope` (BEFORE UPDATE): `osgb_id`/`firma_id`/`personel_id`/`atama_turu`/`created_by` değiştirilemez (IDOR/role spoof engeli).
- `atama_prevent_delete` (BEFORE DELETE): fiziksel silme yok (`ATAMA_SILINEMEZ`).
- `atama_set_updated_at` (mevcut `set_updated_at()`).

### AG4. RLS (USING(true) YOK)

- **SELECT:** admin(tümü) / osgb_admin(kendi osgb_id) / uzman+hekim(kendi atamaları, `personel.profile_id = auth.uid()`) / firma(kendi firma_id).
- **INSERT/UPDATE:** yalnızca admin ve osgb_admin (kendi osgb_id, WITH CHECK). Firma/uzman/hekim mutation YAPAMAZ.
- **DELETE:** hiçbiri (fiziksel silme bloklu; pasifleştirme soft-state).

### AG5. Backend RPC (SECURITY DEFINER, `search_path` public)

Atomik, transaction içi, concurrency-safe (advisory lock):

- **`atama_create(firma_id, personel_id, atama_turu, baslangic, bitis, notes)`** — yetki (admin/osgb_admin) → firma (aktif, aynı OSGB) → personel (aktif, profile'lı, aynı OSGB) → `profiles.role` = `atama_turu` (role spoof engeli) → **overlap kontrolü** (`pg_advisory_xact_lock` + çakışan aktif dönem) → INSERT → audit `ASSIGNMENT_CREATED` → satır döner.
- **`atama_update(atama_id, baslangic, bitis, notes)`** — kimlik alanları değişmez (trigger kilidi); tarih/not güncellenir, overlap self-hariç yeniden kontrol edilir → audit `ASSIGNMENT_UPDATED`.
- **`atama_deactivate(atama_id)`** — `is_active=false` (soft), audit `ASSIGNMENT_DEACTIVATED`.

Hata kodları: `UNAUTHORIZED_ASSIGNMENT` / `CROSS_OSGB` / `FIRMA_NOT_FOUND` / `INACTIVE_FIRM` / `PERSONEL_NOT_FOUND` / `INACTIVE_PERSONEL` / `PERSONEL_PROFILE_MISSING` / `PROFILE_NOT_FOUND` / `INVALID_ASSIGNMENT_ROLE` / `INVALID_ATAMA_TURU` / `INVALID_DATE_RANGE` / `ASSIGNMENT_OVERLAP` / `ASSIGNMENT_NOT_FOUND` / `ATAMA_SILINEMEZ`.

### AG6. Authorization Helper `has_active_firma_assignment(user_id, firma_id)`

SECURITY DEFINER boolean helper — tüm zinciri kontrol eder: `personel.profile_id = user_id` + `atama.is_active` + `baslangic <= bugün <= bitis(NULL=açık)` + `personel.is_active` + `firma.is_active/deleted_at` + `osgb.is_active/deleted_at/erisim_baslangic/erisim_bitis`. Güvenlik: anonim `false`; non-admin caller yalnızca KENDİ user_id'sini sorgulayabilir (cross-tenant bilgi sızıntısı yok). Faz 5 ziyaret scope'u ve Faz 3 evrak scope'u bu helper'a bağlanır.

### AG7. Frontend Servis `src/lib/assignmentService.ts`

Tipler (`AtamaTuru`, `AtamaRow`/`AtamaData`, `mapAtamaRow`), `fetchAtamalar` (RLS'li, explicit kolonlar), `createAtama`/`updateAtama`/`deactivateAtama` (RPC invoke), `hasActiveFirmaAssignment` (helper), `friendlyAtamaError` (Türkçe hata eşlemesi). Mevzuat oranı/süresi/kısıtı İÇERMEZ.

### AG8. Durum / Kalan

- Referans/veri tabloları BOŞ (uydurma veri yok). Atama türü yalnızca `uzman`/`hekim`; "firma başına X uzman" gibi mevzuat iş kuralı ÜRETİLMEZ.
- Atama listeleme UI + detay + filtreler → **Faz 4 / Prompt 2** (mevcut `osgb/atamalar` sayfası `PanelPlaceholder`).
- Faz 5 (ziyaret) scope'u `atama.id` + `has_active_firma_assignment` üzerine kurulacak; Faz 3 evrak erişimi atama scope'una bağlanacak.

---

## AH. FAZ 5 / PROMPT 1 — PROGRAM MOTORU + ZİYARET PLANLAMA BACKEND TEMELİ

> Faz 5'in temelidir: Tam zamanlı ve gezici (süre bazlı) çalışma programı modelleri, haftalık tekrar + istisna, aylık gezici süre, ziyaret planı ve gerçek ziyaret için planned/actual ayrımı. **UI Prompt 2'de; GPS/geofence/check-in/check-out/24:00 job'ı Faz 6'dadır.** KİLİTLİ ZİNCİR: **OSGB → Firma → Personel → Atama → Program → Ziyaret Planı → Gerçek Ziyaret.** Atama authorization kaynağı, program planlama kaynağı, ziyaret planı belirli bir ziyaretin planlı kaydı, gerçek ziyaret operasyonel gerçekleşme kaydıdır. Ziyaret planı firma yetkisi KAZANDIRMAZ.

### AH1. Kavram Kilidi (bozulmaz)

- **İki ayrı program modeli:** `tam_zamanli` (haftalık tekrar) ve `gezici` (firma başına aylık süre). Birbirine karıştırılmaz; model gerçek veriden (`calisma_programlari.program_turu`) belirlenir, frontend state'inden DEĞİL.
- **Program tanımı ≠ gerçekleşen gün.** Haftalık tekrar, client'ta sahte kayıt olarak tutulmaz; program tanımı + istisna ayrıdır.
- **Ziyaret planı ≠ gerçek ziyaret.** Tek `ziyaretler` satırı hem planlanan hem gerçekleşen alanları AYRI taşır (`planlanan_*` vs `actual_*`).

### AH2. Yeni Tablolar (tek kaynak, duplicate yok)

1. **`public.calisma_programlari`** — program başlığı: `osgb_id`, `personel_id`, `program_turu` (CHECK: tam_zamanli/gezici), `baslangic_tarihi`, `bitis_tarihi` (nullable=açık), `is_active`, `notlar`, `created_by`. CHECK `bitis >= baslangic`.
2. **`public.calisma_program_gunleri`** — tam zamanlı haftalık şablon: `program_id`, `gun` (0=Pazar..6=Cumartesi), `baslangic_saat`/`bitis_saat` (izin'de null), `izin`. CHECK: izin→saatler null; değilse `bitis > baslangic`. `UNIQUE(program_id, gun)`.
3. **`public.calisma_program_istisnalari`** — tek haftalık izin günü değişikliği: `program_id`, `hafta_baslangic` (date), `gun`, `izin`, `aciklama`, `created_by`. `UNIQUE(program_id, hafta_baslangic, gun)` (race-safe upsert).
4. **`public.gezici_sure_planlari`** — gezici firma bazlı AYLIK süre: `osgb_id`, `personel_id`, `firma_id`, `atama_id`, `donem` (ay başı date), `planlanan_sure_dakika`, `gerceklesen_sure_dakika` (Faz 6 gerçek ziyaretten beslenir). `UNIQUE(personel_id, firma_id, donem)`; CHECK `donem = ay başı`. Fazla/eksik sonraki aya DEVREZ.
5. **`public.ziyaretler`** — plan + gerçekleşme: `osgb_id`, `firma_id`, `atama_id`, `personel_id`, `program_id`/`program_turu` (nullable), `ziyaret_turu`, `planlanan_baslangic`/`planlanan_bitis`, `durum` (CHECK: planlandi/basladi/tamamlandi/iptal_edildi), `notlar`, `actual_start`/`actual_end`, `start/end_latitude`/`longitude` (Faz 6 GPS), `auto_closed`, `created_by`. CHECK `bitis > baslangic`, `actual_end >= actual_start`.

### AH3. Trigger'lar (DB invariant, RPC'den bağımsız savunma)

- `calisma_program_validate` — INSERT'te `created_by := auth.uid()`; `personel.osgb_id = osgb_id` (CROSS_OSGB).
- `calisma_program_lock_scope` — osgb_id/personel_id/program_turu/created_by değiştirilemez.
- `calisma_program_istisna_validate` — `created_by` + program OSGB scope (cross-OSGB).
- `gezici_sure_validate` — osgb/firma/personel/atama tutarlılığı (CROSS_OSGB + ATAMA_FIRMA/PERSONEL_MISMATCH).
- `gezici_sure_lock_scope` — osgb/personel/firma/atama/donem/created_by kilitli (yalnız sure alanları değişir).
- `ziyaret_validate` — osgb/firma/personel/atama tutarlılığı; program↔personel/tür tutarlılığı (PROGRAM_PERSONEL_MISMATCH, PROGRAM_TURU_MISMATCH).
- `ziyaret_lock_scope` — kimlik alanları + program_id değiştirilemez (IDOR engeli).
- `ziyaret_prevent_delete` — fiziksel silme yok (`ZIYARET_SILINEMEZ`).

### AH4. RLS (USING(true) YOK)

- `calisma_programlari`/`gunleri`/`istisnalari`: SELECT admin(tümü) / osgb_admin(kendi osgb) / uzman+hekim(kendi personel). INSERT/UPDATE yalnızca admin + osgb_admin (kendi osgb). Firma program GÖREMEZ.
- `gezici_sure_planlari`: SELECT admin / osgb_admin / uzman+hekim(kendi personel) / firma(kendi firma). Yazma admin + osgb_admin.
- `ziyaretler`: SELECT admin / osgb_admin / firma(kendi firma) / uzman+hekim(kendi personel). INSERT/UPDATE yalnızca admin + osgb_admin. DELETE hiçbiri (prevent_delete trigger).

### AH5. RPC'ler (SECURITY DEFINER, search_path public, concurrency-safe)

- `program_create/update/deactivate`, `program_istisna_upsert/delete` — OSGB admin yetkisi + personel aktif + uzman/hekim türü + OSGB erişim penceresi + cross-OSGB.
- `gezici_sure_upsert` — atama aktif + firma/personel aktif + OSGB erişimi; `ON CONFLICT (personel,firma,donem)`.
- `ziyaret_create/update/cancel` — atama aktif + OSGB erişimi + firma/personel aktif + atama tarih geçerliliği + **overlap** (`pg_advisory_xact_lock` + çakışan `planlandi/basladi` dönem) + program↔personel tutarlılığı.
- `program_list` / `ziyaret_list` — server-side search/filter/sort/pagination (N+1 yok).

### AH6. Authorization Helper'lar

- `auth_personel_id()` — auth.uid() → personel.id (uzman/hekim kapsamı).
- `osgb_erisim_acik(osgb_id)` — merkezi OSGB erişim kuralı tek yerden: `is_active AND deleted_at IS NULL AND (erisim_baslangic IS NULL OR <= now()) AND (erisim_bitis IS NULL OR > now())`.

### AH7. Audit

`system_logs` → `PROGRAM_CREATED/UPDATED/DEACTIVATED`, `PROGRAM_ISTISNA_UPSERTED/DELETED`, `GEZICI_SURE_PLANLANDI`, `ZIYARET_PLANLANDI/UPDATED/IPTAL` (gerçek user_id/role/osgb_id, `auth.uid()`). Password/token/secret loglanmaz.

### AH8. Durum / Kalan

- Referans/veri tabloları BOŞ (uydurma veri yok). `ziyaret_turu`/GPS alanları/`auto_closed` Faz 6'da doldurulacak nullable alanlardır — sahte GPS/check-in ÜRETİLMEZ.
- UI (program + ziyaret listeleme/planlama + uzman/hekim Ziyaretler) → **Faz 5 / Prompt 2**.
- GPS/geofence/check-in/check-out/24:00 otomatik kapanış job'ı + gerçek süre/gün kartı/gezici aylık hesaplama → **Faz 6**.

---

## AI. FAZ 6 / PROMPT 1 — GERÇEK ZİYARET + GPS/GEOFENCE + CHECK-IN/OUT BACKEND

> Faz 5 ziyaret planlarını gerçek saha ziyaretine dönüştüren backend + veri modeli temeli. Mevcut `ziyaretler` tablosu GENİŞLETİLDİ (yeni tablo YOK).

### AI1. Veri Modeli (mevcut `ziyaretler` genişletildi)

Eklenen kolonlar: `actual_duration_minutes`, `start/end_accuracy_meters`, `start/end_distance_meters`, `start/end_location_verified`, `started_by`, `finished_by`, `start_note`, `finish_note`. Mevcut `actual_start/end`, `start/end_latitude/longitude`, `auto_closed` aynen kullanıldı. Firma konumu mevcut `firmalar.geofence_radius_meters`.

### AI2. Backend RPC'ler

- `haversine_meters` — güvenilir koordinat mesafesi (IMMUTABLE, STRICT).
- `ziyaret_baslat(ziyaret_id, lat, lng, accuracy, start_note)` — 17 adımlı zincir: auth→role→OSGB→firma→personel→atama→durum→GPS→doğruluk eşiği→firma koordinatı→mesafe→geofence→atomik `actual_start=now()`→GPS kaydı→audit. Radius dışı `GEOFENCE_DISINDA`.
- `ziyaret_bitir(ziyaret_id, finish_note, lat, lng, accuracy)` — aynı zincir + geofence + `actual_duration_minutes` sunucuda + gezici aylık dönem yazımı.
- `ziyaret_auto_close_due` — `basladi` durumundaki, yerel 24:00 sınırını geçmiş ziyaretleri kapatır (`auto_closed=true`).
- `ziyaret_list` — yeni alanları döndürür (RETURNS json).

### AI3. 24:00 Otomatik Kapanış

`pg_cron` + `ziyaret-auto-close` job (`*/5 * * * *`) — browser açık olmasa da çalışır. Client timer YOK.

### AI4. Güvenlik

Eski GPS'siz overload'lar `GPS_REQUIRED` ile etkisizleştirildi. Radius frontend'den override edilemez. IDOR/role-spoof/scope-spoof backend'de. Çift başlat/bitir atomik `WHERE durum=...`. Doğruluk eşiği merkezi (`system_settings.ziyaret_gps_min_accuracy_meters`=150).

---

## AJ. FAZ 6 / PROMPT 2 — GERÇEK ZİYARET UI + UZMAN/HEKİM SAHA OPERASYONU

> Faz 6 Prompt 1 backend'ini mevcut UI'a bağlayan katman. Yeni auth/role/atama/modal/listing motoru YOK; SharedUICore kullanılır.

### AJ1. Uzman/Hekim Ziyaretler (shared `ZiyaretOperasyonList`)

Başlat → gerçek geolocation → backend geofence → `actual_start` (sunucu). Bitir → konum → `actual_end` + gerçek süre. Detay modalda plan/gerçekleşme/konum doğrulama/not. Konum izni reddi + firma dışı mesajları friendly.

### AJ2. Yeni Backend RPC'ler

- `ziyaret_not_guncelle(ziyaret_id, not)` — uzman/hekim kendi `basladi`/`tamamlandi` ziyaretine `finish_note` yazar (devam eden not + 24:00 auto-close açıklaması). Yetki `personel_id = auth_personel_id()`.
- `gun_kartlari(personel_id, baslangic, bitis)` — osgb_admin scope'lu; program + haftalık istisna + ziyaret verisini (firma unvan + Türkiye tarih anahtarı) döndürür (N+1 yok).

### AJ3. Gün Kartı (`GunKartiTab`)

OSGB personel detayına "Gün Kartı" sekmesi: "Son 7 Gün" + "Geçmiş Aylar". `gunKartiService.buildGunKartlari` program + istisna (Pazartesi hafta başı) + gerçek ziyaretten; plan/gerçek süre/fark/geç giriş/erken çıkış/gelmedi hesaplanır (gerçek DB timestamplerinden, uydurma YOK). Personel işe giriş tarihinden önce kart üretilmez.

### AJ4. OSGB Ziyaretler + Detail

`ZiyaretDetailModal`'a "Plan / Gerçek Özeti" (planlanan/gerçek saat + süre + fark). Uzman/hekim detail'ına geçen süre (görsel sayaç) + auto-close etiketi + açıklama girişi.

### AJ5. Kalan (Faz 6 sonraki / Faz 7)

Gelişmiş saha operasyon UI, gün kartına gezici model aylık özet entegrasyonu, gelişmiş geçmiş/raporlama → sonraki promptlarda. Canlı uçtan-uca test (gerçek firma koordinatı + aktif profil + cihaz GPS'i) veri olmadan doğrulanamadı.

---

## AK. ZİYARET SİSTEMİ — FAZ 4: GERÇEK OCCURRENCE ALTYAPISI

> PROGRAM → PLAN → OCCURRENCE ayrımının kalıcı kilitlenmesi. Bu faz `ziyaretler` tablosunu ve idempotent occurrence üretimini kurar. Gerçek operasyon (start/finish/GPS/check-in) HENÜZ YOK — yalnızca `planlandi` durumundaki occurrence kayıtları üretilir.

### AK1. Kavram Kilidi (bozulmaz)

- **Program** = tekrar eden çalışma düzeni (`calisma_programlari` + `calisma_program_gunleri`).
- **Plan** = OSGB'nin oluşturduğu çalışma/ziyaret planı (program satırı).
- **Occurrence** = belirli tarihte gerçekleşmesi planlanan BAĞIMSIZ ziyaret kaydı (`ziyaretler`).
- Her occurrence kendi UUID'sine sahiptir; başka occurrence'ın "devamı" DEĞİLDİR. Bir gün gerçekleşmezse diğer günler etkilenmez.

### AK2. Tablo `public.ziyaretler` (occurrence, tek kaynak)

Kolonlar: `id`, `osgb_id`, `firma_id`, `personel_id`, `atama_id`, `plan_id` (FK YOK — geçmiş korunur), `plan_turu` (CHECK: tam_zamanli/gezici), `ziyaret_tarihi`, `donem` (gezici ay), `planlanan_baslangic/bitis/sure_dakika` (SNAPSHOT), `durum` (CHECK: planlandi/devam_ediyor/gerceklesti/gerceklesmedi/otomatik_kapatildi/iptal, default planlandi), `firma_latitude/longitude/geofence_radius_meters` (konum snapshot), `actual_start/actual_end/actual_duration_minutes/auto_closed/notlar` (Faz 6, NULL bırakılır), `created_by`, zaman damgaları.

- **Snapshot ilkesi:** occurrence oluşturulurken planlanan değerler kendi üzerine yazılır; program sonradan değişse bile geçmiş occurrence DEĞİŞMEZ.
- **Dedup:** `UNIQUE (plan_id, ziyaret_tarihi) WHERE plan_turu='tam_zamanli'` + `UNIQUE (plan_id, firma_id, donem) WHERE plan_turu='gezici'` (partial unique index) → race condition altında bile duplicate yok.
- **FK'ler:** osgb/firma/personel/atama FK'lı; `plan_id` bilinçli FK'sız (plan silinince occurrence bozulmaz).

### AK3. Trigger'lar (DB invariant)

- `ziyaret_validate` (BEFORE INSERT/UPDATE, SECURITY DEFINER): firma/personel/atama ↔ osgb tutarlılığı (CROSS_OSGB_FIRMA/PERSONEL/ATAMA, ATAMA_PERSONEL/FIRMA_MISMATCH).
- `ziyaret_lock_scope` (BEFORE UPDATE): osgb/firma/personel/plan_id/plan_turu değiştirilemez (IDOR engeli).
- `ziyaret_prevent_delete` (BEFORE DELETE): fiziksel silme yok (`ZIYARET_SILINEMEZ`).
- `ziyaret_set_updated_at`.

### AK4. RLS (read-only client, yazma yalnızca edge function)

SELECT: admin / osgb_admin(kendi osgb) / firma(kendi firma) / uzman+hekim(kendi personel). INSERT/UPDATE/DELETE istemciye KAPALI — yazma yalnızca service role edge function. `USING(true)` YOK.

### AK5. Backend (mevcut `ziyaret-planlama` edge function genişletildi)

- **`generate`** aksiyonu: idempotent occurrence üretimi. Tam zamanlı planın çalışma günlerinden, `GENERATION_FORWARD_DAYS=60` kontrollü pencereyle (açık uçlu planda sonsuz gelecek INSERT EDİLMEZ). Personel/firma/atama aktiflik + işe giriş/çıkış + atama tarih aralığı + plan bitiş + istisna (`calisma_program_istisnalari`, hafta_baslangic eşleşmeli) dikkate alınır. Zaten var olan tarihler atlanır (snapshot bozulmaz); 23505 race güvenle yok sayılır.
- **`listOccurrences`** aksiyonu: server-side listeleme (program/personel/tarih filtresi + pagination).
- `handleCreate` sonrası tam zamanlı plan için occurrence otomatik üretilir; `handleDeactivate` gelecekteki `planlandi` occurrence'ları `iptal` yapar (geçmiş korunur).
- Audit: `PROGRAM_*` olayları `system_logs`'a yazılır.

### AK6. Frontend Servis + UI

- `planlamaService.ts`: `ZiyaretOccurrence` tipi, `ZIYARET_DURUM_LABEL`, `generateOccurrences`, `fetchOccurrences`, `timeToMinutes`.
- `ZiyaretDetailModal`: detay açılırken occurrence'ları çeker; tam zamanlı aktif planda occurrence yoksa idempotent backfill yapar.
- `ZiyaretlerTab`: "Bu Hafta" ve "Geçmiş" görünümleri artık gerçek occurrence kayıtlarını (`planlandi`) gösterir; izin günü/plan-yok ayrımı korunur.

### AK7. Durum / Kalan

- Gezici planlar için per-day occurrence ÜRETİLMEZ — aylık firma süreleri `gezici_sure_planlari`'nda zaten firma-bazlı ayrık tutulur (aylık snapshot doğal olarak korunur). `ziyaretler.plan_turu='gezici'` + `donem` alanları gelecek gerçek ziyaret kayıtları için hazırdır.
- Gerçek operasyon (start/finish/GPS/geofence/check-in/24:00 auto-close) + aylık bakiye hesabı → sonraki faz.

---

## AL. ZİYARET SİSTEMİ — FAZ 5: PROGRAM VERSİYONLAMA + GELECEK TARİHLİ PROGRAM DEĞİŞİKLİĞİ

> Faz 4'te kilitlenen PROGRAM → PLAN → OCCURRENCE ayrımının üzerine gerçek program versiyonlama sistemi. KİLİTLİ KURAL: **GEÇMİŞ ASLA DEĞİŞMEZ** — program değişikliği yalnızca belirli bir `effective_from` tarihinden itibaren geçerli olur; o tarihten önceki occurrence'ların planlanan değerleri (snapshot) kalıcı korunur.

### AL1. Kavram Kilidi (bozulmaz)

- **Program versiyonu** = haftalık çalışma düzeninin belirli bir tarih aralığındaki tanımı (`calisma_program_versiyonlari` + `calisma_program_versiyon_gunleri`).
- **Effective date** = yeni programın geçerli olmaya başladığı takvim günü (`effective_from`). `effective_from` tarihinin KENDİSİ yeni versiyona dahildir.
- **Snapshot** = occurrence oluşturulduğu andaki `planlanan_baslangic/bitis/sure_dakika` + `versiyon_id` (hangi versiyondan üretildiği). Program sonradan değişse bile geçmiş occurrence DEĞİŞMEZ.

### AL2. Yeni Tablolar (tek kaynak, duplicate yok)

1. **`public.calisma_program_versiyonlari`** — `id`, `program_id` (FK→calisma_programlari, NO ACTION), `effective_from` (date, NOT NULL), `effective_to` (date, nullable=açık uçlu), `notlar`, `created_by`, `created_at`. `UNIQUE(program_id, effective_from)` → aynı gün iki versiyon OLAMAZ.
2. **`public.calisma_program_versiyon_gunleri`** — `id`, `versiyon_id` (FK→calisma_program_versiyonlari, CASCADE), `gun` (0–6 CHECK), `izin`, `baslangic_saat`/`bitis_saat` (izin'de null), `created_at`.

### AL3. Trigger'lar (DB invariant)

- `calisma_program_versiyon_validate` (BEFORE INSERT/UPDATE): `effective_from >= program.baslangic_tarihi` (VERSION_BEFORE_START); `effective_to >= effective_from` (VERSION_INVALID_RANGE); **overlap engeli** — aynı program içinde başka bir versiyonun `[effective_from, effective_to]` aralığına düşen `effective_from` REDDEDİLİR (VERSION_OVERLAP).
- `calisma_program_versiyon_prevent_delete` (BEFORE DELETE): program versiyonu tarihsel korunur, silinemez (VERSION_SILINEMEZ).

### AL4. RLS (read-only client)

`calisma_program_versiyonlari` + `calisma_program_versiyon_gunleri`: SELECT admin / osgb_admin(kendi osgb, program→osgb_id) / uzman+hekim(kendi personel, program→personel_id) / firma(kendi firma, program→firma_id). INSERT/UPDATE/DELETE istemciye KAPALI — yazma yalnızca service role edge function. `USING(true)` YOK.

### AL5. Backend (edge function `ziyaret-planlama` genişletildi)

- **`createVersion`** aksiyonu (yalnızca OSGB Yönetici/admin, tam zamanlı, aktif plan): geçmiş `effective_from` BLOCK (EFFECTIVE_FROM_PAST, server zamanı); plan başlangıcından önce BLOCK; plan bitişinden sonra BLOCK; gün doğrulama. Önceki aktif versiyonun `effective_to`'su `effective_from - 1 gün`'e çekilir (server-side, timezone-safe); yeni versiyon INSERT. Audit `PROGRAM_VERSION_CREATED`.
- **`listVersions`** aksiyonu: program versiyonlarını günleriyle birlikte döndürür (effective_from ASC).
- **`handleCreate`** artık `calisma_program_gunleri` yerine V1 versiyonu oluşturur (versiyon + versiyon günleri).
- **`handleGet`** artık aktif versiyonun günlerini (`gunler`) + versiyon listesini (`versiyonlar`) döndürür.
- **`generateForProgram`** versiyon-tabanlı: her tarih için `effective_from <= tarih` olan EN SON versiyonu seçer; o versiyonun günlerinden occurrence üretir; istisna (hafta bazlı, program bazlı) birlikte değerlendirilir. `versiyon_id` occurrence'a yazılır. 60 günlük pencere + idempotent + 23505 race koruması KORUNUR.

### AL6. Migration (idempotent)

Mevcut tam zamanlı programların `calisma_program_gunleri` kayıtları `calisma_program_versiyonlari` + `calisma_program_versiyon_gunleri`'ne V1 olarak normalize edildi (`effective_from = baslangic_tarihi`, `NOT EXISTS` guard). `ziyaretler.versiyon_id` backfill edildi (`versiyon_id IS NULL` guard).

### AL7. FK Çelişkisi Netleştirildi (kritik)

Faz 4 raporundaki "FK" ifadesi doğrulanmıştır: **`ziyaretler.plan_id` üzerinde FK YOKTUR.** FK'lar yalnızca `osgb_id`/`firma_id`/`personel_id`/`atama_id` üzerindedir (hepsi `ON DELETE NO ACTION`), ayrıca `calisma_programlari` üzerinde `prevent_delete` trigger'ı vardır. Yani plan silinemez ve occurrence'lar plan silinse bile korunur — tarihsel koruma kararı doğru kurulmuştur, gereksiz FK EKLENMEDİ.

### AL8. Frontend Servis + UI

- `planlamaService.ts`: `ProgramVersiyon` tipi, `CreateVersionPayload`, `fetchProgramVersions` (listVersions), `createProgramVersion` (createVersion), yeni hata çevirileri.
- `PlanDetailModal`: "Program Geçmişi" bölümü (versiyon listesi + aktif/geçmiş durumu + gün/saat özeti) + "Programı Değiştir" formu (effective_from + haftalık günler + notlar). Mevcut Shared Modal içinde, yeni modal/drawer YOK.

### AL9. Durum / Kalan

- Gezici (süre bazlı) sistem versiyonlanmadı — aylık firma süreleri `gezici_sure_planlari`'nda zaten firma-bazlı + dönem bazlı ayrık tutulur (aylık snapshot doğal korunur); Tam Zamanlı versiyon modeli geziciye KOPYALANMADI.
- Gerçek operasyon (GPS/geofence/start/finish/actual/24:00 auto-close/gerçekleşmedi/erken çıkış/normal ziyaret notu) → sonraki faz. Faz 5 tamamlanıp test edilmeden gerçek saha operasyonuna geçilmez.

---

## AL-2. GLOBAL TYPOGRAPHY / UI FONT STANDARDI (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI tipografi hiyerarşisidir. Tüm 5 panel + tüm modüller TEK token sisteminden beslenir; sayfa bazlı rastgele `font-size`/`font-weight` ÜRETİLMEZ. Renk/logo/sidebar genişliği/kart/buton/tablo/badge yapısı DEĞİŞMEZ — yalnızca yazı hiyerarşisi standartlaştırılır.

### TY1. Tek Kaynak — Tipografi Token Katmanı (`src/index.css`)

Font AİLESİ DEĞİŞMEZ (`--font-body/heading/label` = Inter). Yalnızca seviye ölçüleri token'lanır (`--d-text-*`) ve rem cinsindendir → `--d-density-scale` kaldıracıyla birlikte ölçeklenir. Komponentler rastgele px yazmaz; `.isg-text-*` sınıflarını ya da token'ı tüketir.

| Token | Değer | Anlam |
|---|---|---|
| `--d-text-page-title` | 1.25rem (20px) | Sayfa başlığı (h1, 600) |
| `--d-text-section` | 1rem (16px) | Bölüm / panel / kart başlığı (600) |
| `--d-text-card-title` | 1rem (16px) | Kart başlığı (600) |
| `--d-text-body` | 0.875rem (14px) | Gövde metni (varsayılan, 400/500) |
| `--d-text-body-sm` | 0.8125rem (13px) | Küçük gövde / sayfa açıklaması |
| `--d-text-caption` | 0.75rem (12px) | Altyazı / yardımcı metin |
| `--d-text-label` | 0.8125rem (13px) | Form etiketi / üst-bilgi (500) |
| `--d-text-table-head` | 0.8125rem (13px) | Tablo başlığı (600, uppercase, letter-spacing) |
| `--d-text-table-body` | 0.875rem (14px) | Tablo gövdesi (400/500) |
| `--d-text-metric` | 1.25rem (20px) | İstatistik değeri (600) |

- `.isg-table-head-cell` ve `.isg-table-cell` artık `--d-text-table-head` / `--d-text-table-body`'yu tüketir (tek kaynak). `--d-head-fs` = 0.8125rem'e hizalandı.
- `.isg-form-label` = 0.8125rem (13px, 500).
- `Table.tsx` başlık hücresi `font-semibold` (600) — başlık 13px/600 ↔ gövde 14px/400-500 hiyerarşisi net.
- `PageHeader` açıklama satırı `isg-text-small` (13px).

### TY2. KURAL — Tablo Başlığı ≠ Tablo İçeriği

Tablo başlıkları ile içerik AYNI boyutta OLMAZ: **başlık bir kademe küçük (13px/600)**, gövde 14px/400-500. Başlık farkı boyuttan çok **font-weight + uppercase + letter-spacing** ile gösterilir. Bu kural SİSTEMDEKİ TÜM tablolara uygulanır (paylaşılan `Table` motoru üzerinden otomatik).

### TY3. Evraklar ekranı (özel dikkat)

Kategori ağacı hiyerarşisi düzeltildi (kök neden: `html` font-size `--d-density-scale` ile %75 ölçeklenirken alt kategoriye sabit `text-[13px]` yazılmıştı → ölçeklenmiyor ve üst kategoriden BÜYÜK görünüyordu):

| Öğe | Ölçü |
|---|---|
| ANA kategori | 14px / 500 (aktif 600) |
| ALT kategori | 13px / 400 (`text-[0.8125rem]`, ölçeklenir — ASLA üstten büyük olmaz) |
| Kategori sayacı | 12px / 500 |
| Bölüm başlığı ("Kategoriler") | 11px / 600 (uppercase) |
| Tablo başlığı | 13px / 600 |
| Tablo içeriği | 14px / 400-500 |
| Evrak adı | 14px / 500 |
| Evrak açıklaması | 12px / 400 |

Evraklar modülündeki (`EvrakBelgeModal`, `EvrakEkleModal` dahil) sabit `text-[11px]`/`text-[10px]`/`text-[13px]` değerleri ölçeklenen rem karşılıklarına (`text-[0.6875rem]` / `text-[0.625rem]` / `text-[0.8125rem]`) çevrildi.

### TY4. Değişmeyenler

Sidebar, navbar, kart yapısı, modal yapısı, font ailesi, spacing, padding, radius, renk paleti, buton boyutları, tablo yapısı, badge yapısı, logo/branding — DOKUNULMADI. Yalnızca yazı hiyerarşisi (font-size/weight) standartlaştırıldı.

---

## AM. ENVANTER MODÜLÜ — VERİ MODELİ + BACKEND + RLS (PROMPT 1)

> OSGB Yönetim Paneli Envanter modülünün production-ready veri altyapısı. Route: `/osgb-panel/envanter`. KİLİTLİ AYRIM: **ENVANTER ≠ ZİMMET**. Envanter = "varlık OSGB sisteminde mevcut"; Zimmet = "kime teslim/kabul/iade" (ayrı modül, bu promptta KURULMAZ). UI Prompt 2'de; bu prompt yalnızca veri modeli + backend + RLS + service altyapısı.

### AM1. Tablo `public.envanter` (tek kaynak, duplicate yok)

Kolonlar: `id` (uuid PK), `osgb_id` (FK→osgb), `envanter_turu` (CHECK: arac/bilgisayar/diger), `envanter_kodu`, `ad`, `aciklama`, `marka`, `model`, `seri_no`, `durum` (CHECK: aktif/pasif), `edinim_tarihi` (date), `edinim_bedeli` (numeric, CHECK >= 0), `garanti_bitis_tarihi` (date), `metadata` (jsonb — tür bazlı değişken alanlar), `created_by`/`updated_by` (uuid, frontend spoof edilemez), `created_at`/`updated_at`, `deleted_at` (soft archive).

- `UNIQUE(osgb_id, envanter_kodu)` — OSGB scope içinde benzersiz kod (race-safe, 23505 → `DUPLICATE_ENVANTER_KODU`). Cross-OSGB aynı kod serbesttir.
- CHECK `garanti_bitis_tarihi >= edinim_tarihi` (mantıksız tarih kombinasyonu engelli).
- Ortak sorgulanabilir alanlar (marka/model/seri_no) gerçek kolonda; yalnızca gerçekten değişken tür alanları (plaka, şasi no, RAM, işlemci vb.) `metadata` jsonb'de kontrollü tutulur.

### AM2. Tür Bazlı Metadata (kontrollü JSONB, dayatmasız)

- `arac`: plaka, model_yili, sasi_no, motor_no, ruhsat_bilgisi, kilometre, yakit_tipi.
- `bilgisayar`: cihaz_tipi, isletim_sistemi, islemci, ram, depolama.
- `diger`: kategori.
Alan zorunlulukları tür bazında backend validation ile yönetilir (Prompt 2'de netleşir; zorunluluk varsayımı ÜRETİLMEZ).

### AM3. Trigger'lar (DB invariant)

- `envanter_before_update` — `osgb_id`/`created_by` değiştirilemez (IDOR/scope spoof engeli) + `updated_at` taze.
- `envanter_prevent_delete` — fiziksel silme YOK (`ENVANTER_SILINEMEZ`); pasifleştirme soft-state.

### AM4. RLS (USING(true) YOK)

- SELECT / INSERT / UPDATE: yalnızca `admin` (tümü) ve `osgb_admin` (kendi `osgb_id`). Firma/uzman/hekim Envanter YÖNETEMEZ (bölüm 13).
- DELETE: hiçbiri (prevent_delete trigger + policy yok).
- Yazma yalnızca edge function (service role); RLS istemci erişimi için defense-in-depth.

### AM5. Edge Function `envanter`

Aksiyonlar: `list` (server-side search/filter/sort/pagination, SELECT * yok), `get`, `create`, `update`, `deactivate`, `reactivate`. Yetki: auth→profile→rol (admin/osgb_admin)→OSGB kapsamı (`osgb_admin` kendi profil OSGB'sini kullanır, body'ye güvenilmez; `admin` cross-OSGB body'den OSGB alır + varlık doğrulaması)→`osgb_erisim_acik` penceresi. `created_by`/`updated_by` gerçek `auth.uid()`'den. Duplicate kod 23505 → `DUPLICATE_ENVANTER_KODU`.

### AM6. Audit

`system_logs` → `ENVANTER_CREATED` / `ENVANTER_UPDATED` / `ENVANTER_DEACTIVATED` / `ENVANTER_REACTIVATED` (gerçek user_id/role/osgb_id, entity_type='envanter'). Frontend user_id/role/osgb_id spoof edemez.

### AM7. Frontend Servis

`src/lib/envanterService.ts` — tip + `mapEnvanterRow` + `friendlyEnvanterError` + `fetchEnvanterlerPage` / `fetchEnvanter` / `createEnvanter` / `updateEnvanter` / `deactivateEnvanter` / `reactivateEnvanter` (edge function invoke). Tür/durum sunum etiketleri (`ENVANTER_TURU_LABEL`/`ENVANTER_DURUM_LABEL`).

### AM8. Zimmet Hazırlığı + Durum / Kalan

- `envanter.id` stabil UUID — ileride `Zimmet → Personel` ilişkisine FK ile bağlanabilir. Zimmet tablosu/workflow'u/teslim/iade/fotoğraf BU PROMPTTA KURULMAZ.
- Dosya/Storage: genişletilmedi; metadata altyapısı ileride bağlanabilir. Yeni public bucket YOK.
- Envanter detay/liste UI + tür bazlı form + filtre → **Prompt 2** (mevcut `osgb/envanter` sayfası `PanelPlaceholder`).

---

## AO. ENVANTER DETAY PREMIUM UI + ZİMMET İADE WORKFLOW (UI/UX TURU)

> Bu tur yalnızca UI/UX + bir gerçek backend boşluğunun kapatılmasıdır. Yeni UI engine / sayfa-özel modal / yeni upload motoru OLUŞTURULMADI; mevcut SharedUICore + mevcut envanter/zimmet/operasyon servisleri + mevcut modallar kullanıldı. Mevcut yaşam döngüleri bozulmadı.

### AO1. Envanter Detay Modalı — Yeni Bilgi Mimarisi

- **Premium header:** tür ikonu + ad + durum/tür/zimmet rozetleri + kod; sağda `Düzenle` / `Pasif-Aktif Yap` / `Zimmetle` / `...` (ContextMenu) — hepsi mevcut handler.
- **5 sekme:** `Genel` / `Zimmet` / `Operasyonlar` / `Belgeler` / `Geçmiş` (`diger` türünde Operasyonlar yok). `TabBar` (underline) + gerçek sayaçlar.
- **Genel:** iki kolonlu premium kart grid'i — `Fotoğraflar` (ana görsel + thumbnail galerisi), `Temel Bilgiler`, `Durum ve Zimmet`, `Hızlı İşlemler`, `Türe Özel Bilgiler`, `Notlar`, `Son İşlemler`. Tümü gerçek veriden; uydurma aktivite YOK.
- **Operasyonlar:** referanstaki 8 ayrı sekme yerine TEK planda segment (pill) filtresi (Yakıt/Yıkama/Bakım/Tamir/Servis/Gider/Kaza; bilgisayarda Arızalar). OSGB yalnızca Bakım Notu oluşturabilir (backend kısıtı). Bakım segmentinde `Sonraki Bakım Tarihi` kartı.
- **Belgeler:** mevcut `fetchOperasyonDetail` ile operasyonlara bağlı TÜM gerçek dosyalar (fiş/fatura/kaza belgesi/arıza dosyası) toplanır; her belge gerçek kayda bağlı, uydurma belge YOK.
- **Geçmiş:** açık + kapanmış tüm zimmet kayıtları (kime, başlangıç/kabul, kapanış nedeni, iade notu). Kayıt silinmez.
- Modal genişliği 1180px (osgb/envanter + osgb/genel-bakis kullanımları).

### AO2. Zimmet İade Fotoğrafları (tek gerçek backend boşluğu)

- `zimmet` edge function `personel_iade` aksiyonu artık `iadeGorselleri` kabul eder; görseller `teslim_metadata.iadeGorseller` altında saklanır (teslim görselleriyle KARIŞMAZ, mevcut `gorseller` anahtarına DOKUNULMAZ → geriye uyumlu).
- `handleGet` hem `gorseller` (teslim) hem `iadeGorseller` (iade) imzalı URL'lerini döndürür.
- `ZimmetIadeModal` (personel modu) mevcut teslim görseli deseniyle fotoğraf yükler (JPG/PNG/WebP, 10 MB); `ZimmetDetailModal` iade fotoğraflarını ayrı bölümde gösterir.

### AO3. Değişmeyenler (regresyon yok)

Firma Ekle adımları, NACE/atama/personel/ziyaret/evrak akışları, RLS/IDOR, mevcut zimmet yaşam döngüsü (bekliyor→aktif→iade_talebi→iade_onayi_bekliyor→kapatildi), bildirim motorları (`zimmet_bildirimleri`/`operasyon_bildirimleri`), `fileUpload`/`Modal`/`TabBar` motorları, mevcut 20 genel gereksinim kuralı korundu. Yeni tablo/kolon/RLS policy eklenmedi.

### AO4. Bilinçli Kapsam Dışı (backend desteklemiyor — uydurulmadı)

- Kaza kaydının ayrı `konum/saat/hasar açıklaması` alanları: `arac_operasyonlari` şemasında yok; akış mevcut serbest açıklama + dosya alanlarıyla çalışır.
- OSGB notu: ayrı tablo YOK; mevcut `operasyon_yorumlari` (OperasyonDetailModal içi yorum/yanıt) OSGB notu olarak kullanılır.
- İade fotoğrafı zorunluluğu: mevcut iş kuralında zorunlu değil → uydurma zorunluluk eklenmedi.

---

## AP. İSG GEREKSİNİM MOTORU — TAM MEVZUAT AUDİTİ (2026-09-17)

> Mevcut 21 gereksinim güncel Türkiye mevzuatına göre resmî kaynaklardan (Resmî Gazete / mevzuat.gov.tr) tek tek denetlendi. **Hiçbir hukuki dayanak uydurulmadı.** Yalnızca doğrulanmış yanlışlar düzeltildi, doğru olanlara dokunulmadı. Motor/hesaplama mimarisi değişmedi (tüm veri `isg_kurallari` + `mevzuat_kaynaklari`'ndan okunur).

### AP1. Kritik Mevzuat Değişikliği — Eğitim Yönetmeliği

- **15.05.2013 tarihli ve 28648 sayılı** “Çalışanların İSG Eğitimlerinin Usul ve Esasları Hakkında Yönetmelik” (MevzuatNo 18371) **02.04.2026 tarihli ve 33212 sayılı Resmî Gazete'de yayımlanan yeni yönetmelikle YÜRÜRLÜKTEN KALDIRILMIŞTIR** (yeni yön. Madde 27).
- Yeni kaynak `mevzuat_kaynaklari`'na eklendi (`ISG-EGITIM-2026`, RG 02.04.2026/33212, kaynak_url = resmigazete.gov.tr/eskiler/2026/04/20260402-2.htm).
- 6 eğitim kuralı (TEMEL_ISG_EGITIMI, YENILEME_EGITIMI, ISE_OZGUN_EGITIM, ISE_BASLAMA_EGITIMI, BILGI_YENILEME, YILLIK_EGITIM_PLANI) yeni kaynağa bağlandı; her birine doğru `legal_article` yazıldı.
- **Süre/periyot değerleri 2026 yönetmeliğiyle ZATEN uyumlu çıktı** (temel 8/12/16 ders saati — Madde 13; tekrar periyodu az 3 / tehlikeli 2 / çok 1 yıl — Madde 14; tekrar eğitimi tüm sınıflarda 8 ders saati — Madde 14/2; 4. konu az 2 / tehlikeli 3 / çok 4 — Madde 13/3). Yalnızca kaynak + madde numarası güncellendi.
- `mevzuat.ts` içindeki eğitim yönetmeliği URL'i eski 18371'den yeni 2026 metnine çevrildi.

### AP2. Düzeltilenler

| Kural | Eski | Yeni | Dayanak |
|---|---|---|---|
| ACIL_DURUM_PLANI | Madde 11 | **Madde 7, 14** | Acil Durumlar Yön.: plan Madde 7, yenileme (2/4/6 yıl) Madde 14 |
| ACIL_SONDURME_EKIBI | Madde 12 | **Madde 11** | Acil Durumlar Yön. Madde 11 (ekipler, 30/40/50 çalışan) |
| ACIL_KURTARMA_EKIBI | Madde 12 | **Madde 11** | aynı |
| ACIL_KORUMA_EKIBI | Madde 12 | **Madde 11** | aynı |
| SAGLIK_GOZETIMI | kaynak=Hekim Yön., madde NULL | **6331 Madde 15** | Sağlık gözetimi (periyot 5/3/1 yıl doğru) |
| 6 eğitim kuralı | 2013 kaynağı | **2026 kaynağı + madde** | RG 33212 |

### AP3. Doğrulanan / Değişmeyenler (zaten doğru)

- **RISK_DEGERLENDIRME** — Risk Değ. Yön. Madde 12 (yenilenme: çok 2 / tehlikeli 4 / az 6 yıl). ✓
- **ACIL_DURUM_TATBIKATI** — Acil Durumlar Yön. Madde 13 (en geç yılda bir). ✓
- **İlkyardımcı sayıları** — İlkyardım Yön. Madde 19: az 20 / tehlikeli 15 / çok 10 (51 çalışan tehlikeli → ceil(51/15)=4). ✓
- **Acil durum ekip sayıları** — az 50 / tehlikeli 40 / çok 30 (51 çalışan → ceil(51/30|40|50)=2). ✓
- **CALISAN_TEMSILCISI** — 6331 Madde 20 kademeleri (2-50:1 … 2001+:6). ✓
- **ISG_KURULU** — 6331 Madde 22 (50+ çalışan + 6 aydan fazla sürekli iş). ✓
- **Sağlık gözetimi periyodu** — az 5 / tehlikeli 3 / çok 1 yıl. ✓
- **İSG profesyonel süreleri** (uzman/hekim/DSP) — ilgili yönetmelikler Madde 12. ✓
- **4 koşullu kural** (PATLAMADAN_KORUNMA_DOKUMANI ATEX Madde 10, KIMYASAL_RISK_DEGERLENDIRME Madde 6, KANSEROJEN_MARUZIYET_KONTROL Madde 7, YUKSEKTE_CALISMA_KORUMA Yapı İşleri Ek-4(A)) + `conditions` yapısı + PENDING/TRUE/FALSE/NACE-uyumsuz mantığı korundu. ✓

### AP4. Bilinçli Yapılmayanlar / Rapor

- **Yeni requirement EKLENMEDİ** (talimat gereği). Denetim sırasında bağımsız bir hukuki yükümlülük olarak ayrıştırılabilecek ek konu tespit edilmedi; mevcut 21 model korundu.
- **Eski 2013 kaynak satırı silinmedi** (tarihsel/traceability); yalnızca hiçbir kural artık ona referans vermiyor.
- Canlı uçtan-uca DB testi (gerçek test firması + aktif personel/evrak) yapılamadı; hesap doğrulaması kural/formül seviyesinde yapıldı.
- Build: **PASS**.

---

## AN. EKİPMANLAR MODÜLÜ — VERİ MODELİ + BACKEND + RLS (PROMPT 1 / ALTYAPI)

> Firma Paneli + yetkili Uzman tarafından yönetilen gerçek fiziksel iş ekipmanlarının production-ready veri altyapısı. KİLİTLİ AYRIM: **EKİPMAN ≠ ZİMMET ≠ ENVANTER**. Ekipman firmaya bağlı fiziksel iş ekipmanıdır; zimmet (teslim/kabul/iade) ve envanter (OSGB varlığı) ayrı modüllerdir. UI (listeleme + detay + form) sonraki promptta; bu prompt yalnızca veri modeli + backend + RLS + service altyapısı.

### AN1. Kavram Kilitleri (bozulmaz)

- **Ekipman no** sistem tarafından üretilir (frontend belirleyemez, race-safe, concurrency-safe, tekrar kullanılmaz). Kod `kod-NNN` biçimindedir (ör. `VINC-001`); `kod` türün prefix'idir, sayaç `(osgb_id, kod)` anahtarıyla atomik artar (`ON CONFLICT ... DO UPDATE ... RETURNING`).
- **QR reference** tahmin edilemez `uuid` (gen_random_uuid()); ekipman bilgisini ifşa etmez, tek başına authorization DEĞİLDİR. Kamera/QR tarama UI'sı sonraki promptta.
- **Kullanım durumu** (`aktif | arizali | bakimda | kullanim_disi`) operasyonel durumdur; `pasif`/`hurda` DURUM DEĞİLDİR. Arşivleme soft-delete (`deleted_at`) ile, fiziksel silme yok.
- **Periyodik kontrol ≠ bakım.** İkisi ayrı kayıt kümeleridir; bakım kaydı kontrol kaydı OLAMAZ.
- **Sonraki kontrol tarihi** sistem tarafından otomatik HESAPLANMAZ; kullanıcı elle girer (son kontrol + sonraki kontrol tarihi). Tarih yaklaşabilir/bugün/geçmiş olabilir; "kalan/geçen gün" göstergeleri ilerleyen UI promptunda türetilir.

### AN2. Tablolar (tek kaynak, duplicate yok)

1. **`ekipman_gruplari`** — 8 ana grup (Kaldırma/İletme, Basınçlı, Tesisat, Tezgâh/Makine, İş Makineleri, İskele, Raf/Kapı, Diğer). `kod` UNIQUE, `siralama`, `aktif`, `versiyon`.
2. **`ekipman_turleri`** — grup altında türler (Mobil Vinç, Forklift, Kompresör, CNC, ...). `kod` (prefix) UNIQUE, `grup_id` FK, `aktif`, `versiyon`.
3. **`ekipman_alt_turleri`** — nullable alt tür; `tur_id` FK, `UNIQUE(tur_id, kod)`.
4. **`ekipman_teknik_sablonlari`** — tür bazlı versiyonlanabilir teknik şablon (`tur_id` + `versiyon` UNIQUE, `aktif`).
5. **`ekipman_teknik_alanlari`** — şablon alanları: `field_key`, `label`, `veri_tipi` (text/number/decimal/date/boolean/select/multi_select/textarea), `zorunlu`, `siralama`, `placeholder`, `secenekler`, `birim`, `aktif`, `versiyon`. Frontend teknik alanları hardcode ETMEZ, şablondan okur.
6. **`ekipmanlar`** — ana kayıt: `osgb_id`, `firma_id`, `ekipman_grubu_id`, `ekipman_turu_id`, `ekipman_alt_turu_id`, `ekipman_no`, `ad`, `marka/model/seri_no/imal_yili/uretici/kullanim_amaci/konum/aciklama`, `kullanim_durumu`, `teknik_ozellikler` (jsonb), `qr_reference` (uuid UNIQUE), `sorumlu_personel_id` (nullable FK), `created_by/updated_by`, `deleted_at`. `UNIQUE(osgb_id, ekipman_no)`.
7. **`ekipman_sayaclari`** — `(osgb_id, kod, son_sayi)` PK; race-safe sayaç.
8. **`ekipman_belgeleri`** — belge kaydı (belge_turu, dosya adı, storage_path, mime, size, tarihler, yükleyen, metadata). Storage PRIVATE (sonraki prompt).
9. **`ekipman_periyodik_kontrolleri`** — kontrol geçmişi (kontrol_tarihi, sonraki_kontrol_tarihi, sonuc, rapor_path). Yeni kontrol yeni kayıt; eski silinmez.
10. **`ekipman_bakimlari`** — bakım geçmişi (bakim_tarihi/turu/yapilan_islem/bakim_yapan/sonraki_bakim_tarihi/notlar). Kontrolden ayrı.
11. **`ekipman_mevzuat_kurallari`** — tür → mevzuat kuralı bağı: `kontrol_gerekliligi` (zorunlu/opsiyonel/verification_required), `belge_kurallari/kontrol_kriterleri/yetkili_kisi_kurallari` (jsonb), `durum` (verified/verification_required/superseded/inactive), `versiyon`, `effective_from/to`. **BOŞ** — doğrulanmamış mevzuat UYDURULMAZ; 23.12.2025 İş Ekipmanları Yönetmeliği değişikliği doğrulanmış kaynakla sonraki promptta işlenir.

### AN3. Trigger'lar (DB invariant, RPC'den bağımsız savunma)

- `ekipman_validate` (BEFORE INSERT/UPDATE): `osgb_id` firmadan TÜRETİLİR (frontend'e güvenilmez — `ekipman.osgb_id = firma.osgb_id`); tür→grup, alt tür→tür, sorumlu→OSGB tutarlılığı (`EKIPMAN_GRUP_TUR_MISMATCH`/`EKIPMAN_ALT_TUR_MISMATCH`/`SORUMLU_CROSS_OSGB`).
- `ekipman_lock_scope` (BEFORE UPDATE): `osgb_id/firma_id/ekipman_grubu_id/ekipman_turu_id/ekipman_no/qr_reference/created_by` KİLİTLİ (IDOR/cross-OSGB taşıma engeli).
- `ekipman_prevent_delete` (BEFORE DELETE): fiziksel silme YOK (`EKIPMAN_SILINEMEZ`).
- `ekipman_set_updated_at` (mevcut `set_updated_at()`).

### AN4. RLS (USING(true) YOK)

- **Katalog** (gruplar/turler/alt turler/şablon/alanlar/mevzuat): SELECT tüm authenticated; INSERT/UPDATE/DELETE yalnızca `admin`.
- **`ekipmanlar`** SELECT: admin(tümü) / osgb_admin(kendi osgb) / uzman(`has_active_uzman_assignment(auth.uid(), firma_id)` — HEKİM HARİÇ) / firma(kendi firma). INSERT/UPDATE/DELETE istemciye KAPALI (yalnızca edge function service role + SECURITY DEFINER RPC).
- **Child tablolar** (belgeleri/periyodik_kontrolleri/bakimlari): SELECT ekipman scope'una göre (EXISTS üzerinden parent ekipman yetkisi); yazma istemciye kapalı.
- **`ekipman_sayaclari`**: istemciye kapalı (yalnızca RPC/edge function).

### AN5. Yardımcı + RPC (SECURITY DEFINER, search_path public)

- `has_active_uzman_assignment(p_user_id, p_firma_id)` — `has_active_firma_assignment`'ın `atama_turu='uzman'` sıkılaştırılmış hali (hekim HARİÇ). Cross-tenant bilgi sızıntısı yok.
- `ekipman_insert(...)` — atomik: auth→role (admin/osgb_admin/uzman/firma)→firma→osgb→scope (uzman: aktif uzman ataması; firma: kendi firması)→tür (aktif, kod)→sayaç artır→`ekipman_no`→`qr_reference`→INSERT (`created_by=auth.uid()`). Cross-OSGB/cross-firma/IDOR kapalı.

### AN6. Edge Function `ekipman`

Aksiyonlar: `katalog` (gruplar/turler/alt turler/şablon/alanlar), `list` (server-side search/filter/sort/pagination + firma_unvan/tur_ad/grup_ad/sonraki_kontrol_tarihi zenginleştirme, N+1 yok), `get` (ekipman + belge/kontrol/bakım), `create` (teknik özellikler aktif şablona göre sanitize + `ekipman_insert` RPC), `update` (scope doğrula + partial patch + `updated_by=auth.uid()`), `delete` (soft-delete). `osgb_erisim_acik` penceresi + firma aktiflik tüm yazmalarda kontrol edilir.

### AN7. Audit

`system_logs` → `EKIPMAN_CREATED/UPDATED/DELETED` (gerçek user_id/role/osgb_id, entity_type='ekipman'). Frontend user_id/role/osgb_id spoof edemez; şifre/token/secret loglanmaz.

### AN8. Frontend Servis

`src/lib/ekipmanService.ts` — tipler + `mapEkipmanRow` + `friendlyEkipmanError` + `fetchEkipmanKatalog` / `fetchEkipmanlarPage` / `fetchEkipmanDetail` / `createEkipman` / `updateEkipman` / `deleteEkipman` + `fetchEkipmanFirmalari` (uzman aktif firma picker) + kullanım durumu/kontrol durumu etiketleri. Mevzuat oranı/süresi İÇERMEZ.

### AN9. Durum / Kalan

- Katalog seed'li (8 grup + ~70 tür + prefix kodları, merkezi şablon sistemi üzerinden yönetilir); teknik şablon alanları ve mevzuat kuralları BOŞ (doğrulanmış kaynakla sonraki promptta). Ekipman kaydı UYDURMA YOK.
- UI (listeleme + Shared Detail Modal + tür bazlı dinamik form + QR tarama) → **sonraki prompt**. Belge yükleme (private storage + signed URL), periyodik kontrol/bakım girişi, sorumlu atama UI'sı da sonraki promptlarda.

---

## AO. EKİPMANLAR MODÜLÜ — PROMPT 2 (UI: LİSTE + TİP BAZLI FORM + DETAY MODAL)

> Prompt 1 altyapısını gerçek UI'a bağlayan katman. Yeni modal/listing/form/dropdown/tema motoru YOK — mevcut SharedUICore kullanılır. KİLİTLİ AYRIM korunur: **EKİPMAN ≠ ZİMMET ≠ ENVANTER**; periyodik kontrol ≠ bakım; ekipman no/QR backend'de üretilir.

### AO1. Ortak Bileşenler (`src/components/feature/ekipman/`)

Firma + Uzman panelinin TAMAMI aynı ortak bileşenleri tüketir (duplicate yok):

- `EkipmanListesi.tsx` — server-side liste motoru (Shared `Table` + `FilterBar` + `Pagination` + `Loading`/`EmptyState`/`ErrorState` + `SharedListCard` mobil kart). Role-aware: firma kendi firmasına kilitli; uzman aktif atama firmaları (firma filtresi + `fetchEkipmanFirmalari`). Search + tür + kullanım durumu filtreleri; sıralama (no/ad/durum); sayfa boyutu 10. Satır tıklaması → Detail Modal.
- `EkipmanFormModal.tsx` — tür bazlı dinamik form. Kademeli seçim: Ekipman Grubu → Ekipman Türü → (opsiyonel) Alt Tür → ortak alanlar → tür şablonundan dinamik teknik alanlar. Grup/tür değişiminde eski türe ait teknik metadata otomatik TEMİZLENİR (spec 9). Zorunluluk merkezi şablondan (`zorunlu`) gelir; teknik alanlar hardcode EDİLMEZ. Edit modunda grup/tür KİLİTLİ (kimlik taşınamaz).
- `EkipmanDetailModal.tsx` — TEK ADIMLI scrollable detay (sekmeli/aşamalı yapı KALDIRILDI). Açılışta fresh `get` (N+1 yok). Üst aksiyonlar: Düzenle / Kaldır (soft-delete arşivleme) / Ekle menüsü (Fotoğraf, Belge, Periyodik Kontrol, Bakım) / "..." menüsü. İki kolonlu: Ekipman Bilgileri + Teknik Özellikler + Periyodik Kontrol Bilgileri (sol) · Ekipman Görselleri + Belgeler + QR/Barkod (sağ). Alt bölüm: Periyodik Kontrol Kayıtları + Bakım Kayıtları.
- `ekipmanUi.ts` — kullanım/kontrol durumu badge varyantları + ikonlar + tarih formatlayıcıları.

### AO2. QR (güvenli referans)

- Detail Modal "QR" sekmesi: `qr_reference` (uuid) token'ından **istemci tarafında** `qrcode` ile görsel üretilir (üçüncü taraf API'ye sızmaz). QR yalnızca güvenli referans taşır; ekipman bilgisi/plaintext ifşa EDİLMEZ; tek başına yetki DEĞİLDİR.
- QR tarama (kamera) + backend resolve → SONRAKİ prompt (kamera lib + resolve aksiyonu henüz yok).

### AO3. Yaşam Döngüsü (Aktif / Pasif)

- "Pasif Yap" = soft-delete (`deleted_at`) — geçmiş/belge/QR/numara KORUNUR, numara tekrar kullanılmaz. Edge function'a `restore` aksiyonu eklendi (yeniden aktifleştirme — arşivlenmiş kayıt görünümü sonraki promptta). `kullanim_durumu` (aktif/arızalı/bakımda/kullanım dışı) operasyonel durum olarak AYRI kalır.

### AO4. Backend Değişiklikleri

- Edge function `ekipman`: `restore` aksiyonu eklendi; `canAccessEkipman` (deleted_at'ten bağımsız scope) + `assertEkipmanAccess` (deleted_at dahil) ayrıştırıldı; `get` artık `gecmis` (system_logs, entity_type='ekipman') döndürür.

### AO5. Bilinçli Kapsam Dışı (sonraki promptlar)

- **Belge yükleme** (private storage + signed URL) — backend belge upload aksiyonu henüz yok; Belgeler sekmesi gerçek (boş) listeyi gösterir, sahte upload UI ÜRETİLMEZ.
- **Periyodik kontrol / bakım girişi** — backend create aksiyonu yok; sekmeler gerçek (boş) listeleri gösterir.
- **QR tarama (kamera)** — kamera lib + backend resolve yok.
- **Arşivlenmiş ekipman görünümü** (restore UI) — `restore` backend'de hazır, listeleme UI'ı sonraki promptta.
- Mevzuat/kontrol kriterleri (EK-III, EKİPNET, İSG-KATİP) — doğrulanmış kaynakla sonraki promptta; `ekipman_mevzuat_kurallari` BOŞ.

---

## AP. EKİPMANLAR MODÜLÜ — PROMPT 3 (DETAY + BELGELER + KONTROL + BAKIM + QR + GEÇMİŞ)

> Prompt 2'deki detay modalını GERÇEK işlevlere bağlayan katman. Yeni UI/modal/drawer/tablo/tema motoru YOK — mevcut SharedUICore kullanılır. KİLİTLİ AYRIM korunur: periyodik kontrol ≠ bakım; belge/QR tek başına yetki DEĞİLDİR; hard delete YOK.

### AP1. Yeni Backend Aksiyonları (edge function `ekipman`)

- **`belge_ekle`** — dosya (base64) private `ekipman-belgeleri` bucket'a + `ekipman_belgeleri` satırına (belge_turu/dosya/mime/size/tarihler/yükleyen=uid/metadata). MIME + 15MB sunucu-side doğrulanır; path sunucuda `{osgb}/ekipman/{id}/{uuid}.{ext}` üretilir.
- **`belge_url`** — scope doğrulama sonrası `createSignedUrl` (3600s). Storage path yetki kanıtı DEĞİL.
- **`belge_arsivle`** — `aktif=false` (soft-archive; fiziksel Storage silme YOK).
- **`kontrol_ekle`** — `ekipman_periyodik_kontrolleri` satırı (kontrol_tarihi + sonraki_kontrol_tarihi ZORUNLU, sonuc, metadata: yontem/kusur/yetkili/meslek/ekipnet_no/isg_katip/aciklama). Yeni kontrol yeni kayıt; eski silinmez.
- **`bakim_ekle`** — `ekipman_bakimlari` satırı (bakim_tarihi ZORUNLU + turu/yapilan_islem/aciklama/yapan/sonraki/notlar). Kontrolden AYRI.
- **`qr_resolve`** — `qr_reference` token → ekipman çözümle; `assertEkipmanAccess` (deleted_at + yetki) ile doğrular. QR tek başına yetki DEĞİL.
- **Uzman view-only kilidi** — `canManageBase(caller)` (role ≠ uzman) `update`/`delete`/`restore`'da zorunlu (`UZMAN_READONLY`). Uzman belge/kontrol/bakım EKLEYEBİLİR (additive) ama temel kaydı değiştiremez.

### AP2. Storage

- Yeni **private** bucket `ekipman-belgeleri` (public=false). Public bucket YOK; `storage.objects` üzerinde policy yok → yalnızca edge function (service role).
- `ekipman_belgeleri`'ne `aktif` boolean (default true) eklendi — soft-archive (belge geçmişi korunur).

### AP3. UI

- `BelgeEkleModal` / `KontrolEkleModal` / `BakimEkleModal` — Shared Form (Select/Input/Textarea/DatePicker + raw `<input type=file>` — `FileUpload` ham File vermez). Çift submit kilidi + gerçek mutation sonrası toast.
- `EkipmanDetailModal` TEK ADIMLI merkezi detay modalına dönüştürüldü (sekmeler kaldırıldı, veri/akış korundu). Belge görüntüle/indir (signed URL), **Ağır Kusur uyarısı**, periyodik kontrol + bakım kayıtları aynı scrollable ekranda. **Fotoğraf/belge Sil = kalıcı silme** (storage dosyası + DB kaydı, `belge_sil` edge action; onay modalı + refetch, orphan dosya bırakmaz). Fotoğraf ekleme (JPG/PNG/WEBP) gerçek file picker + storage/DB kaydı. **Uzman/hekim de dahil tüm yetkili roller ekipmanı yönetebilir** (backend `canManageBase` uzmana açıldı; scope yine sunucuda doğrulanır).
- Ekipman QR ÜRETİMİ (indirme) + QR OKUTMA/AKILLI ERİŞİM mevcuttur. QR yalnızca tahmin edilemez opak bir erişim anahtarı taşır ve tam URL (`/ekipman-qr/<token>`) olarak üretilir; TEK BAŞINA ekipman bilgilerine erişim sağlamaz. Erişim SUNUCUDA doğrulanır: `ekipman` edge function `qr_resolve` (oturum + firma yetkisi + ekipman yetkisi) başarılıysa mobil ekipman ekranı açılır. Oturum yoksa "Erişim Gerekli", yetki yoksa "Erişim Yetkiniz Yok" gösterilir; geçersiz/kayıt yok/yetkisiz durumları aynı genel hata (QR_ERISIM_YOK) ile döner ve bilgi ifşa EDİLMEZ. Detay modalında "QR'ı Yenile" ile eski token anında geçersiz kılınır. Detay bölümleri (belgeler/kontroller/bakım/görseller) kullanıcı dokununca TEMBEL yüklenir (`get` + `bolum`). QR okutma ortak bir tarayıcı bileşeniyle yapılır; ekipman detayına gömülmez. QR/Barkod kartı mobil okutma ekranında GÖSTERİLMEZ.
- `EkipmanListesi` — "QR Tara" aksiyonu eklendi; uzman için "Pasif Yap" satır aksiyonu gizli.

### AP4. Bilinçli Kapsam Dışı (sonraki promptlar)

- **Arşivlenmiş ekipman görünümü / restore UI** — `restore` backend'de hazır, arşiv listesi görünümü sonraki promptta.
- **Kontrol raporu dosya yükleme** (`rapor_path`) — rapor şu an belge olarak yüklenebilir; özel rapor upload sonraki promptta.
- **Mevzuat/kontrol kriterleri** (EK-III, EKİPNET, İSG-KATİP) — doğrulanmış resmî kaynakla sonraki promptta; `ekipman_mevzuat_kurallari` BOŞ, `verification_required` yaklaşımı korunur.

---

## AQ. EKİPMANLAR MODÜLÜ — PROMPT 4 (SON HARDENING + QA + LOCK)

> Modülün üretim kalitesinde kapanış denetimi. Yeni sistem KURULMAZ; mevcut kod/DB/RLS/Storage/UI gerçek kaynaktan denetlenip tutarlılık delikleri kapatılır. KİLİTLİ AYRIM korunur: **EKİPMAN ≠ ZİMMET ≠ ENVANTER**; periyodik kontrol ≠ bakım; ekipman no/QR backend'de üretilir; hard delete YOK.

### AQ1. Denetimde Kapatılan Tutarlılık/Güvenlik Delikleri (4)

Pasif/arşivlenmiş firmaya operasyonel yazma işlemi `create`/`update`/`restore`'da zaten engellenirken, aynı kural aşağıdaki aksiyonlarda UYGULANMIYORDU (spec "Firma kullanım dışıysa işlem engellenir" ilkesine aykırı tutarsızlık):

1. **`delete`** — `assertOsgbAccess` + firma aktiflik kontrolü EKSİKTİ (`restore`'da vardı).
2. **`belge_ekle`** — firma aktiflik kontrolü YOKTU.
3. **`kontrol_ekle`** — firma aktiflik kontrolü YOKTU.
4. **`bakim_ekle`** — firma aktiflik kontrolü YOKTU.

Çözüm: `assertFirmaOperational(admin, firmaId)` yardımcısı eklendi (firma `is_active` + `deleted_at` kontrolü, `INACTIVE_FIRMA`); 4 aksiyonun tamamında uygulanır. `delete` ayrıca `assertOsgbAccess` kazandı. Sonuç: tüm yazma aksiyonları artık `assertOsgbAccess` + firma aktiflik zincirini birebir uygular (savunma derinliği).

### AQ2. Doğrulanan Sağlam Katmanlar (değiştirilmedi)

- **RLS:** `ekipmanlar` SELECT admin/osgb_admin/uzman(`has_active_uzman_assignment` — `atama_turu='uzman'`, HEKİM HARİÇ)/firma; INSERT/UPDATE/DELETE istemciye KAPALI (yazma yalnızca service role). Child tablolar parent scope'lu SELECT. `ekipman_sayaclari` istemciye kapalı. `USING(true)` YOK (yalnızca read-only katalog SELECT'inde `auth.uid() IS NOT NULL`).
- **Trigger'lar:** `ekipman_validate` (osgb_id firmadan TÜRETİLİR + tür/grup/alt-tür/sorumlu cross-OSGB tutarlılığı), `ekipman_lock_scope` (osgb/firma/grup/tür/no/QR/created_by KİLİTLİ), `ekipman_prevent_delete` (fiziksel silme yok).
- **Sayaç/numara:** `ekipman_insert` RPC atomik (`ekipman_sayaclari` + `gen_random_uuid`); `UNIQUE(osgb_id, ekipman_no)` + `UNIQUE(qr_reference)` DB seviyesinde race-safe; numara update endpoint'inden DEĞİŞTİRİLEMEZ (`lock_scope` + form readonly).
- **Storage:** `ekipman-belgeleri` bucket private (`public=false`); signed URL yalnızca scope doğrulaması sonrası; belge arşivleme soft (`aktif=false`), fiziksel silme yok.
- **QR:** `qr_reference` uuid; ekipman/firma/kişisel/belge bilgisi plaintext İFŞA ETMEZ; `qr_resolve` `assertEkipmanAccess` (deleted_at + yetki) ile doğrular — tek başına yetki DEĞİL.
- **Uzman view-only:** `canManageBase` (`role !== uzman`) update/delete/restore'da zorunlu; belge/kontrol/bakım additive.
- **Audit:** `system_logs` entity_type='ekipman' → `EKIPMAN_CREATED/UPDATED/DELETED/RESTORED/BELGE_EKLENDI/BELGE_ARSIVLENDI/KONTROL_EKLENDI/BAKIM_EKLENDI` (gerçek user_id/role/osgb_id, `auth.uid()`); şifre/token/secret loglanmaz.

### AQ3. Bilinçli Kapsam Dışı (sahte UI/veri ile doldurulmadı)

- **Arşivlenmiş ekipman görünümü / restore UI** — `restore` backend'de hazır, arşiv listesi görünümü sonraki promptta.
- **Kontrol raporu dosya yükleme** (`rapor_path`) — rapor şu an belge olarak yüklenebilir.
- **Mevzuat/kontrol kriterleri** (EK-III, EKİPNET, İSG-KATİP) — doğrulanmış resmî kaynakla sonraki promptta; `ekipman_mevzuat_kurallari` BOŞ, `verification_required` yaklaşımı korunur.

### AQ4. Sonuç

Firma Paneli → Ekipmanlar modülü mevcut İSGDenetim mimarisi içinde LOCK durumundadır. Shared UI/Modal/Listing/Mobile/Theme motorları değiştirilmedi; yeni motor/drawer/notification/tema sistemi oluşturulmadı. Yeni ekipman türleri, belgeler ve hukuki kurallar gelecekte merkezi template/rule engine üzerinden genişletilebilir.

---

## AR. EKİPMANLAR MODÜLÜ — PROMPT 5 (SON ENTEGRASYON / QA / LOCK)

> Modülün NİHAİ kapanışı. Yeni sistem KURULMAZ; önceki 4 prompttan kalan yarım/eksik işler tamamlanır, veri tutarlılığı + RLS/IDOR gerçek kaynaktan denetlenir ve modül LOCK'a alınır. KİLİTLİ AYRIM korunur: **EKİPMAN ≠ ZİMMET ≠ ENVANTER**; periyodik kontrol ≠ bakım; ekipman no/QR backend'de üretilir; hard delete YOK. KAPSAM SINIRI: Ziyaret/Saha Denetimi/Uygunsuzluk/Tutanak/Muayene gibi başka modüllerin business logic'i EKİPMAN modülüne TAŞINMAZ.

### AR1. Veri Tutarlılığı Denetimi (SQL gerçek kaynağından doğrulandı)

- **Unique constraint:** `UNIQUE(osgb_id, ekipman_no)` + `UNIQUE(qr_reference)` DB seviyesinde. Pasif ekipman satırı soft-delete ile korunur (satır silinmez) → numara tekrar kullanılamaz. Race-safe.
- **FK constraint (child tablolar):** `ekipman_belgeleri/periyodik_kontrolleri/bakimlari` → `ekipmanlar(id) ON DELETE CASCADE`. CASCADE hiçbir zaman tetiklenmez çünkü `ekipman_prevent_delete` trigger'ı hard delete'i DB seviyesinde bloklar (soft-delete CASCADE üretmez). Belge/kontrol/bakım başka ekipmana taşınamaz: child tablolarda write RLS policy YOK (yalnızca SELECT), move endpoint'i YOK, FK `ekipman_id` geçerli parent'a işaret eder.
- **RLS:** tüm ekipman tablolarında `relrowsecurity=true`; child tablolarda yalnızca `polcmd='r'` (SELECT) politikaları — yazma istemciye tamamen kapalı, yalnızca service-role edge function. `USING(true)` YOK.
- **Trigger'lar doğrulandı:** `ekipman_validate`, `ekipman_lock_scope`, `ekipman_prevent_delete`, `ekipman_set_updated_at` aktif.

### AR2. Kapatılan Kalan İşler (2)

1. **QR erişim denemeleri loglanmıyordu** — spec bölüm 21 ("QR erişim denemesi" geçmiş olayı) + 25 ("QR erişim denemeleri ve yetki reddi loglanmalı") gereğince `handleQrResolve` artık audit yazar: başarılı çözüm `EKIPMAN_QR_RESOLVED` (entity_id=ekipman → Geçmiş sekmesinde görünür); yetki reddi/geçersiz token `EKIPMAN_QR_DENIED` (entity_id=NULL, generic açıklama — hedef ekipmanın osgb/firma/ekipman_no bilgisi İFŞA EDİLMEZ).
2. **Arşivlenmiş ekipman restore UI'ı yoktu** — `restore` backend'de hazırdı ama "Pasif Yap" kullanıcı gözünden tek yönlüydü. Tamamlandı: `handleList` `includeDeleted` parametresi kazandı; `EkipmanData.deletedAt` eklendi; liste UI'ına "Pasifleri göster" toggle'ı + arşivlenmiş satırlarda "Pasif" rozeti + "Yeniden Aktifleştir" aksiyonu (desktop satır aksiyonu + mobil kart). Arşivlenmiş satırın detail'e açılması engellendi (detail `get` deleted_at'te 403 döner).

### AR3. Doğrulanamayan (BLOCKED — PASS demiyorum)

- **Gerçek authenticated E2E:** Firma/Uzman hesabıyla ekipman oluştur → no/QR → listele → detay → belge → kontrol → bakım → QR tara → pasifleştir → yeniden aktifleştir. Gerçek hesap olmadan koşulamıyor.
- **Gerçek concurrency:** iki eşzamanlı create'in aynı numara üretmeyeceği — mantık + `UNIQUE(osgb_id, ekipman_no)` constraint doğru, canlı yarış testi yapılamadı.
- **Kamera QR tarama:** gerçek cihaz GPS/kamera akışı.

### AR4. Bilinçli Kapsam Dışı (sahte veri ile doldurulmadı)

- **Kontrol raporu dosya yükleme** (`rapor_path` null) — rapor belge olarak yüklenebilir; özel rapor upload ayrıca.
- **Mevzuat/kontrol kriterleri** (EK-III, EKİPNET, İSG-KATİP zorunluluğu) — doğrulanmış resmî kaynakla sonraki promptta; `ekipman_mevzuat_kurallari` BOŞ, `verification_required` yaklaşımı korunur.

### AR5. SONUÇ (LOCK)

Firma Paneli → Ekipmanlar modülü mevcut İSGDenetim mimarisi içinde LOCK durumundadır. QR audit logging + arşiv restore UI'ı tamamlandı; veri tutarlılığı (unique/FK/RLS/trigger) SQL seviyesinde doğrulandı; Shared UI/Modal/Listing/Mobile/Theme motorları değiştirilmedi. Yeni ekipman türleri, teknik alanlar, belgeler ve hukuki kurallar merkezi template/rule/source sistemi üzerinden genişletilebilir; modül kendi sınırı içinde kalır (başka modüllerin business logic'ini içine almaz).

---

## AS. EKİPMANLAR MODÜLÜ — PROMPT 6 (FİNAL QA + GERÇEK E2E + GÜVENLİK + LOCK)

> Modülün SON denetim + kilitleme pası. Yeni özellik İCAT EDİLMEZ; mevcut kod/DB/RLS/Storage/UI gerçek kaynaktan denetlenip eksikler kapatılır. KAPSAM SINIRI: yalnızca Firma Paneli → Ekipmanlar. KİLİTLİ AYRIM korunur: **EKİPMAN ≠ ZİMMET ≠ ENVANTER**; periyodik kontrol ≠ bakım; İSG-KATİP ≠ EKİPNET; ekipman no/QR backend'de üretilir; hard delete YOK.

### AS1. Index Denetimi + Kapatılan Boşluklar (bölüm 25)

SQL `pg_indexes` gerçek kaynağından denetlendi. `ekipmanlar` tablosu iyi indexlenmişti (`ekipmanlar_firma_idx` / `ekipmanlar_osgb_idx` / `ekipmanlar_tur_idx` / `ekipmanlar_kullanim_durumu_idx` + `ekipman_no_osgb_unique` + `ekipman_qr_reference_unique`). Ancak **child tablolar yalnızca pkey'e sahipti** — `handleGet` (belge/kontrol/bakım) ve `sonrakiKontrolMap` (kontrol tarihi sıralaması) hep `ekipman_id`'ye göre sorguluyordu ve `system_logs` geçmiş sorgusu `entity_type + entity_id` composite index'ten yoksundu. Kapatılan 4 boşluk (idempotent `CREATE INDEX IF NOT EXISTS`):

1. `ekipman_belgeleri (ekipman_id, aktif, created_at DESC)`
2. `ekipman_periyodik_kontrolleri (ekipman_id, kontrol_tarihi DESC)` — sonraki kontrol tarihi sıralaması N+1'siz tek sorguda hızlanır.
3. `ekipman_bakimlari (ekipman_id, bakim_tarihi DESC)`
4. `system_logs (entity_type, entity_id, created_at DESC)` — Geçmiş sekmesi sorgusu.

### AS2. Kod Temizliği Denetimi (bölüm 33)

- `console.log/debug/info/warn/error` → ekipman bileşenlerinde + serviste **SIFIR**.
- Fake/demo/mock veri → ekipman modülünde **SIFIR** (tüm bileşenler gerçek Supabase servis katmanından okur; boş veri = Empty State).
- N+1 yok: liste `sonrakiKontrolMap` tek `.in()` sorgusu; detail `Promise.all` ile belge/kontrol/bakım paralel.
- Kullanılmayan component/service/duplicate hook/ölü route bulunmadı; `Table`/`TableListing`/`Pagination`/`Modal`/`useToast`/`useConfirm` SharedUICore'dan tüketiliyor.

### AS3. Build / Runtime

Build + TypeScript temiz (hatasız). `AuthContext.firmaId` + `system_logs` kolonları (`role`/`metadata`/`entity_type`/`entity_id`) doğrulandı. Hekim için ekipman route YOK + backend `ALLOWED_ROLES` hekimi dışlıyor.

### AS4. Doğrulanamayan (BLOCKED — PASS demiyorum)

- **Gerçek authenticated E2E:** Firma/Uzman hesabıyla tam akış (oluştur → no/QR → belge → kontrol → bakım → QR tara → pasifleştir → aktifleştir) gerçek hesap olmadan koşulamıyor.
- **Gerçek concurrency:** iki eşzamanlı create yarış testi — mantık + `UNIQUE(osgb_id, ekipman_no)` doğru, canlı yarış koşulamadı.
- **Kamera QR tarama:** gerçek cihaz kamera/GPS akışı.

### AS5. Bilinçli Kapsam Dışı (sahte veri ile doldurulmadı)

- **Kontrol raporu dosya yükleme** (`rapor_path` null) — rapor belge olarak yüklenebilir.
- **Mevzuat/kontrol kriterleri** (EK-III, EKİPNET, İSG-KATİP zorunluluğu) — doğrulanmış resmî kaynakla; `ekipman_mevzuat_kurallari` BOŞ, `verification_required` korunur.

### AS6. SONUÇ (LOCK)

Firma Paneli → Ekipmanlar modülü mevcut İSGDenetim mimarisi içinde LOCK durumundadır. Index boşlukları kapatıldı; kod temizliği + build + RLS/trigger/constraint SQL seviyesinde doğrulandı;

---

## AT. EKİPMANLAR MODÜLÜ — PROMPT 7 (MERKEZİ VERİ KATALOĞU + JSONB SÖZLEŞMESİ + DİNAMİK FORM ENTEGRASYONU)

> Amaç: Yeni Ekipman formunu statik değil tür-bazlı dinamik hale getirmek; merkezi template/rule/source verisini formla buluşturmak. KAPSAM: yalnızca Firma Paneli → Ekipmanlar. Yeni paralel UI/upload/belge/kontrol sistemi OLUŞTURULMAZ.

**JSONB sözleşmesi (tek standart)**: `belge_kurallari` → `{version, items:[{code,name,document_type,required,applicability,source,notes}]}`; `kontrol_kriterleri` → `{version, periodic_control:{required,period{value,unit,source},method,criteria,required_fields,result_options,defect_options,report_required}}`; `yetkili_kisi_kurallari` → `{version, rules:[{code,scope,allowed_roles,allowed_professions,conditions,source,notes}]}`. `source` ortak: `{source_id,reference,title,url}`.

**Yapılan**: edge function `katalog`→`kurallar` + `create`→atomik kontrol/belge (hata durumunda geri al); helper `fetchMevzuatKurali`/`zorunluBelgeler`/`periyodikKontrolGerekli`; servis parser'ları (`parseBelgeKurallari`/`parseKontrolKriterleri`/`parseYetkiliKisiKurallari`) + `mevzuatKuraliForTur` + `EkipmanCreatePayload.kontrol/belgeler`; formda Periyodik Kontrol + Gerekli Belgeler bölümleri (tür değişiminde temizlenir, submit'te atomik). `mevzuat_kaynaklari` seed: 2013 yönetmelik (`verified`) + 23.12.2025 değişikliği (`verification_required`).

**BLOCKED/UNVERIFIED**: teknik şablon/alan (0 kayıt) + mevzuat kuralı (0 kayıt) — periyot/belge/yetkili değerleri 23.12.2025 EK-III yenilemesi nedeniyle resmi metinden birebir doğrulanamadı, uydurulmadı. Kod, veri eklendiğinde otomatik çalışır durumda. Shared UI/Modal/Listing/Mobile/Theme motorları değiştirilmedi. Yeni ekipman türleri, teknik alanlar, belgeler ve hukuki kurallar merkezi ve versiyonlu template/rule/source sistemi üzerinden genişletilebilir; modül kendi sınırı içinde kalır.

---

## AU. EKİPMANLAR MODÜLÜ — PROMPT 8 (TÜR BAZLI TEKNİK ŞABLON SEED + GERÇEK DİNAMİK FORM)

> Amaç: Prompt 7'de BLOCKED kalan "form dinamik ama veri boş" açığını kapatmak. Form kodunun zaten dinamik olduğu (`alanlarForTur` + `mevzuatKuraliForTur`, hardcode YOK) doğrulandı; asıl eksik merkezi veri katmanıydı (teknik şablon/alan = 0 kayıt). KAPSAM: yalnızca Firma Paneli → Ekipmanlar. Hukuki kural (periyot/belge zorunluluğu/yetkili meslek) UYDURULMAZ.

**Ayrım (kritik)**: "teknik alan" (kaldırma kapasitesi, bom uzunluğu, hacim, basınç, sıcaklık, motor gücü...) = mühendislik/teknik özniteliktir, hukuki kural DEĞİLDİR → dürüstçe seed edilebilir. "mevzuat kuralı" (periyot, CE zorunluluğu, yetkili meslek) = hukuki veridir, 23.12.2025 EK-III yenilemesi doğrulanamadığı için UYDURULMAZ.

**Yapılan**: `ekipman_teknik_sablonlari` (8 kayıt) + `ekipman_teknik_alanlari` (43 alan) seed — Kule Vinç (üretici/kaldırma kapasitesi/bom/kule yüksekliği/çalışma yarıçapı/motor gücü), Mobil Vinç, Forklift (motor tipi select), Köprülü Vinç, Buhar Kazanı (ısıtma yüzeyi/işletme-tasarım basıncı/buhar kapasitesi/sıcaklık), Kalorifer Kazanı (yakıt tipi select), Kompresör (tank hacmi/çalışma-tasarım basıncı/hava debisi), Sütunlu Çalışma Platformu. Backend `fetchTeknikAlanlar` + `sanitizeTeknikOzellikler` (whitelist + zorunlu doğrulama) frontend `alanlarForTur` ile birebir tutarlı — tür seçilince o türün teknik alanları hem formda render edilir hem backend doğrular. Forma "şablon bulunamadı" bilgi durumu eklendi (bölüm 11): şablonu/mevzuat kuralı olmayan tür seçilince dürüst boş-durum gösterilir, alan UYDURULMAZ.

**BLOCKED/UNVERIFIED**: `ekipman_mevzuat_kurallari` hâlâ BOŞ (0 kayıt) — periyodik kontrol periyodu, belge zorunluluğu (CE vb.), yetkili meslek değerleri 23.12.2025 EK-III yenilemesi nedeniyle resmî metinden birebir doğrulanamadı; `verification_required` yaklaşımı korunur, mevzuat uzmanı/hukuk danışmanı doğrulaması gerekir. Bu veri eklenene kadar kontrol/belge bölümleri (kural boş olduğu için) açılmaz — bu DÜRÜST davranıştır, sahte kontrol/belge zorunluluğu ÜRETİLMEZ. Shared UI/Modal/Listing/Mobile/Theme motorları değiştirilmedi; yeni ekipman türleri teknik alan ekleyerek (frontend kod değişmeden) genişletilebilir.

---

## AV. FAZ 2 / PROMPT 1 — MERKEZİ DURUM RESOLVER + İDEMPOTENT HESAPLAMA (TAMAMLAMA)

> Faz 2 / Prompt 1'in kapanışı: merkezi kural motorunun ürettiği gereksinimlere **gerçek evrak geçerlilik resolver'ı** ve **idempotent hesaplama** eklenir. Mevcut altyapı (AC) korunur; yeni paralel sistem YOK. KİLİTLİ AYRIM korunur: **kural ≠ firma_gereksinimi ≠ snapshot ≠ evrak**.

### AV1. Merkezi Gereksinim Durum Resolver'ı

`gereksinim-hesapla` edge function'ı artık her gereksinim için `gecerlilik_durumu` (`valid`/`expiring`/`expired`) + `kalan_gun` üretir — frontend hesabı DEĞİL, yalnızca server-side resolver.

- **Belge yok** → `gecerlilik_durumu = null`, durum `missing` (Eksik).
- **Belge var + tarih geçti** → `expired` (Süresi Geçmiş), `kalan_gun` negatif.
- **Belge var + eşik içinde** → `expiring` (Yaklaşıyor), `kalan_gun = kalan gün`.
- **Belge var + geçerli** → `valid` (Geçerli).

Yenilenme tarihi: belgenin açık `valid_until`'i varsa o; yoksa `document_date + merkezi kural süresi` (`isg_kurallari.calculation_definition.validity_by_hazard` veya `validity_duration/validity_unit`). "Yaklaşıyor" eşiği merkezi `system_settings.evrak_yaklasma_gun` (45) — frontend'e hardcode YOK, hukuki süre uydurulmaz.

### AV2. İdempotent Hesaplama (duplicate snapshot engeli)

- `firmalar.isg_girdi_degisti` dirty flag'i (trigger: NACE/tehlike/panel/manuel/personel değişimi) ile hesaplama yalnızca anlamlı girdi değişiminde yeni snapshot dönemi oluşturur.
- Aynı input ile tekrar hesaplama → `snapshotCreated = false`, append-only geçmiş duplicate ÜRETMEZ.
- `firma_gereksinimleri` her zaman upsert edilir (evrak sayısı/durumu girdi değişiminden bağımsız güncellenir); `UNIQUE(firma_id, rule_id)` ile stabil id korunur, evrak `requirement_id` bağlantısı kopmaz.

### AV3. UI

`IsgGereksinimleriTab` gereksinim listesine geçerlilik badge'i ekler: `Geçerli` / `Yaklaşıyor — X gün` / `Süresi Geçmiş` (gerçek resolver sonucu). `gereksinimService` `GecerlilikDurumu` tipi + `GECERLILIK_DURUMU_LABEL` sunar.

### AV4. Güvenlik / Doğrulanan (değiştirilmedi)

RLS (cross-OSGB/cross-firma/IDOR kapalı), trigger'lar, NACE→tehlike sync, panel/manuel çalışan ayrımı, append-only snapshot, evrak→gereksinim (`requirement_id` → `firma_gereksinimleri.id`) bağlantısı korunur. `USING(true)` YOK. Mevzuat oranı/süresi uydurulmaz; `verification_required` yaklaşımı korunur.

---

## AW. FAZ 2 / PROMPT 2 — UZMAN + HEKİM FİRMALARIM FİRMA DETAYI + İSG GEREKSİNİMLERİ ENTEGRASYONU

> Amaç: Uzman/Hekim paneli "Firmalarım → Firma Detayı → İSG Gereksinimleri" akışını gerçek veri + gerçek yetkilendirme + mevcut Shared UI ile tamamlamak. Yeni modal/drawer/listing/theme motoru YOK; yeni firma detay veri modeli YOK. KİLİTLİ AYRIM korunur: **kural ≠ firma_gereksinimi ≠ snapshot ≠ evrak**.

### AW1. Hekim Kapsamı (merkezi metadata, uydurma yok)

- `isg_kurallari.hekim_kapsami` (boolean, default false) eklendi; yalnızca 3 sağlık kuralı `true` işaretlendi: `saglik_gozetimi` (Sağlık Gözetimi), `diger_saglik_personeli` (Diğer Sağlık Personeli/DSP), `isyeri_hekimi_hizmeti` (İşyeri Hekimi Hizmeti). Bu sınıflandırma mevcut `requirement_type` slug'larına dayanır (isim eşleştirme DEĞİL); hukuki eşik/oran ÜRETİLMEDİ.
- `firma_gereksinimleri.hekim_kapsami` (boolean, default false) denormalize kolon eklendi; `gereksinim-hesapla` edge function'ı rule'dan kopyalar. Mevcut kayıtlar backfill edildi.
- Hekim görünümü `fetchFirmaGereksinimleri(firmaId, 'hekim')` → `.eq('hekim_kapsami', true)`; frontend'de kural/tehlike/isim eşleştirmesi YOK.

### AW2. RLS Sıkılaştırma (atama-bazlı, cross-OSGB/IDOR kapalı)

- `firma_gereksinimleri_select` politikası `ALTER POLICY` ile daraltıldı: uzman/hekim artık `osgb_id = auth_osgb_id()` DEĞİL, `has_active_firma_assignment(auth.uid(), firma_id)` ile yalnızca AKTİF ataması bulunan firmaları görür (atama yoksa görmez). osgb_admin/firma kolları korundu.
- `isg_gereksinim_snapshot`'a `snapshot_select_uzman_hekim` policy eklendi (aynı atama-bazlı scope; önceden uzman/hekim hiç göremiyordu).
- `firmalar_select_uzman_hekim` zaten `has_active_firma_assignment` kullanıyordu (değiştirilmedi). `USING(true)` YOK; `has_active_firma_assignment` SECURITY DEFINER, tüm zinciri (atama aktif + personel aktif + firma aktif + osgb aktif + erişim penceresi + tarih aralığı) kontrol eder ve non-admin yalnızca kendi user_id'sini sorgulayabilir.

### AW3. Shared UI / Yeniden Kullanım

- `IsgGereksinimleriTab`'e `scope` prop eklendi (`'osgb' | 'uzman' | 'hekim'`): 'osgb' tam yönetim (yeniden hesaplama dahil), 'uzman' tam liste salt okunur, 'hekim' yalnızca hekim kapsamı. Yeniden hesaplama butonu + dirty badge yalnızca OSGB'de. Hesaplama/formül hiçbir scope'ta frontend'de yapılmaz.
- Uzman/Hekim/DSP panelleri de AYNI ortak `FirmaDetayModal` bileşenini kullanır (UI birebir aynı, yalnızca `firmaDetayPermissions` ile yetki farkı). Ayrı bir uzman/hekim detay modalı YOKTUR.
- `FirmalarimList` (uzman/hekim ortak) satır tıklamasında Shared Detail Modal açar; yeni göz/detay ikonu veya drawer YOK.

### AW4. Doğrulanamayan (BLOCKED — PASS demiyorum)

- Gerçek authenticated E2E (uzman/hekim hesabıyla atanmış firma detayı + gereksinim + hekim filtresi + IDOR/cross-OSGB reddi) gerçek hesap olmadan koşulamadı; mantık + RLS SQL seviyesinde doğrulandı.
- Evrak bağlantılı geçerlilik durumu canlı testi: `evraklar` 0 kayıt; resolver kodda hazır, belge bağlandığında otomatik çalışır.

### AW5. Bilinçli Kapsam Dışı (sahte veri ile doldurulmadı)

Personeller/Evraklar/Saha Denetimleri/Ekipmanlar/Tutanaklar sekmeleri firma detayına bu promptta EKLENMEDİ (her biri ayrı salt-okunur modül wiring'i gerektirir; spec "hazır olmayan içeriği sahte veriyle oluşturma" der). Mevcut OSGB Firma Detay davranışı bozulmadı.

---

## AX. PERSONELLER — PERSONEL TÜRLERİ + UZMANLIK SINIFLARI (OSGB YÖNETİM / PROMPT 1)

> Amaç: OSGB → Personeller yapısını, mevcut davet/panel/rol akışını bozmadan İSG Uzmanı (A/B/C) + İşyeri Hekimi + DSP personel türlerini destekleyecek şekilde sağlamlaştırmak. Yeni paralel personel/uzman/hekim/DSP tablosu YOK; yeni rol/panel YOK; yeni modal/drawer/listing motoru YOK. KİLİTLİ AYRIM: **A/B/C bir uzmanlık NİTELİĞİDİR, kullanıcı rolü DEĞİLDİR** — üçü de aynı Uzman Paneline, İşyeri Hekimi + DSP aynı Hekim Paneline girer.

### AX1. Veri Modeli (mevcut `personeller` genişletildi)

- `personeller.personel_turu` CHECK'i `isg_uzmani`/`isyeri_hekimi`/`dsp` olarak genişletildi (DROP+ADD CONSTRAINT).
- Yeni `personeller.uzmanlik_sinifi` (text nullable) + CHECK `uzmanlik_sinifi IS NULL OR IN ('A','B','C')` + cross-field CHECK `personel_turu='isg_uzmani' OR uzmanlik_sinifi IS NULL` → uzman olmayana A/B/C atanamaz (DB invariant).
- Mantık: `uzman` → A/B/C; `hekim`/`dsp` → `uzmanlik_sinifi` NULL. Mevcut 5 uzman kaydında sınıf bilgisi olmadığı için NULL korunur (rastgele A/B/C ATANMAZ), UI "—" gösterir.

### AX2. Rol/Panel Eşlemesi (değişmedi, DSP eklendi)

- `personel-hesap` edge function `turuRoleMap`: `isg_uzmani→uzman`, `isyeri_hekimi→hekim`, `dsp→hekim`. Rol her zaman personel türünden server-side türetilir (frontend role güvenilmez). DSP→`role='hekim'` → Hekim Paneli. Yeni rol değeri YOK.

### AX3. UI (SharedUICore)

- `personelService`: `PersonelTuru`+'dsp', `UzmanlikSinifi` tipi + `UZMANLIK_SINIFI_OPTIONS` + `uzmanlikSinifiLabel`, `uzmanlik_sinifi` kolon + `sinif` listeleme filtresi.
- `NewPersonelModal`: İSG Uzmanı seçilince "Uzmanlık Sınıfı" (A/B/C) zorunlu görünür; Hekim/DSP'de gizlenir + NULL.
- `EditPersonelModal`: aynı sınıf alanı + **aktif hesabı (profile_id) olan personelin türü kilitlenir** (`turuLocked`) — uzman↔hekim rol dönüşümü engellenir (sınıf değişimi serbest).
- `PersonelDetailModal`: sınıf başlık kartı badge + Genel Bilgiler satırı; `roleFromTuru` DSP→hekim.
- `page.tsx`: "Uzmanlık Sınıfı" kolonu + filtre (A/B/C); tür filtresine DSP eklendi.

### AX4. Güvenlik / Korunan (değiştirilmedi)

Mevcut davet akışı (`davetler` token/status/expiration, accept-invite, profile/role/osgb bağlantısı, panel yönlendirmesi), duplicate Auth/invite koruması, cross-OSGB/IDOR RLS'leri `USING(true)` olmadan korunur. Şifre hiçbir yerde loglanmaz/saklanmaz.

### AX5. BLOCKED (PASS demiyorum)

Gerçek authenticated E2E (A/B/C uzman + Hekim + DSP oluştur → davet → kabul → doğru panele yönlenme) gerçek hesap olmadan koşulamadı; mantık + SQL constraint'leri doğrulandı. Atamalar/ziyaret/süre/kapasite/evrak modüllerine DOKUNULMADI (kapsam dışı).

---

## AY. ATAMALAR — PROFESYONEL GEREKSİNİM + ÇALIŞAN SAYISI + UYGUNLUK TEMELİ (OSGB YÖNETİM / PROMPT 2)

> Amaç: Atamalar sisteminin temelini kurmak — firma çalışan sayısı + tehlike sınıfı + profesyonel türüne göre gerekli profesyonel görevlendirme. Yeni paralel atama/assignment/rule-engine tablosu YOK; mevcut merkezi `isg_kurallari` + `gereksinim-hesapla` kullanılır. KİLİTLİ AYRIM: **required_quantity (adet) ≠ required_service_minutes (hizmet süresi)**; hizmet süresi ayrı domain'dir, atama ayrı domain'dir, ziyaret ayrı domain'dir; hukuki hesap frontend'e hardcode EDİLMEZ.

### AY1. Merkezi Kural Motoru Zenginleştirme (`isg_kurallari`)

- Yeni `professional_type` kolonu (nullable text): `isg_uzmani` / `isyeri_hekimi` / `dsp`. 3 profesyonel kuralı backfill edildi (ISG_UZMANI/ISYERI_HEKIMI/DIGER_SAGLIK_PERSONELI).
- `calculation_definition` merkezi olarak genişletildi (frontend'de sabit sayı YOK):
  - **İSG Uzmanı:** `by_hazard` (10/20/40 dk) + `full_time_threshold_by_hazard` (1000/500/250) + `sinif_uygunluk` (A→az+tehlikeli+cok, B→az+tehlikeli, C→az).
  - **İşyeri Hekimi:** `by_hazard` (5/10/15 dk) + `full_time_threshold_by_hazard` (2000/1000/750).
  - **DSP:** `hazards` (tehlikeli+cok_tehlikeli) + `employee_count_min=10` + `stepped_minutes` (10–49:10 / 50–249:15 / 250+:20 dk) + `hekim_tam_sureli_istisna=true`.

### AY2. required_quantity ↔ required_service_minutes Ayrımı

- `firma_gereksinimleri.required_service_minutes` + `professional_type` kolonları; `isg_gereksinim_snapshot.required_service_minutes` kolonu eklendi.
- `computeRequired` artık `{qty, serviceMinutes}` döndürür: `per_employee_minutes` → `serviceMinutes=n*rate` + `qty=ceil(n/full_time_threshold)`; `stepped_minutes` → `serviceMinutes=n*band` + `qty=1`; sayı-bazlı modlar `qty` üretir, `serviceMinutes=null`.
- `hazards` listesi applicability filtresi eklendi (DSP tehlikeli+cok_tehlikeli daraltır). `hekim_tam_sureli_istisna` metadata'ya taşındı (çözümü hizmet-süresi domain'i olmadığı için sonraki faza).

### AY3. Uygun Personel Havuzu (uzman A/B/C uygunluğu)

- `assignmentService.fetchUzmanSinifUygunluk()` + `isUzmanSinifUygun()` — merkezi `sinif_uygunluk` matrisini `isg_kurallari`'dan okur (frontend'de sabit eşleme YOK).
- `fetchAtamaPersoneller(tur, firmaHazardClass?)` uzman seçilip firmanın tehlike sınıfı biliniyorsa UYGUN OLMAYAN sınıftaki uzmanları havuzdan çıkarır; `personel_turu` + `uzmanlik_sinifi` döndürür.
- `fetchAtamaFirmalar()` artık `tehlike_sinifi` döndürür; `NewAtamaModal` firma→personel sırasına alındı, uzman sınıfı seçenek etiketinde gösterilir.

### AY4. Korunan / Değiştirilmeyen

`atamalar` tablosu + `atama_turu` CHECK (`uzman`/`hekim`) + `atama_create` RPC + `atama_validate`/`atama_lock_scope` trigger'ları değiştirilmedi (DSP `personel_turu='dsp'` → `role='hekim'` eşlemesiyle mevcut atama yapısı üzerinden çözülür). RLS `USING(true)` eklenmedi; cross-OSGB/IDOR korunur. Ziyaret/planlama/gezici/süre modüllerine DOKUNULMADI.

### AY5. Bilinçli Kapsam Dışı / BLOCKED

- **DSP'nin ayrı `atama_turu` olarak modellenmesi** + **"gereksinimi karşılayan vs toplam atama"** sayımı (yardımcı atama) sonraki faz — `professional_type`/`required_service_minutes`/`sinif_uygunluk` veri temeli hazır.
- **Hekim tam süreli istisnasının çözümü** hizmet-süresi domain'i olmadığı için ertelendi (kural merkezde, çözüm sonraki faz).
- Gerçek authenticated E2E (çalışan sayısı→NACE→tehlike→rule engine→profesyonel gereksinimi→uygun havuz→atama) gerçek hesap olmadan koşulamadı; mantık + SQL seviyesinde doğrulandı. Build temiz.

---

## AZ. ATAMALAR — GEREKSİNİMİ KARŞILAYAN AKTİF ATAMALAR + CURRENT_QUANTITY + EKSİK (OSGB YÖNETİM / PROMPT 3)

> Amaç: Prompt 2'deki merkezi profesyonel gereksinim temelini gerçek atamalara bağlamak. `required_quantity → aktif+uygun+geçerli atama → current_quantity → remaining_quantity → status` zincirini gerçek veriyle çalıştırmak. Yeni paralel atama/assignment/requirement tablosu YOK. KİLİTLİ AYRIM: **current_quantity ≠ toplam aktif atama**; hizmet süresi bu hesaptan AYRIDIR; hukuki hesap merkezi rule engine'dedir.

### AZ1. current_quantity'nin Kaynağı (evrak → ATAMA)

Önceki durumda `gereksinim-hesapla` `current_quantity`'yi EVRAK sayısından (`coveringDocs.length`) hesaplıyordu. Artık profesyonel tür bazlı 3 kural (isg_uzmani/isyeri_hekimi/dsp) için kaynak gerçek AKTİF + UYGUN + GEÇERLİ atamalardır; diğer (evrak bazlı) gereksinimler mevcut evrak sayım mantığını korur.

- `countSatisfyingAtamalar(profType, hazardClass, personeller, sinifUygunluk)` eklendi:
  - `isg_uzmani` → `personel_turu='isg_uzmani'` + `uzmanlik_sinifi` merkezi A/B/C matrisine göre firma tehlike sınıfına UYGUN.
  - `isyeri_hekimi` → yalnızca `personel_turu='isyeri_hekimi'` (DSP hekim SAYILMAZ).
  - `dsp` → yalnızca `personel_turu='dsp'` (hekim gereksinimini KARŞILAMAZ).
- Atama havuzu: `atamalar` (firma + `is_active` + `bitis_tarihi NULL veya >= bugün`) → personel_id'ler **Set ile tekil** (duplicate aktif atama 1 kez sayılır) → `personeller` (`is_active` + `isten_cikis_tarihi IS NULL`).
- `sinif_uygunluk` merkezi olarak `isg_kurallari` ISG_UZMANI `calculation_definition.sinif_uygunluk`'tan okunur (frontend'de sabit eşleme YOK).

### AZ2. remaining_quantity + status (merkezi, frontend hesabı yok)

- `remaining_quantity = MAX(required_quantity - current_quantity, 0)` — negatif OLMAZ; `current > required` ise 0.
- `status` mevcut değerlerle korunur (`met`/`missing`/`not_applicable`/`verification_required`): `required=0` → not_applicable; `current=0` → missing; `0<current<required` → missing; `current>=required` → met. `partial`/`fulfilled` isimleri ÜRETİLMEZ (mevcut status yapısı korunur).
- Profesyonel kurallarda evrak geçerliliği (`gecerlilik_durumu`) uygulanmaz (`null`) — karşılama ATAMAYA bağlıdır; evrak geçerliliği ayrı domain.

### AZ3. UI (SharedUICore, yeni tablo/modal/drawer YOK)

- `atama_list` RPC'sine `p.uzmanlik_sinifi` eklendi (genişletici; davranış bozulmadı).
- `assignmentService`: `PersonelTuru` + `PERSONEL_TURU_LABEL` + `personelTuruLabel`/`uzmanlikSinifiLabel`; `AtamaListRow`/`AtamaListData`'ya `personelTuru`+`uzmanlikSinifi` eklendi (atama_turu'dan FARKLI gerçek profesyonel tür).
- `atamaUi.personelTuruBadgeVariant`: uzman=info, hekim=accent, **dsp=warning** (ayrı tür olduğu görünür).
- `page.tsx` "Tür" kolonu → "Profesyonel" (profesyonel tür + uzman sınıf badge); mobil kart badge'i profesyonel türe çevrildi.
- `AtamaDetailModal`: başlık + satırlar profesyonel tür + uzmanlık sınıfı gösterir.

### AZ4. Korunan / Değiştirilmeyen

`atamalar` tablosu + `atama_turu` CHECK (`uzman`/`hekim`) + `atama_create`/`atama_update`/`atama_deactivate` RPC'leri + `atama_validate`/`atama_lock_scope`/`atama_prevent_delete` trigger'ları DEĞİŞTİRİLMEDİ. RLS `USING(true)` YOK; cross-OSGB/cross-firma/IDOR kapalı. DSP `profiles.role='hekim'` korunur; yeni Auth role YOK. Ziyaret/planlama/hizmet süresi/kapasite modüllerine DOKUNULMADI. Hizmet süresi (`required_service_minutes`) bu hesaptan ayrı kalır.

### AZ5. BLOCKED (PASS demiyorum)

Gerçek authenticated E2E (uzman A/B/C uygun/pasif/yanlış-sınıf + hekim + DSP atamalarının current_quantity'ye etkisi, çalışan sayısı/NACE değişiminde yeniden değerlendirme) gerçek hesap olmadan koşulamadı; mantık + SQL seviyesinde doğrulandı. Mevcut firma_gereksinimleri satırlarındaki eski (Prompt 2 öncesi) dakika-değerleri bir sonraki yeniden hesaplamada upsert ile düzelir — eski kayıt silinmez. Build temiz.

---

## BA. ATAMALAR — ATAMA YAP PROFESYONEL TÜRÜ + A/B/C + DSP + SAHA UZMANI AKIŞI (OSGB YÖNETİM / PROMPT 4)

> Amaç: Atama Yap modalını gerçek iş akışına taşımak — 3 profesyonel türü (İSG Uzmanı/İşyeri Hekimi/DSP), uzman A/B/C sınıf seçimi, Saha Uzmanı (operasyonel helper) seçimi. Yeni atama sistemi YOK; mevcut `atamalar` + `atama_create` + `atama_turu` + RLS korunur. KİLİTLİ AYRIM: **primary (yasal gereksinimi karşılayan) ≠ helper (Saha Uzmanı — operasyonel, yasal gereksinimi KARŞILAMAZ)**; panel hesabı atama kriteri DEĞİLDİR.

### BA1. Veri Modeli (mevcut `atamalar` genişletildi)

- Yeni `atamalar.assignment_role` kolonu (`text NOT NULL DEFAULT 'primary'`) + CHECK (`primary`/`helper`). Bu bir DURUM değil, atama NİTELİĞİDİR (gereksinimi karşılayan vs yardımcı).
- `atama_turu` CHECK (`uzman`/`hekim`) DEĞİŞTİRİLMEDİ — DSP `personel_turu='dsp'` → `atama_turu='hekim'` (profiles.role='hekim') eşlemesiyle mevcut yapıdan çözülür; yeni Auth role YOK.

### BA2. Atama Yap Modalı (SharedUICore, yeni modal/drawer YOK)

Akış: Firma → Profesyonel Türü (İSG Uzmanı/İşyeri Hekimi/DSP) → (uzman ise) Uzmanlık Sınıfı A/B/C → Personel → (uzman ise) Yardımcı sorusu + merkezi uygunluk gösterimi → Kaydet.

- Profesyonel türü 3 seçenek gerçekten UI'da görünür; seçim personel havuzunu `personel_turu` üzerinden daraltır (isg_uzmani / isyeri_hekimi / dsp AYRI).
- A/B/C seçimi gerçek `personeller.uzmanlik_sinifi`'den filtreler (frontend sınıf UYDURMAZ); hekim/DSP'de A/B/C alanı GÖRÜNMEZ.
- Yardımcı sorusu yalnızca İSG Uzmanı için (Radio Hayır/Evet). Hekim/DSP'de YOK.
- Uygunluk gösterimi: seçilen uzmanın merkezi A/B/C matrisine göre firma tehlike sınıfına uygunluğu bilgi amaçlı işaretlenir (`sinifUygun`), engel DEĞİL — asıl kontrol backend'de.

### BA3. Backend (`atama_create` RPC genişletildi)

- `p_assignment_role` parametresi (default `'primary'`). Rol eşleşmesi yine `personel_turu` üzerinden (panel hesabı şartı YOK).
- **Primary İSG Uzmanı:** merkezi `sinif_uygunluk` matrisi (`isg_kurallari`) ile firma `tehlike_sinifi`na uygun olmayan uzman `INVALID_EXPERT_CLASS` ile REDDEDİLİR (frontend'e güvenilmez).
- **Helper:** yalnızca `isg_uzmani` için geçerli (`INVALID_HELPER_ROLE`); merkezi `helper_eligibility` kuralı TANIMLI DEĞİLSE `HELPER_RULE_NOT_DEFINED` ile REDDEDİLİR — hukuki helper yetkisi UYDURULMAZ.
- `atama_list` RPC'sine `assignment_role` döndürme eklendi (genişletici).

### BA4. Merkezi Helper Eligibility Durumu (dürüst, uydurma yok)

Merkezi `isg_kurallari` ISG_UZMANI kuralında `helper_eligibility` alanı TANIMLIDIR. Bu yüzden:
- Saha Uzmanı (helper) ataması backend `atama_create` tarafından kabul edilir; `helper_eligibility` matrisi sınıf/tehlike uygunluğunu server-side doğrular.
- Helper/primary veri modeli (`assignment_role`) aktiftir ve tek yerden yönetilir. Saha Uzmanı operasyonel bir görevdir; gereksinim motoru helper kayıtlarını ASLA yasal mevcut sayısına dahil ETMEZ.

### BA5. UI Gösterimi (SharedUICore)

- `assignmentService`: `AssignmentRole` + `assignmentRoleLabel` ("Gereksinimi Karşılayan Uzman"/"Saha Uzmanı") + `fetchHelperEligibility` + `fetchAtamaPersoneller(personelTuru, firmaHazardClass, uzmanSinif)` 3 parametreli.
- `atamaUi.assignmentRoleBadgeVariant`: primary=success, helper=warning.
- `page.tsx` "Profesyonel" kolonuna uzman için atama niteliği badge'i eklendi; `AtamaDetailModal` "Atama Niteliği" satırı (yalnızca uzman).

### BA6. Korunan / Değiştirilmeyen

`atamalar` mevcut kayıtları, `atama_turu` CHECK, `atama_update`/`atama_deactivate` RPC'leri, `atama_validate`/`atama_lock_scope`/`atama_prevent_delete` trigger'ları, RLS (`USING(true)` YOK), cross-OSGB/IDOR, DSP `role='hekim'`, ziyaret/planlama/hizmet süresi/kapasite modülleri — DOKUNULMADI. Hizmet süresi (`required_service_minutes`) bu hesaptan AYRI kalır.

### BA7. BLOCKED (PASS demiyorum)

Gerçek authenticated E2E (firma→tür→A/B/C→personel→yardımcı sorusu→uygunluk→atama; helper kural-yok reddi; uygun olmayan uzmanın primary reddi) gerçek hesap olmadan koşulamadı; mantık + SQL + RLS seviyesinde doğrulandı. **Helper akışı merkezi `helper_eligibility` kuralı tanımlanana kadar bilinçli REDDEDİLİR** (TEST 21/22'deki "gerçekten helper atanabilen uzman" senaryosu BLOCKED — kural yok). Build temiz.

---

## BB. ATAMALAR — ÜST LİMİT YOK + YENİDEN HESAPLAMA TETİKLERİ + HELPER DIŞLAMA (OSGB YÖNETİM / PROMPT 5)

> Amaç: `required_quantity`'nin ATAMA ÜST LİMİTİ OLMADIĞINI garantiye almak; çalışan sayısı/NACE değişiminde merkezi yeniden hesaplamayı ve atama değişiminde requirement güncellemesini tetiklemek; helper (yardımcı) atamaların `current_quantity`'ye dahil EDİLMEMESİNİ sağlamak. Yeni paralel sistem YOK. KİLİTLİ KURAL: **required_quantity = asgari sayı, azami DEĞİL**; `current_quantity` onu aşabilir; `remaining = MAX(required - current, 0)`; atamalar otomatik SİLİNMEZ; hukuki hesap merkezi rule engine'dedir.

### BB1. Doğrulanan Sağlam Katmanlar (değiştirilmedi)

- `current_quantity` zaten aktif+uygun atamalardan sayılıyor, ÜST LİMİT YOK (AZ'den gelen davranış korundu).
- `remaining_quantity = MAX(required - current, 0)` — negatif OLMAZ; `current > required` ise 0.
- `atama_create` RPC'de `required`/`limit`/`max` kontrolü YOK — yalnızca overlap (mükerrer aktif atama) kontrolü. `required_quantity` üst limit DEĞİL.
- Çalışan sayısı/NACE/tehlike/personel değişimi trigger'ları (`firma_isg_girdi_degisim` + `personel_isg_girdi_degisim` + `firma_nace_hazard_sync`) mevcut ve `isg_girdi_degisti` flag'ini doğru set ediyor.
- Atamalar hiçbir yerde otomatik silinmiyor (soft-state, fiziksel silme yok).

### BB2. Kapatılan Boşluklar (3)

1. **Atama değişiminde requirement güncelleme (bölüm 42) — trigger YOKTU.** `atama_isg_girdi_degisim` trigger'ı eklendi (AFTER INSERT/DELETE/UPDATE on `atamalar`): `is_active`/`bitis_tarihi`/`baslangic_tarihi`/`personel_id`/`firma_id`/`assignment_role`/`atama_turu` değişiminde ilgili firmanın (ve firma taşınmışsa eski firmanın) `isg_girdi_degisti = true` yapılır. Böylece atama oluştur/pasifleştir/sonlandır → merkezi yeniden hesaplama tetiklenir.
2. **Merkezi kural değişiminde tüm firmaları flag (bölüm 41/8) — trigger YOKTU.** `isg_kural_degisim` trigger'ı eklendi (AFTER INSERT/DELETE/UPDATE on `isg_kurallari`): tüm aktif arşivsiz firmalar `isg_girdi_degisti = true` yapılır.
3. **Helper ataması `current_quantity`'ye sızıyordu (bölüm 13/16/43).** `gereksinim-hesapla` artık atamaları `personel_id, assignment_role` ile çeker; `assignment_role = 'helper'` kayıtları current_quantity havuzundan ÇIKARILIR (dedup öncesi). Böylece "Karşılayan 5 + Yardımcı 2 = current 5" ayrımı doğru çalışır.

### BB3. UI (değiştirilmedi)

`IsgGereksinimleriTab` `Miktar` bileşeni "Mevcut" değerini ham `current_quantity` olarak gösterir (görsel üst kırpma YOK) — bölüm 37'nin görsel tarafı doğrulandı. Yeni UI/modal/tablo/drawer YOK.

### BB4. Korunan / Değiştirilmeyen

`atamalar` kayıtları + `atama_turu` CHECK + `atama_create`/`atama_update`/`atama_deactivate` RPC'leri + mevcut trigger'lar + RLS (`USING(true)` YOK) + cross-OSGB/IDOR + DSP `role='hekim'` + ziyaret/planlama/hizmet süresi/kapasite modülleri — DOKUNULMADI. Hizmet süresi (`required_service_minutes`) bu hesaptan AYRI kalır; atama üst limiti oluşturacak hiçbir kısıt EKLENMEDİ.

### BB5. BLOCKED (PASS demiyorum)

Gerçek authenticated E2E (5 uygun uzman → current=5 vs required=3 → remaining=0; yardımcı atama → current değişmez; atama pasifleştirme → current düşer; çalışan sayısı/NACE değişimi → yeniden hesaplama) gerçek hesap olmadan koşulamadı; mantık + SQL + RLS seviyesinde doğrulandı. Helper exclusion şu an fiilen no-op (helper ataması `helper_eligibility` kuralı yokken oluşturulamıyor) ancak kural tanımlandığında doğru sayım için önden düzeltildi. Build temiz.

---

## BC. ZİYARET SİSTEMİ — YENİDEN KURGULAMA (PLAN TİPLERİ + İZİN + OPERASYON + UI)

> Amaç: Mevcut ziyaret planlama/ziyaret modülünü gerçek saha ihtiyaçlarına göre yeniden kurgulamak. İnceleme sonucu mevcut sistemde kritik eksikler tespit edildi (24:00 otomatik kapanış kurulu DEĞİL, süresiz plan otomatik yenilenme YOK, haftalık istisna UI'ı YOK, "tam zamanlı" tek firma ile sınırlı). Bu bölüm netleşen hedef modeli ve faz planını KİLİTLER. Henüz UYGULANMADI — sıradaki geliştirme bu plana göre yapılacak.

### BC1. Kavram Kilidi (yeni model)

- **Bir personel iki plan tipinden SADECE BİRİNDE olabilir:** `gün_bazlı` (haftalık takvim) veya `süre_bazlı` (aylık saat). İkisi aynı anda ASLA olmaz.
- **Gün bazlı** = şimdiki "tam zamanlı" ama ÇOK FİRMALI: haftanın her günü için hangi firmada + hangi saatte çalışılacağı belli; aynı gün içinde saat dilimli birden fazla firma olabilir (Pzt 08-12 A, 12-18 B).
- **Süre bazlı** = şimdiki "gezici": firma başına aylık saat (A 50, B 20). Aylık saat DEVREZ; her ay bağımsız.
- Mutual exclusion: süre bazlı çalışana gün bazlı eklenmeye çalışılırsa "bu kişi süre bazlı çalışıyor" uyarısı (ve tersi).

### BC2. Nihai Madde Listesi (10 madde)

1. İki plan tipi + birbirini dışlama kuralı (BC1).
2. Gün bazlı çok firmalı + aynı gün içinde saat dilimli çok firma.
3. Süre bazlı aylık saat + devretme YOK + her ay ayrı.
4. Yıllık izin: kişiye bağlı, takvimden tek tek gün seçimi, ileri tarihli, tüm planlarını etkiler.
5. Haftalık gün değişimi istisnası: herhangi gün ("Pzt izin, Salı mesai"), gelecek hafta için de planlanabilir.
6. 24:00 otomatik kapanış: bitirilmeyen gün bazlı ziyaret gün sonunda sistem tarafından kapatılır + sonra uzman/hekim gerekçe yazar.
7. Yanlışlıkla başlat/bitir → "geri al" (gerekçeli, aynı gün, audit loglu; saat düzeltmesi DEĞİL).
8. Süresiz plan otomatik yenilenme: 60 günlük üretim penceresi kendini otomatik uzatır.
9. Listeleme: firma bazlı (her firma tek satır) + planlama/takip TEK sayfada birleşik.
10. Plan öncesi günleri gizle: hafta başındaki boş günler "Plan yok" göstermez.

### BC3. Ek Kararlar

- **Veri taşıma:** Mevcut tanımlı tam zamanlı/gezici planlar yeni "gün bazlı/süre bazlı" modeline bozulmadan taşınmalı (eski planlar çökmemeli).
- **Audit log:** İzin, gün değişimi, geri alma işlemlerinin tamamı `system_logs`'a yazılmalı (kim/ne zaman/ne değiştirdi).
- **Geri alma (madde 7) kuralları:** yalnızca aynı gün; gerekçe zorunlu; yalnızca ziyaretin sahibi (uzman/hekim) veya OSGB; GPS/geofence şartı ARANMAZ; audit loglu. Yanlışlıkla bitirildi → `gerceklesti→devam_ediyor` (bitiş/süre/erken-çıkış temizlenir); yanlışlıkla başlatıldı → `devam_ediyor→planlandi` (başlangıç temizlenir).
- **Yıllık izin + süre bazlı etkileşimi:** şimdilik "aylık süreden düşülmez" yönünde karar verildi, ancak bu nokta AÇIK (kullanıcıyla Faz 2'de netleştirilecek).

### BC4. Faz Planı (3 faz)

**Faz 1 — Planlama çekirdeği (veri modeli + UI birlikte):**
- İki plan tipi + mutual exclusion (madde 1)
- Gün bazlı çok firmalı + saat dilimli (madde 2)
- Süre bazlı aylık saat (madde 3)
- Firma bazlı tek sayfa listeleme (madde 9)
- Plan öncesi günleri gizle (madde 10)
- Mevcut veri taşıma (BC3)

**Faz 2 — İzin & esneklik:**
- Yıllık izin (madde 4)
- Haftalık gün değişimi istisnası (madde 5)

**Faz 3 — Operasyonel doğruluk:**
- 24:00 otomatik kapanış + gerekçe (madde 6)
- Yanlışlıkla başlat/bitir → geri al (madde 7)
- Süresiz plan otomatik yenilenme (madde 8)

### BC5. Bilinçli Kapsam Dışı / Açık Noktalar

- Yıllık iznin süre bazlı aylık saatten düşülüp düşülmeyeceği AÇIK (Faz 2'de netleşecek).
- Veri modeli detayları (çok-firmalı gün yapısının tablo şeması: `calisma_program_gunleri` → `calisma_program_versiyon_gunleri`'ne `firma_id` + saat dilimi desteği) Faz 1'de netleştirilip uygulanacak.
- Shared UI/Modal/Listing/Mobile/Theme motorları DEĞİŞTİRİLMEZ; bu kurgu mevcut SharedUICore üzerinden kurulur.

---

## BD. FİRMA PERSONELLER + PERSONEL EKLE MODALI (FAZ 2 — TAMAMLANDI)

> Amaç: FAZ 1'de kurulan personel veri altyapısını UI katmanına taşımak. Firma Paneli → Personeller ekranı + 3 adımlı Personel Ekle modalı. Yeni paralel personel evreni YOK; tek gerçek kaynak `personeller`. İSG motoru + Ziyaretler modülüne DOKUNULMADI.

### BD1. Veri Modeli (minimal, geriye dönük uyumlu)

- `personeller`'e `sicil_no` (text) + `dogum_tarihi` (date) eklendi (nullable). Yeni tablo değil.
- Yeni `personel_saglik_muayeneleri` tablosu: `personel_id` (FK), `muayene_tarihi` (date), `yenileme_tarihi` (nullable — merkezi validity motoru doldurur). Sağlık muayenesi EĞİTİM olarak modellenmez; Sağlık Raporu ayrıca `evraklar` (personel evrakı) olarak gider.
- `evrak_turleri`'ne 5 personel belge tipi seed: MYK / Operatör Belgesi / İSG Eğitim Belgesi / Sağlık Raporu / Diğer.

### BD2. RLS (minimal policy, USING(true) YOK)

- `personeller_insert_firma` — firma yalnızca kendi `firma_id`'sine personel ekleyebilir.
- `personel_egitim_insert_firma` — firma kendi personelinin eğitimini ekleyebilir.
- `personel_saglik_select/insert_(admin/osgb/firma)` — sağlık muayene kapsamı.
- `evraklar_select_firma_personel` — firma kendi personelinin evraklarını görebilir (owner_type='personel' + EXISTS personel firma eşleşmesi).

### BD3. Evrak Edge Function (minimal genişletme)

`evrak` edge function'ı firma→personel evrak yüklemesini destekler hale getirildi: firma `ownerType='personel'` için yalnızca `personel.firma_id === caller.firma_id` ile yükleyebilir (cross-firma kapalı). Mevcut firma-evrakı davranışı korunur.

### BD4. UI (SharedUICore)

- `src/pages/firma/personeller/page.tsx` — gerçek liste (server-side search/filter/sort/pagination, `Table` + `FilterBar` + `Pagination` + `SharedListCard` mobil kart).
- `PersonelEkleModal` — 3 adımlı wizard (`WizardStepper`): Genel Bilgiler (ad/soyad/tc/sicil/doğum/telefon/e-posta/görev/işe giriş) → Eğitim & Sağlık (İSG Eğitim + Sağlık Muayene tarihi) → Personel Evrakları (belge tipi + `FileUpload`). `osgb_id`/`personel_turu` frontend'den gönderilmez; `personel_validate_firma` trigger'ı türetir.
- `FileUpload` `UploadFile`'a `raw?: File` eklendi (geriye dönük uyumlu — gerçek sunucu yüklemesi için ham dosya taşınır).
- `personelService`: `gorev/sicil_no/dogum_tarihi` tipleri + `createFirmaPersonel` + `fetchFirmaPersonellerPage` + `createSaglikMuayene`.

### BD5. Bilinçli Kapsam Dışı (sonraki fazlar)

İşten çıkarma UI, Personel Detay, Dijital Personel Dosyası, Personel Arşiv ekranı, yeniden işe alma — FAZ 2'de YAPILMADI (Word yol haritasına göre sonraki fazlar). "İlgili belge (opsiyonel)" ADIM 2'den ADIM 3'e taşındı (belgeler merkezi evrak sisteminden gider, ayrı dosya alanı kopya olurdu). `egitim_turu` ADIM 2'de sabit `temel_isg` tutuldu.

---

## BE. FAZ9 E-POSTA ENTEGRASYONU — ADIM 1 (MERKEZİ MAILSERVICE + PANEL AYARLARI)

> Projenin İLK gerçek e-posta altyapısı. Önceki modüllerde e-posta yoktu (yalnızca form input + Auth e-postaları). Bu faz: merkezi MailService, kullanıcı-bazlı (user-scoped) e-posta bağlantısı, güvenli credential mimarisi, gerçek test gönderimi ve mail log. Tutanaklar/Sihirbaz entegrasyonu BU FAZDA YAPILMADI.

### BE1. Veri Modeli (3 tablo, tek kaynak)

1. **`public.mail_connections`** — hassas OLMAYAN bağlantı metadata'sı: `user_id` (FK auth.users, UNIQUE), `provider` (CHECK: google/microsoft/smtp), `sender_email/sender_name`, `connection_status` (CHECK: disconnected/connected/error), `smtp_host/smtp_port/smtp_secure`.
2. **`public.mail_credentials`** — HASSAS kimlik bilgisi (SMTP username/password, ileride OAuth token). `connection_id` (FK CASCADE, UNIQUE) + `credential` (JSON text). **RLS policy YOK → authenticated hiçbir şekilde okuyamaz/yazamaz; yalnızca service-role edge function.**
3. **`public.mail_logs`** — audit: `sender_user_id`, `recipient_to/cc/bcc`, `subject`, `attachment_ref`, `related_module/related_record_id`, `provider`, `status` (CHECK: pending/sent/failed), `provider_message_id`, `error_code/error_message`, `sent_at`.

### BE2. RLS (USING(true) YOK)

- `mail_connections` + `mail_logs`: yalnızca SELECT (kendi `user_id = auth.uid()`). INSERT/UPDATE/DELETE policy YOK → istemci yazamaz; tüm yazma edge function (service role).
- `mail_credentials`: hiç policy yok → istemciden tamamen kapalı.

### BE3. Edge Function `mail`

Aksiyonlar: `get` (bağlantı, hassas alan hariç), `save-smtp` (validasyon + credential'ı mail_credentials'a yaz), `disconnect` (cascade sil), `test` (gerçek test maili), `send` (merkezi gönderim), `logs`, `oauth-url`/`oauth-callback` (BLOCKED — OAuth client credential yok). Gönderen her zaman `auth.uid()`'den çözülür; istemci sender_email gönderemez/override edemez. `ALLOWED_ROLES = admin/osgb_admin/uzman/hekim`. Credential/password asla loglanmaz (hata mesajları sanitize edilir).

### BE4. SMTP Gönderimi (gerçek)

Deno native minimal SMTP client (`Deno.connectTls`/`Deno.connect` + `Deno.startTls`; Node `net`/`tls` YOK). SSL (465) / STARTTLS (587) / none + AUTH LOGIN. MIME: UTF-8 base64 body, RFC2047 Türkçe konu, multipart/alternative (text+html) ve multipart/mixed (attachment base64 veya storage path'ten çözümleme).

### BE5. Frontend (merkezi servis + ortak UI)

- `src/lib/mail/types.ts` + `errors.ts` + `mailService.ts` — `getConnection/saveSmtpConnection/disconnectConnection/testConnection/sendMail/fetchMailLogs` (tek `mail` edge function'a bağlı).
- `src/components/feature/mail/EmailIntegrationSection.tsx` — ORTAK "E-posta Entegrasyonu" ayarları (sağlayıcı seç → Özel SMTP formu / OAuth bilgilendirme; bağlı durumda test/kes/değiştir + son gönderimler). OSGB Yönetim + Uzman + Hekim panellerinin ayarlarına "E-posta" sekmesi olarak eklendi.

### BE6. Güvenlik

SMTP şifresi/OAuth token localStorage'a yazılmaz, frontend state'te kalıcı tutulmaz, kullanıcıya geri gösterilmez, loglanmaz. Cross-user okuma/yazma engelli (user_id = auth.uid() + mail_credentials RLS'siz). Frontend bundle'da SMTP_PASSWORD/OAUTH_CLIENT_SECRET/REFRESH_TOKEN YOK.

### BE7. BLOCKED (PASS demiyorum)

- **OAuth (Google/Microsoft)** gerçek token exchange — client ID/secret yok; `oauth-url`/`oauth-callback` 501 `OAUTH_NOT_CONFIGURED` döner (dürüst scaffold).
- **Gerçek SMTP test gönderimi** — geçerli bir SMTP hesabı (host/port/user/pass) olmadan doğrulanamadı. Kod gerçek SMTP protokolünü uygular; credential girilince çalışır.
- **Tutanaklar/Sihirbaz entegrasyonu** — BU FAZDA YAPILMADI (sonraki faz; `MailService.send(...)` hazır).

---

## BF. FAALİYET KOŞULU (ACTIVITY ATTRIBUTE) — FİRMA EKLE + MERKEZİ MOTOR ENTEGRASYONU

> NACE bazlı faaliyet koşullarının, mevcut merkezi İSG Gereksinim Motoru'na doğru INPUT olarak aktarılması. KIRMIZI ÇİZGİ: hiçbir mevzuat maddesi/oranı/koşulu uydurulmaz; NACE tek başına bir koşulu "VAR" kabul ETMEZ. Firma Ekle wizard'ının yalnızca ADIM 1'i genişletildi; Konum (Adım 2) ve Hesap Oluşturma (Adım 3) dokunulmadan korundu.

### BF1. Veri Modeli (önceden kurulmuş, bu turda doğrulandı)

- `activity_attributes` — 4 doğrulanmış koşul: `patlayici_ortam` (ATEX), `kimyasal_maruziyet`, `kanserojen_mutajen_maruziyet`, `yuksekte_calisma`. Her biri gerçek `legal_source_id` → `mevzuat_kaynaklari` (Kimyasal 18709, Kanserojen/Mutajen 18695, Yapı İşleri 18928, ATEX 18335 — tümü `verified`, mevzuat.gov.tr). `legal_article` bilinçli NULL (madde uydurulmaz).
- `nace_activity_attributes` — NACE → koşul eşlemesi (yalnızca aday koşulları sunar; zorunluluk DEĞİL).
- `firma_activity_attributes` — firma bazlı `attribute_value` (boolean) + `source` + `verified_at/verified_by/verified_role` + `note`.
- RLS: `activity_attributes`/`nace_activity_attributes` SELECT authenticated (read), write admin; `firma_activity_attributes` SELECT scope'lu (admin/osgb_admin+uzman+hekim kendi OSGB / firma kendi), write admin+osgb_admin.

### BF2. Firma Ekle (Adım 1) — Faaliyet Bilgileri

- `src/lib/activityAttributeService.ts` — `fetchActivityAttributesByNace(naceId)` (NACE'e bağlı aktif + doğrulanmış koşulları mevzuat dayanağıyla okur; eşleme yoksa boş dizi).
- `NewFirmaWizard` Adım 1'de NACE altında "Faaliyet Bilgileri" bölümü: seçilen NACE'e bağlı koşullar checkbox olarak listelenir (her koşulun altında gerçek `Mevzuat:` dayanağı). Koşul yoksa boş checkbox listesi GÖSTERİLMEZ, bilgilendirme notu düşer. NACE değişince liste + seçim sıfırlanır.
- Firma Ekle modalında İSG gereksinim listesi / uyum skoru / önizleme YOKTUR (spec ile tutarlı).

### BF3. Kayıt (firma-davet)

- `CreateFirmaPayload.activity_attribute_ids: string[]` eklendi; `firma-davet` `create` aksiyonu, yalnızca seçili NACE'e gerçekten bağlı (`nace_activity_attributes`) koşulları `firma_activity_attributes`'a `attribute_value=true, source='firma_beyan'` (doğrulanmamış) olarak yazar. IDOR/uydurama engeli sunucuda. Attribute insert hatası firma oluşturmayı BOZMAZ (warning log).

### BF4. Merkezi Motor (değiştirilmedi — bilinçli)

- `gereksinim-hesapla` motorunda koşul-bazlı kural YOKTUR (`isg_kurallari.conditions` tümü NULL). Kırmızı çizgi gereği koşullu kural uydurulmadı; motor, doğrulanmamış/mevcut olmayan koşullar için zaten `verification_required`/`not_applicable` üretir. Faaliyet koşulları, koşul-bazlı kural gerçek mevzuatla tanımlanana kadar motor tarafından değerlendirilmez (doğru davranış).
- "Faaliyet Koşulu Doğrulama (VAR/YOK + audit)" edge function'ı mevcut (OSGB yöneticisi `verified_at/verified_by/verified_role` doldurur).

### BE7-TAMAMLAMA — DOĞRULAMA UI + KOŞULLU EVRAK ENTEGRASYONU

Önceki turda kalan 2 eksik kapatıldı (build geçer, regresyon yok):

1. **Doğrulama UI** — `faaliyet-kosulu-dogrulama` edge function'ı (yerel kodu kaybolmuştu) deterministik slug ile yeniden kuruldu: `list` (NACE'e bağlı koşullar + firma beyanı + doğrulama durumu + mevzuat + append-only tarihçe) ve `verify` (VAR/YOK + not + audit). Yetki: `admin`/`osgb_admin` (kendi OSGB) / `uzman` (firmaya atanmış); `firma`/`hekim`/`dsp` REDDEDİLİR. `firma_activity_attributes` unique `(firma_id, activity_attribute_id)` üzerinde upsert; `system_logs` (`FAALIYET_KOSULU_DOGRULANDI`) append-only audit. Mevcut trigger `firma_activity_attribute_isg_girdi_degisim()` otomatik `isg_girdi_degisti=true` bayraklar. Frontend: `FaaliyetKosullari` + `KosulDogrulamaModal` (Firma Detay → İSG Gereksinimleri), durum backend'den türetilir (Mevcut/Mevcut Değil/Doğrulama Gerekli).
2. **Koşullu evrak** — 4 conditional rule (`PATLAMADAN_KORUNMA_DOKUMANI`/`KIMYASAL_RISK_DEGERLENDIRME`/`KANSEROJEN_MARUZIYET_KONTROL`/`YUKSEKTE_CALISMA_KORUMA`) `DOCUMENT_BASED_CODES`'a eklendi; mevzuat bazlı `evrak_turleri` kayıtları (kategori "Faaliyet Koşulu", code = requirement_code) eklendi; "Evrak Yükle" butonu `not_applicable`/`verification_required` durumlarında gizlenir. Koşullu requirement kartında tetikleyici "Faaliyet Koşulu" etiketi gösterilir. Evrak yükleme mevcut `EvrakUploadModal` + `evrak` edge function üzerinden (yeni motor YOK).

### BF5. Kalan (sonraki faz)

- Firma Detay → İSG Gereksinimleri ekranında faaliyet koşullarının görüntülenmesi + doğrulama UI'ı (VAR/YOK).
- Gerçek mevzuat doğrulaması tamamlanan koşullar için merkezi `isg_kurallari`'na koşul-bazlı kural bağlama (yalnızca resmî kaynak + madde/fıkra/bent doğrulanınca).

---

## BG. ZİYARET RAPORU — GÜN PROGRAMI PDF RENDER DÜZELTMESİ (UI/ÇIKTI TURU)

> OSGB Yönetim > Ziyaretler > Rapor Al > PDF > Gün Programı çıktısının premium, okunabilir ve Excel çıktısıyla görsel tutarlı hale getirilmesi. Yeni PDF motoru / yeni rapor sistemi OLUŞTURULMADI; mevcut `visitPdfDoc.ts` + `visitExcel.ts` + pdfTheme düzeltildi. Veri katmanı (`visitReport.ts`) ve modal (`ZiyaretRaporModal.tsx`) DEĞİŞMEDİ.

### BG1. Kök Nedenler (kapatıldı)

1. **Tablo sayfa genişliğini kullanmıyordu** — AutoTable `tableWidth: 'auto'` sabit genişlikli kolonlarla birlikte tabloyu sayfadan dar bırakıyordu; `tableWidth: contentW` + gün kolonlarına hesaplanmış sabit `cellWidth` verildi → tablo kullanılabilir genişliğin ~%100'ünü dolduruyor.
2. **Gün hücrelerinde ikon karmaşası** — `◐/✓/×/—` glyph'leri kaldırıldı; yerine temiz durum dolgusu (planlanan=soft mavi, gerçekleşen=yeşil, gerçekleşmeyen=kırmızı, plan yok=hafta sonu pembe/boş). Excel de AYNI dolgu mantığına çekildi (`DAY_FILL_HEX`), legend '▉' renk bloklarıyla.
3. **İki ayrı başlık + gereksiz boşluk** — Üstteki ayrı `Ziyaret Raporu` başlığı kaldırıldı; tek `Aylık Ziyaret Raporu - Gün Programı` başlığı + sağda `Dönem: ...` rozeti. Başlık→alt başlık boşluğu daraltıldı.
4. **Legend tabloya değiyordu** — tablo `finalY`'sinden +7mm boşluk sonrası çiziliyor.
5. **Header çok yüksek / logo küçük** — tek dengeli blok: logo 36×17mm alan, kurumsal unvan 15pt, iletişim 9pt, sağda rapor meta 8.5–9pt; altında tek ince ayırıcı.
6. **Büyük boş alan** — satır yükseklikleri (`minCellHeight`) sayfada kalan dikey alana göre dinamik hesaplanır (8–15mm), tablo sayfayı doldurur.

### BG2. Sayfa Düzeni (efektif override)

- Rapor HER ZAMAN **A3 Landscape** + **12 mm kenar boşluğu** ile üretilir (`resolvePdfLayout`). Kullanıcı Portrait/A4/geniş margin seçse bile bu raporda override edilir (okunabilirlik öncelikli). Gerçek jsPDF page config landscape'dir (HTML taklidi değil).
- Diğer bölümler (Süre Bazlı / Detaylı Liste / Özet) `tableWidth: contentW` ile tam genişlik.

### BG3. Dokunulmayanlar (regresyon yok)

Veri katmanı (`visitReport.ts`: durum filtreleri, iptal hariç, duration hesabı), `ZiyaretRaporModal` (dönem/ayar/önizleme/indirme), Excel'in veri/hesap mantığı, diğer rapor türleri (personel raporu), `pdfFont`/`branding`/`layout` korundu. Yeni tablo/edge function/RLS değişmedi.

### BG4. Build

PASS — TypeScript + build hatasız.

---

## BH. ACİL DURUM EYLEM PLANI MODÜLÜ (UZMAN PANELİ — EVRAKLAR)

> Uzman Paneli > Evraklar > Firma Evrakları > Acil Durum > Acil Durum Eylem Planı için mevzuat kontrollü, dinamik plan üretim ve yaşam döngüsü sistemi. Mevcut SharedUICore / Modal / Table / FileUpload / TabBar motorları kullanılır; yeni UI altyapısı OLUŞTURULMADI. Mevcut İSG gereksinim motoru / acil durum ekipleri / evrak / personel sistemleri BOZULMADI.

### BH1. Kavram Kilidi (bozulmaz)

- **Plan üretimi** = firma+nace+tehlike sınıfı+çalışan sayısı+İSG gereksinimleri+mevcut acil durum ekiplerinden beslenen dinamik süreç. Statik belge doldurma DEĞİLDİR.
- **NACE doğrudan mevzuat zorunluluğu değildir**; faaliyet + tehlike sınıfı + risk değerlendirmesiyle birlikte değerlendirilir. Karşılığı doğrulanamayan öneri "sistem önerisi" olarak etiketlenir; mevzuat UYDURULMAZ.
- **Ekipler ikinci kez kurulmaz:** plan sihirbazının ekip adımı ile merkezi "Acil Durum Ekipleri" modülü AYNI kaynağı (`acil_durum_atamalari`) kullanır; sihirbazda yapılan değişiklik merkezde de görünür.

### BH2. Giriş Akışı

`ACIL_DURUM_PLANI` evrak türü seçilince `FirmaEvrakListesi` → `AcilDurumPlaniYonetim` modalı açılır. Yöntem seçimi (Sihirbaz / Dosya). Dosya → mevcut `EvrakUploadModal` (kategori "Acil Durum", `ACIL_DURUM_PLANI` türü → İSG gereksinimi bağlanır). Sihirbaz → 7 adımlı plan oluşturma modalı.

### BH3. 7 Adım

1. İşyeri ve Plan Bilgileri (firma/NACE/tehlike/çalışan otomatik; geçerlilik tarihi tehlike sınıfına göre otomatik: çok tehlikeli 2 / tehlikeli 4 / az tehlikeli 6 yıl).
2. Acil Durumların Belirlenmesi (öneri motoru: risk değerlendirmesi / NACE / sistem; özel senaryo ekleme, düzenle/pasifleştir/sil).
3. Önleyici ve Sınırlandırıcı Tedbirler (senaryo başına otomatik tedbir; durum/sorumlu/termin/açıklama).
4. Acil Durum Ekipleri (merkezi ekip verisi; gerekli kişi sayısı motordan; ekle/çıkar/lider).
5. Müdahale ve Tahliye (müdahale sırası, alarm/tahliye yöntemi, kaçış yolları, toplanma alanı, özel tahliye, kesme noktaları, kroki işaretleme).
6. Tatbikat ve Yenileme (yıllık takvim, senaryo, ekipler, sonuç/düzeltici faaliyet, yenileme sebepleri).
7. Kontrol ve Onay (final kontrol listesi, plan özeti, mevzuat kontrolü, onay → `imza_bekliyor`).

### BH4. Veri Modeli (tek kaynak)

- `public.acil_durum_planlari` — plan başlığı + `icerik` jsonb (senaryolar/tedbirler/müdahale/tahliye/kroki/tatbikat/iletişim/onay) + `durum` (taslak…yayinda/revizyon_gerekli/suresi_doldu/arsiv) + `revizyon_no`. RLS: admin/osgb_admin(kendi osgb)/uzman+hekim(has_active_firma_assignment)/firma(kendi firma).
- `public.acil_durum_plani_revizyonlari` — değiştirilemez revizyon geçmişi (snapshot jsonb).
- `public.acil_durum_plani_belgeleri` — üretilen/imzalı belge bağları (`tur`: olusturulan/imzali).
- Mevcut `personeller`/`acil_durum_atamalari`/`evraklar` tabloları ile FK/ilişki; kopya veri üretilmez. Mevzuat dayanağı gerçek `isg_kurallari` + `mevzuat_kaynaklari`'ndan çekilir.

### BH5. Yaşam Döngüsü

Taslak/Hazırlanıyor → İnceleme → İmza Bekliyor → İmzalı → Yayında; Revizyon Gerekli / Süresi Doldu / Arşiv. Taslak kaydetme revizyon üretmez; "Planı Oluştur ve Onayla" ilk revizyonu yazar ve `imza_bekliyor` durumuna geçer. İmzalı belge yüklenince `yayinda` + revizyon kilidi.

### BH6. Bu Etapta Kalan (sonraki)

Tam kapsamlı plan PDF/Word üretimi (kapak + 34 bölüm + kroki sayfaları), OCR ile dosya analizi doğrulama ekranı, tatbikatın merkezi tatbikat modülüne otomatik kaydı, bildirimler, kroki çizim editörünün gelişmiş sürümü. Mevcut etapta bunlar UYDURULMADI; dürüstçe bırakıldı.

### BH7. Build

PASS — TypeScript + build hatasız.

---

## BI. ACİL DURUM TATBİKATLARI MODÜLÜ (UZMAN PANELİ — EVRAKLAR / ACİL DURUM)

> Evraklar > Firma Evrakları > Acil Durum > **Acil Durum Tatbikatı** kısayolundan açılan, mevcut Evrak sayfası/mimarisini bozmayan, gerçek veri akışlı ve uçtan uca çalışan tatbikat yönetim modülü. Statik listeleme değil; planlama → gerçekleştirme → sonuç → rapor → revizyon yaşam döngüsü.

### BI1. Kavram Kilidi (bozulmaz)

- Tatbikat iki kaynaktan beslenir: **plan bağlı** (`plan_id` dolu, `kaynak='plan'`) veya **harici** (`plan_id` null, `kaynak='harici'`). İkisi TEK tablo/tek kayıttır — duplicate modül YOK.
- Acil Durum Eylem Planı sihirbazının Tatbikat adımı, kaydettiğinde AYNI merkezi tatbikat kaydını oluşturur/günceller; plan detayının "Tatbikatlar" sekmesi de bu kaydı gösterir (çift yönlü ilişki).
- Ekipler/katılımcılar mevcut personel + acil durum ekipleri verisinden seçilir; ikinci personel sistemi oluşturulmaz.
- Mevzuat adına uydurma metin ÜRETİLMEZ; yalnızca gerçek `mevzuat_kaynaklari`/`isg_kurallari` kataloğundan referans gösterilir. Doğrulanamayan bilgi "sistem önerisi" olarak işaretlenir.

### BI2. Veri Modeli (tek kaynak)

- **`public.acil_durum_tatbikatlari`** — ana tablo: `osgb_id`, `firma_id`, `plan_id` (nullable), `plan_revizyon_no`, `ad`, `senaryo`, `tur`, `durum`, `kaynak`, `tarih`, `baslangic`, `bitis`, `yer`, `sorumlu_ad/gorev`, `aciklama`, `revizyon_no`, `icerik` (jsonb: katılımcılar/değerlendirme/kronoloji/eksiklikler/fotoğraflar/belgeler/imzaAlanlari/timeline), `created_by`, zaman damgaları. RLS acil durum deseniyle aynı (admin/osgb_admin/uzman-hekim atama/firma).
- **`public.acil_durum_tatbikat_revizyonlari`** — değiştirilemez revizyon geçmişi (snapshot jsonb).
- Bağlı tatbikat, mevcut `acil_durum_planlari` kaydıyla ilişkilidir — ikinci plan/veri kaynağı OLUŞTURULMAZ.

### BI3. Yaşam Döngüsü + Süreç

- Durumlar: `planlandi → uygulaniyor → sonuc_girildi → raporlandi → tamamlandi` (+ `eksiklik_var`, `iptal`). Geçişler kontrollü; açık kritik eksiklik varsa tamamlama için kullanıcıya uyarı gösterilir.
- Süreç zaman çizelgesi (5 adım) her geçişte kullanıcı/tarih ile damgalanır.
- "Tatbikata X gün kaldı / bugün / tarih geçti – sonuç bekleniyor" hesabı merkezi (`tatbikatZamanDurumu`); sayfa yenilenince korunur.
- Yenileme: çok tehlikeli 2 / tehlikeli 4 / az tehlikeli 6 yıl (sistem kuralı) + değişiklik tetikleyicileri.

### BI4. UI (referans görsel dili)

- Giriş: liste + durum filtre çipleri (Tümü/Planlandı/Gerçekleşti/Eksiklik Var/İptal) + arama + tarih filtresi + tablo (Tarih, Tatbikat Adı/Senaryo, Plan, Durum, Katılımcı, Sonuç) + `+ Tatbikat Planla`.
- Detay modal (Shared Modal): üst bilgi kartları (Durum/Tarih/Senaryo/Plan Bağlantısı/Sorumlu) + 8 sekme (Genel Bakış, Planlama, Katılımcılar, Uygulama, Sonuç ve Değerlendirme, Belgeler, Fotoğraflar, Revizyon) + Tatbikat Süreci timeline + alt action bar (Kapat / Taslak Word İndir / Önizle / Rapor Oluştur / durum aksiyonu).
- Katılımcılar mevcut personelden eklenir; fotoğraf/belge mevcut evrak altyapısına (`evraklar` + storage, `ACIL_DURUM_TATBIKATI` türü) yüklenir ve `evrakId` ile ilişkilendirilir; persist edilir, refresh sonrası gelir.

### BI5. Word Raporu

- `acil-durum-tatbikat-rapor` edge function'ı SUNUCU tarafında gerçek, geçerli `.docx` üretir (kapak, doküman kontrol, tatbikat bilgileri, plan bağlantısı, amaç/kapsam, senaryo, plan, katılımcılar, ekipler, uygulama/zamanlama, değerlendirme, sonuç, eksiklikler, DÖF, fotoğraflar, belgeler, mevzuat kontrolü, revizyon geçmişi, imza alanları, ekler). Sayfa numaralı, header/footer'lı, logolu.
- Logo firma/OSGB ayarından (`osgb.logo_url`) gelir — hardcoded YOK. Her görsel gerçek DOCX relationship'i ile gömülür.
- Üretim öncesi OOXML doğrulaması (ZIP `PK` imzası + zorunlu parçalar) hem frontend hem sunucu tarafında yapılır; bozuk DOCX indirilmez, net hata gösterilir.
- Veri tek normalize edilmiş rapor modelinden (`assembleTatbikatRaporModel`) üretilir — eksik veri nedeniyle Word bozulması engellenir.

### BI6. Entegrasyon

- `FirmaEvrakListesi` → `ACIL_DURUM_TATBIKATI` türü seçilince tatbikat yönetim modalı açılır (`onAcilDurumTatbikatlari`); mevcut kategori ağacı, firma seçici, sidebar, SharedUI korunur.
- `AcilDurumPlaniWizard` → plan kaydında tatbikat adımı merkezi kayda senkronlanır; `AcilDurumPlaniDetayModal` "Tatbikatlar" sekmesi bağlı tatbikatları gösterir.

### BI7. Build

PASS — TypeScript + build hatasız.

---

## BJ. EKİPMANLAR MODÜLÜ — PRODUCTION REVİZE (2026-09-19)

> Araştırma (salt-okunur) + mantıklı revize turu. Amaç: Ekipman modülünü "yayına çıkacakmış gibi" kurmak. Mevzuat uydurma YOK; her zorunluluk merkezi `ekipman_mevzuat_kurallari` (RG/TS EN/ÇSGB referanslı) üzerinden gelir.

### BJ1. Mevzuat Araştırma Özeti (kaydedildi)

- **İş Ekipmanlarının Kullanımında Sağlık ve Güvenlik Şartları Yönetmeliği** — RG 25.04.2013/28628; güncel değişiklik **RG 23.12.2025/33116** (doğrulandı: ÇSGB + TÜYAK).
- **EK-III Tablo-1…Tablo-6** periyodik kontrol kapsamını belirler (basınçlı kap/tesisat, kaldırma-iletme, tesisat, tezgâh, raf/kapı, iş makineleri). İskele + katodik koruma **6 ay**, diğerleri (standart yoksa) **1 yıl**.
- **Asansörler** ayrı mevzuata tabi (Asansör Periyodik Kontrol Yönetmeliği, RG 04.05.2018/30411) — aylık/3 aylık/yıllık ayrı rejim. Modülde kategori olarak HENÜZ YOK.
- **İSG-KATİP** resmî sistem; **EKİPNET** İSG-KATİP içi modül (23.12.2025 ile netleşti). **Resmî public API/web servis dokümantasyonu BULUNAMADI** → gerçek entegrasyon yok; yalnızca kayıt no/sözleşme belgesi tutulur (varsayım yapılmadı).
- Akreditasyon zorunlu 4 grup (Ek Madde 2, RG 18.02.2022/31754): kule kren, LPG tank/tesisat, yürüyen merdiven, asılı erişim donanımı.

### BJ2. Bu Turda Kapatılan Üretim Boşlukları

1. **"Kalan gün" + "Güncelle" akışı** — `getPeriodicControlTimeStatus` zaten merkezi (takvimsel, Türkiye saati). Eksik olan aksiyon eklendi: detay modalında süre **geçmiş/bugün** olduğunda (ve mevzuat kontrol zorunluysa) başlık + uyarı bandında **"Kontrolü Güncelle"** butonu belirir → `KontrolEkleModal` açar. Yeni kontrol **append-only history** (`ekipman_periyodik_kontrolleri`) olarak eklenir; eskisi geçmişte korunur, `sonraki_kontrol_tarihi` en güncel kayıttan türer.
2. **Mevzuat bilgisi detayda** — Genel sekmesine `Mevzuat Bilgileri` kartı eklendi: kontrol gerekliliği (zorunlu/opsiyonel), periyot, yetkili kişiler, zorunlu belgeler + kaynak referansı.
3. **Eksik uyarısı** — mevzuat kontrolü **zorunlu** kılıyor ama hiç kontrol kaydı yoksa detay modalında "Periyodik kontrol kaydı yok" uyarısı + "Kontrol Ekle" aksiyonu gösterilir.
4. **Kontrol modalı mevzuata bağlandı** — `KontrolEkleModal` artık `kural` alır: periyot bilgisi banner'ı, sonraki tarih **otomatik önerisi** (`addPeriodToDate`), sonuç/yöntem/kusur seçenekleri mevzuat kuralından (yoksa varsayılan).
5. **İSG-KATİP / EKİPNET sözleşme belgesi** — `BelgeEkleModal`'a "İSG-KATİP Sözleşme" ve "EKİPNET Kayıt Belgesi" türleri eklendi (gerçek dosya yükleme, mevcut `ekipman_belgeleri` + private bucket).

### BJ3. Paylaşılan Yardımcılar (duplicate temizliği)

- `ekipmanService.periyodikKontrolGerekli(kural)` — backend ile birebir; form + detay + listeleme aynı fonksiyonu kullanır.
- `ekipmanUi.periyotMetni(period)` + `ekipmanUi.addPeriodToDate(date, period)` — periyot metni ve sonraki tarih önerisi tek kaynak.
- Form modal'daki yerel `periyotMetni`/`kontrolGerekli` IIFE kaldırılıp paylaşılanlara bağlandı.

### BJ4. Kalan / Sonraki Adımlar (uygulanmadı)

- **Alt tür tablosu boş** (`ekipman_alt_turleri` 0 satır) — mimari destekliyor; mevzuat doğrulamalı alt tür verisi sonraki turda doldurulacak.
- **Asansör / konveyör / kaldırma aksesuarları** yeni kategorileri (mevzuat kapsamında) henüz eklenmedi.
- **Risk/DÖF bağlantısı** — `ekipman_id` FK'sı risk/uygunsuzluk/DÖF tablolarına bağlanmadı.
- **Periyodik kontrol raporu üretimi** (PDF/Word) — `rapor_path`/`report_required` mevcut ama rapor üreten fonksiyon yok.
- **Sorumlu personel seçici** formda yok (`sorumlu_personel_id` kolonu dolu değil).

---

## BK. ALAN DAĞILIMI (SPACE DISTRIBUTION) KİLİDİ — MODAL + ÖNİZLEME + WIZARD (KALICI STANDART)

> Bu bölüm modal alanının KULLANICININ İŞ YAPTIĞI ALANA dağıtılması standardıdır. Amaç: yan panellerin ana içeriği daraltmaması, modalın içeriğe göre doğru ölçeklenmesidir. Kök neden her zaman ORTAK katmanda (Shared UI / ortak bileşen) kapatılır; sayfa bazlı width/spacing yaması YAZILMAZ (J7/N4).

### BK1. Ölçü Birimi Kuralı (yoğunluk uyumu)

- **Sabit `px` (arbitrary `w-[210px]` vb.) ölçüler yoğunluk kaldıracına (`--d-density-scale`) UYMAZ; rem tabanlı Tailwind ölçüleri (`w-48`, `w-[21rem]`) UYAR.** Yan panel / sidebar / kolon genişlikleri mümkün olduğunca **rem tabanlı** yazılır → Light/Dark aynı geometriyi korur ve %75 yoğunlukta panel de içerikle birlikte ölçeklenir. Yoğunlukla ölçeklenmeyen sabit px yan kolon, küçülen modal içinde ORANSIZ yer kaplayıp form/içerik alanını daraltır (kök neden).
- İstisna: PDF.js thumbnail render çözünürlüğü gibi JS'e px verilen GERÇEK çizim ölçüleri (bkz. BK2) sabit kalır — bunlar yoğunlukla ölçeklenmez, yalnızca kompaktlaştırılır.

### BK2. Belge Önizleme Sol Thumbnail Rafı (tek kaynak)

- Raf genişliği thumbnail'den **TÜREVDİR**, ayrı bir sabit değildir: `THUMB_RAIL_WIDTH = THUMB_WIDTH + yatay iç boşluk` (ThumbnailRail'den export). Raf kapsayıcısı (DocumentPreviewEngine) bu değeri tüketir; thumbnail genişliği değişince raf OTOMATİK uyar.
- Raf, thumbnail'den gereksiz GENİŞ OLMAZ; ana belge görüntüleme alanına MAKSİMUM alan kalır. Thumbnail genişliği okunabilirliği koruyacak kadar yeterli ama kompakt tutulur.

### BK3. Tutanak Wizard 3-Kolon Alan Dağılımı

- Sol adım navigasyonu + orta form + sağ Word önizleme 3-kolon düzeninde yan kolonlar **rem tabanlı** genişlik kullanır; orta (KULLANICININ İŞ YAPTIĞI) form kolonu `flex-1` ile artan alanı alır.
- Öncelik: form alanı. Yan paneller ana içeriği sıkıştırmaz. Yeni bir wizard/3-kolon düzen eklenirse aynı ilke (yan paneller kompakt + form baskın) uygulanır.

### BK4. Değişmezler

Modal motoru (L), zero-jump atomik paint, adaptif genişlik + modal-içi reflow, scroll sistemi, tema/yoğunluk motoru, Dark/Light ve iş mantığı BU bölümle DEĞİŞMEZ — yalnızca alan dağılımı (genişlik) düzeltilir.

### BK5. Çok Sayfalı PDF / Belge Önizleme — Render Performans Kilidi

Belge önizleme motorunun (SharedUICore → `preview` + `pdfEngine`) çok sayfalı (50/100/300/600+) belgelerde donmaması için KALICI kurallar:

- **Merkezi render kuyruğu TEK kaynak:** TÜM PDF render'ları (aktif sayfa + thumbnail + ön-yükleme) `pdfEngine.ts` içindeki merkezi kuyruktan geçer; eşzamanlı render `MAX_CONCURRENT_RENDERS` (2) ile SINIRLIDIR. Sayfa bazlı kendi render döngüsü YAZILMAZ. `pages.map(...) + Promise.all(...)` ile toplu render YASAK (fırsat bulunursa kuyruğa taşınır).
- **Öncelik sırası:** `ACTIVE_PAGE(0) > NEAR_PAGE(1) > VISIBLE_THUMB(2) > BUFFER_THUMB(3)`. Aktif sayfa asla aç kalmaz; thumbnail'ler düşük önceliklidir. Yeni bir render çağrısı türü eklenirse önceliği `RENDER_PRIORITY`'den alır.
- **Virtualization:** Thumbnail rail pencereleme (windowing) kullanır — DOM'a yalnızca viewport civarı hücreler basılır; 600 sayfa → 600 canvas ASLA oluşturulmaz. Ana sayfa görüntüleyici tek seferde YALNIZCA aktif sayfayı render eder.
- **İptal/kuyruk temizliği:** Her render `AbortSignal`/`RenderTask.cancel` ile iptal edilebilir; iptal edilen bekleyen iş kuyruktan ÇIKARILIR (slot işgal etmez). Sayfa değişince önceki iş biter.
- **Sınırlı cache:** Doküman cache'i (LRU) ve thumbnail cache'i (LRU) SINIRLIDIR; belge atılınca thumbnail'leri de temizlenir. Sınırsız cache YASAK.
- **Cache anahtarı genişlik-duyarlı:** Thumbnail cache anahtarı çözünürlüğü (`cssWidth`) içerir; farklı amaçlar (rail vs. ön-yükleme) birbirinin yanlış boyutlu sonucunu almaz. Ön-yükleme rail ile AYNI genişliği (`THUMB_WIDTH`) kullanır — ayrı/uyumsuz px YAZILMAZ.
- **Race/generation:** Render sonucu yazılmadan önce iptal/generation kontrol edilir; eski belge/sayfanın async sonucu yeni viewer'a YAZILMAZ.
- **Worker:** PDF.js worker aktif (`pdfjsRuntime` tek lazy yükleyici). Ana thread uzun synchronous loop ile kilitlenmez. `setTimeout`/rAF ile sahte perf çözümü YASAK.
- **Modaldan bağımsız:** Bu kilit yalnızca render motorunu performanslı yapar; modal/Y (full-screen), zero-jump (L1), scroll (L1) sistemleri DEĞİŞMEZ. Çok sayfalı belge yüzünden modalın tamamı scroll container YAPILMAZ.
- **Hata izolasyonu:** Tek sayfa render hatası tüm viewer'ı çökertmez (sayfa-bazlı "Tekrar Dene" + `friendlyPreviewError`/`friendlyErrorMessage`).
- **Değişmez:** Belge baytları, format destekleri, indirme/yazdırma, thumbnail seçimi ve iş mantığı DEĞİŞMEZ — yalnızca render mimarisi (kuyruk + öncelik + iptal + sınırlı cache) sertleştirilir.

---

## BL. EKİPMAN EXCEL — SABİT ŞABLON + SABİT LİSTE STANDARDI (KALICI STANDART)

> Önceki "firma bazlı dinamik listeleme şeması" kararı GERİ ALINMIŞTIR. Ekipman liste kolonları SABİTTİR; kullanıcının içe aktardığı Excel bu yapıyı DEĞİŞTİRMEZ. Global Excel motoru (`isgExcelCore` + `ekipmanExcel`) tek kaynaktır.

### BL1. İSGDenetim Excel Şablonu KALIR
- "Ekipmanları İçe Aktar" modalında **Excel Şablonunu İndir** butonu vardır ve gerçek çalışır şablonu indirir. Şablon generatorü SİLİNMEZ.
- Şablon: kurumsal logo/bilgiler (Kurumsal Ayarlar'dan) + seçili firma bilgileri + standart ekipman kolonları + gerçek Excel formülleri + global kurumsal tasarım. Şablonda veri satırları BOŞTUR.
- Dosya adları: **`Ekipman_Listesi_Sablon.xlsx`**, **`Ekipman_Listesi_{DD-MM-YYYY}.xlsx`**, **`Ekipman_Listesi_{DD-MM-YYYY}.csv`**. Hardcode firma/logo YOK.

### BL2. Yasaklı Metinler
- Modalda ve inen Excel'in içinde **"Kendi Excel dosyanızla da aktarım yapabilirsiniz."** ve **"İSGDenetim sistemi ile uyumludur"** gibi kullanım talimatı/açıklama metinleri OLMAZ. Kaldırıldı.

### BL3. Listeleme SABİT (kilitli kolonlar)
Ekipman listesi kolonları sistem standardında SABİTTİR: Ekipman No · Ekipman Adı · Ekipman Grubu · Ekipman Türü · Firma · Lokasyon · Son Kontrol · Sonraki Kontrol · Kalan Süre · Durum. Kullanıcının Excel'inde Marka/Model/Seri No/Maliyet Merkezi vb. olsa bile liste yapısı DEĞİŞMEZ. Dinamik firma şeması (`ekipmanCustomFieldService`, `buildCustomFieldPayload`, liste/export özel kolonları) KALDIRILDI.

### BL4. Import Mantığı
- Standart şablon kolonları sistem alanlarıyla doğrudan eşleşir. Farklı Excel'de mevcut alanlar otomatik eşleştirilir; **eşleşmeyen kolonlar import dışında bırakılır** (firma özel alanı OLUŞTURULMAZ, `customFields: []` gönderilir; backend boş listede özel alan yazmaz).
- Modalda sütun eşleştirme ekranı ve Excel önizlemesi YOKTUR (kompakt geometri).

### BL5. Export = Standart
- Dışa aktarma sabit standart kolonları + kurumsal Excel tasarımını kullanır; kullanıcı Excel'i liste yapısını DEĞİŞTİRMEZ. CSV aynı sabit kolon/sırayı izler.

### BL6. Global Excel Standardı (GLOBAL EXCEL ŞABLON MOTORU)

> **SON DÜZELTME (KALICI):** Excel kolonları artık LİSTELEME KOLONLARINDAN dinamik üretilir (`src/lib/ekipmanKolonlari.ts` tek kaynak → liste + şablon + export + CSV). Ekipman listesinde MARKA / MODEL / SERİ NO ayırt edici kimlik olarak vardır; "Ekipman Grubu" liste/Excel kapsamından çıkarılmıştır (formda kalır). Ekipman Ekle sihirbazında Marka/Model/Seri No alanları zorunlu değildir; detayda Firma satırı görünür. Harici belge yükleme GLOBAL `FileUpload` motorunu kullanır (Periyodik Kontrol Raporu + Kullanım Kılavuzu / Uygunluk / CE / Bakım / Teknik Doküman / Fotoğraf / Diğer). KALAN SÜRE gerçek Excel FORMÜLÜ (`=IF(<sonraki>="","",<sonraki>-TODAY())`, sütun harfi dinamik); DURUM kullanım durumu (Arızalı/Bakımda/Kullanım Dışı) öncelikli, aksi halde kontrol tarihinden formülle (`● Gecikmiş / ● Takip / ● Uygun`) + gerçek Conditional Formatting (6 renk). Excel header referans kompozisyonunu uygular: geniş logo alanı (kırpılmaz, orantılı), logo yanında OSGB kurumsal bilgileri (Kurumsal Ayarlar'dan), kırmızı geometrik vurgu şeridi, sağ lacivert rapor paneli (Firma/Lokasyon/Hazırlayan/Rapor Tarihi/Toplam), lacivert tablo başlığı + AutoFilter. Footer'da kullanıcıya yönelik AÇIKLAMA/TALİMAT metni YOK; yalnızca kurumsal bilgi blokları + lacivert alt bant + kırmızı web segmenti. Tasarım GLOBALDİR, içerik modüle özeldir.
- Tasarım (`header` + logo/kurumsal alan + tablo header + tipografi + border + spacing + conditional formatting + print layout + formül sistemi) sistemin GLOBAL Excel standardıdır. İleride Personel/Evrak/Risk/Denetim/Ziyaret modülleri AYNI motoru kullanır; modüle özel ikinci Excel motoru OLUŞTURULMAZ.

### BL7. Global Excel Motoru Mimarisi (TEK KAYNAK)
`src/lib/excel/` altında modüler motor; `isgExcelCore` orkestratördür:
- `excelTheme.ts` — renk paleti (lacivert `#0F2747` + kırmızı) + font + yerleşim sabitleri (`EXCEL_LAYOUT`) + `colLetter`.
- `excelTypes.ts` — ortak tipler (`ExcelColumnDef`, `ExcelDataRow`, `ExcelBrandMeta`, `BrandedSheetOptions`).
- `excelCell.ts` — `put`/`mergePut`/`border`/`computeColumnWidths` (dinamik sütun genişliği).
- `excelCompanyHeader.ts` — kurumsal header (logo sol + OSGB bilgileri + lacivert rapor paneli + kırmızı ayırıcı) + premium footer (Not/Rapor Bilgileri/Hazırlayan/Tarih) + kurumsal alt bant.
- `excelTable.ts` — tablo başlığı (lacivert + beyaz bold) + zebra satırlar + DURUM/KALAN SÜRE conditional formatting.
- `excelPrintLayout.ts` — landscape + fitToWidth=1 + freeze pane + AutoFilter + tekrar eden başlık satırları (`printTitlesRow`) + printArea.
- `isgExcelCore.ts` — `createBrandedSheet`/`exportBrandedWorkbook`/`buildExcelBrandMeta`/`fetchLogoAsset`/`downloadBlobFile`.
Her üretilen Excel başlığında **logo (orantı korunur, kırpılmaz)** + OSGB adı/adres/telefon/e-posta/vergi/web + belge başlığı + Firma/Lokasyon/Hazırlayan/Rapor Tarihi/Toplam Ekipman + lacivert tablo header + conditional formatting + footer vardır. **Hiçbir OSGB/firma bilgisi kod içine sabit yazılmaz** — logo + kurumsal bilgiler Kurumsal Ayarlar'dan, firma bilgileri seçili firmadan, hazırlayan aktif kullanıcıdan gelir (cross-OSGB sızıntısı RLS ile engellenir).

### BL8. Formül + Conditional Formatting
- KALAN SÜRE: gerçek Excel formülü `${SONRAKI}${satır}-TODAY()` (sütun harfi seçilen kolonlara göre DİNAMİK).
- DURUM: `IF(...<0,"● Gecikmiş", IF(...<=30,"● Takip","● Uygun"))` — statik metin YOK.
- DURUM kolonunda metin bazlı, KALAN SÜRE kolonunda sayısal (`<0` kırmızı / `0–30` turuncu / `>30` yeşil) conditional formatting uygulanır → Excel açıldığında renk otomatik güncellenir.
- LOGO: Excel header'da 9 satırlık logo alanı GERÇEKTEN doldurulur (premium ölçek ~250px genişlik × 168px yükseklik, dikeyde ortalı; orantı korunur, kırpılmaz, küçücük hücreye sıkıştırılmaz).

---

## BM. GLOBAL PDF ÇIKTI MOTORU — İSGDenetim PDF STANDARDI (KALICI STANDART)

> Bu bölüm İSGDenetim'in KALICI PDF çıktı standardıdır. Excel standardıyla (BL) AYNI görsel dille hizalanır; TASARIM GLOBAL, İÇERİK MODÜLE ÖZELDİR. İkinci bir PDF tasarım motoru OLUŞTURULMAZ.

### BM1. Tek Kaynak Mimarisi (`src/lib/pdf/`)
- `pdfTheme.ts` — kurumsal renk paleti (lacivert `#0F2747` + kırmızı `#C8102E`) + font + A4 ölçüleri + ortak margin (`PDF_MARGIN`) + header/footer yükseklikleri + `hexToRgb`/`clamp`.
- `pdfFont.ts` — tam Türkçe destekli DejaVu Sans (mevcut `personelReport/pdfFont` yeniden kullanılır; ikinci font indirici YOK).
- `pdfCore.ts` — `createIsgPdf` (A4 portrait/landscape) + `drawIsgHeader` (logo sol + belge başlığı & rapor meta paneli sağ + kırmızı ayırıcı) + `drawIsgFooter` (lacivert kurumsal bant + kırmızı slogan segmenti + sayfa no) + `drawImageFit`/`fitText`.
- `pdfLabelGrid.ts` — etiket/grid yerleşim hesaplayıcı (header+footer+margin sonrası kullanılabilir alana göre; kart ölçüsü SABİT KODLANMAZ).
- `qrEtiketPdf.ts` — Ekipman toplu QR/PDF üreticisi (gerçek ekipman QR tokenlarından).

### BM2. Ekipman Toplu QR / PDF (ilk gerçek uygulama)
- A4 dikey; üstte kurumsal header + sağda **Ekipman QR Kodları** + Firma/Rapor Tarihi/Toplam Ekipman; ortada 3×7 (merkezi hesaplanır, örn. 21 QR/sayfa) QR etiket grid'i; altta lacivert bant + kırmızı slogan segmenti.
- Her etiket: QR kod + Ekipman No + Ekipman Adı + Tür/Marka/Model/Seri No/Lokasyon + küçük marka alanı + "QR kodu okutarak ekipman bilgilerine ulaşın."
- QR kodları GERÇEK ekipman erişim adreslerinden (`buildEkipmanQrUrl(qrReference)`) üretilir; mock/örnek QR üretilmez. Logo + tüm kurumsal bilgiler Kurumsal Ayarlar'dan (ExcelBrandMeta) gelir; hardcode YOK.
- Kapsam: seçili ekipmanlar / tüm ekipmanlar. Mod: A4 çoklu grid / tekli (sayfa başına 1 etiket). Dosya adı: `Ekipman_QR_Kodlari_{FirmaAdi}_{DD-MM-YYYY}.pdf` (Türkçe karakter güvenli).

### BM3. Birleşik İşlem Girişi
- Ekipman modülünde TEK giriş: **"Excel / PDF İşlemleri"** butonu → menü: Excel İçe Aktar · Excel Dışa Aktar · Toplu QR / PDF Oluştur. Ayrı Excel/CSV/QR butonları oluşturulmaz.
- Tüm alt eylemler mevcut merkezi Modal motoruyla açılır (modal merkezleme, MDI, resize, maximize/minimize korunur).

### BM4. Gelecekteki Tüm Geliştirmeler İçin Kilit
Başka bir modül PDF ürettiğinde AYNI motoru (header + logo yerleşimi + filtre/renk + footer + tipografi + margin + sayfa numarası + çok sayfa + Türkçe) kullanır. Modüle özel yalnızca başlık/kolonlar/veri/formüller/etiket içeriği değişir; yeni PDF tasarım sistemi İCAT EDİLMEZ. Mevcut çalışan rapor/generator'lar (personelReport vb.) bozulmaz.

---

## BN. İSG-KATİP ENTEGRASYON ALTYAPISI (FAZ 6A / 6A.1 / 6B / 6C)

> İSG-KATİP (ÇSGB İSG Kayıt, Takip ve İzleme Programı) entegrasyon hazırlığı. Resmî public developer API DOĞRULANMADI; entegrasyon yolu **Chrome Extension → normalize veri → İSGDenetim backend**'dir. Kanonik tek kaynak: **`src/lib/isgKatip/`**. Sahte KATİP verisi / uydurma selector / uydurma enum YASAK.

### BN1. Kavramsal Ayrım (bozulmaz)
- **YASAL ATAMA** = İSG-KATİP kaynaklı (İSG Uzmanı / İşyeri Hekimi / DSP).
- **SAHA UZMANI** = İSGDenetim operasyonel görevi (`assignment_role='helper'`); İSG-KATİP yasal ataması DEĞİLDİR, requirement engine onu saymaz.
- **İçe Görevlendirme (INTERNAL)** = OSGB ↔ profesyonel (İSG Personel Sözleşmeleri).
- **Dışa Görevlendirme (EXTERNAL)** = OSGB ↔ hizmet alınan işyeri (İSG Hizmet Sözleşmeleri) → yasal işyeri atamasının esas ilişkisi.

### BN2. FAZ 6A/6A.1 — Sözleşme + Validation + Şema
- `src/lib/isgKatip/`: `types.ts` (normalize iç sözleşme), `validation.ts` (client), `sync.ts` (client→backend), `adapter.ts` (arayüz), `labels.ts`, `normalize.ts`.
- Edge function `isg-katip-sync`: JWT zorunlu (`verify_jwt:true`), admin/osgb_admin, server-side OSGB scope (CROSS_OSGB=403), payload boyut/JSON/validation kontrolü, `system_logs` sync log (PII yazılmaz). Yanıt `mode:'CONTRACT_ONLY'` — import motoru PASİF.
- DB: `personeller.isg_katip_id/sicil_no/sertifika_no/source/tc_kimlik_no` (mevcut), `firma<span>/atamalar.isg_katip_id` (nullable + partial unique index). Backfill YAPILMADI.
- Chrome Extension iskeleti: `chrome-extension/` (Manifest V3 + background/service-worker + content + adapter + shared mesaj sözleşmesi).

### BN3. FAZ 6B — Gerçek Endpoint → Adapter → Parse → Normalize
- Gerçek endpointler (doğrulanmış): `POST /be/bsn-inter-instance/hizmet-sozlesmesi-surec-view/ongoing` ve `POST /be/bsn-inter-instance/personel-sozlesmesi-surec/ongoing`; gövde `{sortOrder,pageIndex,pageSize,filters,sortColumn}`.
- **KESİN MAPPING:** `hizmetAlanIsyeriId → firmalar.isg_katip_id`; İSG Hizmet Sözleşmesi `sozlesmeId → atamalar.isg_katip_id`.
- **İSG Personel Sözleşmesi `sozlesmeId` YASAL İŞYERİ ATAMA ID'Sİ DEĞİLDİR** — ayrı entity (içe görevlendirme), `atamalar`'a yazılmaz.
- Modüller: `endpoints.ts` (endpoint + request builder + `tableData` çıkarımı + idempotent pagination), `mapper.ts` (gerçek alan → normalize; helper YOK), `roleMapping.ts` (enum haritaları BİLEREK BOŞ — gerçek enum discovery bekler; eşleşmeyen → UNRESOLVED), `adapter.ts` (`HttpIsgKatipAdapter`, taşıma enjekte edilebilir; transport yoksa açık hata).
- `katipCalisanSayisi` YALNIZCA metadata taşınır; `firmalar.calisan_sayisi`'na YAZILMAZ (merkezî çalışan sayısı = `firmalar.calisan_sayisi`).
- READ-ONLY: KATİP cookie/session/token backend'e GÖNDERİLMEZ; fetch MAIN world'de kullanıcının kendi oturumuyla (`credentials:'include'`).

### BN4. FAZ 6C — Matching + Conflict-Safe Upsert HAZIRLIĞI
- `src/lib/isgKatip/matching.ts` (SAF; supabase/DOM bağımsız): `matchFirms` / `matchPersonnel` / `matchAssignments` / `buildMatchPlan` / `buildUpsertOperations` / `buildFirmaSafePatch` / `buildPersonelSafePatch` / `assessSyncScope`.
- Sonuç durumları: `MATCHED / NEW / CONFLICT / UNRESOLVED / SKIPPED`. Riskli/otomatik-dışı eşleşmeler `system_logs` uyumlu `KatipConflict` (entityType/externalId/localId/reason/source/correlationId; PII yok) ile raporlanır.
- Eşleştirme önceliği — Firma: isg_katip_id → vergi_no → isim (yalnızca inceleme/UNRESOLVED) → NEW; Personel: isg_katip_id → T.C. → UNRESOLVED (yalnızca isimle EŞLEŞTİRİLMEZ); Atama: sozlesmeId (helper/geçersiz rol → SKIPPED).
- Conflict-safe: kaynakta OLMAYAN alan NO-OP (telefon/e-posta NULL yapılmaz), `source` mevcut kayıtta korunur (MANUAL ezilmez), `firmalar.calisan_sayisi` yazılmaz, `isg_katip_id` yalnızca boşsa doldurulur.
- `src/lib/isgKatip/matchingService.ts`: OSGB kapsamlı yerel snapshot okur (RLS), plan üretir — **SALT OKUNUR** (yazma YOK).
- **DB IMPORT KAPALI:** `importEnabled=false`; plan yalnızca hazırlanır. Gerçek import FAZ 6D/6E/6F'te kontrollü açılacak. `isg-katip-sync` yanıtı `CONTRACT_ONLY` olarak KORUNUR.
- UI DEĞİŞMEZ; Firma/Personel/Atama Ekle-Düzenle ekranları ve SharedUICore dokunulmaz.

### BN5. Test / Kalan
- Testler: `chrome-extension/tests/` (node:test, PII maskeli) — FAZ 6B adapter/parse + FAZ 6C matching/conflict/idempotency/scope. Test runner komutu ortamda koşulamazsa açıkça NOT RUN bildirilir (statik doğrulama test gibi gösterilmez).
- Kalan blokajlar: gerçek rol enum değerleri (discovery), gerçek authenticated tarayıcı E2E, host izni daraltma (`*.csgb.gov.tr`), extension `.ts`→`.js` bundler adımı.

### BN6. FAZ 6D / 6E / 6F — KONTROLLÜ GERÇEK DB IMPORT (Firma + Personel + Yasal Atama)
- Canonical motor `src/lib/isgKatip/import.ts` (SAF; transport-agnostik `KatipWriteGateway`): `parseImportFlag` / `resolveEffectiveMode` / `assessImportAuthz` / `buildFirmaInsert` / `buildPersonelInsert` / `buildAssignmentInsert` / `executeImportPlan`.
- **Merkezî feature gate:** `system_settings.isg_katip_import_enabled` (yoksa env `ISG_KATIP_IMPORT_ENABLED`), **varsayılan KAPALI**. Kapalı ise mod DAİMA `DRY_RUN` → INSERT/UPDATE/DELETE YOK.
- **Modlar:** `DRY_RUN` (varsayılan) · `SAFE_IMPORT` · `FULL_CONTROLLED_IMPORT`. Yalnızca güvenli `MATCHED`/`NEW` yazılır; `CONFLICT`/`UNRESOLVED`/`SKIPPED`/`CROSS_OSGB` → otomatik yazma YOK.
- **Sunucu-taraflı gerçek upsert:** `supabase/functions/isg-katip-sync` mod `import` (JWT + admin/osgb_admin + authenticated OSGB scope; frontend `osgbId` kapsam BELİRLEMEZ). Matching + conflict-safe patch + insert builder + log SUNUCUDA (self-contained mirror).
- **DB eşlemeleri (gerçek şemadan doğrulandı):** yasal atama `assignment_role='primary'` + `atama_turu` (`isg_uzmani→uzman`, `isyeri_hekimi/dsp→hekim`); `firmalar.calisan_sayisi` NOT NULL+defaultsuz → yeni firmada nötr `0` (**ASLA İSG-KATİP değeri yazılmaz**); `tehlike_sinifi`/SGK kolonu KATİP'ten yazılmaz. `atamalar.baslangic_tarihi` NOT NULL → tarih yoksa INSERT YOK.
- **Kesin kurallar korundu:** DELETE YOK (termination = lifecycle); helper/Saha Uzmanı üretilmez; MANUAL personel `source`/telefon/e-posta korunur (kaynakta yoksa NO-OP); rol enum UYDURULMAZ (UNRESOLVED → yazma yok).
- **Idempotency:** `firmalar/atamalar.isg_katip_id` + `personeller (osgb_id,isg_katip_id)` partial unique; ikinci sync → NOOP.
- **Extension build:** `chrome-extension/build.mjs` (esbuild; dependency `esbuild`) → `dist/`; manifest host izni `https://isgkatip.csgb.gov.tr/*`'e daraltıldı (v0.3.0).
- **Testler:** `chrome-extension/tests/isg-katip-import.test.ts` (27 senaryo; firma/personel/atama/idempotency/dry-run/flag/security). Test runner komutu ortamda koşulamazsa NOT RUN bildirilir.
- **DB import:** varsayılan KAPALI (`import_enabled` false → DRY_RUN). Açmak için `system_settings`'e `isg_katip_import_enabled=true` eklenmesi gerekir; role enum doğrulanana kadar yasal atama üretilmez.

### BN7. FAZ 6G — KATİP Role Discovery + Import Readiness Audit
- **AMAÇ:** Gerçek import AÇILMADAN, son teknik eksikleri kapatmak. Bu fazda: gerçek import YOK, DB'ye KATİP verisi yazma YOK, feature flag ON YOK, otomatik atama/onay YOK, termination DELETE YOK, fake/mock KATİP verisi YOK. Yalnızca DISCOVERY + VALIDATION + READINESS AUDIT.
- **Rol enum DOĞRULANMADI:** `roleMapping.ts` haritaları BİLEREK BOŞ kaldı (`sertifikaMapEmpty=true`, `sozlesmeMapEmpty=true`). Enum değeri UYDURULMADI; A/B/C sertifika sınıfı QUALIFICATION olarak kabul edildi, ROL enum'u sayılmadı. Eşleşmeyen roller `UNRESOLVED` kalır.
- **`src/lib/isgKatip/roleDiscovery.ts` (yeni, SAF):** `collectRoleDiscovery` (gerçek response'tan `gorevlendirilenKisiSertifikaTipi`/`sozlesmeTipi`/`sozlesmeYapilanKisiSertifikaTipi` değerlerini SALT GÖZLEMLE toplar) + `findUnmappedRoleValues` + `buildRoleMappingSkeleton` (değerler `null`, doldurulmayı bekler) + `describeRoleMappingReadiness`. Değer ÜRETMEZ/TAHMİN ETMEZ.
- **`src/lib/isgKatip/readiness.ts` (yeni, SAF):** `buildDryRunReport` (DRY_RUN raporu: `imported`/`updated`/`matched`/`conflicts`/`skipped`/`validationErrors` + `unresolved.{roles,firms,persons,assignments}` breakdown; `applied=false`, `importEnabled=false`) + `buildImportReadinessChecklist` (18 kriter; kanıt yokken PASS DEĞİL, feature flag daima OFF) + `KATIP_EMPLOYEE_COUNT_POLICY`/`assessEmployeeCountPolicy` + `diffContractFields` (`KATIP_HIZMET_CONTRACT_FIELDS` — 21 alan, `sozlesmeSurecId` dahil).
- **Çalışan sayısı POLICY:** KATİP `hizmetAlanIsyeriCalisanSayisi` → `firmalar.calisan_sayisi` ÜZERİNE YAZILMAZ (`autoWriteToFirmalar=false`), ancak YENİ/BOŞ firmada DOLDURULUR (`fillWhenEmpty=true`); merkezî runtime kaynak `firmalar.calisan_sayisi`; personel COUNT fallback DEĞİL.
- **Contract audit:** FAZ 6G listesindeki İSG Hizmet Sözleşmeleri alanları normalize katmanıyla karşılaştırıldı; adapter contract'a eksik `sozlesmeSurecId` (opsiyonel) eklendi. Alan adları tahmin edilmedi.
- **Extension:** content script'e `roleDiscovery` çıktısı eklendi (additive). Host izni `https://isgkatip.csgb.gov.tr/*` korunuyor. Extension `node chrome-extension/build.mjs` ile derlenir (bu ortamda komut çalıştırma yoksa NOT RUN).
- **Güvenlik/UI/RLS:** Değişmedi. SharedUICore + UI Freeze korundu; Firma/Personel/Atama UI'larına dokunulmadı; yeni migration gerekmedi.
- **Testler:** `chrome-extension/tests/isg-katip-readiness.test.ts` (role discovery, dry-run breakdown, çalışan sayısı policy, contract diff, checklist, feature flag default). Test runner bu ortamda koşulamazsa NOT RUN bildirilir.
- **Gerçek DB import:** AÇILMADI (`system_settings.isg_katip_import_enabled` YOK → DRY_RUN; rol enum doğrulanana kadar yasal atama üretilmez, çalışan sayısı yazılmaz).

### BN8. FAZ 6H — GERÇEK KATİP ROLE DISCOVERY + QA + IMPORT READINESS
- **AMAÇ:** Gerçek import AÇILMADAN discovery + contract QA + build/test QA + canlı import öncesi son teknik kontroller. Bu fazda: gerçek import YOK, DB'ye KATİP verisi yazma YOK, feature flag ON YOK, otomatik atama/onay YOK, termination DELETE YOK, fake/mock KATİP verisi YOK, UI değişikliği YOK.
- **Rol enum DOĞRULANMADI:** Gerçek authenticated KATİP oturumu bu ortamda yok → `gorevlendirilenKisiSertifikaTipi`/`sozlesmeTipi` değerleri gözlemlenemedi. `roleMapping.ts` haritaları **bilerek BOŞ** kaldı; tahmin YOK. A/B/C qualification'dır, rol enum'u DEĞİL.
- **`roleDiscovery.ts` (güncelleme, additive):** yeni `summarizeRoleDiscovery` + `RoleDiscoveryAudit` — gözlemlenen değerler + haritalanmamış değerler + boş harita uyarısı + doldurulacak iskeleti (değer=null) TEK nesnede toplar (rapor `A) ROLE DISCOVERY`).
- **`readiness.ts` (güncelleme, additive):** `KatipDryRunReport`'a `breakdown` alanı eklendi → `helperSkipped`, `duplicateConflicts`, `crossOsbgRejected`, `missingStartDate`, `invalidExternalId` ayrı sayaçlar (madde 9). `crossOsgbRejected` scope katmanından sağlanır; diğerleri plandan TÜRETİLİR (uydurma yok). `applied`/`importEnabled` DAİMA false.
- **Contract QA (additive):** `KatipHizmetSozlesmesiRow`'a opsiyonel `sozlesmeSurecAdi` eklendi; `KATIP_HIZMET_CONTRACT_FIELDS` 21→22. Gerçek response örneklemi olmadığından alan bazlı present/missing diff runtime'da dürüstçe PENDING kalır (tahmin yok).
- **QA doğrulandı (statik + tip):** `firmalar.deleted_at` mevcut (snapshot okuyucu geçerli); `firmalar.calisan_sayisi` NOT NULL + varsayılansız (yeni firmada nötr 0, KATİP değeri DEĞİL); yasal atama `assignment_role='primary'`, helper `'helper'`; `dsp → atama_turu='hekim'`. `system_settings`'te `isg_katip_import_enabled` **YOK → gate KAPALI** (SQL `[]`).
- **Güvenlik/UI/RLS:** Değişmedi. SharedUICore + UI Freeze korundu; Firma/Personel/Atama/Detay UI'larına dokunulmadı; yeni migration gerekmedi.
- **Testler:** Mevcut testler korundu + `chrome-extension/tests/isg-katip-qa6h.test.ts` (role discovery audit, dry-run breakdown, idempotency, termination-no-DELETE, helper exclusion, OSGB scope, contract alan, çalışan sayısı, checklist). Extension build (`node chrome-extension/build.mjs`) + unit testler + browser E2E bu ortamda komut çalıştırma aracı olmadığı için **NOT RUN** (statik doğrulama test gibi gösterilmez).
- **Son karar:** İSGDenetim KATİP entegrasyonu bugün kontrollü gerçek import için **HAZIR DEĞİL** (rol enum doğrulanmadı · çalışan sayısı policy çözülmedi · extension build/testler/browser E2E koşulmadı). Canlı açılış FAZ 6I (authenticated dry run) → 6J (tek firma pilot) → 6K (kademeli) fazlarında yapılacak; bu fazlarda KENDİLİĞİNDEN işlem YAPILMADI.

### BN9. FAZ 6I + 6J — GERÇEK KATİP DRY RUN + KONTROLLÜ PİLOT IMPORT (HAZIRLIK)
- **AMAÇ:** 6C'deki matching/conflict plan zincirinin üzerine KONTROLLÜ TEK-FİRMA pilot import altyapısı eklemek; gerçek KATİP verisini hiçbir DB write yapmadan doğrulamak. Bu fazda: gerçek import YOK, DB'ye KATİP verisi yazma YOK, global feature flag ON YOK, otomatik atama/onay/termination YOK, fake/mock veri YOK, UI değişikliği YOK.
- **FAZ 6I — Authenticated dry run:** Bu ortamda authenticated KATİP oturumu YOK → **NOT RUN**. Kod, gerçek oturum sağlandığında tek adımda çalışacak durumda bırakıldı. Dry-run raporu `unknown*` sayaçlarıyla genişletildi (madde 5): `readiness.ts` `KatipDryRunReport.unknown = { roles, firms, persons, assignments }` (unresolved'ın açık/filtrelenebilir aynası). `applied`/`importEnabled` DAİMA false.
- **FAZ 6J — Kontrollü pilot (`import.ts`, additive):** `KatipPilotScope { firmExternalId }` + `applyPilotScope(plan, scope)` → planı TEK firmaya (+ bağlı personel + yasal atamalar) indirger; kapsam dışı firma/personel/atama ve işlemler plana DAHİL EDİLMEZ. Bilinmeyen firma ID → güvenli boş plan. `executeImportPlan({ ...pilot })` pilot kapsamıyla çalışır ve sonuca `pilot: { firmExternalId }` ekler. `buildPilotPreWriteSummary(plan, scope)` → yazma ÖNCESİ son kontrol (firma durumu, personel/atama conflict-unresolved sayıları, `safeToWrite`, `blockingReasons`).
- **Sunucu-taraflı pilot (edge function `isg-katip-sync`, yeniden deploy edildi, `verify_jwt: true`):** `pilotFirmExternalId` gövdesiyle runImport match öğelerini TEK firmaya indirger (firma ext eşleşmesi + o firmanın atamaları + o atamaların personeli). Kapsam sunucuda belirlenir; başka firmaya/OSGB'ye dokunulmaz. `system_logs.metadata.pilot` + yanıt `pilot` bayrağı eklendi.
- **Çalışan sayısı policy GÜNCELLENDİ:** `KATIP_EMPLOYEE_COUNT_POLICY.autoWriteToFirmalar=false` (üzerine yazma YOK) + `fillWhenEmpty=true`. KATİP `hizmetAlanIsyeriCalisanSayisi`, YENİ/BOŞ (null/0) firmada `firmalar.calisan_sayisi`'na DOLDURULUR; mevcut DOLU değer korunur. Doldurma `isg-katip-sync` pilot apply sonrası best-effort yapılır (PII'siz). Requirement motoru `firmalar.calisan_sayisi` üzerinden çalışmaya devam eder.
- **Güvenlik/Scope (korundu):** JWT zorunlu (401), admin/osgb_admin (403), OSGB kapsamı authenticated context'ten, CROSS_OSGB 403, update'ler `.eq('osgb_id', ...)`. KATİP cookie/token/e-Devlet bilgisi hiçbir yere yazılmaz; ham payload loglanmaz.
- **Testler:** `chrome-extension/tests/isg-katip-pilot6ij.test.ts` (pilot scope tek-firma, bilinmeyen firma→boş plan, pilot write yalnız hedef firma, pilot dry-run write-free, flag kapalı→DRY_RUN zorlama, pre-write summary safeToWrite, unknown* sayaçları, idempotency). Extension build + unit testler + browser E2E bu ortamda **NOT RUN**.
- **Son karar:** **PILOT BLOCKED** — FAZ 6I authenticated dry run başarılı olmadan 6J çalıştırılmaz; rol enum doğrulanmadı → `roleMapping` boş → yasal atama üretilemez. Global feature flag `isg_katip_import_enabled` **YOK → OFF** (SQL `[]`). Hiçbir gerçek import / flag açma / KATİP işlemi YAPILMADI.

### BN10. FAZ 6K — KATİP CHROME EXTENSION KURULUM + READ-ONLY DISCOVERY
- **AMAÇ:** İSG-KATİP Chrome Extension'ını gerçek Chrome'da kurulabilir/çalışabilir hâle getirmek ve salt-okunur discovery altyapısını kurmak. Bu fazda: gerçek import YOK, DB'ye KATİP verisi yazma YOK, feature flag ON YOK, otomatik atama/onay/termination YOK, KATİP'te işlem YOK, fake/mock KATİP verisi YOK, İSGDenetim UI değişikliği YOK. Extension popup İSGDenetim SharedUICore DIŞINDA BAĞIMSIZ küçük UI'dır.
- **DOĞRULANMIŞ ROL MAPPING (gerçek KATİP response discovery):** `gorevlendirilenKisiSertifikaTipiId=20002` / `gorevlendirilenKisiSertifikaTipi="C Sınıfı İş Güvenliği Uzmanlığı Sertifikası"` → `role=isg_uzmani`, `uzmanlikSinifi='C'`, **VERIFIED**. `roleMapping.ts`: `SERTIFIKA_TIPI_ID_ROLE_MAP` (birincil/anchor, ID tabanlı) + `SERTIFIKA_TIPI_ROLE_MAP` (etiket yedeği) dolduruldu. `roleKey()` TR diakritiklerini ASCII'ye indirger (etiket eşleşmesi kararlı). Yeni `resolveKatipRoleByCertId(id)`. `KatipRoleResolution.source`'a `'SERTIFIKA_TIPI_ID'` + `uzmanlikSinifi` eklendi. A/B/C QUALIFICATION'dır, ROL değildir → sınıf `uzmanlik_sinifi`'na yazılır.
- **DÜRÜST SINIR:** Yalnızca C (20002) doğrulandı. `sozlesmeTipi` (ör. "Kısmi Süreli") ROL değil SÜRE niteliğidir → `SOZLESME_TIPI_ROLE_MAP` BİLEREK BOŞ. Diğer enum'lar (A/B, İşyeri Hekimi, DSP) görülmediği için UYDURULMADI → `UNRESOLVED`. `describeRoleMappingReadiness()` artık `verifiedCount`/`sertifikaIdMapEmpty` raporlar; `complete=false` (tam değil).
- **CONTRACT (additive):** `KatipHizmetSozlesmesiRow`'a discovery alanları eklendi: `gorevlendirilenKisiSertifikaTipiId`, `sozlesmeTipiId`, `sozlesmeTurId`/`sozlesmeTur`, `sozlesmeSurecTurId`/`sozlesmeSurecTur`, `sozlesmeStatuId`, `sozlesmeOnayDurumuId`. `mapper.ts` rol çözümünde önce cert ID'yi dener, sonra etiket→sözleşme→enjekte çözümleyiciye düşer; `uzmanlikSinifi` resolution'dan taşınır.
- **PII-GÜVENLİ DISCOVERY (`discovery.ts`, yeni):** `buildDiscoveryReport({hizmetRows, personelRows})` → yalnızca `field + unique values + IDs + counts`; `KATIP_DISCOVERY_FIELDS` (categorical/presence/redacted). TC/ad-soyad değeri ASLA taşınmaz (`redactedFields`, `piiExposed:false`); `containsPii()` savunmacı tarayıcı. `buildCertTypeDiscoveryLogEntry()` → `{source, mode:'DISCOVERY', endpoint, field, uniqueValues[{id,label,mappingStatus}]}` (madde 12 şekli). `roleDiscovery.summarizeCertTypeObservations()` VERIFIED/UNRESOLVED enum gözlemi üretir.
- **EXTENSION (MV3 korundu):** manifest `0.4.0`; `host_permissions` yalnızca `https://isgkatip.csgb.gov.tr/*`. Yeni bağımsız popup (`popup/popup.html` + `popup/popup.ts`, `default_popup`) → "KATİP Bağlantısı: Hazır / KATİP sayfası bekleniyor" + READ-ONLY discovery paneli ("Discovery Verisini Yenile" butonu). Content script `ISG_KATIP_STATUS_REQUEST` + `ISG_KATIP_DISCOVERY_REQUEST` handler'ları eklendi (additive). `messages.ts` yeni mesaj tipleri. `build.mjs` popup'ı da derliyor + HTML'i kopyalıyor. Cookie/token Supabase'e GÖNDERİLMEZ; KATİP session browser context'inde kalır.
- **GÜVENLİK (korundu):** `isg-katip-sync` edge function değişmedi; import gate KAPALI; DRY_RUN varsayılan; pilot execution kapalı; DELETE yok.
- **Testler (yazıldı, ortamda NOT RUN):** `chrome-extension/tests/isg-katip-extension6k.test.ts` — endpoint tanıma, adapter init (taşıma yoksa Hata/veri üretmez), response parse, `20002→C→isg_uzmani` VERIFIED, etiket yedeği, unknown→UNRESOLVED, "Kısmi Süreli" rol değil, PII redaction, no-write (applied/importEnabled=false), feature flag OFF. Mevcut `isg-katip-readiness.test.ts` RD4 yeni doğrulanmış duruma güncellendi.
- **Build:** Vite SPA build PASS. Extension build (`node chrome-extension/build.mjs`) + unit testler + browser E2E bu ortamda **NOT RUN** (komut çalıştırma aracı ve authenticated KATİP oturumu yok) — koda bakıp "PASS" denmedi.
- **Son karar:** **READ-ONLY DISCOVERY HAZIR — GLOBAL IMPORT KAPALI.** Feature flag `isg_katip_import_enabled` **YOK → OFF**. Hiçbir gerçek import / flag açma / KATİP işlemi / UI değişikliği YAPILMADI.

### BN11. FAZ 6J.3 — GERÇEK WRITE + ORTAK KATİP SYNC WRITE CORE (TEK PİLOT)
- **AMAÇ:** 6J.2'ye kadar kurulan READ-ONLY plan zincirini (bridge/discovery/capture/matching/pilot önizleme) güvenli SERVER-SIDE WRITE + VERIFY katmanına bağlamak. Yeni mimari/matching motoru KURULMADI; çalışan bridge/discovery/capture DEĞİŞTİRİLMEDİ.
- **SERVER-SIDE ÇEKİRDEK (atomik):** `public.isg_katip_apply_pilot(p_plan jsonb)` PostgreSQL RPC — TEK çağrı = TEK transaction. Plan JSONB'yi (firma + personel + yasal atama aksiyonları) alır; firma oluştur/bağla → personel oluştur/bağla (firma/personel ext→id map) → yasal atama oluştur sırasıyla işler. `security definer` + `search_path=public`; `revoke ... from anon, authenticated` + `grant ... to service_role` → yalnızca edge function (service role) çağırabilir. `calisan_sayisi` plandan YOK (KATİP'ten yazılmaz).
- **IDEMPOTENCY / ATOMİKLİK:** Mevcut partial unique indexler kullanılır — `firmalar_isg_katip_id_key`, `personeller_isg_katip_id_uniq (osgb_id,isg_katip_id)`, `atamalar_isg_katip_id_key`. INSERT'ler `ON CONFLICT ... DO NOTHING` + `returning id`; race'te mevcut satır yeniden seçilir → duplicate YOK, NOOP. Fonksiyon gövdesi = tek transaction; hata durumunda rollback.
- **PILOT_ONLY GUARD (edge `isg-katip-sync`):** `const PILOT_ONLY=true`. `pilotFirmExternalId` verilmişse import etkin (=pilot write); verilmemişse GLOBAL feature gate'e bağlı (halâ `isg_katip_import_enabled` YOK → OFF). DRY_RUN yolu ASLA yazmaz. Pilot DAİMA tek firma (+bağlı personel +yasal atamalar).
- **PLAN ÜRETİMİ (edge, mevcut matching yeniden kullanıldı):** `buildPilotApplyPlan(...)` mevcut `matchFirms/matchPersonnel/matchAssignments` sonuçlarından + `firmaPatch/personelPatch/firmaInsert/personelInsert` alanlarından plan üretir. CONFLICT/UNRESOLVED/SKIPPED plana GİRMEZ → yazılmaz. Paralel matching motoru YOK.
- **SPA ORKESTRATÖR (`src/lib/isgKatip/apply.ts`, yeni):** `runIsgKatipPilotApply()` → RLS snapshot (scopeValidated) → `buildSyncPayload` (normalize) → `pushIsgKatipImport(payload,'SAFE_IMPORT',{pilotFirmExternalId})` → sonra READ-ONLY `verifyPilotApply()` (taze snapshot ile `isg_katip_id` bağları karşılaştırılır). Sonuç: linked/created/noop/verify PASS-FAIL; `employeeCountChanged` DAİMA 0.
- **KÖPRÜ (`bridge.ts`, additive):** Yeni `ISG_KATIP_PILOT_APPLY_REQUEST` / `..._RESULT` kanalları + `parseBridgePilotApplyEnvelope` + `handlePilotApply`. Mevcut dry-run/pilot (salt-okuma) kanallarına DOKUNULMADI. Extension `chrome-extension/content/denetim-relay.ts` + popup izole röle `apply` türü destekler.
- **POPUP UI (minimum, additive):** Mevcut pilot bloğuna `PİLOTU UYGULA` butonu + açık onay özeti (FİRMA/PERSONEL/YASAL ATAMA/ÇALIŞAN SAYISI=DEĞİŞMEYECEK/DB WRITE=HAZIR) + sonuç (linked/created/noop + verify PASS/FAIL). Yalnızca `PILOT_DRY_RUN_READY` + seçili İSGDenetim firması + çakışma yoksa gösterilir. Yeni Firma/Personel/Atama ekranı YENİDEN TASARLANMADI.
- **ÇALIŞAN SAYISI KURALI KORUNDU:** `firmalar.calisan_sayisi` KATİP'ten ASLA yazılmaz; yeni firmada nötr 0; personel COUNT ile değiştirilmez; `manuel_calisan_sayisi` fallback kullanılmaz.
- **KAPSAM DIŞI (bilinçli):** Toplu/global import AÇILMADI (PILOT_ONLY=true); Firma/Personel/Atama ekranlarının write core'a tam entegrasyonu bu fazda YAPILMADI (core PASS sonrası aynı çekirdeğe bağlanacak).
- **Build:** Vite SPA build **PASS**. Extension build (`node chrome-extension/build.mjs`) + gerçek Chrome E2E bu ortamda **DOĞRULANAMADI** (komut çalıştırma/gerçek authenticated KATİP oturumu yok) — koda bakıp PASS denmedi.

### BN12. FAZ 6L — KATİP SYNC WORKSPACE POPUP'TAN CHROME SIDE PANEL'E TAŞINDI
- **AMAÇ:** Uzun süren Pilot / Dry Run / WRITE / Verify workflow'unu kalıcı Chrome Side Panel çalışma alanına taşımak. Popup kalıcı DEĞİLDİR (sekme değişince/yenilenince kapanır); bu yüzden yalnızca hızlı durum + panel açma görevi verildi.
- **MANIFEST:** `"sidePanel"` permission + `"side_panel": { "default_path": "popup/sidepanel.html" }` eklendi; sürüm `0.8.0`. Service worker `setOptions({enabled:true,path})` ile paneli global etkinleştirir; `ISG_OPEN_SIDE_PANEL` mesajı yedek açma yolu.
- **POPUP (küçük):** KATİP bağlantısı + İSGDenetim bağlantısı + kısa durum + mevcut "İSGDenetim'e Bağlan" + "Pilot / Sync Panelini Aç" (`chrome.sidePanel.open`; yedek SW mesajı). Uzun pilot UI popup'tan ÇIKARILDI.
- **SIDE PANEL (tam):** Mevcut pilot workflow hiyerarşisi KORUNDU (1 KATİP firma … 8 İlk WRITE planı … 9 PİLOT WRITE … 10 Verify). Mevcut popup tasarım dili/renk/badge korundu.
- **STATE PERSISTENCE:** `chrome.storage.session` (`isgKatipSyncWorkspace` anahtarı) → seçili KATİP pilot firması, seçili İSGDenetim firması, pilot kaynağı, pilot sonucu, manuel önizleme (PII MASKELİ), ilk write planı, apply/verify sonucu, correlation id, workflowStep. 🔒 Token/cookie/JWT/Authorization/session secret/TC Kimlik No ASLA yazılmaz (intercepted KATİP response bellek-içi kalır).
- **SEKME/REFRESH DAYANIKLILIĞI:** Side Panel KATİP↔İSGDenetim sekme değişiminde ve sayfa refresh'inde KAPANMAZ; `chrome.tabs.onActivated/onUpdated` yalnızca KATİP durum göstergesini tazeler — workflow state TEMİZLENMEZ. Panel açılışında session state geri yüklenir; bridge READY olunca manuel doğrulama kaldığı yerden sürer. WRITE her zaman EXPLICIT kullanıcı onayı gerektirir (otomatik yazma YOK).
- **DEĞİŞMEYENLER (kritik):** bridge.ts protokolü, denetim-relay handshake, katip-main-hook, katip-content, service-worker capture, Discovery endpointleri, response interception, mevcut APPLY kanalı, pilot resolver/matching, write core, `isg-katip-sync` edge function, `isg_katip_apply_pilot` RPC. Yeni paralel bridge/matching/write motoru YOK; yeni KATİP HTTP isteği YOK.
- **KOD YAPISI:** popup.ts (2141 satır) paylaşılan modüllere ayrıştırıldı — `shared/katipBridge.ts` (self-contained enjekte sender'lar + köprü yardımcıları), `shared/katipConnection.ts` (tek canonical connect state machine), `shared/katipDiscovery.ts` (discovery + dry run render/akış), `shared/katipPilot.ts` (pilot workflow + persist), `shared/katipPilotTypes.ts` (loose tipler + etiketler), `shared/katipSession.ts` (session persistence), `shared/domUtils.ts`. Girişler: `popup/popup.ts` (küçük) + `popup/sidepanel.ts` (tam).
- **Build:** Vite SPA build **PASS**. Extension build (`node chrome-extension/build.mjs`) + gerçek Chrome Side Panel E2E bu ortamda **DOĞRULANAMADI** (komut çalıştırma/gerçek authenticated KATİP oturumu yok) — koda bakıp PASS denmedi.

### BN13. FAZ 6J.3-DIAG — PILOT APPLY KÖK NEDEN DÜZELTMESİ + GERÇEK HATA TEŞHİSİ
- **BULUNAN KÖK NEDEN (kesin, DB ile kanıtlandı):** `public.isg_katip_apply_pilot(p_plan jsonb)` fonksiyonunun DECLARE bloğunda `v_map jsonb := ''::jsonb;` vardı. plpgsql değişken default'larını BLOK GİRİŞİNDE değerlendirdiği için fonksiyon HER çağrıldığında tek satır iş yapmadan `22P02: invalid input syntax for type json` ile patlıyordu (`... during statement block local variable initialization — QUERY: ''::jsonb`). Sonuç: Firma/Personel/Atama hep `0/0/0`, `Hata: 0`, generic `IMPORT_FAILED`. **Mutation hiç gerçekleşmiyordu.**
- **DÜZELTME (minimum):** `v_map jsonb := jsonb_build_object();` — aynı boş `` nesnesi, tuzaklı literal olmadan. RPC `CREATE OR REPLACE` ile yeniden oluşturuldu; doğrulandı (`SELECT isg_katip_apply_pilot(...)` → `{"ok":true,...}`).
- **TEŞHİS KATMANI (yeni):** Kök neden bir daha GİZLENMESİN diye hata zinciri uçtan uca korunur:
  - **Edge (`isg-katip-sync`):** RPC hatası artık throw EDİLMEZ; `ImportOutcome.failure = { stage:'RPC', code, message }` üretir. Handler bunu `{ success:false, code:'PILOT_APPLY_ERROR', stage, error:{ code, message } }` olarak 200 ile döndürür. `sanitizeErrorCode`/`sanitizeErrorMessage` (max 64/300) ile temizlenir — token/cookie/JWT/Authorization/TC/PII/service-role ASLA dönmez. Generic `IMPORT_FAILED` yalnızca gerçekten bilinmeyen son çare olarak DURUYOR (ama artık sanitize mesaj + UNKNOWN stage ile).
  - **Client (`apply.ts`):** `pushIsgKatipImport` yapısal `success:false` gövdesinde throw etmez; `runIsgKatipPilotApply` bunu yakalayıp `KatipPilotApplyResult`'a `stage/errorCode/errorMessage` yazar (baseResult imzası genişletildi; normal OK yolunda null).
  - **Types:** `IsgKatipSyncResponse` → `stage/code/error` alanları; `LooseApply` → `stage/errorCode/errorMessage`.
  - **UI (Side Panel):** `renderApplyResult` hata durumunda EN ÜSTE `Aşama / Kod / Mesaj` satırlarını yazar; çelişkili `Hata: 0` düzeltildi (gerçek failure → `1`); `applied !== true` ise `Sonuç: Değişiklik uygulanmadı.` satırı eklenir.
- **KORUNANLAR:** tek-RPC transaction (rollback), idempotency (mevcut 3 partial unique index + ON CONFLICT DO NOTHING), pilot scope (tek firma + auth scope), `PILOT_ONLY=true` + global import OFF, `calisan_sayisi` YAZILMAZ, bridge/relay kanalları ve write core DEĞİŞMEDİ.
- **Build:** Vite SPA **PASS**. Edge `isg-katip-sync` yeniden deploy edildi. Gerçek Chrome E2E bu ortamda **DOĞRULANAMADI**.

### BN14. FAZ 6J.3 — PERSONEL + YASAL ATAMA WRITE/VERIFY TAMAMLAMA (FİRMA WRITE KORUNDU)
- **BAĞLAM:** Gerçek pilot testte Firma WRITE başarılı (0/1/0) ancak Personel `0/0/0`, Yasal Atama `0/0/0`, Verify Personel 0/1 & Atama 0/1. Verify'ın `0/1` beklemesi payload'da personel+atama bağının OLDUĞUNU kanıtlar → sorun PLAN üretiminde (yazma değil).
- **KÖK NEDEN 1 — Personel (bulundu):** `matchPersonnel` (hem canonical `src/lib/isgKatip/matching.ts` hem edge mirror'u `isg-katip-sync`) **NEW (oluştur) dalı İÇERMİYORDU**. Yerelde eşleşmeyen KATİP personeli her zaman `UNRESOLVED` dönüp pilot plana HİÇ girmiyordu → personel ne bağlanıyor ne oluşturuluyordu (`0/0/0`).
- **KÖK NEDEN 2 — Yasal Atama (bulundu):** `buildPilotApplyPlan` atama CREATE için `baslangic_tarihi` şart koşar; `normalizeKatipDate`'in `dd.MM.yyyy` dalı sonda SAAT kısmına takılınca (`01.01.2026 00:00:00` gibi) `null` dönüyordu → `baslangic_tarihi` boş → NOT NULL olduğu için atama plana GİRMİYOR (`0/0/0`).
- **DÜZELTME (minimum):**
  - `matching.ts` + edge `matchPersonnel`: eşleşme yoksa ve personel oluşturulabilirse (ad+soyad ve en az bir güvenilir kimlik: externalId VEYA TC) → `NEW`; aksi halde `UNRESOLVED` (davranış uyumlu; mevcut test beklentileri korunur).
  - `mapper.ts` `normalizeKatipDate`: `dd.MM.yyyy` deseni opsiyonel sondaki saat kısmını (`[ T].*`) kabul eder → gerçek KATİP datetime değeri düşmez.
- **TEŞHİS (yeni):** Edge `buildPilotApplyPlan` özeti (`personnelMatched/New/Unresolved/Conflict`, `assignmentNew`, üretilen aksiyon sayıları) `writeResult.plan` olarak döner; Side Panel `renderApplyResult` aksiyon 0 ise NEDEN'ini (durum dağılımı) satır olarak gösterir. PII taşımaz.
- **KORUNANLAR:** Firma WRITE akışı DEĞİŞMEDİ (yeniden tasarlanmadı); tek-RPC transaction + rollback; idempotency (mevcut 3 partial unique index + ON CONFLICT DO NOTHING); pilot scope (tek firma + auth scope); `PILOT_ONLY=true` + global import OFF, `calisan_sayisi` YAZILMAZ; Side Panel / Bridge / Capture / Discovery / write core protokolü DEĞİŞMEDİ; yeni paralel motor / yeni KATİP HTTP isteği YOK; token/cookie/JWT/TC storage'a yazılmaz.
- **QA:** Build Vite SPA **PASS**; Edge `isg-katip-sync` yeniden deploy edildi. Gerçek Chrome E2E + gerçek DB mutation bu ortamda **DOĞRULANAMADI** (uydurma PASS yazılmadı).
- **BEKLENEN (fix sonrası):** Firma 0/1/0 · Personel gerçek plana göre LINK veya CREATE · Yasal Atama 0/1/0 · Verify Firma/Personel/Atama PASS · ikinci Apply NOOP (duplicate yok).

### BN15. FAZ 6J.3 — PİLOT DRY RUN BAĞIMSIZ OPERATION STATE + APPLY/VERIFY/IDEMPOTENCY HARDENING
- **BAĞLAM:** Side Panel'de "Pilot Dry Run" butonuna basınca sonuç görünmüyordu; "DRY RUN HAZIR" durumu kayboluyor, bir süre sonra geri geliyordu.
- **KÖK NEDEN 1:** Pilot Dry Run, `runCanonicalDryRun` üzerinden çalışıyor ve **bağlantı göstergesini (`spa-text`) operation state sanıyordu** — `setSpaStatusExternal('warn','BAĞLANIYOR…')` ile "DRY RUN HAZIR" siliniyor, sonra `setSpaStatusExternal('ok','DRY RUN HAZIR')` ile geri geliyordu (gözlenen flicker).
- **KÖK NEDEN 2:** Dry Run breakdown'u yalnızca panelin EN ALTINDAKI genel "Dry Run" bölümüne (`dr-*`) yazılıyordu; Pilot butonunun yanında hiçbir sonuç/durum yoktu → "sonuç görünmüyor". Ayrıca `pilot-dryrun` butonu MANUEL akışta gizliydi.
- **DÜZELTME (minimum dosya):**
  - `chrome-extension/shared/katipPilot.ts`: BAĞIMSIZ `pilotDryRunState` (`IDLE|RUNNING|SUCCESS|ERROR`) + `pilotDryRunResult/Error` + `runPilotDryRun()` + `renderPilotDryRunPanel()` + `sendDryRunBridge()` (röle-öncelikli, aktif-sekme yedekli) + 15sn timeout + in-flight kilidi (double-click guard). Bağlantı göstergesine (`spa-text`) DOKUNMAZ; yalnızca `getConnState()!=='READY'` ise bağlanır.
  - `chrome-extension/popup/sidepanel.html`: `pilot-dryrun-panel` (durum + breakdown + not) eklendi.
  - `chrome-extension/shared/katipSession.ts`: `pilotDryRunState/Result/Error` persistence (refresh/tab değişiminde sonuç kaybolmaz).
- **DRY RUN SONUCU:** Firma/Personel/Yasal Atama (M/Y/Ç/B/A veya manuel WRITE planı: bağla/yeni) + Çalışan (KATİP/Merkez/fark · REPORT-ONLY) + **DB WRITE = 0**. Hata durumunda **Aşama / Kod / Mesaj** (BRIDGE_NOT_READY · DRY_RUN_TIMEOUT · DRY_RUN_ERROR · SNAPSHOT_NOT_READY · DRY_RUN_NOT_READY). PII/token/cookie/JWT yok.
- **APPLY HARDENING:** `PİLOTU UYGULA` artık yalnızca plan hazır **VE** pilot Dry Run BAŞARILI olduğunda açılır (`updateApplyReadiness`). Apply in-flight kilidi eklendi. WRITE akışı DEĞİŞMEDİ (mevcut `runIsgKatipPilotApply` → `pushIsgKatipImport` → `isg_katip_apply_pilot` tek-RPC transaction + verify).
- **KORUNANLAR:** Firma/Personel/Yasal Atama write core; tek transaction/rollback; idempotency (mevcut 3 partial unique index + ON CONFLICT DO NOTHING); pilot scope (tek firma + auth scope); `PILOT_ONLY=true` + global import OFF, `calisan_sayisi` YAZILMAZ, bridge/capture/discovery protokolü DEĞİŞMEDİ; yeni KATİP HTTP isteği YOK; token/cookie/JWT taşınmaz.
- **QA:** Build Vite SPA **PASS**. Extension build (`node chrome-extension/build.mjs`) + gerçek Chrome E2E bu ortamda **DOĞRULANAMADI** (uydurma PASS yazılmadı). Geliştirme sırasında **DB WRITE yapılmadı**.

### BN16. FAZ 6J.3 → 6J.4 — PİLOT KAPSAMI (SCOPE) MOTOR SEVİYESİNDE TEK FİRMAYA İNDİRİLDİ + NEW FİRMA KATİP AKTAR TEMELİ
- **BAĞLAM:** Pilot Dry Run sonucu GLOBAL dataseti raporluyordu (ör. Firma `1/97/0/0/0`, Yasal Atama `0/100/0/0/0`). Tek pilot firma seçilse bile 98 KATİP firması kapsama giriyordu.
- **KÖK NEDEN:** `runPilotDryRun` yalnızca MANUEL seçimde istemci-taraflı filtre uyguluyordu; **AUTO modda hiç filtre yoktu** → tüm yakalanmış satırlar `buildKatipDryRun`'a gidiyordu. MANUEL modda ise filtre boş dönerse global satırlara düşen hatalı fallback vardı. Kapsam filtreleme motorda zorunlu değildi.
- **DÜZELTME — KAPSAM TEK GERÇEK KAYNAK (motor seviyesi):**
  - `src/lib/isgKatip/dryRun.ts`: `buildKatipDryRun` artık `pilotFirmExternalId` (+ `pilotSource`, `pilotFirmTitle`) alır. Verilirse **yalnızca `hizmetAlanIsyeriId === pilot` satırları** normalize/matching'e girer; diğer tüm KATİP firmaları kapsam DIŞIDIR. Yeni `PILOT_SCOPE_UNRESOLVED` durumu (pilot satırı bulunamazsa WRITE YOK). Sonuca `scope` raporu eklendi (maskeli işyeri ID, kaynak, kapsam-dışı firma/atama teşhis sayaçları — write planına GİRMEZ).
  - `src/lib/isgKatip/matchingService.ts` + `src/lib/isgKatip/bridge.ts`: pilot kapsam parametreleri Dry Run girdisine/kanalına taşındı (yeni kanal/protokol YOK).
  - `src/lib/isgKatip/pilot.ts`: çözümlemeye HAM `katipWorksiteId` eklendi (yalnızca kapsam filtresi için; UI'da maskeli gösterilir).
  - `chrome-extension/shared/katipBridge.ts` + `katipPilot.ts`: Pilot Dry Run/Apply artık kapsamı (`resolvePilotScope`) hem AUTO hem MANUEL modda taşır; kapsam yoksa Dry Run ÇALIŞMAZ (`PILOT_SCOPE_UNRESOLVED`). Kapsam paneli (Pilot Kapsamı / KATİP İşyeri ID / Kaynak) + kapsam-dışı teşhis satırları Side Panel'e eklendi.
- **APPLY (AUTO mod):** `PİLOTU UYGULA` artık AUTO modda da (pilot kapsamı çözülmüş + Dry Run SUCCESS) açılır; kullanıcı onayı olmadan mutation YOK. WRITE core DEĞİŞMEDİ (`runIsgKatipPilotApply` → `pushIsgKatipImport` → `isg_katip_apply_pilot`). Backend `isg-katip-sync` zaten yalnızca pilot firma planını RPC'ye geçirir (defence-in-depth korundu). Verify PASS sonrası `PİLOT SENKRONİZASYONU TAMAMLANDI` durumu gösterilir.
- **NEW FİRMA (temel):** `IsgKatipFirmaSec` + `NewFirmaWizard` metinleri düzeltildi. Yanlış "İSG-KATİP entegrasyonu yapılandırılmadı" ve "KATİP çalışan sayısı doğrudan merkezi alana aktarılır" ifadeleri KALDIRILDI. Gerçek akış şeması (KATİP durumu → işyerleri → firma seç → önizleme/eşleşme → onay → kontrollü tek-firma WRITE) yansıtıldı; çalışan sayısı **REPORT-ONLY** olarak netleştirildi (merkezi alanı otomatik DEĞİŞTİRMEZ).
- **KORUNANLAR:** Bridge/capture/discovery protokolü; Dry Run READ-ONLY (DB WRITE = 0); `PILOT_ONLY=true`; global import OFF, otomatik sync OFF, tek pilot + tek İSGDenetim firması; helper yasal atama değil; `calisan_sayisi` YAZILMAZ; token/cookie/JWT/TC taşınmaz/loglanmaz; tek transaction/rollback + idempotency (3 partial unique index + ON CONFLICT DO NOTHING).
- **QA:** Build Vite SPA **PASS**. Extension build + gerçek Chrome E2E bu ortamda **DOĞRULANAMADI**. Geliştirme sırasında **DB WRITE yapılmadı**. **Kalan:** New Firma "İSG-KATİP'ten Aktar" 13-adımlı tam sihirbaz (firma→personel→yasal atama önizleme + kontrollü WRITE) temeli kuruldu; SPA ↔ extension captured veri bağlama UI'ı sonraki adımda tamamlanacak.

### BN17. FAZ 6J.4 — NEW FİRMA "İSG-KATİP'ten Aktar" GERÇEK KONTROLLÜ İÇE AKTARIM SİHİRBAZI + SPA'YA CAPTURED VERİ KANALI
- **BAĞLAM:** New Firma "İSG-KATİP'ten Aktar" kartı statik yer tutucuydu; SPA, eklentinin yakaladığı gerçek KATİP verisine erişemiyordu.
- **MİMARİ:** Bridge/capture/discovery REWRITE EDİLMEDİ; mevcut protokole **ADDITIVE** bir kanal eklendi. SPA, kalıcı İSGDenetim rölesine (`content/denetim-relay`) `ISG_KATIP_WORKSITES_REQUEST` yayınlar → röle service worker'a `ISG_KATIP_RELAY_CAPTURED_REQUEST` gönderir → servis worker KATİP sekmesindeki READ-ONLY interception satırlarını `readCapturedRows()` ile okur → röle aynı pencere/origin'e `ISG_KATIP_WORKSITES_RESULT` döner. Yeni KATİP HTTP isteği YOK; token/cookie/JWT taşınmaz.
- **DEĞİŞEN DOSYALAR:**
  - `src/lib/isgKatip/bridge.ts` (ADDITIVE): `KATIP_BRIDGE_WORKSITES_REQUEST/RESULT_CHANNEL` + `KatipBridgeWorksitesEnvelope` + `parseBridgeWorksitesEnvelope()` + `requestKatipWorksites()` (SPA initiator; röle geç yüklenebileceğinden bounded yeniden yayın + timeout).
  - `src/lib/isgKatip/newFirmaImport.ts` (YENİ, SAF): `matchKatipFirmToLocal()` — firma eşleşme sırası `isg_katip_id → vergi no → unvan`. Unvan tek başına OTOMATİK LINK DEĞİL (yalnızca öneri); belirsizde kullanıcı seçimi.
  - `chrome-extension/content/denetim-relay.ts` (ADDITIVE): SPA talebini karşılayan `window` message listener; mevcut dry-run/pilot/apply kanallarına DOKUNMAZ.
  - `chrome-extension/background/service-worker.ts` (ADDITIVE): `ISG_KATIP_RELAY_CAPTURED_REQUEST` handler → `readCapturedRows()`.
  - `src/pages/osgb/firmalar/components/IsgKatipFirmaSec.tsx` (YENİDEN): gerçek 7-aşamalı sihirbaz — KATİP durumu → işyerleri (arama) → firma seç → eşleşme önizleme → personel önizleme → yasal atama önizleme → çalışan sayısı (REPORT-ONLY) → final özet → açık onaylı TEK kontrollü WRITE → VERIFY.
  - `src/pages/osgb/firmalar/components/KatipImportPanels.tsx` (YENİ): PII-maskeli sunum panelleri (firma/personel/atama/çalışan sayısı/WRITE planı/apply sonucu).
- **WRITE CORE:** Değişmedi. Sihirbaz, mevcut `runIsgKatipPilotApply` → `pushIsgKatipImport` → `isg_katip_apply_pilot` zincirini ve taze RLS verify'ı kullanır. Tek transaction; partial write yok; kullanıcı onayı olmadan mutation YOK.
- **KORUNANLAR:** Dry Run READ-ONLY; `PILOT_ONLY=true`; global import OFF, otomatik sync OFF, tek firma kapsamı; `calisan_sayisi` YAZILMAZ; helper yasal atama değil; tarih normalizasyonu; token/cookie/JWT/TC loglanmaz; mevcut Side Panel/pilot flow bozulmadı.
- **QA:** Build Vite SPA **PASS**. Extension build (`node chrome-extension/build.mjs`) + gerçek Chrome E2E bu ortamda **DOĞRULANAMADI**. Geliştirme sırasında **DB WRITE yapılmadı**.
- **Kalan:** Extension build + gerçek Chrome E2E kullanıcı tarafında doğrulanacak; sihirbaz sonucu sonrası "Yeni Pilot Seç / Side Panel'e Git" aksiyonları sonraki adımda eklenebilir.

### BN18. FAZ 6J.4 — NEW FİRMA KATİP AKTARIMI: ADIM ADIM WIZARD + YENİ FİRMA (CREATE) + TEK TRANSACTION WRITE + VERIFY
- **KÖK NEDEN:** (1) Firma eşleşme paneli, güvenli yerel eşleşme bulunamadığında yanıltıcı "Güvenli firma eşleşmesi/önerisi bulunamadı; yerel firma seçin" gösteriyor ve kullanıcıyı **mevcut firma seçmeye zorluyordu**; "Yeni Firma" (CREATE) senaryosu modellenmemişti → yeni firma için Apply hiç açılamıyordu. (2) Modal alt butonu sabit "Firmayı Kaydet" ve KATİP modunda devre dışıydı; adım adım akış yoktu. (3) Sağ İSG özeti "Tehlike Sınıfı Seçilmedi/Hesaplama bekleniyor" ve "Dosyalar sekmesinden..." metni KATİP akışı için yanlıştı.
- **ÇÖZÜM:**
  - `src/lib/isgKatip/newFirmaImport.ts`: `buildKatipImportPlan()` (SAF, SALT-OKUMA) — `firmMode: 'existing' | 'new'` ile LINK/NOOP/CREATE/ÇAKIŞMA planı; `ready` bayrağı; çalışan sayısı REPORT-ONLY. `matchKatipFirmToLocal` NONE notu "Yeni Firma" olarak düzeltildi.
  - `src/lib/isgKatip/pilot.ts` (ADDITIVE): `KatipPilotAssignmentPreview`'ya `sertifikaSinifi` + `baslangicTarihi`; `resolveRowRoleInfo()` sertifika sınıfını da çözer.
  - `src/pages/osgb/firmalar/components/KatipImportPanels.tsx` (YENİDEN): Firma (Mevcut/Yeni seçim kartları), Personel (rol + Kaynak ISG_KATIP + İşlem), Yasal Atama (rol/sınıf/sözleşme/başlangıç + İşlem), Çalışan Sayısı, Final Özet, Apply sonucu.
  - `src/pages/osgb/firmalar/components/IsgKatipFirmaSec.tsx` (YENİDEN): 7 adımlı `WizardStepper` (KATİP → İşyeri → Firma → Personel → Yasal Atama → Çalışan → Final) + footer kontrolü (`KatipWizardFooterState`) → üst modala taşınır: ara adımlarda **"Devam Et"**, final adımda **"KATİP AKTARIMINI UYGULA"** (yalnızca plan hazır + onay checkbox). Bağlantı göstergesi artık operation state değil.
  - `src/pages/osgb/firmalar/components/NewFirmaWizard.tsx`: KATİP footer durumu (`onFooterChange`); manuel modda "Firmayı Kaydet", KATİP modda wizard'ın dinamik butonu. Sihirbaz başlığı "İSG-KATİP'ten Aktar".
  - `src/pages/osgb/firmalar/components/FirmaOzetPaneli.tsx` (ADDITIVE `context` prop): KATİP modda "Firma oluşturulduktan sonra hesaplanacak" + sözleşme kartı düzeltildi. "Dosyalar sekmesinden..." KATİP akışından çıkarıldı.
- **WRITE CORE:** DEĞİŞMEDİ. Sihirbaz ortak çekirdeği kullanır: `runIsgKatipPilotApply` → `pushIsgKatipImport` → server-side `isg_katip_apply_pilot` (tek transaction). Pilot ile New Firma arasında tek fark: firma kimliğinin nereden seçildiği (Side Panel vs wizard). Paralel write motoru YOK.
- **VERIFY / IDEMPOTENCY:** Değişmedi — `verifyPilotApply` taze RLS snapshot ile doğrular; PASS olmadan "tamamlandı" yok. 3 partial unique index + `ON CONFLICT DO NOTHING` korunur; ikinci çalıştırma duplicate üretmez.
- **KAPSAM/GÜVENLİK:** Tek firma kapsamı; başka firma/personel/atama plana giremez; helper yasal atama değil; Dry Run/preview SALT-OKUMA (DB WRITE = 0); global import OFF, otomatik sync OFF, yeni KATİP HTTP isteği YOK; token/cookie/JWT/Authorization/TC okunmaz/taşınmaz/loglanmaz; `calisan_sayisi` YAZILMAZ.
- **QA:** Build Vite SPA **PASS**. Extension build (`node chrome-extension/build.mjs`) + gerçek Chrome E2E bu ortamda **DOĞRULANAMADI**. Geliştirme sırasında **DB WRITE yapılmadı**.

### BN19. FAZ 6J.4 — GERÇEK WRITE/VERIFY FAILURE HARDENING (KÖK NEDEN: İKİ FARKLI MATCHING + NON-ATOMİK RPC)
- **GERÇEK KÖK NEDEN (kanıtlı):** Gerçek Chrome testinde New Firma KATİP aktarımı → **firma CREATE=1, personel 0/0/0, atama 0/0/0, Verify (firma BAĞLI · personel 0/1 · atama 0/1)**. DB teyidi: `firmalar` isg_katip_id=2 kayıt, `personeller`/`atamalar` isg_katip_id=0. Nedeni: (1) **SPA önizleme motoru ile edge function matching motoru birbirinden farklıydı** — önizleme TC eşleşmesini isim kontrolü OLMADAN "MATCH" sayıyor, backend ise `NAME_MISMATCH` → CONFLICT verip personeli SESSİZCE düşürüyordu; önizleme "güvenli" dediği için Apply açıldı. (2) **`isg_katip_apply_pilot` NON-ATOMİKTİ** — atama ilişkisi çözülemezse `v_errors++` yapıp YİNE DE başarıyla dönüyordu → **kısmi state** (firma yazıldı, personel/atama yazılmadı, rollback YOK).
- **ÇÖZÜM:**
  - `isg_katip_apply_pilot` (DB, CREATE OR REPLACE): `v_errors > 0` ise `raise exception 'KATIP_APPLY_RELATION_UNRESOLVED'` → **TAM ROLLBACK**; kısmi write imkânsız. `v_map` düzeltmesi ve tüm iş mantığı korundu.
  - `supabase/functions/isg-katip-sync/index.ts`: pilot RPC'den **ÖNCE** bloklayıcı gate — firma/personel/atamadan herhangi biri CONFLICT/UNRESOLVED/SKIPPED ise VEYA atama yazılabilir personele bağlanamıyorsa **RPC HİÇ ÇAĞRILMAZ, firma DAHİ oluşturulmaz**; `WRITE_PLAN_*` teşhis kodu + planDiag döner.
  - `src/lib/isgKatip/pilot.ts`: önizleme personel eşleştirmesi backend ile **birebir hizalandı** (external ID → TC mutabakatı; TC → isim mutabakatı) + PII'siz `reason` kodu (NAME_MISMATCH/TC_EXTERNAL_MISMATCH/…).
  - `src/lib/isgKatip/matchingService.ts`: DRYRUN personel snapshot'ına `ad,soyad` eklendi (isim mutabakatı için).
  - `src/lib/isgKatip/newFirmaImport.ts`: `ready` gate artık `personnel.unresolved > 0`'ı da bloklar.
  - `src/lib/isgKatip/apply.ts`: `verify` sonucuna entity-bazlı `diagnostics` (entity/criterion/expected/actual/ok) eklendi.
  - `IsgKatipFirmaSec.tsx` + `KatipImportPanels.tsx`: verify FAIL → "bağlantılar yeniden kontrol edilmeli" + **"Bağlantıları Yeniden Kontrol Et"** butonu; başarısız apply sonrası footer **"Önce Bağlantıları Yeniden Kontrol Edin"** olarak kilitli → tekrar write için önce taze Dry Run zorunlu. Çakışma nedeni satır altında gösterilir.
- **MEVCUT DB'YE MÜDAHALE:** YOK. Oluşan 2 firma SİLİNMEDİ; sonraki Dry Run bunları `NOOP/LINK` görecek. Personel/atama için otomatik cleanup YAPILMADI. Geliştirme sırasında DB WRITE = 0.
- **KAPSAM/GÜVENLİK:** Global import OFF, otomatik sync OFF, tek firma scope (defence-in-depth), yeni KATİP HTTP isteği YOK; token/cookie/JWT/Authorization/TC loglanmaz; `calisan_sayisi` REPORT-ONLY.
- **QA:** Build Vite SPA **PASS**; edge function `isg-katip-sync` deploy edildi; RPC `isg_katip_apply_pilot` güncellendi. Gerçek Chrome E2E bu ortamda **DOĞRULANAMADI** (gerçek KATİP oturumu + `node chrome-extension/build.mjs` yok).

### BN20. FAZ 6J.5 — KATİP AKTİF SÖZLEŞME MOTORU (KANONİK CONTRACT ACTIVITY DOMAIN + NEW/PILOT ORTAK FİLTRE)
- **KÖK NEDEN:** 100 ham hizmet sözleşmesi içinde geçmiş/sonlandırılmış kayıtlar "aktarılabilir işyeri" olarak görünüyordu çünkü **hiçbir katmanda sözleşme aktiflik filtresi YOKTU**; kod yalnızca `hizmetAlanIsyeriId` üzerinden unique işyeri çıkarıyor ve `ongoing` endpoint ADINI aktif kanıtı sayıyordu (doğrulanmamış varsayım).
- **KANONİK MODEL (`src/lib/isgKatip/contractActivity.ts`, yeni):** TEK çözümleyici `normalizeKatipContractActivity(row)` → `ACTIVE | TERMINATED | CANCELLED | EXPIRED | PENDING | UNKNOWN`. Karar sırası: (1) `sozlesmeSonlandirilmaNedeni` dolu → TERMINATED (KATİP UI "Sözleşme Sonlandırılma Nedeni"); (2) `sozlesmeyiSonlandiranAdSoyad` dolu → TERMINATED; (3) statü/onay metni (`sozlesmeStatu`/`sozlesmeStatuId`/`sozlesmeOnayDurumu`/`sozlesmeOnayDurumuId`/`…OnayStatüsü`) kelime taraması (negatif → terminated/cancelled/expired/pending; pozitif → active); (4) `sozlesmeBitisTarihi` geçmiş → EXPIRED; (5) belirleyici işaret yok → **UNKNOWN (AKTİF KABUL EDİLMEZ, güvenli taraf)**. Alan adları UYDURULMADI — mevcut `KatipHizmetSozlesmesiRow` tipinde tanımlı gerçek alanlardır.
- **İŞYERİ ÇÖZÜMÜ:** `resolveKatipWorksiteActivity(rows)` — aynı işyerinin TÜM sözleşmeleri birlikte değerlendirilir: en az bir ACTIVE → ACTIVE; yoksa en az bir UNKNOWN → UNKNOWN; aksi halde INACTIVE. (İlk satıra göre filtreleme YOK.) `summarizeKatipContractActivity(rows)` PII'siz sayaç özeti üretir (ham/benzersiz/aktif/terminated/cancelled/expired/pending/unknown + aktif/inaktif/unknown işyeri + transferable).
- **TEK KAYNAK:** Aynı çözümleyici discovery/pilot/New Firma/preview/apply gate/verify tarafından kullanılır. İkinci filtre motoru OLUŞTURULMADI.
- **PILOT (`pilot.ts`):** `listKatipPilotFirmCandidates` artık RAW→unique işyeri değil; GROUP BY işyeri → aktiflik çözümü → **yalnızca ACTIVE**. UNKNOWN/TERMINATED işyerleri listede GÖRÜNMEZ. `resolveKatipPilotCandidate` + `buildKatipManualPilotPreview` yalnızca AKTİF sözleşme satırlarını işler (terminated yasal atama/personel üretmez). Yeni `filterActiveHizmetRowsByWorksite`.
- **NEW FİRMA (`newFirmaImport.ts`):** `buildKatipImportPlan` `activityStatus` alır; `ready` artık `activityStatus === 'ACTIVE'` ZORUNLU — TERMINATED/CANCELLED/EXPIRED/PENDING/UNKNOWN → **PLAN NOT READY → APPLY DISABLED**.
- **APPLY (`apply.ts`):** `runIsgKatipPilotApply` pilot kapsamındaki satırları işyerine daraltıp kanonik aktifliği çözer; ACTIVE değilse yeni durum `PILOT_APPLY_SCOPE_NOT_ACTIVE` ile reddedilir; yalnızca AKTİF satırlar normalize edilir; `context.contractActivityStatus='ACTIVE'` taşınır.
- **EDGE FUNCTION (`isg-katip-sync`) DEFENCE-IN-DEPTH:** pilot import (gerçek yazma) için `payload.context.contractActivityStatus === 'ACTIVE'` şartı; eksik/ACTIVE dışı ise **firma DAHİ oluşturulmadan** reddedilir (`stage=CONTRACT_ACTIVITY`, `error.code=CONTRACT_ACTIVITY_NOT_ACTIVE`). Atomik RPC (`isg_katip_apply_pilot`) DOKUNULMADI.
- **UI:** `IsgKatipFirmaSec` + `KatipImportPanels` — PII'siz aktiflik özeti paneli (KATİP Hizmet Sözleşmeleri: ham/aktif/sonlandırılmış/…), `"KATİP'te Aktif İşyeri Bulunamadı"` dürüst empty state (geçmiş sözleşmeler aktarım kapsamına alınmaz), Final Özet'te "Sözleşme Aktifliği" satırı. Side Panel (`katipPilot.ts`) manuel listede aktif sözleşme yokken PII'siz neden özeti. Mevcut 7 adımlı wizard ve SharedUICore korundu; yeni tasarım sistemi YOK.
- **KORUNANLAR:** canonical matching/atomic RPC/verify diagnostics/single-firm scope/employee-count protection/global import OFF/automatic sync OFF/YENİ KATİP HTTP isteği YOK/token-cookie-JWT-TC loglanmaz. `firmalar.calisan_sayisi` KATİP değeriyle DEĞİŞMEZ (REPORT-ONLY).
- **MEVCUT DB'YE MÜDAHALE:** YOK (silme/cleanup yok; geliştirmede DB WRITE = 0).
- **TEST:** `chrome-extension/tests/isg-katip-contract-activity.test.ts` (yeni) — ACTIVE/TERMINATED/CANCELLED/EXPIRED/UNKNOWN çözümü; TERMINATED+ACTIVE=ACTIVE; TERMINATED+CANCELLED=INACTIVE; UNKNOWN+TERMINATED=UNKNOWN; 100 ham/0 aktif=0 transferable; 100 ham/5 işyeri/3 aktif=3; preview aktif-filtresi; apply gate (ACTIVE ready / UNKNOWN+TERMINATED disabled); idempotency determinizmi.
- **QA:** Vite SPA **BUILD PASS**. `node chrome-extension/build.mjs` + gerçek Chrome E2E bu ortamda **DOĞRULANAMADI** (uydurma PASS yok).

### BN21. FAZ 6J.6 — KATİP ÇOK-SAYFALI CAPTURE AGGREGATION + CANONICAL RÖLE HARDENING (WIZARD KÖPRÜ TIMEOUT FIX)
- **KÖK NEDEN 1 (pagination / 100 limiti):** `content/katip-main-hook.ts` `capture()` her yeni response'u `store[path] = {...}` ile **ÜZERİNE yazıyordu** → yalnızca SON yakalanan sayfa (100 satır) kalıyordu; sayfa birikimi YOKTU. Ayrıca `createChromeCapturedTransport` `pageIndex>0`'ı yapay olarak boş döndürüyordu. Kullanıcının ~380 kaydı bu yüzden hep 100 görünüyordu.
- **KÖK NEDEN 2 (New Firma "Köprü zaman aşımı"):** İKİ ayrı röle implementasyonu vardı. Declarative `content/denetim-relay.ts` `ISG_KATIP_WORKSITES_REQUEST` window handler'ını İÇERİYORDU; ancak scripting ile enjekte edilen `denetimRelayInstaller()` (katipBridge) bu handler'ı **İÇERMİYORDU**. Side Panel açılınca scripting rölesi kurulup frame bayrağını (`__ISG_KATIP_DENETIM_RELAY__`) kapıyor, declarative röle devre dışı kalıyor → SPA'nın WORKSITES isteği yanıtsız → **wizard zaman aşımı** (bu arada Side Panel doğrudan `chrome.scripting` ile okuduğu için çalışıyordu). Bu, kullanıcının gözlemiyle (Side Panel OK + New Firma hata) BİREBİR örtüşür.
- **YENİ KANONİK MODÜL (`src/lib/isgKatip/capture.ts`, yeni, SAF):** `dedupeRows` (uniqueId/sozlesmeId/sozlesmeSurecId ile tekilleştirme; kimliksiz satır KORUNUR), `mergeCapturedPages`, `readReportedTotal` (savunmacı metadata okuma; yoksa null), `summarizeCapture` → `{ rowCount, pageCount, lastPageIndex, lastPageSize, lastPageRowCount, terminalPageReached, reportedTotal, complete }`. Completeness: metadata varsa `rowCount >= total`; yoksa **son sayfa pageSize'dan az** ise complete. `rowCount === pageSize` olan tek sayfa "tamamlandı" SAYILMAZ (madde 6).
- **MAIN HOOK (`katip-main-hook.ts`):** Her yakalanan response artık sayfa-bazlı BİRİKTİRİLİR (`reqBody.pageIndex` anahtarı; aynı sayfa üzerine yazılır). `entry.rows` = tüm sayfaların birleşik (dedup) satırları; `entry.meta` = PII'siz sayfa metadata'sı; `entry.reportedTotal`. Okuyucular yalnızca `entry.rows` okur → 380 kayıt 380 kalır (ikinci yakalamada 400 olmaz).
- **OKUYUCULAR:** `katipBridge.readKatipRawCaptured` + service-worker `mainWorldReadCaptured` artık BİRLEŞİK satırları döndürür (`{ body: { tableData: mergedRows } }`) → discovery/pilot/Side Panel/wizard/verify AYNI canonical datasetten beslenir. `readCapturedRows` + SPA `requestKatipWorksites` yeni `dataset` özetini taşır.
- **RÖLE FIX (`katipBridge.denetimRelayInstaller`):** Eksik `ISG_KATIP_WORKSITES_REQUEST` → `ISG_KATIP_RELAY_CAPTURED_REQUEST` → `ISG_KATIP_WORKSITES_RESULT` handler'ı eklendi. İki röle (scripting + declarative) artık AYNI kanalları destekler → tek canonical davranış.
- **UI (`IsgKatipFirmaSec` + `KatipImportPanels`):** Yeni `KatipCaptureStatusPanel` — "Toplanan kayıt / Sayfa / Son sayfa (satır/boyut) / sunucu toplamı" + YÜKLENİYOR/TAMAMLANDI rozeti. `KATİP verisi alınamadı` (bridge yok) ile `Aktif işyeri bulunamadı` (raw>0, aktif=0) ve `veri tamamlanmadı` durumları KESİN AYRIŞTIRILDI.
- **KORUNANLAR:** canonical matching/atomic RPC/verify/employee-count/single-firm scope/global import OFF/automatic sync OFF. YENİ KATİP HTTP isteği YOK; token/cookie/JWT/TC/PII log YOK. Mevcut DB'ye MÜDAHALE YOK (silme/cleanup yok).
- **QA:** Vite SPA **BUILD PASS**. `node chrome-extension/build.mjs` + gerçek Chrome E2E bu ortamda **DOĞRULANAMADI** (uydurma PASS yok).

### BN22. DESTEK SİSTEMİ REVİZYONU — TEK MODAL + ADMIN AYRIMI + DOSYA/REALTIME HARDENING
- **KRİTİK AYRIM:** Admin panelindeki `Destek Talepleri` sidebar + listeleme/yönetim ekranı **AYNEN KORUNDU** (`/destek`, `SupportTicketList canCreate=false`, `SupportTicketDetail`). Kullanıcı panellerinde (OSGB/Firma/Uzman/Hekim) ayrı destek listeleme sayfası **KALDIRILDI** → `panelNavigation.ts` sidebar girdileri silindi, 4 `pages/*/destek-talepleri/page.tsx` **panele redirect**'e çevrildi (eski liste UI'ı kullanıcıya gösterilmez).
- **TOPBAR DESTEK İKONU (`SupportButton.tsx`, yeni):** Bildirim zilinin yanına headset ikonu; tıklanınca **dropdown/popover/ara ekran YOK** → doğrudan tek Destek modalı açılır. Okunmamış destek yanıtı varsa zarif rozet (`fetchSupportUnreadCount`, yalnızca `support_notifications.read=false`).
- **TEK DESTEK MODALI (`SupportCenterModal.tsx`, yeni; `bodyLayout:'fill'`):** İki kolon — Sol: sekmeler **“Yeni Destek Talebi” / “Geçmiş Destek Talepleri”**; Sağ: **aktif destek görüşmesi**. **Ayrı “Mesajlaşma” sekmesi YOK.** Desktop scrollsuz (header/modal sabit; yalnızca liste ve konuşma gövdeleri iç scroll). Mobilde tek kolon + konuşmada tek geri ikonu (full-screen akış).
- **YENİ TALEP FORMU (`SupportTicketForm.tsx`):** Konu (150) + Kategori + Açıklama (2000, sayaç). **Öncelik KULLANICIDAN KALDIRILDI** — kategoriye göre sunucu-taraflı başlangıç değeri (`defaultPriorityForCategory`), kullanıcı değiştiremez. Süreç: create → ilk mesaj → ekler → talep no → **aynı modal içinde aktif görüşme** (sayfa değişmez).
- **DOSYA SİSTEMİ (`SupportFilePicker.tsx` + `supportService.uploadAttachment`):** Geniş, güvenli destek (PDF/JPG/PNG/WEBP/DOC/DOCX/XLS/XLSX/PPT/ZIP/RAR/CSV/TXT/MP4/MOV/MP3/WAV...), **25 MB/dosya**, çoklu + sürükle-bırak + progress + başarı/hata + kaldırma + mükerrer engeli. Doğrulama tek merkezden (`fileUpload.validateUploadFile`), storage adı `sanitizeStorageName` ile güvenli. Yükleme başarısızsa dosya geri alınır (orphan yok). **Erişim signed URL + RLS** ile korunur.
- **GÖRÜŞME (`SupportConversation.tsx`):** Gerçek `support_messages` + `support_attachments`; gönderen tarafı avatarı, tarih/saat **Europe/Istanbul**, gün ayracı. **Realtime abonelik (`subscribeSupportMessages`) + 12 sn poll fallback**; duplicate listener yok, unmount'ta temizlenir. Kullanıcı aşağıdaysa otomatik scroll; değilse “Yeni mesaj” göstergesi. Görsel ekler thumbnail + tam ekran önizleme; dosyalar güvenli indirme.
- **ÇÖZÜM:** `resolved/closed` → kullanıcı için **“Çözüldü” / “Talebiniz çözüme ulaştı”**; mesaj kutusu kilitlenir, **“Yeni Destek Talebi Oluştur”** yeni ticket açar (eski ticket yeniden açılmaz).
- **KORUNANLAR:** SharedUICore, Dark/Light/Auto (token tabanlı), admin destek yönetimi, `create_support_ticket` RPC / `support_*` tabloları / `support` bucket / RLS. **Yeni tablo/edge function/şema değişikliği: 0.** Vite **BUILD PASS**; gerçek tarayıcı E2E bu ortamda DOĞRULANAMADI (uydurma yok).

### BN23. MESAJLAŞMA FONKSİYON HARDENING (İLET + GERÇEK SİL + REALTIME) & DESTEK REALTIME TAMAMLAMA
- **MESAJ İLET (forward):** `mesajlasma` edge function'a `forward_message` action (yeni). Kaynak mesaja ve hedef sohbete **katılımcı olma** zorunlu (cross-OSGB engeli); kaynak mesaj **değişmez**, hedef sohbete yeni mesaj oluşur; ekler aynı `storage_path` ile bağlanır (kopya yok). Frontend: `forwardMessage()` servisi + yeni `ForwardMessageModal.tsx` (erişilebilir sohbet seçici) + mesaj menüsünde **“İlet”**.
- **GERÇEK MESAJ SİLME (soft-delete):** `delete_message` action (yeni). `messages.deleted_at` set edilir, içerik temizlenir (fiziksel satır silinmez). Yetki **backend'de**: yalnızca gönderen kendi mesajını (admin istisnası) silebilir. Karşı tarafta **“Bu mesaj silindi”** placeholder’ı gösterilir. Uzun-bas/context menüde **“Sil”** (yalnızca kendi mesajı).
- **REALTIME:** `messages` UPDATE event'i aktif sohbette `deleted_at`/`body` alanlarını canlı yansıtır (silme anında placeholder). Id bazlı dedupe korunur; duplicate subscription/mesaj yok.
- **MOBİL:** Long-press menüsü **Yanıtla / Kopyala / İlet / Sil** (Sil yalnız own). Klavye açılışında composer’ı klavye üstünde tutmak için `visualViewport` tabanlı konteyner yüksekliği. Fullscreen + tek geri ikonu korundu.
- **DSP:** Ayrı DSP rolü/paneli olmadığından sahte veri üretilmedi; DSP sekmesi **konuşma yoksa gizlenir** (boş/kırık görünüm bırakılmaz).
- **DESTEK REALTIME TAMAMLAMA (gerçek açık):** Admin detay modalı `SupportTicketDetail`’da realtime/poll **yoktu** → admin açıkken kullanıcı mesajı refresh gerektiriyordu. `subscribeSupportMessages` + 12 sn poll eklendi (silent load, spinner flash yok). Kullanıcı tarafına `subscribeSupportTicket` eklendi → admin talebi çözdüğünde **“Talebiniz çözüme ulaştı”** canlı görünür. Admin listesine `support_tickets` realtime aboneliği eklendi.
- **KORUMA:** Tasarım/3 kolon/tema/mobil fullscreen değişmedi; sesli/görüntülü arama EKLENMEDİ; cross-OSGB engeli backend’de; RLS korundu. Vite **BUILD PASS**. Edge function kaynağı güncellendi ancak **dağıtım için backend bağlantısı gerekli (bu ortamda bağlı değil)** → gerçek E2E DOĞRULANAMADI (uydurma yok).

### BN24. ZİYARET/İZİN AÇIKLARI + OSGB ZİYARET RAPORU PDF HİZALAMA + PLAN İPTAL→YENİ PLAN DEVRİ
- **H1 (planı olmayan firmaya ziyaret başlatma — kök neden):** `ziyaret-planlama` → `geziciStart` artık firma için geçerli `gezici_sure_planlari` satırı YOKSA `FIRMA_PLAN_YOK` ile reddeder (önceden `plan_id=null` ile ziyaret oluşturuyordu). `resolveGeziciFirmalar` yalnızca gerçek planı olan firmaları döndürür (frontend seçim listesi de temizlendi).
- **H2 (izin talebinde seçilen tarih kaybolması):** `createIzinTalep` gun_degisikligi dalı artık `tarih` parametresinden hafta (`mondayOf(tarih)`) ve günü türetir; geçmiş hafta reddi; seçilen tarih `baslangic_tarihi/bitis_tarihi` olarak kaydedilir. Önceden talep HER ZAMAN içinde bulunulan haftaya yazılıyordu.
- **H3 (personel_izinleri programa yansımıyordu):** `generateForProgram` artık OSGB’nin girdiği merkezi izin tablosu `personel_izinleri`’ni de okur; izinli günlerde occurrence ÜRETİLMEZ/iptal edilir. İki izin tablosu arası bağ kopukluğu kapatıldı.
- **PLAN İPTAL → YENİ PLAN DEVRİ:** `handleCreate` (gezici) eski/pasif plana ait firma+dönem rate satırını YENİ plana devreder (`program_id` güncellenir) → `DUPLICATE_SURE` bloğu kalkar, iptal sonrası yeni plan sorunsuz devreye girer.
- **OSGB ZİYARET RAPORU PDF HİZALAMA (gerçek bug):** `personelReport/visitPdfDoc` Süre Bazlı + Detaylı Liste tablolarında `showRowNumber` açıkken başlık satırında `#` hücresi YOKTU → gövde bir kolon sola kayıyordu (Firma değeri `#` kolonunda görünüyordu). Başlıklara koşullu `#` eklendi; PDF satırları artık doğru hücrede.
- **Not:** OSGB “Rapor Al” zaten paylaşılan premium motoru (`visitPdf`/`visitExcel`, ExcelJS) kullanıyor — silinecek eski/ikinci bir PDF/Excel üreticisi bulunmadı.
- **Backend deploy:** `mesajlasma` edge function yeniden dağıtımı ve canlı destek realtime için backend bağlantısı gerekli (bu ortamda bağlı değil). Vite **BUILD PASS**.

### BN25. ZİYARET RAPORU → ORTAK RENDER MOTORU (ÖNİZLEME = PDF) + ÖLÜ MOTOR TEMİZLİĞİ
- **Ziyaret raporu sihirbaz mimarisine taşındı:** Personel Raporu sihirbazıyla AYNI yol — ekranda gösterilen HTML doküman sayfaları (`VisitReportPage`) gizli alanda aynen render edilip ortak `pdfRenderer` (html2canvas) ile gerçek PDF'e çevrilir. Böylece **ÖNİZLEME === İNDİRİLEN PDF** ve görsel dil sihirbazla birebir (antrasit + teal, kurumsal başlık, KPI kutuları, tablo, legend, footer, filigran). Sayfa A4 LANDSCAPE (1123×794).
- **Yeni dosyalar:** `src/lib/personelReport/visitReportEngine.ts` (sayfalama modeli), `src/components/feature/personel-report/VisitReportPage.tsx` (HTML doküman sayfası), `VisitReportPreview.tsx` (canlı önizleme + tam ekran), `VisitExcelPreview.tsx` (çalışma-sayfası önizleme), `src/lib/personelReport/visitPdfExport.ts` (ortak motor ile PDF üretimi).
- **Kaldırılan eski/ayrı PDF/Excel motorları:** `personelReport/visitPdf.ts` + `personelReport/visitPdfDoc.ts` (jsPDF + AutoTable doküman üreticisi) SİLİNDİ; ölü kalan `personelReport/pdfTheme.ts` SİLİNDİ. Tek PDF yolu artık ortak html2canvas motorudur. (Excel `.xlsx` üretimi hâlâ ExcelJS ister — `visitExcel.ts` korundu ancak paleti sihirbaz görsel diline eşitlendi.)
- **Palet birleştirme:** `personelReport/reportPalette.ts` zümrüt/antrasit tonlardan sihirbazın teal/antrasit diline (#0D9488 accent, #1E293B head) güncellendi → Excel ve PDF aynı görünür.
- **Ziyaret düzeltmeleri (H1/H2/H3 + plan devri) kodda mevcut ve doğrulandı** (`FIRMA_PLAN_YOK`, `createIzinTalep` tarih bazlı hafta türetimi, `personel_izinleri` entegrasyonu, iptal→yeni plan devri). Çalışan sisteme yansıması için `ziyaret-planlama` edge function'ının yeniden dağıtımı gerekir (backend bağlı değil).
- **Ölü kod taraması:** Barrel + route yapısı nedeniyle güvenle silinebilir başka ölü dosya bulunmadı; yalnızca eski PDF motoruna ait `personelReport/pdfTheme.ts` kaldırıldı. Vite **BUILD PASS**.

### BN26. FAZ 1/4 — KATİP READ / PAGINATION / CANONICAL DATA STATE KAPANIŞ PAKETİ
- **AMAÇ:** Mevcut READ-ONLY multi-page capture altyapısının ÜZERİNE eksik olan canonical data state katmanını, DATA_INCOMPLETE UI/pilot gate'lerini, capture session izolasyonunu ve TEST A–T kapsamını eklemek. Bridge protokolü / MAIN hook akışı / service-worker mimarisi / RLS / write core / contractActivity iş mantığı DEĞİŞTİRİLMEDİ.
- **Canonical data state (`src/lib/isgKatip/capture.ts`, additive):** `KatipDataState = IDLE|LOADING|DATA_INCOMPLETE|DATA_COMPLETE|ERROR` + `deriveKatipDataState()` (deterministik; timeout tek başına DATA_COMPLETE DEĞİL). Mevcut `complete: boolean` KORUNDU (geriye uyumlu).
- **Canonical pagination meta:** `KatipPaginationMeta { pageIndex, pageSize, totalCount, totalPages, hasNext, isLastPage }` (yalnızca güvenilir okunabilen alanlar; yoksa null). `readReportedPagination()` → body/kök `totalElements`/`totalPages` (yalnızca number). `buildDatasetReport()` → state + receivedPages + pagination + terminalPageReached + sessionId + timeout. `resolveOverallDiscoveryStatus()` → hizmet+personel ayrı; biri incomplete ise overall READY olamaz.
- **DATA GATE (`src/lib/isgKatip/dataGate.ts`, yeni saf modül):** `deriveWorksiteGateView()` → BRIDGE_ERROR/ERROR/LOADING/DATA_INCOMPLETE/NO_ACTIVE_WORKSPACE/READY. DATA_INCOMPLETE iken "Aktif İşyeri Bulunamadı" ÜRETİLMEZ.
- **UI bug fix:** `IsgKatipFirmaSec.tsx` artık canonical gate kullanıyor; DATA_INCOMPLETE → yeni `KatipDataIncompleteState` (toplanan/beklenen ilerleme), yalnızca DATA_COMPLETE+active=0 → `KatipNoActiveWorksiteState`. `KatipCaptureStatusPanel` state rozeti (BAŞLAMADI/YÜKLENİYOR/VERİ TOPLANIYOR/VERİ TAMAMLANDI/VERİ TOPLANAMADI).
- **Pilot gate:** `KatipPilotStatus`'a `PILOT_DATA_INCOMPLETE` eklendi; `resolveKatipPilotCandidate`/`resolveKatipManualPilotCandidate` `datasetComplete === false` iken "aday yok" sonuçlarını PILOT_DATA_INCOMPLETE'e çevirir (geçerli aday varsa dönmeye devam eder). Side Panel AUTO pilot + pilot Dry Run DATA_INCOMPLETE'ta çalışmaz; manuel list mesajı "veri henüz tamamlanmadı" der.
- **Personel dataset + overall:** Extension `readCapturedRows().report = { hizmet, personel, overall }`; Side Panel Discovery notunda overall durum (VERİ TOPLANIYOR/VERİ TAMAMLANDI…) gösterilir.
- **Capture session isolation (MAIN hook, minimal additive):** `captureSessionId`; önceki döngü ZATEN tamamlanmışken yeni sayfa-0 gelirse oturum sıfırlanır (eski sayfalar yeni dataset'e taşınmaz). Aynı döngü içi sayfa tekrarı hâlâ dedupe/update.
- **Testler:** `chrome-extension/tests/isg-katip-data-state.test.ts` → TEST A–T + gate matrisi + pagination meta + pilot DATA_INCOMPLETE + summarizeCapture regression.
- **KISITLAR KORUNDU:** DB WRITE=0, import/pilot apply OFF, yeni KATİP isteği=0, token/cookie okunmadı, employee count auto-write kapalı. Vite **BUILD PASS**. Gerçek Chrome E2E bu ortamda yapılmadı (extension build + gerçek KATİP oturumu gerekir).

### BN27. FAZ 2/4 — KATİP → OSGB PERSONELLER + ATAMALAR ENTEGRASYONU (SALT-OKUMA)
- **AMAÇ:** FAZ 1'de sertleştirilen canonical KATİP datasetini (READ-ONLY) OSGB Personeller ve Atamalar ekranlarına güvenli biçimde bağlamak. Yeni paralel eşleştirme motoru / yeni KATİP endpointi / yeni veri modeli OLUŞTURULMADI; bridge protokolü, MAIN hook, service-worker, RLS/scope, write core ve contractActivity iş mantığı DEĞİŞTİRİLMEDİ.
- **Saf entegrasyon çekirdeği (`src/lib/isgKatip/osgbIntegration.ts`, yeni):** `buildOsgbKatipIntegration()` → yakalanan KATİP satırları + authenticated OSGB snapshot'ı MEVCUT `buildSyncPayload` + `matchPersonnel`/`matchAssignments` üzerinden karşılaştırır ve PII'siz durum modeli üretir. `KatipEntityLinkStatus = MATCH|NEW|CONFLICT|NOT_FOUND|UNRESOLVED|INCOMPLETE`. Yalnızca kanonik **ACTIVE** hizmet sözleşmeleri eşleşme adayıdır; TERMINATED/CANCELLED/EXPIRED/PENDING/UNKNOWN aday DEĞİL. Saha Uzmanı (helper) yasal atama olarak asla sayılmaz (`resolveAtamaKatipStatus` helper → null). `resolvePersonelKatipStatus` / `isFirmaKatipLinked` / `assessOsgbKatipScope` (CROSS_OSGB reddi) / `maskKatipIdentity` yardımcıları.
- **Firma KATİP eşleşmesi DÜZELTİLDİ:** `isFirmaKatipLinked` artık `firmalar.isg_katip_id` DB gerçeğine dayanır; veri-tamamlama (`DATA_COMPLETE`) kapısına ve canlı yakalama oturumuna BAĞLI DEĞİLDİR. Yakalanan veri ilgili işyerini sonlandırılmış gösteriyorsa bağ YOK sayılır; oturum bu işyerini içermiyorsa DB gerçeği korunur. Sihirbaz aktarımı sonrası paylaşılan `isg-katip-osgb-integration` SWR önbelleği tazelenir.
- **DATA_COMPLETE GATE:** Hizmet dataset DATA_COMPLETE değilse `ready=false`; hiçbir MATCH/NEW/CONFLICT kesinleştirilmez, tüm satırlar `INCOMPLETE` gösterilir. Personel sözleşmeleri HİÇ BAŞLAMAMIŞSA (yakalanan sayfa/satır yok) bu eksik veri sayılmaz; personel dataset tamamlandıysa kabul. Hizmet tamam + personel henüz başlamamış → ready olabilir; hizmet tamam + personel INCOMPLETE → ready olamaz.
- **Paylaşımlı hook (`src/hooks/useKatipOsgbIntegration.ts`, yeni):** SWR global anahtar (`isg-katip-osgb-integration`) → Personeller/Atamalar/Detay AYNI sonucu paylaşır (tek istek). Köprü (`requestKatipWorksites`, 8s timeout) + `fetchIsgDenetimDbSnapshot` (RLS kapsam) + saf builder. Hata olsa bile sayfa çökmez.
- **Paylaşımlı UI (`src/components/feature/isgKatip/KatipSyncStatusPanel.tsx`, yeni):** `KatipSyncStatusPanel` (Veri Tamamlandı/Toplanıyor/Bekleniyor/Bağlantı Yok + Personel ve Yasal Atama sayaçları; DATA_COMPLETE değilse RAKAM GÖSTERİLMEZ) + `KatipDurumBadge` + `KatipSahaUzmaniNot`.
- **Personeller ekranı:** KATİP Senkronizasyon Durumu paneli + **KATİP Durumu** kolonu (liste + mobil kart). Yalnızca `ready` iken kesin badge (KATİP Bağlı/Çakışma); aksi halde kaynak (`ISG_KATIP`/isg_katip_id) varsa "KATİP Kayıtlı", yoksa "—".
- **Atamalar ekranı:** KATİP Yasal Atama Senkronizasyonu paneli + Saha Uzmanı notu + firma satırında AKTİF KATİP hizmet sözleşmesi varsa "KATİP Bağlı" göstergesi (liste + mobil kart). Helper hiçbir koşulda KATİP bağlı gösterilmez.
- **Personel Detay:** Genel Bilgiler alanına "KATİP Entegrasyonu" kartı (Kaynak · KATİP Bağlantı Durumu · maskeli KATİP Kimlik · Sicil). 2 tab kuralı korundu; yeni sekme açılmadı. KATİP kaydı yoksa telefon/e-posta İSGDenetim'de manuel düzenlenebilir kalır.
- **Employee count:** `firmalar.calisan_sayisi` KATİP değeriyle YAZILMAZ (merkezi kaynak korunur).
- **Testler:** `chrome-extension/tests/isg-katip-osgb-integration.test.ts` → TEST A–O + firma düzeyi KATİP bağlantısı (DATA_INCOMPLETE/MATCH/CONFLICT/ACTIVE/TERMINATED/UNKNOWN/helper/CROSS_OSGB/employee count/fake kayıt yok).
- **KISITLAR KORUNDU:** DB WRITE=0, INSERT/UPDATE/DELETE=0, RPC apply OFF, import OFF, automatic sync OFF, yeni KATİP authenticated isteği=0, token/cookie/JWT taşınmadı. Vite **BUILD PASS**. Extension build (`node chrome-extension/build.mjs`) ve birim testleri bu ortamda koşturulmadı; gerçek Chrome E2E yapılmadı.

### BN28. FAZ 3/4 — KATİP TEK-FİRMA PİLOT WRITE → VERIFY → NOOP + LIFECYCLE HARDENING

- **AMAÇ:** FAZ 1/2 ile kurulan canonical KATİP READ altyapısını, kullanıcının AÇIKÇA seçtiği TEK firma için güvenli WRITE → taze RLS VERIFY → ikinci çalıştırmada NOOP/LINK zincirine bağlamak. Yeni paralel write/matching motoru OLUŞTURULMADI; mevcut `runIsgKatipPilotApply` → `pushIsgKatipImport` → atomik RPC `isg_katip_apply_pilot` yeniden kullanıldı. Global import / automatic sync / batch AÇILMADI.
- **Gerçekten mevcut olan core (doğrulandı):** RPC `isg_katip_apply_pilot(p_plan jsonb)` `SECURITY DEFINER` + tek transaction; firm LINK/CREATE/NOOP + personel LINK/CREATE + atama CREATE, hepsi `ON CONFLICT DO NOTHING`; relation çözülemezse `raise exception KATIP_APPLY_RELATION_UNRESOLVED` → ROLLBACK (kısmi state yok). Global unique index'ler: `firmalar_isg_katip_id_key`, `personeller_isg_katip_id_uniq (osgb_id,isg_katip_id)`, `atamalar_isg_katip_id_key`. Edge `isg-katip-sync`, pilot yazmadan önce `contractActivityStatus==='ACTIVE'` sunucu kapısı + conflict/unresolved/orphan bloklayıcı kapısı uygular. VERIFY, `verifyPilotApply` ile TAZE `fetchIsgDenetimDbSnapshot` okur (frontend eski snapshot kullanmaz).
- **Bu fazda kapatılan gerçek boşluklar:**
  1. **DATA_COMPLETE kapısı (client core):** `runIsgKatipPilotApply` artık `datasetComplete` alır; `false` ise `PILOT_DATA_INCOMPLETE` ile WRITE BLOKLAR (tek sayfa 100 kayıt COMPLETE sayılmaz). Side Panel `runPilotApply` de ayrıca DATA_COMPLETE değilse erken iptal eder.
  2. **Lifecycle termination:** Sonlandırılmış/iptal/süresi-dolmuş sözleşmelerin mevcut yasal ataması artık SİLİNMEDEN pasifleştirilir (`is_active=false`). `firmalar.is_active` otomatik DEĞİŞTİRİLMEZ. Aynı `sozlesmeId` AKTİF ise lifecycle üretilmez (çift yön yok); UNKNOWN/PENDING lifecycle ÜRETMEZ.
  3. **Apply/Verify sonrası SWR tazeleme:** `handlePilotApply` başarılı write sonrası `mutate('isg-katip-osgb-integration')` ile Personeller/Atamalar panelini tazeler (sürekli polling yok).
- **Yeni saf modül (`src/lib/isgKatip/pilotLifecycle.ts`):** `evaluatePilotApplyGate()` (ALLOW / PILOT_DATA_INCOMPLETE / SCOPE_NOT_ACTIVE / FIRM|PERSONNEL|ASSIGNMENT_BLOCKED / ORPHAN), `buildPilotLifecycleItems()` (yalnızca KESİN terminal durumlar, tek-firma kapsamı), `scopeLifecycleItems()`. SAF; supabase/chrome/DOM bağımlılığı yok.
- **Tipler (`types.ts`):** `KatipLifecycleItem { externalId, firmaExternalId, action:'DEACTIVATE' }` + `IsgKatipSyncPayload.lifecycle?` (opsiyonel → geriye uyumlu).
- **Edge (`isg-katip-sync`):** payload `lifecycle` doğrulaması (yapısal; yoksa hata YOK), pilot write planına `lifecycle` (`DEACTIVATE`) eklenir ve TEK firma kapsamına indirgenir.
- **RPC (CREATE OR REPLACE, additive):** `p_plan->'lifecycle'` döngüsü → `atamalar SET is_active=false` yalnızca `isg_katip_id = sozlesmeId AND osgb_id = kapsam AND is_active=true`. DELETE YOK; firma master'a dokunmaz. Mevcut tüm davranış korunur.
- **Bridge (`src/lib/isgKatip/bridge.ts` + `chrome-extension/shared/katipBridge.ts`):** Apply zarfına `datasetComplete` eklendi ve köprü zinciri boyunca taşınır.
- **Personeller/Atamalar entegrasyonu (FAZ 2):** Aynı canonical `useKatipOsgbIntegration` durumunu tüketmeye devam eder; Apply sonrası tazeleme ile DB durumuyla hizalanır. İkinci bir UI hesaplama motoru oluşturulmadı.
- **Testler (`chrome-extension/tests/isg-katip-pilot-write-lifecycle.test.ts`, yeni):** TEST A–W (DATA_INCOMPLETE blok, ACTIVE=0/TERMINATED/UNKNOWN blok, ALLOW, CONFLICT/UNRESOLVED/orphan blok, lifecycle DEACTIVATE + ACTIVE varsa üretilmez, CROSS_OSGB, tek-firma lifecycle kapsamı, employee count policy, inactive manuel bypass edilemez).
- **KISITLAR:** Bu oturumda gerçek KATİP oturumu olmadığından **DB WRITE = 0** (hiçbir apply çalıştırılmadı); gerçek doğrulanmış ACTIVE sözleşme yokken WRITE ZORLANMADI ve bu blocker olarak raporlandı. Token/cookie/JWT taşınmadı; yeni KATİP authenticated isteği=0. Vite **BUILD PASS**. Extension build + birim testleri bu ortamda KOŞULMADI; gerçek Chrome E2E yapılmadı.

### BN29. FAZ 4/4 — KATİP FINAL KAPANIŞ (E2E + WRITE/VERIFY + NOOP + LIFECYCLE FINAL QA)
- **AMAÇ:** FAZ 1–3 ile kurulan ve sertleştirilen KATİP zincirini (capture → pagination → DATA_COMPLETE → ACTIVE → eşleşme → preview → atomic WRITE → fresh VERIFY → second-run NOOP/LINK → lifecycle) GERÇEK RUNTIME KANITI ile kapatmak. Bu faz YENİ ÖZELLİK EKLEMEZ; yeni motor/endpoint/state/paralel akış OLUŞTURULMAZ. Bridge protokolü / MAIN hook akışı / service-worker mimarisi / RLS / write core / contractActivity iş mantığı DEĞİŞTİRİLMEDİ.
- **Denetim sonucu (kod tarafı hazır):** Zincirin TAMAMI kodda mevcut ve sağlam: `capture.ts` (state machine + pagination meta + overall discovery), `dataGate.ts`, MAIN hook capture session izolasyonu (`captureSessionId`), `apply.ts` (`datasetComplete` + `PILOT_DATA_INCOMPLETE`), `pilotLifecycle.ts` (gate + DEACTIVATE lifecycle), edge `isg-katip-sync` (ACTIVE + lifecycle), RPC `isg_katip_apply_pilot` (atomik + `ON CONFLICT DO NOTHING` + lifecycle pasifleştirme), `useKatipOsgbIntegration` (FAZ 2 Personeller/Atamalar, apply sonrası SWR `mutate`).
- **TEST X–AO (yeni dosya):** `chrome-extension/tests/isg-katip-final-qa.test.ts` → X (page0→INCOMPLETE), Y (terminal→COMPLETE), Z (ACTIVE=0→pilot yok), AA (ACTIVE>0→pilot READY), AB/AC/AD (WRITE rollback / fresh VERIFY / second-run NOOP — **yalnızca bunları YÖNETEN saf kapı doğrulanır; transaction tarafı runtime gerektirir**), AE (terminated→DEACTIVATE, delete yok), AF (başka ACTIVE→aktif kalır), AG (employee count değişmez), AH (cross-firm bloke), AI (cross-OSGB bloke), AJ (helper yasal atama değil), AK (DATA_INCOMPLETE→apply kapalı), AL (UNKNOWN→apply kapalı), AM (duplicate page yok), AN (duplicate contract yok), AO (session izolasyonu).
- **GERÇEK RUNTIME KANITI — BU ORTAMDA ÜRETİLEMEDİ (dürüst blocker raporu):** Gerçek Chrome E2E (KATİP login + tüm pagination capture + DATA_COMPLETE doğrulaması), gerçek atomik WRITE, fresh RLS VERIFY, second-run NOOP/LINK ve lifecycle runtime değişimi bu ortamda **KOŞULMADI** → **PASS YAZILMADI**. Ayrıca gerçek KATİP hesabında doğrulanmış ACTIVE hizmet sözleşmesi olmadan WRITE ZORLANMAZ; bu durumda ACTIVE=0/TRANSFERABLE=0 doğru kabul edilir ve blocker olarak raporlanır.
- **KRİTİK KURAL (korundu):** Gerçek ACTIVE yoksa kodu değiştirerek ACTIVE üretme yok; pagination runtime doğrulanamıyorsa PASS yok; test/WRITE/VERIFY/second-run koşulmadıysa PASS yok. Yeni KATİP authenticated isteği=0; token/cookie/JWT=0; DB cleanup yok; duplicate yok; partial write yok.
- **GLOBAL IMPORT = OFF, AUTOMATIC SYNC = OFF, CONTROLLED BATCH = HAZIRLIK (AÇILMADI).** Tek-firma E2E (WRITE PASS + VERIFY PASS + second-run NOOP/LINK PASS) gerçek kanıtı olmadan toplu import açılmaz.
- **BUILD:** Vite **BUILD PASS**. Extension build (`node chrome-extension/build.mjs`) + birim test koşumu bu ortamda yapılamadı.

### BN30. OSGB AYARLAR → İSG-KATİP ENTEGRASYONU (CHROME UZANTISI ONBOARDING + YÖNLENDİRME)
- **AMAÇ:** Kullanıcı, Chrome Uzantısı'nın teknik olarak var olduğunu bilmek zorunda kalmadan İSGDenetim içinden İSG-KATİP entegrasyonunu kurabilsin, uzantıya yönlendirilebilsin ve mevcut GERÇEK aktarım akışına geçebilsin. KATİP motoru (capture/pagination/matching/pilot/apply/RPC/RLS/employee-count + Personeller/Atamalar entegrasyonu) DEĞİŞTİRİLMEDİ; yalnızca OSGB panel Ayarlar ürünleştirme + yönlendirme UI'ı eklendi.
- **Yeni dosyalar:** `src/lib/isgKatip/extensionConfig.ts` (MERKEZİ `ISG_KATIP_EXTENSION_INSTALL_URL` + `ISG_KATIP_EXTENSION_ID` + Chrome masaüstü tespiti + kurulum adımları/rehberi; SAHTE URL/ID ÜRETİLMEZ → boşken "Uzantı yakında kullanıma sunulacak"), `src/components/feature/isgKatip/KatipEntegrasyonSection.tsx` (2 kolonlu premium: durum kartı + aksiyonlar + aktarım ayarları + bağlantı durumu + kurulum adımları + açılır kurulum rehberi + güvenlik).
- **Ayarlar entegrasyonu:** `src/pages/osgb/ayarlar/page.tsx` → yeni "İSG-KATİP Entegrasyonu" sekmesi (`ri-puzzle-2-line`) + `?katip=1` deep-link. SharedUICore korundu (Card/Button/Badge/Toggle/TabBar/PageHeader); yeni page-specific tasarım motoru YOK.
- **Gerçek bağlantı durumu (SAHTE YOK):** Kanonik `useKatipOsgbIntegration` (bridge + captured + dataState) tüketilir → 🟢 Bağlı / 🟠 Uzantı bekleniyor / 🟠 Veriler hazırlanıyor / 🔴 Bulunamadı / 🔴 Kontrol edilemedi. Teknik hata detayı (stack/RPC/kod) kullanıcıya GÖSTERİLMEZ; Chrome dışı tarayıcıda "Google Chrome üzerinde çalışır" bilgisi verilir.
- **Gerçek butonlar:** "İSG-KATİP'ten Firma Aktar" → `/osgb-panel/firmalar?katip=1` (mevcut Yeni Firma sihirbazı KATİP kaynağıyla açılır), "İSG-KATİP'i Aç" → gerçek KATİP adresi, "Bağlantıyı Kontrol Et" → kanonik refresh, "Chrome Uzantısını Kur"/"Uzantıyı Aç" → merkezi config, "İSGDenetim'i Aç" → panel içi navigasyon, "Kurulumu Nasıl Yapacağınızı Görün" → aynı sayfada açılan rehber. Placeholder buton YOK.
- **Firmalar sihirbazı:** `NewFirmaWizard` `initialKaynak` prop'u; `firmalar/page.tsx` `?katip=1` auto-open (parametre açılışta temizlenir) + mevcut "Yeni Firma" butonlarındaki pointer-event sızması düzeltildi (`onClick={() => handleOpenWizard()}`).
- **Kapsam dışı korundu:** yeni KATİP authenticated istek yok; token/cookie/JWT yok; capture/matching/pilot/WRITE/RPC/RLS/employee-count mimarisi değişmedi; yeni paralel iletişim/side panel/bridge mimarisi KURULMADI.
- **BUILD:** Vite **BUILD PASS**. Gerçek Chrome uzantı kurulumu runtime'da test edilemedi → "runtime pending" (sahte PASS yok).

### BN31. KATİP AKTARIM UX DÜZELTMELERİ + FİRMA ALAN OTOMASYONU (NACE/İL/SGK) + ATAMA EŞLEŞME GÖSTERGESİ
- **AMAÇ:** Gerçek kullanımda görülen 6 sorunu kökünden gidermek; KATİP motoru/matching/RPC/RLS/employee-count mimarisi KORUNUR.
- **1 · Atamalar "Eşleşmedi" (kök neden):** `FirmaAtamaMevcutTablo` içindeki İSG-KATİP Eşleşme kolonu SABİT `<Badge variant="danger">Eşleşmedi</Badge>` render ediyordu (hiçbir duruma bağlı değildi). Artık firma KATİP bağı (`isFirmaKatipLinked`) + atama KATİP durumu (`resolveAtamaKatipStatus`) + kaynak (`ISG_KATIP`) girdileriyle DİNAMİK: MATCH/KATİP kaynaklı → **Eşleşti**, CONFLICT → Çakışma, veri hazır değil/bağ bekliyor → Bağlantı Bekleniyor, helper → Operasyonel, aksi halde —. `FirmaDetailModal` durum haritasını besler.
- **2 · Firma il / NACE kodu / SGK/DETSİS No otomatik çekme:** `firmalar`'a `nace_kodu` (text) + `sgk_detsis_no` (text) sütunları eklendi. `buildFirmaSafePatch`/`buildFirmaInsert` (canonical) + edge `firmaPatch`/`firmaInsert` + pilot apply sonrası best-effort senkron bu alanları KATİP'ten yazar. NACE kodu `nace_kodlari.kod` ile eşleşirse `nace_id` de çözülür → mevcut `firma_nace_hazard_sync` tetikleyicisi `tehlike_sinifi`'nı senkronlar. İl yalnızca yerelde boşsa doldurulur.
- **3 · Arayüzde "pilot / verify / dev" jargonu kaldırıldı:** `IsgKatipFirmaSec` footer `PİLOT UYGULANIYOR…` → `Aktarım uygulanıyor…`; `KatipImportPanels` ApplyResult/FinalPlan panellerindeki `WRITE VERIFY PASS/FAILED`, `Aşama/Kod/DB WRITE/Verify ·` satırları sade Türkçeye çevrildi (`Kontrol ·`, `Veri Yazımı`).
- **4 · Çalışan sayısı alanı (manuel firma ekle hariç) kaldırıldı:** `EditFirmaModal`'dan Çalışan Sayısı inputu kaldırıldı (yerine "İSG-KATİP'ten otomatik güncellenir" notu); KATİP sihirbazındaki "Çalışan Sayısı / Kontrol" adımı ve "Çalışan Sayısı Politikası" kartı kaldırıldı. `NewFirmaWizard` MANUEL akışındaki alan KORUNDU.
- **5 · Zaten ekli firmalar aktarım listesinde gizlenir:** `IsgKatipFirmaSec.loadWorksites` RLS snapshot'ındaki `firmalar.isg_katip_id` kümesiyle KATİP işyeri adaylarını filtreler; gizlenen sayı kullanıcıya bilgi notu olarak gösterilir. Bağlı firmalar listede GÖRÜNMEZ.
- **6 · Çalışan sayısı KATİP'te değişince güncellenir:** Politika "dolduysa koru" yerine **KATİP geçerli değer verdiyse GÜNCELLE** olarak değiştirildi (canonical `buildFirmaSafePatch` + edge `firmaPatch` + pilot apply best-effort `calisan_sayisi` yazımı; `.or(calisan_sayisi.is.null,=0)` filtresi kaldırıldı).
- **7 · Personel ekle → KATİP aktar: zaten ekli personel gizlenir:** `NewPersonelModal.loadKatipPersonel` mevcut `personeller.isg_katip_id` + `tc_kimlik_no` kümesini çekip adayları filtreler.
- **8 · Atama sonlandırılırsa sistemde de sonlandırılır (firma/personel silinmez):** Mevcut lifecycle zinciri korunur — `pilotLifecycle.buildPilotLifecycleItems` (yalnızca KESİN TERMINATED/CANCELLED/EXPIRED) → payload `lifecycle` → edge tek-firma kapsamı → RPC `atamalar SET is_active=false` (DELETE YOK; `firmalar`/`personeller` master'a dokunulmaz).
- **DEĞİŞEN DOSYALAR:** `src/pages/osgb/atamalar/components/FirmaAtamaMevcutTablo.tsx`, `.../FirmaDetailModal.tsx`, `src/pages/osgb/firmalar/components/{KatipImportPanels,IsgKatipFirmaSec,NewFirmaWizard,EditFirmaModal}.tsx`, `src/pages/osgb/personeller/components/NewPersonelModal.tsx`, `src/lib/isgKatip/{matching,import}.ts`, `supabase/functions/isg-katip-sync/index.ts`; DB: `firmalar` + `nace_kodu`/`sgk_detsis_no`.
- **KORUNANLAR:** canonical matching, tek-transaction atomik RPC, fresh VERIFY, single-firm scope, DATA_COMPLETE/ACTIVE gate, helper yasal atama değil, `PILOT_ONLY` + global import OFF, token/cookie/JWT/TC loglanmaz.
- **BUILD:** Vite **BUILD PASS**; edge `isg-katip-sync` yeniden deploy edildi. Gerçek Chrome E2E bu ortamda doğrulanamadı.

### BN32. MEVCUT (ZATEN EKLİ) FİRMALARIN İSG-KATİP BİLGİLERİNİ BACKFILL
- **AMAÇ:** Daha önce aktarılmış (isg_katip_id bağlı) firmaların İL / NACE KODU / SGK-DETSİS NO / ÇALIŞAN SAYISI alanlarının boş kalması sorununu gidermek. Kök neden: KATİP aktarımı TEK-FİRMA pilot kapsamında ve zaten bağlı firmalar aktarım listesinden gizlendiği için (BN31 · madde 5) bu firmalar için server-side alan yazımı bir daha ÇALIŞMIYORDU.
- **ÇÖZÜM:** Yeni bağımsız yazma motoru KURULMADI. `apply.ts` → `runIsgKatipBackfillExistingFirms()` eklendi: yakalanan gerçek KATİP satırlarındaki her işyeri için, yerelde `isg_katip_id` ile BAĞLI bir firma VARSA ve işyeri kanonik AKTİFSE, mevcut tek-firma `runIsgKatipPilotApply()` o firma için yeniden çalıştırılır. Edge `firmaPatch`/pilot-apply sonrası best-effort senkron (BN31 · madde 2) aynen kullanılır. YENİ firma oluşturulmaz; DELETE YOK; firma/personel SİLİNMEZ.
- **UI:** `IsgKatipFirmaSec` adım 1'de "Mevcut firmaların bilgilerini güncelle" kartı — zaten ekli firma sayısını gösterir, tek tıkla backfill çalıştırır, sonuç mesajı gösterir ve SWR `isg-katip-osgb-integration` cache'ini tazeler. Aktarım onay metni "ÇALIŞAN SAYISI DEĞİŞTİRİLMEYECEK" → "İSG-KATİP bilgilerinin (çalışan sayısı, il, NACE kodu, SGK/DETSİS no) güncellenmesi" olarak düzeltildi.
- **İL KURALI GÜNCELLENDİ:** İl artık yalnızca boşsa değil, KATİP değeri mevcutsa yazılır (BN31 · madde 2 notu revize edildi). Çalışan sayısı/NACE/SGK davranışı korunur.
- **DEĞİŞEN DOSYALAR:** `src/lib/isgKatip/apply.ts`, `src/pages/osgb/firmalar/components/IsgKatipFirmaSec.tsx`, `.../KatipImportPanels.tsx`. Edge `isg-katip-sync` yeniden deploy edildi.
- **KORUNANLAR:** PILOT_ONLY, tek-firma atomik kapsam, ACTIVE gate, fresh VERIFY, helper yasal değil, token/cookie/JWT/TC loglanmaz.

### BN33. İSG-KATİP SÖZLEŞME/BELGE (PDF) KEŞİF + YAKALAMA — CHROME UZANTISI (READ-ONLY)
- **AMAÇ:** KATİP'ten sözleşme PDF'ini (veya belge yanıtını) yakalama yolunu KEŞFETMEK. Firma detay "Sözleşmeler" (`firma_sozlesmeleri`) ve personel detay "İSG Katip Sözleşmesi" (`atama_belgeleri` · `isg_katip_sozlesme`) alanlarına otomatik PDF düşürmenin ÖN KOŞULU: KATİP'in belgeyi HANGİ uçtan/nasıl döndürdüğünü TAHMİN etmeden görmek.
- **YAKLAŞIM (READ-ONLY · YENİ KATİP İSTEĞİ YOK):** İki JSON listesi dışındaki KATİP yanıtları MAIN-world hook'ta SALT GÖZLEMLE yakalanır: XHR (blob/arraybuffer) + fetch (clone) belge gövdeleri base64 olarak YALNIZCA pencere belleğinde (`window.__ISG_KATIP_DOC_CAPTURED__`) tutulur; `window.open` ve bağlantı tıklaması ile başlatılan indirme ADRESLERİ (metadata) kaydedilir. Query parametreleri rapora GİRMEZ (yalnızca query'siz yol saklanır).
- **UI:** Side Panel'e "Sözleşme / Belge Yakalama (KEŞİF)" paneli eklendi — yakalananlar listelenir; içeriği yakalananlar tek tıkla tarayıcı indirmesine (Blob) dönüştürülür. Sunucuya HİÇBİR veri gönderilmez.
- **KURAL:** KATİP'e YAZMA YOK; token/cookie/JWT OKUNMAZ/taşınmaz; ikinci authenticated istek ATILMAZ; 12 MB üzeri gövde saklanmaz (yalnızca adres/meta). Mevcut JSON capture/pilot/apply akışları BOZULMADI (additive).
- **DEĞİŞEN DOSYALAR:** `chrome-extension/content/katip-main-hook.ts`, `chrome-extension/shared/katipBridge.ts`, `chrome-extension/shared/katipDocs.ts` (yeni), `chrome-extension/popup/sidepanel.html`, `chrome-extension/popup/katip-ui.css`, `chrome-extension/popup/sidepanel.ts`.
- **SONRAKİ ADIM (HENÜZ UYGULANMADI):** Gerçek KATİP testinde yakalanan uç/adres görüldükten sonra, firma `firma_sozlesmeleri` veya atama `atama_belgeleri` kaydına OTOMATİK bağlama kararı verilecek.

---

## BO. EVRAKLAR EKRANI — SIFIRDAN YENİ TASARIM (UZMAN + FİRMA ORTAK) (2026-09-29)

> Uzman Paneli > Evraklar ve Firma Paneli > Evraklar ekranı TAMAMEN yeniden kuruldu. Eski kategori ağacı / klasör sistemi / Sık Kullanılanlar / Son Eklenenler SÖKÜLDÜ; yeni kategori+tablo mimarisi SIFIRDAN oluşturuldu. İki panel AYNI ortak bileşeni kullanır (ayrı ekran kodlanmadı).

### BO1. Yeni Modül Mimarisi (`src/components/feature/evrak/documents/`)
- `documentCategories.ts` — **TEK KAYNAK** kategori veri yapısı (8 ana kategori + alt kategoriler + Remix ikon + badge varyantı + `dbKategoriler`/`codes`/`keywords` eşlemesi) + eşleme yardımcıları (`categoryTurIds`, `fallbackTurIds`, `subMatchesTur`, `dbKategoriDisplayName`, `dbKategoriBadge`).
- `documentsTypes.ts` — ortak tipler (`DocumentSelection`, `DocumentSortKey`, `DocumentViewMode`, `DocumentColumnDef`).
- `DocumentCategoryTree.tsx` — chevron'lu katlanabilir kategori ağacı (ana + alt kategori).
- `DocumentsSidebar.tsx` — “Kategoriler” paneli (kategori ara + `Tüm Evraklar` sabit satırı + ağaç).
- `DocumentsToolbar.tsx` — ara / filtrele / sıralama / sütunlar / görünüm (liste-kart).
- `DocumentTable.tsx` + `DocumentActions.tsx` — yeni kolon seti + satır işlemleri (Görüntüle/İndir/Diğer).
- `DocumentsPage.tsx` — orkestratör (veri, seçim, breadcrumb, yükleme/önizleme/güncelleme modalları, sihirbaz).
- `EvrakYonetim.tsx` — ince sarmalayıcı (firmaId + role → `DocumentsPage`).

### BO2. Kategori Sistemi
- **8 ana kategori (Uzman Evrakları + Firma İSG Evrakları AYNI ağaç):** Risk Yönetimi · Acil Durum · Yıllık Planlar · Saha Denetimleri · Tutanaklar · Ölçüm & Teknik · İSG Kurulu & Organizasyon · Diğer İSG Dokümanları (+ `Tüm Evraklar` sabit satır).
- **Kapsam:** Yalnızca `owner_type='firma'` İSG iş dokümanları. Personel Dijital Dosyası ve uzmanın kendi mesleki belgeleri bu ekrana DAHİL EDİLMEZ. Yeni `owner_type`/tablo/kategori kaydı YOK — kategori ağacı saf SELECT/filtre.
- **Sık Kullanılanlar ve Son Eklenenler YOK.** Word/PDF/Excel için AYRI sekme YOK (dosya türü yalnızca satırda).
- **İlk açılışta TÜM kategoriler KAPALI**, yalnızca `Tüm Evraklar` seçili. Kategori tıklanınca seçilir + açılır (chevron ile aç/kapa); alt kategoriye tıklanınca yalnız o alt kategori filtrelenir. Sayfa yenilenince yine kapalı başlar.
- Breadcrumb: `Evraklar > Kategori > Alt Kategori`.

### BO3. Filtreleme / Eşleme (iş mantığı DEĞİŞMEDİ)
- Ana kategori → `dbKategoriler` (ör. `Risk Yönetimi`, `Acil Durum`, `Eğitim`, `İSG Kurulu`, `İSG Organizasyonu`, `Planlama`, `Faaliyet Koşulu`) + alt kategori kod/anahtar eşleşmesi. `Diğer` = hiçbir kategoriye eşleşmeyen belgeler (fallback).
- Kapsam **firma evrakı** (`owner_type='firma'`, tutanak-dışı) olarak KORUNDU. Kategori/adetler mevcut `firma_evrak_sayilari` RPC'sinden gelir (gerçek veri; kişi sayısı hardcode değil).

### BO4. Tablo & Araç Alanı
- Kolonlar: `□ · EVRAK ADI · KATEGORİ · DOSYA TÜRÜ · EKLENME TARİHİ · GEÇERLİLİK TARİHİ · KALAN SÜRE · DURUM · YÜKLEYEN · İŞLEMLER`.
- Üst araç alanı: `Evrak ara...` · `Filtrele` (Tür + Durum) · `Tarih / Sıralama` · `Sütunlar` (görünür kolon) · `Görünüm` (liste/kart). Sağ üst: `+ Evrak Yükle` (+ Uzman'da `Sihirbaz` KORUNDU).
- Durum rozetleri (`Geçerli/Bekliyor/Taslak/Süresi Doldu` vb.) mevcut İSGDenetim renk sistemiyle korunur.

### BO5. Korunanlar / Değişmeyenler
- **YÜKLEME/GÜNCELLEME/ÖNİZLEME İŞLEVLERİ KORUNDU:** mevcut `EvrakEkleModal`, `EvrakBelgeModal`, `evrakService` (yükleme/indirme/imzalı URL/revizyon/silme/arşiv/supersede) AYNEN kullanılır. DB/Edge/RLS/RPC/route/auth/storage/business logic DOKUNULMADI. Sihirbaz (belge üretme) korundu.
- **Noter Defteri ve İSG Organizasyonu, Evraklar > kategori akışından AÇILIR (geri getirildi).** `Noter Defteri` ayrı bir kategori olarak tanımlandı (`action: 'noter'`); seçilince üstte "Noter Defteri Kayıtları" butonu çıkar ve mevcut `NoterDefteriPanel` (onaylı defter + tespit/öneri kayıtları + Asıl/Uzman/Hekim fiziksel nüsha takibi) modalda açılır. `İSG Kurulu & Organizasyon` kategorisinde kategori düzeyinde `kurul` aksiyonu, `İSG Organizasyonu` alt kategorisinde `organizasyon` aksiyonu (`IsgOrganizasyonuModal`) tanımlıdır. Aksiyon meta tablosu tek kaynak: `DOCUMENT_ACTION_META`.

### BO6. Silinen / Değişen Dosyalar
- **SİLİNDİ:** `EvrakDosyaListesi.tsx`, `EvrakKlasorPaneli.tsx` (eski liste + eski kategori ağacı paneli).
- **GÜNCELLENDİ:** `EvrakYonetim.tsx` (yeni `DocumentsPage` render eder).
- **OLUŞTURULDU:** yukarıdaki `documents/` modülü (8 dosya).

### BO7. Doğrulama
- **BUILD:** Vite **BUILD PASS**. Light + Dark tema korunur; sidebar/navbar/layout/renk paleti/buton yapısı DEĞİŞMEDİ.

---

## BP. YENİ PERSONEL MODALI — TEK EKRAN PREMIUM YENİDEN TASARIM (FİRMA + UZMAN ORTAK) (2026-09-29)

> Firma Paneli > Personeller ve Uzman Paneli > Personeller "Yeni Personel" modalındaki **3 adımlı sihirbaz (Genel Bilgiler → Eğitim & Sağlık → Evraklar) TAMAMEN KALDIRILDI**. İleri/Geri, stepper, adım göstergesi YOK. Tek ekranlı, scrollsuz hedefli, iki kolonlu premium modal sıfırdan kuruldu. İki panel AYNI ortak `PersonelEkleModal` motorunu kullanır.

### BP1. Modal Yerleşimi (tek ekran / scrollsuz hedef)
- Sol (ana form): Kimlik ve İletişim · İş Bilgileri · Sağlık Uygunluğu · İSG ve İşe Başlama Eğitimi.
- Sağ: Gerekli Belgeler (dinamik) · Uygunluk Özeti.
- Modal `bodyLayout:'fill'` + geniş (1180) + viewport yüksekliği; footer (İptal / Personeli Oluştur) SABİT. Modal başlığı: "Yeni Personel" + küçült / genişlet / kapat.

### BP2. Dinamik Meslek & Belge Motoru (`src/lib/meslekService.ts`)
- **Görev/Meslek klasik dropdown DEĞİLDİR.** 8.000+ meslek düz liste olarak yüklenmez; `arabMeslekler()` yazdıkça (300ms debounce) SUNUCU tarafında `occupations` tablosunda `ilike` arar (limit 20). Sonuç: meslek adı + meslek kodu + seviye + MYK kapsam rozeti.
- Seçilen mesleğin MYK yeterliliği `myk_qualifications` (occupation_code ↔ aktif) üzerinden çözülür. **"MYK kapsamında" ile "MYK belgesi zorunlu" AYRI kavramlardır.**
- `belgeGereksinimleri()`: mesleğin MYK yeterliliği varsa `myk` belgesi **ZORUNLU**; İşe Özgü Talimat (`ISE_OZU_TALIMAT`) **ZORUNLU**; Diğer Mesleki Belge / Ehliyet / Operatörlük **OPSİYONEL**. Tüm kurallar merkezi veriye (meslek + MYK) dayanır; frontend'e sabit meslek listesi/kural gömülmez.

### BP3. Veritabanı Ekleri (mevcut mimari KORUNDU, yalnızca ekleme)
- `personeller` += `departman, vardiya, lokasyon, personel_grubu, ehliyet_sinifi, occupation_code` (text, nullable).
- `personel_egitimleri` += `egitim_durumu, egitim_suresi_saat, egitimi_veren`.
- `personel_saglik_muayeneleri` += `saglik_durumu`.
- `evrak_turleri` (owner_type='personel') += `EHLIYET`, `OPERATORLUK_BELGESI`, `ISE_OZU_TALIMAT`, `USTALIK_BELGESI`, `MESLEKI_EGITIM_BELGESI` (merkezi katalogtan, kod gömülmeden).

### BP4. Belgeler ve Dijital Personel Dosyası
- Sağ paneldeki her belge alanı ÇOKLU dosya kabul eder (Shared UI `FileUpload`). Eğitim bölümünde ayrıca çoklu "Eğitim ve Sertifika Belgeleri" alanı vardır.
- Kayıt sırasında her dosya `uploadEvrak` ile **AYRI belge kaydı** olarak dijital dosyaya yazılır (tek `documents` kolonuna sıkıştırılmaz). Belge türü mesleğe göre `evrak_turleri.code` ile eşlenir.
- **Sağlık raporu dosyası YÜKLENMEZ** (KVKK): yalnızca `Sağlık Raporu Tarihi` + `Sağlık Durumu` (Uygun/Uygun değil/Belirtilmemiş) tutulur. Kan grubu / medeni durum YOK.

### BP5. Eğitim & Sağlık
- İSG eğitimi durumu (Planlandı/Tamamlandı/Eksik). "Tamamlandı" seçilirse Eğitim Tarihi + Eğitim Süresi (Saat) + Eğitimi Veren + en az bir eğitim belgesi ZORUNLU olur; yalnızca bu durumda `personel_egitimleri` kaydı açılır.
- **Yenileme/sonraki eğitim tarihi frontend'de HESAPLANMAZ** — merkezi geçerlilik motoru (DB trigger) doldurur.

### BP6. Ortak Bileşenler (`src/components/feature/personel/`)
- `MeslekSecici.tsx` — search-as-you-type meslek seçici (MYK kapsam rozeti + meslek bilgi kartı).
- `BelgeSlotu.tsx` — zorunlu/opsiyonel etiketli kompakt çoklu dosya yükleme alanı.
- `UygunlukOzeti.tsx` — kayıt öncesi kontrol listesi (zorunlu eksikler kırmızı; opsiyonel eksikler kaydı engellemez).

### BP7. Değişen Dosyalar
- **YENİDEN YAZILDI:** `src/pages/firma/personeller/components/PersonelEkleModal.tsx` (tek ekran/sihirbazsız).
- **OLUŞTURULDU:** `src/lib/meslekService.ts`, `src/components/feature/personel/{MeslekSecici,BelgeSlotu,UygunlukOzeti}.tsx`.
- **GÜNCELLENDİ:** `src/lib/personelService.ts` (payload tipleri), `src/pages/firma/personeller/page.tsx` ve `src/pages/uzman/personeller/page.tsx` (modal genişlik/yükseklik/bodyLayout).
- **BUILD:** Vite **BUILD PASS**.

---

## BQ. YENİ PERSONEL MODALI — BİREBİR + SCROLLSUZ + MERKEZİ TARİH MOTORU (2026-09-30)

> Firma (ve ortak motoru kullanan Uzman) Personel Ekle modalı, tasarım referansına birebir + scrollsuz hale getirildi. Wizard/hesap/davet YOK. Mevcut SharedUICore ve dijital dosya mimarisi KORUNDU.

### BQ1. Zorunlu Alanlar (belgeler ENGELLEMEZ)
- Yalnızca **Ad, Soyad, İşe Giriş Tarihi, Meslek/Görev** zorunludur. Sağlık ve eğitim bilgisi opsiyoneldir; hiçbir belge yüklemeden personel kaydedilebilir.
- Sağlık raporu dosyası KVKK gereği yüklenmez (yalnızca tarih + durum); sağlık belgesi satırı hekim dışı roller için yüklemeye kapalıdır.

### BQ2. MYK Gösterim Mantığı (hukuki zorunluluk DEĞİL)
- `belgeGereksinimleri()` artık zorunluluk üretmez; nötr bilgi gösterir: "Bu görev MYK kapsamında değerlendirilmektedir. İlgili MYK yeterliliği: {kod} (Seviye N)" / "Bu görev için sistemde MYK kapsam eşleşmesi bulunmuyor."
- Meslek seçimi yazdıkça-arama (search-as-you-type) olarak korunur; seçilen mesleğe göre önerilen belge satırları (MYK, İşe Özgü Talimat, Eğitim/Sertifika/Sınav, Sağlık Raporu, Operatörlük, Diğer Mesleki) listelenir.

### BQ3. Merkezi Tarih Motoru (hard-code YOK)
- **YENİ:** `src/lib/personelValidity.ts` — DB trigger'ının (`personel_validity_resolve` + `isg_kurallari.calculation_definition.validity_by_hazard`) istemci aynası. Firma tehlike sınıfı + merkezi kuraldan süre okur.
- Eğitim "Tamamlandı" → Eğitim Tamamlanma Tarihi açılır; "Sonraki Eğitim Tarihi" `TEMEL_ISG_EGITIMI` kuralından hesaplanır. Sağlık Raporu Tarihi girilince "Sonraki Sağlık Muayenesi" `SAGLIK_GOZETIMI` kuralından hesaplanır. Süreler bileşen içine hard-code EDİLMEZ.

### BQ4. UI
- İki kolonlu, scrollsuz, tek ekran; sağ kolon "Meslek ve Belge Bilgisi" (bilgi bandı + kompakt belge satırları). `BelgeSlotu` kompakt satır-içi yükleyiciye dönüştürüldü (paylaşılan `@/lib/fileUpload` çekirdeği kullanılır).
- Kaydet butonu: **"Personeli Kaydet"** — yalnızca temel validasyon.

### BQ5. Değişen Dosyalar
- **YENİ:** `src/lib/personelValidity.ts`
- **YENİDEN YAZILDI:** `src/pages/firma/personeller/components/PersonelEkleModal.tsx`, `src/components/feature/personel/BelgeSlotu.tsx`
- **GÜNCELLENDİ:** `src/lib/meslekService.ts` (`belgeGereksinimleri` nötr/engelleyici-olmayan)
- **BUILD:** Vite **BUILD PASS**. DB/migration DEĞİŞMEDİ.