# İSGDenetim (OSGB SaaS) — BİRLEŞİK GÜVENLİK DENETİMİ KAPANIŞ RAPORU

> **Tarih:** 2026-10-12 · **Rol:** Tek konsolide referans (GUV-01 → GUV-24 + runtime iyileştirme)
> **Kaynaklar:** `PENTEST_READINESS_DOSSIER.md` (kanonik), `SECURITY_FINAL_CLOSURE_PENTEST_READY_PHASE8_2026-10-11.md`,
> `SECURITY_STORAGE_HARDENING_2026-10-12.md`, `SECURITY_STORAGE_BUCKET_LIMITS_2026-10-12.md`.
>
> **Üretim sınırı:** Bu rapor bir **özet/kapanış** dokümanıdır. İçinde listelenen tüm migration'lar
> daha önce uygulanmış ve canlı salt-okuma sorgularla doğrulanmıştır. Raporda gizli anahtar /
> token / connection string / gerçek kullanıcı verisi **YOKTUR**.
>
> ⚠️ **Bu rapor, gerçek bir sızma testinden geçildiği anlamına GELMEZ.**

---

## 0) TEK CÜMLEDE DURUM

> Veri katmanı ve uygulama savunması **canlıda uygulanmış ve kanıtlı**; panel işleri
> (Auth Dashboard + hosting başlıkları) kullanıcı tarafından tamamlandı. Kalan tek madde
> **izole ortamda runtime pgTAP kanıtı** ve **`npm audit`** olup bunlar **kritik açık değildir.**

---

## 1) KAPANAN TÜM BULGULAR (konsolide)

| ID | Önem | Konu | Durum | Kanıt |
|---|---|---|---|---|
| **GUV-01** | Yüksek | Storage tenant izolasyonu | ✅ DOĞRULANDI | Canlı: `storage_tenant_ok()` VAR (definer + `search_path=public`); 4 hassas bucket private |
| **GUV-02** | Yüksek | `handle_new_user` metadata rol yükseltme | ✅ DOĞRULANDI | Canlı gövde: `role='pending'` sabit, metadata'dan rol okunmuyor |
| **GUV-06** | Yüksek | `teklifler`/`teklif_hizmetleri` tenant kapsamı | ✅ DOĞRULANDI | Canlı: RESTRICTIVE tenant policy'ler mevcut |
| **GUV-07** | Yüksek | `osgb_access_ok()` NULL dalı | ✅ DOĞRULANDI | Canlı gövde: NULL guard + erişim penceresi |
| **GUV-11/13/13b** | Yüksek | anon-çağrılabilir definer RPC'ler | ✅ DOĞRULANDI | Canlı: anon definer EXECUTE **159 → 77**; 2 yazma fonksiyonu yalnız `service_role` |
| **GUV-14/15** | Orta | definer `search_path` NULL/boş hijacking | ✅ DOĞRULANDI | Canlı: `search_path IS NULL` = **0** |
| **GUV-16** | Orta | Sabit bootstrap admin e-postası | ✅ DOĞRULANDI | Canlı: bootstrap yok |
| **GUV-17** | Orta | Tablo-düzeyi `TRUNCATE`/`REFERENCES`/`TRIGGER` (en-az-ayrıcalık) | ✅ KAPATILDI (2026-10-12) | Canlı: anon/auth `TRUNCATE` kalan tablo = **0**; regresyon geçti |
| **GUV-18** | Orta | Auth abuse/rate-limit tablosu yok | ✅ DOĞRULANDI | Canlı: `auth_abuse_limits` VAR, RLS açık + default-deny |
| **GUV-23** | Düşük-Orta | Storage policy'lerinde en-dar-rol ihlali (6 policy `{public}`) | ✅ KAPATILDI (2026-10-12) | Canlı: 6 policy → `{authenticated}`; `public` rolü kalan = **0** |
| **GUV-24** | Orta | Bucket boyut limiti yok (14/16 sınırsız) + MIME yok | ✅ KAPATILDI (2026-10-12) | Canlı: `file_size_limit IS NULL` = **0**; görsel bucket'lara MIME; `support` 10→30 MB |
| **SSRF (mail)** | Yüksek | smtpHost/Port ile SSRF | ✅ KISMEN | Kod + enjekte-resolver birim testi; gerçek HTTP runtime yok |
| **P5 dosya/dep** | Orta | CSV injection / xlsx DoS / magic-byte | ✅ KISMEN | `csvSafe`, `readWorkbookSafe`, `fileSignature`; `npm audit` BLOCKED |
| **P6 CORS/CSP** | Orta | `ACAO:*` + `unsafe-eval` | ✅ KISMEN | Origin allowlist + CSP; preflight runtime testi BLOCKED |
| **HTTP başlıkları** | Orta | HSTS / nosniff / frame-ancestors / Referrer-Policy / Permissions-Policy | ✅ DOĞRULANDI (2026-10-12) | securityheaders.com **A+** + canlı `curl -I` çıktısı (Cloudflare Response Header Transform Rule) |
| **P7 self-escalation** | Yüksek | `profiles.role` kullanıcı kendi rolünü değiştirebiliyordu | ✅ DOĞRULANDI | Canlı: `profile_lock_role` RAISE 23514 |

**Bonus bug (GUV-24 turunda açığa çıkan ve düzelen):** `support` bucket **10 MB**'da kilitliydi
ama uygulama kullanıcıya **25 MB**'a izin veriyordu → 10–25 MB arası destek ekleri **sessizce
reddediliyordu.** 30 MB'a çekilince gerçek kullanıcı hatası da kapandı.

---

## 2) RUNTIME / DAYANIKLILIK İYİLEŞTİRMESİ (bu tur)

- **"Bağlantı kuruluyor" ekranı hızlandırması:** OSGB erişim / bakım modu / personel durumu
  kontrolleri geçici hata (cold-start / kısa ağ kesintisi / token yarışı) yaşadığında artık
  **60 sn beklemiyor**; ~1.5sn → 3sn → 6sn → 12sn geri çekilmeli hızlı deneme yapıyor.
- **Güvenlik mantığı korundu:** Hızlanma **yalnızca "durum okunamadı" (geçici)** hâlinde çalışır.
  Erişim gerçekten reddedilmişse (pasif OSGB, süre dolmuş, işten çıkarma) geçici sayılmaz.
- **Dosyalar:** `src/lib/autoRetry.ts` (yeni) + `src/components/feature/ProtectedLayout.tsx`
  (3 kontrole bağlandı). Build **PASS**.

---

## 3) SİZİN TARAFINIZDAN TAMAMLANAN PANEL İŞLERİ

| # | Bileşen | İşlem | Durum |
|---|---|---|---|
| 1 | Supabase Dashboard → Auth | Self-signup KAPALI, redirect/recovery URL allowlist, Site URL | ✅ Yapıldı (kullanıcı beyanı) |
| 2 | Cloudflare Response Header Transform Rule | `Strict-Transport-Security`, `X-Content-Type-Options`, `Content-Security-Policy (frame-ancestors 'self')`, `Referrer-Policy`, `Permissions-Policy` | ✅ DOĞRULANDI (securityheaders.com **A+**, 2026-10-12) |

> **HTTP başlıkları kanıtı (2026-10-12):** `app.isgdenetim.com.tr` CNAME → `publish.readdy.site`
> kaydı Cloudflare'de **Proxied (turuncu bulut)** durumuna alındı; ardından
> **Rules → Overview → Create rule → Response Header Transform Rule** ile 5 başlık eklendi.
> Doğrulama: **securityheaders.com = A+** (Strict-Transport-Security, X-Content-Type-Options,
> Content-Security-Policy, Referrer-Policy, Permissions-Policy + bonus X-Frame-Options tümü ✅).
> Kanıt: securityheaders.com ekran görüntüsü + `curl -I https://app.isgdenetim.com.tr` çıktısı.
> Not: Bu madde önceki turlarda "kullanıcı beyanı" olarak işaretliydi; artık **canlı doğrulanmıştır.**

---

## 4) KALAN MADDELER (kritik açık DEĞİL — kalibrasyon)

| # | Madde | Durum | Kapanış koşulu |
|---|---|---|---|
| R1 | İzole test ortamı + `guv*.test.sql` runtime pgTAP | ⛔ BLOCKED (ayrı DB / şema-only dump yok) | İzole DB'de testler PASS → sonuç raporlanır |
| R2 | `npm audit` / bağımlılık CVE taraması | ⛔ BLOCKED (yürütücü yok) | Yerel `npm ci && npm audit --audit-level=high` çıktısı saklanır |
| R3 | `sourcemap: false` | ⛔ Platform kilitli (`vite.config.ts` yazılamıyor) | Hosting adımı / platform desteği |
| R4 | Ortak CORS modülü (`_shared/*`) | ⛔ Platform kilitli + runtime testi gerekli | Edge dosyalarına erişim + tek tek test |
| R5 | Runtime RLS / cross-tenant manuel doğrulama | 🟡 Kısmen (statik kanıtlı) | İzole ortamda manuel senaryo |

> Bu maddelerin tümü **kapsam-içi kalibrasyon / ortam eksikliği** engelidir; doğrulanmış
> kritik/yüksek açık **YOKTUR.**

---

## 5) CANLI DURUM TABLOSU (canlı salt-okuma, güncel)

| Kontrol | Değer | Yorum |
|---|---|---|
| RLS açık tablo | **177 / 177** (kapalı = 0) | ✅ |
| `anon` definer EXECUTE | **77** (159'dan) | ✅ |
| `search_path IS NULL` definer | **0** | ✅ |
| `storage_tenant_ok` | **VAR** | ✅ |
| `storage.buckets.file_size_limit IS NULL` | **0** | ✅ (GUV-24) |
| `storage.objects` `public` rolündeki policy | **0** | ✅ (GUV-23) |
| anon/auth TRUNCATE kalıntısı | **0** | ✅ (GUV-17) |
| `profile_lock_role` self-escalation | **RAISE 23514** | ✅ |
| `auth_abuse_limits` | **VAR**, RLS + default-deny | ✅ (GUV-18) |

---

## 6) NİHAİ KARAR

> ### KOŞULLU HAZIR
>
> Tanımlı kapsamda **kritik ve yüksek riskli açık doğrulanmadı.** Çekirdek veri katmanı
> savunması (RLS 177/177, RESTRICTIVE tenant policy'ler, negatif-guard'lı erişim fonksiyonları,
> self-escalation kilidi, minimum-yetkili definer fonksiyonlar, private bucket'lar, boyut+MIME
> sertleştirmesi, SMTP default-deny) **canlı kanıtla** doğrulandı; panel işleri tamamlandı ve
> **HTTP güvenlik başlıkları artık canlı doğrulanmıştır (securityheaders.com A+).**
>
> **"PENTESTE HAZIR" denmez** çünkü: **DB runtime pgTAP testleri BLOCKED** ve **`npm audit`
> çalıştırılamadı.** Bu engeller izole ortam/yürütücü eksikliğindendir, açık değildir.
>
> ⚠️ Bu ifade gerçek bir sızma testinden geçildiği anlamına **GELMEZ.** Bağımsız uzman pentest +
> yeniden testler tamamlanmadan "sızma testini geçti" iddia edilemez.