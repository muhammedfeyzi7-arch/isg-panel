# Güvenlik Denetimi · RLS Politikaları + Tenant İzolasyonu + Rol-Yetki Matrisi

- **Tarih:** 2026-10-11
- **Kapsam:** Supabase PostgreSQL (SaaS Supabase), RLS politikaları, tenant izolasyonu, rol yetkileri, RPC ve Edge Functions
- **Yöntem:** Salt-okuma. Kod incelemesi + canlı katalog sorguları (`pg_policies`, `pg_class`, `pg_proc`, `pg_trigger`, `storage.objects`, `information_schema.*`). **Hiçbir kod, politika, RPC veya veri değiştirilmedi.** Başka müşterilerin gerçek kayıtları okunmadı; yalnızca sayım/şema/politika metadatası çekildi.
- **Dürüstlük notu:** Bu ortamda `execute_sql` yükseltilmiş yetkiyle çalışır; bu yüzden **anon/authenticated rolünü çalıştırarak** RLS davranış testi yapılamadı. Politika davranışı **katalog + statik muhakeme** ile değerlendirildi. İzole iki-OSGB test ortamı olmadığı için **canlı çapraz-tenant erişim testi yapılmadı.**

---

## BÖLÜM A — RLS Etkinliği ve Politika Envanteri

### A.1 Kanıt: RLS etkinliği
| Ölçüm | Sonuç |
|---|---|
| public şemasında tablo (relkind='r') | 176 |
| RLS **açık** tablo | **176 (tamamı)** |
| RLS **kapalı** tablo | 0 |

- Kanıt sorgusu: `pg_class.relrowsecurity` gruplaması → `{rls_enabled:true, tablo_sayisi:176}`.
- **Değerlendirme:** Fail-safe (kapalı-yönlü) temel sağlam. Hiçbir public tablo korumasız değil.

### A.2 Kanıt: politika komut/permissive dağılımı
| cmd | PERMISSIVE | RESTRICTIVE |
|---|---|---|
| SELECT | 244 | 0 |
| INSERT | 116 | 1 |
| UPDATE | 105 | 1 |
| DELETE | 72 | 1 |
| ALL | 17 | 6 |
| **Toplam** | **554** | **9** |

- Rol kapsamı: `{public}` **456**, `{authenticated}` **106**, `{postgres}` **1**.

### A.3 Kanıt: RESTRICTIVE (AND ile birleşen) guard'lar — 9 adet
Bunlar tenant izolasyonunun ikinci savunma hattı:

| Tablo | Politika | cmd | Koşul |
|---|---|---|---|
| atamalar | atamalar_osgb_access_guard | ALL | `osgb_access_ok()` |
| evraklar | evraklar_osgb_access_guard | ALL | `osgb_access_ok()` |
| evraklar | evraklar_client_write_deny_insert/update/delete | INSERT/UPDATE/DELETE | `false` (istemci yazımı kapalı) |
| firmalar | firmalar_osgb_access_guard | ALL | `osgb_access_ok()` |
| personeller | personeller_osgb_access_guard | ALL | `osgb_access_ok()` |
| teklifler | teklifler_tenant_restrictive | ALL | `admin OR osgb_id=auth_osgb_id()` |
| teklif_hizmetleri | teklif_hizmetleri_tenant_restrictive | ALL | `admin OR osgb_id=auth_osgb_id()` |

- `osgb_access_ok()` **sertleştirilmiş** sürüm (canlı gövde doğrulandı): `auth_role()='admin' OR (auth_osgb_id() IS NOT NULL AND EXISTS(aktif/silinnmemiş/kapsam penceresi içindeki OSGB))`. **`osgb_id IS NULL → koşulsuz TRUE` dalı YOK.** (Bu düzeltmenin tasarım kanıtı: `supabase/migrations/20260101000400_guv07_osgb_access_ok.sql`.)

### A.4 Bulgu: `qual = true` veya `with_check = true` olan 15 politika
| Rol | Tablolar | Değerlendirme |
|---|---|---|
| public (SELECT) | diploma_equivalences, mastership_equivalences, myk_document_requirements, myk_qualifications, occupation_nace_map, occupations, requirement_document_equivalents, requirement_rules | Referans/lookup tabloları — **muhtemelen kasıtlı** halka açık okuma |
| authenticated (SELECT) | activity_attributes, custom_icons, evrak_onerileri, iskur_myk_eslesmeleri, myk_ums, nace_activity_attributes, nace_activity_families | Referans tabloları — yalnızca oturumlu okuma |

- **Risk: DÜŞÜK.** Hepsi referans veri. **Doğrulanması gereken:** bu setin tamamının gerçekten halka açık/salt-okunur referans verisi olduğu (içinde müşteri verisi bulunmadığı) teyit edilmeli. Aktif sızma bulgusu yok.

### A.5 Bulgu: RLS açık ama HİÇ politikası olmayan 16 tablo (deny-all)
`acil_durum_ai_kullanim`, `acil_durum_atamalari`, `acil_durum_ekipleri`, `acil_durum_koordinatoru`, `ekipman_sayaclari`, `isg_kurul_ai_kullanim`, `mail_credentials`, `mail_oauth_states`, `ocr_document_groups`, `risk_degerlendirme_ai_kullanim`, `saha_tutanak_sayaclari`, `tutanak_no_reservations`, `uygunsuzluk_sayaclari`, `uygunsuzluk_talepleri`, `yillik_calisma_plan_ai_kullanim`, `yillik_egitim_plan_ai_kullanim`

- **Risk: DÜŞÜK (fail-closed).** Politikası olmayan tabloya istemci erişemez; bu tablolara yalnızca Edge Function / service_role erişir.
- **Doğrulama önerisi:** her birinin gerçekten yalnızca servis tarafından kullanıldığı teyit edilsin (`mail_credentials`, `mail_oauth_states` özellikle hassas).

### A.6 Özel durum: `evraklar.evraklar_select_legacy`
- `roles = {postgres}` → yalnızca `postgres` (yüksek yetkili) rolüne uygulanır. **İstemci rolleri (anon/authenticated) etkilenmez.**
- **Risk: BİLGİ.** Şaşırtıcı bir tanım; kaldırılması/kapsamının netleştirilmesi önerilir ama aktif açık değil.

### A.7 Kısmi açık / savunma derinliği zayıflığı (KRİTİK DEĞİL)
- **F-A1 (Orta · Savunma derinliği):** `anon` VE `authenticated` rolleri, **176 public tablonun tamamında geniş TABLO seviyesi yetkilere** sahip (SELECT/INSERT/UPDATE/DELETE/**TRUNCATE**/**TRIGGER**/REFERENCES). Güvenlik **tek kapıya (RLS)** bağlı. (Kanıt: `information_schema.table_privileges` → profiles için bile DELETE/TRUNCATE/UPDATE.) RLS tuttuğu sürece sızma yok; ancak RLS'te tek bir hata tüm veriyi açar. **Öneri:** gereksiz tablo-seviyesi grant'ler daraltılsın; TRUNCATE/REFERENCES kaldırılsın.
- **F-A2 (Düşük-Orta):** Politikaların **456/562'si `TO public`** (>%81). `public` rolü `anon`'u da kapsar. Şu an qual'lar `auth_*()` üzerinden koruyor (anon'da `auth.uid()` NULL → koşul false), bu yüzden **aktif sızma doğrulanmadı**; ama geniş rol kapsamı gelecekteki hata riskini büyütür. **Öneri:** mümkün olan yerde `TO authenticated` kullanılsın.

---

## BÖLÜM B — Tenant İzolasyonu (OSGB ↔ OSGB, Firma ↔ Firma)

### B.1 Kimlik kaynağı — istemciye güven YOK
Yardımcı fonksiyonlar tenant kimliğini **profiles tablosundan `auth.uid()` üzerinden** türetir; istemciden gelen `osgb_id`/`firma_id` parametresine güvenilmez:

- `auth_role()` → `SELECT role FROM profiles WHERE id = auth.uid()` (SECURITY DEFINER, `search_path=public`)
- `auth_osgb_id()` → `osgb_id FROM profiles WHERE id = auth.uid()`
- `auth_firma_id()` → `firma_id FROM profiles WHERE id = auth.uid()`

### B.2 İzolasyon kapsama ölçümleri (kanıt)
| Ölçüm | Sonuç |
|---|---|
| `auth_osgb_id()` kullanan politikalı tablo | **98** |
| `auth_firma_id()` kullanan politikalı tablo | **64** |
| `osgb_id`/`firma_id` kolonu olup tenant-predicate'i **doğrudan** görünmeyen tablo | 22 (aşağıda tek tek açıklandı — hepsi başka mekanizmayla kapsanmış) |

### B.3 "Tenant predicate'i doğrudan görünmeyen" 22 tablonun gerçek durumu
| Tablo | Durum |
|---|---|
| acil_durum_ai_kullanim, acil_durum_atamalari, acil_durum_ekipleri, acil_durum_koordinatoru, ekipman_sayaclari, isg_kurul_ai_kullanim, ocr_document_groups, risk_degerlendirme_ai_kullanim, saha_tutanak_sayaclari, tutanak_no_reservations, uygunsuzluk_sayaclari, yillik_calisma_plan_ai_kullanim, yillik_egitim_plan_ai_kullanim | **Politikasız (deny-all)** → yalnızca Edge/service_role. Fail-closed. |
| announcement_targets | `can_access_announcement(announcement_id)` / admin ile kapsanmış |
| isg_organizasyon_atamalari | Politika içinde açık `f.osgb_id=p.osgb_id` (osgb_admin) + `p.firma_id=...firma_id` (firma) + `has_active_firma_assignment` kurallı |
| email_signatures | `user_id = auth.uid()` ile kişiye özel |
| ocr_jobs | `created_by = auth.uid()` |
| operasyon_dosyalari / operasyon_yorumlari | `operasyon_entity_accessible(entity_type, entity_id)` (OSGB/kişi zimmet kontrolü yapar) |
| osgb_yoneticileri | `profile_id = auth.uid()` / admin |
| profiles | `id = auth.uid()` / admin |
| support_tickets | `created_by = auth.uid()` / admin (`can_access_ticket`) |
| system_logs | yalnızca admin |

- **Sonuç:** Bu 22 tabloda **doğrulanmış çapraz-tenant sızma bulunmadı.** Hepsi ya politikasız (fail-closed) ya da kişi/kayıt bazlı bir yardımcı ile kapsanmış.

### B.4 İzolasyon omurgası — güçlü tasarım kanıtları
- `has_active_firma_assignment(p_user_id, p_firma_id)` (canlı gövde doğrulandı): `auth.uid()` NULL ise **false**; `auth.uid() <> p_user_id` ve rol `admin/osgb_admin` değilse **false**; ardından **aktif atama + aktif personel + aktif/silinmemiş firma + aktif/kapsam penceresi içindeki OSGB + tarih geçerliliği (`tr_today()`)** kontrolüyle EXISTS döner. Uzman/hekim için firma erişimi **bu fonksiyonla** kilitli.
- `osgb_access_ok()` sertleştirilmiş (Bölüm A.3) → atamalar/evraklar/firmalar/personeller RESTRICTIVE guard'ı NULL→TRUE ile baypas edilemez.
- `operasyon_entity_accessible` (canlı gövde): admin true; osgb_admin yalnızca `e_osgb = r_osgb`; uzman/hekim yalnızca kaydı oluşturan/zimmetli personel. Firma sınırı OSGB sınırı üzerinden uygulanıyor.
- `storage_tenant_ok(bucket, name)` → Storage okuma politikalarında (atama-belgeleri, noter-defteri, personel-foto, hazop-kanitlari) tenant kapısı.

### B.5 Storage izolasyonu
| Bucket | public | Değerlendirme |
|---|---|---|
| avatars | **true** | Profil fotoğrafı — public okuma normal (ID/path tahminine karşı dikkat) |
| osgb-logos | **true** | Marka logosu — public okuma normal |
| diğer 14 bucket | false | Private + politikayla korumalı |

- **Risk: DÜŞÜK.** `support` bucket'ı private; insert/read `support_tickets.created_by` ile bağlı. `announcements`, `atama-belgeleri` vb. tenant/path politikalarıyla korumalı.
- **F-B1 (Bilgi):** `avatars` ve `osgb-logos` public — bu bucket'lara **hassas içerik yüklenmemesi** kural olarak belgelenmeli.

### B.6 Edge Function tenant kontrolleri (client parametresine güven testi)
| Fonksiyon | Kimlik doğrulama | Tenant kontrolü | Sonuç |
|---|---|---|---|
| `firma-davet` | anon client `getUser(jwt)` → caller profili | osgb_admin için `osgb_id = caller.osgb_id`; admin için `body.osgbId`; firma `osgb` eşleşmesi, `CROSS_OSGB` döner | ✅ Sağlam |
| `osgb-davet` | `getUser(jwt)` + `role='admin'` zorunlu | — | ✅ Sağlam |
| `personel-hesap` | `getUser(jwt)` + rol osgb_admin/admin | `personel.osgb_id !== osgbId` → `CROSS_OSGB`; **rol, `personel_turu`'ndan türetilir, frontend `role`'a güvenilmez** | ✅ Sağlam |
| `accept-invite` | Token (kasıtlı public) | Rol/OSGB/firma **davet kaydından** okunur; `ROLE_CONFLICT`/`CROSS_OSGB`/`CROSS_FIRMA` kontrolleri | ✅ Sağlam (token = yetki) |

- **F-B2 (Orta · önceki denetimden devam):** 43 Edge Function'da `Access-Control-Allow-Origin: *`. Token sunucuda doğrulandığı için doğrudan exploit yok, ama wildcard CORS sertleştirilmeli.

---

## BÖLÜM C — Rol-Yetki Matrisi (admin / osgb_admin / firma / uzman / hekim / DSP)

### C.1 Rol kaynağı ve yükseltme direnci (KRİTİK — doğrulandı)
- Roller: `profiles.role` CHECK kısıtı → `admin, osgb_admin, firma, uzman, hekim, pending`. **`dsp` rolü yok** (aşağıda C.4).
- **Kendini yükseltme engeli — ÇİFT KATMAN:**
  1. `profiles_update_own` politikası yalnızca `id = auth.uid()` — bu **tek başına yetersiz** olurdu (WITH CHECK yazılmamış; kullanıcı kendi rolünü değiştirmek isteyebilirdi).
  2. **Ama `profile_lock_role` BEFORE UPDATE trigger'ı** (canlı gövde doğrulandı): `auth.uid() IS NOT NULL AND pg_trigger_depth()<=1` iken `role`/`osgb_id`/`firma_id` değişirse `RAISE EXCEPTION` (`ROLE_LOCK`/`OSGB_LOCK`/`FIRMA_LOCK`). Service_role (`auth.uid() NULL`) ve FK cascade (`depth>1`) hariç tutulmuş — doğru tasarım.
- **Değerlendirme:** İstemciden **dikey yükseltme (role=admin/osgb_admin) ve yatay yükseltme (başka osgb_id/firma_id'ye taşınma) engellenmiş.**
- **F-C1 (Düşük · savunma derinliği):** Yükseltme koruması **tamamen trigger'a** bağlı; politikanın kendisinde `WITH CHECK ('role','osgb_id','firma_id' değişmemeli)` yok. Trigger bir gün kaldırılırsa `profiles_update_own` yeniden açık hâle gelir. **Öneri:** politikaya WITH CHECK ve/veya kolon-seviyesi UPDATE grant ekle (yalnızca first_name/last_name/avatar_url).
- **F-C2 (Bilgi · GUV-02):** `handle_new_user()` rolü metadata'dan okumaz (daima `pending`); tek istisna gömülü bootstrap e-postası → bu yüzden **Auth self-signup KAPALI olmalıdır** (Dashboard'dan doğrulanamadı). (Kanıt: `supabase/migrations/20260101000200_guv02_handle_new_user.sql`.)

### C.2 Arayüz gizleme = güvenlik sınırı DEĞİL (doğru yaklaşım)
- `ProtectedLayout.tsx` → `roleMatchesPath()` + `PANEL_ROOT` ile her rolü kendi panel köküne yönlendirir (admin→admin+osgb-panel, osgb_admin→/osgb-panel, firma→/firma, uzman→/uzman, hekim→/hekim). Panel içi gizleme UI'dır; **asıl kapı RLS'tir.**
- `firmaDetayPermissions.ts` açıkça not düşer: *"Bu matris YALNIZCA arayüz görünürlüğünü belirler. Asıl yetki backend/RLS tarafındadır."* → **Doğru mimari.**
- Edge Functions caller rolünü **sunucuda** `profiles`'tan okur (client role parametresine güvenmez).

### C.3 Rol → kayıt erişimi matrisi (RLS politika kanıtına dayalı)
| Kaynak/Rol | admin | osgb_admin | firma | uzman | hekim | Kaynak kanıtı |
|---|---|---|---|---|---|---|
| osgb kaydı | tümü | yalnız kendi aktif OSGB | yalnız kendi (bağlı) | yalnız kendi (bağlı) | yalnız kendi (bağlı) | `osgb_select`, `osgb_select_bound_roles` |
| profiles | tümü | yalnız kendi | yalnız kendi | yalnız kendi | yalnız kendi | `profiles_select_own` |
| firmalar / personeller / atamalar / evraklar | tümü | kendi OSGB'si | kendi firması (`auth_firma_id`) | aktif atamalı firma (`has_active_firma_assignment`) | aktif atamalı firma | RESTRICTIVE guard + policy |
| teklifler / teklif_hizmetleri | tümü | kendi OSGB'si | — | — | — | `*_tenant_restrictive` |
| envanter | tümü | kendi OSGB'si | — | zimmet/kayıt bazlı | zimmet/kayıt bazlı | `envanter_insert/update_osgb`, `operasyon_entity_accessible` |
| custom_field_* | tümü | kendi OSGB'si | kendi firması | — | — | `cf*_insert/update_osgb/firma` |
| system_logs | tümü | — | — | — | — | `system_logs_select` (admin) |
| support_tickets | tümü | kendi kaydı | kendi kaydı | kendi kaydı | kendi kaydı | `tickets_*` (`created_by=auth.uid()`) |

### C.4 DSP rolü — kanıt ve netlik
- `personel-hesap` fonksiyonunda: `{isg_uzmani:'uzman', isyeri_hekimi:'hekim', dsp:'hekim', isg_teknikeri:'uzman'}` → **DSP, profiles'ta `hekim` rolüyle oluşturulur.** Ayrı bir `dsp` profile rolü **yok**.
- `firmaDetayPermissions.normalizeFirmaDetayRole()` hiçbir zaman `'dsp'` döndürmez (profiles.role 'dsp' olamaz) → DSP, hekim paneli/`isgScope='uzman'` davranışıyla çalışır.
- **F-C3 (Bilgi):** DSP'nin hekim ile **aynı** panel/veri kapsamına sahip olması tasarım tercihi. Hekim'e özel (sağlık) modüllerle DSP arasında ayrım gerekiyorsa, ayrı rol veya kolon düzeyi ayrım gerekir. `firmaDetayPermissions` içinde tanımlı ama erişilemez `'dsp'` anahtarı **ölü kod** (kafa karışıklığı riski).

### C.5 "Arayüzde gizli işlemi API'den çağırma" riski
- **Doğrulanmadı (limited):** Ekran görüntüsü/UI dışı bir işlemin doğrudan REST/RPC ile çağrılması ancak **izole ortamda anon/authenticated rolüyle** test edilebilir; bu ortamda yapılamadı.
- **Statik değerlendirme:** Yazma yollarının büyük kısmı **SECURITY DEFINER RPC** (ör. `teklif_kaydet/sil`, `*_validate/lock` trigger'ları) ve RLS RESTRICTIVE guard'larla korunuyor. `evraklar` için istemci INSERT/UPDATE/DELETE politikaları **`false`** ile kapatılmış (yalnız service yazar). Bu, dikey yükseltme yüzeyini ciddi biçimde daraltıyor.
- **Kalan risk:** Client parametresine dayanan **RPC gövde doğrulamaları** (ör. `custom_field_definition_set_osgb`, `envanter_*`) statik incelendi; içlerindeki scope setter'ların `auth_osgb_id()`'ye sabitlediği görülüyor, ancak **çalıştırarak** doğrulanmadı.

---

## Özet Risk Tablosu

| ID | Bulgu | Seviye | Durum |
|---|---|---|---|
| A1/F-A1 | anon+authenticated tüm 176 tabloda geniş tablo yetkisi (TRUNCATE dahil) | **Orta** (savunma derinliği) | RLS tutuyor; aktif açık yok |
| F-A2 | Politikaların %81'i `TO public` | Düşük-Orta | Aktif sızma yok |
| F-A4 | 15 politika `qual=true` (referans tablolar) | Düşük | Niyet teyidi gerek |
| F-C1 | `profiles_update_own`'da WITH CHECK yok; koruma trigger'a bağlı | Düşük | Trigger çalışıyor |
| F-B2 | 43 Edge Function'da CORS `*` | Orta | Sertleştirme önerilir |
| F-C2 | Bootstrap admin e-postası → self-signup kapalı olmalı | Bilgi | Dashboard doğrulaması gerek |
| F-A6 | `evraklar_select_legacy` roles={postgres} | Bilgi | Netleştirme |
| F-C3 | DSP = hekim (profile rolü yok); `'dsp'` ölü kod | Bilgi | Tasarım kararı |
| F-B1 | avatars/osgb-logos bucket'ları public | Bilgi | Hassas içerik konmamalı |

**Doğrulanmış, sömürülebilir kritik bir açık bulunmadı.** Veri katmanı olgun; kalan işler çoğunlukla savunma derinliği sertleştirmesi + Dashboard/hosting doğrulaması.

---

## İncelenemeyen / doğrulanamayan alanlar (dürüst sınırlar)
1. **Runtime RLS testi** — anon/authenticated rolüyle çalıştırma yapılamadı; değerlendirme metadata + statik.
2. **Çapraz-tenant canlı test** — izole iki-OSGB ortamı yok; gerçek saldırı simülasyonu yapılmadı.
3. **Supabase Auth Dashboard** — self-signup durumu, parola politikası, JWT süresi, rate-limit, refresh-token rotation okunamadı.
4. **Per-function `verify_jwt`** — dashboard ayarı bu ortamdan doğrulanamadı.
5. **CORS başlığı / CSP** — hosting yanıt başlıkları (frame-ancestors vb.) uygulama kodundan doğrulanamaz.
6. **Storage nesne içerikleri** — yalnızca bucket/politika incelendi; gerçek nesne erişim testi yapılmadı.

## Önerilen sertleştirme adımları (öncelik sırasıyla)
1. Gereksiz **tablo-seviyesi grant**'leri daralt (özellikle `truncate`, `references`); politikaları mümkünse `TO authenticated` yap.
2. `profiles` UPDATE için **kolon-seviyesi grant** (yalnız first_name/last_name/avatar_url) + politika `WITH CHECK`.
3. Edge Function **CORS** allow-list'e indir.
4. 15 adet `qual=true` politikanın **niyetini teyit et**, hassas tablo varsa kapsamlandır.
5. `evraklar_select_legacy` (postgres) ve `'dsp'` ölü kodunu temizle/netleştir.
6. Auth Dashboard'da **self-signup kapalı** + güçlü parola politikası + makul JWT süresi doğrula.