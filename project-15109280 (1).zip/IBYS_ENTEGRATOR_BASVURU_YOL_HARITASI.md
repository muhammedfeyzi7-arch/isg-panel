# İBYS Entegratör Firma Yetki Süreci — Yol Haritası

> Durum: **Başvuru YAPILMADI.** Süreç analiz edildi, sıralama netleşti.
> Rol: **Yazılım şirketi (entegratör adayı)** — OSGB değiliz.
> Son güncelleme: 2026-10-20

---

## 0. Neden "İBYS Test Web Servis Erişim Talebi" görünmüyor?

İSG-KATİP'te **iki ayrı bildirim türü** var ve ikisi farklı kitleye hitap ediyor:

| Bildirim türü | Kim başvurur | Amaç |
|---|---|---|
| `İBYS Test Web Servis Erişim Talebi Bildirimi` | **İşyeri / OSGB** | Kendi verisini kendi yazılımıyla göndermek |
| `İBYS Entegratör Firma Yetki Talebi Bildirimi` | **Yazılım şirketi** | Müşterileri adına entegre yazılım satmak |

Biz ikinci gruptayız → aranan tür **`İBYS Entegratör Firma Yetki Talebi Bildirimi`**.
Birinci tür bizim hesabımızda hiçbir zaman listelenmez; bu bir hata değil, tasarım.

**Ayrıca kritik sıra:** Entegratör yetki talebi bildirimi, **yazılım gösterimi (demo)
başarıyla tamamlanmadan İSG-KATİP'te açılmıyor.** Yani "menüde yok" durumu, demo
yapılmadığı sürece normaldir.

---

## 1. Ön koşullar (bunlar eksikse süreç hiç başlamaz)

| # | Ön koşul | Not |
|---|---|---|
| 1 | **Kendi şirketimizin SGK işyeri sicil no'su** (26 hane) | Müşterinin/OSGB'nin sicili DEĞİL. Kurumsal giriş kendi sicilimizle yapılır |
| 2 | İSG-KATİP'e **Kurumsal** giriş (Şahsi değil) | e-Devlet → İSG-KATİP → Kurumsal |
| 3 | Giriş yapan kişi **işyeri yetkilisi / temsil ve ilzam** | Şirket müdürü/ortağı olmalı |
| 4 | `Kurumsal İletişim Bilgileri` dolu | Beyan Kurumsal Telefon + Beyan E-posta |
| 5 | **Kurumsal domain e-posta** | gmail / hotmail / yahoo **kabul edilmiyor** — en sık takılma noktası |
| 6 | **Sabit yurt içi IP** | Tek IP beyan edilecek (bkz. Bölüm 6) |

Menü yolu: `Kişi/Kurum/Ekipman Kartı → İşyeri Bilgileri → İşyeri Kartı Bilgileri → Kurumsal İletişim Bilgileri`

---

## 2. Süreç — 7 adım, sıralı

### Adım 1 — Kurumsal iletişim bilgilerini tamamla
Yukarıdaki 1–5 numaralı ön koşullar. Kurumsal domain e-postası şart.

### Adım 2 — Yazılım gösterimi (demo) randevusu talep et
`ibys@csgb.gov.tr` adresine mail. Bu adım **İSG-KATİP'ten önce** gelir.

### Adım 3 — Demoyu yap
Bakanlık ekibi, yayımladıkları **Veri Setleri + Metotlar**'a uygun veri topladığımızı
ve web servis aktarımının çalıştığını canlı görmek ister. Bkz. Bölüm 4.

### Adım 4 — `İBYS Entegratör Firma Yetki Talebi Bildirimi` aç
Demo geçtikten sonra İSG-KATİP → `Süreç Yönetimi → Kurumsal Bildirim Başvuruları → YENİ`.
Tür ancak bu aşamada listelenir.

### Adım 5 — Belgeleri yükle (⏰ 2 GÜN)
Islak imzalı + kaşeli, **PDF**. Bildirim açıldıktan sonra **2 gün içinde**
tamamlanmazsa başvuru **otomatik iptal** olur ve süreç sıfırdan başlar.
Bkz. Bölüm 3'teki 6 belge. **Bu 6 belge hazır olmadan Adım 4'e basılmamalı.**

### Adım 6 — Onay → Entegratör Firma Kodu
Bakanlık onayı sonrası firmaya özel entegratör firma kodu + canlı ortam yetkisi tanımlanır.

### Adım 7 — Müşteri işyeri onayı
Her işyeri (OSGB veya işveren) kendi İSG-KATİP kurumsal hesabından bizi seçip
**onay** vermek zorunda:
`İBYS Hizmet Alma Bilgileri → Onay Bekliyor → Onayla`

> **Kural:** Bir işyerinin aynı anda **yalnızca bir** entegratör onayı olabilir.
> Yeni onay verildiğinde önceki/bekleyen diğer entegratör bildirimleri **otomatik iptal** olur.
> Bu, ürün akışımızda "firma devri" senaryosu demek — tasarımda hesaba katılmalı.

---

## 3. Zorunlu belgeler (6 adet)

| # | Belge | İçerik / dikkat |
|---|---|---|
| 1 | **Gizlilik Sözleşmesi** (Bilişim Sistemleri Gizlilik ve Veri Paylaşım Sözleşmesi) | Bakanlık ↔ yazılım üretici firma; veri gizliliği + paylaşım sürekliliği taahhüdü |
| 2 | **Sözleşme Başvuru Formu** | Firma + yazılım genel bilgileri |
| 3 | **Uzaktan Erişim Talep Formu** | **Yalnızca 1 (bir) IP adresi** yazılır |
| 4 | **İBYS Güvenlik Testi Raporu** | **TSE onaylı A Seviye Sızma Testi firması**ndan Uygulama Sızma Testi raporu |
| 5 | **İBYS Yedekleme Prosedürü** | Hangi veri, hangi sıklıkla, nerede saklanır, geri yükleme testi |
| 6 | **İBYS Veritabanı Değişiklik Prosedürü** | Değişiklik talepleri **yalnızca veri sahibinden** gelir kuralı + kayıt/işleyiş |

Formlar: `ibys.csgb.gov.tr → Başvuru Formları`

### Belge 4 hakkında uyarı — mevcut pentest raporu yetmeyebilir
Raporun **TSE onaylı A seviye** bir firmadan alınmış olması zorunlu. Daha önce
yaptırdığımız pentest bu şartı karşılamıyorsa **yeni rapor gerekir** ve rapor
**Türkiye'de barındırılan nihai sistem** için düzenlenmiş olmalı
(bkz. `IBYS_SELF_HOST_PLAN.md` → "Sızma Testi Zamanlaması").
→ Aksiyon: Nesil Grup teklifinin (NT-PT-2026-118) **"TSE onaylı A seviye"** şartını
karşıladığı **yazılı** olarak teyit edilmeli. Varsayım yapılmamalı.

### Belge 5 & 6 hakkında
Bu iki prosedür dokümanı bizde henüz yok. İçerikleri teknik olarak yazılabilir
(yedekleme script'i `deploy/scripts/` içinde zaten var), ama **belge olarak
imzalanıp taranması** gerekir.

---

## 4. Demo'da gösterilmesi gerekenler

Bakanlığın yayımladığı v2 dokümanındaki metot envanteri:

| Controller | Metotlar |
|---|---|
| Eğitim | `egitimBilgisiBildir`, `egitimBilgisiGoruntule`, `egitimBilgisiSil` |
| Hizmet Verilen İşyeri | `hizmetVerilenIsyeriBildir`, `hizmetVerilenIsyeriSil`, `hizmetBilgisiDurumGoruntule` |
| İSG Profesyoneli | `isgProfesyoneliDogrula`, `isgProfesyoneliSozlesmeKontrolu` |
| Muayene | `muayeneBilgisiBildir`, `muayeneBilgisiGoruntule`, `muayeneBilgisiSil` |
| Çalışan | `calisanSigortalilikKontrolu` |
| Referans | `ustReferansDegerlerGoruntule`, `bagliReferansDegerlerGoruntule` |
| Maden | `madenVeriSetiBildir`, `madenVeriSetiBilgisiGoruntule` |

**Demoda en az şunlar canlı çalışmalı:**
1. Referans listelerini API'den çekip kendi eşleştirme tablomuzu doldurma
2. `hizmetVerilenIsyeriBildir` → `bildirimNo` → `hizmetBilgisiDurumGoruntule` zinciri
3. `egitimBilgisiBildir` → `egitimBilgisiGoruntule` → `egitimBilgisiSil`
4. Sorgu metotları: `isgProfesyoneliDogrula`, `calisanSigortalilikKontrolu`

**Kapsam gerçeği:** Tetkik, Risk Değerlendirmesi, İş Kazası/Ramak Kala ve KKD için
API'de **metot yok**. Demoda bu türleri "İBYS'ye gönderilir" diye sunmak risklidir.
Bu türler yalnızca kendi sistemimizde tutulur; tetkik bilgisi muayene bildiriminin
içinde (`kanTetkikiYapildiMi`, `idrarTetkikiYapildiMi`) gider.

---

## 5. Başarı kriteri (yanıt sözleşmesi)

Tüm metotların yanıt şeması aynı:

```json
{ "sonuc": "1", "aciklama": "Kayıt başarıyla eklenmiştir.", "bildirimNo": "uuid" }
```

- `sonuc: "1"` = başarı, `sonuc: "0"` = başarısız
- **Başarı göstergesi HTTP 200 değil, `sonuc` alanı.**
- Hata kodları: `401` kimlik geçersiz, `400` validasyon (errors dizisi), `500`/`1111` sunucu

Bu, mevcut kodumuzdaki `code`/`message`/`referansNo` okuma mantığının **yanlış**
olduğu anlamına gelir. Kod düzeltmesi ayrı bir iş kalemi (kod fazı).

---

## 6. 🔴 Tek IP kısıtı — mimariyi doğrudan etkiliyor

`Uzaktan Erişim Talep Formu`'na **yalnızca 1 adet IP** yazılabiliyor.
Bu, İBYS entegrasyonunun **tek bir çıkış noktasından** yapılması gerektiği anlamına gelir.

**Bizim durumumuz (iyi haber):** Self-host sunucumuz zaten var.

| Bilgi | Değer |
|---|---|
| Sunucu | Turhost VDS TR 6 — `srv.ibys-prod.com` |
| Sabit yurt içi IP | `37.230.105.216` |
| API adresi | `api.isgdenetim.com.tr` |
| Servisler | Supabase self-host (Docker), 12/12 healthy |

Yani tüm İBYS çağrıları **bu sunucudan** çıkmalı. Edge Function'lar bu sunucuda
çalıştığı sürece çıkış IP'si `37.230.105.216` olur → şart sağlanır.

**Yapılmaması gerekenler:**
- İBYS çağrısını **tarayıcıdan** (frontend) yapmak → kullanıcının IP'si çıkar, reddedilir + firma şifresi sızar
- İBYS çağrısını **SaaS Supabase / başka bulut** üzerinden yapmak → yurt dışı IP, reddedilir
- Çıkış IP'sini değiştiren bir proxy/VPN katmanı eklemek

**Teyit edilmesi gereken belirsizlik:** Formun "uzaktan erişim" ifadesi iki şekilde
yorumlanabilir: (a) bizim İBYS'ye çıkış IP'miz, (b) Bakanlığın bizim sistemimize
erişeceği IP. Yönü ne olursa olsun **tek IP** olduğu için beyan edilecek değer
`37.230.105.216`. Yine de `ibys@csgb.gov.tr`'ye açıkça sorulmalı — yanlış yönde
beyan, demo gününde bağlantı kopması demek.

**Ek risk:** Sunucu IP'si değişirse (sağlayıcı taşıma, IP yenileme) İBYS erişimi
kesilir ve form yenilenmesi gerekir. Sunucu sözleşmesinde IP sabitliği teyit edilmeli.

---

## 7. Takvim beklentisi

| Aşama | Gerçekçi süre |
|---|---|
| Ön koşullar (sicil, yetki, kurumsal e-posta) | 1–3 gün |
| Randevu talebi + demo tarihi | 1–3 hafta (Bakanlık yoğunluğuna bağlı) |
| Demo | 1 gün |
| Bildirim + 6 belge yükleme | ⏰ 2 gün (sabit, kaçırılırsa iptal) |
| Onay | 1–3 hafta |
| **Toplam** | **~4–8 hafta** |

Belgelerin (özellikle sızma testi raporu) demo **öncesinde** hazır olması gerekir,
yoksa 2 günlük pencere kaçırılır.

---

## 8. Şu an yapılacaklar (kod yok)

- [ ] `ibys@csgb.gov.tr`'ye mail: entegratör yetkisi + demo randevu talebi (şablon Bölüm 9)
- [ ] Kurumsal domain e-posta hazırla (gmail/hotmail değil)
- [ ] Kendi SGK işyeri sicil no'sunu netleştir
- [ ] Nesil Grup'tan **"TSE onaylı A seviye"** yazılı teyidi al
- [ ] Yedekleme Prosedürü + Veritabanı Değişiklik Prosedürü taslaklarını yaz
- [ ] `Uzaktan Erişim Talep Formu` için `37.230.105.216` beyanını teyit et
- [ ] Başvuru Formları'nı indir, imza/kaşe akışını planla

## 9. Hazır mail şablonu

> Sayın Bakanlık,
>
> Firmamız İSG yazılımı geliştirmektedir. İBYS 2.0 web servislerine entegrasyon
> sağlamak ve entegratör firma yetkisi almak istiyoruz.
>
> - Firma unvanı: …
> - SGK işyeri sicil no: … (26 hane)
> - Kurumsal e-posta: … (kurumsal domain)
> - Sabit yurt içi IP: 37.230.105.216
> - Kullanılacak test servis adresi: `https://ibystestws.csgb.gov.tr/ibystest/api/...`
>
> Yazılım gösterimi (demo) için randevu talep ediyoruz. Ayrıca;
> - Entegratör Firma Yetki Talebi Bildirimi'nin İSG-KATİP kurumsal girişimizde
>   hangi koşullar sağlandıktan sonra listeleneceği,
> - `Uzaktan Erişim Talep Formu`'ndaki tek IP adresinin hangi yönde (firmamızın
>   İBYS'ye çıkış IP'si mi) kullanıldığı,
> - Güvenlik Testi Raporu'nun TSE onaylı A seviye firma şartına ilişkin kabul kriterleri
>
> konularında bilgi rica ederiz.
>
> Saygılarımızla,

---

## 10. Riskler

| Risk | Etki | Önlem |
|---|---|---|
| 2 günlük belge penceresi kaçırılır | Başvuru iptal, süreç sıfırlanır | 6 belge demo öncesi hazır |
| Sızma raporu TSE A seviye değil | Başvuru reddi | Yazılı teyit al |
| Sunucu IP değişir | Erişim kesilir, form yenilenir | IP sabitliği sözleşmede |
| Kurumsal e-posta ücretsiz domain | Bildirim açılmaz | Kurumsal domain kur |
| Yanlış sicille giriş | Başvuru yanlış kurum adına gider | Kendi sicilini belgele |
| Demo'da API'de olmayan türleri vaat etmek | Demo başarısız | Kapsamı Eğitim + Muayene'ye indir |