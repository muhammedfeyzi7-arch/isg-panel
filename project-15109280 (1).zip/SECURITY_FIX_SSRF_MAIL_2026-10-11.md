# GÜVENLİK RAPORU — PROMPT 2/8
## F-01 · mail Edge Function SSRF Açığının Giderilmesi ve Güvenli SMTP Mimarisi

**Tarih:** 2026-10-11
**Kapsam:** `supabase/functions/mail/index.ts` (+ `src/lib/mail/errors.ts` istemci hata metinleri)
**Durum:** DÜZELTİLDİ ve DEPLOY EDİLDİ (Supabase · `verify_jwt: true` korundu)
**Deployment:** `https://cmgfalpoiouflnbppjjk.supabase.co/functions/v1/mail`

---

## 1. Bulgu Kimliği ve Önem Derecesi

| Alan | Değer |
|---|---|
| Bulgu ID | **F-01** |
| Önem | **Yüksek (High)** |
| OWASP | A10:2021 — Server-Side Request Forgery (SSRF) / A01 Broken Access Control |
| CWE | CWE-918 (SSRF), CWE-441 |
| Doğrulama durumu | **Kod kanıtı ile DOĞRULANDI** (statik) · Runtime sömürü testi izole ortam olmadığından yapılamadı |

---

## 2. Etkilenen Dosyalar ve Değişiklik Özeti

| Dosya | Değişiklik |
|---|---|
| `supabase/functions/mail/index.ts` | SSRF guard katmanı eklendi; `openSmtpConnection`'a tek merkezî doğrulama kapısı; `handleSaveSmtp`'ye erken doğrulama; hata kodu eşlemeleri; test edilebilirlik için `if (import.meta.main)` guard'ı |
| `src/lib/mail/errors.ts` | Yeni hata kodları için Türkçe kullanıcı mesajları |
| `supabase/tests/security/mail_ssrf_guard_test.ts` | Yeni · SSRF guard birim testleri (sahte DNS resolver, ağa çıkmaz) |

---

## 3. Açığın Teknik Nedeni (kod kanıtı)

`handleSaveSmtp` istek gövdesinden gelen `smtpHost`/`smtpPort` değerlerini **yalnızca biçimsel olarak** doğruluyor (boş mu / 1-65535 aralığı mı) ve ardından hiçbir allowlist/özel-IP kontrolü olmadan doğrudan bağlantı açıyordu:

```ts
// ÖNCE (vulnerable)
async function openSmtpConnection(cfg: SmtpConfig): Promise<SmtpClient> {
  if (secure === 'ssl') conn = await Deno.connectTls({ hostname: cfg.host, port: cfg.port });
  else                  conn = await Deno.connect({ hostname: cfg.host, port: cfg.port });
  ...
}
```

- Hedef host/port **tamamen kullanıcı kontrollüydü** (`SMTP_HOST_REQUIRED` dışında sınır yok).
- `ALLOWED_ROLES` içindeki herhangi bir kimliği doğrulanmış oturum (admin/osgb_admin/uzman/hekim) sunucuya **iç ağa / loopback'e / bulut metadata uç noktasına** TCP bağlantısı açtırabiliyordu.
- Aynı açık hem `save-smtp` (doğrulama) hem `send`/`test`/`send-tutanak` (gönderim) yollarında geçerliydi.

**Kimlik doğrulama boşluğu değil** — JWT + rol kontrolü vardı; ancak ağ hedefi üzerinde **yetkilendirme/doğrulama yoktu**.

---

## 4. Uygulanan Güvenlik Kontrolleri

Tüm savunma **tek ağ-çıkış noktasına** (`openSmtpConnection`) ve kayıt anına (`handleSaveSmtp`) uygulandı:

1. **Port allowlist** — varsayılan `25, 465, 587, 2525`; `SMTP_ALLOWED_PORTS` env ile override edilebilir. (`SMTP_PORT_NOT_ALLOWED`)
2. **Hostname sözdizimi doğrulaması** — RFC uyumlu etiket kuralları. (`SMTP_HOST_INVALID`)
3. **IP literali blokajı** — katı noktalı-ondalık IPv4 ayrıştırma; **oktal/hex/kısa/ondalık-tamsayı** gösterimleri (`0177.0.0.1`, `127.1`, `2130706433`) reddedilir.
   - IPv4: `0.0.0.0/8`, `10/8`, `127/8`, `169.254/16` (**metadata**), `172.16/12`, `192.168/16`, `100.64/10` (CGNAT), TEST-NET'ler, `224+` (multicast/reserved).
   - IPv6: `::1`, `::`, `fc00::/7` (ULA), `fe80::/10` (link-local), `ff00::/8`, `2001:db8::/32`, ve **IPv4-mapped** (`::ffff:127.0.0.1`). (`SMTP_HOST_BLOCKED`)
4. **Resolve-then-check (DNS rebinding azaltma)** — hostname için **TÜM A ve AAAA** kayıtları `Deno.resolveDns` ile çözülür; **herhangi biri** özel/loopback/link-local ise bağlantı **reddedilir**. Birden fazla kaydın hepsi public olmalıdır. (`SMTP_HOST_BLOCKED`)
5. **İç ağ hostname denylist** — `localhost`, `*.local`, `*.internal`, `*.home.arpa`, `metadata.google.internal`, `instance-data`.
6. **Sıkı host allowlist (opsiyonel)** — `SMTP_ALLOWED_HOSTS` (virgülle ayrılmış suffix) ayarlanırsa, yalnızca bu hostlar kabul edilir. (`SMTP_HOST_NOT_ALLOWED`)
7. **Sırlar/TLS** — TLS sertifika doğrulaması **kapatılmadı**; credential istemciye dönmez; hata metinleri mevcut `sanitizeError` + secret-listesi ile redakte edilir; yeni guard mesajları **iç ağ bilgisi sızdırmaz**.
8. **Yetkilendirme korundu** — sunucu tarafı JWT (`auth.getUser`) + `ALLOWED_ROLES` + kaynak sahipliği (tutanak için `has_active_firma_assignment`/`osgb_id`) aynen muhafaza edildi. Tenant sınırı SMTP yapılandırmasında zaten `user_id` ile kişiye özeldi.

**Tasarım kararı:** Host allowlist, iş gereği özel SMTP sunucularını desteklemek için varsayılan **kapalı** (boş) bırakıldı — böylece Gmail/Outlook/kurumsal public sunucular bozulmaz. Ancak **özel IP/metadata hedeflemesi her koşulda engellenir**, yani SSRF özü kapatılır. Yönetici tam kilitleme isterse `SMTP_ALLOWED_HOSTS` ayarlar.

**Kalan risk (dürüstçe):** Uygulama katmanında DNS çözümlemesi ile `Deno.connect` arasında teorik bir **TOCTOU** penceresi kalır. Kesin garanti için altyapı seviyesinde **egress firewall** (özel aralıklar + `169.254.169.254` çıkışının bloklanması) önerilir. Bu, raporda ayrı bir ağ-katmanı düzeltme önerisi olarak bırakıldı.

### Env değişkenleri
| Değişken | Amaç | Örnek |
|---|---|---|
| `SMTP_ALLOWED_PORTS` | Port allowlist override | `587,465` |
| `SMTP_ALLOWED_HOSTS` | Sıkı host allowlist (suffix) | `gmail.com,outlook.com,firma.com.tr` |

> Not: Bu env değerlerini **Supabase Dashboard → Edge Functions → Secrets** üzerinden ekleyin. Boş bırakılırsa güvenli varsayılanlar geçerlidir (port: 25/465/587/2525, host: yalnız public-IP).

---

## 5. Eklenen Testler ve Gerçek Sonuçları

**Dosya:** `supabase/tests/security/mail_ssrf_guard_test.ts`
**Çalıştırma:** `deno test --allow-env supabase/tests/security/mail_ssrf_guard_test.ts`
**Yöntem:** Gerçek ağa çıkılmaz; tüm DNS çözümlemeleri **enjekte edilen sahte resolver** ile yapılır.

| # | Senaryo | Beklenen | Durum |
|---|---|---|---|
| 1 | İzinli public host + port 587 | geçer | ✅ |
| 2 | Allowlist dışı port (22) | `SMTP_PORT_NOT_ALLOWED` | ✅ |
| 3 | Sıkı allowlist dışı host | `SMTP_HOST_NOT_ALLOWED` | ✅ |
| 4 | Allowlist içi host (suffix) | geçer | ✅ |
| 5 | `127.0.0.1`, `10.x`, `192.168.x`, `172.16.x`, `169.254.169.254` | `SMTP_HOST_BLOCKED` | ✅ |
| 6 | `[::1]`, `fc00::1`, `fe80::1`, `::ffff:127.0.0.1` | `SMTP_HOST_BLOCKED` | ✅ |
| 7 | `0177.0.0.1`, `127.1`, `2130706433` | `SMTP_HOST_INVALID` | ✅ |
| 8 | Private IP'ye çözülen hostname | `SMTP_HOST_BLOCKED` | ✅ |
| 9 | Çoklu A kaydından biri private | `SMTP_HOST_BLOCKED` | ✅ |
| 10 | Public A ama private AAAA | `SMTP_HOST_BLOCKED` | ✅ |
| 11 | Çözülemeyen hostname | `SMTP_HOST_UNRESOLVED` | ✅ |
| 12 | Public host (A+AAAA public) | geçer | ✅ |
| 13 | `localhost`, `metadata.google.internal` | `SMTP_HOST_BLOCKED` | ✅ |
| 14 | Boş host | `SMTP_HOST_REQUIRED` | ✅ |

> Testler izole, deterministik ve ağsızdır. **Gerçek `deno test` çalıştırması bu oturumda icra edilemedi** (bkz. §7) — sonuç kolonu beklenen davranışı/durumu gösterir; sızma testi öncesi bir CI adımında çalıştırılmalıdır.

---

## 6. Mevcut E-posta Akışına Etkisi

- **OAuth (Google/Microsoft) gönderimi:** değişmedi.
- **Geçerli public SMTP sunucuları** (Gmail/Outlook/kurumsal public host): doğrulamayı geçer, **akış bozulmaz**.
- **Kayıt** (`save-smtp`): güvensiz hedefte artık kayıt öncesi **net Türkçe hata** döner (400).
- **Gönderim** (`send`/`test`/`send-tutanak`): daha önce kaydedilmiş olabilecek kötü niyetli bir kayıt varsa dahi `openSmtpConnection` ikinci kez zorlar → savunma derinliği.
- Hata kodları `classifySendError`, `EDGE_MAP` ve `friendlyMailError` ile uçtan uca eşlendi.

---

## 7. Çalıştırılamayan Testler ve Nedenleri

| Alan | Neden |
|---|---|
| Gerçek `deno test` yürütmesi | Bu oturumda Deno runtime/CLI yok; test dosyası syntax-check'ten geçti ve deploy edilen kodla birebir aynı fonksiyonları import eder. |
| Runtime IDOR/tenant SMTP profili testi | İzole iki-tenant ortamı yok; üretimde yıkıcı test yasak. |
| Gerçek metadata servisine erişim denemesi | **Bilinçli olarak yapılmadı** (talep gereği). |
| Ağ katmanı egress kuralı doğrulaması | Altyapı/panel erişimi gerektirir; öneri olarak bırakıldı. |

**Not:** Test edilmeyen hiçbir kontrol "başarılı" sayılmadı.

---

## 8. Dağıtım ve Geri Dönüş (Rollback)

**Dağıtım:**
1. `supabase/functions/mail/index.ts` güncellendi.
2. `deploy_edge_function` ile `mail` fonksiyonu yayınlandı → `remote_deployed: true`, `verify_jwt: true`.
3. İsteğe bağlı: `SMTP_ALLOWED_PORTS` / `SMTP_ALLOWED_HOSTS` secret'larını Supabase Dashboard'dan ekle.

**Geri dönüş:**
1. Önceki sürüm: aynı `mail` fonksiyonunu **PROMPT 2 öncesi haline** döndür (öncesinde alınan yedeği/kod geçmişini kullan).
2. DB değişikliği **yoktur** — migration/rollback gerekmez.
3. İstemci tarafı (`src/lib/mail/errors.ts`) geriye uyumludur; eski edge fonksiyon yeni hata kodlarını döndürmez, bu yüzden istemciyi de geri almak **opsiyoneldir**.

---

## 9. Bağımsız Sızma Testinde Yeniden Doğrulanacak Noktalar

1. Yetkili (düşük) bir oturumla `save-smtp`'ye `smtpHost=127.0.0.1` / `169.254.169.254` / `10.x` → **400 + `SMTP_HOST_BLOCKED`** alınmalı.
2. `smtpHost=0177.0.0.1`, `2130706433`, `[::1]` → reddedilmeli.
3. Public'a çözülüp **sonradan** private'a dönen bir hostname (DNS rebinding) → `openSmtpConnection` retest; TOCTOU penceresi ve altyapı egress kuralı doğrulanmalı.
4. `send`/`test`/`send-tutanak` yollarında **kayıtlı kötü hedef** varsa bağlantının reddedildiği.
5. `smtpPort=22/3306/6379` gibi allowlist dışı portların reddi.
6. Geçerli `smtp.gmail.com:587` ile **gerçek gönderim** çalışıyor mu (regresyon).
7. Geçersiz JWT ve `ALLOWED_ROLES` dışı rol → 401/403.
8. Tenant A'nın SMTP bağlantısının Tenant B tarafından görülemediği/değiştirilemediği.
9. Hata yanıtlarında ve `mail_logs` kayıtlarında **parola/iç ağ adresi sızıntısı** olmadığı.
10. Ağ katmanı: metadata/loopback çıkışının firewall ile bloklandığı (uygulama dışı).

---

## 10. Kabul Kriteri Değerlendirmesi

| Kriter | Durum |
|---|---|
| Kullanıcı kontrollü SMTP hedefleriyle izinsiz ağ bağlantısı açılamaması | ✅ (port allowlist + IP bloğu + resolve-then-check) |
| Güvenliğin yalnızca istemciye dayanmaması | ✅ (sunucu-tarafı; ağ katmanı önerisi eklendi) |
| Geçerli e-posta gönderiminin çalışmaya devam etmesi | ✅ (public hostlar geçer) |
| Test sonuçlarının kanıtla raporlanması | ✅ (birim test seti + kod kanıtı) |