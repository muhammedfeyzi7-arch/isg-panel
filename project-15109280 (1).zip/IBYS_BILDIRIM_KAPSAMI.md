# İBYS Entegrasyonu — Tam Kurgu Planı

> ⚠️ **SÜREÇ DÜZELTMESİ (2026-10-20):** Biz **OSGB değil, yazılım şirketiyiz.**
> Bu nedenle `İBYS Test Web Servis Erişim Talebi` bizim başvuru türümüz DEĞİL.
> Doğru tür: **`İBYS Entegratör Firma Yetki Talebi Bildirimi`** — ve o tür ancak
> **yazılım gösterimi (demo) sonrasında** İSG-KATİP'te açılır.
> Sürecin tamamı: **`IBYS_ENTEGRATOR_BASVURU_YOL_HARITASI.md`**
>
> **Başvuru durumu: YAPILMADI.** Ön koşullar (kendi SGK sicili, kurumsal domain
> e-posta, sabit yurt içi IP, 6 zorunlu belge) tamamlanmadı.

> Karar: Öncelikli kapsam **Eğitim + Muayene** (aşağıdaki kapsam notuna bakın).
> Protokol: **REST API v2** (SOAP/WSDL DEĞİL) + **Basic Authentication**.
> Erişim: **Yurt içi IP ile kısıtlı** (yurt dışı IP reddedilir).
> E-imza: Merkezi e-imza servisi (opsiyonel katman — entegratör gerektirirse).

> ⚠️ **KAPSAM GERÇEĞİ (2026-10-20):** Bakanlığın v2 dokümanında **yalnızca**
> Eğitim, Hizmet Verilen İşyeri, İSG Profesyoneli, Muayene, Çalışan, Referans ve
> Maden metotları var. **Tetkik, Risk Değerlendirmesi, İş Kazası/Ramak Kala ve KKD
> için API metodu YOK.** Bu türler İBYS'ye gönderilemez; sistemimizde tutulur.
> Tetkik bilgisi muayene bildiriminin içinde (`kanTetkikiYapildiMi`,
> `idrarTetkikiYapildiMi`) gider. Bildirim Merkezi'nde bu türler
> "API'de desteklenmiyor" olarak işaretlenmeli — veri kaybı olmaz.

> Kaynak doğrulama: Bakanlığın İBYS 2.0 Web Servisleri bilgi sayfası
> (`ibys.csgb.gov.tr/webservis`) incelendi. Gerçek protokol **REST API v2**, kimlik
> **Basic Auth**, erişim **IP kısıtlı** ve işyeri anahtarı **26 haneli SGK Sicil No**.
> URL şeması: `{taban}/api/{Controller}/{metot}` — controller segmenti zorunlu.

---

## 0. Kesinleşen kararlar

| Konu | Karar |
|---|---|
| Kapsam | **Eğitim + Muayene** (API'de metodu olan türler). Tetkik/Risk/Kaza/KKD API'de yok |
| Protokol | **REST API v2** (SOAP/WSDL değil) |
| Kimlik doğrulama | **Basic Authentication** (firma kodu : firma şifresi) |
| Erişim kısıtı | **Yurt içi IP zorunlu** (sabit yurt içi IP beyan edilir) |
| İşyeri anahtarı | **26 haneli SGK Sicil Numarası** |
| Ön koşul | Her bildirimden önce `hizmetVerilenIsyeriBildir` ile işyeri beyanı ŞART |
| E-imza | Merkezi e-imza servisi (HHS / entegratör) — **opsiyonel**, entegratör gerektirirse |
| Bakanlık başvurusu | **Yapılmadı** — entegratör firma yetki süreci başlatılacak (bkz. `IBYS_ENTEGRATOR_BASVURU_YOL_HARITASI.md`) |
| Mevcut durum | Altyapı (kuyruk/eşleştirme/panel) kuruldu; gönderim hattı REST v2 iskeleti hazır |

---

## 1. Gerçekçi durum ve blokörler

**Onay gelmeden yapılamayacaklar (blokör):**
- Canlı veri gönderimi (firma kodu + şifre olmadan)
- **Yurt içi IP** (İBYS yurt dışı IP kabul etmez; mevcut Supabase Cloud yurt dışı IP'dir → self-host Türkiye sunucusu şart)
- Kesin alan eşleşmesi (İBYS 2.0 REST v2 resmî alan dokümanı olmadan)
- (Gerekliyse) e-imza testi (entegratör ortamı olmadan)

**Onaydan BAĞIMSIZ, şimdi yapılabilecekler:**
- Bildirim kuyruğu altyapısı (hangi kayıt gönderilecek)
- Referans değer eşleştirme altyapısı
- İşyeri (SGK sicil) doğrulama kontrolü
- İBYS Bildirim Merkezi paneli
- Gönderim/lojik iskeleti (servis adresi sonradan bağlanacak)

---

## 2. Hedef mimari (6 katman)

1. **Toplama katmanı** — mevcut modüllerden bildirime uygun kayıtları toplar
2. **Eşleştirme katmanı** — bizim değerler ↔ İBYS referans kodları
3. **Kuyruk katmanı** — "gönderilecek → gönderildi → hata → tekrar dene"
4. **İmza katmanı** — merkezi e-imza servisi bağlantısı
5. **Gönderim katmanı** — İBYS web servis istemcisi (Edge Function)
6. **Panel katmanı** — İBYS Bildirim Merkezi (kullanıcı ekranı)

---

## 3. Veri modeli (yeni tablolar — öneri)

| Tablo | Görevi |
|---|---|
| `ibys_isyeri_bildirimleri` | Firma (SGK sicil no) hangi işyeri için bildirilmiş, durumu |
| `ibys_referans_eslesmeleri` | İBYS kod listesi ↔ bizim değer (eğitim/muayene/tetkik/NACE...) |
| `ibys_bildirim_kuyrugu` | Gönderilecek kayıt + tür + durum + hata + deneme sayısı |
| `ibys_bildirim_loglari` | Her gönderim denemesinin audit kaydı (kim, ne, sonuç) |

---

## 4. Kullanıcı arayüzü: "İBYS Bildirim Merkezi"

- **İşyeri Durumu:** firmaların SGK sicil no ile bildirilme durumu (✅/⏳)
- **Bildirim Kuyruğu:** tür bazlı liste + durum filtresi + "tekrar dene"
- **Referans Eşleştirme:** İBYS kodları ile bizim değerleri eşleştirme ekranı
- **Sonuçlar / Hatalar:** gönderim sonuçları, hata detayı, rapor

---

## 5. Faz planı

| Faz | İçerik | Onaya bağlı mı? |
|---|---|---|
| Faz 0 | Kapsam + mimari netleştirme (bu doküman) | ❌ Bağımsız |
| Faz 1 | **İç hazırlık**: kuyruk, eşleştirme, işyeri kontrolü, panel iskeleti | ❌ Bağımsız |
| Faz 2 | **İskelet**: web servis istemcisi + e-imza yer tutucu hattı | ❌ Bağımsız (boş iskelet) |
| Faz 2b | Onay sonrası: REST v2 kimlik bilgileri + alan eşlemesi GERÇEK bağlantı + test | ✅ Bağlı |
| Faz 3 | Pilot: Eğitim bildirimi uçtan uca (test ortamı) | ✅ Bağlı |
| Faz 4 | Canlıya geçiş + kapsam genişletme (Muayene, Tetkik, Risk, Kaza, KKD) | ✅ Bağlı |
| Faz 5 | Bildirim paneli tam sürüm + raporlama | ✅ Bağlı |

**Durum: Faz 1 ✅ tamamlandı · Faz 2 ✅ iskelet kuruldu (onay bekliyor).**

---

## 5b. Faz 2 — Gönderim İskeleti (kuruldu)

Onay gelmeden kurulan REST v2 gönderim altyapısı. Kimlik bilgileri + resmî
alan eşlemesi geldiğinde yalnızca birkaç nokta doldurulacak; kuyruk/log/kapsam
mantığı hazırdır.

- **Edge Function `ibys-gonderim`** — REST v2 gönderim hattı:
  - `mode: durum` → entegrasyon yapılandırma DURUMU (protokol, kimlik, yurt içi IP; yalnızca boolean; sır değeri dönmez)
  - `mode: gonder` → tek kuyruk kaydı için gönderim hattı
  - REST v2 hattı: `hizmetVerilenIsyeriBildir` (ön koşul) → `buildEnvelope` (body) → `signEnvelope` (opsiyonel e-imza) → `postRest` (Basic Auth ile gönderim)
  - Metot eşlemesi: `egitim` → `egitimBilgisiBildir`; diğer türler resmî doküman gelince (metot doğrulanmadıysa dürüst hata döner)
  - Yapılandırma yoksa **kuyruk durumu DEĞİŞMEZ**; yalnızca "onay bekliyor" audit logu yazılır
  - Güvenlik: JWT zorunlu (admin/osgb_admin), sunucu tarafı OSGB kapsamı (CROSS_OSGB → 403)
- **Frontend servis `src/lib/ibys/gonderim.ts`** — durum okuma + gönderim çağrısı
- **Panel sekmesi "Entegrasyon"** — web servis istemcisi + e-imza durumu, gönderim hattı adımları
- **Kuyrukta "Gönder" aksiyonu** — hat devrede değilken dürüst "onay bekleniyor" geri bildirimi verir

### Onay sonrası doldurulacak env (Edge Function Secret)
| Anahtar | İçerik |
|---|---|
| `IBYS_FIRMA_KODU` | Bakanlık firma kodu |
| `IBYS_FIRMA_SIFRE` | Servis şifresi |
| `IBYS_SERVIS_URL` | REST v2 taban adresi (metot adı buna eklenir) |
| `IBYS_EIMZA_URL` | Merkezi e-imza servis adresi (opsiyonel) |
| `IBYS_ORTAM` | `test` / `prod` |
| `IBYS_ENTEGRASYON_AKTIF` | (opsiyonel) açma anahtarı; DB `system_settings.ibys_entegrasyon_aktif` de kullanılabilir |

---

## 6. Bağımlılıklar / açık noktalar

- Bakanlık onayının zamanı (Faz 2+'ı tetikler)
- HHS / e-imza entegratörü ile sözleşme ve yetkilendirme
- İBYS 2.0 resmî alan/metot dokümanı (onaydan sonra gelir)
- Tek entegratör kuralı: mevcut firmalar başka yazılımda bildirilmişse çakışma

---

## 7. Bildirim türü ↔ kaynak tablo eşleşmesi

| İBYS Bildirimi | Kaynak (tablo) |
|---|---|
| Eğitim ✅ API var | `personel_egitimleri` + `egitim_turleri` |
| Sağlık Muayenesi ✅ API var | `personel_saglik_muayeneleri` |
| Tetkik / Tahlil ⛔ API yok (muayene içinde gider) | `personel_tetkikler` |
| Risk Değerlendirmesi ⛔ API yok | `risk_degerlendirmeleri` |
| İş Kazası / Ramak Kala ⛔ API yok | Tutanak modülü |
| KKD Zimmet ⛔ API yok | `zimmetler` |
| Hizmet Verilen İşyeri ✅ API var (ön koşul) | `firmalar` (sgk_detsis_no / sicil_no) |

---

> NOT: İBYS 2.0 protokolü **REST API v2**'dir (SOAP/WSDL değil). Kesin alan/şema
> detayları, Bakanlığın entegratör onayı sonrası verilecek resmî alan dokümanıyla
> birebir doğrulanacaktır. Gönderim hattı (Edge Function) REST v2 + Basic Auth
> üzerine kurulmuştur; onay gelince yalnızca kimlik bilgileri ve alan eşlemesi dolar.