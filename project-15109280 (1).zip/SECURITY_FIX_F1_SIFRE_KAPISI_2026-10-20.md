# F1 — Şifre değişiminde yeniden doğrulama · Uygulama ve Kapanış Runbook'u

Tarih: 2026-10-20
Kapsam: PENTEST F1 (CWE-620 / CWE-602) — oturum belirteci ele geçirildiğinde şifre değiştirme
Durum: Kod ve migration hazır · **canlıda uygulandı** (Adım 1-3 tamam, mod: `log`) · `enforce` için Adım 4-5 bekliyor

---

## 1. Açık neydi (tek cümle)

`GOTRUE_SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION=true` yalnızca **24 saatten eski**
oturumlarda reauth zorluyor. 24 saatten yeni bir oturum belirteciyle `PUT /auth/v1/user`
gövdesinde `password` gönderen biri, uygulamanın e-posta kodlu akışını hiç açmadan şifreyi
değiştirebiliyordu.

Bizim akış (mevcut şifre → 6 haneli e-posta kodu → atomik RPC → şifre geçmişi → diğer
oturumların iptali) sağlamdı; sorun **ikinci kapının açık kalmasıydı**.

## 2. Çözüm: veritabanı kapısı (GUV-44)

`auth.users.encrypted_password` üzerine `BEFORE UPDATE` trigger'ı kondu. Şifre yazımı
yalnızca şu iki durumda geçer:

1. **Operatör yolu** — `session_user IN ('postgres','supabase_admin')`
   (psql, migration, kilitlenme kurtarması)
2. **Tek kullanımlık izin varsa** — `public.sifre_degisim_izinleri` içinde tüketilmemiş,
   süresi geçmemiş bir satır. Yazım anında tüketilir.

İzni **yalnızca** şu doğrulanmış yollar üretir:

| Kaynak | Nerede üretilir | Ne kanıtlar |
|---|---|---|
| `kod` | `sifre_kodu_ile_degistir` (kod doğrulandıktan sonra) | E-posta kutusu + mevcut şifre |
| `sifirlama` | `sifre_sifirlama_ile_degistir` (Edge Function, recovery oturumu) | E-posta bağlantısı sahipliği |
| `admin` | `accept-invite` (davet token'ı doğrulandıktan sonra) | Davet token'ı sahipliği |

### Neden `current_user` değil `session_user`

`sifre_guncelle_atomik` **security definer** bir fonksiyondur; içeride `current_user`
`postgres` olur. `current_user` ile kontrol edilseydi kendi RPC'miz kapıyı herkese açardı.
`session_user` gerçek bağlantı kimliğidir ve definer tarafından değiştirilemez:

- PostgREST → `authenticator`
- GoTrue → `supabase_auth_admin`
- psql → `postgres`

### Mod anahtarı kimseye verilmez

`sifre_kapisi_ayar` tablosunda `service_role` yalnızca **SELECT** yetkisine sahiptir.
Ele geçirilmiş bir service key kapıyı kapatamaz; mod yalnızca sunucuda `psql` ile değişir.

## 3. Dosyalar

| Dosya | İş |
|---|---|
| `supabase/migrations/20260101003200_guv44_sifre_degisim_kapisi.sql` | tablolar + trigger + izin RPC'leri + kod akışının izin üretmesi |
| `supabase/migrations/rollback/20260101003200_..._rollback.sql` | geri alma |
| `supabase/tests/security/guv44_sifre_degisim_kapisi.test.sql` | pgTAP yapısal test (10 iddia) |
| `deploy/scripts/34_f1_sifre_kapisi_deploy.sh` | kurulum · doğrulama · davranış testi · mod geçişi |
| `deploy/edge-functions/sifre-dogrulama/index.ts` | `sifirla-degistir` aksiyonu (recovery oturumu doğrulaması) |
| `src/lib/sifreDogrulama.ts` | `sifreSifirlamaIleDegistir()` |
| `src/pages/sifre-sifirla/page.tsx` | sıfırlama artık sunucu kapısından geçiyor |
| `supabase/functions/accept-invite/index.ts` | davet kabulünde tek kullanımlık izin |
| `deploy/scripts/25_pentest_hesap_sifre_yenile.sh` | admin API ile şifre sabitlerken izin |

## 4. Kademeli açma — sıra bozulmaz

### Adım 0 · Yedek

```bash
docker exec -T supabase-db pg_dump -U postgres -d postgres -Fc > /root/isg-yedek/pre_guv44_$(date +%Y%m%d_%H%M%S).dump
```

### Adım 1 · Migration'ı uygula (mod: `log`, hiçbir şeyi engellemez)

```bash
bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh
```

Beklenen: `trigger: kurulu · mod: log`

### Adım 2 · Uygulamayı yayınla

- `sifre-dogrulama` Edge Function'ını yeniden deploy et (`sifirla-degistir` aksiyonu için)
- Arayüzü yayınla (şifre sıfırlama sayfası)

Yayınlamadan **enforce'a geçilmez**: sıfırlama akışı GoTrue recovery oturumu kullanıyor,
yeni kod yayında değilse "şifremi unuttum" kırılır.

```bash
# fonksiyon kaynağı sunucuya gönderildikten sonra (tek dosya):
scp -P 23422 "deploy/edge-functions/sifre-dogrulama/index.ts" root@SUNUCU:/tmp/sifre-dogrulama-index.ts

# sunucuda:
bash /opt/ibys/deploy/scripts/35_sifre_dogrulama_yayin_ve_kapat.sh
```

Bu betik sırayla şunları yapar ve **hepsi kanıt üretir**:

1. Kaynağın `sifirla-degistir` aksiyonunu içerdiğini doğrular (eski dosya gönderilirse durur).
2. Mevcut fonksiyonu `/root/isg-yedek/` altına yedekler, yenisini `volumes/functions/sifre-dogrulama/index.ts` konumuna kurar, `functions` servisini yeniden başlatır.
3. **Canlılık:** `OPTIONS /functions/v1/sifre-dogrulama` → 200, tokansız `POST` → 401 `SESSION_EXPIRED` (404 = fonksiyon yüklenmemiş).
4. **Uçtan uca sıfırlama testi (posta göndermeden):**
   `admin/generate_link(recovery)` → `/auth/v1/verify(recovery)` → JWT `amr` içinde
   `recovery` **veya** `otp` var mı → fonksiyon `sifirla-degistir` →
   **yeni şifreyle `grant_type=password` girişi 200**.
5. **Negatif test (F1 bekçisi):** aynı kullanıcıyla normal parola girişi yapılır, alınan
   token ile `sifirla-degistir` çağrılır ve `FORBIDDEN` beklenir. Bu adım, `otp` kabul
   edilirken kapının gevşemediğini kanıtlar.
   Test kullanıcısı ve izin kayıtları sonunda temizlenir.

Beklenen satırlar:

```
==> OPTIONS 200 (CORS ön kontrolü tamam)
==> tokansız istek → 401 SESSION_EXPIRED (fonksiyon yayında)
  · JWT amr: [{"method":"otp","timestamp":1792472022}]
  · negatif test: parola oturumu REDDEDİLDİ (F1 kapalı)
  · fonksiyon yanıtı: {"ok":true,...}
==> UÇTAN UCA TEST: PASS — recovery oturumu + sifirla-degistir + yeni şifreyle giriş
```

#### `amr` etiketi ve GoTrue sürüm farkı (2026-10-20'de canlıda yakalandı)

Self-host GoTrue'nun bu sürümü, `/auth/v1/verify?type=recovery` ile kurulan oturumu
`amr` içinde `recovery` olarak değil **`otp`** olarak etiketliyor:

```
JWT amr: [{"method":"otp","timestamp":1792472022}]
```

İlk sürüm yalnızca `recovery` kabul ettiği için gerçek "şifremi unuttum" oturumu da
`FORBIDDEN` alıyordu. Bu, enforce'a geçilseydi kullanıcıların şifresini sıfırlamasını
kıracaktı; deploy provası bunu üretim öncesi yakaladı.

Düzeltme (`deploy/edge-functions/sifre-dogrulama/index.ts` · `isRecoverySession`):

- Kabul edilen yöntemler: **`recovery` veya `otp`**. İkisi de e-posta sahipliğini kanıtlar
  (biri sıfırlama bağlantısı, diğeri aynı bağlantının GoTrue'daki etiketi / magic-link).
- **`password` etiketi asla kabul edilmez** — F1'in kapalı kalması buna bağlıdır.
- Bunun gevşeme olmadığını kanıtlamak için betiğe **negatif test** eklendi: test
  kullanıcısıyla normal parola girişi yapılır, alınan token ile `sifirla-degistir`
  çağrılır ve `FORBIDDEN` beklenir. Beklenmezse betik `FAIL` verir.

Kapanış kriteri: `negatif test REDDEDİLDİ` satırı **ve** `UÇTAN UCA TEST: PASS` satırı
aynı çıktıda görünmeli. Biri eksikse enforce'a geçilmez.

#### Adım 2 · Kayıtlı sonuç (2026-10-20, self-host sunucu)

İlk deploy turu (`35_...sh`, sürüm `-a`):

```
==> konteynerler : db=supabase-db  auth=supabase-auth  functions=supabase-edge-functions
==> GoTrue DB kullanıcısı: supabase_auth_admin
==> kaynak doğrulandı: 609 satır, 'sifirla-degistir' mevcut
==> kuruldu: .../volumes/functions/sifre-dogrulama/index.ts
==> OPTIONS 200  ·  tokansız istek → 401 SESSION_EXPIRED
==> mod korunuyor: log
     · JWT amr: [{"method":"otp","timestamp":1792472022}]
!! JWT'de amr=recovery YOK → uçtan uca test BAŞARISIZ (mod hâlâ log)
```

Sonuç: **fonksiyon yayında ve sağlıklı**, tek eksik `amr` etiket uyumu. Düzeltme
(sürüm `-b`) sonrası aynı betik yeniden koşuldu.

#### Adım 2 · Kayıtlı sonuç — düzeltme sonrası (2026-10-20, self-host sunucu)

İkinci deploy turu (`35_...sh`, sürüm `guv44-release-2026-10-21-b`):

```
==> GoTrue DB kullanıcısı: supabase_auth_admin
==> kaynak doğrulandı: 625 satır, 'sifirla-degistir' mevcut
==> kuruldu: .../volumes/functions/sifre-dogrulama/index.ts
==> OPTIONS 200  ·  tokansız istek → 401 SESSION_EXPIRED
==> mod korunuyor: log
     · negatif test: parola oturumu REDDEDİLDİ (F1 kapalı)
     · JWT amr: [{"method":"otp","timestamp":1792472312}]
     · fonksiyon yanıtı: {"ok":true,"otherSessionsRevoked":true,"notificationSent":true}
==> UÇTAN UCA TEST: PASS — recovery oturumu + sifirla-degistir + yeni şifreyle giriş
```

Bu koşuda `amr` yine `otp` olarak geldi (GoTrue sürümü böyle etiketliyor) ve fonksiyon
bunu kabul etti; **aynı çıktıda** negatif testin REDDEDİLDİ satırı da var. Yani hem
"şifremi unuttum" çalışıyor hem de taze parola oturumu kapıdan geçemiyor.

Kapanış kriterinin ikisi de sağlandı. Sıradaki adım: 24-48 saat `log` gözlemi.
Not: `GoTrue DB kullanıcısı: supabase_auth_admin` satırı enforce için ön koşuldur ve
sağlanmıştır.

### Adım 3 · Davranış kanıtı

```bash
bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh --test
```

Beklenen dört satır:

```
[1] izinsiz yazim      REDDEDILDI (PASSWORD_REAUTH_REQUIRED)
[2] izinli yazim        GECTI (UPDATE 1)
[3] izin tuketildi      EVET (consumed_at dolu)
[4] ikinci yazim        REDDEDILDI (tek kullanimlik)
```

`--test` sonda rolüyle (`guv44_probe`) GoTrue'nun kimliğini taklit eder, çünkü `postgres`
ile bağlanan psql kapıyı doğal olarak atlar. Test sonunda geçici kullanıcı silinir.

#### Adım 3 · Kayıtlı sonuç (2026-10-20, self-host sunucu)

```
==> mod (once): log
==> trigger (auth.users): 1
==> test kullanici: 2f13eca3-f64b-453c-9177-a221948f2411
==> sonda yetkileri: select/update auth.users = evet
==> burunme kontrolu: session_user = guv44_probe (tamam)
==> mod: enforce (test suresince)
  [1] izinsiz yazim      REDDEDILDI (PASSWORD_REAUTH_REQUIRED)
  [2] izinli yazim        GECTI (UPDATE 1)
  [3] izin tuketildi      EVET (consumed_at dolu)
  [4] ikinci yazim        REDDEDILDI (tek kullanimlik)
  [5] ihlal kaydi         0 satir

RESULT A=1 B=1 C=1 D=1  -> PASS
```

Notlar:

- `[5] 0 satir` beklenen sonuçtur: `enforce` modunda `RAISE` aynı transaction'ı geri aldığı
  için ihlal satırı da geri alınır. Enforce dönemi izleri sunucu logundadır (`GUV44_`).
- Probe bağlantısı süperuser gerektirmeyecek şekilde kuruldu: sonda rolü
  `LOGIN + BYPASSRLS` olarak oluşturulup **doğrudan o rolle** bağlanılır, `SET SESSION
  AUTHORIZATION` kullanılmaz (`postgres` bu imajda süperuser değil).
- Mod geri alma adımı artık **doğrulanıyor**: `restore_mod` yazımdan sonra modu tekrar
  okuyup eşleşmezse 3 kez dener ve başarısızsa yüksek sesle uyarı basar.
  Elle düzeltme gerekirse:
  `docker exec -i supabase-db psql -U postgres -d postgres -c "update public.sifre_kapisi_ayar set mod=chr(108)||chr(111)||chr(103) where id;"`

### Adım 4 · 24-48 saat gözlem

```bash
bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh --dogrula
```

Bakılacak: `toplam_ihlal` ve `son_24_saat`. Bu sayaç `log` modunda **her** izinsiz şifre
yazımını kaydeder. Meşru akışlar izin ürettiği için buraya düşmez.

> `enforce` modunda sayaç artmaz (yukarıdaki transaction notu). Enforce sonrası
> izleme için: `docker logs supabase-db 2>&1 | grep -c GUV44_`

Beklenen: ya `0`, ya da açıklanabilir birkaç satır (ör. 09/11 numaralı eski kanıt
betiklerinin admin API ile şifre sabitlemesi). Açıklanamayan satır varsa **enforce'a geçme**,
önce o kullanıcıyı incele:

```sql
select * from public.sifre_kapisi_ihlalleri order by olusma desc limit 20;
```

### Adım 5 · Kapıyı kapat

```bash
bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh --enforce
```

Betik önce GoTrue'nun DB kullanıcısını okur. `postgres` veya `supabase_admin` çıkarsa
**enforce'u reddeder** — o durumda kapı GoTrue'yu atlar, yani koruma sahte olur.

**Kapatma provası (önerilen yol):** aynı işi yapan ama kapatmayı *kanıtla* birleştiren sürüm:

```bash
bash /opt/ibys/deploy/scripts/35_sifre_dogrulama_yayin_ve_kapat.sh --enforce
```

Bu betik: GoTrue DB kullanıcısını doğrular → `mod='enforce'` yapar → **uçtan uca sıfırlama
testini enforce altında tekrar koşar**. Test geçerse kapı kapalı kalır; geçmezse otomatik
olarak `log` moduna döner ve hata verir. Yani "kapıyı kapattım, sıfırlama kırıldı" durumu
imkânsız hale gelir.

Beklenen kapanış çıktısı:

```
==> mod → enforce (şifre yazımı artık izinsiz REDDEDİLİR)
==> UÇTAN UCA TEST: PASS — recovery oturumu + sifirla-degistir + yeni şifreyle giriş
==> KAPI KAPALI (enforce) ve sıfırlama yolu ÇALIŞIYOR.
```

### Adım 6 · Son kanıt

```bash
bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh --dogrula
```

Beklenen: `KAPI KAPALI (enforce)`.

### Adım 7 · Gerçek saldırgan senaryosu (retest)

1. Bir test hesabıyla normal giriş yap → `access_token` al (< 24 saatlik, taze oturum)
2. Doğrudan GoTrue'ya şifre güncelleme gönder:

```bash
curl -sS -X PUT "$API/auth/v1/user" \
  -H "apikey: $ANON" -H "Authorization: Bearer $TOKEN" \
  -H 'Content-Type: application/json' \
  -d '{"password":"Saldirgan.2026.Aa1"}'
```

**Beklenen (üç ayrı kanal):**

1. HTTP yanıtı 4xx/5xx döner (GoTrue DB hatasını 500 olarak sarmalar).
2. **Asıl kanıt:** eski şifre **hâlâ çalışır**, yeni şifreyle giriş başarısız olur.
   `curl -X POST "$API/auth/v1/token?grant_type=password" ...` ile doğrula.
3. Postgres logunda kayıt:

```bash
docker logs supabase-db 2>&1 | grep GUV44_ | tail -5
# GUV44_IZINSIZ_SIFRE_YAZIMI user=<uuid> mod=enforce oturum=supabase_auth_admin
```

> **Neden tabloya satır düşmüyor:** enforce modunda `RAISE` aynı transaction'ı geri
> aldığı için ihlal satırı da geri alınır (Postgres'te otonom transaction yoktur).
> Tablo kaydı, `log` modundaki gözlem penceresinin kanıt kaynağıdır; enforce dönemi
> izleri sunucu logundadır. Bu davranış bilerek seçilmiştir ve raporda böyle anlatılmalıdır.

**Kapanış kriteri:** istek başarısız **ve** eski şifre çalışmaya devam ediyor **ve**
uygulamanın kodlu akışı bozulmamış.

## 5. Geri dönüş

```bash
bash deploy/scripts/34_f1_sifre_kapisi_deploy.sh --log     # anında, veri kaybı yok
```

Tam kaldırma (nadiren gerekir):

```bash
docker exec -i supabase-db psql -U postgres -d postgres \
  -f supabase/migrations/rollback/20260101003200_guv44_sifre_degisim_kapisi_rollback.sql
```

Rollback sonrası kod akışı kullanılacaksa GUV-42 migration'ını yeniden uygula
(`sifre_kodu_ile_degistir` eski sürüme döner).

## 6. Riskler ve azaltmalar

| Risk | Azaltma |
|---|---|
| Kullanıcı şifresini hiç değiştiremez | `psql` (postgres) her zaman geçer; `--log` tek komutla geri dönüş |
| "Şifremi unuttum" kırılır | Adım 2 yayınlanmadan enforce yok; Edge Function erişilemezse sayfa eski yola düşer |
| GoTrue recovery oturumunu `otp` etiketlerse sıfırlama reddedilir | Fonksiyon `recovery` **ve** `otp` kabul eder; deploy betiği ikisini de tanır ve her koşuda uçtan uca test eder |
| Davet kabulü kırılır | `accept-invite` kabul öncesi izin üretir; RPC yoksa sessizce atlar (migration öncesi) |
| GoTrue `postgres` ile bağlanıyorsa kapı sahte | `--enforce` bunu tespit edip reddeder |
| Ele geçirilmiş service key kapıyı açar | Mod tablosunda service_role yalnızca SELECT |
| Test/kanıt betikleri (09, 11) enforce'ta kırılır | Bu betikler yalnızca kanıt amaçlıdır; enforce öncesi çalıştır veya `--log` modunda koş |

## 7. Denetçiye verilecek metin

> **F1 — Giderildi.** Şifre yazımı uygulama katmanından bağımsız olarak veritabanı
> seviyesinde kapıya alınmıştır: `auth.users.encrypted_password` üzerindeki
> `BEFORE UPDATE` trigger'ı, kısa ömürlü ve tek kullanımlık bir yeniden doğrulama izni
> yoksa güncellemeyi reddeder. İzin yalnızca (a) e-posta kodunun doğrulanması,
> (b) şifre sıfırlama bağlantısının kurduğu recovery oturumu veya (c) doğrulanmış davet
> token'ı üzerinden, sunucu tarafında üretilir. Bu nedenle 24 saatten yeni bir oturum
> belirteciyle `PUT /auth/v1/user` çağrısı yapmak da şifreyi değiştirmez; deneme
> `PASSWORD_REAUTH_REQUIRED` ile reddedilir ve `sifre_kapisi_ihlalleri` tablosuna kaydedilir.
> Kapı, `sifre_kapisi_ayar` tablosundaki mod ile kademeli açılmıştır (önce `log`,
> gözlem sonrası `enforce`); mod değiştirme yetkisi uygulama rollerine verilmemiştir,
> yalnızca sunucu operatöründedir.

## 8. Kalan dürüstlük notu

- Bu kontrol **şifre** yazımını kapatır. Ele geçirilmiş token ile yapılabilecek diğer
  işlemler (profil okuma, evrak indirme) ayrı bulguların kapsamındadır ve RLS ile sınırlıdır.
- `log` modunda rapor "kısmen" olarak kalmalıdır; "giderildi" ifadesi `--enforce` ve
  Adım 7 kanıtı alındıktan sonra kullanılmalıdır.