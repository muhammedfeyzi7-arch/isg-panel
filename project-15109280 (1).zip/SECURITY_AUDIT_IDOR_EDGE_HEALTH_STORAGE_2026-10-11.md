# Güvenlik Denetimi — IDOR / Edge Functions / Hassas Sağlık Verisi / Storage
**Proje:** OSGB SaaS (PRO İSGDenetim) · **Tarih:** 2026-10-11 · **Backend:** SaaS Supabase
**Kapsam:** (1) IDOR & Broken Access Control, (2) Edge Functions + RPC envanteri, (3) Hassas sağlık verisi koruması (KVKK), (4) Supabase Storage denetimi.

> ⚠️ **Yöntem ve sınırlar**
> - **Kod değiştirilmedi, gerçek kullanıcı/veri üzerinde yıkıcı test yapılmadı.**
> - Bu oturumda **izole iki-OSGB test ortamı yok**. Bu nedenle davranışsal (çalıştırarak) IDOR testi **yapılamadı**.
> - Kanıtlar iki kümede ayrılır: **[KOD]** = kaynak okuma, **[AKTİF-OKUMA]** = canlı DB'den salt-okuma metadata (pg_policies / pg_proc / storage.buckets). Her ikisi de **doğrulama** sayılır; "çalıştırarak exploit" ayrı ve yapılmadı.
> - Doğrulanamayan alanlar "**Doğrulanamadı**" olarak işaretlendi; kesin bulgu olarak sunulmadı.
> - Rapora **hiçbir gerçek sağlık verisi / TC kimlik içeriği kopyalanmadı** (yalnızca şema/kolon adı ve politika ifadeleri).

---

## 0. Yönetici Özeti

Kod tarafı, IDOR/erişim kontrolü açısından **olgun ve tutarlı** bir desen kullanıyor: çağıran kimlik Edge Function içinde `auth.getUser(jwt)` ile doğrulanıyor, tenant kimliği (osgb_id/firma_id) **istemciden değil `profiles`'tan** türetiliyor, kaynak ID'leri (firma/personel/evrak/zimmet...) için **sahiplik/tenant yeniden doğrulanıyor**. Sağlık verisi RLS ile firma/uzman rollerinden **tamamen kapatılmış**, tıbbi detay yalnızca KVKK-güvenli bir RPC ile (durum + tarihler) dönüyor. Storage bucket'ları çoğunlukla private ve client'tan erişilemez durumda.

**Bu oturumda doğrulanmış, sömürülebilir kritik bir açık bulunmadı.** Kalan maddeler çoğunlukla savunma derinliği sertleştirmesi, bilgi ifşası (enumeration) ve doğrulanması gereken yapılandırma noktalarıdır.

---

## 1. IDOR ve Broken Access Control (firma, çalışan/personel, atama, evrak)

### 1.1 Doğrulanan güvenli desenler [KOD]

Tüm kritik Edge Function'lar aynı üç katmanlı kapıyı uyguluyor:

1. **JWT doğrulama:** anon-key istemcisiyle `client.auth.getUser(jwt)`; hata/geçersizde `401`. Örn. `evrak/index.ts`, `envanter/index.ts`, `zimmet/index.ts`, `ekipman/index.ts`, `saha-denetim/index.ts`, `tutanak/index.ts`, `operasyon/index.ts`, `firma-davet/index.ts` — **hepsinde ortak**.
2. **Tenant kimliği istemciden alınmıyor:** `caller = profiles.select('role, osgb_id, firma_id')`. `osgb_admin` için `osgb_id = caller.osgb_id` (client `osgbId` **yok sayılır**). Yalnızca `admin` için client `osgbId`'si dikkate alınır (`firma-davet`, `personel-hesap`).
3. **Kaynak sahipliği yeniden doğrulanıyor:**
   - `firma-davet` / `firma-sozlesme` / `firma-yukumluluk` / `operasyon` / `saha-denetim` / `evrak`: hedef kaydın `osgb_id`/`firma_id` değeri çağıranın kapsamıyla karşılaştırılır → `CROSS_OSGB` / `CROSS_FIRMA`.
   - `zimmet`: `assertZimmetAccess` → personel kaydı `record.personel_id === callerPersonelId` kontrolü (kendi zimmeti dışındakine erişim yok).
   - `operasyon`: `assertEntityAccess` → personel yalnızca içinde bulunduğu **açık** zimmet dönemine ait kayıtları görür.
   - `ekipman`: `assertEkipmanAccess` → `osgb_admin` kendi OSGB, `uzman` yalnızca **aktif atamalı** firması (`has_active_uzman_assignment`), `firma` kendi firması.
   - `evrak`: `assertEvrakAccess` + rol bazlı ek kapılar (`helper` saha personeli evrak oluşturamaz → `HELPER_EVRAK_FORBIDDEN`); uzman silme için `has_active_primary_assignment` zorunlu.
   - `ziyaret-planlama`: `authorizeOccurrenceOperation` → saha start/finish yalnızca **ilgili personelin kendisi** (`occ.personel_id === callerPersonelId`), OSGB kapsamı + aktif atama + tarih penceresi.

**Sonuç:** Kod incelemesinde, kaynak ID'sini (firma_id/personel_id/evrak_id/zimmet_id/atama_id) değiştirerek başka kiracıya ait kayda erişilebildiği bir akış **bulunmadı**. Kimlik hiçbir yerde istemci beyanından alınmıyor.

### 1.2 Üç kademeli `resolveCaller` (savunma amaçlı, olumlu) [KOD]
`envanter`, `ziyaret-planlama`, `gereksinim-hesapla`, `firma-sozlesme` içinde `resolveCaller` service-role → e-posta → RLS self-read sırasıyla profili çözer. Bu, yanlış 403'ü önler; **yetki yine `profiles.role`'dan** okunur, ID uydurulmaz. Olumlu bir sertleştirme.

### 1.3 Dikkat çeken noktalar (genellikle Düşük; kesin açık değil)

| # | Bulgu | Kanıt | Risk | Yorum |
|---|-------|-------|------|-------|
| IDOR-1 | **Kiracı-dışı kaynak varlığının ifşası (enumeration).** Hata kodları ayrıştırılıyor: `FIRMA_NOT_FOUND` (404) vs `CROSS_OSGB` (403). | [KOD] `evrak` `handleUpload`, `firma-davet`, `firma-sozlesme` | Düşük-Orta | Saldırgan "bu UUID başka OSGB'de var mı" çıkarımı yapabilir. Veri gövdesi sızmaz; yalnızca **varlık** ifşası. |
| IDOR-2 | **Kendi firma çalışanının TC kimlik no'su liste yanıtında dönüyor.** | [KOD] `firmaPersonelService.ts` `LIST_COLS` → `tc_kimlik_no` | Bilgi / KVKK | Kiracı-içi (kendi firması). Ama liste/kart görünümünde tam TC gösterimi "fazla veri gösterimi" ilkesiyle tartışmalı → maskelenebilir. |
| IDOR-3 | **Fazla log detayı (PII).** Bazı `system_logs.metadata` kayıtları `{ email }`, `{ reason }` taşır. | [KOD] `firma-davet` `FIRMA_EMAIL_CHANGED` metadata `{ email }` | Düşük | Log erişimi admin/OSGB ile sınırlı (RLS); yine de PII içerir. |
| IDOR-4 | **Edge Function CORS `*`.** 43+ fonksiyonda wildcard. | [KOD] tüm `supabase/functions/*/index.ts` | Düşük (savunma derinliği) | JWT sunucuda doğrulandığı için doğrudan exploit yok; wildcard sertleştirilmeli. |

> **Not:** IDOR-1/2 "kesin sömürülebilir açık" değildir; sertleştirme/azaltma önerileridir.

### 1.4 Çalıştırarak (aktif) IDOR testi — **Doğrulanamadı**
İzole iki-OSGB test ortamı bulunmadığından, politika davranışı **statik + metadata** ile değerlendirildi. Runtime kanıt üretilmedi.

---

## 2. Edge Functions ve RPC Envanteri

### 2.1 Envanter [KOD] + [AKTİF-OKUMA]
- **Edge Functions:** 47 adet `supabase/functions/<slug>/index.ts` (davet/hesap: `osgb-davet`, `accept-invite`, `firma-davet`, `personel-hesap`; belge/operasyon: `evrak`, `evrak-klasor`, `envanter`, `zimmet`, `ekipman`, `operasyon`, `saha-denetim`, `tutanak`, `ziyaret-planlama`, `firma-sozlesme`, `firma-yukumluluk`, `toplu-evrak`, `mail`, `isg-katip-sync`, `gereksinim-hesapla`, `nace-import`, `osgb-delete-permanent`, `tani-bilgi` (devre dışı), `send-reset-email`, `auth-log` vb.).
- **SECURITY DEFINER fonksiyonlar:** [AKTİF-OKUMA] `public` şemasında **167** adet SECURITY DEFINER fonksiyon; bunlardan **77**'sinde `anon` EXECUTE yetkisi görünüyor.

> ⚠️ Bu **77** sayısı, önceki remediasyon turlarında ("159 → 22") bildirilen değerden yüksek. `has_function_privilege('anon', ...)` PUBLIC'e varsayılan verilmiş EXECUTE'ları da içerebilir. **Bu bir çelişki/doğrulama noktasıdır — kesin açık olarak sunulmaz.** Yeniden doğrulama gerekir (bkz. §2.4).

### 2.2 Ortak güvenlik kontrolleri (doğrulandı) [KOD]
- **JWT doğrulaması:** hepsinde `401` kapısı.
- **Rol kontrolü:** `profiles.role` allowlist (`['admin','osgb_admin','uzman','hekim','firma']` vb.).
- **Kaynak sahipliği / tenant izolasyonu:** bkz. §1.1.
- **Parametre doğrulama:** MIME allowlist, boyut üst sınırı (`MAX_*_SIZE`), UUID format (`UUID_RE`), `sanitizeTerm` (PostgREST `.or()` injection temizliği), sayı/tarih/ara değer kontrolü.
- **Hata yönetimi:** merkezi `edgeErrorResponse` — SQLSTATE (`23505`) → sabit mesaj; **ham DB mesajı kullanıcıya sızmaz**; 5xx'ler `console.error`'a yazılır. İstemci tarafında `errorMessages.ts` `humanizeTechError` teknik metni ekrana basmaz, `fid=`/`db=` token'larını yakalar.

### 2.3 SECURITY DEFINER / service_role / dinamik SQL
- **service_role kullanımı:** tüm Edge Function'larda `admin` (service-role) istemcisi **yalnızca JWT doğrulaması + profil/tenant çözümlemesinden sonra** kullanılıyor. Yetki kapısından önce service-role çağrısı **görülmedi**.
- **`osgb-delete-permanent`:** en hassas akış. `admin` rolü + `confirmName` birebir eşleşme + RPC `delete_osgb_permanent` (yetki RPC içinde tekrar doğrulanır). Storage temizliği service-role ile ama **rol doğrulamasından sonra**.
- **`isg-katip-sync`:** `PILOT_ONLY` guard, tek firma kapsamı, atomik pilot RPC (`isg_katip_apply_pilot`), "CONTRACT_ACTIVITY = ACTIVE" savunma katmanı, yapısal bloklayıcı gate (kısmi state yok). Hata çıktısı sanitize edilir.
- **Dinamik SQL:** Edge Function'larda `sql` string birleştirme **görülmedi**. Sorgular PostgREST builder/RPC ile parametrik. DB tarafındaki definer fonksiyonlarda `search_path` sabit (`SET search_path TO 'public'`) — örn. [AKTİF-OKUMA] `personel_saglik_ozet` `proconfig = {search_path=public}`.

### 2.4 Doğrulanamayan / yeniden doğrulanması gereken alanlar
- **Per-function `verify_jwt` politikası** (Dashboard ayarı) bu ortamdan **okunamadı**.
- **anon EXECUTE'lu definer fonksiyonların fiilen RPC ile çağrılabilirliği** (trigger dönüşlü kapsı ayrılmadan) bu oturumda **tam doğrulanmadı**; 77 sayısı `has_function_privilege` temelli olup PUBLIC varsayılanını içerebilir. **Yeniden doğrulama önerilir.**
- **`Auth Dashboard`** ayarları (self-signup, parola politikası, rate-limit, JWT ömrü) **doğrulanamadı**.

---

## 3. Hassas Sağlık Verisi Koruması (KVKK)

### 3.1 Verinin bulunduğu tablolar / API'ler [KOD] + [AKTİF-OKUMA]

| Veri | Tablo / API | RLS |
|------|-------------|-----|
| Sağlık muayeneleri (tarih, yenileme, tıbbi durum) | `personel_saglik_muayeneleri` | [AKTİF-OKUMA] **RLS aktif**, 11 politika |
| Tetkik/tahliller | `personel_tetkikler` | [AKTİF-OKUMA] **RLS aktif**, 6 politika |
| Eğitim kayıtları (sağlık-ilişkili) | `personel_egitimleri` | [AKTİF-OKUMA] **RLS aktif**, 13 politika |
| TC kimlik / kişisel veri | `personeller` | [AKTİF-OKUMA] **RLS aktif**, 13 politika |
| KVKK-güvenli özet (durum+tarih) | RPC `personel_saglik_ozet` | [AKTİF-OKUMA] SECURITY DEFINER, `search_path=public` |

### 3.2 Erişim kontrolü — doğrulandı ve güçlü [AKTİF-OKUMA]
`personel_saglik_muayeneleri` **SELECT** politikaları:
- `admin` → tümü (`auth_role()='admin'`).
- `osgb_admin` → yalnızca kendi OSGB'si (`personel_osgb_id(personel_id) = auth_osgb_id()`).
- `hekim` → yalnızca **aktif ataması olan** firmanın çalışanı (`has_active_firma_assignment`).
- `firma` → **`false`** (ham tıbbi veriyi OKUYAMAZ). ✓
- `uzman` → **`false`** (ham tıbbi veriyi OKUYAMAZ). ✓

`personel_tetkikler` benzer şekilde: `admin` / `osgb_admin`(kendi) / `hekim`(aktif atama); firma/uzman SELECT politikası **yok** → deny.

**Sonuç:** Ham tıbbi veri, yalnızca sağlık mesleği (hekim) + OSGB yönetimi + admin ile sınırlı. Firma ve İSG uzmanı ham kaydı göremez.

### 3.3 KVKK-güvenli özet ve istemci ifşası [KOD] + [AKTİF-OKUMA]
- RPC `personel_saglik_ozet` yalnızca **`personel_id, muayene_tarihi, saglik_durumu, yenileme_tarihi`** döndürür ([AKTİF-OKUMA] gövde doğrulandı). **Muayene türü/kurum/açıklama/dosya ASLA dönmez.**
- RPC içinde rol/kapsam filtresi: admin / osgb_admin / firma / aksi halde **aktif atama** kontrolü.
- İstemci `firmaPersonelService.ts` ham tabloya **doğrudan gitmez**; `fetchSaglikOzetMap` (RPC) ile **3 durumlu uygunluk** (`uygun` / `uygun_degil` / `yok`) türetir → firma/uzman yalnızca "uygun mu" görür, tıbbi teşhis görmez.
- Sağlık kaydı **yazımı**: `eklePersonelSaglikKaydi` RPC `personel_saglik_kaydi_ekle` (definer) — firma/uzman yalnızca muayene tarihi girer (`saglik_durumu` NULL kalır); hekim/OSGB/admin durumu belirleyebilir.

### 3.4 Log sızıntısı ve istemci tarafı ifşa
- [KOD] Edge Function'lar sağlık verisini loglamaz; `system_logs` sağlık içeriği taşımaz (yalnızca id/count).
- [KOD] İstemcide service-role anahtarı **yok** (önceki denetimlerle tutarlı); sağlık verisi yalnızca RPC özeti üzerinden taşınır.
- [KOD] `sanitizeHtml` (DOMPurify) zengin metin/önizleme çıktısında XSS savunması sağlar.

### 3.5 Dikkat çekenler
| # | Bulgu | Risk | Yorum |
|---|-------|------|-------|
| PII-1 | Çalışan **TC kimlik no'su** firma/uzman liste verisinde dönüyor (kendi firması içinde). | Bilgi/KVKK | Kiracı-içi; ancak ekranda tam gösterim yerine **maskeleme** önerilir. |
| PII-2 | `personeller` ham kolonları (tc, adres, telefon) RLS ile kapsam içindedir; politika ifadeleri bu oturumda **satır satır** doğrulanmadı. | Doğrulanamadı | SELECT kapsamının firma/uzman için yalnızca kendi kapsamı olduğu **kod**la destekli, ancak politika detayı teyit edilmedi. |

> **Teknik / hukuki ayrımı:** Bu bölüm **teknik** erişim kontrolü bulgularıdır. KVKK md.6 (özel nitelikli veri) kapsamında **açık rıza, veri saklama süresi, işleme amacı, veri sorumlusu kaydı** gibi **hukuki** yükümlülükler bu denetimin kapsamı dışındadır ve ayrı bir hukuki değerlendirme gerektirir.

---

## 4. Supabase Storage Denetimi

### 4.1 Bucket envanteri ve public durumu [AKTİF-OKUMA]
16 bucket; **yalnızca 2'si public:**
- `avatars` (public=true) — avatarlar (tasarım gereği genel).
- `osgb-logos` (public=true) — OSGB logoları (tasarım gereği genel).

**Private (public=false):** `evraklar`, `saha-denetimleri`, `ekipman-belgeleri`, `ekipman-gorselleri`, `envanter`, `zimmet`, `operasyon`, `mesajlasma`, `support`, `announcements`, `atama-belgeleri`, `personel-foto`, `noter-defteri`, `hazop-kanitlari`.
- `evraklar` ve `support` için boyut limiti tanımlı (`209715200` / `10485760` bayt); diğerlerinde `file_size_limit=null` (limit edge function içinde uygulanıyor).

### 4.2 `storage.objects` politikaları [AKTİF-OKUMA]
**SELECT politikası olan bucket'lar (client erişimi):** `announcements`, `atama-belgeleri`, `hazop-kanitlari`, `noter-defteri`, `personel-foto`, `support`.
- `atama-belgeleri`, `hazop-kanitlari`, `noter-defteri`, `personel-foto` → merkezi `storage_tenant_ok(bucket_id, name)` ile tenant/rol/kapsam doğrulaması. ✓
- `avatars`, `osgb-logos`, `support` → `{public}` rol kapsamlı politikalarla.

**SELECT politikası OLMAYAN (client erişimi kapalı) bucket'lar:** `evraklar`, `saha-denetimleri`, `ekipman-belgeleri`, `ekipman-gorselleri`, `envanter`, `zimmet`, `operasyon`, `mesajlasma`, `announcements`(admin/dinamik hariç).
- Bu bucket'lar RLS default-deny olduğundan **istemci (anon/authenticated) tarafından okunamaz**; dosyalar yalnızca **service-role kullanan Edge Function'lar** üzerinden imzalı URL ile sunulur. ✓ (İyi ayrım.)

**DELETE politikaları:** `announcements`, `atama-belgeleri`, `hazop-kanitlari`, `noter-defteri`, `personel-foto`, `avatars`, `osgb-logos`, `support` — tenant/sahiplik/rol temelli; tablo DELETE RLS'i ile hizalanmış (GUV-01).

### 4.3 İmzalı URL / sahiplik / dosya türü-boyut [KOD]
- **İmzalı URL süresi:** Edge Function'larda tutarlı **`3600` sn (1 saat)** (evrak, ekipman, saha-denetim, envanter, zimmet, operasyon, firma-sozlesme).
- **Sahiplik:** İmzalı URL üretilmeden **önce** `assertEvrakAccess`/`assertEkipmanAccess`/`assertAccess` çalışır → başka firmanın dosyasına imzalı URL **verilmez**.
- **Dosya türü:** MIME allowlist (PDF/JPEG/PNG/WebP/Office...). **Boyut:** edge function içinde (`MAX_FILE`/`MAX_IMG`/`MAX_PHOTO` genelde 10–15 MB).
- **Yol yapısı:** `{osgb_id}/...` ve `{uid}/...` prefix'leri; `storage_tenant_ok` bu prefix'i ve ilişkisel tablo kapsamını çapraz kontrol eder.
- **Yükleme yolu:** `supabase.storage.from(bucket).upload(path, ArrayBuffer, {...})` — `FormData` ile bozuk çok-parça yükleme **yok** (önceki bir risk bertaraf edilmiş).

### 4.4 Bir firmanın başka firmaya ait belgeye erişme riski
| Kanıt | Değerlendirme |
|-------|---------------|
| `storage_tenant_ok` — 4 bucket için rol+ilişkisel kapsam (firma: `auth_firma_id()` eşleşmesi, uzman/hekim: aktif atama) | [AKTİF-OKUMA] Merkezi fonksiyon canlıda mevcut ✓ |
| Belge bucket'larında client SELECT politikası yok | [AKTİF-OKUMA] Client erişimi kapalı ✓ |
| İmzalı URL öncesi `assert*Access` | [KOD] Cross-firma reddi ✓ |

**Değerlendirme:** Kodda ve storage politikalarında, bir firmanın başka firmaya ait **belgeye client üzerinden eriştiği** bir yol **bulunamadı**.

### 4.5 Dikkat çekenler / doğrulanamayanlar
| # | Bulgu | Risk | Yorum |
|---|-------|------|-------|
| ST-1 | **`avatars` + `osgb-logos` bucket'ları public** → nesne URL'i dünya-okunur. | Düşük | Logo/avatar tasarım gereği genel; hassas değil. |
| ST-2 | `announcement_obj_insert`, `atama_belgeleri_obj_insert`, `hazop_kanit_storage_insert`, `noter_defteri_obj_insert`, `ocr_source_insert`, `support_obj_insert` politikalarının **WITH CHECK ifadeleri** (INSERT için) `pg_policies.qual`'da (USING) görünmediği için **doğrulanamadı**. | Doğrulanamadı | INSERT WITH CHECK ayrıca okunmalı; özellikle `ocr_source_insert` hangi bucket'a bağlı olduğu tespit edilmeli. |
| ST-3 | `evraklar` gibi client-SELECT'i olmayan bucket'ların bazı akışları dosyayı **base64 olarak Edge Function'dan** istemciye taşır (ör. OCR `content`). | Düşük | `assertEvrakAccess` sonrası; kapsam doğru. |
| ST-4 | İmzalı URL'ler 1 saat geçerli; paylaşılan/önbelleğe alınan URL süresi boyunca erişilebilir. | Düşük | Standart; hassas belge için daha kısa süre düşünülebilir. |

---

## 5. Veri Katmanı Hızlı Kontroller (destekleyici kanıt)
- [AKTİF-OKUMA] `personel_saglik_muayeneleri` / `personel_tetkikler` / `personel_egitimleri` / `personeller`: **RLS aktif** ve politika sayıları > 0.
- [AKTİF-OKUMA] `profile_lock_role` (rol kilit trigger fonksiyonu) canlıda mevcut — dikey yetki yükseltme koruması.
- [AKTİF-OKUMA] `storage_tenant_ok` canlıda mevcut.

---

## 6. Bulgu Özet Tablosu

| ID | Başlık | Risk | Durum |
|----|--------|------|-------|
| IDOR-1 | Kiracı-dışı varlık enumeration (404 vs 403) | Düşük-Orta | Sertleştirme |
| IDOR-2 | Liste yanıtında tam TC gösterimi (kiracı-içi) | Bilgi/KVKK | Öneri |
| IDOR-3 | Log metadata'da PII (email/reason) | Düşük | Öneri |
| IDOR-4 | Edge Function CORS `*` | Düşük | Sertleştirme |
| EDGE-1 | anon EXECUTE'lu definer fonksiyon sayısı (77) — önceki "22" ile çelişki | Doğrulanamadı | Yeniden doğrula |
| EDGE-2 | Per-function `verify_jwt` doğrulanamadı | Doğrulanamadı | Dashboard teyidi |
| PII-1 | Çalışan TC maskeleme önerisi | Bilgi/KVKK | Öneri |
| ST-1 | `avatars` + `osgb-logos` public bucket | Düşük | Kabul edilebilir |
| ST-2 | INSERT WITH CHECK ifadeleri doğrulanamadı | Doğrulanamadı | Teyit |
| ST-3 | Base64 ile servis üzerinden dosya taşıma | Düşük | Kabul edilebilir |

---

## 7. Dürüstçe Doğrulanamayanlar
- **Runtime IDOR/tenant testi** (izole iki-OSGB ortamı yok) → yapılamadı.
- **Per-function `verify_jwt`** ve **Auth Dashboard** ayarları → bu ortamdan okunamadı.
- **anon EXECUTE'lu definer fonksiyon envanteri** → `has_function_privilege` temelli; PUBLIC varsayılanını içerebilir, kesin RPC erişilebilirliği doğrulanmadı.
- **Storage INSERT `WITH CHECK`** ifadeleri ve `ocr_source_insert` bucket eşlemesi → doğrulanamadı.
- `npm audit`, `.env` git geçmişi → yapılamadı.

**Net hâli:** Bu denetimde **doğrulanmış, sömürülebilir kritik bir açık bulunmadı**; sistem IDOR/erişim kontrolü ve hassas veri koruması açısından olgun görünüyor. Kalan işler savunma derinliği sertleştirmesi + Dashboard/storage yapılandırma doğrulamasıdır.