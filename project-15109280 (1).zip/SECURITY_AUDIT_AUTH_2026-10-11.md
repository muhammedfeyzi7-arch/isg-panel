# İSGDenetim — Kimlik Doğrulama & Oturum Güvenliği Denetimi

**Tarih:** 2026-10-11
**Kapsam:** Giriş, çıkış, şifre sıfırlama, e-posta doğrulama, oturum yenileme, token saklama.
**Yöntem:** Kaynak kod okuma + canlı veritabanına **salt-okuma, PII içermeyen özet sorgular**.
**İlke:** Bu denetimde **hiçbir kod / DB / yapılandırma değiştirilmedi**. Gerçek kullanıcı hesaplarına müdahale edilmedi (yalnızca agregat sayaçlar okundu).

> ⚠️ Not: Bu ortamdan erişilemeyen alanlar (Supabase Auth Dashboard ayarları, per-function `verify_jwt`, çalışma-zamanı oturum iptali davranışı) aşağıda ayrıca ve dürüstçe listelenmiştir. Doğrulanamayan şeyler "kesin açık" olarak sunulmamıştır.

---

## 1. Mimari Envanteri

| Katman | Dosya / Fonksiyon | Rol |
|---|---|---|
| Auth istemcisi (singleton) | `src/lib/supabase.ts` | Tek Supabase client; `persistSession`, `autoRefreshToken`, `detectSessionInUrl` |
| Auth durumu | `src/context/AuthContext.tsx` | `signIn` / `signOut` / `changePassword` / profil yükleme / `onAuthStateChange` |
| Oturum sınırı | `src/components/feature/SessionBoundary.tsx` | Kimlik değişince geçici UI sıfırlama |
| Route koruması | `src/components/feature/ProtectedLayout.tsx` | Oturum + rol + OSGB erişim + bakım + personel durumu kapıları |
| Giriş | `src/pages/login/page.tsx` | E-posta/şifre, "Beni hatırla", başarısız deneme logu |
| Şifremi unuttum | `src/pages/sifremi-unuttum/page.tsx` | Markalı e-posta (edge) → fallback `resetPasswordForEmail` |
| Şifre sıfırla | `src/pages/sifre-sifirla/page.tsx` | `verifyOtp({type:'recovery'})` → `updateUser` |
| Davet kabul | `src/pages/invite/accept/page.tsx` + `supabase/functions/accept-invite` | Davet token doğrulama, hesap oluşturma/şifre belirleme |
| Edge: şifre e-postası | `supabase/functions/send-reset-email/index.ts` | `admin.generateLink(recovery)` + Resend |
| Edge: auth log | `supabase/functions/auth-log/index.ts` | `system_logs`'a giriş/çıkış olayı yazar |
| Hata mesajları | `src/lib/authErrorMessages.ts` | Tek kaynak Türkçe, ham metin sızdırmaz |
| CSP | `index.html` | `Content-Security-Policy` meta |

**Canlı kanıt (salt-okuma, agregat):**
- `auth.users`: toplam **6**, e-posta doğrulanmış **6**, doğrulanmamış **0**, geçici banlı **0**.
- `system_logs`: `AUTH_LOGIN_SUCCESS`=41, `AUTH_LOGIN_FAILED`=39, `AUTH_LOGOUT`=17, `AUTH_INVITATION_ACCEPTED`=5.

---

## 2. Olumlu Kontroller (gerçekten yerinde olanlar)

- **Kullanıcı enumerasyonu engelli:** `send-reset-email` her koşulda `{ ok: true }` döner; "kullanıcı yok" ile "gönderildi" ayırt edilemez (kanıt: `send-reset-email/index.ts` — `return json({ ok: true, sent: false })` yolları).
- **Ham hata sızdırmama:** `friendlyAuthError` bilinmeyen/teknik hatada fallback döner; İngilizce Supabase mesajı yüzeye çıkmaz.
- **Recovery token URL temizliği:** `sifre-sifirla/page.tsx` — `verifyOtp` sonrası `window.history.replaceState` ile `token_hash` adres çubuğundan silinir.
- **Çıkışta state temizliği:** `signOut` session/user/profile'ı null'lar; `SessionBoundary` geçici UI overlay'lerini sıfırlar.
- **Geçici ağ hatası ≠ logout:** `AuthContext` `SIGNED_OUT` olayını `getSession()` ile yeniden doğrular; token-refresh hıçkırığında kullanıcıyı panelden atmaz.
- **`onAuthStateChange` senkron:** Deadlock riski yok (kurala uygun, `.then()` non-blocking).
- **İstemcide servis anahtarı yok:** `src` altında `SERVICE_ROLE` referansı **yok** (grep: eşleşme yok). Service-role yalnızca Edge Function runtime'ında.
- **Istemci tarafı rol kapısı + sunucu tarafı zorlama:** `ProtectedLayout` rol/rota eşleşmesi yapar; asıl yetki RLS/RPC'de (önceki denetimde 176/176 tabloda RLS açık).
- **Client-side şifre politikası:** min 8 + büyük/küçük harf + rakam (login/invite/reset formlarında).

---

## 3. Bulgular (kanıtlı)

### AUTH-01 — Token'lar `localStorage`'da (Orta)
**Kanıt:** `src/lib/supabase.ts` → `persistSession: true`, özel `storage` verilmemiş → supabase-js varsayılanı `localStorage`.
**Sonuç:** Erişim + refresh token'ları JS ile okunabilir. Herhangi bir XSS, token hırsızlığına → hesap ele geçirmeye dönüşür. `index.html` CSP'sinde `script-src ... 'unsafe-inline' 'unsafe-eval'` bulunması XSS yüzeyini büyütür (AUTH-10 ile ilişkili).
**Not:** SPA + Supabase'in standart davranışı; httpOnly cookie alternatifi bu mimaride yok. Doğrudan exploit değil, **risk çarpanı**.

### AUTH-02 — Uygulama seviyesinde kilitlenme (lockout) / CAPTCHA yok (Orta)
**Kanıt:** `src/pages/login/page.tsx` — başarısız deneme sayacı / hesap kilidi / CAPTCHA / artan gecikme yok. Yalnızca `logAuthEvent('AUTH_LOGIN_FAILED')`. Canlı: **39 başarısız giriş** loglanmış.
**Sonuç:** Brute-force / credential-stuffing koruması yalnızca Supabase Auth'un tümleşik rate-limit'ine bağlı. Uygulama katmanında ikincil savunma yok.
**Doğrulanamaz:** Supabase'in rate-limit eşikleri Dashboard'da — buradan okunamadı.

### AUTH-03 — `auth-log` uç noktası kimlik doğrulama gerektirmiyor → denetim kaydı zehirlenmesi (Düşük-Orta)
**Kanıt:** `supabase/functions/auth-log/index.ts` — JWT **opsiyonel**: token yoksa/geçersizse `userId=null` ile yine de `system_logs`'a **insert** edilir; `ALLOWED_EVENTS` yalnızca olay tipini beyaz listeye alır.
**Sonuç:** Anon anahtarla (herkese açık) sahte `AUTH_LOGIN_FAILED`/`AUTH_LOGIN_SUCCESS`/`AUTH_LOGOUT` satırları eklenebilir. Etkileri: (1) denetim kaydı gürültüsü/güven kaybı, (2) gerçek saldırının log içinde gizlenmesi, (3) `AUTH_LOGIN_FAILED` + e-posta ile profil üzerinden rol/OSGB eşlemesi (değer istemciye dönmez → doğrudan enumerasyon yok).
**Not:** `AUTH_LOGIN_SUCCESS` ile `last_login_at` sahtelenemez (yalnızca geçerli JWT + userId ile). Impact bu yüzden sınırlı.

### AUTH-04 — `send-reset-email` herkese açık ve oran sınırı yok → e-posta bombardımanı (Orta)
**Kanıt:** `supabase/functions/send-reset-email/index.ts` çağıran kimliği doğrulamaz; yalnızca e-posta formatı kontrolü var. Var olan bir kullanıcı adresi için sınırsız tetiklenebilir.
**Sonuç:** Hedef kullanıcıya spam; Resend maliyeti/abuse. (Enumerasyon AÇISINDAN güvenli: yanıt her zaman `ok:true`.)
**Doğrulanamaz:** `verify_jwt` ayarı ve Resend tarafı oran sınırı.

### AUTH-05 — Şifre değişiminde diğer oturumlar iptal edilmiyor (Orta)
**Kanıt:** `src/context/AuthContext.tsx` → `changePassword` mevcut şifreyi `signInWithPassword` ile doğrular, sonra `updateUser({ password })`. **`signOut({ scope: 'others'|'global' })` çağrısı yok.** `sifre-sifirla/page.tsx` de yalnızca yerel `signOut()` yapar.
**Sonuç:** Şifre çalındıktan sonra kullanıcı şifreyi değiştirse bile, saldırganın elindeki mevcut refresh token/session **geçerli kalır**. "Ele geçirme sonrası toparlanma" senaryosunu zayıflatır.
**Öneri (uygulanmadı):** Şifre değişiminde/sıfırlamada `supabase.auth.signOut({ scope: 'others' })`.

### AUTH-06 — Çıkışta bellek içi veri önbelleği temizlenmiyor (Düşük)
**Kanıt:** `SessionBoundary` → `resetAllTransientUi()` **yalnızca** modal/confirm/bottomsheet/toast sıfırlar (`transientUiReset.ts`). SWR cache (`tabDataCache.ts`, modül seviyesi, `SWRConfig`) ve diğer in-memory cache'ler çıkışta **temizlenmez**; logout sonrası tam sayfa yenileme de yapılmaz.
**Sonuç:** Aynı sekmede ikinci bir kullanıcı giriş yaptığında, anahtar eşleşirse önceki kullanıcının tenant verisi bir an görünebilir. Paylaşılan cihaz senaryosunda artık veri riski.
**Not:** Farklı kullanıcı anahtarları farklı olduğundan kalıcı sızma değil; **geçici/artık veri** riski.

### AUTH-07 — MFA / 2FA yok (Bilgi)
**Kanıt:** Kod tabanında `mfa`/`totp`/`challenge` referansı yok; giriş yalnızca şifre.
**Sonuç:** Yönetici/OSGB hesapları için ikinci faktör bulunmuyor. Şifre sızıntısı = doğrudan hesap ele geçirme.

### AUTH-08 — E-posta doğrulama akışı tasarım gereği kullanılmıyor (Bilgi / Tasarım)
**Kanıt:** Kayıt (sign-up) akışı yok; hesaplar davetle oluşturulur. `accept-invite/index.ts` hem yeni kullanıcıda hem mevcut kullanıcı güncellemesinde `email_confirm: true` verir. Canlı: 6/6 kullanıcı "doğrulanmış".
**Sonuç:** Gerçek bir "e-posta sahipliği doğrulama" mekanizması yok; güven, davet e-postasının kontrolüne dayanır. Bu, davet token'ının güvenliğini kritik hale getirir (aşağıya bakınız).

### AUTH-09 — Tüm auth Edge Function'larında CORS `*` (Düşük)
**Kanıt:** `send-reset-email`, `accept-invite`, `auth-log`, `personel-hesap` hepsi `'Access-Control-Allow-Origin': '*'`.
**Sonuç:** Her origin bu uçları çağırabilir; AUTH-03/AUTH-04 ile birleşince abuse yüzeyi artar. JWT sunucuda doğrulandığı sürece doğrudan veri sızdırmaz, ama sertleştirme gerekir.

### AUTH-10 — CSP'de `unsafe-inline` / `unsafe-eval` (Düşük-Orta)
**Kanıt:** `index.html` `script-src 'self' 'unsafe-inline' 'unsafe-eval' ...`.
**Sonuç:** XSS'e karşı CSP koruması zayıf; AUTH-01 (localStorage token) ile birleşince token çalma zinciri kolaylaşır.
**Not:** `frame-ancestors`, HSTS, `nosniff` yalnızca HTTP başlığı ile verilebilir (meta ile değil) — barındırma katmanında ayarlanmalı. Raporda not düşülmüş durumda.

### AUTH-11 — Davet token'ı URL query'de (Düşük)
**Kanıt:** Davet linki `${siteUrl}/invite/accept?token=...` (`personel-hesap`, `osgb-davet`, `firma-davet`).
**Sonuç:** Token, tarayıcı geçmişi / proxy logları / referrer üzerinden sızabilir. `index.html` referrer politikası `strict-origin-when-cross-origin` (kısmi hafifletme). AUTH-08 ile birlikte token güvenliği tek savunma hattı.

### AUTH-12 — `accept-invite` profil satırı olmayan mevcut hesap senaryosu (Bilgi, düşük olasılık)
**Kanıt:** `accept-invite/index.ts` — mevcut auth kullanıcısı bulunduğunda, eğer `profiles` satırı **yoksa**, rol/OSGB (personel/ firma) rol çakışması kontrolleri atlanır ve `updateUserById({ password, email_confirm: true })` + yeni profil bağlanır.
**Sonuç:** Profil satırı olmayan bir auth hesabı varsa, davet eden OSGB yöneticisi o hesaba yeni şifre belirleyip kendi OSGB'sine bağlayabilir. Tüm kullanıcıların profili olduğu varsayımıyla risk düşük; yine de savunma derinliği için not edilmelidir.

---

## 4. Bu Ortamdan DOĞRULANAMAYAN ALANLAR (kesin bulgu olarak sunulmadı)

- **Supabase Auth Dashboard:** Self-signup kapalı mı?, sunucu-taraflı minimum şifre uzunluğu/kompleksliği, JWT süresi, **refresh token rotation** açık mı?, e-posta OTP süresi, rate-limit eşikleri, MFA zorunluluğu → panel ayarı, koddan okunamaz.
- **Per-function `verify_jwt`:** Her Edge Function için ayrı ayar; dashboard'dan doğrulanamadı (davranış koddan çıkarıldı, kesin değil).
- **Çalışma-zamanı oturum iptali:** Süresi dolmuş/iptal edilmiş token ile erişimin gerçekten reddedildiği, izole iki-kullanıcı ortamı olmadığı için **çalıştırarak** test edilmedi. Değerlendirme statik muhakeme + sunucu tarafı RLS'e dayanır.
- **`auth` şeması** iç yapısı (GoTrue tabloları) detaylı incelenmedi (yalnızca agregat kullanıcı sayaçları okundu).
- **`.env` git geçmişi** ve `npm audit` bu ortamdan çalıştırılamadı.

---

## 5. Risk Özeti

| ID | Bulgu | Seviye |
|---|---|---|
| AUTH-01 | Token `localStorage`'da (XSS → token hırsızlığı) | Orta |
| AUTH-02 | App-level lockout/CAPTCHA yok | Orta |
| AUTH-04 | Auth'suz reset e-postası tetikleme (bombardıman) | Orta |
| AUTH-05 | Şifre değişiminde diğer oturumlar iptal edilmiyor | Orta |
| AUTH-10 | CSP `unsafe-inline`/`unsafe-eval` | Düşük-Orta |
| AUTH-03 | `auth-log` kimliksiz → denetim kaydı zehirlenmesi | Düşük-Orta |
| AUTH-06 | Çıkışta in-memory cache temizlenmiyor | Düşük |
| AUTH-09 | CORS `*` | Düşük |
| AUTH-11 | Davet token URL'de | Düşük |
| AUTH-07 / AUTH-08 / AUTH-12 | MFA yok / e-posta doğrulama kullanılmıyor / profil-siz hesap senaryosu | Bilgi |

**Sonuç:** Kimlik doğrulama hattı **olgun** (enumerasyon koruması, ham hata sızdırmama, token URL temizliği, geçici-ağ-hiccup toleransı, deadlock'suz callback'ler). Doğrulanmış, sömürülebilir kritik bir açık bulunmadı. Ana riskler **sertleştirme** sınıfında: token saklama (CSP ile birleşik), oturum iptali politikası ve uç-nokta abuse'u. Kalan doğrulamalar Supabase Dashboard ve barındırma başlık katmanında yapılmalı.

*Bu rapor salt-okuma inceleme çıktısıdır; hiçbir kod/DB/yapılandırma değiştirilmemiştir.*