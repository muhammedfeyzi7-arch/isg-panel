# İSGDenetim — Faz 8: GUV-13 / GUV-14 Kapsam Tamamlama Analizi

> **Yöntem:** (a) migration + rollback + test dosyalarının tam içeriği okundu, (b) canlı
> Supabase'de **yalnızca salt-okuma** `SELECT` (pg_proc / pg_namespace / pg_policy /
> has_function_privilege / `prosrc` gövdeleri), (c) uygulama kodu `grep` taraması
> (`src/**/*.ts`, `supabase/functions/**/*.ts`).
>
> **SINIR:** Bu doküman hazırlık amaçlıdır. **Hiçbir DDL/DML üretime uygulanmadı**, hiçbir
> migration çalıştırılmadı, hiçbir Edge Function deploy edilmedi, kullanıcı verisi
> değiştirilmedi. Aşağıdaki "gerçek sonuç" bilgileri **statik inceleme + canlı metadata
> gözlemidir**; runtime PASS değildir.

---

## 1) GUV-13 kapsam tamamlama — anon-çağrılabilir definer fonksiyonlar

### 1.0 Canlı ölçüm (salt-okuma, Faz 8)
- `anon`'un EXECUTE edebildiği SECURITY DEFINER fonksiyon: **çok sayıda**; bunlardan
  **trigger döndürmeyen (RPC ile gerçekten çağrılabilir)** olanlar `pg_proc` üzerinden
  listelendi.
- GUV-13 (Faz 6) hedef listesi bunların bir kısmını kapsıyordu. Faz 7'nin işaretlediği
  **23 kapsam-dışı fonksiyon** bu turda **tek tek** incelendi.
- Ayrıca anon'a açık **RLS/erişim yardımcıları** ve **meşru public** fonksiyonlar da
  tespit edildi (bunlara dokunulmaz).

### 1.1 Karar tablosu — 23 kapsam-dışı fonksiyon (tek tek)

| # | Fonksiyon (imza) | Gövde işi | Guard durumu | RLS/politika veya kod çağrısı | Önerilen rol | Karar |
|---|---|---|---|---|---|---|
| 1 | `atama_firma_durum_ozet()` | Firma/atama KPI özeti üretir (okuma) | **VAR** — `role NOT IN ('admin','osgb_admin') → RAISE` | `src/lib/atamaKapsam.ts:244` (panel) | authenticated | **anon REVOKE** |
| 2 | `atama_rol_doygunluk()` | Rol doygunluk özeti (okuma) | YOK ama iç çağrı `atama_firma_list` guard'lı | `src/lib/osgbDashboardService.ts:268` | authenticated | **anon REVOKE** |
| 3 | `firma_aktif_atamalar(uuid)` | Firma aktif atamaları (okuma) | **VAR** — `auth.uid() IS NULL → return` + rol/kapsam | (DB içi yardımcı) | authenticated | **anon REVOKE** |
| 4 | `firma_aktif_personel_sayisi(uuid)` | Çalışan sayısı (okuma) | **VAR** — rol/kapsam kontrolü | (DB içi yardımcı) | authenticated | **anon REVOKE** |
| 5 | `firma_calisan_sayisi(uuid)` | Çalışan sayısı (okuma) | **VAR** — rol/kapsam | (DB içi yardımcı) | authenticated | **anon REVOKE** |
| 6 | `hazard_change_detect(uuid,text)` | Tehlike sınıfı değişim tespiti | **VAR** — `role NOT IN ('admin','osgb_admin') → RAISE` | `src/lib/assignmentService.ts:986` | authenticated | **anon REVOKE** |
| 7 | `resolve_hazard_change_assignment(uuid,text)` | Tehlike değişim mutabakatı (YAZAR) | **VAR** — admin/osgb_admin guard | `src/lib/assignmentService.ts:1018` | authenticated | **anon REVOKE** |
| 8 | `personel_saglik_ozet(uuid[])` | Sağlık muayene özeti (okuma) | **VAR** — role göre filtre | `src/lib/firmaPersonelService.ts:594` | authenticated | **anon REVOKE** |
| 9 | `personel_aktif_bagimliliklar(uuid)` | Bağımlılık sayıları (okuma) | **VAR** — role göre filtre | `src/lib/personelService.ts:1021` | authenticated | **anon REVOKE** |
| 10 | `personel_validity_resolve(uuid,text,date)` | Geçerlilik hesabı (okuma) | **YOK** — personel→firma→tehlike zinciri | `src/lib/personelValidity.ts` (DB motoru) | authenticated | **anon REVOKE** |
| 11 | `personel_firma_id(uuid)` | id→firma_id eşlemesi döndürür | **YOK** — kimlik kontrolü yok | (DB içi yardımcı) | authenticated | **anon REVOKE** |
| 12 | `personel_osgb_id(uuid)` | id→osgb_id eşlemesi döndürür | **YOK** — kimlik kontrolü yok | (DB içi yardımcı) | authenticated | **anon REVOKE** |
| 13 | `mesajlasma_unread_count()` | Okunmamış mesaj sayısı | **VAR** — `auth.uid()` kapsamı | Mesajlaşma paneli | authenticated | **anon REVOKE** |
| 14 | `mesajlasma_unread_counts(uuid,uuid[])` | Okunmamış sayıları | **VAR** — `auth.uid()` kapsamı | Mesajlaşma paneli | authenticated | **anon REVOKE** |
| 15 | `mesajlasma_conversation_unread_count(uuid)` | Konuşma okunmamış sayısı | **VAR** — `auth.uid()` kapsamı | Mesajlaşma paneli | authenticated | **anon REVOKE** |
| 16 | `mesajlasma_last_messages(uuid[])` | Son mesajlar | **VAR** — `auth.uid()` kapsamı | Mesajlaşma paneli | authenticated | **anon REVOKE** |
| 17 | `personel_atama_sure_plan()` | Tüm firma/atama süre planı (okuma) | **YOK** — cross-tenant okuma | **Kod çağrısı YOK** (iç/scheduler) | authenticated | **anon REVOKE** |
| 18 | `operasyon_bakim_hatirlatma()` | **YAZAR** — `operasyon_bildirimleri`'ne toplu INSERT | **YOK** — hiçbir guard yok | **Kod çağrısı YOK** (scheduler) | service_role | **anon+authenticated REVOKE** |
| 19 | `project_myk_requirements()` | MYK gereksinim satırları yazar/günceller | **VAR** — gövdesel: yalnız `service_role` | **Kod çağrısı YOK** (sunucu) | service_role | **anon+authenticated REVOKE** |
| 20 | `osgb_erisim_acik(uuid)` | OSGB erişim durumu (salt bool) | YOK ama kullanıcı verisi sızdırmaz | (DB içi yardımcı) | public/helper | **DOKUNMA** (koru) |
| 21 | `mesajlasma_is_participant(uuid)` | Konuşma üyeliği kontrolü | **VAR** — `auth.uid()` | **RLS policy** (`conversation_participants` vb.) | helper | **DOKUNMA** (koru) |
| 22 | `operasyon_entity_accessible(text,uuid)` | Operasyon erişim kontrolü | **VAR** — rol/uid/osgb | **RLS policy** (`operasyon_dosyalari`, `operasyon_yorumlari`) | helper | **DOKUNMA** (koru) |
| 23 | `resolve_hazard_change_assignment` *(tekrar referans)* / `resolve_profile_names(uuid[])` | Profil adları çözümler | YOK — isim döndürür | (DB içi yardımcı) | authenticated | **anon REVOKE** |

> Not: Yukarıda 17 fonksiyon `anon REVOKE` grubuna, 2 fonksiyon `anon+authenticated REVOKE`
> (yalnız service_role) grubuna girdi; 3 fonksiyon (`osgb_erisim_acik`, `mesajlasma_is_participant`,
> `operasyon_entity_accessible`) **RLS/erişim yardımcısı olduğu için korundu**.
> (`resolve_profile_names` tabloda 23. satırda ayrıca listelendi.)

### 1.2 Neden bazıları KORUNUYOR (körü körüne kapatma YOK)
- **RLS/erişim yardımcıları** (`mesajlasma_is_participant`, `operasyon_entity_accessible`,
  `has_active_*`, `can_access_*`, `auth_role`, `auth_osgb_id`, `auth_firma_id`,
  `auth_personel_id`, `auth_personel_bilgi`, `is_maintenance_active`, `is_icon_admin`,
  `request_context`, `osgb_erisim_acik`, `osgb_access_ok`):
  - Politikalar içinde çağrılır; `SECURITY DEFINER` + `auth.uid()`/`auth_role()` ile
    **kendi kapsam kontrolünü** yaparlar → anon çağırınca güvenli şekilde `false`/boş
    dönerler. Kapatılırsa politikaların anon sorgularında **hata** üretmesine yol açabilir.
- **Meşru public akış**: `teklif_public_get/view/action` (token tabanlı public teklif),
  `create_support_ticket` (destek kanalı) → anon açık kalır.
- **`next_tutanak_no`** → GUV-11 tarafından zaten daraltıldı.

### 1.3 Uygulanan migration
- **`supabase/migrations/20260101000800_guv13b_anon_definer_scope.sql`** (+ rollback):
  - (1) 17 fonksiyon: `REVOKE FROM PUBLIC, anon` + `GRANT TO authenticated, service_role`.
  - (2) 2 fonksiyon (`operasyon_bakim_hatirlatma`, `project_myk_requirements`):
    `REVOKE FROM PUBLIC, anon, authenticated` + `GRANT TO service_role`.
  - Dinamik `DO` + `regprocedure` → overload çözümü ve idempotency garantili.

### 1.4 İşlevsellik etkisi
- **Panel (authenticated)**: etkilenmez — tüm çağrılan fonksiyonlar `authenticated` grant'ını korur.
- **Edge Function (service_role)**: etkilenmez — `service_role` grant'ı verilir.
- **Scheduler / pg_cron**: `operasyon_bakim_hatirlatma` artık `service_role` ile çağrılmalı;
  pg_cron kendi süper-kullanıcı rolüyle çalıştığından etkilenmez. **İzole testte doğrulanmalı.**

---

## 2) GUV-14 kapsam tamamlama — search_path boş vs NULL

### 2.1 Canlı ölçüm (salt-okuma, Faz 8)

| Durum | Anlam | Canlı sayı | Örnekler |
|---|---|---|---|
| `search_path IS NULL` | Hiç set edilmemiş → oturumdan miras → **hijacking riski** | **4** | `custom_field_definition_set_osgb`, `custom_field_value_set_scope`, `firma_evrak_klasorleri_set_scope`, `ziyaret_auto_close_due` |
| `search_path = ""` (BOŞ, set) | Yalnız pg_catalog örtük → **hijacking İMKÂNSIZ** | ~35 | `log_system_event`, `can_access_announcement`, `create_maintenance_plan`, `cancel_maintenance_plan`, `announcement_audit`, … |
| `search_path` set (dolu) | Güvenli | çok sayıda | `{search_path=public}`, `{search_path=public, pg_temp}` |

### 2.2 `log_system_event(text,text)` incelemesi
- **Gövde:** `IF public.auth_role() IS DISTINCT FROM 'admin' THEN RAISE ... 'ADMIN_ONLY'` +
  `PERFORM public.audit_log(...)`.
  → **Tam-nitelikli** ve **admin guard'lı**. `search_path=""` **güvenli önerilen desendir**
  → **DEĞİŞTİRİLMEMESİ önerilir.** (GUV-13, bu fonksiyonu zaten anon'dan kapatıyor.)
- Ek bulgu: bu fonksiyon boş `search_path` taşıdığı için GUV-14 filtresine **takılmaz** (bu
  doğru davranış — değiştirmek gerekmez), ancak **GUV-13 grant daraltması** ile korunmalıdır.

### 2.3 Boş search_path ANCAK niteliksiz gövde (risk/uyumsuzluk)
Canlıda boş `search_path` taşıyıp **gövdesinde `public.` niteliği bulunmayan** 7 fonksiyon:

| Fonksiyon | Trigger mı | Risk |
|---|---|---|
| `firma_isg_girdi_degisim()` | ✅ trigger | Niteliksiz referans boş search_path altında çözülemez (varsa) |
| `firma_lock_osgb()` | ✅ trigger | aynı |
| `firma_prevent_delete()` | ✅ trigger | aynı |
| `personel_lock_scope()` | ✅ trigger | aynı |
| `personel_normalize()` | ✅ trigger | aynı |
| `personel_prevent_delete()` | ✅ trigger | aynı |
| `request_context()` | ❌ fonksiyon (çağrılabilir) | header okur; niteliksiz referans riski |

> Bunların 6'sı **çekirdek tablo trigger'ıdır** (`firmalar`, `personeller`); eğer gövdede
> niteliksiz public tablo referansı varsa boş search_path altında **runtime hatası** olurdu.
> Canlı sistem çalıştığına göre ya niteliksiz public referansı yoktur ya da ilgili kod yolu
> tetiklenmemektedir. Güvenli çözüm: `search_path = public, pg_temp` sabitlemek.

### 2.4 Uygulanan migration
- **`supabase/migrations/20260101000900_guv15_search_path_completion.sql`** (+ rollback):
  - (1) `search_path IS NULL` olan TÜM definer fonksiyonlara `public, pg_temp` (GUV-14 ile idempotent).
  - (2) Yukarıdaki 7 niteliksiz-boş fonksiyona `public, pg_temp`.
  - Boş `search_path` taşıyan **tam-nitelikli** diğer fonksiyonlara **dokunulmaz** (zaten güvenli).
- ⚠️ **Bu dosya doğrulama önceliklidir:** trigger davranışı izole ortamda doğrulanmadan
  üretime alınmamalıdır.

---

## 3) Değiştirilen / oluşturulan dosyalar (Faz 8)

| Dosya | Durum | Amaç |
|---|---|---|
| `supabase/migrations/20260101000800_guv13b_anon_definer_scope.sql` | **Yeni** | 23 fonksiyon kapsam tamamlama (anon daraltma) |
| `supabase/migrations/rollback/20260101000800_guv13b_anon_definer_scope_rollback.sql` | **Yeni** | Geri dönüş |
| `supabase/migrations/20260101000900_guv15_search_path_completion.sql` | **Yeni** | search_path boş/NULL tamamlama |
| `supabase/migrations/rollback/20260101000900_guv15_search_path_completion_rollback.sql` | **Yeni** | Geri dönüş |
| `SECURITY_COVERAGE_PHASE8.md` | **Yeni** | Bu doküman |
| `SECURITY_TEST_ENV_PLAN_PHASE8.md` | **Yeni** | Test ortamı engeli çözüm planı |
| `SECURITY_TEST_RESULTS_PHASE8.md` | **Yeni** | Faz 8 sonuç raporu (PASS/FAIL/BLOCKED) |
| `supabase/tests/security/guv13b_guv15_coverage.test.sql` | **Yeni** | GUV-13b + GUV-15 izole testi |
| `supabase/tests/security/README.md` | Güncellendi | Yeni test dosyası + kurulum |

---

## 4) Idempotency / kilit / erişim / veri kaybı

| Risk | GUV-13b | GUV-15 |
|---|---|---|
| Tekrar çalıştırılabilirlik | ✅ (`REVOKE`/`GRANT` + dinamik `DO`) | ✅ (`ALTER ... SET` + dinamik `DO`) |
| Kilit | Düşük (metadata lock) | Düşük (metadata lock) |
| Veri kaybı | **YOK** | **YOK** |
| Erişim kaybı riski | `authenticated`+`service_role` korunur → düşük | Trigger davranışı değişebilir → **izole testte doğrulanmalı** |
| Rollback | ✅ var | ✅ var (RESET) |

> Bu doküman resmî TSE onaylı sızma testinin yerine geçmez. Gerçek PASS için migration'lar
> izole ortamda çalıştırılıp kanıtlanmalıdır.