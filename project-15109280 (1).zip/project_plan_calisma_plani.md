# İSGDenetim — Yıllık Çalışma Planı Sihirbazı (uygulama notu)

> Bu dosya, ana `project_plan.md`'nin yanına "Yıllık Çalışma Planı" sihirbaz akışını
> belgeler. Mevcut 5x5 / Fine-Kinney / HAZOP akışlarına, SharedUICore'a ve tasarım
> diline DOKUNULMAMIŞTIR; yeni sayfaya özel UI motoru OLUŞTURULMAMIŞTIR.

## 1. Amaç
Uzman > Evraklar → **+ Sihirbaz → İSGDenetim Sihirbazı → Yıllık Çalışma Planı** akışını,
HAZOP ile aynı mimaride (5 adım yerine 4 adım) uçtan uca çalışır hâle getirmek.

Hukuki dayanak: **İSG Hizmetleri Yönetmeliği — Madde 15 (Yıllık çalışma planı)** ve
6331 sayılı İSG Kanunu. Plan; işyeri hekimi ve iş güvenliği uzmanı tarafından hazırlanan,
bir sonraki yılın İSG faaliyetlerinin zaman planıdır.

## 2. Konum ve Giriş
- Route: `/uzman/evraklar` (mevcut). Buton zaten mevcut (+ Sihirbaz).
- Modül seçim ekranındaki **Yıllık Çalışma Planı** kartı artık AKTİF ve seçilebilir
  (Risk Değerlendirmesi kartının yanında, 2×2 ızgaranın 2. aktif kartı).
- Diğer sihirbazlar gibi kendi `RwStepper` + footer aksiyonlarını yönetir.

## 3. Akış (4 Adım)
1. **Temel Bilgiler ve Kapsam** — Plan Adı, Plan Yılı, Firma, Tesis, Düzenleme Tarihi,
   Geçerlilik, Amacı; **Plan Kapsamı** (10 madde + "Tümünü Seç" + özel madde ekleme),
   Plan Ekibi, Referans Dokümanlar, Rapor künyesi. Sağda "Yıllık Çalışma Planı Hakkında"
   (m.15) + Planın Hedefleri.
2. **Faaliyetler** — Satır içi düzenlenebilir faaliyet kartları (Kategori · Faaliyet ·
   Açıklama · Sorumlu · Periyot · Öncelik + planlanan ay önizlemesi). Sağda **AI Asistan**
   öneri kartları ("Faaliyete Ekle") + **Şablon Kütüphanesi** (22 hazır faaliyet) + örnek sorular.
3. **Aylık Planlama** — 12 aylık matris (Ocak…Aralık işaretlenebilir hücreler),
   "Tamamını Temizle", "Önerilen Planı Uygula" (periyoda göre deterministik dağıtım).
   Sağda **Planlama Özeti** (ay bazında planlanan) + Periyot Dağıtımı + legend.
4. **Rapor ve Önizleme** — Özet kartları, **kategori dağılımı donut**, **aylık yoğunluk
   grafiği**, **yıllık çalışma matrisi** önizlemesi, Mevzuat Dayanakları, uygulama içi
   gerçek PDF önizleme ve Word/PDF/Excel indirme.

## 4. Veri Katmanı (KAYIT YOK — yerel çalışma)
- Kalıcı kayıt / arşiv YOKTUR; sisteme/Supabase'e hiçbir veri gönderilmez.
- Çalışma yalnızca **IndexedDB** üzerinde tutulur (`calismaWorkspaceStore.ts`) → modal
  kapanıp açılınca kaldığı yerden devam; "Sıfırla" ile tamamen silinir.

## 5. Yapay Zeka (backend)
- Frontend: `src/lib/riskAiService.ts → aiCalismaOnerileri` (`risk-ai-oneriler` edge
  function, `body.calisma` bloğu). API anahtarı yalnızca server-side (Deno.env).
- Model; işyeri bağlamına (firma, tesis, NACE, tehlike sınıfı, plan yılı, kapsam) ve
  kullanıcının mevcut faaliyetlerine göre TAM 10 faaliyet önerir (kategori/periyot/öncelik
  geçerli değer aralığında). Öneri, kullanıcı kabul etmeden listeye YAZILMAZ.

## 6. Rapor Çıktıları (premium, kurumsal — 5x5/Fine-Kinney/HAZOP ile aynı dil)
`src/lib/calismaRapor/`:
- **PDF** (`pdf.ts`) — A4 YATAY, DejaVu Sans gömülü. Bölümler: kapak → 1 Plan Bilgileri →
  2 Plan Kapsamı → 3 Yıllık Çalışma Matrisi → 4 Faaliyet Detayları → 5 Özet/Dağılım →
  6 Mevzuat Dayanakları → 7 Onay ve İmza. Sabit header/footer + "Sayfa X / Y".
- **Word** (`word.ts`) — gerçek .docx; kapak A4 DİKEY, tablolar A4 YATAY, header + Sayfa X/Y.
- **Excel** (`excel.ts`) — tek sayfa alt alta bölümler; ekipman Excel'iyle aynı kurumsal
  header, navy başlıklar, zebra satırlar, A4 yatay, FitToWidth, print area, footer.
- Logo/OSGB künyesi Kurumsal Ayarlar'daki gerçek kayıttan gelir (`loadRiskBrandMeta`).

## 7. Yeni Dosyalar
- `src/components/feature/risk/calismaTypes.ts`
- `src/components/feature/risk/calismaWorkspaceStore.ts`
- `src/components/feature/risk/CalismaSihirbazContent.tsx`
- `src/components/feature/risk/calisma/adimlar/CalismaAdim1Temel.tsx`
- `src/components/feature/risk/calisma/adimlar/CalismaAdim2Faaliyetler.tsx`
- `src/components/feature/risk/calisma/adimlar/CalismaAdim3Aylik.tsx`
- `src/components/feature/risk/calisma/adimlar/CalismaAdim4Rapor.tsx`
- `src/lib/calismaRapor/model.ts` · `pdf.ts` · `word.ts` · `excel.ts` · `index.ts`

## 8. Değişen Dosyalar
- `RiskModulSecim.tsx` — "Yıllık Çalışma Planı" kartı aktif + modül anahtarı iletimi.
- `RiskSihirbazModal.tsx` — `calisma` aşaması ve başlığı; modül→ekran yönlendirmesi.
- `RiskSihirbazHeader.tsx` — `CalismaHeaderIcon`.
- `src/lib/riskAiService.ts` — `aiCalismaOnerileri` + tipler.
- `supabase/functions/risk-ai-oneriler/index.ts` — `calisma` bloğu (prompt + handler + route).

## 9. Kapsam Dışı (şimdilik)
- Kayıtlı planı sihirbazda yeniden açıp düzenleme (yalnız yeni oluşturma).
- Otomatik geçerlilik/hatırlatma motoru ve DÖF aktarımı.

## 10. Not
- AI butonları backend `GEMINI_API_KEY` ister; tanımlı değilse arayüz anlaşılır hata
  gösterir (çökmez). `risk-ai-oneriler` edge function'ı yayında olmalıdır.