# Sunucu Loglarını Panele Çekme — Toplama & Özet Planı

> **Durum:** UYGULANDI (kod repoda) — sunucuda cron + migration kurulumu bekliyor
> **Tarih:** 2026-10-14
> **Hedef:** Caddy / docker compose (Kong · PostgREST · GoTrue · Storage) ve
> varsa Cloudflare katmanındaki olayları periyodik olarak toplayıp uygulama
> paneline (özet + filtrelenebilir ham kayıt) taşımak. Böylece **oturumsuz
> (unauthenticated) saldırı denemeleri** de Sistem Logları yanında tek ekranda
> görülebilir olur.

---

## 1. Neden bu iş gerekli (boşluğun tanımı)

Mevcut durumda uygulama içi güvenlik görünürlüğü **oturum (JWT) gerektirir**
(`auth-log` edge function + `securityEventLogger` süzgeci). Bu yüzden:

| Olay tipi | Bugün görünür mü? | Nerede? |
|---|---|---|
| Başarılı / başarısız giriş | ✅ | Sistem Logları (`AUTH_LOGIN_*`) |
| Oturumlu kullanıcının RLS / 401 / 403 hatası | ✅ | Sistem Logları (`SECURITY_*`) |
| **Oturumsuz tarama / isimsiz endpoint denemesi** | ❌ | Yalnız sunucu logları |
| **4xx-5xx patlamaları, /wp-login gibi sahte URL avı** | ❌ | Yalnız sunucu logları |
| **Kong/PostgREST/GoTrue içinde reddedilen istekler** | ❌ | Yalnız `docker compose logs` |
| **Cloudflare WAF / bot / ban olayları** | ❌ | Yalnız Cloudflare paneli |

Bu plan tam olarak **❌ işaretli satırları** uygulama paneline taşımayı amaçlar.

---

## 2. Genel Mimari

```
┌─────────────────────────── SUNUCU (srv.ibys-prod.com / Turhost) ──────────────────────────┐
│                                                                                            │
│  Caddy access log   docker compose logs      Cloudflare (ops.)                             │
│  /var/log/caddy/*    (kong/postgrest/       Logpush veya API                               │
│         │              gotrue/storage)            │                                        │
│         └──────────────┬───────────────────────────┘                                      │
│                        ▼                                                                   │
│        ┌───────────────────────────────────────────────┐                                   │
│        │  05-server-log-topla.sh  (cron · 1-5 dk)       │                                  │
│        │  1) KEŞİF: hangi log kaynakları var?           │                                  │
│        │  2) PARSE: satır → yapılandırılmış olay        │                                  │
│        │  3) SINIFLANDIR: tarama / abuse / waf / ban    │                                  │
│        │  4) ÖZETLE: IP + URL + status sayaçları        │                                  │
│        │  5) YAZ: service-role ile PostgREST'e          │                                  │
│        └───────────────────────┬───────────────────────┘                                   │
│                                ▼                                                           │
│              Postgres (self-host Supabase)                                                 │
│              · server_security_events   (ham, filtrelenebilir)                             │
│              · system_logs              (yalnız "dikkate değer" özet olaylar)              │
└────────────────────────────────────────────────────────────────────────────────────────────┘
                                 │  (RLS: yalnız admin okur)
                                 ▼
        ┌───────────────────────────────────────────────┐
        │  Panel: "Sunucu Güvenliği" görünümü            │
        │  Üstte özet kartları · Altta ham kayıt tablosu │
        └───────────────────────────────────────────────┘
```

**Veri deposu kararı (hibrit):**
- **Ham** sunucu olayları → yeni tablo `server_security_events`. Amaç: erişim
  loglarının hacmi büyük; mevcut `system_logs`'u sel gibi doldurup gerçek
  kimlik olaylarını gömmesin.
- **Dikkate değer özetler** (ör. "aynı IP'den 40 adet 404",
  "bilinen tarama imzası", "fail2ban ban") → mevcut `system_logs`'a **tek satır**
  olarak da yazılır. Böylece mevcut **Güvenlik ön-ayarı** ve **24s KPI**'ların
  içinde de belirir. (`event_type` yeni slug'lar, `action='security'`,
  `severity='warning'|'critical'`, `status='failed'`, `user_id=NULL`.)

---

## 3. Fazlar (uygulama sırası)

### FAZ 0 — Keşif (sunucuda hangi log var?)
Amaç: senin "bilmiyorum" cevabını sisteme **otomatik** netlettirmek.
`05-server-log-topla.sh` ilk çalıştırmada şu kaynakları **var/yok** diye tarar ve
bir **keşif raporu** üretir (`/var/log/ibys-log-kesif.txt`):

- `/var/log/caddy/access*.log` veya `journalctl -u caddy`
- `docker compose logs --no-color {kong,rest,auth,storage,functions}`
- `fail2ban-client status` (jail listesi + banlanan IP'ler)
- `docker/.env` içinde Cloudflare token var mı (ops.)
- `ufw status` (açık portlar)
- Postgres log dizini (`/opt/ibys/supabase/docker/volumes/db/data/log/...`)

> Çıktı: "Var olan kaynaklar" listesi. Toplama fazında **yok olanlar sessizce atlanır**.

### FAZ 1 — Toplama (parse)
- Cron zamanlaması: `*/2 * * * *` (2 dakikada bir; gecikme 1-5 dk hedefiyle uyumlu).
- **İdempotans:** son işlenen satır işareti (byte offset / `journalctl` cursor / son
  `--since`) küçük bir state dosyasında tutulur → aynı satır iki kez yazılmaz.
- **Kaynak başınа parser:**
  - **Caddy (JSON formatı önerilir):** `ip, ts, method, host, uri, status, size, ua, duration`.
    (Caddyfile'da `log { format json }` — JSON gelmezse common-log regex ile.)
  - **docker compose logs:** `kong`/`rest`/`auth`/`storage` satırlarından
    `status` kodları, `401/403`, `RLS`/`permission denied`, anormal RPC yolları.
  - **fail2ban:** yeni ban/blok olayları.
  - **Cloudflare (ops.):** Logpush → dosya, veya API ile son N dk Security Events.
- **Gizlilik/temizlik:** Authorization header, `apikey`, JWT, e-posta kısmi maskeleme
  (ham logdaki sır/token **asla** panele yazılmaz — `stripSecrets` mantığı sunucu
  tarafında da uygulanır).

### FAZ 2 — Sınıflandırma & özetleme
Olay → kategori eşlemesi:

| Kategori | Tetikleyici (örnek) | severity |
|---|---|---|
| `SCAN` | `/wp-login`, `/admin`, `/\.env`, `/phpmyadmin`, `/.git` | warning |
| `UNKNOWN_HOST` | Yanlış Host başlığı / tanımsız alan adı | info |
| `HTTP_ERROR_BURST` | Aynı IP'den pencere içinde N adet ≥400 | warning/critical |
| `AUTH_ABUSE` | Aynı IP'den tekrarlı 401/403 (Kong/GoTrue) | warning |
| `RPC_DENIED` | PostgREST `permission denied` / `RLS` | warning |
| `BAN` | fail2ban / Cloudflare WAF blok | critical |
| `PAYLOAD_SUSPECT` | Şüpheli büyük gövde / garip content-type | warning |

- **Eşik (throttle):** aynı IP+kategori için pencere içinde tekrar eden olaylar
  tek özet satıra düşer (log flood önlenir; mevcut `auth_abuse_limits` mantığıyla
  aynı felsefe).
- **Özet üretimi:** per kaynak-IP toplam istek, 4xx/5xx sayısı, en çok vurulan URL,
  ilk/son görülme. Bu özet hem ham tabloya hem `system_logs`'a alınır.

### FAZ 3 — Depolama (DB değişiklikleri)
Yeni migration (rollback dosyasıyla birlikte):

**a) `server_security_events`** (ham; yalnız service-role yazar, yalnız admin okur)

| Sütun | Tip | Not |
|---|---|---|
| id | bigint identity | PK |
| occurred_at | timestamptz | log satırının zamanı |
| source | text | caddy / kong / postgrest / gotrue / storage / cloudflare / fail2ban |
| category | text | SCAN / AUTH_ABUSE / HTTP_ERROR_BURST / … |
| severity | text | info / warning / critical |
| ip_address | text | (ops. kısmi maske) |
| method | text | GET/POST… |
| host | text | |
| path | text | |
| status_code | int | |
| user_agent | text | |
| description | text | kısa, temizlenmiş |
| raw_fingerprint | text | tekrar engelleme için hash |
| dedupe_key | text | idempotans (unique) |
| created_at | timestamptz | |

- İndeksler: `(occurred_at desc)`, `(ip_address)`, `(category)`, `(status_code)`.
- **RLS:** `ENABLE ROW LEVEL SECURITY`; okuma politikası yalnız `role='admin'`.
  Yazma yalnız service-role (politika yoksa service-role bypass eder zaten).
- **Retention:** ör. 30/90 gün — eski satırları temizleyen hafif bir `DELETE`
  cron'u ya da partition. (Ayrı karar; plan maddesi.)

**b) `search_server_security_events` RPC** — panel filtreleri için
(`p_ip`, `p_category`, `p_severity`, `p_from`, `p_to`, `p_page`, `p_page_size`,
`p_sort_by`, `p_sort_dir`). `search_system_logs` ile aynı desende.

**c) `server_security_summary` RPC** — üstteki özet kartları:
son 24s kategori dağılımı, en çok deneyen ilk 10 IP, en çok vurulan ilk 10 URL,
toplam 4xx/5xx, toplam blok.

**d) `system_logs`'a özet yazımı** — dikkate değer özet olaylar
(`SERVER_SCAN`, `SERVER_ABUSE`, `SERVER_BAN`, `SERVER_RPC_DENIED` gibi slug'lar).
Bu slug'lar `src/lib/logService.ts` içindeki `EVENT_LABEL`'a **Türkçe etiket**le
 eklenir ki panelde ham İngilizce görünmesin.

> ⚠️ Canlı DB'de `system_logs` ve `search_system_logs`/`system_log_summary`
> zaten mevcut; bu adımlar onların **üzerine** eklenir, mevcut akış bozulmaz.

### FAZ 4 — Panel görünümü
"Sistem Logları" sayfasına **Sunucu Güvenliği** sekmesi/görünümü (mimari olarak
mevcut sayfayla uyumlu; tek görünümde hem özet hem ham liste):

- **Üst — Özet kartları:** Son 24s: 4xx/5xx, Tarama denemesi, Bloklanan IP,
  En çok deneyen IP (ilk 3). + kategori dağılım mini grafiği.
- **Orta — Filtre çubuğu:** IP, kategori (SCAN/AUTH_ABUSE/BAN…), severity,
  tarih aralığı, kaynak (caddy/kong/…). Mevcut `FilterBar`/`SegmentedControl`
  bileşenleriyle.
- **Alt — Ham kayıt tablosu:** zaman · kaynak · kategori · IP · method · path ·
  status · (satıra tıkla → detay). Sayfalama mevcut `Table`/`Pagination` ile.
- **"Dikkate değer" olaylar** ayrıca mevcut **Güvenlik** ön-ayarında görünür
  (system_logs'a yazıldığı için) — çift görünürlük, kayıp yok.

### FAZ 5 — Doğrulama & pentest günü kullanımı
- Test: sunucuda bilerek `curl https://api.isgdenetim.com.tr/wp-login.php` ve
  art arda 404 üret → 1-2 dk içinde panelde beliren `SCAN`/`HTTP_ERROR_BURST`
  kaydını doğrula.
- fail2ban testi: eşik aşan denemede `BAN` olayının panele düşmesi.
- **Pentest günü:** "Sunucu Güvenliği" görünümü + mevcut Güvenlik ön-ayarı
  birlikte izlenir; sunucu logları yine destekleyici kaynak kalır.

---

## 4. Yeni olay slug'ları (system_logs'a düşenler)

| event_type | Türkçe etiket (logService EVENT_LABEL) | action | severity |
|---|---|---|---|
| `SERVER_SCAN` | Sunucu Tarama Denemesi | security | warning |
| `SERVER_ABUSE` | Sunucu Anormal İstek Yoğunluğu | security | critical |
| `SERVER_AUTH_ABUSE` | Sunucu Yetki Denemesi Yoğunluğu | security | warning |
| `SERVER_RPC_DENIED` | Sunucu Veri Erişimi Reddi (RLS) | security | warning |
| `SERVER_BAN` | Sunucu IP Bloklama | security | critical |

---

## 5. Güvenlik & gizlilik kuralları (bu planda bağlayıcı)

1. **Sır sızmaz:** ham logda `Authorization`/`apikey`/JWT/e-posta örnekleri
   temizlenir; panele yalnız kısaltılmış/anonimleştirilmiş metin gider.
2. **Service-role sırrı sunucuda kalır:** toplama script'i yalnız sunucudaki
   `.env`'den okur; repoya/asla commit edilmez.
3. **Yazma yüzeyi kapalı:** `server_security_events` yalnız service-role yazar;
   `anon`/`authenticated` INSERT yetkisi **yok**. Okuma yalnız admin (RLS).
4. **Log zehirlenmesine direnç:** `dedupe_key` + kategori/throttle; sır temizleme;
   satır uzunluğu sınırı.
5. **En az ayrıcalık:** yeni tablo/sequence, GUV-17 desenine uygun yetkilendirilir.

---

## 6. Riskler & geri dönüş

| Risk | Etki | Önlem |
|---|---|---|
| Log formatı beklenenden farklı (Caddy JSON değil) | parse boş | Faz 0 keşfi + common-log fallback |
| Yüksek hacim → DB şişmesi | performans | ham tablo retention + throttle |
| Yanlış pozitif gürültü | panel kirliliği | kategori eşikleri + admin filtresi |
| Cron çakışması / tekrar yazım | mükerrer satır | state dosyası + `dedupe_key` unique |
| Cloudflare yok | WAF olayı gelmez | kaynak opsiyonel; diğer katmanlar çalışır |

**Geri dönüş:** yeni tablo/RPC/panel pasifize edilir; cron kaldırılır. Mevcut
`system_logs` akışı hiç etkilenmediği için sistem eski haline döner.

---

## 7. Teslimat listesi (uygulanınca üretilecekler)

- [x] `deploy/scripts/05-server-log-topla.sh` — keşif + parse + yazım (cron)
- [x] Cron kurulum satırı + state/log dizinleri (`--kur-cron` bayrağı)
- [x] `supabase/migrations/20260101001900_srv01_server_security_events.sql` (+ rollback)
- [x] `search_server_security_events` + `server_security_summary` RPC'leri
- [x] `src/lib/logService.ts` → yeni `EVENT_LABEL` girdileri (Türkçe)
- [x] `src/lib/serverSecurityService.ts` → fetch/RPC sarmalayıcıları
- [x] Panel: **Sunucu Güvenliği** görünümü (özet + ham liste + filtre)
- [x] Doğrulama script'i (`supabase/tests/security/pentest_gunu/10_sunucu_log_dogrula.sh`)
- [ ] Sunucuda uygulama: migration + `--kur-cron` (deploy adımı)

### Sunucuda kurulum (senin adımın)
```bash
# 1) SRV-01 migration'ını canlı DB'ye uygula (rollback dosyası da hazır)
# 2) Toplayıcıyı test et ve cron'u kur:
sudo bash deploy/scripts/05-server-log-topla.sh --kesif
sudo bash deploy/scripts/05-server-log-topla.sh --dry-run
sudo bash deploy/scripts/05-server-log-topla.sh --kur-cron
# 3) Doğrula:
bash supabase/tests/security/pentest_gunu/10_sunucu_log_dogrula.sh
```

---

## 8. Ankara/bağımlılık notu

- Bu iş **sunucu tarafında** çalışır (cron + self-host Supabase). Readdy Backend
  veya SaaS Supabase'in bağlı olması gerekmez; hedef **self-host Postgres**'tir.
- Panel değişiklikleri (FAZ 4) arayüz işidir ve normal **Publish/Update** ile çıkar;
  cron + migration'lar sunucuda ayrı uygulanır.