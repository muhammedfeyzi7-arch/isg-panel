# İSGDenetim / OSGB SaaS — PROMPT 6/8: CORS, CSP, HTTP Güvenlik Başlıkları ve Dağıtım Sertleştirmesi

> **Tarih:** 2026-10-11 · **Kapsam:** Supabase Edge Functions CORS · `index.html` CSP ·
> HTTP yanıt başlıkları · Frontend build (sourcemap) · Ortam değişkenleri · `verify_jwt`.
> **Tür:** Gerçek kod + dağıtım düzeltmesi (salt-okuma denetimi DEĞİL).
>
> **DÜRÜSTLÜK NOTU:** Gerçek HTTP yanıt başlıkları (HSTS / frame-ancestors / nosniff)
> **barındırma (hosting) katmanında** üretilir; bu proje için barındırma yapılandırmasına
> erişimim YOK → ilgili maddeler **"doğrulanamadı / hosting adımı"** olarak raporlandı,
> **başarılı sayılmadı**. `vite.config.ts` **platform tarafından kilitli** (kod ile
> değiştirilemedi) → sourcemap maddesi **hosting/platform adımı** olarak belgelendi.
> Edge Function CORS **canlı uygulandı ve deploy edildi**. CSP `index.html` üzerinde
> uygulandı. Ağ/log yakalama bu oturumda boş geldi → runtime kanıtı üretilemedi.

---

## 0) ÖZET

| Bulgu | Şiddet | Durum |
|---|---|---|
| **F-06-01** 44 Edge Function'da `Access-Control-Allow-Origin: *` | 🟡 Orta | **GİDERİLDİ** (origin allowlist yansıması + `Vary: Origin`) — canlı deploy |
| **F-06-02** CSP `script-src` içinde `'unsafe-eval'` | 🟡 Orta | **GİDERİLDİ** (`'wasm-unsafe-eval'`'e indirildi) |
| **F-06-03** CSP eksik origin'ler (`unpkg.com`, `cdn.jsdelivr.net`) | 🟡 Orta | **GİDERİLDİ** (connect-src'ye eklendi) |
| **F-06-04** Hassas API yanıtları için `Cache-Control`/`nosniff` yok | 🟡 Orta | **GİDERİLDİ** (tüm fonksiyon yanıtlarına eklendi) |
| **F-06-05** `build.sourcemap: true` (üretimde kaynak haritası) | 🔵 Düşük | **ENGELLENDİ** (platform `vite.config.ts`'i kilitliyor) → hosting/platform adımı |
| **F-06-06** HSTS / `frame-ancestors` / `X-Content-Type-Options` başlıkları | 🟡 Orta | **HOSTING ADIMI** (kod ile verilemez; doğrulanamadı) |
| **F-06-07** `verify_jwt` politikaları | 🔵 Bilgi | **DOĞRULANDI** (tüm fonksiyonlarda `verify_jwt: true`) |

**Doğrulama:** `vite build` ✅ · 44/44 Edge Function deploy ✅ · statik+mantık testleri yazıldı.
**Kanıtlanmış, uzaktan-kimliksiz kritik açık YOK.**

---

## 1) EDGE FUNCTIONS CORS DENETİMİ

**Envanter:** 44 fonksiyonun **tamamında** `Access-Control-Allow-Origin: '*'` + sabit
`Allow-Headers/Methods` vardı. **`Access-Control-Allow-Credentials: true` HİÇBİR
fonksiyonda YOKTU** → tarayıcı çerez göndermez; kimlik **Bearer token** ile taşınır.

**Gerçek risk (dürüst değerlendirme):** Kimlik bilgisi modu olmadığı ve auth bearer
tabanlı olduğu için `*`, pratikte tarayıcı cross-origin **yanıt okumayı** değil, kaynak
paylaşımını açık bırakır. Saldırgan bir site, kurbanın token'ını elde edemeden bu
uçlara **kimlikli** istek atamaz. Bu nedenle asıl etki **düşük-orta**'dır (yine de
"gereksiz wildcard" ilkesine aykırı). Bu değerlendirme raporda açıkça belirtilmiştir.

**Uygulanan düzeltme (canlı, 44/44 deploy):**
- Her fonksiyona **inline `corsHeaders(req)` + `withCors(handler)`** eklendi
  (kanonik kaynak: `supabase/functions/_shared/cors.ts` belgesi).
- `Deno.serve(withCors(async (req) => { … }))` ile tüm yanıtlar sarıldı.
- **Karar mantığı:** istek `Origin` **izinliyse yansıtılır**; izinli değilse
  `Access-Control-Allow-Origin` **hiç gönderilmez** (tarayıcı okumayı engeller).
- İzinli origin'ler: bilinen üretim alan adları + `localhost` (dev) + Readdy
  önizleme/hosting alan adları + **`ALLOWED_ORIGINS`** ortam değişkeni (virgülle).
- `Access-Control-Allow-Credentials` **eklenmedi** (bearer mimarisiyle uyumlu).
- Preflight (`OPTIONS`) wrapper tarafından **izinli origin yansımasıyla** karşılanır.
- **Sağlamlık:** başlık uygulamasında beklenmeyen hata olursa **orijinal yanıt**
  döndürülür (fonksiyon asla düşmez) → mevcut akışlar korunur.

**Fonksiyon ihtiyaçları ayrı değerlendirildi:** Bu sistemde **webhook yok** ve
sunucudan-sunucuya çağrılar **`Origin` başlığı taşımaz** (bu durumda CORS başlığı
üretilmez, akış etkilenmez). Chrome eklentisi `host_permissions` + içerik betiği ile
çalışır → **CORS'a bağımlı değildir**. Bu nedenle tarayıcı-yüzeyli tüm uçlara ortak
politika uygulanması doğrudur (kör uygulama değildir).

**Kabul kriteri kontrolü:** CORS gereksiz wildcard'a **dayanmıyor** ✅ · CORS kimlik
doğrulamanın yerine **geçmiyor** (yetki hâlâ JWT/rol/tenant kontrolüyle) ✅.

---

## 2) CONTENT SECURITY POLICY

**Bulgu F-06-02/03:** `index.html` `<meta http-equiv="Content-Security-Policy">`
politikasında `script-src … 'unsafe-inline' 'unsafe-eval' …` vardı; ayrıca kod
tarafından **fetch edilen** `https://unpkg.com` (PDF.js wasm/cMap/font) ve
`https://cdn.jsdelivr.net` (gömülü font CDN fallback) origin'leri **politikada YOKTU**.

**Doğrulama:** `src/**` içinde `eval(` / `new Function(` **hiç yok** (grep) → JS eval
gerekmiyor. PDF.js taranmış belgeleri açmak için **WebAssembly** kullanır → CSP'de
yalnızca **`'wasm-unsafe-eval'`** gerekir.

**Uygulanan düzeltme (`index.html`):**
- `script-src`: **`'unsafe-eval'` KALDIRILDI** → **`'wasm-unsafe-eval'`** eklendi.
- `connect-src`: `https://unpkg.com` + `https://cdn.jsdelivr.net` **eklendi**.
- `default-src 'self'` + `form-action 'self'` **eklendi** (belirtilmemiş direktifler
  artık `'self'`'e düşer).
- Korunan mevcut direktifler: `object-src 'none'`, `base-uri 'self'`, `img-src`
  (Supabase storage, OSM tile, readdy görselleri), `font-src` (Google Fonts, cdnjs),
  `frame-src 'self' blob: https://*.supabase.co`, `worker-src 'self' blob:`.
- `'unsafe-inline'` **style-src ve script-src'de KORUNDU**: script için `index.html`
  içindeki inline tema (FOUC önleme) betiği; style için React inline stilleri ve
  enjekte edilen stiller gerekli. **Nonce/hash geçişi ayrı bir dikkatli tur gerektirir**
  (çok sayıda inline script/style üreticisi var). Bu turda **aşırı daraltma yapılmadı**
  (uygulamayı bozmama kuralı).

**`frame-ancestors` (clickjacking):** `<meta>` ile **GÖNDERİLEMEZ** → **HTTP yanıt
başlığı** olarak barındırma katmanında ayarlanmalıdır (§3, §6). Meta ile sağlandığı
**varsayılmadı**.

**Regresyon riski (dürüst):** `'unsafe-eval'` kaldırılması, PDF.js'in JS-eval tabanlı
font derleme yolunu devre dışı bırakır; PDF.js bunu **otomatik algılayıp** yedek
yorumlayıcıya düşer. Bu davranış **bu ortamda runtime test edilemedi** (ağ/log yok).
Başarısızlık görülürse: `'wasm-unsafe-eval'` → `'unsafe-eval'` geri alınır.

---

## 3) HTTP GÜVENLİK BAŞLIKLARI — HOSTING ADIMI (doğrulanamadı)

Projede `_headers` / `netlify.toml` / `vercel.json` / `nginx.conf` **yok** ve
barındırma paneline erişimim **yok**. Dolayısıyla **gerçek yanıt başlıkları
doğrulanamadı** ve **değiştirildiği iddia EDİLMEDİ**. Aşağıdaki başlıklar barındırma/
CDN katmanında ayarlanmalıdır:

```
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
Content-Security-Policy: frame-ancestors 'none'
Referrer-Policy: strict-origin-when-cross-origin
Permissions-Policy: geolocation=(self), camera=(), microphone=(), payment=()
Cache-Control: no-store   # sağlık verisi içeren API yanıtları için
```

- **HSTS:** yalnızca **tüm ilgili alt alan adları** (www, app, statik) HTTPS hazır
  olduğunda ve `preload` dikkatle açılmalıdır (kontrolsüz genişletme yapılmadı).
- **Cache-Control:** Edge Functions yanıtlarına **kod ile `no-store` eklendi**
  (F-06-04 — paylaşımlı/ortak önbelleğe alınma riski kapatıldı). Statik varlıklar için
  ayrı politika barındırma tarafında.
- **X-Content-Type-Options: nosniff** Edge Functions yanıtlarına **kod ile eklendi**.

---

## 4) HTTPS VE YÖNLENDİRME

- **Open redirect:** `send-reset-email` içinde `redirectTo` için **origin allowlist**
  (Faz-4'te uygulanmış) mevcut; `accept-invite` token tabanlı, yeniden kullanılamaz.
- OAuth/recovery callback URL'leri `mail/index.ts` (`DEFAULT_REDIRECT_URI`) ve
  `send-reset-email` içinde **sabitlenmiş** (istemciden gelen serbest URL allowlist'e
  tabi). **HTTP→HTTPS yönlendirmesi** barındırma katmanına bağlı → **doğrulanamadı**.
- Karışık içerik: tüm harici kaynaklar `https://` (index.html). ✅ (statik doğrulama)

---

## 5) SOURCEMAP VE FRONTEND BUILD — ENGELLENDİ

- **Kanıt:** `vite.config.ts` → `build: { sourcemap: true, outDir: 'out' }`.
- **Deneme:** `sourcemap: false` yapmak istendi → **platform reddetti**:
  *"vite.config.ts modification prohibited to avoid compilation failure"*.
- **Sonuç:** Bu ortamda **kod ile kapatılamadı.** Kaynak haritalar sır **içermez**
  (yalnızca kaynak kodu ifşası) → **tek başına kritik değil**. Kapatma/özel depoda
  tutma **platform/dağıtım ayarıdır** (§6). **Değiştirildiği iddia edilmedi.**

---

## 6) ORTAM DEĞİŞKENLERİ VE GİZLİ ANAHTARLAR

- **Frontend'e gömülen değerler:** `.env` yalnızca `VITE_PUBLIC_SUPABASE_URL` ve
  `VITE_PUBLIC_SUPABASE_ANON_KEY` içerir. `VITE_` öneki istemciye **görünür** —
  **anon (publishable)** anahtar tasarım gereği public'tir. ✅
- **`service_role` / özel anahtarlar:** istemci kodunda **YOK**; yalnızca Edge
  Function ortam değişkenlerinden (`Deno.env`) okunur (`SUPABASE_SERVICE_ROLE_KEY`,
  `RESEND_API_KEY`, `GEMINI_*`, `STRIPE_*` vb.). Build çıktısına girmedikleri
  **statik olarak doğrulandı** (frontend `Deno`/service_role referansı yok).
- **Sır değerleri** bu rapora **yazılmadı**. **Rotation**, yalnızca sızıntı kanıtı
  olmadığı için **önerilmedi**.

---

## 7) EDGE FUNCTION KİMLİK DOĞRULAMA AYARLARI

- Deploy sonuçları **her fonksiyonda `verify_jwt: true`** olduğunu doğruladı.
- Kimlik doğrulama **yalnızca istemcide değil**: fonksiyonlar `Authorization: Bearer`
  JWT'yi **sunucu tarafında** doğrular + rol/tenant (`profiles`) kontrolü yapar.
- **Herkese açık uçlar** (bilinçli): `send-reset-email`, `auth-log` (failed-login),
  `accept-invite` (token ile), `osgb-status` — bunlar `verify_jwt: true` olsa da
  anon anahtarıyla çağrılır ve **kendi içinde** abuse/rate-limit/enumerasyon korumaları
  taşır (Faz-4).
- **CORS daraltması yetki kontrolünü ZAYIFLATMADI** (yetki hâlâ fonksiyon içinde).

---

## 8) OTOMATİK TESTLER (gerçek sonuç)

| Test | Durum |
|---|---|
| `vite build` (TypeScript + bundle) | ✅ **PASS** |
| 44/44 Edge Function deploy | ✅ **PASS** |
| `guv20_cors_csp.test.ts` (statik + saf mantık + CSP) | ⛔ **BLOCKED** — Deno runtime yok; yazıldı |
| Yetkisiz-origin / OPTIONS preflight canlı HTTP testi | ⛔ **BLOCKED** — izole ortam yok |
| `frame-ancestors` gerçek yanıt başlığı doğrulaması | ⛔ **BLOCKED** — hosting erişimi yok |
| Üretim build'de `.map` dosyası kontrolü | ⛔ **BLOCKED** — platform build kontrolü |

**Yazılan test kapsamı:** üretim origin yansıması; `evil.com` reddi; sahte
`readdy.ai.evil.com` / `evilreaddy.ai` reddi; Readdy önizleme kabulü; Origin yoksa
başlık üretilmemesi; `ALLOWED_ORIGINS` genişletmesi; tüm fonksiyonlarda wildcard
kalmadığı; `withCors` sarmalaması; CSP'de `'unsafe-eval'` olmadığı ve
`unpkg`/`jsdelivr`/`supabase` origin'lerinin connect-src'de olduğu.
**Bu testler ÇALIŞTIRILMADI → "başarılı" sayılmadı.** İzole ortamda
`deno test supabase/tests/security/guv20_cors_csp.test.ts` ile koşulmalıdır.

---

## 9) DAĞITIM VE GERİ DÖNÜŞ

**Dağıtım (yapıldı):**
1. 44 Edge Function kaynağına inline `corsHeaders`/`withCors` + `Deno.serve(withCors(...))`.
2. `deploy_edge_function` ile **44/44** canlıya alındı (JWT politikası korunarak).
3. `index.html` CSP sertleştirildi.

**Geri dönüş (rollback):**
- Fonksiyon başına: ilgili `index.ts`'te `Deno.serve(withCors(` → `Deno.serve(`,
  kapanış `}));` → `});`, eklenen `__GUV20_*`/`corsHeaders`/`withCors` bloğu kaldırılır,
  `'Access-Control-Allow-Origin': '*'` geri eklenir → yeniden deploy.
- `index.html`: CSP `content` değeri önceki hâline döndürülür (git).
- DB/migration değişikliği **yok**.

---

## 10) HOSTING / DASHBOARD ÜZERİNDEN YAPILMASI GEREKENLER

1. **HTTP güvenlik başlıkları** (§3) — barındırma/CDN seviyesinde (alan adı paneli).
2. **`build.sourcemap`** — platform/dağıtım ayarı ile kapatma veya `.map` erişimini kısıtlama.
3. **`ALLOWED_ORIGINS` ortam değişkeni** — (opsiyonel) üretimde beklenen origin
   listesini daraltmak için Supabase → Edge Functions → Secrets.
4. **HTTPS zorlaması** ve OAuth/recovery redirect allowlist (Supabase Auth URL config).

---

## 11) BAĞIMSIZ SIZMA TESTİNDE YENİDEN DOĞRULANACAK NOKTALAR

1. İzinli origin'den (`app.isgdenetim.com.tr`) istek → `Access-Control-Allow-Origin`
   yansımalı, `Vary: Origin`, `Cache-Control: no-store`, `X-Content-Type-Options: nosniff`.
2. Yetkisiz origin (`evil.com`) → **ACAO yok** (tarayıcı okumayı engeller).
3. `OPTIONS` preflight → 200 + doğru izin başlıkları.
4. CSP: login/panel/PDF önizleme/rapor üretimi akışlarının **engellenmeden** çalışması
   (özellikle PDF.js taranmış belgeler — `'wasm-unsafe-eval'` davranışı).
5. `frame-ancestors 'none'` gerçek HTTP başlığında; clickjacking denemesi başarısız.
6. Üretim build çıktısında `.map` **yok**.
7. Giriş, davet, OAuth, e-posta, dosya akışlarında regresyon testi.

---

## 12) KAYNAK / KANIT DİZİNİ

- **CORS:** `supabase/functions/*/index.ts` (44 dosya) · kanonik: `supabase/functions/_shared/cors.ts`
  > ⚠️ `_shared/cors.ts` **yeni dosya olarak OLUŞTURULAMADI** (platform, `supabase/functions`
  > altında deploy dışı dosya yazımını engelliyor). Bu nedenle **otoriter kaynak = her
  > fonksiyondaki inline kopyalardır**; `_shared/cors.ts` yalnızca **referans/içerik
  > belgesidir** (Supabase CLI kullanan bir ortamda birebir oluşturulabilir).
- **CSP:** `index.html`
- **Build:** `vite.config.ts` (`build.sourcemap: true` — kilitli)
- **Env:** `.env` · Edge Secrets (`Deno.env`)
- **Test:** `supabase/tests/security/guv20_cors_csp.test.ts`
- **Deploy kanıtı:** `deploy_edge_function` çıktıları (44× `remote_deployed: true`, `verify_jwt: true`)

---

## 13) KAPANIŞ BEYANI

- **Kod + dağıtım DEĞİŞTİRİLDİ; 44/44 Edge Function canlıya alındı.**
- **Giderilen:** wildcard CORS (origin allowlist yansıması), CSP `'unsafe-eval'`,
  eksik CSP origin'leri, fonksiyon yanıtlarında eksik cache/nosniff başlıkları.
- **Engellenen/giderilemeyen:** `vite.config.ts` sourcemap (platform kilidi),
  HSTS/frame-ancestors/nosniff gerçek yanıt başlıkları (hosting erişimi yok).
- **Çalıştırılmayan testler / doğrulanamayan başlıklar BAŞARILI SAYILMADI.**
- Bu rapor **resmî sızma testinin yerine GEÇMEZ.**