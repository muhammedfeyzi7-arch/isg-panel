# IzgDenetim — PROMPT 3/8 · RLS, Veritabanı Yetkileri ve Tenant İzolasyonu Sertleştirme

**Tarih:** 2026-10-11 · **Backend:** SaaS Supabase · **Yöntem:** canlı salt-okuma metadata + migration dosyaları
**Kural uyumu:** RLS hiçbir tabloda kapatılmadı · üretim verisi değiştirilmedi · politikalar geçici gevşetilmedi · üretimde yıkıcı test yapılmadı.

---

## 1. Yönetici özeti

Sistemin veritabanı güvenlik duruşu **genel olarak güçlü**: 176/176 tabloda RLS açık, tüm SECURITY DEFINER fonksiyonlarda `search_path` sabitlenmiş, anon RPC yüzeyi yalnızca 22 bilinçli fonksiyona inmiş, anon/authenticated `BYPASSRLS` değil. **Uzaktan-kimliksiz sömürülebilir kritik bir açık bulunmadı.**

Bu turun asıl sertleştirme fırsatı **tablo düzeyi geniş GRANT'lar** (klasik Supabase varsayılanı):
anon ve authenticated, 176 tablonun **tamamında** `arwdDxtm` yetkisine — yani **RLS tarafından korunmayan `TRUNCATE`** ve gereksiz `REFERENCES/TRIGGER/MAINTAIN` — sahipti.

**Canlı uygulanan (bu turda):**
- ✅ `ALTER DEFAULT PRIVILEGES FOR ROLE postgres` → yeni tablolara yalnızca RLS-denetimli 4 yetki (SELECT/INSERT/UPDATE/DELETE). `[F-17-03]`
- ✅ `profiles_update_own` politikasına açık `WITH CHECK (id = auth.uid())` eklendi. `[F-17-04]`

**Kullanıcı tarafından uygulanması gereken (platform çalıştırıcısı GRANT/REVOKE'i bloklar):**
- ⏳ Mevcut 176 tablodan `TRUNCATE/REFERENCES/TRIGGER/MAINTAIN` kaldırma. `[F-17-01]`
- ⏳ Hassas sequence'lerden anon USAGE kaldırma. `[F-17-02]`
- ⏳ `supabase_admin` default privileges (süper kullanıcı gerekir). `[F-17-03]`

Migration + rollback + test dosyaları hazır: `supabase/migrations/20260101001100_guv17_least_privilege_grants.sql`, ilgili rollback ve `supabase/tests/security/guv17_least_privilege.test.sql`.

---

## 2. Veritabanı envanteri (canlı)

| Nesne | Sayı | Not |
|---|---|---|
| Tablo (relkind='r') | 176 | **RLS 176/176 açık** |
| View / materialized view / foreign table | 0 | Görünüm tabanlı sızma yüzeyi yok |
| RLS politika | 563 | 9'u RESTRICTIVE (guard) |
| RLS açık + politika YOK | 16 | **Default-deny** (güvenli): `mail_credentials`, `mail_oauth_states`, sayaç/tutanağı reservasyon tabloları vb. |
| SECURITY DEFINER fonksiyon | 167 | **search_path eksik = 0** (tamamı sabit) |
| → anon EXECUTE edebilen definer (non-trigger) | 22 | Hepsi bilinçli: RLS yardımcıları + public teklif/destek akışı |
| Sequence | 3 | `tutanak_no_seq`, `system_logs_id_seq`, `support_ticket_seq` |
| Trigger (örnek) | profiles: `profile_lock_role_trigger`, `set_profiles_updated_at` | Rol/tenant kilidi aktif |

**Rol üyeliği (canlı doğrulandı):** `anon`, `authenticated`, `service_role` → `BYPASSRLS = false` ✅. `postgres`/`service_role` bypass eder (beklenen).

---

## 3. Doğrulanmış bulgular

### F-17-01 · Geniş tablo yetkileri — RLS-bypass eden TRUNCATE · **ORTA→YÜKSEK** · Uygulama: BEKLİYOR
- **Etkilenen:** tüm public tablolar (176), roller `anon` + `authenticated`.
- **Teknik kanıt (canlı):** `information_schema.table_privileges` → `anon` TRUNCATE=176, SELECT=176; tablo ACL `{postgres=arwdDxtm,anon=arwdDxtm,authenticated=arwdDxtm,service_role=arwdDxtm}`. `has_table_privilege('anon','public.firmalar','TRUNCATE') = true`.
- **Etki:** `TRUNCATE` RLS'e TABİ DEĞİLDİR (satır politikaları devreye girmez). PostgREST doğrudan TRUNCATE sunmasa da bu gereksiz yetki, ileride bir RPC/yanlış yapılandırma/SQL yüzeyi açığa çıkarsa **tüm tenant verisinin toplu yok edilmesine** kapı aralar. `REFERENCES/TRIGGER/MAINTAIN` istemci için tamamen gereksiz.
- **İstismar ön koşulu:** TRUNCATE çağırabilecek bir yüzey (şu an bilinen yok) + anon/authenticated oturumu.
- **Düzeltme:** GUV-17 Part A — REVOKE ALL + 4 yetkiyi geri verme (net: yalnızca `TRUNCATE/REFERENCES/TRIGGER/MAINTAIN` kalkar; RLS kontrol modeli korunur).
- **Tekrar test:** `SELECT count(*) ... WHERE has_table_privilege('anon', c.oid,'TRUNCATE')` → **0**.

### F-17-02 · anon'un hassas sequence USAGE'i · **DÜŞÜK-ORTA** · Uygulama: BEKLİYOR
- **Etkilenen:** `anon`, sequence `tutanak_no_seq`, `system_logs_id_seq`, `support_ticket_seq`.
- **Teknik kanıt (canlı):** `usage_privileges` → üçünde de `anon USAGE = true`; ACL `{...,anon=rwU,...}`.
- **Etki:** anon, `nextval()` ile sequence tüketebilir (tutanak numarası boşluğu / log ID enflasyonu). Doğrudan veri sızdırmaz; düşük şiddet.
- **Düzeltme:** GUV-17 Part B — `tutanak_no_seq` ve `system_logs_id_seq` üzerinde anon/PUBLIC yetkisi kaldırılır (meşru yazma definer RPC'den geçer). `support_ticket_seq` public destek akışı için muhafazakâr bırakıldı.
- **Tekrar test:** `has_sequence_privilege('anon','public.tutanak_no_seq','USAGE')` → **false**.

### F-17-03 · Default privileges yeni nesnelere geniş yetki veriyordu · **ORTA** · Uygulama: KISMEN CANLI
- **Etkilenen:** `pg_default_acl` — rolleri `postgres` ve `supabase_admin`, şema `public`.
- **Teknik kanıt (canlı):** başlangıçta `anon=arwdDxtm` / `authenticated=arwdDxtm` (tablolar). Yani **her yeni tablo otomatik RLS-bypass yetkisiyle doğuyordu** (kök neden).
- **Etki:** F-17-01'in yapısal kaynağı; tablo eklemeleriyle açık kendini yeniden üretir.
- **Düzeltme:** GUV-17 Part C.
  - ✅ **`postgres` için CANLI UYGULANDI** → `anon=arwd`, `authenticated=arwd` (RLS-bypass yetkileri kalktı).
  - ⏳ **`supabase_admin` için uygulanamadı** → `ERROR 42501: permission denied to change default privileges` (süper kullanıcı gerekir). Kullanıcı Supabase Dashboard'da yükseltilmiş yetkiyle uygulamalı.
- **Tekrar test:** `pg_default_acl` içinde `anon`/`authenticated` ACL'inde `D/x/t/m` bulunmamalı.

### F-17-04 · `profiles_update_own` açık WITH CHECK yokluğu · **DÜŞÜK / BİLGİ** · Uygulama: CANLI ✅
- **Etkilenen:** politika `profiles_update_own` (tablo `profiles`).
- **Teknik kanıt (canlı, uygulama öncesi):** `polwithcheck = NULL`, `polqual = (id = auth.uid())`.
- **Değerlendirme:** **Gerçek açık DEĞİL** — (a) PostgreSQL, `WITH CHECK` belirtilmediğinde `USING` ifadesini yeni-satır kontrolü için de uygular (dokümante davranış); (b) `profile_lock_role` trigger'ı `role`, `osgb_id` ve `firma_id` değişimini birlikte engeller (canlı gövde doğrulandı). Yani rol/tenant yükseltmesi iki katmanla kapalı.
- **Düzeltme:** Auditability için açık `WITH CHECK (id = auth.uid())` eklendi → **CANLI UYGULANDI** ✅.
- **Tekrar test:** `profiles_update_own.polwithcheck` boş olmamalı.

### F-17-05 · IBYS global referans satırları çok-tenantlı yazılabilir · **DÜŞÜK** · Uygulama: İNCELEME
- **Etkilenen:** `ibys_referans_eslesmeleri` INSERT/UPDATE politikaları (`ibys_referans_insert_osgb`, `ibys_referans_update_osgb`).
- **Teknik kanıt (canlı):** `WITH CHECK = (auth_role()='osgb_admin' AND (osgb_id IS NULL OR osgb_id = auth_osgb_id()))`. `osgb_id IS NULL` dalı, herhangi bir OSGB yöneticisinin **global (tüm tenantlarca okunan)** referans satırı oluşturmasına izin verir; DELETE politikaları da benzer kapsamda.
- **Etki:** Tenant, diğer tenantları etkileyen global referans kaydı ekleyebilir/değiştirebilir (izolasyon ihlali, düşük şiddet; veri sızıntısı yok).
- **Düzeltme önerisi:** Global (`osgb_id IS NULL`) yazma yalnızca `admin`'e kısıtlanmalı; `osgb_admin` yalnızca kendi `osgb_id` kapsamında yazabilmeli.
- **Tekrar test:** anon ve tenant-olmayan kullanıcı global referans satırı eklemeye çalışınca RLS reddi.

---

## 4. Doğrulanmış güçlü taraflar (canlıdan)

- **RLS:** 176/176 tablo açık; 16 tablo politika-yok = default-deny (istenen davranış).
- **SECURITY DEFINER:** 167/167 fonksiyonda `search_path` sabit (0 eksik) → search_path hijacking kapalı.
- **anon RPC yüzeyi:** yalnızca 22 non-trigger definer; hepsi meşru (RLS yardımcıları, public teklif/destek).
- **Restrictive guard'lar (9):** `osgb_access_ok()` → `atamalar`, `evraklar`, `firmalar`, `personeller`; `teklifler`/`teklif_hizmetleri` tenant restrictive; `evraklar` client write-deny.
- **Anon yazma kapalı:** anon'a özel (yalnız-anon) yazma politikası YOK; PUBLIC yazma politikaları `auth_role()` (anon'da NULL) ile bloke.
- **Rol yükseltme kapalı:** `profile_lock_role` trigger'ı rol/osgb/firma üçlüsünü kilitler.
- **Global referans yazmaları:** `nace_kodlari`, `isg_kurallari`, `mevzuat_kaynaklari`, `myk_*`, `occupations` write politikaları `auth_role()='admin'` ile sınırlı.
- **Referans okuma geniş** (`USING(true)`, 15 tablo) ancak **PII içermez** (NACE/MYK/meslek mevzuat referansları) — kabul edilebilir.

---

## 5. Doğrulanamayan / başarı sayılmayan

- **Runtime IDOR / cross-tenant erişim testi:** izole iki-tenant ortamı yok, üretimde yıkıcı test yasak → değerlendirme statik + metadata.
- **GUV-17 Part A/B canlı uygulaması:** platform SQL çalıştırıcısı `GRANT/REVOKE` ifadelerini güvenlik gereği bloklar → uygulama kullanıcıya bırakıldı.
- **`supabase_admin` default privileges:** yetki yok (42501).
- **pgTAP testleri (`guv17_*`):** izole ortam/extension yok → çalıştırılmadı; yalnızca syntax-check geçti.
- **Auth Dashboard ayarları** (parola politikası, rate-limit) ve **per-function `verify_jwt`** (workspace `config.toml` yok): doğrulanamadı.
- **Klasik CSRF / istemci SQLi:** bu mimaride **N/A** (Bearer JWT + parameterized PostgREST).

---

## 6. Düzeltme ve uygulama planı

### Uygulanması gereken (madde sırasıyla)
1. Supabase Dashboard → **SQL Editor** → `supabase/migrations/20260101001100_guv17_least_privilege_grants.sql` içeriğini çalıştır
   *(veya `supabase db push`)* → F-17-01, F-17-02 ve Part-C/supabase_admin tamamlanır.
2. Yükseltilmiş yetkiyle `supabase_admin` default privileges düzeltmesi (F-17-03).
3. F-17-05 için `ibys_*` global yazma politikalarının `admin`'e daraltılması (ayrı migration).

### Geri alma
`supabase/migrations/rollback/20260101001100_guv17_least_privilege_grants_rollback.sql` (GRANT ALL + policy recreate).

### Regresyon doğrulaması (uygulama sonrası)
- `SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
   WHERE n.nspname='public' AND c.relkind='r' AND has_table_privilege('anon', c.oid,'TRUNCATE')` → **0**
- `has_sequence_privilege('anon','public.tutanak_no_seq','USAGE')` → **false**
- `profiles_update_own.polwithcheck` → boş değil
- **Fonksiyonel:** panel CRUD (anon/authenticated SELECT/INSERT/UPDATE/DELETE korunur), public teklif/destek akışı, Edge Function (service_role) RPC'leri çalışmaya devam etmeli.

---

## 7. Önceki raporlarla tutarlılık

| Önceki iddia | Bu turun sonucu |
|---|---|
| 176 tabloda RLS açık | ✅ **doğrulandı** (176/176) |
| anon definer RPC çelişkisi (77 vs 22) | ✅ **doğrulandı = 22** (trigger-döndürenler hariç, hepsi bilinçli) |
| 167 definer search_path sabit | ✅ **doğrulandı** (eksik = 0) |
| `osgb_access_ok()` NULL dalı kaldırıldı | ✅ restrictive guard'larda canlı çalışıyor |
| `profile_lock_role` yükseltmeyi engeller | ✅ **doğrulandı** (role+osgb_id+firma_id) |
| CORS/CSP/xlsx/jsPDF bağımlılık CVE'leri | Bu turun kapsamı dışı — ayrı raporlarda |