# Bağımlılık Güvenlik Triyajı (npm audit) — 2026-10-13

## Özet

Pentest günü hazırlığında `npm audit` çalıştırıldı.

```
ÖNCE:  16 vulnerabilities (7 moderate, 9 high)
SONRA: 12 vulnerabilities (7 moderate, 5 high)   ✅ (sunucuda doğrulandı)
```

`firebase` kaldırıldıktan sonra `high` sayısı **9 → 5**'e düştü ve kalan 5
`high`'ın tamamı yalnızca `tailwindcss` **build** zincirinden gelmektedir
(production bundle'a girmez). 9 `high` bulgunun tamamı iki transitif zincirden
geliyordu; aşağıda her biri için durum ve gerekçeli karar kayıtlıdır.

> Sunucu doğrulaması (`pentest_gunu/01_npm_audit.sh`, 2026-10-13):
> `npm ci` sonrası TAM kapsam `12 vulnerabilities (7 moderate, 5 high)`;
> ÜRETİM kapsamı (`--omit=dev`) `5 moderate, 0 high` → **GEÇTİ**.
> (Script iyileştirildi: artık npm'in yeni `N vulnerabilities (...)` özet satırını da
> yakalar; ayrıca `--omit=dev` adımı ve otomatik **GEÇTİ/DİKKAT** kararı eklendi.)

---

## 1) Kullanılmayan `firebase` bağımlılığı — DÜZELTİLDİ ✅

`firebase@12.0.0`, `dependencies` altında duruyordu ancak **kaynak kodun hiçbir
yerinde import edilmiyordu** (yalnızca dokümanlar ve `package.json` içinde geçiyordu).

Bu tek ölü bağımlılık, aşağıdaki 4 `high` bulgunun kaynağıydı:

| Paket | Bulgu |
| --- | --- |
| `firebase` | @firebase/firestore, @firebase/firestore-compat |
| `@firebase/firestore` | @grpc/grpc-js |
| `@firebase/firestore-compat` | @firebase/firestore |
| `@grpc/grpc-js` | GHSA-m9gg-hp2v-232j, GHSA-f596-whhp-79r4 |

**Karar:** Kullanılmayan `firebase` bağımlılığı `package.json`'dan kaldırıldı.
Build doğrulandı (başarılı). Bu sayede 4 `high` bulgu tamamen ortadan kalktı.

> Not: `npm audit`'in önerdiği "düzeltme" (`firebase@9.14.0`) mevcut sürümden
> **daha eski** bir sürümdür; advisory veritabanının `@grpc/grpc-js` kaynaklı
> hatalı eşleşmesidir. Bu nedenle `npm audit fix --force` **kullanılmamıştır**.

---

## 2) `tailwindcss` build zinciri — BELGELENMİŞ RİSK (kabul edildi)

Aşağıdaki 5 `high` bulgu, `tailwindcss` (devDependency) zincirinden gelmektedir:

| Paket | Bulgu |
| --- | --- |
| `tailwindcss` | chokidar, fast-glob, micromatch, postcss-nested, postcss-selector-parser |
| `chokidar` | braces |
| `braces` | GHSA-vfj7-8cjw-p6xm (derin iç içe desenlerde stack exhaustion DoS) |
| `micromatch` | braces |
| `fast-glob` | micromatch |

**Bu paketlerin tamamı devDependency / build-time araçlarıdır.** Tailwind bir
**build aracıdır** ve bu transitif paketlerin hiçbiri tarayıcıya gönderilen
production bundle'ına girmez. Dolayısıyla çalışma zamanında (runtime) exploit
edilebilirlik pratikte sıfırdır.

`npm audit fix --force` bu bulguları yalnızca `tailwindcss@4.x`'e yükselterek
"kapatır" ki bu, **v3 → v4 kırıcı bir yeniden yazımdır** ve mevcut
`tailwind.config.ts`, StyleSystem token yapısı ve tüm stil sistemini kırar.
Üretim kararlılığı açısından bu yol tercih edilmemiştir.

**Karar:** Belgelenmiş risk olarak kabul edildi (build-time only, non-runtime).

---

## 3) Moderate bulgular (7 adet — 3 danışı)

| Paket | Bağımlı | Not |
| --- | --- | --- |
| `postcss-selector-parser` `<7.1.6` | postcss-nested → tailwindcss (build) | Build-time; runtime'a girmez |
| `sprintf-js` | mammoth → argparse | Unmaintained; etkilenen `sprintf` hassas format yolu uygulamada kullanılmıyor |
| `uuid` `<11.1.1` | exceljs | Etkilenen yol (v3/v5/v6 + `buf`) kullanılmıyor; uygulama `v4()` kullanır |

**Karar:** Yukarıdakilerle aynı gerekçe (build-time veya ulaşılamayan kod yolu);
`npm audit fix --force` kırıcı olduğu için uygulanmadı, izlemeye alındı.
`overrides` ile zorlama yükseltme (ör. `uuid@11`) `exceljs` API'sini kırma riski
taşıdığından tercih edilmedi.

---

## Doğrulama Komutları (kanıt)

```bash
# Tam audit
npm audit --audit-level=high | tee /tmp/npm_audit.txt

# Yalnızca production bağımlılıkları (deploy edilen ürün)
npm audit --omit=dev | tee /tmp/npm_audit_prod.txt
```

### Doğrulanmış sonuçlar (2026-10-13)

| Kapsam | Bulgu | Not |
| --- | --- | --- |
| Tam audit (`npm audit`) | **12** (7 moderate, **5 high**) | 5 high'ın tamamı `tailwindcss` **build** zinciri |
| **Production (`--omit=dev`)** | **5 moderate, 0 high** ✅ | Yalnızca `sprintf-js` + `uuid`; build zinciri ve firebase **yok** |

> **Kritik kanıt:** Deploy edilen ürünün bağımlılıklarında **hiç `high` bulgu yoktur.**
> Audit'te görünen 5 high yalnızca devDependency / build-time zincirine aittir ve
> `--omit=dev` çıktısında görünmez.

### Kalan production moderate (2 danışı) — DÜZELTİLEMEZ, belgelenmiş risk

Her iki paket de **zaten en güncel doğrudan bağımlılıklarının** içinden geliyor:

- `mammoth@1.12.2` (güncel) → `argparse` → `sprintf-js@1.0.x`
- `exceljs@4.4.0` (güncel) → `uuid@8.3.2`

Doğrudan sürüm yükseltmesiyle çözüm yoktur; `npm audit fix --force` ise mammoth/exceljs'i
**eski** sürümlere düşürerek (mammoth@0.3.29, exceljs@3.4.0) üretimi kırar. Etkilenen
kod yolları (sprintf hassas format dizeleri; uuid `v3/v5/v6` + `buf` argümanı)
uygulamada kullanılmamaktadır (uygulama `uuid.v4()` kullanır). Bu nedenle izlemeye alındı.

---

## Sonuç

- **4 `high` bulgu → kalıcı olarak kapatıldı** (kullanılmayan `firebase` kaldırıldı).
  Sunucuda birebir doğrulandı: `high` sayısı **9 → 5**.
- **Kalan 5 `high` + 7 moderate → gerekçeli belgelenmiş risk** (build-time,
  non-runtime; `--force` üretimi kıracağı için uygulanmadı).
- Asıl kanıt için `npm audit --omit=dev` ile production-only görünüm alınmalı;
  burada `firebase` ailesinin ve build-time zincirin **görünmemesi** beklenir.