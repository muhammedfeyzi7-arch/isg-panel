# İSGDenetim — Storage Sertleştirme Raporu (GUV-23) · 2026-10-12

> **Yöntem:** Canlı Supabase'de **salt-okuma** `SELECT` (pg_policies / storage.buckets)
> ile mevcut durum doğrulandı; ardından yalnızca **rol daraltması** uygulandı ve
> tekrar salt-okuma ile **kanıtlandı**.
>
> **Kapsam:** Uygulama kodu değişmedi. Yalnızca 6 storage policy'nin rolü daraltıldı.

---

## 1) Tespit — Storage genel durumu (canlı)

- Toplam **16 bucket**; **14'ü private**, yalnızca `avatars` ve `osgb-logos` public
  (profil fotoğrafı + logo → public URL ile okunur; bu kasıtlıdır).
- **Çekirdek dosya bucket'ları** (`atama-belgeleri`, `personel-foto`, `hazop-kanitlari`,
  `noter-defteri`) → **tenant izolasyonu aktif**. `public.storage_tenant_ok(text,text)`
  fonksiyonu `SECURITY DEFINER` + `search_path=public` ile sabitli. (GUV-01 uygulanmış.)
- Diğer bucket'ların çoğunda istemci policy'si **yok** → **varsayılan DENY**; erişim
  edge function'lar üzerinden `service_role` ile. Doğru "least privilege" deseni.

## 2) Bulgu — "En dar rol" ihlali (gerçek sızıntı YOK)

Şu 6 policy `{public}` rolüne (anon dahil) verilmişti:

| Bucket | Policy | İşlem |
|---|---|---|
| avatars | avatars_obj_insert | INSERT |
| avatars | avatars_obj_delete | DELETE |
| osgb-logos | osgb_logos_insert | INSERT |
| osgb-logos | osgb_logos_delete | DELETE |
| support | support_obj_insert | INSERT |
| support | support_obj_read | SELECT |

**Neden sızıntı değil:** Gövdeler zaten `auth.uid()` / `auth_role()` şartı taşıyor →
anon (`auth.uid()=NULL`) hiçbir kuralı geçemiyordu.
**Neden yine de düzeltildi:** "policy rolü public/anon" satırı, sızma testi raporlarında
"en dar yetki ilkesi ihlali" olarak işaretlenir.

## 3) Uygulanan düzeltme (GUV-23)

- Migration: `supabase/migrations/20260101001300_guv23_storage_policy_least_role.sql`
- Rollback: `supabase/migrations/rollback/20260101001300_guv23_storage_policy_least_role_rollback.sql`
- İşlem: İlgili 6 policy `TO authenticated` olarak yeniden atandı. **USING/WITH CHECK
  gövdeleri DEĞİŞMEDİ.**

## 4) Kanıt (uygulama sonrası salt-okuma)

- 6 policy → `roles = {authenticated}` ✅
- `SELECT ... WHERE roles::text LIKE '%public%'` → **0 satır** ✅ (storage.objects'ta
  public/anon rolü kalmadı)

## 5) Davranış / işlevsellik etkisi

- **Etkilenen işlev YOK.** Bu bucket'lara yazan tüm akışlar giriş yapmış kullanıcıdır
  (profil avatarı, OSGB logosu, destek bileti eki). Public bucket okumaları RLS dışı
  public URL üzerinden devam eder.
- Geri dönüş: rollback dosyası rolü `{public}`'e döndürür (tek komut).

---

Bu doküman resmî TSE onaylı sızma testinin yerine geçmez; yalnızca yapılan kontrol ve
kanıtını kaydeder.