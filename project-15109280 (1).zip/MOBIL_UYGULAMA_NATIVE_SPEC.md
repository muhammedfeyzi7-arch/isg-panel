# IBYS / ISG Yönetim Sistemi — Native Mobil Uygulama Şartnamesi

Bu doküman, mevcut web tabanlı IBYS/ISG yönetim sisteminin **gerçek native mobil uygulaması** (iOS + Android, mağazada yayınlanacak) için hazırlanmış teknik ve operasyonel şartnamedir. Bir geliştiriciye veya AI uygulama üreticisine (Emergent vb.) verilmek üzere yazılmıştır.

Tarih: 2026-10-22

---

## 1. Amaç

Mevcut web sisteminin saha kullanımına uygun, mağazadan indirilebilen native bir mobil uygulamasını üretmek. Uygulama **yeni bir backend kurmayacak**, mevcut self-hosted Supabase altyapısını kullanacak.

Kapsamdaki roller: `admin`, `osgb_admin`, `uzman`, `hekim`, `firma` (personel/firma kullanıcısı).

---

## 2. Kritik Mimari Karar (En Önemli Madde)

**Mevcut backend yeniden kullanılacaktır. Yeni backend kurulmayacaktır.**

- Backend: self-hosted Supabase (Docker, `/opt/ibys/supabase/docker`), PostgREST + GoTrue (Auth) + Storage + Edge Functions.
- Mobil istemci yalnızca **anon key + kullanıcı JWT** ile bağlanır.
- `service_role` anahtarı **asla** mobil uygulamaya gömülmez. Gömülen her service_role anahtarı = tüm veritabanı.
- **Güvenlik sınırı yalnızca RLS politikalarıdır.** Mobil uygulama, web uygulamasının gördüğü veriden fazlasını göremez; RLS neyi verirse o.
- Mevcut Edge Function'lar (davet, mail, tutanak, ekipman, evrak, zimmet, ziyaret-planlama, saha-denetim, risk-ai vb.) aynen kullanılır; mobil tarafta yeniden yazılmaz.
- Multi-tenant yapı korunur: `osgb_id` / `firma_id` kapsamı RLS ile zorunlu. Mobil tarafta tenant filtresi "kolaylık" içindir, güvenlik sayılmaz.

**Yapılmaması gerekenler:**
- Mobil için ayrı bir veritabanı kurmak.
- Mobil uygulamada doğrudan SQL / DB kullanıcısı ile bağlanmak.
- service_role anahtarını uygulama içine gömmek.
- İş kurallarını (yetki, kapsam, hesaplama) mobilde tekrar yazmak; edge function'ı çağırmak varken mobilde yeniden hesaplamak.

---

## 3. Teknoloji Önerisi

**Birincil öneri: React Native + Expo + TypeScript**

Nedenleri:
- Mevcut ekip React/TypeScript biliyor, kod mantığı taşınabilir.
- Expo EAS ile iOS ve Android için mağazaya hazır paket üretimi tek komutla yapılır.
- Kamera, QR/barkod, konum, push notification, dosya seçici, secure storage gibi native ihtiyaçlar hazır modüllerle karşılanır.
- Expo Router ile rol bazlı navigasyon temiz kurulur.

Alternatif: Flutter (tek kod tabanı, güçlü performans, ama ekip React biliyor).

**WebView sarmalayıcı ("siteyi kutuya koy") yaklaşımı önerilmez.** Apple App Store 4.2 (Minimum Functionality) maddesi gereği yalnızca web sitesini gösteren uygulamalar reddedilir. Gerçek native ekranlar üretilmelidir.

---

## 4. Kimlik Doğrulama ve Oturum

- Supabase Auth (GoTrue) üzerinden e-posta + şifre girişi.
- Access token + refresh token **SecureStore / Keychain** içinde saklanır (AsyncStorage kullanılmaz).
- Token yenileme Supabase istemcisinin kendi mekanizmasıyla yapılır.
- Şifre sıfırlama: mevcut `send-reset-email` edge function'ı kullanılır.
- Şifre politikası ve şifre geçmişi kuralları backend'de; mobil tarafta tekrar yazılmaz.
- İsteğe bağlı: Face ID / parmak izi ile hızlı giriş (yalnızca cihaz üzerinde kilit açma, token yine SecureStore'da).
- Oturum süresi / boşta kalma politikası mevcut `SessionPolicyGuard` mantığıyla uyumlu olmalı.

**Güvenlik notu:** Mevcut profil/rol yükseltme korumaları (kolon yetkileri, `ROLE_LOCK` trigger'ları, `auth_role()` kapıları) backend'de duruyor. Mobil uygulama bu kapıları atlayamaz; mobilde ayrıca yetki kontrolü yazmak zorunlu değil, sadece UX için menü gizleme yapılır.

---

## 5. Rol Bazlı Navigasyon (Alt Sekme Yapısı)

Her rol için ayrı tab yapısı. Maksimum 5 sekme + "Diğer" menüsü.

**`uzman` (sahada en yoğun kullanıcı)**
1. Genel Bakış
2. Firmalarım
3. Ziyaretler (bugünkü program + ziyaret başlat/bitir)
4. Saha Denetimleri
5. Diğer → Tutanaklar, Ekipmanlar (QR), Evraklar, Personeller, Mesajlaşma, Bildirimler, Destek

**`hekim`**
1. Genel Bakış
2. Muayeneler
3. Tetkik & Tahliller
4. Planlama
5. Diğer → Tutanaklar, Sağlık Evrakları, Personeller, Mesajlaşma

**`firma` (firma personeli)**
1. Genel Bakış
2. Personellerim
3. Evraklar
4. Saha Denetimleri / Tutanaklar
5. Diğer → Ekipmanlar, Zimmetlerim, Mesajlaşma, Bildirimler

**`osgb_admin`**
1. Genel Bakış
2. Firmalar
3. Atamalar
4. Personeller / Ziyaret Planlama
5. Diğer → Teklifler, Zimmet/Envanter, Mesajlaşma, Bildirimler, Destek

**`admin`**
- Genel Bakış, OSGB'ler, Loglar, Meslek/Evrak Yönetimi, Bildirimler, Destek.

---

## 6. Modül Kapsamı

### Faz 1 — MVP (ilk sürümde olması gerekenler)

Sahada gerçekten kullanılan, mobilde anlamlı olan modüller:

| Modül | Mobilde beklenen davranış |
|---|---|
| Giriş / oturum | E-posta + şifre, biyometrik kilit, şifre sıfırlama |
| Bildirimler | Push + uygulama içi liste, okundu işaretleme, detaya gitme |
| Ziyaretler | Bugünkü program, ziyaret başlat (konum), ziyaret bitir, süre kaydı, geçmiş |
| Saha Denetimleri | Uygunsuzluk listesi, yeni uygunsuzluk (kamera + konum), kapatma talebi |
| Ekipmanlar (QR) | QR okut → ekipman kartı, kontrol ekle, bakım ekle, fotoğraf |
| Evraklar | Liste, filtre, PDF/görsel önizleme, indirme/paylaşma |
| Personeller | Liste, arama, detay, sağlık/mesleki belge durumu (rol yetkisi kadar) |
| Tutanaklar | Liste + görüntüleme; is kazası / ramak kala / tehlikeli olay sihirbazları Faz 2 |
| Mesajlaşma | Sohbet listesi, mesaj gönder, dosya/fotoğraf ekle, okundu |
| Destek | Talep oluştur, ekran görüntüsü/dosya ekle, geçmiş |
| Ayarlar | Profil, avatar, şifre değiştir, bildirim tercihleri, çıkış, hesap silme |

### Faz 2

- Risk analizi sihirbazları (Fine-Kinney, HAZOP, acil durum, çalışma, eğitim)
- ISG kurulu sihirbazı
- Teklif oluşturma/PDF
- IBYS bildirim kuyruğu
- ISG-Katip entegrasyonu (mobilde büyük olasılıkla sadece durum/özet)
- Rapor üretimi (PDF/Word/Excel) — üretim backend'de, mobilde sadece görüntüleme + paylaşma
- Envanter/zimmet detaylı akışları

---

## 7. Offline Stratejisi (Saha için Kritik)

Sahada internet zayıf olabilir. Aşağıdakiler **çevrimdışı çalışmalı, bağlantı gelince kuyruğa alınıp gönderilmeli**:

- Ziyaret başlat / bitir (zaman damgası + GPS noktası cihazda saklanır)
- Saha denetimi uygunsuzluk kaydı (fotoğraf dahil)
- Ekipman kontrol kaydı (QR okutma + fotoğraf)
- Serbest not / tutanak taslağı

Teknik yaklaşım:
- Yerel kuyruk: SQLite (expo-sqlite) veya WatermelonDB. Her kayda `client_id` (uuid), `created_at_device`, `sync_state` alanları.
- Fotoğraflar cihazda sıkıştırılıp kuyruğa alınır, bağlantı gelince Storage'a yüklenir, sonra DB kaydı tamamlanır.
- Çakışma: sunucu zaman damgası kazanır, cihaz kaydı "senkronize edildi" olarak işaretlenir; reddedilen kayıt kullanıcıya görünür hata olarak döner.
- Kullanıcıya her zaman görünür senkronizasyon durumu (bekliyor / gönderiliyor / hata).

---

## 8. Native Yetenekler

| Yetenek | Kullanım | Not |
|---|---|---|
| Kamera | Uygunsuzluk fotoğrafı, ekipman fotoğrafı, evrak tarama | Yükleme öncesi sıkıştırma, boyut limiti |
| QR / Barkod | Ekipman kartına hızlı erişim | Mevcut QR etiketleriyle uyumlu |
| Konum | Ziyaret başlat/bitir, geofence doğrulama | Arka planda sürekli takip YAPILMAZ, yalnızca işlem anında |
| Push | Bildirim, ziyaret hatırlatma, onay | FCM + APNs, kullanıcı bazlı token kaydı |
| Dosya seçici | Evrak yükleme | PDF, görsel, Word/Excel |
| PDF görüntüleme | Tutanak, teklif, rapor önizleme | Cihaz içi render |
| Paylaşım | Üretilen belgeyi WhatsApp/e-posta ile gönderme | Native share sheet |
| Biyometrik | Uygulama kilidi | Yalnızca cihaz kilidi |

---

## 9. Arayüz Kuralları

- Mobil öncelikli, tek elle kullanım. Minimum dokunma hedefi 44x44 px.
- Alt sekme çubuğu sabit; içerik kaydırılabilir.
- Liste ekranlarında sonsuz kaydırma (pagination), arama, filtre.
- Form ekranları adım adım (wizard) — saha kullanımında tek ekranda 10 alan doldurulmaz.
- Boş durum, yükleme iskeleti ve hata + "tekrar dene" her listede zorunlu.
- Renk paleti mevcut web temasıyla uyumlu; koyu mod desteklenir.
- Türkçe arayüz. Tarih formatı `dd.MM.yyyy`, para birimi `₺`.

---

## 10. Mağaza Yayın Gereksinimleri

### Hesaplar ve ücretler

- **Apple Developer Program**: yıllık ücretli üyelik. Kurumsal (şirket) hesap için D-U-N-S numarası gerekir.
- **Google Play Console**: tek seferlik kayıt ücreti. Kişisel geliştirici hesapları için kapalı test şartı vardır (belirli sayıda test kullanıcısı + belirli süre), kurumsal hesapta bu şart yok.
- Ücret tutarlarını yayın öncesi güncel olarak doğrula; Apple ve Google bu bedelleri değiştirebiliyor.

### Zorunlu belgeler ve ekranlar

- Gizlilik Politikası (herkese açık URL)
- KVKK Aydınlatma Metni ve açık rıza akışları
- **Hesap silme** akışı (Apple zorunlu kılıyor: uygulama içinden hesap silinebilmeli)
- Apple App Privacy detayları (hangi veri toplanıyor, hangi amaçla)
- Google Play Data Safety formu
- Uygulama ikonu, açılış ekranı, ekran görüntüleri (her iki mağaza için ayrı boyutlar)
- Destek iletişim adresi

### Bu projeye özel hassas veri notları

Sistemde **TC kimlik numarası, sağlık muayenesi, tetkik/tahlil sonuçları, mesleki belgeler** var. Bu, mağaza denetimlerinde "hassas veri" olarak değerlendirilir.

- Veriler yalnızca HTTPS üzerinden taşınır (mevcut altyapı zaten TLS).
- Cihazda saklanan veriler şifreli olmalı (SecureStore / şifreli SQLite).
- Sağlık verisi ekranlarında ekran görüntüsü engelleme (Android `FLAG_SECURE`) değerlendirilmeli.
- TCKN ekranlarda maskeli gösterilmeli (mevcut backend zaten maskeli view sunuyor, mobilde de maskeleme korunur).
- Uygulama içi log / crash raporlarına kişisel veri yazılmaz.
- KVKK kapsamında veri işleme amaçları ve saklama süreleri yazılı olmalı.

### Yayın akışı

1. Backend erişimi doğrulanır (mobil cihazdan Supabase Auth + PostgREST + Storage + Edge Function testleri).
2. Expo EAS ile imzalı build üretilir (iOS için sertifika + provisioning profile, Android için keystore).
3. TestFlight (iOS) ve Play kapalı test (Android) ile iç test.
4. Mağaza formları doldurulur, incelemeye gönderilir.
5. Yayın sonrası sürüm takibi: OTA güncelleme (Expo Updates) ile JS katmanı, mağaza güncellemesi ile native katman.

---

## 11. Güvenlik Kontrol Listesi (Yayın Öncesi Zorunlu)

- [ ] Uygulama paketinde `service_role` anahtarı yok.
- [ ] Tüm girişler RLS'e tabi; mobilde "filtre var" diye güvenlik varsayılmıyor.
- [ ] Token'lar SecureStore'da, AsyncStorage'da değil.
- [ ] Sertifika sabitleme (certificate pinning) değerlendirildi.
- [ ] Kök/jailbreak tespiti (opsiyonel, kurumsal dağıtımda önerilir).
- [ ] Derin bağlantı (deep link) ile gelen parametreler doğrulanıyor (IDOR riski).
- [ ] Offline kuyrukta bekleyen veriler cihazda şifreli.
- [ ] Fotoğraf/dosya yüklemede tip ve boyut doğrulaması istemcide de yapılıyor.
- [ ] Log ve crash raporlarında kişisel veri yok.
- [ ] Test hesapları mağaza incelemesi için hazır (demo kullanıcı + şifre).

---

## 12. AI Uygulama Üreticisine Verilecek Brief (Kopyala-Yapıştır)

Aşağıdaki metni, native uygulamayı ürettireceğin araca olduğu gibi ver. Kısa ve kararlı tutuldu; araç kendi backend'ini kurmaya kalkarsa bu metin onu durdurur.

---

Bir ISG/OSGB yönetim sistemi için iOS ve Android native mobil uygulama üret. React Native + Expo + TypeScript kullan. Uygulama mağazada yayınlanacak, gerçek native ekranlar olacak, WebView sarmalayıcı kullanma.

Backend: MEVCUT bir self-hosted Supabase kurulumu var (Auth, PostgREST, Storage, Edge Functions). Yeni backend kurma, yeni veritabanı şeması oluşturma, Supabase projesi oluşturma. Yalnızca anon key + kullanıcı JWT ile mevcut Supabase'e bağlan. service_role anahtarını asla kod içine koyma.

Kimlik doğrulama: Supabase Auth, e-posta + şifre. Token'ları expo-secure-store içinde sakla. Refresh token yenilemesini Supabase istemcisine bırak. Biyometrik uygulama kilidi ekle.

Roller: admin, osgb_admin, uzman, hekim, firma. Role göre ayrı alt sekme navigasyonu üret; yetkisiz modülleri menüde gösterme. Yetki kontrolünü güvenlik sınırı sayma, gerçek sınır backend RLS.

Faz 1 ekranları: giriş/şifre sıfırlama, bildirimler, ziyaretler (başlat/bitir + konum + süre), saha denetimleri (uygunsuzluk listesi + yeni kayıt + kamera), ekipmanlar (QR okutma + kontrol/bakım ekleme), evraklar (liste + PDF önizleme + paylaşma), personeller (liste/arama/detay), tutanak listesi, mesajlaşma (sohbet + dosya), destek talepleri, ayarlar (profil, şifre değiştir, bildirim tercihleri, çıkış, hesap silme).

Native yetenekler: kamera, QR/barkod tarayıcı, konum (yalnızca işlem anında), push notification, dosya seçici, PDF görüntüleyici, native paylaşım, secure storage.

Offline: ziyaret başlat/bitir, uygunsuzluk kaydı ve ekipman kontrolü çevrimdışı çalışsın; SQLite kuyruğu + fotoğraf kuyruğu + görünür senkronizasyon durumu + hata durumunda kullanıcıya bildirim.

Arayüz: Türkçe, mobil öncelikli, tek elle kullanım, 44px minimum dokunma hedefi, alt sekme çubuğu, liste ekranlarında arama/filtre/sonsuz kaydırma, her listede boş durum + yükleme iskeleti + hata ve tekrar dene, koyu mod, tarih formatı gg.aa.yyyy.

Mağaza hazırlığı: hesap silme akışı, gizlilik politikası ve KVKK bağlantıları, Apple App Privacy ve Google Data Safety için veri envanteri, ekran görüntüleri, uygulama ikonu, açılış ekranı. Expo EAS ile imzalı iOS ve Android paket üretim yapılandırması hazır olsun.

Hassas veri: uygulama TC kimlik numarası ve sağlık verisi içerir. TCKN maskeli gösterilsin, cihazda saklanan veri şifreli olsun, Android'de hassas ekranlarda ekran görüntüsü engellensin, log ve crash raporlarına kişisel veri yazılmasın.

Teslim edilecekler: çalışan Expo projesi, role göre navigasyon, Faz 1 ekranları, offline kuyruk, EAS build yapılandırması, mağaza yayın kontrol listesi.

---

## 13. Riskler

| Risk | Etki | Önlem |
|---|---|---|
| AI aracın kendi backend'ini kurması | İki ayrı veri dünyası, veri kaybı | Brief'te açıkça yasak; ilk kontrolde Supabase URL'i mevcut olanla aynı mı doğrula |
| service_role anahtarının pakete gömülmesi | Tam veritabanı ele geçirme | Yayın öncesi paket taraması, anahtar rotasyonu |
| WebView sarmalayıcı üretilmesi | Apple 4.2 reddi | Native ekran şartı, inceleme öncesi kontrol |
| Offline çakışmaları | Yanlış ziyaret süresi / mükerrer kayıt | `client_id` + idempotent yazma |
| Sağlık verisi ihlali | KVKK yaptırımı, mağaza reddi | Maskeleme, şifreli depolama, ekran görüntüsü engeli |
| Mağaza incelemesinde test hesabı eksikliği | Red | Demo kullanıcı + şifre + senaryo dokümanı |
| Backend'e mobil erişim kısıtı (firewall/Caddy) | Uygulama hiç bağlanamaz | Yayın öncesi cihazdan uçtan uca test |