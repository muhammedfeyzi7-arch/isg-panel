# OSGB SaaS — PROMPT 4/8 · Kimlik Doğrulama, Oturum ve Auth Sertleştirme

**Tarih:** 2026-10-11
**Kapsam:** Giriş/çıkış, parola sıfırlama, parola değişimi, davet/rol, oturum/token, auth log, callback/redirect
**İlke:** Kanıta dayalı + geri alınabilir + işlevi bozmayan. Test edilmeyen kontrol "başarılı" sayılmadı.

---

## Özet — durum tablosu

| ID | Önem | Bulgu | Durum |
|---|---|---|---|
| F-04-01 | Yüksek | `send-reset-email` sunucu tarafı abuse/rate-limit YOK → e-posta bombardımanı | ✅ GİDERİLDİ + DEPLOY |
| F-04-02 | Yüksek | `send-reset-email` `redirectTo` allowlist YOK → açık yönlendirme / recovery-token sızıntısı | ✅ GİDERİLDİ + DEPLOY |
| F-04-03 | Yüksek | `auth-log` kimliksiz sahte güvenlik olayı yazabiliyor (log zehirlenmesi) | ✅ GİDERİLDİ + DEPLOY |
| F-04-04 | Yüksek | Parola değişince diğer oturumlar iptal EDİLMİYOR | ✅ GİDERİLDİ |
| F-04-05 | Orta | Logout/kimlik değişiminde SWR/sekme cache temizlenmiyor → önceki veri sızabilir | ✅ GİDERİLDİ |
| F-04-06 | Bilgi | `signOut()` varsayılan scope = global (doğrulandı) | 📄 Belgelendi |

**Doğrulanmış, uzaktan-kimliksiz sömürülebilir Kritik açık: YOK.** Bulgular orta-yüksek; en acil ikisi (F-04-01/02) deploy edildi.

---

## 1. Auth mimarisi (kod kanıtı ile)

| Akış | Frontend | Sunucu (Edge/DB) |
|---|---|---|
| Giriş/çıkış | `AuthContext.signIn/signOut`, `login/page.tsx` | Supabase Auth (`signInWithPassword`) |
| Parola sıfırlama | `sifremi-unuttum`, `sifre-sifirla` | `send-reset-email` (Resend + `generateLink`) → `verifyOtp` |
| Parola değişimi | `SecuritySection`, `ProfileModal` → `changePassword` | `admin.updateUser` / `auth.updateUser` |
| Davet/hesap oluşturma | `invite/accept` → `accept-invite` | `accept-invite` (service-role, atomik talep) |
| E-posta doğrulama | davet akışında `email_confirm: true` | — |
| Recovery callback | `sifre-sifirla` (`?token_hash=&type=recovery`) | `auth.verifyOtp` |
| Oturum yenileme | supabase-js `autoRefreshToken: true` | GoTrue refresh |
| Rol/tenant yükleme | `AuthContext.fetchProfile` | `profiles` + RLS (`auth_role`/`osgb_access_ok`) |
| Auth log | `logService.logAuthEvent` | `auth-log` |
| MFA | Yok | — |

Frontend sorumlulukları: form doğrulama, UX, hata mesajı çevirisi (`friendlyAuthError`).
Sunucu sorumlulukları: kimlik doğrulama, token üretimi, rol/tenant türetimi, abuse limiti. **Yetki asla istemciden gelen role/osgb_id'ye dayanmaz.**

---

## 2. Bulgular ve düzeltmeler

### F-04-01 · YÜKSEK · `send-reset-email` abuse/rate-limit yok
- **Etkilenen:** `supabase/functions/send-reset-email/index.ts`
- **Teknik neden:** Fonksiyon anon çağrılabilir; her istekte `admin.generateLink` ile gerçek recovery maili üretip Resend'e gönderiyordu. İstemci tarafı limit yoktu → tek aktör, tek adrese veya çok adrese sınırsız sıfırlama e-postası tetikleyebilirdi (e-posta bombardımanı + sağlayıcı maliyeti/reputation riski).
- **Önceki davranış:** Limitsiz gönderim.
- **Düzeltme:** Sunucu tarafı sabit-pencere rate-limit (`auth_abuse_limits`): **e-posta başına 3 / 15 dk**, **IP başına 8 / 15 dk**. Limit aşımında kullanıcıya YİNE tutarlı `{ ok: true }` deneyimi döner (numaralandırma sızmaz).
- **Yeni davranış:** Abuse sınırlı, UX ve numaralandırma koruması değişmedi.

### F-04-02 · YÜKSEK · `redirectTo` allowlist yok (açık yönlendirme / token sızıntısı)
- **Etkilenen:** aynı fonksiyon
- **Teknik neden:** `generateLink({ options: { redirectTo } })` ve `resetUrl` doğrudan istemciden gelen `redirectTo` ile kuruluyordu. Saldırgan, bir kurbanın e-postası + kendi domainini gönderirse recovery `hashed_token` saldırgan origin'ine gömülürdü (token sızıntısı + açık yönlendirme).
- **Düzeltme:** `redirectTo` yalnızca allowlist origin'e (varsayılan `https://app.isgdenetim.com.tr`; env `SEND_RESET_ALLOWED_ORIGINS` ile genişletilebilir; dev için localhost) işaret ediyorsa kullanılır. Aksi halde yok sayılır ve Supabase `action_link` kullanılır → **markalı e-posta yine gider, meşru akış bozulmaz.**

### F-04-03 · YÜKSEK · `auth-log` kimliksiz sahte olay enjeksiyonu
- **Etkilenen:** `supabase/functions/auth-log/index.ts`
- **Teknik neden:** `event_type` istemciden alınıyordu. `AUTH_LOGIN_SUCCESS`/`AUTH_LOGOUT` için geçerli JWT yoksa bile `user_id = null` ile `system_logs`'a kayıt atılıyordu → anon bir aktör sisteme sınırsız sahte "başarılı giriş / çıkış" yazabilirdi (denetim kaydı zehirlenmesi / DoS).
- **Düzeltme:**
  - **`AUTH_LOGIN_SUCCESS` ve `AUTH_LOGOUT` yalnızca geçerli JWT ile yazılır** (aksi halde `401 AUTH_REQUIRED`, kayıt YOK).
  - `AUTH_LOGIN_FAILED` (oturumsuz akış) korunur ama **IP başına 20 / 5 dk** + **e-posta başına 5 / 15 dk** ile sınırlanır; aşımda sessizce yutulur.
  - `description` sınırlandırılır/satır sonu temizlenir; `email` biçimi doğrulanır ve normalize edilir (log enjeksiyonu engellenir).
- **Önceki → Yeni:** Sahte olay serbest → yalnız JWT'li success/logout; failed için sunucu limiti.

### F-04-04 · YÜKSEK · Parola değişiminde diğer oturumlar iptal edilmiyor
- **Etkilenen:** `src/context/AuthContext.tsx` (`changePassword`)
- **Teknik neden:** `updateUser({ password })` sonrası diğer cihaz/oturumların refresh token'ları geçerli kalıyordu. Parolası çalınmış/ele geçirilmiş bir oturum, parola değiştirilse bile erişimini sürdürebiliyordu.
- **Düzeltme:** `supabase.auth.signOut({ scope: 'others' })` — **mevcut oturum korunur, diğer TÜM oturumların refresh token'ları iptal edilir.** (Supabase dokümanı: "Sign out of all other sessions, keep the current one.") İptal başarısız olsa bile parola değişikliği geri alınmaz; hata loglanır.
- **Ayrıca:** `signOut()` varsayılan scope = **global** olduğu doğrulandı (Supabase v2 varsayılanı). Bu, çıkışta kullanıcının diğer cihazlarındaki refresh token'ların da iptal olduğu anlamına gelir — güvenlik açısından kabul edilebilir; davranış değiştirilmedi.

### F-04-05 · ORTA · Logout/kimlik değişiminde istemci cache temizliği yok
- **Etkilenen:** `AuthContext.signOut`, `SessionBoundary`
- **Teknik neden:** SWR cache (sekme verisi / `useTabData` dahil) oturum kapsamlı değildir. Çıkış/sign-out'ta temizlenmediği için, aynı tarayıcıda farklı kullanıcıyla (özellikle aynı SWR anahtarını paylaşan hesaplarda) giriş yapıldığında önceki kullanıcının bellekteki verisi bir an görünebilirdi.
- **Düzeltme:** Yeni `src/lib/clientCacheReset.ts` → `clearClientCaches()` SWR global cache'ini (`mutate(() => true, undefined, { revalidate:false })`) ve in-flight istek birleştirici kayıtlarını temizler. `signOut`'ta ve **her authenticated kimlik değişiminde** (`SessionBoundary`, sunucu taraflı token iptali/SIGNED_OUT dahil) çağrılır.
- **Not:** Sunucu tarafı RLS + tenant kontrolleri yetkili kaynaktır; bu katman yalnızca istemci belleğindeki artığı sıfırlar (defense-in-depth).

---

## 3. Uygulanan kontrol listesi (PROMPT 4 eşleşmesi)

| İstenen | Uygulama |
|---|---|
| Parola sıfırlama tutarlı yanıt (enumerasyon) | Zaten vardı (her durumda `{ ok:true }`); korundu + rate-limit eklendi |
| E-posta/IP/zaman penceresi abuse | `auth_abuse_limits` sabit-pencere (sunucu tarafı) |
| Rate-limit sunucu tarafında | ✅ (istemci değil) |
| Brute-force / limitler | Supabase Auth limitleri + başarısız giriş LOG limiti (kesişmez) |
| Logout sonrası cache temizliği | `clearClientCaches()` |
| Parola değişince oturum iptali | `signOut({ scope:'others' })` |
| signOut scope doğrulama | Global varsayılan doğrulandı (v2 doküman) |
| Kimliksiz sahte log engeli | success/logout JWT zorunlu + failed limit |
| Redirect/allowlist + token URL temizliği | allowlist + `sifre-sifirla` `history.replaceState` (mevcut) |
| Rol/tenant istemciye dayanmaz | `accept-invite`/`auth-log` sunucu tarafı; `profile_lock_role` (önceki faz) |

---

## 4. Testler ve gerçek sonuçlar

| Test | Tür | Durum |
|---|---|---|
| `supabase/tests/security/guv18_auth_abuse_limits.test.sql` | pgTAP (katalog) | ✅ Hazır (syntax-check geçti). **Çalıştırılamadı:** izole pgTAP ortamı erişimi yok |
| Build (`vite build`) | Derleme | ✅ Başarılı |
| Edge deploy (`send-reset-email`, `auth-log`) | Deploy | ✅ `remote_deployed` (`verify_jwt: true` korundu) |
| Canlı şema doğrulama | SQL (katalog) | ✅ `auth_abuse_limits`: RLS açık, **0 politika** (default-deny) |
| Rate-limit uçtan uca (gerçek istek) | Runtime | ❌ Çalıştırılamadı (canlıda yıkıcı/üretim maili tetikleme yasak) |
| Parola değişince eski oturum iptali | Runtime | ❌ Çalıştırılamadı (gerçek kullanıcı oturumu yasak) |

**Çalıştırılamayanların nedeni:** İzole çift-tenant + izole auth ortamı ve pgTAP erişimi bu workspace'te yok; üretim kullanıcı oturumu/parolası ve toplu e-posta gönderimi kurallar gereği yasak. Bu kontroller **"başarılı" sayılmadı.**

---

## 5. Dashboard üzerinden yapılması gerekenler (kod dışı, doğrulanamadı)

1. **Auth > Rate Limits:** email gönderim limitleri ve `signup`/`login` limitleri.
2. **Auth > Providers > Email > "Allow new users to sign up":** KAPALI olmalı (davet-only model). *Doğrulanamadı — Dashboard erişimi yok.*
3. **Auth > URL Configuration:** `Site URL` + `Redirect URLs` allowlist (recovery/orientation). *Doğrulanamadı.*
4. **Auth > Sessions:** "Refresh token rotation" + "Reuse interval" + session timebox. *Doğrulanamadı.*

> Bu ayarlar **kod değişikliği değildir**; yalnızca Supabase Dashboard'dan yapılır.

---

## 6. Dağıtım ve geri dönüş

**Deploy edilenler (canlı):**
- `send-reset-email` (rate-limit + redirect allowlist)
- `auth-log` (JWT zorunlu + failed limit)
- DB: `auth_abuse_limits` tablosu (RLS açık, politika-yok)

**Geri dönüş:**
- Edge: ilgili fonksiyonu önceki sürüme alıp yeniden deploy et (`git` geçmişi yok; önceki sürüm `do_not_retry` değil — deploy ile geri alınır).
- DB: `supabase/migrations/rollback/20260101001200_guv18_auth_abuse_limits_rollback.sql` (tabloyu kaldırır). Kaldırılırsa rate-limit fail-open davranır; uygulama işlevi bozulmaz.
- Frontend: `clearClientCaches` çağrıları ve `signOut({ scope:'others' })` kaldırılabilir (davranış değişikliği minimal).

---

## 7. Bağımsız sızma testinde yeniden doğrulanacaklar

1. Aynı e-postaya >3 sıfırlama isteği / 15 dk → 4.'de mail gitmemeli, yanıt yine `{ok:true}`.
2. Aynı IP'den >8 sıfırlama isteği → limit.
3. `redirectTo=https://evil.example` ile istek → mail linkinin allowlist'e/`action_link`'e düştüğü, saldırgan origin'e token GİTMEDİĞİ.
4. Anon (JWT'siz) `auth-log` `AUTH_LOGIN_SUCCESS` → `401`, kayıt YOK.
5. Anon `AUTH_LOGIN_FAILED` spam → IP/e-posta limiti sonrası kayıt yok.
6. Parola değiştir → diğer cihaz oturumu düşmeli; mevcut oturum ayakta.
7. Logout → SWR cache boş; aynı tarayıcıda başka kullanıcıyla girişte eski veri görünmemeli.
8. `auth_abuse_limits`'a anon/authenticated ile PostgREST erişimi → 0 satır / hata.

---

## 8. Dürüst kapsam notları

- **Runtime IDOR/oturum testleri yapılamadı** (izole ortam + üretim kısıtları) → değerlendirme statik + katalog kanıtı.
- **Dashboard ayarları doğrulanamadı** (erişim yok) → §5'te liste.
- **MFA** uygulamada yok; admin/hassas sağlık verisi rolleri için **aşamalı MFA planı önerilir** (henüz uygulanmadı, "etkin" sayılmadı).
- Klasik CSRF ve istemci SQLi bu mimaride **N/A**.
- `accept-invite` davet token akışı incelendi: **atomik tek-kullanım** (`.eq('status','pending')` ile claim) ve süre kontrolü (`expires_at`) mevcut → ek değişiklik gerekmedi.