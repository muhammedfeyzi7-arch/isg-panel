# İSGDenetim — Güvenlik Migration Test Sonuçları (Faz 7)

> **Yöntem:** (a) 7 migration + 7 rollback dosyasının tam içeriği okundu, (b) canlı Supabase'de
> **yalnızca salt-okuma** `SELECT` (pg_proc / pg_policies / information_schema /
> has_function_privilege / storage.buckets), (c) uygulama kodu incelemesi, (d) production
> build.
>
> **SINIR:** Bu turda **hiçbir DDL/DML üretime uygulanmadı**, hiçbir migration çalıştırılmadı,
> hiçbir Edge Function deploy edilmedi, canlı RLS/Storage değiştirilmedi, kullanıcı verisi
> değiştirilmedi. **Yalnızca statik inceleme + canlı metadata gözlemi yapıldı.**
>
> ⛔ **Gerçekten çalıştırılan runtime testi YOKTUR.** İzole iki-OSGB test ortamı mevcut
> olmadığı için veritabanı davranış testleri **BLOCKED**'dır. Hiçbir migration için "PASS"
> yazılmamıştır; "PASS" yalnızca gerçekten çalıştırılan statik kontroller için kullanılır.

---

## A. Özet

- **Statik inceleme sonucu:** 7/7 migration dosyası **şema-uyumlu** (istisna: GUV-13 kapsam
  açığı, aşağıda).
- **Gerçekten çalıştırılan testler:** 1 (production build) → PASS.
- **Veritabanı runtime (A/B, RLS, Storage, RPC) testleri:** **BLOCKED** (izole ortam yok).
- **Canlı sisteme müdahale:** ❌ HİÇ YOK.

---

## B. Canlı durum teyidi (salt-okuma kanıtları — bu turda alındı)

| Kontrol | Canlı sonuç | Anlam |
|---|---|---|
| `storage_tenant_ok` fonksiyonu | **YOK** | GUV-01 uygulanmadı |
| `noter_defteri_obj_read` policy roller | **`{public}`** | GUV-01 anon kapama uygulanmadı |
| `teklifler` RESTRICTIVE policy sayısı | **0** | GUV-06 uygulanmadı |
| `teklif_hizmetleri` RESTRICTIVE policy sayısı | **0** | GUV-06 uygulanmadı |
| `atamalar/evraklar/firmalar/personeller` `*_osgb_access_guard` | **RESTRICTIVE (zaten canlı)** | Guard policy'ler base şemadan; GUV-07 yalnız fonksiyonu sertleştirir |
| `osgb_access_ok` gövdesi | `auth_osgb_id() IS NULL` dalı **hâlâ var** | GUV-07 uygulanmadı |
| `handle_new_user` gövdesi | `raw_user_meta_data` okuması **hâlâ var** | GUV-02 uygulanmadı |
| anon'un EXECUTE ettiği definer fonksiyon | **159** (çağrılabilir **104**) | GUV-13 uygulanmadı |
| 6 fonksiyon `anon` EXECUTE | **6/6 `true`** | GUV-11 uygulanmadı |
| 4 definer fonksiyon `search_path` | **null** | GUV-14 uygulanmadı |
| 4 bucket `public` | **hepsi `false`** | RLS tek kapı |
| RLS kapalı public tablo | **YOK** | ✅ iyi haber |

---

## C. Migration bazında ön koşul / kapsam / risk

| # | Migration | Ön koşul hazır | Idempotent | Rollback | Meşru erişim riski |
|---|---|---|---|---|---|
| GUV-01 | Storage izolasyonu | ✅ | ✅ | ✅ | Düşük-orta (orphan dosya erişimi kapanır) |
| GUV-02 | handle_new_user | ✅ | ✅ | ✅ | Çok düşük (davet akışı trigger'a bağlı değil) |
| GUV-06 | teklifler restrictive | ✅ | ✅ | ✅ | Düşük (yazma SECURITY DEFINER) |
| GUV-07 | osgb_access_ok | ✅ | ✅ | ✅ | Düşük (firma kullanıcıları osgb_id dolu) |
| GUV-11 | anon EXECUTE | ✅ (imzalar eşleşiyor) | ✅ | ✅ | Düşük — ⚠️ service_role grant'ı test edilmeli |
| GUV-13 | anon definer RPC | ✅ 54/54 — ⚠️ kapsam açığı | ✅ | ✅ | Düşük (authenticated+service_role korunur) |
| GUV-14 | search_path (4) | ✅ | ✅ | ✅ | Düşük (yalnız nitelikli çözümleme sabitlenir) |

Detaylı bağımlılık/rollback/risk analizi: **`SECURITY_MIGRATION_DEPENDENCIES.md`**.

---

## D. GUV-13 özel kontrol (istenen)

### D.1 Dinamik REVOKE gerçekten doğru hedefleri buluyor mu?
- Blok `pg_proc` üzerinden `prosecdef = true AND proname = ANY(hedef)` seçer ve
  `oid::regprocedure` ile **gerçek imzayı** kullanır → imza uyuşmazlığı imkânsız.
- **Doğrulama:** Listedeki **54 fonksiyon adının tamamı canlıda definer olarak MEVCUT** ✅.
- **Overload'lar regprocedure ile çözülür:** `atama_create` ×4, `atama_update` ×2,
  `uygunsuzluk_manuel_kapat` ×2 → hepsi yakalanır.
- **Var olmayan hedef yok** → blok hata vermez; yalnız mevcutları işler.

### D.2 anon / PUBLIC / authenticated / service_role
- Blok `REVOKE ... FROM PUBLIC, anon` + `GRANT ... TO authenticated, service_role`.
- **Doğrulama:** `auth_role`: anon=true, authenticated=true, service_role=true (canlı, henüz
  uygulanmadı). Uygulandıktan sonra **anon=false** beklenir; authenticated/service_role korunur.

### D.3 Başka fonksiyon / Edge Function çağrıları
- `service_role` grant'ı verilir → edge function RPC erişimi korunur.
- İç içe definer çağrıları owner yetkisiyle yürür → etkilenmez.
- **Yalnızca izole testte doğrulanabilir** → BLOCKED.

### D.4 ⛔ KAPSAM AÇIĞI (yeni bulgu)
Canlıda anon'un çağırabildiği **104** definer fonksiyondan **23'ü GUV-13 hedef listesinin
DIŞINDA** kaldı (RLS yardımcıları + bakım/özet fonksiyonları):
`atama_firma_durum_ozet, atama_rol_doygunluk, firma_aktif_atamalar, firma_aktif_personel_sayisi,
firma_calisan_sayisi, has_active_primary_assignment, has_active_primary_firma_assignment,
has_active_uzman_assignment, hazard_change_detect, mesajlasma_conversation_unread_count,
mesajlasma_is_participant, mesajlasma_last_messages, mesajlasma_unread_count,
mesajlasma_unread_counts, operasyon_bakim_hatirlatma, operasyon_entity_accessible,
osgb_erisim_acik, personel_aktif_bagimliliklar, personel_atama_sure_plan, personel_saglik_ozet,
personel_validity_resolve, project_myk_requirements, resolve_hazard_change_assignment`
(+ `next_tutanak_no` GUV-11 tarafından kapatılır).

- **RLS yardımcıları** (mesajlasma_is_participant, osgb_erisim_acik, personel_validity_resolve,
  resolve_hazard_change_assignment, has_active_*, operasyon_entity_accessible) → politikalar
  içinde kullanılabilir; dokunulmaması savunulabilir.
- **Bakım/özet fonksiyonları** (operasyon_bakim_hatirlatma, personel_atama_sure_plan,
  atama_firma_durum_ozet, atama_rol_doygunluk, project_myk_requirements, personel_saglik_ozet,
  firma_* özetleri) → **anon için daraltılması önerilir.**

**Sınıflandırma:** GUV-13 kapsamı → **Kod incelemesi gerekli / Test edilmedi**.

---

## E. GUV-14 özel kontrol (istenen)

- `search_path` sabitlenmemiş definer fonksiyonlar (canlı, tam **4**):
  `custom_field_definition_set_osgb()`, `custom_field_value_set_scope()`,
  `firma_evrak_klasorleri_set_scope()`, `ziyaret_auto_close_due()`.
- `firma_evrak_klasorleri_set_scope` gövdesinde niteliksiz `FROM firmalar` → `search_path =
  public, pg_temp` altında `public.firmalar` olarak çözümlenir (doğru şema) → beklenen sorun yok.
- **Doğrulama (canlı):** 4 fonksiyonun `proconfig` = **null** → GUV-14 uygulanmadı.
- ⚠️ **Ek bulgu:** `log_system_event(text,text)` canlıda `search_path=""` (BOŞ, set edilmiş).
  Bu desen GUV-14 filtresine **uymadığı için blok bu fonksiyonu ATLAR** → ayrı ele alınmalıdır.
- **Sınıflandırma:** Kod incelemesi tamamlandı; runtime çalıştırma → **Test edilmedi / BLOCKED**.

---

## F. Test sonuçları tablosu (PASS / FAIL / BLOCKED)

> Kural: **Yalnızca gerçekten çalıştırılmış test PASS kabul edilir.** Aşağıdaki DB testleri
> izole ortam olmadığı için **hiçbiri çalıştırılmadı** → BLOCKED.

| # | Test | Beklenen | Gerçek | Sonuç |
|---|---|---|---|---|
| T0 | Production build | Başarılı | Build successful | **PASS** |
| T1 | GUV-01 storage A/B SELECT | Cross-tenant 0 | Çalıştırılmadı | **BLOCKED** |
| T2 | GUV-01 hazop anon/other-uid INSERT | 42501 | Çalıştırılmadı | **BLOCKED** |
| T3 | GUV-02 metadata rol yükseltme | role='pending' | Çalıştırılmadı | **BLOCKED** |
| T4 | GUV-06 teklif tenant SELECT/INSERT/UPDATE | Yalnız kendi OSGB | Çalıştırılmadı | **BLOCKED** |
| T5 | GUV-07 osgb_access_ok NULL tenant | false | Çalıştırılmadı | **BLOCKED** |
| T6 | GUV-11 anon EXECUTE (6 fonksiyon) | false | Çalıştırılmadı | **BLOCKED** |
| T7 | GUV-13 anon definer RPC EXECUTE | false | Çalıştırılmadı | **BLOCKED** |
| T8 | GUV-14 search_path'siz definer | 0 satır | Çalıştırılmadı | **BLOCKED** |
| T9 | GUV-11/13 service_role RPC erişimi | Başarılı | Çalıştırılmadı | **BLOCKED** |
| T10 | Auth Dashboard self-signup KAPALI | Kapalı | Dashboard erişimi yok | **BLOCKED** |

### F.1 Yalnızca statik/katalog kontrolleri (gerçekten çalıştırıldı ✅)

| Kontrol | Sonuç | Kanıt |
|---|---|---|
| GUV-13 hedef isimlerinin varlığı | 54/54 mevcut | `pg_proc` sorgusu |
| GUV-13 overload çözünürlüğü | atama_create×4, atama_update×2, uygunsuzluk_manuel_kapat×2 | `regprocedure` |
| GUV-14 hedefleri | tam 4, `proconfig=null` | `pg_proc` sorgusu |
| Tablo/kolon bağımlılıkları | Tümü mevcut (firma_id dahil) | `information_schema` |
| `_cleanup_personel_mig` definer durumu | **false (INVOKER)** | `pg_proc` |
| RLS kapalı public tablo | 0 | `pg_class`/`pg_policies` |

---

## G. Test ortamı eksikliği (BLOCKER)

- Temel (base) şema migration'ları proje klasöründe **yok** → `auth_role()` vb. yerelde yok.
- Uydurma `auth_role()`/tablo **oluşturulmadı**; migration'lar **yeniden sıralanmadı**.
- İzole test ortamı kurulum adımları: `supabase/tests/security/README.md`.
- Test dosyaları: `supabase/tests/security/*.test.sql` (yalnız sahte veri, transaction+rollback,
  production'a bağlanmaz).

---

## H. Değiştirilen / oluşturulan dosyalar (Faz 7)

| Dosya | Durum | Amaç |
|---|---|---|
| `SECURITY_MIGRATION_DEPENDENCIES.md` | **Yeni** | 7 migration + rollback bağımlılık/precondition/rollback kapsamı |
| `SECURITY_TEST_RESULTS_PHASE7.md` | **Yeni** | Bu rapor |
| `supabase/tests/security/README.md` | **Yeni** | İzole ortam kurulum + test çalıştırma |
| `supabase/tests/security/00_harness.sql` | **Yeni** | Yardımcı fonksiyonlar + sahte fixture üretici |
| `supabase/tests/security/guv01_storage_isolation.test.sql` | **Yeni** | Storage izolasyon testi |
| `supabase/tests/security/guv02_role_escalation.test.sql` | **Yeni** | Rol yükseltme testi |
| `supabase/tests/security/guv06_teklif_tenant.test.sql` | **Yeni** | Teklif tenant testi |
| `supabase/tests/security/guv07_osgb_access.test.sql` | **Yeni** | osgb_access_ok testi |
| `supabase/tests/security/guv11_guv13_anon_execute.test.sql` | **Yeni** | anon EXECUTE testi |
| `supabase/tests/security/guv14_search_path.test.sql` | **Yeni** | search_path testi |
| `SECURITY_FIXES_PHASE2.md` | Güncellendi | Faz 7 bölümü |
| `SECURITY_MIGRATION_TEST_PLAN.md` | Güncellendi | Faz 7 notları |

> ⚠️ 7 migration ve 7 rollback dosyası **incelendi ancak DEĞİŞTİRİLMEDİ** (Faz 5'te yazılmış
> hâlleri geçerli).

---

## I. Üretim güvenliği (açık doğrulama)

- ✅ Canlı veritabanına **hiçbir DDL/DML uygulanmadı** (yalnız salt-okuma SELECT).
- ✅ Gerçek kullanıcı/veri/hesap **değiştirilmedi**.
- ✅ Production migration **çalıştırılmadı**, Edge Function **deploy edilmedi**, secret değişmedi.
- ✅ Hiçbir test sonucu uydurulmadı; çalıştırılamayanlar **BLOCKED** işaretlendi.

---

## J. Üretime geçiş için önerilen sıra ve açık işler

1. İzole test ortamı kur → base şema klonu → `00_harness.sql` → testleri çalıştır.
2. Önerilen uygulama sırası: **GUV-02 → GUV-07 → GUV-06 → GUV-01 → GUV-11 → GUV-13 → GUV-14**.
3. **GUV-13 hedef listesini genişlet** (yukarıdaki 23 fonksiyondan bakım/özet olanlar).
4. **`log_system_event` boş `search_path`** durumunu ayrıca ele al (GUV-14 kapsamı dışı).
5. **GUV-11/GUV-13 `service_role`** RPC erişimini izole ortamda doğrula.
6. Dashboard: Auth self-signup **KAPALI**, parola politikası/rate-limit, backup/PITR.

> **Son karar:** Statik inceleme **TAMAMLANDI**; veri katmanı **CANLIDA HÂLÂ AÇIK** ve runtime
> testler **BLOCKED** olduğundan bu hâliyle **ÜRETİME HAZIR DEĞİL**. Bu çalışma resmî TSE
> onaylı sızma testinin yerine geçmez.