# İSGDenetim — Risk Değerlendirmesi Sihirbazı (Eklenti Planı)

> Bu dosya, ana `project_plan.md`'nin yanına, büyüyen ana planı bozmadan eklenen
> "Sihirbaz" akışını belgeler. Mevcut UI/UX, SharedUICore, tasarım dili, responsive
> ve mevcut sayfa düzeni KORUNMUŞTUR. Yeni tasarım dili / sayfaya özel UI motoru
> OLUŞTURULMAMIŞTIR.

## 1. Amaç
Uzman > Evraklar sayfasının üst sağ köşesine **"+ Sihirbaz"** butonu eklenir; buton
**İSGDenetim Sihirbazı**'nı (ortak Modal motoru) açar. Sihirbaz ilk ekranda modül,
ardından yöntem seçimi sunar. Bu fazda YALNIZCA **5x5 L Tipi Matris** uçtan uca
çalışır; Fine-Kinney ve HAZOP yalnızca seçim ekranında görünür ("Yakında").

## 2. Konum ve Giriş
- Route: `/uzman/evraklar` (mevcut). Buton, `EvrakYonetim` başlık aksiyonlarına
  `sihirbazRender` render-prop'u ile eklenir (yalnızca Uzman panelinde).
- Modal: `useModal` + `Modal` + `ModalManager` (variant `large`). Sihirbaz içinde
  yeni sidebar / ikinci step listesi YOKTUR; stepper yalnızca üstte `WizardStepper`.

## 3. Akış (5x5 L Tipi Matris)
1. **Temel Bilgiler** — Başlık, Açıklama, Değerlendirme Tarihi, Geçerlilik Süresi,
   Kapsam + sağda "5x5 L Tipi Matris Hakkında" (R = O × Ş + matris görseli).
2. **Tehlikeler ve Riskler** — NACE/firma otomatik; tablo (No/Tehlike/Risk/
   Etkilenenler/Mevcut Kontrol/O/Ş/Skor/Seviye/İşlemler); manuel ekleme;
   sağda NACE Analizi + **Gemini tehlike önerileri** ("Seçili Önerileri Tabloya Ekle").
3. **Kontroller ve Önlemler** — tablo (Tehlike/Mevcut Kontrol/Ek Önlem/Kontrol Türü/
   Sorumlu/Termin/Durum); sağda seçili risk detayı + **Gemini önlem önerileri**
   ("Öneriyi Ekle") + **Önlem Sonrası Risk** (O/Ş → R karşılaştırması).
4. **Onay ve Kaydet** — solda **gerçek PDF önizleme** (iframe, zoom/tam ekran/
   yeni sekme/indir), sağda rapor kontrol listesi. **Online imza YOK.**
   "PDF İndir" + "Taslak Kaydet".

## 4. Backend
- Yeni tablo/kolon AÇILMADI; mevcut `risk_degerlendirmeleri` +
  `risk_degerlendirme_kayitlari` + `risk_degerlendirme_kontrolleri` +
  `risk_degerlendirme_belgeleri` + `risk_degerlendirme_ai_kullanim` kullanıldı.
- Açıklama alanı mevcut `word_duzenleme.amac` üzerinde tutulur (yeni kolon açılmadı).
- Edge function `risk-degerlendirme-rapor`'a İKİ yeni aksiyon eklendi (mevcut
  Word/DOCX akışı ve `ai-suggestions` BOZULMADI):
  - `ai-onlem` — seçili risk için Gemini kontrol/önlem önerileri (JSON schema,
    rate-limit, `AI_SUGGESTION` etiketi, backend-only API key).
  - `save-pdf` — tarayıcıda üretilen gerçek PDF'i `evraklar` bucket'ına yazar,
    `evraklar` (owner_type=firma, RISK_DEGERLENDIRME türü) + `risk_degerlendirme_belgeleri`
    kaydı oluşturur. Storage yazımı yalnızca service role.
- Servis: `src/lib/riskDegerlendirmeService.ts` → `aiOnlemOnerileri`, `saveRiskPdf`,
  `fetchOsgbIsgBilgi`.

## 5. PDF
- `src/lib/riskDegerlendirmePdf.ts` — **jsPDF + jspdf-autotable** ile VEKTÖREL
  (ekran görüntüsü DEĞİL) **A4 YATAY** gerçek PDF. Türkçe için mevcut
  `personelReport/pdfFont` (DejaVu Sans) fontu gömülür (tek kaynak, yeni font yok).
- İçerik: kapak/genel bilgiler, firma/NACE, yöntem, risk tablosu, kontroller/önlemler,
  önlem sonrası risk, imzalar. Üst bilgi (logo/firma/doküman no/tarih/revizyon),
  her sayfada tekrar eden tablo başlıkları ve "Sayfa X / Y".
- Dosya adı: `{Firma}_Risk_Degerlendirmesi_5x5_Matris_{yıl}.pdf` (firma adı sanitize).

## 6. Yeni/Kullanılan Dosyalar
- `src/components/feature/risk/RiskSihirbazModal.tsx` (orkestratör)
- `src/components/feature/risk/RiskModulSecim.tsx`, `RiskYontemSecim.tsx`
- `src/components/feature/risk/L5x5Adim1TemelBilgiler.tsx`, `L5x5Adim2Tehlikeler.tsx`,
  `L5x5Adim3Kontroller.tsx`, `L5x5Adim4OnayKaydet.tsx`, `L5x5KayitFormModal.tsx`
- `src/components/feature/risk/RiskMatrisGorseli.tsx`, `RiskBilgiPaneli.tsx`,
  `riskSihirbazTypes.ts`
- `src/lib/riskDegerlendirmePdf.ts`
- `EvrakYonetim` (render-prop), `uzman/evraklar/page.tsx` (buton)

## 7. Kapsam Dışı (şimdilik)
- Fine-Kinney ve HAZOP workflow, adımları, raporu ve AI entegrasyonu.
- What-If / FMEA / JSA / FTA / ETA gibi ek yöntemler (EKlenmedi).
- Online imza süreci (yok); imzalı belge yükleme sonraki turlarda detaydan.

## 8. Not
- Gemini için backend secret `GEMINI_API_KEY` gerekir. Eksikse arayüz anlaşılır hata
  gösterir (çökmez). AI önerileri kesin kayıt DEĞİLDİR; kullanıcı onayıyla tabloya alınır.

---

## 9. FAZ GÜNCELLEMESİ — "Sihirbaz İlk İki Ekran" (BU SÜRÜM)

> Önceki bölümler uzun vadeli hedefi belgeler. Bu sürümde YALNIZCA sihirbazın
> ilk iki ekranı kuruldu; sonraki risk adımları (Temel Bilgiler, Tehlikeler vs.)
> BİLİNÇLİ olarak YAPILMADI.

### 9.1 Kapsam
- **Ekran A — İSGDenetim Sihirbazı (modül seçimi):** Uzman > Evraklar başlığındaki
  yeni **"+ Sihirbaz"** butonuyla, mevcut Shared Modal motoru üzerinden açılır.
  Tek aktif modül kartı: **Risk Değerlendirmesi**. Sol stepper / adım numarası YOK.
  Chip'ler: `5x5 Matris`, `Fine-Kinney`, `HAZOP`.
- **Ekran B — Risk Değerlendirme Yöntemi:** Risk kartına tıklanınca AYNI modal
  içinde açılır (yeni modal açılmaz). Yalnızca **3 yöntem**: 5×5 Matris,
  Fine-Kinney, HAZOP. **L Tipi Matris seçenek DEĞİLDİR.** Sağda bilgi paneli
  (Yöntem Seçimi Hakkında / Yasal Dayanak / Ortak Özellikler / Önemli Not).
  Footer sabit: sol **İptal**, sağ **Devam Et**.
- Kaldırılan eski jeneratörler (Yıllık Çalışma / Eğitim Planı, Acil Durum Eylem
  Planı) ve eski L Tipi Matris akışı GERİ GETİRİLMEDİ.

### 9.2 Teknik
- **Tek modal:** Ekran geçişinde `useModal`'a eklenen `updateModal(id, patch)`
  ile aynı modalın **başlığı/ikonu/headerExtra'sı** reaktif güncellenir. Yeni
  modal motoru / ikinci modal YOK. Geometri persistence YOK.
- **Sabit header + sabit footer + yalnızca gövde scroll:** Modal `bodyLayout:'fill'`
  ile açılır; içerik bileşeni kendi gövde scroll'unu ve sabit footer'ını yönetir.
- **Merkezi UI:** Button/Card/`isg-card`/`isg-badge`/`isg-btn`/`--d-*` tokenları
  kullanılır; sayfaya özel renk/spacing sistemi kurulmaz. Dark/Light aynı geometri,
  yalnızca renk tokenları değişir.
- **Kapsam dışı (bu sürüm):** form, DB kayıt, risk tablosu/matris hesaplama motoru,
  aksiyon, rapor, PDF/Word/Excel, AI analiz, wizard step 1 ve sonrası.

### 9.3 Yeni/Kullanılan Dosyalar (bu sürüm)
- `src/components/feature/risk/RiskSihirbazModal.tsx` (iki ekran orkestratörü)
- `src/components/feature/risk/RiskModulSecim.tsx`
- `src/components/feature/risk/RiskYontemSecim.tsx`
- `src/components/feature/risk/RiskMatrisGorseli.tsx` (5×5 görsel, saf CSS)
- `src/components/feature/risk/RiskSihirbazHeader.tsx`
- `src/components/feature/risk/riskSihirbazTypes.ts`
- `src/hooks/useModal.tsx` (`updateModal` eklendi)
- `src/components/feature/evrak/EvrakYonetim.tsx` ("+ Sihirbaz" butonu)

---

## 10. FAZ GÜNCELLEMESİ — "Tam Risk Değerlendirmesi Sihirbazı" (BU SÜRÜM)

> Referans görsellerdeki 5 ekran birebir hedeflenerek kuruldu. Yöntem seçim ekranı
> KALDIRILDI; bu proje YALNIZCA **5x5 L Tipi Matris (Olasılık × Şiddet)** kullanır.
> Fine-Kinney / HAZOP seçenek DEĞİLDİR.

### 10.1 Akış
`Uzman > Evraklar > Sihirbaz` → modül seçimi (2×2, Risk Değerlendirmesi aktif) →
**5 adımlı** risk sihirbazı: **1. Temel Bilgiler · 2. Tehlikeler ve Riskler ·
3. Kontroller ve Aksiyonlar · 4. Değerlendirme (interaktif 5x5) · 5. Rapor ve Önizleme**.

### 10.2 Veri akışı (tek merkezi workspace)
- `riskWorkspaceStore` (IndexedDB) — GEÇİCİ çalışma alanı; yarıda bırakılan sihirbaz
  kaldığı yerden devam eder. **Kalıcı kayıt/arşiv DEĞİLDİR.** "Kaydet / Taslak /
  Tamamla" aksiyonu YOKTUR.
- Adım 2'de (AI / manuel / şablon / Excel) oluşan risk, adım 3 ve 4'e OTOMATİK yansır;
  adım 4 sonucu Word/PDF/Excel çıktısına gider. Tablo satırları BOŞ BIRAKILMAZ.
- Risk seviyesi: 1–5 Düşük · 6–15 Orta · 16–25 Yüksek (Olasılık × Şiddet).

### 10.3 AI (Gemini)
- Edge function **`risk-ai-oneriler`** (batch: her basışta TAM 10 YENİ öneri; mevcut
  riskler + daha önce önerilenler bağlama gönderilir, semantik duplicate engellenir).
- Öneriler önceki listenin ALTINA eklenir (silinmez). Kategori listesi 37 başlığa
  genişletildi. `GEMINI_API_KEY` backend secret olarak kullanılır.

### 10.4 Yeni/Kullanılan Dosyalar (bu sürüm)
- `src/components/feature/risk/RiskSihirbazContent.tsx` (4 adım + rapor orkestratörü)
- `src/components/feature/risk/adimlar/Adim1TemelBilgiler.tsx` … `Adim5Rapor.tsx`
- `src/components/feature/risk/RiskMatrisInteractive.tsx`, `RiskDagilimGrafik.tsx`,
  `AiTehlikePaneli.tsx`, `ManuelRiskModal.tsx`
- `src/components/feature/risk/riskSihirbazTypes.ts` (workspace modeli + kategoriler)
- `src/components/feature/risk/riskWorkspaceStore.ts` (IndexedDB geçici alan)
- `src/lib/riskAiService.ts`, `src/lib/riskRaporService.ts` (Word/PDF/Excel)
- `supabase/functions/risk-ai-oneriler/index.ts`
- KALDIRILDI: `RiskYontemSecim.tsx`, `RiskMatrisGorseli.tsx` (yöntem seçimi artık yok).

---

## 11. FAZ GÜNCELLEMESİ — "Yöntem Seçim Ekranı Geri Getirildi" (BU SÜRÜM)

> Kullanıcı, referans görseldeki **"Risk Değerlendirme Yöntemi"** ekranının
> BİREBİR korunmasını istedi. Bu ekran daha önce kaldırılmıştı; geri getirildi.

### 11.1 Akış
`Sihirbaz` → modül seçimi (2×2) → **Risk Değerlendirmesi** → **Risk Değerlendirme
Yöntemi (referans UI)** → **Devam Et** → 5 adımlı risk sihirbazı
(1. Temel Bilgiler · 2. Tehlikeler ve Riskler · 3. Kontroller ve Aksiyonlar ·
4. Değerlendirme · 5. Rapor ve Önizleme).

### 11.2 Yöntem seçim ekranı (referans birebir)
- **3 kart:** 5x5 Matris (kırmızı/öne çıkan), Fine-Kinney, HAZOP. Her kartta
  ikon kutusu, radio, başlık, alt başlık, açıklama, görsel (mini 5x5 matris /
  O×Ş×F kutuları / HAZOP görseli) ve alt formül kutusu korunur.
- **Sağ bilgi kolonu AYNEN korunur:** Yöntem Seçimi Hakkında · Yasal Dayanak ·
  Ortak Özellikler · Önemli Not.
- **Footer sabit:** sol İptal · sağ Devam Et.
- Kart/panel öğeleri referansta var olduğu için KALDIRILMAZ.
- Gerçek hesaplama motoru YALNIZCA 5x5'tir. Diğer iki kart görsel referanstır;
  seçilse bile "Devam Et" akışı 5x5 üzerinden yürür (kullanıcı bilgilendirilir).

### 11.3 Teknik
- `RiskSihirbazModal` orkestratörüne `yontem` aşaması eklendi; ekran geçişinde
  AYNI modalın başlığı `updateModal` ile güncellenir (yeni modal motoru YOK).
- **Yeni dosyalar:** `RiskYontemSecim.tsx`, `RiskMatrisGorseli.tsx`.
- 4. adım matris eksen etiketleri referansa göre düzeltildi (solda Şiddet +
  tanımlar, altta Olasılık + tanımlar) + "Risk Seviyesi Açıklamaları".
- 5. adım imzacı bölümü referanstaki tablo düzenine (Adı Soyadı / Görev /
  İşlemler) çevrildi; düzenle + sil + "Yeni İmzacı Ekle" çalışır.

---

## 12. FAZ GÜNCELLEMESİ — "Tek Rapor Tasarım Motoru (Word/PDF/Excel) + Wizard Tipografi" (BU SÜRÜM)

> Referans görseldeki A4 YATAY kurumsal rapor birebir hedeflendi ve wizard
> tipografisi `Manuel Risk Ekle` ölçeğine indirildi. Mevcut 5 adımlı yapı,
> sidebar, modal motoru ve fonksiyonlar KORUNDU.

### 12.1 Tek rapor tasarım motoru
- **TEK veri modeli:** `src/lib/riskRapor/model.ts` → `RaporVerisi` + TEK
  hesaplama fonksiyonları (`riskSayim`, `kalanRiskPuani`, `azalmaYuzde`,
  `azalmaOzeti`, `seviyeLabel/seviyeRenk`, `imzaListesi`). Aynı risk üç formatta
  da aynı puan/seviye/azalma üretir.
- **Üç renderer:** `src/lib/riskRapor/pdf.ts` (jsPDF + autotable, gerçek VEKTÖREL
  A4 yatay), `word.ts` (A4 yatay .doc, gerçek düzenlenebilir tablolar, tekrarlayan
  tablo başlığı, `mso-header`/`mso-footer` + Sayfa X/Y), `excel.ts` (ExcelJS,
  8 ayrı worksheet, A4 yatay, FitToWidth=1, print area, gizli gridline, tekrar eden
  başlık, footer).
- **Aynı bölüm sırası (üç formatta):** Kapak · 1 Firma Bilgileri · 2 Tehlikeler ve
  Riskler · 3 Kontroller ve Aksiyonlar (+ Kontrol Hiyerarşisi) · 4 Kontrol Sonrası
  Risk (+ Risk Azalma Özeti + Değerlendirme Notu) · 5 Özet ve Sonuç (+ dağılım) ·
  6 Değerlendirme Ekibi / İmza (+ Onay).
- **Görsel dil:** lacivert (#0F2747) header bandı, kırmızı (#C8102E) vurgu çizgisi,
  beyaz içerik, ince çizgiler, yeşil/sarı/kırmızı risk seviyeleri. Neon/gradient/
  dashboard yok.
- `src/lib/riskRaporService.ts` geriye dönük uyum için aynı export adlarını
  `src/lib/riskRapor` üzerinden yeniden yayınlar.

### 12.2 Wizard tipografi düzeltmesi
- **Kök sebep:** Global yoğunluk `--d-density-scale: 75%` (html font-size) iken
  wizard kendi kutusunda `text-[13px]` gibi SABİT piksel kullanıyordu → ölçeklenmediği
  için ortak bileşenlerden (`.isg-input` = 0.875rem, ölçekli) BÜYÜK görünüyordu.
- **Çözüm:** `wizardUi.tsx` + tüm adım/AI/matris/grafik bileşenlerindeki sabit px
  yazılar rem tabanlı ortak ölçeğe çevrildi (13px→`text-sm`, 11px→`text-xs`,
  12.5px→`text-[0.8125rem]`, 17px→`text-base`). Artık wizard, `Manuel Risk Ekle`
  modalıyla AYNI yazı ölçeğini ve yoğunluğu paylaşır. Yeni font sistemi kurulmadı,
  yazılar büyütülmedi, adım yapısı/sidebar/modal/fonksiyonlar korundu.

### 12.3 Yeni/Kullanılan Dosyalar (bu sürüm)
- `src/lib/riskRapor/model.ts`, `pdf.ts`, `word.ts`, `excel.ts`, `index.ts`
- `src/lib/riskRaporService.ts` (yeniden yayın)
- `riskSihirbazTypes.ts`: `TemelBilgiler`'e rapor künye alanları (raporNo,
  tehlikeSinifi, adres, isveren, nace, calisanSayisi, hazirlayan, onaylayan,
  imzacilar) + `RiskItem`'a `kontrolTuru/baslangic/kalanOlasilik/kalanSiddet`
  (opsiyonel) + `Imzaci` tipi + `KONTROL_TURLERI/TEHLIKE_SINIFLARI`.
- `Adim1TemelBilgiler.tsx`: firma künye alanları; `Adim4Degerlendirme.tsx`:
  "Kontrol Sonrası Risk" kartı; `Adim5Rapor.tsx`: imzacılar merkezi modele taşındı
  (+Belge No).

---

## 13. FAZ GÜNCELLEMESİ — "Word/PDF/Excel Çıktı Düzeltmeleri + Hız/Matris" (BU SÜRÜM)

> Kullanıcı geri bildirimi (Word indirilemiyor, PDF/Excel tasarımı, Excel'den
> Aktar, AI yavaş, matris hataları). Mevcut 5 adımlı yapı, sidebar, modal motoru
> ve fonksiyonlar KORUNDU.

### 13.1 Word — gerçek .docx
- **Kök sebep:** Çıktı HTML tabanlı `.doc` olarak üretiliyordu; Microsoft Word
  bunu "bozuk / açılmıyor" olarak değerlendirebiliyordu.
- **Çözüm:** `docx` (v9.7.1) ile **gerçek OOXML `.docx`**. Kapak A4 DİKEY; tablolu
  tüm bölümler A4 YATAY; gerçek düzenlenebilir Word tabloları; uzun tabloda başlık
  satırı sonraki sayfada TEKRAR eder (`tableHeader`); her sayfada kurumsal
  header/footer + Sayfa X / Y alanı. `Packer.toBlob` ile indirilir.

### 13.2 PDF — Görsel 2 bölüm bandı
- Bölüm başlıkları **tam-genişlik lacivert bant + sol kırmızı numara karesi + alt
  ince kırmızı çizgi** olarak güncellendi (tutanak/ekipman çıktılarıyla aynı dil).
- Global kurumsal PDF header (logo + OSGB künyesi) ve footer (lacivert bant +
  kırmızı slogan + sayfa no) korunur.

### 13.3 Excel — ekipman Excel'iyle aynı tasarım
- Ham export / çok sekme DEĞİL: **tek sayfa, alt alta bölümler**.
- Başlık artık GLOBAL `renderCompanyHeader` ile üretilir: logo + OSGB künyesi +
  kırmızı dikey şerit + lacivert rapor paneli (Firma / Rapor No / Rapor Tarihi /
  Toplam Risk / Hazırlayan). `renderCompanyHeader`'a opsiyonel `reportLabels`
  parametresi eklendi (ekipman davranışı korunur; modül kendi etiketlerini verir).
- A4 yatay, FitToWidth=1, print area, tekrar eden üst bilgi, footer (Sayfa X/Y).

### 13.4 Excel'den Aktar (2. adım)
- Dosya seçici `hidden` (display:none) yerine `sr-only` yapıldı (bazı tarayıcılar
  display:none input için seçiciyi açmıyordu).
- `XLSX.read` girdisi `Uint8Array`'e çevrildi; boş sayfa ve ayrıştırma hataları
  kullanıcıya toast ile bildirilir. Kolon takma adları genişletildi (termin/durum/
  notlar vb.).

### 13.5 AI hızlandırma
- `risk-ai-oneriler` edge function'da Gemini `thinkingConfig.thinkingBudget = 0`
  yapıldı (2.5 serisinde varsayılan düşünme adımı yanıtı çok yavaşlatıyordu).

### 13.6 5x5 matris
- `RiskMatrisGorseli` (mini matris) eksen etiketleri YANLIŞTI (üstte "Şiddet",
  yanda "Olasılık"). `RiskMatrisInteractive` ile hizalandı: **X / üst = Olasılık
  (1→5), Y / yan = Şiddet (5→1)**. Renk bantları seviye eşikleriyle tutarlı
  (1–5 Düşük · 6–15 Orta · 16–25 Yüksek).
- Yöntem seçim ekranında 5x5 dışı seçim HATA üretmez; kullanıcı bilgilendirilip
  akış 5x5 üzerinden yürür.

---

## 14. FAZ GÜNCELLEMESİ — "Fine-Kinney Yöntemi (Uçtan Uca)" (BU SÜRÜM)

> Kullanıcı, yöntem seçim ekranındaki **Fine-Kinney** kartının GERÇEKTEN
> çalışmasını, referans görsellerdeki (5 adım) birebir arayüzle kurulmasını ve
> son adımda 5x5 ile AYNI kurumsal tasarımda **PDF/Word/Excel** vermesini istedi.
> Fine-Kinney, 5x5 akışından BAĞIMSIZ ayrı bir modül olarak kuruldu; mevcut 5x5
> akışı, modal motoru ve ortak bileşenler KORUNDU (bozulmadı).

### 14.1 Akış
`Sihirbaz` → modül seçimi → Risk Değerlendirmesi → Risk Değerlendirme Yöntemi →
**Fine-Kinney** seçilip **Devam Et** → 5 adımlı Fine-Kinney sihirbazı:
**1. Temel Bilgiler · 2. Tehlikeler ve Riskler · 3. Kontroller ve Aksiyonlar ·
4. Değerlendirme · 5. Rapor ve Önizleme**. (HAZOP hâlâ bilgilendirme kartıdır.)

### 14.2 Hesap (mülga 5x5'ten farklı)
- **Risk Puanı = Olasılık (O) × Frekans (F) × Şiddet (S)**
- Ölçekler: O → 0,1 · 0,2 · 0,5 · 1 · 3 · 6 · 10 · F → 0,5 · 1 · 2 · 3 · 6 · 10 ·
  S → 1 · 3 · 7 · 15 · 40 · 100.
- Seviye bandı: **<20 Kabul Edilebilir · 20–70 Olası · 70–200 Önemli ·
  200–400 Yüksek · >400 Çok Yüksek**.
- Tek hesaplama kaynağı: `src/components/feature/risk/fkTypes.ts` (`fkPuan`,
  `fkSeviye`, `fkSeviyeBilgi`) — matris, kartlar ve rapor aynı sonucu verir.

### 14.3 Kayıt YOK / sisteme bağlanmaz
- Supabase'e YAZILMAZ, veri SİSTEMDEN OKUNMAZ (kurumsal logo/künye hariç, o da
  yalnızca çıktı başlığı için).
- Geçici çalışma `fkWorkspaceStore` (IndexedDB, ayrı DB adı) ile saklanır:
  modal kapanınca **kaldığı yerden devam**, alt barda **Sıfırla** ile tamamen silinir.
- Kullanıcı yalnızca **indirme** yapar.

### 14.4 Rapor çıktıları (5x5 ile aynı kurumsal tasarım)
- `src/lib/fineKinneyRapor/{model,pdf,word,excel,index}.ts`. Ortak global kurumsal
  motor yeniden kullanılır: PDF için `pdfCore` (logo + OSGB künyesi + footer),
  Excel için `excelCompanyHeader` (logo + kırmızı şerit + lacivert panel + footer),
  Word için gerçek `.docx` (kapak dikey, bölümler yatay, tekrarlayan tablo başlığı).
- Ortak bölümler: 1 Firma · 2 Tehlikeler ve Riskler · 3 Kontroller ve Aksiyonlar
  (+ hiyerarşi) · 4 Kontrol Sonrası Risk (+ azalma özeti) · **5 Fine-Kinney
  Ölçekleri** (matris yerine O/F/S tabloları + seviye aralıkları) · 6 Özet · 7 Ekip/İmza.
- Kurumsal logo/künye `loadRiskBrandMeta` ile Kurumsal Ayarlar'daki gerçek OSGB
  kaydından gelir; koda sabit yazılmaz.

### 14.5 AI
- `risk-ai-oneriler` edge function'a `yontem: 'fine-kinney'` dalı eklendi: bu mod
  O/F/S değerlerini YALNIZCA geçerli Fine-Kinney ölçek değerlerinden üretir ve
  sunucuda en yakın geçerli değere SNAP edilir. 5x5 dalı değişmeden korunur.

### 14.6 Yeni/Kullanılan Dosyalar (bu sürüm)
- `src/components/feature/risk/fkTypes.ts`, `fkWorkspaceStore.ts`
- `src/components/feature/risk/FkSihirbazContent.tsx`
- `src/components/feature/risk/fk/FkTehlikePaneli.tsx`, `FkManuelRiskModal.tsx`
- `src/components/feature/risk/fk/adimlar/FkAdim1Temel.tsx` … `FkAdim5Rapor.tsx`
- `src/lib/fineKinneyRapor/{model,pdf,word,excel,index}.ts`
- `RiskSihirbazModal.tsx` (Fine-Kinney yönlendirmesi), `riskAiService.ts` (yontem),
  `supabase/functions/risk-ai-oneriler/index.ts` (Fine-Kinney O/F/S dalı).
