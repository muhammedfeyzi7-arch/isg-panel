> ⛔⛔ **GEÇERSİZ / TARİHSEL KAYIT (2026-10-09 öncesi durum):** Bu dosya, güvenlik migration'ları
> canlıya uygulanmadan ÖNCE yazıldı. Aşağıdaki **"9 migration uygulanmadı / veri katmanı açık"**
> ifadeleri **ARTIK GEÇERSİZDİR.** Migration'lar (GUV-01/02/06/07/11/13/13b/14/15/17/18) canlıya
> uygulanmış ve canlı salt-okuma sorgularla doğrulanmıştır.
>
> 👉 **GÜNCEL TEK DOĞRU KAYNAK: [`PENTEST_READINESS_DOSSIER.md`](./PENTEST_READINESS_DOSSIER.md)**
>
> Bu dosya yalnız **tarihsel** neden analizi için saklanmaktadır. Çelişki halinde dossier geçerlidir.

# İSGDenetim — Kapanmamış Güvenlik Maddeleri Takibi (Faz 11)

> **Amaç:** Kapanış kriterlerini (kök neden + düzeltme + başarılı test + retest + regresyon
> kontrolü + rollback) **henüz karşılamayan** tüm maddeleri tek yerde izlemek.
>
> **Durum sözlüğü**
> - **CLOSED** — tüm kapanış kriterleri karşılandı.
> - **FIXED — UNVERIFIED** — düzeltme/ dosya hazır, runtime testi çalıştırılmadı.
> - **PREPARED — NOT APPLIED** — çözüm hazır ancak sisteme uygulanmadı (platform/deploy kısıtı).
> - **BLOCKED** — ortam/erişim eksikliğinden çalıştırılamadı.
> - **NOT APPLICABLE (code)** — yalnız hosting/Dashboard katmanında yapılabilir.

Tarih: 2026-10-09 · Bu turda canlıya **hiçbir** DDL/DML/deploy/secret uygulanmadı.

> **⟳ F-08 HİZALAMA (düzeltme turu):** `20260101000100_guv01_storage_tenant_isolation.sql`
> dosyasında **P0/F-08 düzeltildi** — `personel-foto`, `hazop-kanitlari` ve `noter-defteri`
> **DELETE** politikaları, ilgili İLİŞKİSEL TABLONUN **DELETE RLS'i + dosya sahibi** ile
> hizalandı (önceki hâl read-scoped `storage_tenant_ok` kullandığından `firma`/`hekim`
> fazladan izin alıyordu → storage DELETE tablo DELETE'inden GENİŞ'ti). Artık storage DELETE,
> tablo DELETE'inden daha geniş **değil**; upload-cleanup (sahibin kendi dosyasını `.remove()`)
> **korunuyor**. `atama-belgeleri` DELETE zaten hizalıydı → değişmedi. Rollback **değişmedi**
> (orijinal `{public}`/bucket-only durumu zaten geri kuruyor).
> `supabase/tests/security/guv01_storage_isolation.test.sql`'e **2 DELETE-kapsam assertion'ı**
> eklendi (`plan 13 → 15`): F1(firma), başka kullanıcının noter/hazop nesnesini silemez.
> **Durum: FIXED — UNVERIFIED** (izole DB ortamı olmadığından DB testi bu turda çalıştırılmadı;
> production build **PASS**).

> **⟳⟳⟳⟳⟳ Bu tur (tam kapsamlı denetim) taze kanıtı:**
> - **MIGRATION ↔ CANLI ŞEMA KOLON UYUMU ✅ PASS:** GUV-01/06/07 + harness'ın referans verdiği TÜM
>   kolonlar canlıda mevcut (`osgb.deleted_at/is_active/erisim_baslangic/erisim_bitis`,
>   `teklifler.osgb_id/durum/teklif_no`, `teklif_hizmetleri.osgb_id/teklif_id`,
>   `atama_belgeleri.dosya_path`, `personeller.foto_url`, `hazop_kanitlari.storage_path`,
>   `noter_defteri_ekleri.storage_path`) → şema-uyumsuzluğu kaynaklı uygulama hatası riski YOK.
> - **GUV-11 AÇIK-İMZA DOĞRULAMASI ✅ PASS:** GUV-11 tüm `REVOKE/GRANT`'ları **açık imza** ile yapar;
>   biri uyuşmazsa tüm transaction patlardı. Canlı `pg_proc` birebir eşleşti (14 fonksiyon imzası).
> - **TEST DOSYASI İMZA UYUMU ✅ PASS:** `has_function_privilege` açık imzaları
>   (`admin_dashboard_summary()`, `auto_close_ziyaretler()`, `delete_osgb_permanent(uuid,text)`)
>   canlıyla birebir → test dosyalarında "does not exist" hatası YOK.
> - **Client güvenlik (statik):** `dangerouslySetInnerHTML` tümü sanitize; `target="_blank"` 5 noktada
>   `rel` mevcut; istemcide secret/token yok → **düzeltilecek yeni client açığı YOK.**
> - **DÜZELTİLECEK HATA BULUNMADI → hiçbir kaynak/SQL/test dosyası DEĞİŞTİRİLMEDİ.** Yasak/engelli
>   işler (`_shared/cors.ts`, `vite.config.ts` sourcemap) kural gereği **tekrar denenmedi**.
> - Canlı durum DEĞİŞMEDİ: `storage_tenant_ok`=YOK, `definer=162`, `null_search_path=4`,
>   `teklif_restrictive=0` → **9 migration hâlâ UYGULANMADI.** Aşağıdaki B/C/D/E bölümleri geçerli.

> **⟳⟳⟳⟳ Bu tur (storage erişim turu) taze kanıtı:**
> - **`noter-defteri` sızması KESİN doğrulandı** (etikettten değil, tam koşuldan): politika
>   `noter_defteri_obj_read` → `roles={public}`, `qual=(bucket_id='noter-defteri')`, `with_check=null`;
>   **`has_table_privilege('anon','storage.objects','SELECT')=true`** + RLS enabled ⇒ **anon
>   listeleyebilir ve imzalı URL üretebilir** ⇒ tüm kiracıların noter ekleri okunabilir.
> - `noter-defteri` bucket **`public=false`** → public-URL yok; sızma **list/createSignedUrl** üzerinden.
>   INSERT/DELETE ise `auth.uid()` gerektirdiğinden **anon yazamaz/silemez** (tek açık = okuma).
> - **Migration çözümü hazır + doğru**; `storage_tenant_ok` canlıda **YOK** ⇒ GUV-01 uygulanmadı;
>   dayandığı tüm kolonlar canlıda birebir mevcut.
> - Diğer 3 bucket (atama/personel/hazop) **bucket-only** ⇒ aynı kök neden; GUV-01 hepsini kapatır.
> - **YENİ statik bulgu (CLOSED DEĞİL):** GUV-01 storage DELETE, okuma-kapsamlı `storage_tenant_ok`
>   kullandığından tablo DELETE RLS'inden **geniş** (firma/hekim eklenir) → yetim dosya riski;
>   **gizlilik sızması değil**, izole ortamda doğrulanmalı. "Sahip" kapsamı upload-cleanup için gerekli.
> - `hazop-kanitlari` src'de **hiç kullanılmıyor** (0 kod referansı) → migration'ın "yol belirsiz" notu doğru.
> - **CORS küçük pilot İMKÂNSIZ:** `json()` helper'ı `req` almıyor; tek `osgb-status` dosyasında ~18
>   `json(...)` çağrı noktası var ⇒ imza değişikliği yaygın refactor gerektirir → deploy testi olmadan YOK.
> - **Test ortamı yine KURULAMADI (BLOCKED):** pg_dump/CLI/Docker/ayrı DB yok; canlı projede test şeması
>   açmak yasak. Ham `pg_dump`'ın başka projeye doğrudan yüklenmesi **önerilmez** (Supabase'e özgü roller/
>   uzantı/sahiplik/sistem nesneleri) → kontrollü şema-only + nesne-bazlı hazırlık gerekir.
> - Canlı DEĞİŞMEDİ: `storage_tenant_ok`=YOK, `noter_policy`=3 (read/insert/delete), `update_policy`=0 →
>   **9 migration hâlâ UYGULANMADI.**

> **⟳⟳ Bu tur (sonuçlandırma) taze kanıtı:**
> - **Kök neden çözüldü:** Canlıda `auth_role()`, `auth_osgb_id()`, `auth_firma_id()`,
>   `has_active_firma_assignment()`, `osgb_access_ok()`, `storage.foldername()` **MEVCUT** →
>   "auth_role() yok" hatası proje klasöründe **base şema/`config.toml` olmamasından**dır
>   (canlı şemadan değil). İzole ortam = canlı `public` şemasının **şema-only** kopyası.
> - **Migration imza/kolon uyumu ✅ PASS:** 34 fonksiyon imzası + tüm referanslı kolonlar +
>   4 private bucket canlıda birebir doğrulandı → imza/kolon kaynaklı uygulama hatası riski yok.
> - **Edge dosya yazılabilir** (mevcut `functions/*/index.ts`) — yalnız `_shared/*` ve
>   `vite.config.ts` kilitli. Ancak per-request CORS çağrı-noktası değişikliği gerektirir →
>   runtime testi olmadan toplu uygulama riskli bulundu; kural gereği uygulanmadı.
> - **Hiç şema dump / `config.toml` / base migration yok** (glob) → izole ortam dış girdi ister.
> - Canlı durum DEĞİŞMEDİ: `definer=162`, `null_searchpath=4`, `anon_definer_exec=159`,
>   `storage_tenant_ok=false`, `teklif_restrictive=0` → **9 migration UYGULANMADI.**

> **⟳ Bu turdaki yeniden doğrulama (kalan hataları kapatma turu):** build **PASS**;
> CORS=**43** (yeniden sayıldı), JWT doğrulama=**40**, service-role=**41**,
> `innerHTML`/`dangerouslySetInnerHTML` hepsi güvenli, `alert(`/`window.location.href=`=**0**.
> Canlı salt-okuma: `definer=162`, `null_search_path=4`, `anon_definer_exec=159`,
> `storage_tenant_ok=0` → **9 migration hâlâ uygulanmadı**. `_shared/cors.ts` oluşturma **tekrar
> denendi ve platform reddetti** ("cannot be modified, please use deploy_edge_function tool");
> `vite.config.ts` sourcemap **yine reddedildi**. **Çağıran analizi** (grep + prosrc): guardsız
> definer fonksiyonlara gövdesel guard EKLENMEDİ çünkü `personel_firma_id/osgb_id` **RLS**,
> `personel_validity_resolve` **trigger** tarafından çağrılıyor → guard RLS/trigger'ı kırardı.
> Doğru çözüm mevcut **grant-narrowing** (GUV-11/13/13b) tasarımıdır. Yeni kapatılabilir kod
> hatası çıkmadı; **yeni migration bilerek üretilmedi**. Aşağıdaki **C/E/D** bölümleri geçerli.

> **⟳⟳⟳ Bu tur (test ortamı turu) taze kanıtı:**
> - **İZOLASYON ORTAMI KURULAMADI → BLOCKED:** ayrı Supabase/PostgreSQL, `psql`/`supabase CLI`/Docker
>   veya şema import yolu **YOK**; bağlı proje canlı olduğundan orada test şeması açmak yasak.
> - **Şema-only dump YAPILAMADI** (dump/CLI aracı yok) — "yapıldı" diye raporlanmadı. Gereken komut +
>   yetki rapor §"Test ortamı turunda" verildi (connection bilgisi paylaşılmadan, yerelde çalıştırılır).
> - **Test barındırma önkoşulları (canlı salt-okuma):** PostgreSQL **17.6**; `pgtap` **kurulabilir**;
>   `pg_cron` mevcut; `anon/authenticated/service_role` **mevcut** → base şema verilirse testler çalıştırılabilir.
> - **Statik uyum ✅ PASS:** migration referanslı yardımcı fonksiyonlar + `storage.foldername` canlıda var;
>   `storage.objects` politikaları GUV-01 tarifiyle birebir; 9 rollback tutarlı.
> - **Sınırlar teyit edildi:** CORS 43 dosya aynı desen → runtime testi olmadan refactor YOK;
>   `tsc`/ESLint/`npm audit` **BLOCKED** (yürütücü yok); build **PASS**.
> - Canlı DEĞİŞMEDİ: `definer=162`, `null_search_path=4`, `anon_definer_exec=159`,
>   `storage_tenant_ok=0`, `teklif_restrictive=0` → **9 migration hâlâ UYGULANMADI**.

---

## A) CLOSED (bu turda gerçekten kapatılan)

| # | Madde | Kanıt |
|---|---|---|
| A1 | `RichTextEditor` yükleme yolunda sanitize edilmemiş `innerHTML` | Kod düzeltildi + **build PASS** |
| A2 | `ocrService.generatePdfFromHtml` sanitize edilmemiş `innerHTML` | Kod düzeltildi + **build PASS** |

> Not: Bu iki madde "derleme + kod incelemesi" ile doğrulandı; **tarayıcıda XSS payload çalıştırma
> testi** bu ortamda yapılamadı. İsterseniz runtime XSS doğrulaması da eklenebilir.

---

## B) FIXED — UNVERIFIED (migration dosyası hazır, canlıda UYGULANMADI, runtime BLOCKED)

| # | Madde | Dosya | Engeli |
|---|---|---|---|
| B1 | GUV-01 Storage tenant izolasyonu | `20260101000100_guv01_...sql` (+rollback) | İzole DB yok |
| B2 | GUV-02 `handle_new_user` rol yükseltme | `20260101000200_guv02_...sql` (+rollback) | İzole DB yok |
| B3 | GUV-06 teklifler RESTRICTIVE | `20260101000300_guv06_...sql` (+rollback) | İzole DB yok |
| B4 | GUV-07 `osgb_access_ok` NULL dalı | `20260101000400_guv07_...sql` (+rollback) | İzole DB yok |
| B5 | GUV-11 anon/PUBLIC EXECUTE (6+) | `20260101000500_guv11_...sql` (+rollback) | İzole DB yok |
| B6 | GUV-13 anon definer RPC | `20260101000600_guv13_...sql` (+rollback) | İzole DB yok |
| B7 | GUV-13b kapsam dışı 19 definer | `20260101000800_guv13b_...sql` (+rollback) | İzole DB yok |
| B8 | GUV-14 NULL search_path (4) | `20260101000700_guv14_...sql` (+rollback) | İzole DB yok |
| B9 | GUV-15 boş+niteliksiz search_path (7) | `20260101000900_guv15_...sql` (+rollback) | İzole DB yok |

**Canlı kanıt (bu tur):** `storage_tenant_ok`=YOK, `null_searchpath`=4, `definer_total`=162 →
**9 migration'ın hiçbiri uygulanmadı, veri katmanı açık.**

---

## C) PREPARED — NOT APPLIED (çözüm hazır, sisteme yazılmadı)

| # | Madde | Neden uygulanamadı |
|---|---|---|
| C1 | GUV-04 ortak CORS modülü (`_shared/cors.ts`) | Workspace'te dosya oluşturulamıyor (yalnız `deploy_edge_function`); **canlı deploy yasak**. İçerik `SECURITY_FINAL_REMEDIATION_REPORT.md §5.1`'de. |
| C2 | GUV-04 43 fonksiyonun refactor'ü | Edge dosyaları build-dışı → kör refactor runtime'da patlar; **her fonksiyon tek tek test edilerek** dönüştürülmeli. |
| C3 | `ALLOWED_ORIGINS` secret'ı | Secret yazma yasak; gerçek üretim origin'i bu ortamdan **doğrulanamadı**. |

---

## D) BLOCKED (ortam/erişim eksikliği)

| # | Madde | Gerekli girdi |
|---|---|---|
| D1 | Tüm DB runtime testleri (tenant A/B, RLS, Storage, RPC, trigger) | Ayrı Supabase test projesi + şema-only dump + `supabase/tests/security/*` çalıştırma |
| D2 | Ayrı `tsc --noEmit` / `eslint` / `npm audit` / `supabase test db` | Komut yürütücüsü / izole ortam |
| D3 | Supabase Auth ayarları (self-signup kapalı, parola politikası, rate-limit) | Dashboard erişimi |
| D4 | CORS preflight runtime doğrulaması | Deploy + gerçek origin |
| D5 | `.env` git geçmişi denetimi (sır rotate gerekli mi) | Git geçmişi erişimi |
| D6 | Hosting HTTP güvenlik başlıkları (HSTS/nosniff/frame-ancestors) | Hosting/CDN erişimi |

---

## E) NOT APPLICABLE (kod ile yapılamaz)

| # | Madde | Gerekçe |
|---|---|---|
| E1 | GUV-03 sourcemap (`vite.config.ts` yazmaya kapalı) | Platform/dağıtım ayarı gerekir |
| E2 | GUV-10 HTTP yanıt başlıkları | `<meta>` ile verilemez; hosting katmanı |

---

## F) İZLENEN KRİTİK RİSK (en yüksek öncelik)

| Risk | Etki | Kapanış koşulu |
|---|---|---|
| **Veri katmanı canlıda açık** (GUV-01/02/06/07/11/13/13b/14/15 uygulanmadı) | Çok yüksek | İzole ortamda tüm testler PASS → onaylı geçiş → canlı doğrulama |
| **GUV-15 trigger değişikliği** | Orta-yüksek | İzole ortamda trigger regresyon testi PASS olmadan üretime alınmaz |
| **GUV-02 + self-signup** | Yüksek | Self-signup KAPALI doğrulanmadan "kapalı" sayılamaz |

---

## G) KAPANIŞ KRİTERİ HATIRLATMASI

Bir madde ancak şu koşullarla **CLOSED** olur: kök neden belirlendi · düzeltme uygulandı ·
ilgili test **çalıştırıldı ve başarılı** · retest başarılı · işlevsel gerileme yok · rollback planı var.

**Bu turda CLOSED sayısı = 2 (yalnız frontend innerHTML).**
**"Tüm hatalar kapandı" İFADESİ KULLANILMAMIŞTIR.**