import { createContext, useContext, useMemo } from 'react';
import { useAuth } from './AuthContext';

export interface AdminProfile {
  ad: string;
  soyad: string;
  email: string;
  avatar: string; // boş string = baş harf fallback
}

interface AdminProfileContextType {
  profile: AdminProfile;
  fullName: string;
  updateProfile: (patch: Partial<AdminProfile>) => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
}

const AdminProfileContext = createContext<AdminProfileContextType | undefined>(undefined);

/**
 * Admin profil bağdaştırıcısı. Tek doğruluk kaynağı AuthContext'teki gerçek
 * Supabase profile kaydıdır. Bu bağdaştırıcı yalnızca mevcut `profile` şeklini
 * (ad/soyad/email/avatar) korur — UserProfile / Sidebar / ProfileModal aynı
 * `useAdminProfile` arayüzünü kullanmaya devam eder.
 */
export function AdminProfileProvider({ children }: { children: React.ReactNode }) {
  const { profile: authProfile, updateProfile: authUpdate, changePassword: authChangePassword } = useAuth();

  const profile: AdminProfile = useMemo(
    () => ({
      ad: authProfile?.firstName ?? '',
      soyad: authProfile?.lastName ?? '',
      email: authProfile?.email ?? '',
      avatar: authProfile?.avatarUrl ?? '',
    }),
    [authProfile],
  );

  const fullName = useMemo(() => `${profile.ad} ${profile.soyad}`.trim(), [profile.ad, profile.soyad]);

  const updateProfile = useMemo(
    () => (patch: Partial<AdminProfile>) =>
      authUpdate({
        firstName: patch.ad,
        lastName: patch.soyad,
        avatarUrl: patch.avatar,
      }),
    [authUpdate],
  );

  const changePassword = useMemo(
    () => (currentPassword: string, newPassword: string) => authChangePassword(currentPassword, newPassword),
    [authChangePassword],
  );

  const value = useMemo(
    () => ({ profile, fullName, updateProfile, changePassword }),
    [profile, fullName, updateProfile, changePassword],
  );

  return <AdminProfileContext.Provider value={value}>{children}</AdminProfileContext.Provider>;
}

export function useAdminProfile() {
  const ctx = useContext(AdminProfileContext);
  if (!ctx) throw new Error('useAdminProfile must be used within AdminProfileProvider');
  return ctx;
}