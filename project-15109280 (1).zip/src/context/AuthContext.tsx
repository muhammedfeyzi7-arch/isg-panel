import { createContext, useContext, useEffect, useState, useCallback, useMemo, useRef } from 'react';
import type { ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import type { Session, User } from '@supabase/supabase-js';
import { logAuthEvent } from '@/lib/logService';
import { logError } from '@/utils/errorLogger';
import { withTimeout, BOOTSTRAP_TIMEOUT_MS } from '@/lib/asyncTimeout';
import { clearClientCaches } from '@/lib/clientCacheReset';
import { PasswordReauthRequiredError, isReauthRequired, requestReauthNonce } from '@/lib/passwordReauth';
import { friendlyAuthError } from '@/lib/authErrorMessages';
import { clearSessionTimes, clearSessionEndNotice, setSessionEndNotice } from '@/lib/sessionPolicy';

/**
 * "Beni hatırla" oturum kalıcılığı anahtarları.
 *
 * Supabase oturumu varsayılan olarak localStorage'da kalıcıdır (tarayıcı
 * kapansa da kalır). "Beni hatırla" KAPALIysa, kullanıcı tarayıcıyı kapatıp
 * yeniden açtığında oturumun düşmesi gerekir. Bunu bir işaretle uygularız:
 *   - localStorage[REMEMBER_KEY] = '1' | '0'  → kullanıcı tercihi
 *   - sessionStorage[SESSION_MARK_KEY] = '1'  → bu TARAYICI OTURUMUNDA giriş yapıldı
 * Tarayıcı kapanınca sessionStorage temizlenir; uygulama açılışında
 * "hatırlama kapalı + işaret yok" ise oturum güvenli şekilde düşürülür.
 */
const REMEMBER_KEY = 'isg:auth-remember';
const SESSION_MARK_KEY = 'isg:auth-session';

function markSessionActive(): void {
  try { sessionStorage.setItem(SESSION_MARK_KEY, '1'); } catch { /* storage kapalı olabilir */ }
}

/**
 * Oturum sunucuda iptal edildi mi? (şifre değişimi veya "tüm/başka cihazlardaki
 * oturumları kapat" işleminden sonra yenileme belirteci geçersiz olur)
 *
 * GoTrue bu durumda `Invalid Refresh Token: Refresh Token Not Found` benzeri bir
 * hata döndürür. Bu, kullanıcının bilerek çıkış yapmasından FARKLIDIR ve giriş
 * ekranında açıklayıcı bir mesajla karşılanmalıdır.
 */
function isRevokedSessionError(e: unknown): boolean {
  const m = (typeof e === 'string' ? e : ((e as { message?: string })?.message ?? '')).toLowerCase();
  return (
    m.includes('refresh token') ||
    m.includes('refresh_token_not_found') ||
    m.includes('session_not_found') ||
    m.includes('session not found')
  );
}

/**
 * Geçici ağ hıçkırığı mı? (cold-start / kısa kesinti / gateway hiccup)
 * Yalnızca bu durumda girişi SESSİZCE bir kez daha deneriz; kimlik bilgisi
 * hatalarında (invalid credentials vb.) tekrar denenmez.
 */
function isTransientAuthNetworkError(e: unknown): boolean {
  const m = (typeof e === 'string' ? e : ((e as { message?: string })?.message ?? '')).toLowerCase();
  return (
    m.includes('failed to fetch') ||
    m.includes('network') ||
    m.includes('fetch failed') ||
    m.includes('load failed') ||
    m.includes('timeout')
  );
}

export interface AuthProfile {
  id: string;
  email: string;
  role: string;
  firstName: string;
  lastName: string;
  avatarUrl: string;
  osgbId: string | null;
  firmaId: string | null;
}

interface AuthContextValue {
  session: Session | null;
  user: User | null;
  profile: AuthProfile | null;
  loading: boolean;
  signIn: (email: string, password: string, remember?: boolean) => Promise<AuthProfile>;
  signOut: () => Promise<void>;
  /** Kullanıcının TÜM cihazlardaki oturumlarını (refresh token'larını) sunucuda iptal eder. */
  signOutEverywhere: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  updateProfile: (patch: { firstName?: string; lastName?: string; avatarUrl?: string }) => Promise<void>;
  /** Mevcut şifreyi (hesaba yeniden giriş yaparak) doğrular; şifreyi DEĞİŞTİRMEZ. */
  verifyCurrentPassword: (currentPassword: string) => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  /** PENTEST F1: e-postaya tek kullanımlık yeniden doğrulama kodu gönderir. */
  requestPasswordReauthNonce: () => Promise<void>;
  /** PENTEST F1: e-postaya gelen kod (nonce) ile şifreyi değiştirir. */
  changePasswordWithNonce: (newPassword: string, nonce: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function fetchProfile(userId: string): Promise<AuthProfile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, email, role, first_name, last_name, avatar_url, osgb_id, firma_id')
    .eq('id', userId)
    .maybeSingle();
  if (error || !data) return null;
  return {
    id: data.id,
    email: data.email,
    role: data.role,
    firstName: data.first_name ?? '',
    lastName: data.last_name ?? '',
    avatarUrl: data.avatar_url ?? '',
    osgbId: data.osgb_id ?? null,
    firmaId: data.firma_id ?? null,
  };
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<AuthProfile | null>(null);
  const [loading, setLoading] = useState(true);

  // Kullanıcının kendi başlattığı çıkış mı? (şifre değişimi / uzaktan iptal ile
  // karışmaması için) — sadece zaman damgası tutulur.
  const intentionalSignOutAtRef = useRef(0);
  // Oturumun gerçekten açık olduğu bir an oldu mu? (ilk açılışta "oturum sona
  // erdi" mesajı göstermemek için)
  const hadUserRef = useRef(false);

  useEffect(() => {
    let mounted = true;

    // İlk oturum + profil yüklemesi.
    const load = async () => {
      try {
        // "Beni hatırla" politikası: hatırlama KAPALI ve bu tarayıcı oturumunda
        // giriş işareti YOKSA (yani tarayıcı kapatılıp yeniden açılmışsa) oturumu düşür.
        try {
          const remembered = localStorage.getItem(REMEMBER_KEY);
          const sessionActive = sessionStorage.getItem(SESSION_MARK_KEY) === '1';
          if (remembered === '0' && !sessionActive) {
            intentionalSignOutAtRef.current = Date.now();
            await withTimeout(supabase.auth.signOut(), BOOTSTRAP_TIMEOUT_MS);
          } else {
            markSessionActive();
          }
        } catch { /* storage erişilemezse varsayılan davranış korunur */ }
        const { data, error: sessionError } = await withTimeout(supabase.auth.getSession(), BOOTSTRAP_TIMEOUT_MS);
        if (!mounted) return;
        // Sunucuda iptal edilmiş bir oturumla dönülüyorsa (şifre değişimi /
        // oturumların kapatılması) giriş ekranında nedenini açıklayalım.
        if (sessionError && isRevokedSessionError(sessionError)) {
          setSessionEndNotice('security');
        }
        const s = data.session;
        setSession(s);
        setUser(s?.user ?? null);
        if (s?.user) {
          hadUserRef.current = true;
          const p = await withTimeout(fetchProfile(s.user.id), BOOTSTRAP_TIMEOUT_MS);
          if (mounted) setProfile(p);
        }
      } catch (e) {
        // Auth bootstrap ASLA sessizce takılmamalı: getSession/fetchProfile ağ hatası
        // fırlatırsa loading sonsuza kadar true kalır ve ekran spinner'da donar
        // (açılışta "sonsuz yükleme" belirtisinin kök nedeni). Hatayı logla, akışı
        // serbest bırak; geçerli oturum yoksa kullanıcı /login'e yönlendirilir.
        logError(e, { source: 'auth-bootstrap', componentName: 'AuthProvider' });
      } finally {
        if (mounted) setLoading(false);
      }
    };
    load();

    // onAuthStateChange callback'i SENKRON dönmeli — supabase çağrıları .then()
    // ile non-blocking yapılır (deadlock önlenir).
    const { data: sub } = supabase.auth.onAuthStateChange((event, s) => {
      // GEÇİCİ ≠ LOGOUT: Ağ / token-refresh hıçkırığı yanıltıcı bir SIGNED_OUT
      // üretebilir. Böyle bir durumda kullanıcıyı PANELDEN DÜŞÜRMEMEK için önce
      // gerçekten geçerli bir oturum kalmış mı doğrularız. Session zaten null'sa
      // (gerçek çıkış) temizleriz. Callback SENKRON döner (promise beklenmez).
      if (event === 'SIGNED_OUT') {
        void supabase.auth.getSession().then(({ data }) => {
          if (!mounted) return;
          if (data.session) {
            setSession(data.session);
            setUser(data.session.user);
          } else {
            // Oturum kendiliğinden düştüyse (kullanıcı çıkış yapmadıysa) bunun
            // nedeni büyük olasılıkla güvenliktir: şifre başka bir cihazda
            // değiştirildi veya oturumlar kapatıldı. Kullanıcıya "oturum geçersiz"
            // gibi teknik ifade yerine ne olduğunu açıklayan mesaj gösterilir.
            const intentional = Date.now() - intentionalSignOutAtRef.current < 8000;
            if (!intentional && hadUserRef.current) {
              setSessionEndNotice('security');
            }
            hadUserRef.current = false;
            setSession(null);
            setUser(null);
            setProfile(null);
          }
        });
        return;
      }
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) hadUserRef.current = true;
      if (event === 'SIGNED_IN' && s?.user) {
        fetchProfile(s.user.id).then((p) => {
          // Profil henüz oluşmadıysa (null) mevcut profile state'ini boşaltma —
          // signIn kendi fetchProfile + setProfile akışıyla zaten dolduracaktır.
          if (mounted && p) setProfile(p);
        });
      }
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
  }, []);

  const signIn = useCallback(async (email: string, password: string, remember = true): Promise<AuthProfile> => {
    let result = await supabase.auth.signInWithPassword({ email, password });
    // Geçici ağ hıçkırığında (cold-start / kısa kesinti) kullanıcıya yanlışlıkla
    // "Bağlantı kurulamadı" göstermemek için SESSİZCE tek sefer yeniden deneriz.
    // Kimlik bilgisi hatalarında (invalid credentials) tekrar DENENMEZ.
    if (result.error && isTransientAuthNetworkError(result.error)) {
      await new Promise((r) => setTimeout(r, 700));
      result = await supabase.auth.signInWithPassword({ email, password });
    }
    const { data, error } = result;
    if (error) throw error;
    // Profil oluşturma (davet kabulü) ile olası yarışı gidermek için kademeli retry.
    // Hesap az önce oluşturulmuşsa profil satırı bir milisaniye gecikmeli görünebilir.
    let p = await fetchProfile(data.user.id);
    if (!p) {
      for (const delay of [300, 700, 1200]) {
        await new Promise((r) => setTimeout(r, delay));
        p = await fetchProfile(data.user.id);
        if (p) break;
      }
    }
    if (!p) throw new Error('Profil bulunamadı');
    // Başarılı girişten SONRA hatırlama tercihini ve oturum işaretini yaz.
    // (Hatalı denemelerde tercih/işaret değişmez.)
    try {
      localStorage.setItem(REMEMBER_KEY, remember ? '1' : '0');
      markSessionActive();
    } catch { /* storage kapalı olabilir */ }
    setProfile(p);
    hadUserRef.current = true;
    // Önceki oturumdan kalan "neden kapandı" bilgisi yeni girişte gösterilmesin.
    clearSessionEndNotice();
    void logAuthEvent('AUTH_LOGIN_SUCCESS');
    return p;
  }, []);

  const signOut = useCallback(async () => {
    intentionalSignOutAtRef.current = Date.now();
    hadUserRef.current = false;
    void logAuthEvent('AUTH_LOGOUT');
    try { sessionStorage.removeItem(SESSION_MARK_KEY); } catch { /* ignore */ }
    await supabase.auth.signOut();
    clearSessionTimes();
    // Önceki kullanıcının istemci veri cache'ini (SWR / sekme verisi) temizle:
    // aynı tarayıcıda farklı kullanıcıyla girişte artık veri görünmemeli.
    clearClientCaches();
    setSession(null);
    setUser(null);
    setProfile(null);
  }, []);

  /**
   * Tüm cihazlardaki oturumları kapatır.
   *
   * `scope: 'global'` GoTrue'da kullanıcının TÜM refresh token'larını sunucuda
   * iptal eder. Yalnızca istemci belleğini silmek yetmez; bu yüzden kararı
   * sunucu verir. Mevcut cihaz da çıkış yapar (beklenen davranış).
   */
  const signOutEverywhere = useCallback(async () => {
    intentionalSignOutAtRef.current = Date.now();
    hadUserRef.current = false;
    void logAuthEvent('AUTH_LOGOUT');
    try { sessionStorage.removeItem(SESSION_MARK_KEY); } catch { /* ignore */ }
    try {
      await supabase.auth.signOut({ scope: 'global' });
    } finally {
      clearSessionTimes();
      clearClientCaches();
      setSession(null);
      setUser(null);
      setProfile(null);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    if (data.session?.user) {
      const p = await fetchProfile(data.session.user.id);
      if (p) setProfile(p);
    }
  }, []);

  const updateProfile = useCallback(
    async (patch: { firstName?: string; lastName?: string; avatarUrl?: string }) => {
      const { data } = await supabase.auth.getSession();
      const userId = data.session?.user.id;
      if (!userId) throw new Error('Oturumunuz sona ermiş görünüyor. Lütfen sayfayı yenileyip yeniden giriş yapın.');
      const { error } = await supabase
        .from('profiles')
        .update({
          first_name: patch.firstName,
          last_name: patch.lastName,
          avatar_url: patch.avatarUrl,
        })
        .eq('id', userId);
      if (error) throw error;
      setProfile((prev) =>
        prev
          ? {
              ...prev,
              firstName: patch.firstName ?? prev.firstName,
              lastName: patch.lastName ?? prev.lastName,
              avatarUrl: patch.avatarUrl ?? prev.avatarUrl,
            }
          : prev,
      );
    },
    [],
  );

  /**
   * Mevcut şifreyi doğrular (aynı hesapla yeniden giriş yaparak).
   * Şifreyi DEĞİŞTİRMEZ — kod adımının ilk aşaması bunu kullanır.
   */
  const verifyCurrentPassword = useCallback(async (currentPassword: string) => {
    const { data: sessionData } = await supabase.auth.getSession();
    const email = sessionData.session?.user?.email;
    if (!email) throw new Error('Oturumunuz sona ermiş görünüyor. Lütfen sayfayı yenileyip yeniden giriş yapın.');

    // Yeni şifre mevcut şifreyle aynı olamaz — sunucuya gitmeden burada durdur.
    if (currentPassword.length === 0) throw new Error('Mevcut şifre zorunludur.');

    const { error: verifyError } = await supabase.auth.signInWithPassword({
      email,
      password: currentPassword,
    });
    if (!verifyError) return;

    // YALNIZCA gerçekten hatalı şifrede "Mevcut şifre hatalı" denir. Aksi halde
    // (hız sınırı, ağ kesintisi, e-posta doğrulanmamış vb.) kullanıcı suçu
    // şifresinde sanmasın diye hata kendi mesajıyla iletilir.
    const raw = String((verifyError as { message?: string })?.message ?? '').toLowerCase();
    if (raw.includes('invalid login credentials') || raw.includes('invalid_credentials')) {
      throw new Error('Mevcut şifre hatalı.');
    }
    if (raw.includes('rate limit') || raw.includes('too many requests') || raw.includes('security purposes')) {
      throw new Error('Çok fazla deneme yapıldı. Lütfen kısa bir süre sonra tekrar deneyin.');
    }
    throw new Error(friendlyAuthError(verifyError, 'Mevcut şifre doğrulanamadı. Lütfen tekrar deneyin.'));
  }, []);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    if (currentPassword && currentPassword === newPassword) {
      throw new Error('Yeni şifreniz mevcut şifrenizle aynı olamaz. Lütfen farklı bir şifre belirleyin.');
    }
    // Mevcut şifreyi doğrula: aynı hesaba giriş yaparak teyit et (Supabase Auth).
    await verifyCurrentPassword(currentPassword);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      // PENTEST F1: sunucu yeniden doğrulama istiyorsa çağıran katman (form)
      // e-posta kodu akışına geçebilsin diye tipli hata fırlatılır.
      if (isReauthRequired(error)) throw new PasswordReauthRequiredError();
      throw error;
    }
    // GÜVENLİK: Parola değişiminden sonra DİĞER tüm oturumların refresh token'ları
    // iptal edilir (scope: 'others' → mevcut oturum korunur). Böylece parolayı bilen
    // eski bir cihaz/oturumun erişimi sona erer. İptal başarısız olsa bile parola
    // değişikliği (ana işlem) geri alınmaz; hata loglanır.
    try {
      await supabase.auth.signOut({ scope: 'others' });
    } catch (e) {
      logError(e, { source: 'auth-change-password', componentName: 'AuthProvider' });
    }
  }, [verifyCurrentPassword]);

  /**
   * PENTEST F1: e-postaya tek kullanımlık yeniden doğrulama kodu (nonce) gönderir.
   *
   * ÖNEMLİ: GoTrue, taze oturumlarda şifre güncellemesinde nonce İSTEMEZ
   * (24 saatten eski oturumlarda ister). Formun her seferinde kod adımını
   * gösterebilmesi için kodu BİZ açıkça talep ediyoruz.
   *
   * Sıra: SDK `reauthenticate()` → yoksa doğrudan GoTrue REST `/reauthenticate`.
   * Uç nokta yoksa `ReauthUnsupportedError` fırlatılır (form eski akışa düşer).
   */
  const requestPasswordReauthNonce = useCallback(async () => {
    // Mantık tek yerde: lib/passwordReauth.requestReauthNonce.
    // (Şifre sıfırlama ekranı da aynı yardımcıyı kullanır.)
    await requestReauthNonce();
  }, []);

  const changePasswordWithNonce = useCallback(async (newPassword: string, nonce: string) => {
    // GoTrue, e-posta ile gelen tek kullanımlık kodu `nonce` alanında bekler.
    const { error } = await supabase.auth.updateUser({
      password: newPassword,
      nonce: nonce.trim(),
    } as unknown as { password: string });
    if (error) {
      if (isReauthRequired(error)) throw new PasswordReauthRequiredError();
      throw error;
    }
    try {
      await supabase.auth.signOut({ scope: 'others' });
    } catch (e) {
      logError(e, { source: 'auth-change-password-nonce', componentName: 'AuthProvider' });
    }
  }, []);

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      user,
      profile,
      loading,
      signIn,
      signOut,
      signOutEverywhere,
      refreshProfile,
      updateProfile,
      verifyCurrentPassword,
      changePassword,
      requestPasswordReauthNonce,
      changePasswordWithNonce,
    }),
    [
      session,
      user,
      profile,
      loading,
      signIn,
      signOut,
      signOutEverywhere,
      refreshProfile,
      updateProfile,
      verifyCurrentPassword,
      changePassword,
      requestPasswordReauthNonce,
      changePasswordWithNonce,
    ],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}