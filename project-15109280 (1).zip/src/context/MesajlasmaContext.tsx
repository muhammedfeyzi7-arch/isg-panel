import { createContext, useContext, useEffect, useState, useCallback, useMemo, useRef } from 'react';
import type { ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { fetchUnreadCount, updatePresence } from '@/lib/mesajlasmaService';
import { runWhenIdle } from '@/lib/idleScheduler';
import { coalesce } from '@/lib/requestCoalescer';

interface MesajlasmaContextValue {
  unreadCount: number;
  refreshUnread: () => Promise<void>;
}

const MesajlasmaContext = createContext<MesajlasmaContextValue | undefined>(undefined);

export function MesajlasmaProvider({ children }: { children: ReactNode }) {
  const { profile } = useAuth();
  // Kullanıcı PRİMİTİFİ: realtime kanalı ve presence YALNIZCA bu değere bağlanır.
  // Profil nesnesi referansı (ad/avatar) değişse bile kanal YENİDEN açılmaz.
  const profileId = profile?.id ?? null;
  const [unreadCount, setUnreadCount] = useState(0);
  const debounceRef = useRef<number | null>(null);

  const refreshUnread = useCallback(async () => {
    if (!profileId) {
      setUnreadCount(0);
      return;
    }
    try {
      // Eşzamanlı tekrar tetiklemeleri (realtime burst + sekme dönüşü + poll + idle)
      // TEK in-flight ağ çağrısına indir; biten çağrıdan sonraki tetikleme taze çeker.
      const n = await coalesce(`mesajlasma-unread:${profileId}`, fetchUnreadCount);
      setUnreadCount(n);
    } catch {
      /* sessiz — sayı güncellenemezse mevcut değer korunur */
    }
  }, [profileId]);

  // Realtime event burst'ünü tek refetch'e sıkıştır (duplicate sayaç engeli).
  const scheduleRefresh = useCallback(() => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    debounceRef.current = window.setTimeout(() => {
      void refreshUnread();
    }, 400);
  }, [refreshUnread]);

  // NOT (performans): İlk okunmamış sayaç çekimi bilinçli olarak boşa (idle) ertelenir
  // (aşağıda). Burada ANINDA çağrı YAPILMAZ; aksi halde erteleme etkisiz kalırdı.
  // Realtime event + 30sn poll hatası yine anında günceller.

  // Presence (son görülme): oturum açıkken hafif heartbeat (60sn) + sekme odağı.
  useEffect(() => {
    if (!profileId) return undefined;
    // Presence "best-effort" bir arka plan işidir: oturum token'ı bayatladığında
    // (401 Yetkisiz erisim) bile kullanıcıya hata yansıtmamalı — sessizce yutulur,
    // oturum yenilendiğinde bir sonraki heartbeat kendiliğinden düzelir.
    const beat = () => {
      updatePresence().catch(() => {
        /* sessiz — presence best-effort */
      });
    };
    // PERFORMANS: İlk presence heartbeat de AÇILIŞ İÇİN KRİTİK DEĞİL; boşta gönderilir.
    const cancelInitialBeat = runWhenIdle(beat);
    const iv = window.setInterval(() => {
      // Yalnızca sekme görünürken heartbeat at (arka planda gereksiz istek yok).
      if (document.visibilityState === 'visible') beat();
    }, 60000);
    const onVis = () => {
      if (document.visibilityState === 'visible') beat();
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      cancelInitialBeat();
      window.clearInterval(iv);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [profileId]);

  // Realtime + 30sn poll fallback (realtime publication kurulu değilse dahi doğru kalır).
  useEffect(() => {
    if (!profileId) return undefined;

    const channel = supabase
      .channel('mesajlasma-unread')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, () => scheduleRefresh())
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'message_reads' }, () => scheduleRefresh())
      .subscribe();

    // Poll güvenlik ağı: yalnızca sekme GÖRÜNÜR iken çalışır. Arka planda interval
    // durdurulur; sekme geri gelince ANINDA sayı tazelenir (okunmamış rozeti
    // gecikmez) ve interval yeniden başlar.
    let poll: number | null = null;
    const startPoll = () => {
      if (poll === null) {
        poll = window.setInterval(() => {
          if (document.visibilityState === 'visible') void refreshUnread();
        }, 30000);
      }
    };
    const stopPoll = () => {
      if (poll !== null) {
        window.clearInterval(poll);
        poll = null;
      }
    };
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        void refreshUnread();
        startPoll();
      } else {
        stopPoll();
      }
    };
    const onOnline = () => void refreshUnread();
    if (document.visibilityState === 'visible') startPoll();
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('online', onOnline);

    return () => {
      void supabase.removeChannel(channel);
      stopPoll();
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('online', onOnline);
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [profileId, scheduleRefresh, refreshUnread]);

  useEffect(() => runWhenIdle(() => {
    // PERFORMANS: Okunmamış sayaç ilk çekimi AÇILIŞ İÇİN KRİTİK DEĞİL; boşta çalıştırılır.
    // Realtime event + 30sn poll hatası yine anında günceller.
    void refreshUnread();
  }), [refreshUnread]);

  const value = useMemo(() => ({ unreadCount, refreshUnread }), [unreadCount, refreshUnread]);

  return <MesajlasmaContext.Provider value={value}>{children}</MesajlasmaContext.Provider>;
}

export function useMesajlasma() {
  const ctx = useContext(MesajlasmaContext);
  if (!ctx) throw new Error('useMesajlasma must be used within MesajlasmaProvider');
  return ctx;
}