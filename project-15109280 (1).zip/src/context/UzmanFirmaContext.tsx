import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { fetchUzmanFirmalari, type UzmanFirma } from '@/lib/personelService';
import { useAuth } from './AuthContext';

interface UzmanFirmaContextValue {
  firmalar: UzmanFirma[];
  selectedFirmaId: string;
  setSelectedFirmaId: (id: string) => void;
}

const UzmanFirmaContext = createContext<UzmanFirmaContextValue | undefined>(undefined);

/**
 * Uzman paneli için GLOBAL firma seçimi. Firma seçici topbar'da yaşar; seçim
 * tüm uzman sekmeleri (personeller, evraklar, tutanaklar vb.) tarafından paylaşılır.
 * "destek" gibi firma-bağımsız sayfalar bu context'i okumadığından etkilenmez.
 * Seçim localStorage'da saklanır; sayfa yenilense veya sekme değişse bile korunur.
 * Yalnızca uzman rolünde firma listesi doldurulur; diğer roller boş alır.
 */
const STORAGE_SUFFIX = 'selectedFirmaId';

/** Firma-bağımlı paneller (uzman/hekim) için role özel saklama anahtarı. */
function storageKey(role: string | null): string {
  return role ? `${role}:${STORAGE_SUFFIX}` : STORAGE_SUFFIX;
}

function readStoredFirmaId(key: string): string {
  try {
    return window.localStorage.getItem(key) ?? '';
  } catch {
    return '';
  }
}

export function UzmanFirmaProvider({ children }: { children: ReactNode }) {
  const { profile } = useAuth();
  // Firma-bağımlı paneller: Uzman ve Hekim aynı global firma seçimini paylaşır
  // (her rol kendi anahtarında saklar). Diğer roller boş alır.
  const scopedRole = profile?.role === 'uzman' || profile?.role === 'hekim' ? profile.role : null;

  const [firmalar, setFirmalar] = useState<UzmanFirma[]>([]);
  const [selectedFirmaId, setSelectedFirmaIdState] = useState<string>(() => readStoredFirmaId(storageKey(scopedRole)));

  const setSelectedFirmaId = useCallback((id: string) => {
    setSelectedFirmaIdState(id);
    try {
      if (id) window.localStorage.setItem(storageKey(scopedRole), id);
      else window.localStorage.removeItem(storageKey(scopedRole));
    } catch {
      // localStorage kullanılamıyorsa sessizce geç (sadece kalıcılık kaybı olur).
    }
  }, [scopedRole]);

  useEffect(() => {
    if (!scopedRole) {
      setFirmalar([]);
      setSelectedFirmaIdState('');
      return;
    }
    let cancelled = false;
    fetchUzmanFirmalari()
      .then((list) => {
        if (cancelled) return;
        setFirmalar(list);
        // Seçimi geri yükle: saklı seçim listede varsa koru, yoksa sıfırla.
        setSelectedFirmaIdState((prev) => {
          const stored = prev || readStoredFirmaId(storageKey(scopedRole));
          if (stored && list.some((f) => f.id === stored)) return stored;
          if (stored) {
            try {
              window.localStorage.removeItem(storageKey(scopedRole));
            } catch {
              // yoksay
            }
          }
          return '';
        });
      })
      .catch(() => {
        if (!cancelled) setFirmalar([]);
      });
    return () => {
      cancelled = true;
    };
  }, [scopedRole]);

  const value = useMemo<UzmanFirmaContextValue>(
    () => ({ firmalar, selectedFirmaId, setSelectedFirmaId }),
    [firmalar, selectedFirmaId, setSelectedFirmaId],
  );

  return <UzmanFirmaContext.Provider value={value}>{children}</UzmanFirmaContext.Provider>;
}

export function useUzmanFirma() {
  const ctx = useContext(UzmanFirmaContext);
  if (!ctx) throw new Error('useUzmanFirma must be used within UzmanFirmaProvider');
  return ctx;
}