import { createContext, useContext, useState, useEffect, useLayoutEffect, useCallback, useMemo } from 'react';

type Theme = 'dark' | 'light' | 'auto';
type ResolvedTheme = 'dark' | 'light';

interface ThemeContextType {
  theme: Theme;
  resolvedTheme: ResolvedTheme;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const STORAGE_KEY = 'isgdenetim-theme';

// ────────────────────────────────────────────────────────────────────
// İSGDenetim OTOMATİK TEMA MODU — zaman tabanlı (local saat).
// Kullanıcının cihaz/işletim sistemi tercihi (prefers-color-scheme)
// KULLANILMAZ. "Sistem/System" modu yoktur.
//   Gündüz      (06:00–17:59) → Açık (light)
//   Akşam/Gece  (18:00–05:59) → Koyu  (dark)
// Saat eşikleri TEK YERDE tanımlıdır — tüm uygulama buradan beslenir.
// ────────────────────────────────────────────────────────────────────
const DAY_START_HOUR = 6; // 06:00 — gündüz başlangıcı
const NIGHT_START_HOUR = 18; // 18:00 — akşam/gece başlangıcı

// Depolama erişimini güvenli hale getir: bazı tarayıcılar (gizli mod vb.)
// localStorage erişiminde throw edebilir. Bu durumda uygulama çökmesin,
// tema oturum boyunca yine de doğru uygulanır.
function readStoredTheme(): Theme | null {
  try {
    const saved = localStorage.getItem(STORAGE_KEY) as Theme | null;
    return saved === 'dark' || saved === 'light' || saved === 'auto' ? saved : null;
  } catch {
    return null;
  }
}

function writeStoredTheme(theme: Theme) {
  try {
    localStorage.setItem(STORAGE_KEY, theme);
  } catch {
    // Depolama kullanılamıyorsa sessizce yoksay — tercih yine de state'te tutulur.
  }
}

// Kullanıcının cihaz YEREL saatine göre otomatik temayı çöz.
// Server/UTC saati kullanılmaz; işletim sistemi tercihi kullanılmaz.
function getAutoTheme(): ResolvedTheme {
  const hour = new Date().getHours();
  return hour >= NIGHT_START_HOUR || hour < DAY_START_HOUR ? 'dark' : 'light';
}

// Auto modda bir sonraki saat eşiğine (18:00 veya 06:00) kadar geçen milisaniye.
// Gece ise sabah 06:00'a, gündüz ise akşam 18:00'a kadar sayar.
function msUntilNextThreshold(): number {
  const now = new Date();
  const hour = now.getHours();
  const target = hour >= NIGHT_START_HOUR || hour < DAY_START_HOUR
    ? DAY_START_HOUR
    : NIGHT_START_HOUR;
  const next = new Date(now);
  next.setHours(target, 0, 0, 0);
  if (next.getTime() <= now.getTime()) {
    next.setDate(next.getDate() + 1);
  }
  return next.getTime() - now.getTime();
}

// Tema değişimi ANINDA olmalı — hiçbir transition/fade yok.
// `.theme-transitioning` class'ı geçici olarak tüm CSS transition'larını kapatır,
// `.dark` class'ı atomik şekilde uygulanır, ardından bir sonraki paint'ten sonra
// transition'lar geri açılır. Böylece tema değişimi "tak diye" olur.
function applyTheme(resolved: ResolvedTheme) {
  const root = document.documentElement;
  // Browser chrome (iOS Safari status bar / Android Chrome address bar / WebView)
  // rengini tema ile eşle — iOS/Android/WebView aynı doğal davranışı kullanır.
  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) metaTheme.setAttribute('content', resolved === 'dark' ? '#0B1118' : '#F4F7FA');

  // Tema değişimi ANINDA olmalı (sıfır animasyon):
  // 1) Önce transition kilidini aç (html.theme-transitioning → tüm alt
  //    elemanlarda transition/animation kapatılır).
  // 2) Style flush zorla; kilidin, tema rengi DEĞİŞMEDEN önce aktif olduğunu
  //    garanti et (yarış durumu / tek karelik fade oluşmaz).
  // 3) .dark class'ını atomik uygula → renkler tak diye değişir.
  // 4) İki kare sonra kilidi kaldır; artık değişecek renk kalmadığı için
  //    normal hover/focus transition'ları geri gelir.
  root.classList.add('theme-transitioning');
  void root.offsetWidth;
  if (resolved === 'dark') {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      root.classList.remove('theme-transitioning');
    });
  });
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => readStoredTheme() ?? 'auto');

  const [autoTheme, setAutoTheme] = useState<ResolvedTheme>(getAutoTheme);

  // TEK MERKEZİ auto timer: yalnızca 'auto' modundayken bir sonraki saat eşiğinde
  // otomatik tema değişimi tetiklenir. Manual light/dark seçiliyken timer kurulmaz
  // (zaman değişimi temayı etkilememeli). Route/panel değişiminde duplicate timer
  // oluşmaz — effect yalnızca 'theme' değeri değişince yeniden kurulur.
  useEffect(() => {
    if (theme !== 'auto') return;

    let timeoutId: ReturnType<typeof setTimeout>;
    const schedule = () => {
      timeoutId = setTimeout(() => {
        setAutoTheme(getAutoTheme());
        schedule();
      }, msUntilNextThreshold());
    };
    schedule();

    return () => clearTimeout(timeoutId);
  }, [theme]);

  const resolvedTheme = useMemo<ResolvedTheme>(
    () => (theme === 'auto' ? autoTheme : theme),
    [theme, autoTheme],
  );

  // useLayoutEffect: ilk boyamadan önce uygulanır (FOUC olmaz) ve her değişimde atomik uygulanır
  useLayoutEffect(() => {
    applyTheme(resolvedTheme);
  }, [resolvedTheme]);

  const setTheme = useCallback((newTheme: Theme) => {
    setThemeState(newTheme);
    writeStoredTheme(newTheme);
  }, []);

  const value = useMemo(() => ({ theme, resolvedTheme, setTheme }), [theme, resolvedTheme, setTheme]);

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}