/**
 * SHARED UI CORE — İSGDenetim'in TEK UI giriş noktası.
 *
 * Bu dosya uygulamadaki TÜM ortak UI'nın zorunlu tek kaynağıdır.
 * Yeni panel/sekme/ekran aşağıdaki gibi SADECE buradan import eder:
 *
 *   import { Button, Modal, TableListing, useModal, useTheme } from '@/components';
 *
 * Panel başına özel UI componenti OLUŞTURULMAZ. Bir ihtiyaç eksikse
 * önce Shared UI Core'a eklenir, sonra buradan tüketilir.
 * (Kurallar: project_plan.md — "UI MİMARİSİ KİLİDİ" bölümleri A–O)
 */

/* ============================================================
 * 1. DESIGN TOKENS + THEME (renk / typography / spacing / radius)
 * ============================================================ */
export { ThemeProvider, useTheme } from '@/context/ThemeContext';
export { AdminProfileProvider, useAdminProfile } from '@/context/AdminProfileContext';
export type { AdminProfile } from '@/context/AdminProfileContext';

/* ============================================================
 * 2. LAYOUT / NAVIGATION
 * ============================================================ */
export { default as Shell } from '@/components/feature/Shell';
export { default as Sidebar } from '@/components/feature/Sidebar';
export { default as Topbar } from '@/components/feature/Topbar';
export { default as BottomNav } from '@/components/feature/BottomNav';
export { default as BrandLogo } from '@/components/feature/BrandLogo';
export { default as ThemeToggle } from '@/components/feature/ThemeToggle';
export { default as NotificationBell } from '@/components/feature/NotificationBell';
export { default as UserProfile } from '@/components/feature/UserProfile';
export { default as ProfileModal } from '@/components/feature/ProfileModal';
export { default as ViewportManager } from '@/components/feature/ViewportManager';

/* ============================================================
 * 3. HEADER / CARD / STAT / BADGE / AVATAR
 * ============================================================ */
export { default as PageHeader } from '@/components/ui/PageHeader';
export { default as SectionTitle } from '@/components/ui/SectionTitle';
export { default as Card } from '@/components/ui/Card';
export { default as StatCard } from '@/components/ui/StatCard';
export { default as Badge } from '@/components/ui/Badge';
export { default as Chip } from '@/components/ui/Chip';
export { default as StatusBadge, segmentToStatusTone } from '@/components/ui/StatusBadge';
export type { StatusTone } from '@/components/ui/StatusBadge';
export { default as Toolbar } from '@/components/ui/Toolbar';
export { default as SegmentedControl } from '@/components/ui/SegmentedControl';
export type { SegmentOption, SegmentTone } from '@/components/ui/SegmentedControl';
export { default as SummaryStats } from '@/components/ui/SummaryStats';
export type { SummaryRow } from '@/components/ui/SummaryStats';
export { default as CategoryList } from '@/components/ui/CategoryList';
export type { CategoryItem } from '@/components/ui/CategoryList';
export { default as AiSuggestPanel } from '@/components/ui/AiSuggestPanel';
export type { AiSuggestion } from '@/components/ui/AiSuggestPanel';
export { default as PhotoUpload } from '@/components/ui/PhotoUpload';
export type { PhotoItem } from '@/components/ui/PhotoUpload';
export { default as PhotoLightbox } from '@/components/ui/PhotoLightbox';
export type { PhotoLightboxItem } from '@/components/ui/PhotoLightbox';
export { default as ImageViewer } from '@/components/ui/ImageViewer';
export type { ImageViewerItem } from '@/components/ui/ImageViewer';
export { default as Avatar } from '@/components/ui/Avatar';
export { getInitials } from '@/components/ui/Avatar';
export { default as AvatarUpload } from '@/components/ui/AvatarUpload';

/* ============================================================
 * 4. BUTTON / ICON BUTTON / ICON
 * ============================================================ */
export { default as Button } from '@/components/ui/Button';
export { default as IconButton } from '@/components/ui/IconButton';
export { default as Icon, FileIcon } from '@/components/ui/Icon';
export {
  ICON_REGISTRY,
  ICON_SIZES,
  ICON_TONES,
  DOSYA_TUR_IKON,
  dosyaTuruBul,
  resolveFileIcon,
  fileIconToneClass,
} from '@/lib/icons/iconRegistry';
export type { IconName, IconSize, IconTone, IconDefinition, DosyaTur, ResolvedFileIcon } from '@/lib/icons/iconRegistry';

/* ============================================================
 * 5. FORM (Input / Select / Date / Checkbox / Radio / Toggle / Upload)
 * ============================================================ */
export { default as Input } from '@/components/ui/Input';
export { default as Select } from '@/components/ui/Select';
export type { SelectOption } from '@/components/ui/Select';
export { default as Textarea } from '@/components/ui/Textarea';
export { default as EmailInput } from '@/components/ui/EmailInput';
export { default as PhoneInput } from '@/components/ui/PhoneInput';
export { formatTRPhone } from '@/components/ui/PhoneInput';
export { default as TcKimlikInput } from '@/components/ui/TcKimlikInput';
export { formatTcKimlik } from '@/components/ui/TcKimlikInput';
export { default as ProvinceSelect } from '@/components/ui/ProvinceSelect';
export { default as DistrictSelect } from '@/components/ui/DistrictSelect';
export { default as DatePicker } from '@/components/ui/DatePicker';
export { default as TimePicker } from '@/components/ui/TimePicker';
export { default as DateTimePicker } from '@/components/ui/DateTimePicker';
export { default as Checkbox } from '@/components/ui/Checkbox';
export { default as Radio } from '@/components/ui/Radio';
export { default as Toggle } from '@/components/ui/Toggle';
export { default as MultiSelect } from '@/components/ui/MultiSelect';
export type { MultiSelectOption } from '@/components/ui/MultiSelect';
export { default as Autocomplete } from '@/components/ui/Autocomplete';
export type { AutocompleteOption } from '@/components/ui/Autocomplete';
export { default as FileUpload } from '@/components/ui/FileUpload';
export type { UploadFile } from '@/components/ui/FileUpload';

/* ============================================================
 * 6. SEARCH / FILTER / DROPDOWN / POPOVER
 * ============================================================ */
export { default as Search } from '@/components/ui/Search';
export { default as FilterBar } from '@/components/ui/FilterBar';
export type { FilterField, FilterFieldType, FilterValue } from '@/components/ui/FilterBar';
export { default as DropdownPanel } from '@/components/ui/DropdownPanel';
export { default as ContextMenu } from '@/components/ui/ContextMenu';
export type { ContextMenuItem } from '@/components/ui/ContextMenu';
export { default as ActionMenu } from '@/components/ui/ActionMenu';
export { default as Tooltip } from '@/components/ui/Tooltip';
export { default as Calendar } from '@/components/ui/Calendar';

/* ============================================================
 * 7. TABS
 * ============================================================ */
export { default as TabBar } from '@/components/ui/TabBar';
export type { TabBarItem } from '@/components/ui/TabBar';
export { default as Tabs } from '@/components/ui/Tabs';

/* ============================================================
 * 8. LIST / TABLE / PAGINATION
 * ============================================================ */
export { default as Table } from '@/components/ui/Table';
export type { TableColumn, TableProps } from '@/components/ui/Table';
export { default as TableListing } from '@/components/feature/TableListing';
export { default as Pagination } from '@/components/ui/Pagination';
export { default as SharedListCard } from '@/components/ui/SharedListCard';
export { ListCardBadge } from '@/components/ui/SharedListCard';
export type { SharedListCardProps } from '@/components/ui/SharedListCard';

/* ============================================================
 * 9. MODAL / OVERLAY / ACTION SHEET / WIZARD
 * ============================================================ */
export { default as Modal } from '@/components/ui/Modal';
export { default as ModalManager } from '@/components/ui/ModalManager';
export { default as ActionSheet } from '@/components/ui/ActionSheet';
export type { ListAction, ListActionVariant } from '@/components/ui/ActionSheet';
export { default as BottomSheet } from '@/components/ui/BottomSheet';
export { default as WizardStepper } from '@/components/ui/WizardStepper';
export type { WizardStepDef } from '@/components/ui/WizardStepper';

/* ============================================================
 * 10. STATE (Loading / Empty / Error / Success)
 * ============================================================ */
export { default as Loading } from '@/components/ui/Loading';
export { default as EmptyState } from '@/components/ui/EmptyState';
export { default as ErrorState } from '@/components/ui/ErrorState';
export { default as SuccessState } from '@/components/ui/SuccessState';
export { default as ErrorBoundary } from '@/components/ui/ErrorBoundary';
export { default as ConfirmDialog } from '@/components/ui/ConfirmDialog';
export { default as Alert } from '@/components/ui/Alert';
export { default as ToastManager } from '@/components/ui/ToastManager';

/* ============================================================
 * 11. FORM ACTIONS
 * ============================================================ */
export { default as FormActions } from '@/components/ui/FormActions';

/* ============================================================
 * 12. CHART (feature)
 * ============================================================ */
export { default as DonutChart } from '@/components/feature/DonutChart';
export { default as LineChart } from '@/components/feature/LineChart';

/* ============================================================
 * 13. HOOKS / MOTORLAR
 * ============================================================ */
export * from '@/hooks/useForm';
export { useModal, useModalActions, useModalState, ModalProvider } from '@/hooks/useModal';
export type { ModalVariant, ModalSize, WizardStep, ModalOptions } from '@/hooks/useModal';
export { useToast, useToastActions, useToastState, ToastProvider, toast } from '@/hooks/useToast';
export type { ToastType, ToastAction, ToastItem, ToastInput } from '@/hooks/useToast';
export { useConfirm, useConfirmActions, useConfirmState, ConfirmProvider } from '@/hooks/useConfirm';
export type { ConfirmOptions } from '@/hooks/useConfirm';
export { useBottomSheet, BottomSheetProvider } from '@/hooks/useBottomSheet';
export type { BottomSheetOptions } from '@/hooks/useBottomSheet';
export { useClickOutside, useDropdownPosition } from '@/hooks/useDropdown';
export type { DropdownPosition, DropdownPositionOptions } from '@/hooks/useDropdown';
export { useLongPress } from '@/hooks/useLongPress';
export type { LongPressHandlers } from '@/hooks/useLongPress';
export { useMediaQuery } from '@/hooks/useMediaQuery';
export { useRovingFocus, listboxStep } from '@/hooks/useKeyboardNav';
export type { RovingFocusOptions } from '@/hooks/useKeyboardNav';

/* ============================================================
 * 14. RUNTIME ERROR HANDLING (logger / global yakalayıcı)
 * ============================================================ */
export {
  logError,
  installGlobalErrorHandlers,
  subscribeErrorLogger,
} from '@/utils/errorLogger';

/* ============================================================
 * 15. MERKEZİ DOKÜMAN ÖNİZLEME MOTORU (PDF / Görsel / DOCX / XLSX)
 * Tüm modüller doküman önizlemesini SADECE buradan tüketir.
 * ============================================================ */
export {
  DocumentPreviewEngine,
  SharedDocumentPreview,
  DocumentPreviewModal,
  usePdfDocument,
  detectPreviewKind,
  previewKindLabel,
  previewKindIcon,
  friendlyPreviewError,
  PREVIEW_DEFAULT_STATE,
} from '@/components/feature/preview';
export type {
  SharedDocumentPreviewProps,
  PreviewDocumentSource,
  PreviewDocumentMeta,
  PreviewKind,
  PreviewViewerHandle,
  PreviewViewerState,
} from '@/components/feature/preview';