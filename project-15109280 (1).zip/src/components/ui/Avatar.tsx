import { useState } from 'react';
import { safeAvatarUrl } from '@/lib/avatarUrl';

interface AvatarProps {
  src?: string;
  name?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  status?: 'online' | 'offline' | 'busy' | 'away';
}

const sizeCls = {
  xs: 'w-6 h-6 text-[10px]',
  sm: 'w-8 h-8 text-xs',
  md: 'w-10 h-10 text-sm',
  lg: 'w-12 h-12 text-base',
  xl: 'w-16 h-16 text-lg',
};

const statusColors = {
  online: 'bg-success-500',
  offline: 'bg-foreground-400',
  busy: 'bg-danger-500',
  away: 'bg-warning-500',
};

export function getInitials(name?: string | null): string {
  if (!name) return '';
  return name
    .split(' ')
    .filter(Boolean)
    .map((n) => n[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
}

/**
 * ORTAK Avatar (TEK KAYNAK). Tüm paneller yalnızca bu componenti kullanır.
 *
 * Kırık görsel fallback: src verilse bile yüklenemezse (404 / bozuk URL)
 * otomatik olarak baş harf avatarına düşer, kırık-resim ikonu gösterilmez.
 *
 * GÜVENLİK (PENTEST F5): src yalnızca allowlist'teki alan adlarından geliyorsa
 * render edilir. Harici/tracking URL'lerinde istek HİÇ atılmaz, baş harf gösterilir.
 * Bu sayede bir kullanıcının avatarına izleme pikseli koyup diğer kullanıcıların
 * IP/User-Agent bilgisini toplaması engellenir.
 */
export default function Avatar({ src, name, size = 'md', className = '', status }: AvatarProps) {
  const [imgError, setImgError] = useState(false);
  const safeSrc = safeAvatarUrl(src);
  const showImage = Boolean(safeSrc) && !imgError;

  return (
    <div className={`relative inline-flex items-center justify-center rounded-full overflow-hidden bg-primary-100 text-primary-700 font-semibold flex-shrink-0 ${sizeCls[size]} ${className}`}>
      {showImage ? (
        <img
          src={safeSrc}
          alt={name}
          loading="lazy"
          referrerPolicy="no-referrer"
          onError={() => setImgError(true)}
          className="w-full h-full object-cover"
        />
      ) : (
        <span>{getInitials(name)}</span>
      )}
      {status && (
        <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-background-100 ${statusColors[status]}`} />
      )}
    </div>
  );
}