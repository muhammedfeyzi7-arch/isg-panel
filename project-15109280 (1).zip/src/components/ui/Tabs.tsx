import { useState } from 'react';
import { useRovingFocus } from '@/hooks/useKeyboardNav';

interface TabsProps {
  tabs: { label: string; content: React.ReactNode; badge?: React.ReactNode }[];
  defaultTab?: number;
  onChange?: (index: number) => void;
  className?: string;
  size?: 'sm' | 'md';
  variant?: 'default' | 'pills';
}

/**
 * İçerik-gömülü / self-managed sekmeler. Sekme çubuğu ihtiyaçlarında `TabBar`
 * (controlled) kullanılır; bu bileşen yalnızca kendi state'ini yöneten gömülü
 * sekmeler içindir. Klavye: Arrow Left/Right + Home/End (roving tabindex),
 * Enter/Space native click ile aktifleştirir.
 */
export default function Tabs({ tabs, defaultTab = 0, onChange, className = '', size = 'md', variant = 'default' }: TabsProps) {
  const [active, setActive] = useState(defaultTab);

  const handleClick = (idx: number) => {
    setActive(idx);
    onChange?.(idx);
  };

  const { itemRef, onKeyDown } = useRovingFocus({
    itemCount: tabs.length,
    orientation: 'horizontal',
    onSelect: handleClick,
  });

  const sizeCls = size === 'sm' ? 'isg-tab-sm' : 'isg-tab';

  return (
    <div className={className}>
      <div role="tablist" className={`flex items-center gap-1 overflow-x-auto no-scrollbar ${variant === 'pills' ? 'isg-segmented p-1 rounded-lg' : 'border-b isg-divider'}`}>
        {tabs.map((tab, idx) => (
          <button
            key={idx}
            ref={itemRef(idx)}
            role="tab"
            aria-selected={active === idx}
            tabIndex={active === idx ? 0 : -1}
            onClick={() => handleClick(idx)}
            onKeyDown={(e) => onKeyDown(e, idx)}
            className={`relative font-medium transition-colors whitespace-nowrap ${sizeCls} rounded-md ${
              variant === 'pills'
                ? active === idx
                  ? 'isg-segment-active text-foreground-950'
                  : 'text-foreground-500 hover:text-foreground-700'
                : active === idx
                ? 'text-primary-700'
                : 'text-foreground-500 hover:text-foreground-700'
            }`}
          >
            <span className="flex items-center gap-2">
              {tab.label}
              {tab.badge}
            </span>
            {variant === 'default' && active === idx && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500 rounded-t-full" />
            )}
          </button>
        ))}
      </div>
      <div className="mt-4">
        {tabs[active]?.content}
      </div>
    </div>
  );
}