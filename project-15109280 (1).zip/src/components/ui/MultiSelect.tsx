import { useId, useRef, useState } from 'react';
import Checkbox from './Checkbox';
import DropdownPanel from './DropdownPanel';

export interface MultiSelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

interface MultiSelectProps {
  label?: string;
  error?: string;
  helpText?: string;
  options: MultiSelectOption[];
  value: string[];
  onChange: (values: string[]) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  searchable?: boolean;
  containerClassName?: string;
  className?: string;
  /** Ölçü varyantı — merkezi --d-input-* tokenlarından gelir (sm/md/lg). */
  size?: 'sm' | 'md' | 'lg';
}

/**
 * Ortak Multi-Select componenti. Form ve FilterBar sistemlerinde birlikte kullanılır.
 * Viewport'a göre aşağı/yukarı açılır, dışarı tıklama/ESC ile kapanır.
 */
export default function MultiSelect({
  label,
  error,
  helpText,
  options,
  value,
  onChange,
  placeholder = 'Seçiniz',
  required,
  disabled,
  searchable,
  containerClassName = '',
  className = '',
  size = 'md',
}: MultiSelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const anchorRef = useRef<HTMLButtonElement>(null);
  const generatedId = useId();
  const hasError = !!error;
  const errorId = hasError ? `${generatedId}-error` : undefined;
  const helpId = helpText ? `${generatedId}-help` : undefined;
  const describedBy = [errorId, helpId].filter(Boolean).join(' ') || undefined;

  const stateCls = hasError ? 'isg-input-error' : '';
  // Ölçü merkezi input token'ından gelir — Select/Search ile bire bir aynı yükseklik.
  const sizeCls = size === 'sm' ? 'isg-input-sm' : size === 'lg' ? 'isg-input-lg' : '';

  const selected = options.filter((o) => value.includes(o.value));

  const filteredOptions = searchable && query
    ? options.filter((o) => o.label.toLowerCase().includes(query.toLowerCase()))
    : options;

  const toggleOption = (val: string) => {
    if (value.includes(val)) {
      onChange(value.filter((v) => v !== val));
    } else {
      onChange([...value, val]);
    }
  };

  const selectAll = () => {
    onChange(options.filter((o) => !o.disabled).map((o) => o.value));
  };

  const clearAll = () => onChange([]);

  return (
    <div className={`w-full relative ${containerClassName}`}>
      {label && (
        <label htmlFor={generatedId} className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}

      <button
        ref={anchorRef}
        id={generatedId}
        type="button"
        onClick={() => !disabled && setOpen((o) => !o)}
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-invalid={hasError || undefined}
        aria-describedby={describedBy}
        className={`isg-input ${sizeCls} w-full flex items-center justify-between text-left cursor-pointer ${stateCls} ${
          disabled ? 'opacity-50 cursor-not-allowed' : ''
        } ${className}`}
      >
        <span className={`flex-1 truncate ${value.length === 0 ? 'text-foreground-400' : 'text-foreground-800'}`}>
          {value.length === 0 ? placeholder : `${value.length} seçili`}
        </span>
        {open ? (
          <i className="ri-arrow-up-s-line text-foreground-400" />
        ) : (
          <i className="ri-arrow-down-s-line text-foreground-400" />
        )}
      </button>

      {selected.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {selected.map((opt) => (
            <span
              key={opt.value}
              className="inline-flex items-center gap-1 px-2 py-0.5 bg-secondary-100 text-secondary-800 text-xs rounded-full"
            >
              {opt.label}
              <button
                type="button"
                onClick={() => onChange(value.filter((v) => v !== opt.value))}
                className="hover:text-secondary-600"
              >
                <i className="ri-close-line" />
              </button>
            </span>
          ))}
        </div>
      )}

      {open && (
        <DropdownPanel
          open={open}
          anchorRef={anchorRef}
          onClose={() => setOpen(false)}
          className="isg-popover"
        >
          {searchable && (
            <div className="p-2 border-b isg-divider">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ara..."
                autoFocus
                className="isg-input isg-input-sm w-full"
              />
            </div>
          )}
          <div className="px-2 py-1 border-b isg-divider flex items-center justify-between">
            <button
              type="button"
              onClick={selectAll}
              className="text-xs text-primary-500 hover:text-primary-600 px-1 py-1 font-medium whitespace-nowrap"
            >
              Tümünü Seç
            </button>
            <button
              type="button"
              onClick={clearAll}
              className="text-xs text-foreground-500 hover:text-foreground-700 px-1 py-1 font-medium whitespace-nowrap"
            >
              Temizle
            </button>
          </div>
          <div className="overflow-y-auto flex-1 min-h-0">
            {filteredOptions.length === 0 ? (
              <div className="p-4 text-sm text-foreground-400 text-center">Sonuç bulunamadı</div>
            ) : (
              filteredOptions.map((opt) => (
                <div
                  key={opt.value}
                  className={`px-3 py-1.5 ${opt.disabled ? 'opacity-50' : ''}`}
                >
                  <Checkbox
                    checked={value.includes(opt.value)}
                    onChange={() => toggleOption(opt.value)}
                    disabled={opt.disabled}
                    label={opt.label}
                  />
                </div>
              ))
            )}
          </div>
        </DropdownPanel>
      )}

      {hasError && (
        <p id={errorId} className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p id={helpId} className="isg-form-help">{helpText}</p>
      )}
    </div>
  );
}