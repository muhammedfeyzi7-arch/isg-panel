import {
  forwardRef,
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type ChangeEvent,
  type InputHTMLAttributes,
} from 'react';
import PickerPortal from './PickerPortal';

interface DatePickerProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helpText?: string;
  containerClassName?: string;
}

// ---------- İSGDenetim GLOBAL TARİH SEÇİCİ (TEK KAYNAK) ----------
// Native <input type="date"> yerine tüm sistem için tek merkezi takvim paneli.
// API aynıdır: `value` = 'YYYY-MM-DD', `onChange` bir input change event'i alır
// (event.target.value). Böylece tüm modüller (Tutanaklar, Ziyaretler, Risk,
// Ekipman, Personel, Ayarlar, Raporlar...) aynı bileşeni kullanır; sayfa/modül
// bazlı ayrı tarih picker kalmaz. Panel viewport dışına taşmaz, modal içinde
// katmanı bozmaz, ESC önce picker'ı kapatır, klavye ile tam kullanılabilir.

const WEEKDAYS = ['Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct', 'Pa'];
const MONTHS = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
];

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

function toISO(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function parseISO(v?: string): Date | null {
  if (!v) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return Number.isNaN(d.getTime()) ? null : d;
}

function formatDisplay(v?: string): string {
  const d = parseISO(v);
  if (!d) return '';
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()}`;
}

function startOfDay(d: Date): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}

const DatePicker = forwardRef<HTMLInputElement, DatePickerProps>(function DatePicker(
  {
    label,
    error,
    helpText,
    containerClassName = '',
    className = '',
    required,
    id,
    value,
    onChange,
    disabled,
    placeholder,
    name,
    min,
    max,
  },
  ref,
) {
  const generatedId = useId();
  const fieldId = id ?? generatedId;
  const hasError = !!error;
  const errorId = hasError ? `${fieldId}-error` : undefined;
  const helpId = helpText ? `${fieldId}-help` : undefined;

  const triggerRef = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);

  const valueStr = typeof value === 'string' ? value : '';
  const selected = useMemo(() => parseISO(valueStr), [valueStr]);

  const minDate = typeof min === 'string' ? parseISO(min) : null;
  const maxDate = typeof max === 'string' ? parseISO(max) : null;

  const [viewMonth, setViewMonth] = useState<Date>(() => selected ?? new Date());
  const [focusDate, setFocusDate] = useState<Date>(() => selected ?? new Date());
  // Panel görünümü: gün ızgarası / ay seçimi / yıl seçimi. Böylece başlıktaki
  // ay ve yıl TIKLANIP seçilebilir; kullanıcı "hangi yıldayım" sorusunu net
  // yanıtlar ve tek tek ok basmadan yıl/ay atlar.
  const [panelView, setPanelView] = useState<'days' | 'months' | 'years'>('days');
  const [yearStart, setYearStart] = useState<number>(() => Math.floor((selected ?? new Date()).getFullYear() / 12) * 12);

  const emit = useCallback(
    (v: string) => {
      onChange?.({ target: { value: v, name } } as unknown as ChangeEvent<HTMLInputElement>);
    },
    [onChange, name],
  );

  const openPicker = useCallback(() => {
    if (disabled) return;
    const base = selected ?? new Date();
    setViewMonth(base);
    setFocusDate(base);
    setYearStart(Math.floor(base.getFullYear() / 12) * 12);
    setPanelView('days');
    setOpen(true);
  }, [disabled, selected]);

  useEffect(() => {
    if (!open) return;
    const el = triggerRef.current;
    return () => {
      if (el && document.activeElement === document.body) el.focus();
    };
  }, [open]);

  const isDisabledDay = useCallback(
    (d: Date): boolean => {
      const day = startOfDay(d).getTime();
      if (minDate && day < startOfDay(minDate).getTime()) return true;
      if (maxDate && day > startOfDay(maxDate).getTime()) return true;
      return false;
    },
    [minDate, maxDate],
  );

  const cells = useMemo(() => {
    const y = viewMonth.getFullYear();
    const m = viewMonth.getMonth();
    const firstWeekday = (new Date(y, m, 1).getDay() + 6) % 7; // Pazartesi = 0
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const prevMonthDays = new Date(y, m, 0).getDate();
    const arr: { date: Date; inMonth: boolean; iso: string }[] = [];
    for (let i = firstWeekday - 1; i >= 0; i -= 1) {
      const date = new Date(y, m - 1, prevMonthDays - i);
      arr.push({ date, inMonth: false, iso: toISO(date) });
    }
    for (let d = 1; d <= daysInMonth; d += 1) {
      const date = new Date(y, m, d);
      arr.push({ date, inMonth: true, iso: toISO(date) });
    }
    let next = 1;
    while (arr.length < 42) {
      const date = new Date(y, m + 1, next);
      arr.push({ date, inMonth: false, iso: toISO(date) });
      next += 1;
    }
    return arr.slice(0, 42);
  }, [viewMonth]);

  const today = new Date();

  const selectDay = (d: Date) => {
    if (isDisabledDay(d)) return;
    emit(toISO(d));
    setOpen(false);
  };

  const moveFocus = (deltaDays: number) => {
    setFocusDate((prev) => {
      const next = new Date(prev);
      next.setDate(next.getDate() + deltaDays);
      setViewMonth(new Date(next.getFullYear(), next.getMonth(), 1));
      return next;
    });
  };

  const shiftMonth = (delta: number) => {
    setViewMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
  };

  // Aktif panele göre gezinme: günlerde ay, aylarda yıl, yıllarda 12'lik dönem.
  const shiftView = (delta: number) => {
    if (panelView === 'months') {
      setViewMonth((prev) => new Date(prev.getFullYear() + delta, prev.getMonth(), 1));
    } else if (panelView === 'years') {
      setYearStart((s) => s + delta * 12);
    } else {
      setViewMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
    }
  };

  const selectMonth = (m: number) => {
    setViewMonth((prev) => new Date(prev.getFullYear(), m, 1));
    setPanelView('days');
  };

  const selectYear = (y: number) => {
    setViewMonth((prev) => new Date(y, prev.getMonth(), 1));
    setYearStart(Math.floor(y / 12) * 12);
    setPanelView('months');
  };

  const handlePanelKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowLeft') {
      e.preventDefault();
      moveFocus(-1);
    } else if (e.key === 'ArrowRight') {
      e.preventDefault();
      moveFocus(1);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      moveFocus(-7);
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      moveFocus(7);
    } else if (e.key === 'PageUp') {
      e.preventDefault();
      shiftMonth(-1);
    } else if (e.key === 'PageDown') {
      e.preventDefault();
      shiftMonth(1);
    } else if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      selectDay(focusDate);
    }
  };

  const describedBy = [errorId, helpId].filter(Boolean).join(' ') || undefined;

  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label htmlFor={fieldId} className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}

      <button
        type="button"
        ref={triggerRef}
        id={fieldId}
        disabled={disabled}
        onClick={() => (open ? setOpen(false) : openPicker())}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
            if (!open) {
              e.preventDefault();
              openPicker();
            }
          }
        }}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-invalid={hasError || undefined}
        aria-describedby={describedBy}
        className={`isg-input w-full flex items-center justify-between gap-2 text-left cursor-pointer ${hasError ? 'isg-input-error' : ''} ${className}`}
      >
        <span className={`truncate ${valueStr ? 'text-foreground-950' : 'text-foreground-400'}`}>
          {valueStr ? formatDisplay(valueStr) : (placeholder || 'gg.aa.yyyy')}
        </span>
        <i className="ri-calendar-line text-foreground-500 flex-shrink-0" />
      </button>

      <input ref={ref} type="hidden" name={name} value={valueStr} readOnly />

      <PickerPortal anchorRef={triggerRef} open={open} onClose={() => setOpen(false)} onKeyDown={handlePanelKeyDown} minWidth={288}>
        <div className="p-3 w-80">
          <div className="flex items-center justify-between gap-1 mb-2">
            <button
              type="button"
              onClick={() => shiftView(-1)}
              aria-label={panelView === 'days' ? 'Önceki ay' : panelView === 'months' ? 'Önceki yıl' : 'Önceki yıllar'}
              className="w-7 h-7 flex items-center justify-center rounded-md border border-background-300/60 dark:border-background-400/40 text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer"
            >
              <i className="ri-arrow-left-s-line" />
            </button>
            <div className="flex items-center gap-1 min-w-0">
              <button
                type="button"
                onClick={() => setPanelView((v) => (v === 'months' ? 'days' : 'months'))}
                aria-label="Ay seç"
                className={`px-2 py-0.5 rounded-md text-sm font-semibold cursor-pointer transition-colors ${panelView === 'months' ? 'bg-primary-500 text-inverse' : 'text-foreground-900 hover:bg-background-200 dark:hover:bg-background-300/40'}`}
              >
                {MONTHS[viewMonth.getMonth()]}
              </button>
              <button
                type="button"
                onClick={() => setPanelView((v) => (v === 'years' ? 'days' : 'years'))}
                aria-label="Yıl seç"
                className={`px-2 py-0.5 rounded-md text-sm font-semibold cursor-pointer transition-colors ${panelView === 'years' ? 'bg-primary-500 text-inverse' : 'text-foreground-900 hover:bg-background-200 dark:hover:bg-background-300/40'}`}
              >
                {viewMonth.getFullYear()}
              </button>
            </div>
            <button
              type="button"
              onClick={() => shiftView(1)}
              aria-label={panelView === 'days' ? 'Sonraki ay' : panelView === 'months' ? 'Sonraki yıl' : 'Sonraki yıllar'}
              className="w-7 h-7 flex items-center justify-center rounded-md border border-background-300/60 dark:border-background-400/40 text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer"
            >
              <i className="ri-arrow-right-s-line" />
            </button>
          </div>

          {panelView === 'days' && (
            <>
              <div className="grid grid-cols-7 gap-0.5 mb-1">
                {WEEKDAYS.map((w) => (
                  <span key={w} className="h-7 flex items-center justify-center isg-text-micro font-medium text-foreground-500 select-none">
                    {w}
                  </span>
                ))}
              </div>

              <div className="grid grid-cols-7 gap-0.5">
                {cells.map((c) => {
                  const isSelected = selected ? toISO(selected) === c.iso : false;
                  const isToday = toISO(today) === c.iso;
                  const isFocus = toISO(focusDate) === c.iso;
                  const dayDisabled = isDisabledDay(c.date);
                  return (
                    <button
                      key={c.iso}
                      type="button"
                      disabled={dayDisabled}
                      onClick={() => selectDay(c.date)}
                      className={`h-8 rounded-md text-xs flex items-center justify-center transition-colors cursor-pointer ${
                        isSelected
                          ? 'bg-primary-500 text-inverse font-semibold'
                          : dayDisabled
                          ? 'text-foreground-300 dark:text-foreground-500/40 cursor-not-allowed'
                          : c.inMonth
                          ? 'text-foreground-800 hover:bg-primary-50 dark:hover:bg-primary-500/15'
                          : 'text-foreground-400 hover:bg-background-200 dark:hover:bg-background-300/40'
                      } ${isFocus && !isSelected ? 'ring-1 ring-primary-400' : ''} ${
                        isToday && !isSelected ? 'text-primary-600 font-medium' : ''
                      }`}
                    >
                      {c.date.getDate()}
                    </button>
                  );
                })}
              </div>
            </>
          )}

          {panelView === 'months' && (
            <div className="grid grid-cols-3 gap-1.5">
              {MONTHS.map((m, i) => {
                const active = i === viewMonth.getMonth();
                return (
                  <button
                    key={m}
                    type="button"
                    onClick={() => selectMonth(i)}
                    className={`h-9 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                      active
                        ? 'bg-primary-500 text-inverse font-semibold'
                        : 'text-foreground-800 hover:bg-primary-50 dark:hover:bg-primary-500/15'
                    }`}
                  >
                    {m.slice(0, 3)}
                  </button>
                );
              })}
            </div>
          )}

          {panelView === 'years' && (
            <div className="grid grid-cols-3 gap-1.5">
              {Array.from({ length: 12 }, (_, i) => yearStart + i).map((y) => {
                const active = y === viewMonth.getFullYear();
                return (
                  <button
                    key={y}
                    type="button"
                    onClick={() => selectYear(y)}
                    className={`h-9 rounded-md text-xs font-medium cursor-pointer transition-colors ${
                      active
                        ? 'bg-primary-500 text-inverse font-semibold'
                        : 'text-foreground-800 hover:bg-primary-50 dark:hover:bg-primary-500/15'
                    }`}
                  >
                    {y}
                  </button>
                );
              })}
            </div>
          )}

          <div className="flex items-center justify-between mt-2.5 pt-2.5 border-t border-background-300/40 dark:border-background-400/30">
            <button
              type="button"
              onClick={() => {
                emit('');
                setOpen(false);
              }}
              className="text-xs text-foreground-600 hover:text-foreground-900 px-1 py-1 cursor-pointer"
            >
              Temizle
            </button>
            <button
              type="button"
              onClick={() => {
                emit(toISO(today));
                setOpen(false);
              }}
              className="isg-btn isg-btn-primary isg-btn-sm"
            >
              Bugün
            </button>
          </div>
        </div>
      </PickerPortal>

      {hasError && (
        <p id={errorId} className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p id={helpId} className="isg-form-help">{helpText}</p>
      )}
    </div>
  );
});

export default DatePicker;