import type { ReactNode } from 'react';

interface ToolbarProps {
  /** Sol blok — filtre/arama grupları (genelde esnek). */
  children: ReactNode;
  /** Sağa yaslanan aksiyon grubu (ör. "Tümünü Uygun İşaretle", "Ekle"). */
  actions?: ReactNode;
  className?: string;
}

/**
 * GLOBAL TOOLBAR / LİSTE ÜST ÇUBUĞU — Shared UI tek kaynak.
 *
 * Referanstaki `[ Tüm Maddeler ] [ Ara... ] [ Tümünü Uygun İşaretle ]` gibi
 * filtre + arama + toplu aksiyon satırlarının ortak yüzeyi. Tüm modüller
 * (liste, denetim, evrak, envanter...) aynı toolbar yükseklik/boşluk/kenarlık
 * dilini paylaşır; her sayfa kendi kutusunu TEKRAR yazmaz. Mobilde sarar,
 * yatay taşma üretmez.
 */
export default function Toolbar({ children, actions, className = '' }: ToolbarProps) {
  return (
    <div className={`isg-toolbar-bar ${className}`}>
      <div className="flex flex-wrap items-center gap-2 flex-1 min-w-0">{children}</div>
      {actions && <div className="flex flex-wrap items-center gap-2 flex-shrink-0">{actions}</div>}
    </div>
  );
}