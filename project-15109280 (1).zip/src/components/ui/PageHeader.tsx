interface PageHeaderProps {
  title: string;
  subtitle?: string;
  breadcrumbs?: { label: string; href?: string }[];
  actions?: React.ReactNode;
  className?: string;
}

export default function PageHeader({ title, subtitle, breadcrumbs, actions, className = '' }: PageHeaderProps) {
  return (
    <div className={`isg-page-header pb-2 mb-2 ${className}`}>
      {breadcrumbs && breadcrumbs.length > 0 && (
        <nav aria-label="Sayfa yolu" className="flex items-center gap-1 isg-text-caption text-foreground-500 mb-1">
          {breadcrumbs.map((crumb, idx) => (
            <span key={idx} className="flex items-center gap-1">
              {idx > 0 && <i className="ri-arrow-right-s-line text-foreground-300" />}
              {crumb.href ? (
                <a href={crumb.href} className="hover:text-foreground-600 transition-colors">{crumb.label}</a>
              ) : (
                <span className={idx === breadcrumbs.length - 1 ? 'text-foreground-600' : ''}>{crumb.label}</span>
              )}
            </span>
          ))}
        </nav>
      )}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
        <div className="min-w-0">
          <h1 className="isg-text-page-title text-foreground-950 truncate">{title}</h1>
          {subtitle && <p className="isg-text-small text-foreground-500 truncate">{subtitle}</p>}
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2 sm:flex-shrink-0">{actions}</div>}
      </div>
    </div>
  );
}