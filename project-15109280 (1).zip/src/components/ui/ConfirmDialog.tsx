import { useEffect, useRef } from 'react';
import { useConfirmActions, useConfirmState } from '@/hooks/useConfirm';
import { Z_LAYERS } from '@/utils/layers';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import Button from './Button';

const variantStyles = {
  danger: 'text-danger-600',
  warning: 'text-warning-600',
  info: 'text-primary-600',
};

const variantIcon = {
  danger: 'ri-error-warning-line',
  warning: 'ri-alert-line',
  info: 'ri-information-line',
};

const variantButton = {
  danger: 'danger' as const,
  warning: 'secondary' as const,
  info: 'primary' as const,
};

/**
 * Global Shared Confirm Dialog — silme/onay/arşiv/kapat gibi kritik onaylar için
 * TEK kaynak. `useConfirm` + `ConfirmDialog` kullanır, sayfaya özel onay modalı
 * YAZILMAZ. Tarayıcı `confirm()` kullanılmaz.
 *
 * Davranış standartları:
 * - ESC → güvenle iptal (alttaki modal motorunun ESC handler'ı ile çakışmaz).
 * - Focus trap → Tab yalnızca İptal/Onay arasında döner, arkaya sızmaz.
 * - Autofocus → "İptal" butonuna gider (Enter yanlışlıkla tehlikeli aksiyonu tetiklemez).
 * - Outside click → iptal (güvenli, non-destructive).
 * - Animasyonsuz — overlay/box TAK açılır, TAK kapanır.
 */
export default function ConfirmDialog() {
  const state = useConfirmState();
  const { close } = useConfirmActions();
  const { isOpen, options } = state;

  const dialogRef = useRef<HTMLDivElement>(null);
  const cancelBtnRef = useRef<HTMLButtonElement>(null);
  const confirmBtnRef = useRef<HTMLButtonElement>(null);
  const isMobile = useMediaQuery('(max-width: 1023px)');

  // ESC + focus trap + güvenli autofocus.
  // CAPTURE fazında dinlenir; stopImmediatePropagation ile alttaki windowed modal
  // motorunun ESC/Tab handler'ı da tetiklenmez — confirm daima "en üst katman" kalır.
  useEffect(() => {
    if (!isOpen || !options) return;

    const focusTimer = setTimeout(() => cancelBtnRef.current?.focus(), 0);

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopImmediatePropagation();
        options.onCancel?.();
        close();
        return;
      }

      if (e.key === 'Tab') {
        const first = cancelBtnRef.current;
        const last = confirmBtnRef.current;
        if (!first || !last) return;
        e.preventDefault();
        e.stopImmediatePropagation();
        const active = document.activeElement as HTMLElement;
        const inside = dialogRef.current?.contains(active);
        if (e.shiftKey) {
          if (active === first || !inside) last.focus();
        } else if (active === last || !inside) {
          first.focus();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown, true);
    return () => {
      clearTimeout(focusTimer);
      window.removeEventListener('keydown', handleKeyDown, true);
    };
  }, [isOpen, options, close]);

  if (!isOpen || !options) return null;

  const variant = options.variant || 'info';

  const handleConfirm = () => {
    options.onConfirm();
    close();
  };

  const handleCancel = () => {
    options.onCancel?.();
    close();
  };

  const iconBlock = (
    <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${variant === 'danger' ? 'bg-danger-100 dark:bg-danger-500/15' : variant === 'warning' ? 'bg-warning-100 dark:bg-warning-500/15' : 'bg-primary-100 dark:bg-primary-500/15'}`}>
      <i className={`${variantIcon[variant]} ${variantStyles[variant]} text-lg`} />
    </div>
  );

  const textBlock = (
    <div className="flex-1 min-w-0">
      <h3 className="text-base font-semibold text-foreground-950">{options.title}</h3>
      <p className="mt-1 text-sm text-foreground-600">{options.message}</p>
    </div>
  );

  return (
    <div className="fixed inset-0 flex items-center justify-center" style={{ zIndex: Z_LAYERS.confirm }}>
      <div className="absolute inset-0 isg-modal-overlay" onClick={handleCancel} />
      <div
        ref={dialogRef}
        role="alertdialog"
        aria-modal="true"
        aria-label={options.title}
        className={`relative isg-modal-content ${isMobile ? 'isg-modal-mobile-full flex flex-col' : 'p-5 w-full max-w-md mx-4'}`}
      >
        {isMobile ? (
          <>
            <div className="flex-1 overflow-y-auto px-5 py-4" style={{ paddingTop: 'calc(1rem + env(safe-area-inset-top))' }}>
              <div className="flex items-start gap-3">
                {iconBlock}
                {textBlock}
              </div>
            </div>
            <div className="flex gap-2 p-4 pb-safe-footer border-t isg-divider flex-shrink-0">
              <Button ref={cancelBtnRef} variant="secondary" onClick={handleCancel} className="flex-1">
                {options.cancelText || 'Vazgeç'}
              </Button>
              <Button ref={confirmBtnRef} variant={variantButton[variant]} onClick={handleConfirm} className="flex-1">
                {options.confirmText || 'Onayla'}
              </Button>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-start gap-3">
              {iconBlock}
              {textBlock}
            </div>
            <div className="flex flex-col-reverse gap-2 mt-5 sm:flex-row sm:items-center sm:justify-end">
              <Button ref={cancelBtnRef} variant="secondary" onClick={handleCancel} className="w-full sm:w-auto">
                {options.cancelText || 'Vazgeç'}
              </Button>
              <Button ref={confirmBtnRef} variant={variantButton[variant]} onClick={handleConfirm} className="w-full sm:w-auto">
                {options.confirmText || 'Onayla'}
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}