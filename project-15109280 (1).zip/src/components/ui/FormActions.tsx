import type { ReactNode } from 'react';
import Button from './Button';

interface FormActionsProps {
  /** Submit butonu tipi: submit (form içinde) veya button (onClick ile). */
  submitType?: 'submit' | 'button';
  /** Submit callback'i (submitType="button" iken kullanılır). */
  onSubmit?: () => void;
  /** İptal callback'i — verilmezse iptal butonu gösterilmez. */
  onCancel?: () => void;
  /** Submit sırasında loading + çift submit kilidi (Button.isLoading). */
  isSubmitting?: boolean;
  /** Sol tarafa eklenen özel butonlar (örn. "Temizle", "Geri"). */
  extra?: ReactNode;
  submitLabel?: string;
  submittingLabel?: string;
  cancelLabel?: string;
  submitIcon?: string;
  submitVariant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success' | 'link';
  /** Buton hizalaması. */
  align?: 'left' | 'right' | 'between';
  /** Üst ayırıcı çizgi gösterilsin mi (form sonunda default true). */
  bordered?: boolean;
  className?: string;
}

/**
 * Global Form Actions — tüm form/modal/wizard'larda "İptal + Kaydet/Gönder"
 * buton satırı tek bileşendir. Sayfaya özel submit/cancel satırı YAZILMAZ.
 *
 * Loading → SharedButton üzerinden (metin korunur, genişlik kayması yok,
 * çift submit otomatik engellenir).
 */
export default function FormActions({
  submitType = 'submit',
  onSubmit,
  onCancel,
  isSubmitting = false,
  extra,
  submitLabel = 'Kaydet',
  submittingLabel,
  cancelLabel = 'İptal',
  submitIcon = 'ri-check-line',
  submitVariant = 'primary',
  align = 'right',
  bordered = true,
  className = '',
}: FormActionsProps) {
  const justifyCls = align === 'left' ? 'justify-start' : align === 'between' ? 'justify-between' : 'justify-end';

  return (
    <div
      className={`flex flex-wrap items-center gap-2 ${justifyCls} ${bordered ? 'pt-3 border-t isg-divider' : ''} ${className}`}
    >
      {extra && <div className="flex items-center gap-2">{extra}</div>}
      <div className="flex items-center gap-2">
        {onCancel && (
          <Button variant="ghost" type="button" onClick={onCancel} disabled={isSubmitting} className="whitespace-nowrap">
            {cancelLabel}
          </Button>
        )}
        <Button
          variant={submitVariant}
          type={submitType}
          onClick={submitType === 'button' ? onSubmit : undefined}
          isLoading={isSubmitting}
          leftIcon={!isSubmitting ? <i className={submitIcon} /> : undefined}
          className="whitespace-nowrap"
        >
          {isSubmitting ? submittingLabel || `${submitLabel}...` : submitLabel}
        </Button>
      </div>
    </div>
  );
}