import { forwardRef, useId, type TextareaHTMLAttributes } from 'react';

interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  helpText?: string;
  maxLength?: number;
  containerClassName?: string;
}

const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { label, error, helpText, maxLength = 500, containerClassName = '', className = '', onChange, value, required, id, ...props },
  ref
) {
  const hasError = !!error;
  const generatedId = useId();
  const fieldId = id ?? generatedId;
  const errorId = hasError ? `${fieldId}-error` : undefined;
  const helpId = helpText ? `${fieldId}-help` : undefined;
  const describedBy = [errorId, helpId].filter(Boolean).join(' ') || undefined;
  const currentLength = typeof value === 'string' ? value.length : 0;
  const stateCls = hasError ? 'isg-input-error' : '';

  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label htmlFor={fieldId} className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}
      <textarea
        ref={ref}
        id={fieldId}
        aria-invalid={hasError || undefined}
        aria-describedby={describedBy}
        maxLength={maxLength}
        className={`isg-input w-full min-h-[80px] resize-y ${stateCls} ${className}`}
        onChange={(e) => {
          if (e.target.value.length <= maxLength) {
            onChange?.(e);
          }
        }}
        value={value}
        required={required}
        {...props}
      />
      <div className="flex items-center justify-between mt-1">
        {hasError ? (
          <p id={errorId} className="isg-form-error mt-0">
            <i className="ri-error-warning-line" />
            {error}
          </p>
        ) : helpText ? (
          <p id={helpId} className="isg-form-help mt-0">{helpText}</p>
        ) : (
          <span />
        )}
        <p className={`text-xs ${currentLength > maxLength ? 'text-danger-600' : 'text-foreground-500'}`}>
          {currentLength}/{maxLength}
        </p>
      </div>
    </div>
  );
});

export default Textarea;