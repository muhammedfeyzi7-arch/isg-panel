import type { ReactNode } from 'react';

export interface CategoryItem {
  key: string;
  title: string;
  /** Remix ikon sınıfı (ör. "ri-building-2-line"). */
  icon?: string;
  /** Sağda gösterilecek madde sayısı. */
  count?: number;
  /** Sağda gösterilecek ek uyarı rozeti (ör. bulgu sayısı). */
  badge?: number;
}

interface CategoryListProps {
  items: CategoryItem[];
  value: string;
  onChange: (key: string) => void;
  title?: string;
  /** Arama kutusu. Verilirse gösterilir (kontrollü). */
  searchValue?: string;
  onSearch?: (value: string) => void;
  searchPlaceholder?: string;
  /** Listenin en altına yerleştirilecek içerik (ör. "Geri" butonu). */
  footer?: ReactNode;
  /** Boş durum metni. */
  emptyText?: string;
  className?: string;
  /** Sabit genişlik kullanımı için ek sınıf (ör. "w-full"). */
  bodyClassName?: string;
}

/**
 * GLOBAL KATEGORİ / NAVİGASYON LİSTESİ — Shared UI tek kaynak.
 *
 * Referanstaki sol kategori panelinin ortak karşılığıdır: başlık + (opsiyonel)
 * arama + ikon/başlık/sayaç satırları + seçili vurgu (primary) + alt aksiyon.
 * Filtre listeleri ve kompakt seçim listeleri de bu bileşeni kullanır; görsel
 * dil tamamen `.isg-cat-item` token'larından gelir. Light/Dark aynı geometri.
 */
export default function CategoryList({
  items,
  value,
  onChange,
  title,
  searchValue,
  onSearch,
  searchPlaceholder = 'Listede ara...',
  footer,
  emptyText = 'Kayıt yok.',
  className = '',
  bodyClassName = '',
}: CategoryListProps) {
  return (
    <div className={`isg-section isg-card-pad flex flex-col min-w-0 ${className}`}>
      {title && (
        <div className="flex items-center justify-between gap-2 mb-2">
          <span className="isg-text-card-title text-foreground-900 truncate">{title}</span>
          <span className="isg-text-micro text-foreground-400 whitespace-nowrap">{items.length}</span>
        </div>
      )}

      {onSearch && (
        <div className="relative mb-2">
          <i className="ri-search-line absolute left-2.5 top-1/2 -translate-y-1/2 text-foreground-400 text-sm" />
          <input
            type="text"
            value={searchValue ?? ''}
            onChange={(e) => onSearch(e.target.value)}
            placeholder={searchPlaceholder}
            className="isg-input isg-input-sm w-full pl-8 text-xs"
            aria-label={searchPlaceholder}
          />
        </div>
      )}

      <div className={`flex flex-col gap-0.5 min-h-0 overflow-y-auto overflow-x-hidden isg-scroll-pane ${bodyClassName}`}>
        {items.map((it) => (
          <button
            key={it.key}
            type="button"
            data-active={it.key === value ? 'true' : 'false'}
            onClick={() => onChange(it.key)}
            className="isg-cat-item"
            title={it.title}
          >
            {it.icon && <i className={`${it.icon} text-base flex-shrink-0`} />}
            <span className="flex-1 min-w-0 truncate">{it.title}</span>
            {typeof it.badge === 'number' && it.badge > 0 && (
              <span className="inline-flex items-center justify-center min-w-[1.1rem] h-[1.1rem] px-1 rounded-full isg-text-nano font-bold bg-danger-500 text-inverse flex-shrink-0">
                {it.badge}
              </span>
            )}
            {typeof it.count === 'number' && (
              <span className="isg-text-micro text-foreground-400 flex-shrink-0">{it.count}</span>
            )}
          </button>
        ))}
        {items.length === 0 && (
          <p className="text-xs text-foreground-400 text-center py-4">{emptyText}</p>
        )}
      </div>

      {footer && <div className="pt-2 mt-2 border-t isg-divider">{footer}</div>}
    </div>
  );
}