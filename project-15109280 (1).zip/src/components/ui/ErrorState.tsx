import Button from './Button';
import { classifyError } from '@/lib/errorMessages';

interface ErrorStateProps {
  /** Anlamlı başlık. Verilmezse `error` sınıflandırılır; o da yoksa nötr başlık kullanılır. */
  title?: string;
  message: string;
  onRetry?: () => void;
  className?: string;
  /**
   * Ham hata nesnesi. Verildiğinde ve `title` boşsa, hata türüne göre anlamlı
   * bir başlık (Bağlantı Hatası / Yetki Hatası / Kayıt Hatası ...) otomatik üretilir.
   * Böylece her yerde jenerik "Bir hata oluştu" başlığı kullanılmaz.
   */
  error?: unknown;
  /** Birincil kurtarma aksiyonu (ör. "Google ile yeniden bağlan"). */
  action?: { label: string; onClick: () => void; icon?: string; loading?: boolean };
}

/**
 * ORTAK Hata Durumu bileşeni (TEK KAYNAK).
 *
 * Başlık çözümlemesi merkezi hata motoruna (`@/lib/errorMessages`) bağlıdır:
 *  • `title` verilirse o kullanılır (sayfa bağlamı korunur).
 *  • `error` verilirse hata türüne göre anlamlı başlık üretilir.
 *  • Hiçbiri yoksa nötr, anlamlı bir başlık kullanılır (jenerik değil).
 */
export default function ErrorState({
  title,
  message,
  onRetry,
  action,
  className = '',
  error,
}: ErrorStateProps) {
  const resolvedTitle = title ?? (error ? classifyError(error).title : 'İşlem Tamamlanamadı');

  return (
    <div className={`flex flex-col items-center justify-center isg-empty px-4 text-center ${className}`}>
      <div aria-hidden="true" className="w-14 h-14 rounded-full bg-danger-50 flex items-center justify-center mb-4">
        <i className="ri-error-warning-line text-2xl text-danger-600" />
      </div>
      <h3 className="isg-text-section text-foreground-800">{resolvedTitle}</h3>
      <p className="mt-1 isg-text-body text-foreground-500 max-w-xs">{message}</p>
      {(action || onRetry) && (
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          {action && (
            <Button
              variant="primary"
              size="sm"
              onClick={action.onClick}
              isLoading={action.loading}
              leftIcon={<i className={action.icon || 'ri-link'} />}
            >
              {action.label}
            </Button>
          )}
          {onRetry && (
            <Button variant="secondary" size="sm" onClick={onRetry} leftIcon={<i className="ri-refresh-line" />}>
              Tekrar Dene
            </Button>
          )}
        </div>
      )}
    </div>
  );
}