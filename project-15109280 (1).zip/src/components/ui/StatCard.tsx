import type { KeyboardEvent } from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  trend?: { value: number; label: string; isPositive?: boolean };
  icon: string;
  iconColor?: string;
  iconBg?: string;
  className?: string;
  onClick?: () => void;
  /** Kart boyutu. 'sm' = tüm panellerdeki kompakt KPI şeridi (varsayılan).
   *  'lg' = referans başlıklarında kullanılan, ikon kutusu ve sayı büyük kart. */
  size?: 'sm' | 'lg';
}

/**
 * Global KPI / İstatistik Kartı (Shared UI tek kaynak).
 *
 * Referans standardı: ikon kutusu SOLDA, sağında başlık + büyük değer (+ küçük
 * alt bilgi). KPI şeritleri `isg-stat-grid` içinde TEK SATIRDA küçük kartlar
 * olarak dizilir; kart sayısı kaç olursa olsun (2/3/4/5/6) kartlar yan yana
 * küçük durur ve ASLA taşmaz (metinler truncate). Tüm paneller (Admin / OSGB /
 * Firma / Uzman / Hekim) aynı KPI geometrisini paylaşır; sayfa bazlı KPI kartı
 * ÜRETİLMEZ — bu merkezi bileşen kullanılır.
 */
export default function StatCard({
  title,
  value,
  subtitle,
  trend,
  icon,
  iconColor = 'text-primary-600',
  iconBg = 'bg-primary-50',
  className = '',
  onClick,
  size = 'sm',
}: StatCardProps) {
  const isLg = size === 'lg';
  return (
    <div
      className={`isg-card h-full flex items-center min-w-0 ${
        isLg ? 'gap-3 px-4 py-3.5' : 'gap-1.5 sm:gap-2.5 px-2 py-1.5 sm:px-3 sm:py-2.5'
      } ${onClick ? 'cursor-pointer active:bg-background-200/50 transition-colors' : ''} ${className}`}
      onClick={onClick}
      {...(onClick
        ? {
            role: 'button',
            tabIndex: 0,
            onKeyDown: (e: KeyboardEvent) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick();
              }
            },
          }
        : {})}
    >
      <div
        aria-hidden="true"
        className={`flex items-center justify-center flex-shrink-0 ${
          isLg ? 'w-11 h-11 rounded-lg' : 'w-5 h-5 sm:w-8 sm:h-8 rounded-md'
        } ${iconBg}`}
      >
        <i className={`${icon} ${isLg ? 'text-lg' : 'text-[11px] sm:text-sm'} ${iconColor}`} />
      </div>
      <div className="flex-1 min-w-0">
        <p
          className={`font-semibold text-foreground-500 uppercase tracking-wide leading-tight truncate ${
            isLg ? 'text-[11px]' : 'text-[9px] sm:text-[11px]'
          }`}
          title={title}
        >
          {title}
        </p>
        <p
          className={`font-bold text-foreground-950 leading-tight truncate ${
            isLg ? 'text-2xl mt-0.5' : 'text-sm sm:text-lg'
          }`}
        >
          {value}
        </p>
        {subtitle && (
          <p
            className={`text-foreground-400 leading-tight truncate ${isLg ? 'text-xs mt-0.5' : 'text-[9px] sm:text-[10px]'}`}
            title={subtitle}
          >
            {subtitle}
          </p>
        )}
        {trend && (
          <div className="mt-0.5 flex items-center gap-1">
            <span
              className={`inline-flex items-center gap-0.5 isg-stat-sub font-semibold px-1 py-0.5 rounded-full ${
                trend.isPositive ? 'text-success-700 bg-success-50' : 'text-danger-700 bg-danger-50'
              }`}
            >
              <i className={`isg-stat-sub ${trend.isPositive ? 'ri-arrow-up-line' : 'ri-arrow-down-line'}`} />
              %{trend.value}
            </span>
            <span className="isg-stat-sub text-foreground-500 truncate hidden sm:inline">{trend.label}</span>
          </div>
        )}
      </div>
    </div>
  );
}