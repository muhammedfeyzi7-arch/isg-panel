import { forwardRef, useId, type InputHTMLAttributes } from 'react';
import DatePicker from './DatePicker';
import TimePicker from './TimePicker';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helpText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  isSuccess?: boolean;
  isLoading?: boolean;
  containerClassName?: string;
}

const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { label, error, helpText, leftIcon, rightIcon, isSuccess, isLoading, containerClassName = '', className = '', required, id, autoComplete = 'off', ...props },
  ref
) {
  const generatedId = useId();
  const fieldId = id ?? generatedId;

  // ── Tek kaynak kuralı: yerel (native) tarih/saat kontrolleri ASLA gösterilmez.
  // `type="date"` / `type="time"` verilirse, çağıran kod hiçbir şey değiştirmeden
  // aynı API ile Shared DatePicker/TimePicker'a delege edilir. Böylece tüm
  // modüller tek merkezi takvim/saat panelini kullanır (event.target.value aynı).
  if (props.type === 'date' || props.type === 'time') {
    const Picker = props.type === 'date' ? DatePicker : TimePicker;
    const { type: _pickerType, ...pickerProps } = props;
    void _pickerType;
    return (
      <Picker
        ref={ref}
        id={fieldId}
        label={label}
        error={error}
        helpText={helpText}
        required={required}
        containerClassName={containerClassName}
        className={className}
        {...(pickerProps as Record<string, unknown>)}
      />
    );
  }

  const hasError = !!error;
  const errorId = hasError ? `${fieldId}-error` : undefined;
  const helpId = helpText ? `${fieldId}-help` : undefined;
  const describedBy = [errorId, helpId].filter(Boolean).join(' ') || undefined;
  // Durum sınıfları Shared UI tek kaynağından gelir (index.css .isg-input-error /
  // .isg-input-success). Bileşen border/focus rengini ELLE ezmez; böylece tüm
  // form kontrolleri açık modda aynı kenarlık dilini kullanır.
  const stateCls = hasError ? 'isg-input-error' : isSuccess ? 'isg-input-success' : '';

  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label htmlFor={fieldId} className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}
      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3 text-foreground-400 pointer-events-none">
            {leftIcon}
          </div>
        )}
        <input
          ref={ref}
          id={fieldId}
          autoComplete={autoComplete}
          aria-invalid={hasError || undefined}
          aria-describedby={describedBy}
          className={`isg-input w-full ${leftIcon ? 'pl-10' : ''} ${rightIcon || isLoading ? 'pr-10' : ''} ${stateCls} ${className}`}
          required={required}
          {...props}
        />
        {isLoading && (
          <div className="absolute right-3 text-foreground-400">
            <span className="inline-block w-4 h-4 border-2 border-foreground-300 border-t-transparent rounded-full animate-spin" />
          </div>
        )}
        {rightIcon && !isLoading && (
          <div className="absolute right-3 text-foreground-400">
            {rightIcon}
          </div>
        )}
      </div>
      {hasError && (
        <p id={errorId} className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p id={helpId} className="isg-form-help">{helpText}</p>
      )}
      {!hasError && isSuccess && (
        <p className="isg-form-success">
          <i className="ri-checkbox-circle-line" />
          Başarılı
        </p>
      )}
    </div>
  );
});

export default Input;