import Button from './Button';
import IconButton from './IconButton';
import Select from './Select';

interface PaginationProps {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  totalItems: number;
  onPageChange: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  className?: string;
}

const pageSizeOptions = [10, 20, 50, 100];

export default function Pagination({ currentPage, totalPages, pageSize, totalItems, onPageChange, onPageSizeChange, className = '' }: PaginationProps) {
  const getPages = () => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (currentPage <= 4) {
        for (let i = 1; i <= 5; i++) pages.push(i);
        pages.push('...');
        pages.push(totalPages);
      } else if (currentPage >= totalPages - 3) {
        pages.push(1);
        pages.push('...');
        for (let i = totalPages - 4; i <= totalPages; i++) pages.push(i);
      } else {
        pages.push(1);
        pages.push('...');
        pages.push(currentPage - 1);
        pages.push(currentPage);
        pages.push(currentPage + 1);
        pages.push('...');
        pages.push(totalPages);
      }
    }
    return pages;
  };

  return (
    <div className={`flex flex-wrap items-center justify-between gap-2 ${className}`}>
      <div className="text-xs text-foreground-500">
        <span className="font-medium text-foreground-700">{(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, totalItems)}</span>
        {' / '}
        <span className="font-medium text-foreground-800">{totalItems}</span> kayıt
      </div>
      <div className="flex items-center gap-1">
        <IconButton
          icon={<i className="ri-skip-back-line" />}
          variant="ghost"
          size="sm"
          disabled={currentPage <= 1}
          onClick={() => onPageChange(1)}
          label="İlk sayfa"
          className="hidden sm:inline-flex"
        />
        <IconButton
          icon={<i className="ri-arrow-left-s-line" />}
          variant="ghost"
          size="sm"
          disabled={currentPage <= 1}
          onClick={() => onPageChange(currentPage - 1)}
          label="Önceki sayfa"
        />
        <div className="hidden sm:flex items-center gap-1">
        {getPages().map((page, idx) => (
          page === '...' ? (
            <span key={idx} className="w-8 h-8 flex items-center justify-center text-sm text-foreground-400">...</span>
          ) : (
            <button
              key={idx}
              onClick={() => onPageChange(page as number)}
              className={`w-8 h-8 flex items-center justify-center rounded-md text-sm font-medium transition-colors ${
                currentPage === page
                  ? 'bg-primary-500 text-inverse'
                  : 'text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40'
              }`}
            >
              {page}
            </button>
          )
        ))}
        </div>
        <IconButton
          icon={<i className="ri-arrow-right-s-line" />}
          variant="ghost"
          size="sm"
          disabled={currentPage >= totalPages}
          onClick={() => onPageChange(currentPage + 1)}
          label="Sonraki sayfa"
        />
        <IconButton
          icon={<i className="ri-skip-forward-line" />}
          variant="ghost"
          size="sm"
          disabled={currentPage >= totalPages}
          onClick={() => onPageChange(totalPages)}
          label="Son sayfa"
          className="hidden sm:inline-flex"
        />
      </div>
      {onPageSizeChange && (
        <div className="hidden md:flex items-center gap-2 text-sm text-foreground-500">
          <span>Sayfa başına:</span>
          <Select
            size="sm"
            value={String(pageSize)}
            options={pageSizeOptions.map((n) => ({ value: String(n), label: String(n) }))}
            onChange={(e) => onPageSizeChange(Number(e.target.value))}
            containerClassName="w-20"
          />
        </div>
      )}
    </div>
  );
}