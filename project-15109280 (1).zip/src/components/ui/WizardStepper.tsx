export interface WizardStepDef {
  title: string;
  /** Kısa etiket (alt yazı). Verilmezse `title` kullanılır. */
  shortTitle?: string;
  /** İkincil açıklama satırı (referans tasarım). Verilmezse gizlenir. */
  subtitle?: string;
}

interface WizardStepperProps {
  steps: WizardStepDef[];
  current: number;
  onStepClick?: (index: number) => void;
}

/**
 * ORTAK WIZARD STEPPER — Shared UI tek kaynak.
 *
 * Tüm çok adımlı modal/sihirbazlar (OSGB, Duyuru, Firma, Uzman, Hekim, Tutanak,
 * Saha Denetim, gelecekteki her wizard) BU bileşeni kullanır. Modal'ın yerleşik
 * adım göstergesi de ayrı bir "pill" sistemi DEĞİL; bu bileşendir. Böylece adım
 * geometrisi (numaralı daire + bağlantı çizgisi + alt etiket) tek merkezden gelir
 * ve DARK / LIGHT AYNI düzeni paylaşır — yalnızca renk tokenları değişir.
 *
 * Referans standardı: daire üstte, altında kalın kısa başlık + (varsa) küçük
 * ikincil açıklama. Aktif adım primary, tamamlanan adım check + primary,
 * gelecek adımlar soluk.
 *
 * Adım sayısı dinamiktir (3 / 4 / 5 / 7 ...). Sayfaya özel stepper YAZILAMAZ.
 * Geriye uyumludur: yalnızca `title`/`shortTitle` veren eski çağrılar birebir
 * çalışmaya devam eder.
 */
export default function WizardStepper({ steps, current, onStepClick }: WizardStepperProps) {
  return (
    <div className="flex items-start justify-between px-4 pt-3 pb-3 flex-shrink-0">
      {steps.map((s, idx) => {
        const isDone = idx < current;
        const isActive = idx === current;
        const previous = idx - 1;
        const clickable = isDone && !!onStepClick;
        return (
          <div key={idx} className="flex flex-col items-center" style={{ flex: '1 1 0' }}>
            <div className="flex items-center w-full">
              {/* Soldaki bağlantı çizgisi — bir önceki adıma ulaşan hat */}
              <div className={`flex-1 h-0.5 ${previous < 0 ? 'invisible' : previous < current ? 'bg-primary-500' : 'bg-background-300/60 dark:bg-background-400/40'}`} />
              {/* Numaralı daire */}
              <button
                type="button"
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 transition-colors ${
                  isActive || isDone
                    ? 'bg-primary-500 text-inverse'
                    : 'bg-background-200 dark:bg-background-300/40 text-foreground-500 border border-background-300/70 dark:border-background-400/40'
                } ${clickable ? 'cursor-pointer' : 'cursor-default'}`}
                onClick={() => clickable && onStepClick?.(idx)}
                disabled={!clickable}
                aria-label={s.title}
                aria-current={isActive ? 'step' : undefined}
              >
                {isDone ? <i className="ri-check-line" /> : idx + 1}
              </button>
              {/* Sağdaki bağlantı çizgisi — sonraki adıma giden hat */}
              <div className={`flex-1 h-0.5 ${idx === steps.length - 1 ? 'invisible' : isDone ? 'bg-primary-500' : 'bg-background-300/60 dark:bg-background-400/40'}`} />
            </div>
            {/* Adım etiketi — aktif adım primary + alt çizgi ile belirgin */}
            <span className={`mt-1.5 isg-text-micro font-semibold text-center leading-tight px-0.5 ${
              isActive
                ? 'text-primary-600 dark:text-primary-400'
                : isDone
                ? 'text-primary-500'
                : 'text-foreground-500'
            }`}>
              {s.shortTitle ?? s.title}
            </span>
            {s.subtitle && (
              <span className={`isg-text-nano font-normal text-center leading-tight px-0.5 mt-0.5 ${
                isActive ? 'text-foreground-500' : 'text-foreground-400'
              }`}>
                {s.subtitle}
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}