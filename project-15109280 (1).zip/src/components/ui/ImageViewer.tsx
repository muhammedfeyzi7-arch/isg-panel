import { useMemo, useState } from 'react';
import PhotoLightbox from './PhotoLightbox';

/**
 * Ortak fotoğraf görüntüleyici — küçük önizleme (thumbnail) gösterir; tıklanınca
 * sistemin TEK merkezî fotoğraf lightbox'ı (PhotoLightbox) açılır.
 *
 * Artık KENDİ tam ekran modalını çizmez: full-screen görüntüleme, zoom, indirme
 * ve galeri gezinmesi (ok tuşları + sayaç) tamamen merkezî PhotoLightbox'tan
 * gelir. Böylece sistemde fotoğraf için TEK bir görüntüleme katmanı bulunur
 * (belge önizleme motoru yalnızca PDF/Word/Excel/PPT için kullanılır).
 *
 * Tek görsel (`src`) VEYA galeri (`gallery` + `index`) modunda çalışır.
 */

export interface ImageViewerItem {
  src: string;
  alt?: string;
  fileName?: string;
}

interface ImageViewerProps {
  src?: string | null;
  alt?: string;
  fileName?: string;
  /** Thumbnail <img> sınıfları (boyut / object-fit). */
  imgClassName?: string;
  /** Buton sarmalayıcı sınıfları. */
  wrapperClassName?: string;
  showDownload?: boolean;
  /** Galeri modu — birden fazla görsel arasında gezilebilir. */
  gallery?: ImageViewerItem[];
  /** Galeride başlangıç indeksi. */
  index?: number;
  /** Thumbnail üzerine hover'da "görüntüle" ikonu göster. */
  showHoverIcon?: boolean;
}

export default function ImageViewer({
  src,
  alt,
  fileName,
  imgClassName,
  wrapperClassName,
  showDownload = true,
  gallery,
  index = 0,
  showHoverIcon = false,
}: ImageViewerProps) {
  const items = useMemo<ImageViewerItem[]>(() => {
    const base = gallery && gallery.length > 0 ? gallery : src ? [{ src, alt, fileName }] : [];
    return base.filter((it) => !!it.src);
  }, [gallery, src, alt, fileName]);

  const safeIndex = Math.min(Math.max(index, 0), Math.max(items.length - 1, 0));
  const thumb = items[safeIndex];

  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(safeIndex);

  if (!thumb) {
    return (
      <div className={`flex items-center justify-center text-foreground-400 ${wrapperClassName || 'w-full h-24'}`}>
        <i className="ri-image-line text-xl" />
      </div>
    );
  }

  const hasGallery = items.length > 1;

  return (
    <>
      <button
        type="button"
        onClick={() => {
          setActiveIndex(safeIndex);
          setOpen(true);
        }}
        className={`group relative block cursor-zoom-in ${wrapperClassName || ''}`}
        aria-label={alt || thumb.alt || 'Fotoğrafı büyüt'}
      >
        <img
          src={thumb.src}
          alt={thumb.alt || alt || 'Fotoğraf'}
          className={imgClassName || 'w-full h-24 object-cover object-top'}
        />
        {showHoverIcon && (
          <span className="pointer-events-none absolute inset-0 flex items-center justify-center rounded-md bg-black/40 opacity-0 transition-opacity group-hover:opacity-100">
            <i className="ri-zoom-in-line text-white text-base" />
          </span>
        )}
        {showHoverIcon && hasGallery && (
          <span className="pointer-events-none absolute right-0.5 bottom-0.5 inline-flex items-center gap-0.5 rounded-full bg-black/60 px-1 py-0.5 text-[9px] font-medium text-white">
            <i className="ri-stack-line" />
            {items.length}
          </span>
        )}
      </button>

      {open && (
        <PhotoLightbox
          items={items.map((it) => ({ src: it.src, alt: it.alt, fileName: it.fileName }))}
          index={activeIndex}
          onIndexChange={setActiveIndex}
          onClose={() => setOpen(false)}
          title={items[activeIndex]?.fileName || items[activeIndex]?.alt || alt || 'Görsel'}
          allowDownload={showDownload}
        />
      )}
    </>
  );
}