import Select from './Select';
import { ilIlceleri } from '@/data/turkiye';

interface DistrictSelectProps {
  label?: string;
  provinceValue: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  error?: string;
  helpText?: string;
  containerClassName?: string;
  name?: string;
  id?: string;
}

/**
 * Ortak İlçe seçici. Seçili ile göre o ilin ilçelerini merkezi veri
 * kaynağından yükler, aranabilir (Türkçe karakter destekli) dropdown kullanır.
 * İl değiştiğinde çağıran taraf value'yu sıfırlar; bu component sadece
 * ilçe listesini provinceValue'ya göre sunar.
 */
export default function DistrictSelect({
  label = 'İlçe',
  provinceValue,
  value,
  onChange,
  placeholder = 'Seçiniz',
  required,
  disabled,
  error,
  helpText,
  containerClassName,
  name,
  id,
}: DistrictSelectProps) {
  const options = provinceValue ? ilIlceleri(provinceValue).map((i) => ({ value: i.value, label: i.label })) : [];

  return (
    <Select
      label={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      options={options}
      placeholder={provinceValue ? placeholder : 'Önce il seçin'}
      required={required}
      disabled={disabled || !provinceValue}
      error={error}
      helpText={helpText}
      searchable
      containerClassName={containerClassName}
      name={name}
      id={id}
    />
  );
}