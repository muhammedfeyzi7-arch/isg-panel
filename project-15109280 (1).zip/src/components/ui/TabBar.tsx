import { type ReactNode } from 'react';
import { useRovingFocus } from '@/hooks/useKeyboardNav';

export interface TabBarItem {
  key: string;
  label: string;
  icon?: string;
  /** Sekme başlığının yanında gösterilecek adım numarası (referans tasarımdaki 1,2,3…). */
  number?: number;
  /** Başlığın altında küçük açıklama (yalnızca adım numaralı sekmelerde kullanılır). */
  subtitle?: string;
  /** Özel badge içeriği */
  badge?: ReactNode;
  /** Sayı badge (kaç kayıt) — pill varyantında gösterilir */
  count?: number;
}

interface TabBarProps {
  items: TabBarItem[];
  active: string;
  onChange: (key: string) => void;
  className?: string;
  size?: 'sm' | 'md';
  /** underline (default) = alt çizgi çubuğu; pill = dolu buton sekmeler */
  variant?: 'underline' | 'pill';
}

/**
 * Ortak sekme çubuğu — İSGDenetim'deki TÜM sekme çubukları bu bileşeni kullanır.
 * Detay modalları, ayarlar sayfası ve tüm panel içi sekmeler aynı kaynaktır.
 *
 * Kurallar (kalıcı kilit):
 * - `flex-wrap` — sekmeler ASLA yatay kaydırmaz, taşanlar alt satıra iner.
 * - Yatay scroll (overflow-x-auto) YASAKTIR.
 * - Klavye: Arrow Left/Right + Home/End ile gezinir (roving tabindex), Enter/Space native click ile aktifleştirir.
 * - Erişilebilirlik: role="tablist" / role="tab" / aria-selected / tabIndex yönetimi.
 */
export default function TabBar({
  items,
  active,
  onChange,
  className = '',
  size = 'md',
  variant = 'underline',
}: TabBarProps) {
  const activeIndex = items.findIndex((it) => it.key === active);

  const { itemRef, onKeyDown } = useRovingFocus({
    itemCount: items.length,
    orientation: 'horizontal',
    onSelect: (index) => onChange(items[index]?.key ?? active),
  });

  if (variant === 'pill') {
    return (
      <div role="tablist" className={`flex flex-wrap items-center gap-1.5 ${className}`}>
        {items.map((item, idx) => {
          const isActive = active === item.key;
          return (
            <button
              key={item.key}
              type="button"
              ref={itemRef(idx)}
              role="tab"
              aria-selected={isActive}
              tabIndex={activeIndex === idx ? 0 : -1}
              onClick={() => onChange(item.key)}
              onKeyDown={(e) => onKeyDown(e, idx)}
              className={`flex items-center gap-1.5 isg-tab-pill font-medium transition-colors whitespace-nowrap cursor-pointer border ${
                isActive
                  ? 'bg-primary-500 border-primary-500 text-inverse'
                  : 'bg-background-100 border-background-200/80 text-foreground-600 hover:bg-background-200 dark:bg-background-200 dark:border-background-400/30 dark:text-foreground-500 dark:hover:bg-background-300/40'
              }`}
            >
              {item.icon && <i className={`${item.icon} text-sm`} />}
              <span>{item.label}</span>
              {item.count !== undefined && (
                <span
                  className={`isg-text-micro font-bold px-1.5 py-0.5 rounded-full leading-none ${
                    isActive
                      ? 'bg-white/20 text-inverse'
                      : 'bg-background-300/70 text-foreground-600 dark:bg-background-300/50 dark:text-foreground-400'
                  }`}
                >
                  {item.count}
                </span>
              )}
              {item.badge}
            </button>
          );
        })}
      </div>
    );
  }

  const sizeCls = size === 'sm' ? 'isg-tab-sm' : 'isg-tab';

  return (
    <div role="tablist" className={`flex flex-wrap items-center gap-1 border-b isg-divider ${className}`}>
      {items.map((item, idx) => (
        <button
          key={item.key}
          type="button"
          ref={itemRef(idx)}
          role="tab"
          aria-selected={active === item.key}
          tabIndex={activeIndex === idx ? 0 : -1}
          onClick={() => onChange(item.key)}
          onKeyDown={(e) => onKeyDown(e, idx)}
          className={`relative font-medium transition-colors whitespace-nowrap cursor-pointer ${sizeCls} ${
            active === item.key ? 'text-primary-500' : 'text-foreground-500 hover:text-foreground-700'
          }`}
        >
          <span className="flex items-center gap-1.5">
            {item.number !== undefined && (
              <span
                className={`w-5 h-5 rounded-full flex items-center justify-center isg-text-nano font-bold flex-shrink-0 ${
                  active === item.key
                    ? 'bg-primary-500 text-inverse'
                    : 'bg-background-200 text-foreground-500 dark:bg-background-300/50'
                }`}
              >
                {item.number}
              </span>
            )}
            <span className="flex flex-col items-start leading-tight">
              <span className="flex items-center gap-1.5">
                {item.icon && <i className={`${item.icon} text-sm`} />}
                {item.label}
                {item.count !== undefined && (
                  <span
                    className={`text-xs font-bold px-1.5 py-0.5 rounded-full ${
                      active === item.key
                        ? 'bg-primary-100 text-primary-600'
                        : 'bg-background-300/70 text-foreground-600'
                    }`}
                  >
                    {item.count}
                  </span>
                )}
                {item.badge}
              </span>
              {item.subtitle && (
                <span className="isg-text-nano font-normal text-foreground-500 mt-0.5">{item.subtitle}</span>
              )}
            </span>
          </span>
          {active === item.key && (
            <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500 rounded-t-full" />
          )}
        </button>
      ))}
    </div>
  );
}