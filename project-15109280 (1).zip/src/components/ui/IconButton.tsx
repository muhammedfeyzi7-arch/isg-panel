import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';

interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  icon: ReactNode;
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  label?: string;
}

/**
 * Global IconButton — kapat/düzenle/sil/filtre/3-nokta gibi tüm ikon butonlarında
 * tek standart. Kare ölçüler merkezi Shared UI token'ından gelir
 * (--d-iconbtn-sm/md/lg): sm=32px, md=40px, lg=44px. Danger rengi Button ile tutarlıdır.
 */
const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { icon, variant = 'ghost', size = 'md', isLoading, label, className = '', disabled, ...props },
  ref
) {
  // Ölçü merkezi token'dan (sayfaya özel w/h yazılmaz).
  const sizeCls = {
    sm: 'isg-iconbtn-sm',
    md: 'isg-iconbtn-md',
    lg: 'isg-iconbtn-lg',
  }[size];

  const variantCls = {
    primary: 'bg-primary-500 text-inverse hover:bg-primary-600',
    secondary: 'bg-background-200 text-foreground-700 hover:bg-background-300 border border-background-300/60',
    ghost: 'bg-transparent text-foreground-600 hover:bg-background-200',
    danger: 'bg-danger-500 text-inverse hover:bg-danger-600',
  }[variant];

  const isDisabled = disabled || isLoading;

  return (
    <button
      ref={ref}
      aria-label={label}
      className={`isg-iconbtn ${sizeCls} ${variantCls} ${isLoading ? 'opacity-70 cursor-wait' : ''} ${className}`}
      disabled={isDisabled}
      {...props}
    >
      {isLoading ? (
        <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" aria-hidden="true" />
      ) : (
        icon
      )}
    </button>
  );
});

export default IconButton;