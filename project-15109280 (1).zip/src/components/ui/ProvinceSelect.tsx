import Select from './Select';
import { ilSecenekleri } from '@/data/turkiye';

interface ProvinceSelectProps {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  error?: string;
  helpText?: string;
  containerClassName?: string;
  name?: string;
  id?: string;
}

/**
 * Ortak İl seçici. Türkiye'nin 81 ilini tek merkezi veri kaynağından
 * sunar, aranabilir (Türkçe karakter destekli) custom dropdown kullanır.
 * Tüm formlarda bu component kullanılır — başka yerde il listesi tanımlanmaz.
 */
export default function ProvinceSelect({
  label = 'İl',
  value,
  onChange,
  placeholder = 'Seçiniz',
  required,
  disabled,
  error,
  helpText,
  containerClassName,
  name,
  id,
}: ProvinceSelectProps) {
  return (
    <Select
      label={label}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      options={ilSecenekleri}
      placeholder={placeholder}
      required={required}
      disabled={disabled}
      error={error}
      helpText={helpText}
      searchable
      containerClassName={containerClassName}
      name={name}
      id={id}
    />
  );
}