import { useEffect } from 'react';
import { useModalState } from '@/hooks/useModal';
import { Z_LAYERS } from '@/utils/layers';
import { lockScroll, unlockScroll } from '@/lib/scrollLock';
import Modal from './Modal';

export default function ModalManager() {
  const state = useModalState();
  const { modals, minimized, activeModalId } = state;

  // Ekranda duran modallerin görsel stack sırası (küçültülmüş olanlar sayılmaz).
  const visibleStackIndex = new Map<string, number>();
  {
    let pos = 0;
    for (const m of modals) {
      if (!minimized.includes(m.id)) visibleStackIndex.set(m.id, pos++);
    }
  }

  // ── GLOBAL MODAL SCROLL LOCK (Shared UI tek kaynak) ──
  // Küçültülmemiş bir modal açıkken arka plan (body + ana içerik scroll alanı)
  // kilitlenir. Kilit tek merkezi utility (`lockScroll`) üzerinden yönetilir;
  // böylece belge önizleme / bottom sheet gibi diğer overlay'lerle çakışmadan
  // sahip sayaçlı paylaşılır. Modalın KENDİ gövde scroll'u etkilenmez.
  const hasOpenModal = modals.some((m) => !minimized.includes(m.id));
  useEffect(() => {
    if (!hasOpenModal) return undefined;
    lockScroll('modal-manager');
    return () => unlockScroll('modal-manager');
  }, [hasOpenModal]);

  return (
    <>
      {/* ── GLOBAL MODAL PERDESİ (Shared UI tek kaynak) ──
          Yalnızca EKRANDA duran (küçültülmemiş) bir modal varken gösterilir;
          böylece dock'a küçültülmüş pencere arka planı karartmaz. Perde, modalin
          sayfadan AYRI bir üst katman olduğunu hissettirir (light: orta,
          dark: daha güçlü — bkz. .isg-modal-overlay). Arka plan yine
          kullanılabilir kalır (pointer-events-none); tıklama engellenmez. */}
      {hasOpenModal && (
        <div
          className="isg-modal-overlay fixed inset-0 pointer-events-none"
          style={{ zIndex: Z_LAYERS.modalBackdrop }}
          aria-hidden="true"
        />
      )}

      {/* Tüm modallar mounted kalır. Minimize edilenler sağ alta dock edilir (dikey stack).
          Restore aynı konuma döner. Global overlay YOKTUR: modal açıkken arka plan kullanılabilir kalır. */}
      {modals.map((modal) => {
        const isActive = activeModalId === modal.id;
        const isMinimized = minimized.includes(modal.id);
        const minimizedIndex = isMinimized ? minimized.indexOf(modal.id) : 0;
        // ── STACK SIRASI (Shared UI tek kaynak) ──
        // Ekranda duran (küçültülmemiş) modaller arasında bu modalın kaçıncı
        // sırada olduğu. Modal bunu kullanarak üst üste birebir aynı koordinatta
        // açılmak yerine KONTROLLÜ bir offset ile yerleşir; en son açılan en üstte.
        const stackIndex = isMinimized ? 0 : visibleStackIndex.get(modal.id) ?? 0;
        return (
          <Modal
            key={modal.id}
            modal={modal}
            isActive={isActive}
            minimized={isMinimized}
            minimizedIndex={minimizedIndex}
            stackIndex={stackIndex}
          />
        );
      })}
    </>
  );
}