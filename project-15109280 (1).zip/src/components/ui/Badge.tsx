import type { ReactNode } from 'react';

type BadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'secondary' | 'accent';

interface BadgeProps {
  children: ReactNode;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  className?: string;
}

const variantStyles: Record<BadgeVariant, string> = {
  /* Light: pastel bg + deep semantic text for strong contrast.
     Dark: inverted semi-transparent bg + light text. */
  default:   'bg-background-300/70 text-foreground-700 dark:bg-background-300/60 dark:text-foreground-700',
  success:   'bg-success-50  text-success-700  dark:bg-success-50  dark:text-success-700',
  warning:   'bg-warning-50  text-warning-700  dark:bg-warning-50  dark:text-warning-700',
  danger:    'bg-danger-50   text-danger-700   dark:bg-danger-50   dark:text-danger-700',
  info:      'bg-primary-50  text-primary-700  dark:bg-primary-50  dark:text-primary-700',
  primary:   'bg-primary-500 text-inverse',
  secondary: 'bg-secondary-100 text-secondary-700 dark:bg-secondary-50 dark:text-secondary-700',
  accent:    'bg-accent-100  text-accent-700   dark:bg-accent-50   dark:text-accent-700',
};

export default function Badge({ children, variant = 'default', size = 'sm', leftIcon, rightIcon, className = '' }: BadgeProps) {
  // Ölçü artık merkezi Shared UI token'ından gelir (--d-badge-* tokenları).
  const sizeCls = size === 'sm' ? 'isg-badge-sm' : 'isg-badge-md';

  return (
    <span className={`isg-badge ${sizeCls} ${variantStyles[variant]} ${className}`}>
      {leftIcon}
      {children}
      {rightIcon}
    </span>
  );
}