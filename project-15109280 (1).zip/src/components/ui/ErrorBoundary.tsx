import { Component, type ErrorInfo, type ReactNode } from 'react';
import { logError } from '@/utils/errorLogger';
import Button from './Button';

interface ErrorBoundaryProps {
  children: ReactNode;
  /** İsteğe bağlı panel adı — loglama ve raporlama için etiket. */
  name?: string;
}

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
  /** Aynı boot içinde art arda tetiklenen hata sayısı (retry loop guard). */
  consecutiveErrors: number;
  /** Kullanıcı "Tekrar Dene" tıkladığında kısa süreli disabled (rapid-tap koruması). */
  retrying: boolean;
}

/**
 * SharedErrorBoundary — TEK global hata sınırı.
 * Bir component/ekran hatası bütün uygulamayı çökertmez; güvenli fallback gösterir.
 *
 * - Root cause'u gizlemez: development'ta gerçek stack korunur.
 * - Production'da kullanıcıya teknik/internal değişken adı gösterilmez.
 * - Retry loop guard: aynı hata art arda tekrarlanırsa sonsuz döngüye izin vermez.
 * - Panel seviyesinde izolasyon: `name` prop'u ile farklı paneller ayrı sınırlar kullanabilir.
 */
export default class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  // Aynı boot oturumunda izin verilen maksimum otomatik retry.
  static readonly MAX_CONSECUTIVE = 3;

  state: ErrorBoundaryState = { hasError: false, message: '', consecutiveErrors: 0, retrying: false };

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return { hasError: true, message: error?.message || 'Beklenmeyen bir hata oluştu.' };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Merkezi logger'a yönlendir (dedup + hassas veri filtreleme tek yerden).
    logError(error, { componentName: this.props.name, source: 'error-boundary' });
    // Development'ta component stack'i konsola yazılır (root cause analizi için).
    if (this.isDev()) {
      // eslint-disable-next-line no-console
      console.error('[ISGDenetim] Component stack:', info.componentStack);
    }
  }

  private isDev(): boolean {
    try {
      return (import.meta as unknown as { env?: { DEV?: boolean } }).env?.DEV === true;
    } catch {
      return false;
    }
  }

  handleRetry = () => {
    if (this.state.retrying) return; // rapid-tap koruması

    const nextCount = this.state.consecutiveErrors + 1;

    // Retry loop guard: aynı hata MAX_CONSECUTIVE kere tekrarlandıysa,
    // kullanıcıyı sonsuz load→error→retry döngüsüne sokmak yerine
    // kalıcı bir durum mesajına düşür (transient değil, gerçek bug).
    if (nextCount > ErrorBoundary.MAX_CONSECUTIVE) {
      this.setState({ retrying: true });
      // Güvenli full reload: transient runtime/network değil, gerçek bug.
      // Tek seferlik — loop oluşmaz çünkü sonrası kullanıcı kontrolünde.
      setTimeout(() => {
        window.location.reload();
      }, 150);
      return;
    }

    this.setState({ hasError: false, message: '', consecutiveErrors: nextCount, retrying: false });
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    const dev = this.isDev();
    const exhausted = this.state.consecutiveErrors >= ErrorBoundary.MAX_CONSECUTIVE;

    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] px-6 py-12 text-center">
        <div className="w-16 h-16 rounded-2xl bg-danger-50 flex items-center justify-center mb-4">
          <i className="ri-error-warning-line text-danger-600 text-3xl" />
        </div>
        <h1 className="text-lg font-semibold text-foreground-950 mb-1">
          {exhausted ? 'Uygulama yeniden başlatılıyor' : 'Beklenmeyen bir hata oluştu'}
        </h1>
        <p className="text-sm text-foreground-500 max-w-md mb-1">
          {exhausted
            ? 'Aynı sorun tekrarlandı. Güvenli bir yeniden başlatma yapılıyor.'
            : 'Bu ekran yüklenirken bir sorun oluştu. Lütfen tekrar deneyin.'}
        </p>

        {/* Development: gerçek stack trace korunur (root cause analizi). Production: gizli. */}
        {dev && this.state.message && (
          <p className="text-xs text-foreground-400 font-mono max-w-md break-words mb-4">
            {this.state.message}
          </p>
        )}

        <Button
          variant="primary"
          onClick={this.handleRetry}
          isLoading={this.state.retrying}
          leftIcon={<i className="ri-refresh-line" />}
        >
          Tekrar Dene
        </Button>
      </div>
    );
  }
}