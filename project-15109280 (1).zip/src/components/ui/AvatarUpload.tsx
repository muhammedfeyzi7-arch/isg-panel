import { useRef, useState, useCallback, useEffect } from 'react';
import Button from './Button';
import { getInitials } from './Avatar';
import { validateUploadFile } from '@/lib/fileUpload';

interface AvatarUploadProps {
  /** Mevcut profil fotoğrafı (dataURL veya uzak URL). Boş ise baş harf avatarı gösterilir. */
  src?: string | null;
  /** Baş harf avatarı için tam ad (örn. "Muhammed Admin"). */
  name: string;
  /** Yeni fotoğraf seçildiğinde dataURL, kaldırıldığında null döner. */
  onChange: (dataUrl: string | null) => void;
  /** Geçersiz dosya / boyut aşımı gibi durumlarda mesaj. (Shared Toast'a bağlanır.) */
  onError?: (message: string) => void;
  /** Fotoğraf işlenirken (kırpma/küçültme) true olur. Kayıt butonunu kilitlemek için kullanılır. */
  onBusyChange?: (busy: boolean) => void;
  /** Ham dosya seçildiğinde (Storage'a yüklemek için) File döner; kaldırıldığında null. */
  onFileSelect?: (file: File | null) => void;
  maxSize?: number; // bytes
  size?: number; // önizleme çapı (px)
  disabled?: boolean;
  label?: string;
  className?: string;
  /** Düzen: 'horizontal' (varsayılan, geniş alanlar) veya 'vertical' (dar kolonlar için dikey/kompakt). */
  layout?: 'horizontal' | 'vertical';
}

// Profil fotoğrafı için kabul edilen türler (tek kaynak: fileUpload çekirdeği).
const ACCEPT_ATTR = 'image/jpeg,image/png,image/webp';

// Sonuç görselin en uzun kenarı. Avatar küçük olduğu için bu değer yeterli
// ve localStorage'a yazılabilir boyutta kalmasını sağlar.
const MAX_DIMENSION = 512;

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Görseli kare merkez kırpma + küçültme ile dataURL'e dönüştürür.
 * Amaç: avatar olarak kullanılabilir, küçük ve localStorage dostu bir çıktı üretmek.
 * Kırpma görseli bozmaz (object-cover ile aynı davranış: merkezden kare alınır).
 */
function processImage(file: File, maxDimension: number): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const size = Math.min(maxDimension, img.naturalWidth, img.naturalHeight);
        const sx = (img.naturalWidth - size) / 2;
        const sy = (img.naturalHeight - size) / 2;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          URL.revokeObjectURL(url);
          reject(new Error('Canvas desteklenmiyor.'));
          return;
        }
        ctx.drawImage(img, sx, sy, size, size, 0, 0, size, size);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        URL.revokeObjectURL(url);
        resolve(dataUrl);
      } catch (err) {
        URL.revokeObjectURL(url);
        reject(err);
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Görsel yüklenemedi.'));
    };
    img.src = url;
  });
}

/**
 * İSGDenetim ORTAK Profil Fotoğrafı Yükleme Componenti (TEK KAYNAK).
 *
 * Tüm paneller (Admin/OSGB/Firma/Uzman/Hekim) profil fotoğrafı için bu componenti
 * kullanır. Ayrı/panel bazlı avatar upload sistemi OLUŞTURULAMAZ.
 *
 * KİLİT KURALLAR:
 * - URL ile fotoğraf yükleme YOKTUR. Yalnızca bilgisayardan/cihazdan dosya seçme
 *   ve sürükle & bırak desteklenir.
 * - Geçerli türler: JPG/JPEG, PNG, WEBP.
 * - Kare merkez kırpma + küçültme (512px) ile localStorage dostu çıktı üretilir.
 * - "Fotoğrafı Değiştir" / "Fotoğrafı Kaldır" / "Profil fotoğrafı ekle" akışları.
 */
export default function AvatarUpload({
  src,
  name,
  onChange,
  onError,
  onBusyChange,
  onFileSelect,
  maxSize = 5 * 1024 * 1024,
  size = 64,
  disabled = false,
  label,
  className = '',
  layout = 'horizontal',
}: AvatarUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [processing, setProcessing] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  // Drag sayaç: iç elemanlara geçişte dragleave tetiklenip alanın titremesini önler.
  const dragDepthRef = useRef(0);
  const processingRef = useRef(false);
  const [imgError, setImgError] = useState(false);

  const setBusy = useCallback(
    (busy: boolean) => {
      processingRef.current = busy;
      setProcessing(busy);
      onBusyChange?.(busy);
    },
    [onBusyChange],
  );

  const handleFiles = useCallback(
    async (rawFiles: FileList | File[]) => {
      if (disabled || processingRef.current) return;
      const file = Array.from(rawFiles)[0];
      if (!file) return;

      const err = validateUploadFile(file, { accept: ACCEPT_ATTR, maxSize });
      if (err) {
        onError?.(err);
        return;
      }

      setBusy(true);
      try {
        const dataUrl = await processImage(file, MAX_DIMENSION);
        onChange(dataUrl);
        onFileSelect?.(file);
      } catch {
        onError?.('Fotoğraf işlenirken bir hata oluştu. Lütfen tekrar deneyin.');
      } finally {
        setBusy(false);
      }
    },
    [disabled, maxSize, onChange, onError, onFileSelect, setBusy],
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragDepthRef.current = 0;
      setIsDragOver(false);
      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        void handleFiles(e.dataTransfer.files);
      }
    },
    [handleFiles],
  );

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      void handleFiles(e.target.files);
    }
    e.target.value = '';
  };

  const handleRemove = () => {
    if (disabled || processingRef.current) return;
    onChange(null);
    onFileSelect?.(null);
  };

  const hasPhoto = !!src;
  const initialFontSize = Math.round(size * 0.32);
  const isVertical = layout === 'vertical';

  const circle = (
    <div
      className={`relative flex items-center justify-center rounded-full overflow-hidden bg-primary-100 border-2 transition-colors flex-shrink-0 ${
        isDragOver ? 'border-primary-500' : 'border-background-300/30'
      } ${disabled ? 'opacity-60' : 'cursor-pointer'}`}
      style={{ width: size, height: size }}
      onClick={() => !disabled && !processing && inputRef.current?.click()}
      onDragEnter={(e) => {
        e.preventDefault();
        if (disabled || processing) return;
        dragDepthRef.current += 1;
        setIsDragOver(true);
      }}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled && !processing) setIsDragOver(true);
      }}
      onDragLeave={(e) => {
        e.preventDefault();
        dragDepthRef.current = Math.max(0, dragDepthRef.current - 1);
        if (dragDepthRef.current === 0) setIsDragOver(false);
      }}
      onDrop={handleDrop}
      role="button"
      tabIndex={disabled ? -1 : 0}
      aria-label="Profil fotoğrafını değiştir"
      onKeyDown={(e) => {
        if (disabled || processing) return;
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          inputRef.current?.click();
        }
      }}
    >
      {hasPhoto && !imgError ? (
        <img src={src} alt={name} loading="lazy" onError={() => setImgError(true)} className="w-full h-full object-cover" />
      ) : (
        <span className="font-semibold text-primary-700" style={{ fontSize: initialFontSize }}>
          {getInitials(name)}
        </span>
      )}

      {processing && (
        <div className="absolute inset-0 bg-background-950/40 flex items-center justify-center">
          <span className="inline-block w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {isDragOver && !processing && (
        <div className="absolute inset-0 bg-primary-500/20 flex items-center justify-center">
          <i className="ri-upload-cloud-2-line text-inverse text-2xl" />
        </div>
      )}
    </div>
  );

  const actions = (
    <div className={isVertical ? 'flex flex-col gap-2 w-full min-w-0' : 'flex flex-col gap-2 flex-1 min-w-0'}>
      <div className={isVertical ? 'flex flex-col items-stretch gap-2 w-full' : 'flex flex-wrap items-center gap-2'}>
        <Button
          variant="secondary"
          size="sm"
          type="button"
          fullWidth={isVertical}
          onClick={() => inputRef.current?.click()}
          leftIcon={<i className="ri-upload-cloud-2-line" />}
          disabled={disabled || processing}
        >
          {hasPhoto ? 'Fotoğrafı Değiştir' : 'Fotoğraf Ekle'}
        </Button>

        {hasPhoto && (
          <Button
            variant="ghost"
            size="sm"
            type="button"
            fullWidth={isVertical}
            onClick={handleRemove}
            leftIcon={<i className="ri-delete-bin-line" />}
            disabled={disabled || processing}
          >
            Kaldır
          </Button>
        )}
      </div>

      <p className={isVertical ? 'text-xs text-foreground-500 text-center leading-snug' : 'text-xs text-foreground-500'}>
        JPG, PNG veya WEBP — en fazla {formatBytes(maxSize)}
      </p>
    </div>
  );

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label className="isg-form-label">{label}</label>
      )}

      <div className={isVertical ? 'flex flex-col items-center gap-3' : 'flex items-center gap-4'}>
        {circle}
        {actions}

        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT_ATTR}
          className="hidden"
          onChange={handleChange}
          disabled={disabled}
        />
      </div>
    </div>
  );
}