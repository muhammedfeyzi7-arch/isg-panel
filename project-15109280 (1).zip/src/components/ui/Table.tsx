import { Fragment, memo, useCallback, useEffect, useMemo, useRef } from 'react';
import type { ReactNode } from 'react';
import { useMediaQuery } from '@/hooks/useMediaQuery';

export interface TableColumn<T> {
  key: string;
  header: string;
  width?: string;
  sortable?: boolean;
  render?: (row: T, index: number) => ReactNode;
  align?: 'left' | 'center' | 'right';
}

export interface TableProps<T> {
  data: T[];
  columns: TableColumn<T>[];
  keyExtractor: (row: T) => string;
  selectable?: boolean;
  selectedKeys?: string[];
  onSelectionChange?: (keys: string[]) => void;
  sortKey?: string;
  sortDirection?: 'asc' | 'desc';
  onSort?: (key: string) => void;
  rowActions?: (row: T) => ReactNode;
  loading?: boolean;
  emptyState?: ReactNode;
  errorState?: ReactNode;
  className?: string;
  onRowClick?: (row: T) => void;
  /**
   * Satırın üzerine gelindiğinde (masaüstü) BİR KEZ tetiklenir. Amaç: detay
   * modalının verisini kullanıcı tıklamadan önce arka planda ısıtmak (ön-yükleme).
   * Non-blocking'dir; hata durumunda hiçbir akışı bozmaz. Mobilde hover olmadığı
   * için tetiklenmez.
   */
  onRowHover?: (row: T) => void;
  stickyHeader?: boolean;
  /**
   * Satır yoğunluğu. Varsayılan `default` mevcut `.isg-table-*` metriklerini
   * kullanır; `compact` yoğun veri listeleri, `comfortable` ferah görünüm
   * içindir. Tüm satır/hücre ölçüleri merkezi Shared UI token'ından gelir.
   */
  density?: 'compact' | 'default' | 'comfortable';
  /** Mobil kart görünümü. Verilmezse tablo kolonları otomatik key-value kart yapılır. */
  mobileCardRenderer?: (row: T) => ReactNode;
  /**
   * Satır genişletme (accordion) desteği. `renderExpandedRow` verildiğinde,
   * `expandedKeys` içindeki satırların altında ek içerik gösterilir. Böylece
   * sayfalar/modal içerikleri ayrı bir "expandable table" yazmak zorunda kalmaz.
   * Açma/kapama kontrolü `rowActions` içindeki butondan `onToggleExpand` ile yapılır.
   */
  expandedKeys?: string[];
  onToggleExpand?: (key: string) => void;
  renderExpandedRow?: (row: T) => ReactNode;
  /**
   * Tablo altı toplam/summary satırı. İçerik bir `<tr>` (veya birden fazla) olarak
   * `<tfoot>` içine render edilir. Ayrı bir tablo motoru yazmadan toplam satırı
   * göstermeyi sağlayan merkezi yetenektir.
   */
  footer?: ReactNode;
}

interface TableRowProps<T> {
  row: T;
  rowIndex: number;
  rowKey: string;
  columns: TableColumn<T>[];
  selectable?: boolean;
  isSelected: boolean;
  isExpanded: boolean;
  colSpanCount: number;
  rowActions?: (row: T) => ReactNode;
  renderExpandedRow?: (row: T) => ReactNode;
  onRowClick?: (row: T) => void;
  onRowHover?: (row: T) => void;
  onToggleSelectRow: (key: string) => void;
}

/**
 * Tek satırın (ve varsa genişletilmiş alt satırının) render'ı.
 *
 * PERFORMANS KİLİDİ: Bu bileşen `memo` ile sarılır. Üst bileşen (Table) alakasız
 * bir state (dropdown açılması, modal ref, filtre paneli vb.) nedeniyle yeniden
 * çizilse bile; `row` referansı, `isSelected`, `isExpanded` ve `columns`/`rowActions`
 * referansları değişmediği sürece satır DOM'u YENİDEN ÜRETİLMEZ. Özellikle çoklu
 * seçimde yalnızca seçimi değişen satır yeniden çizilir (diğerleri atlanır).
 * Kolon/fonksiyon referansları sayfa tarafında sabitlenmezse güvenli biçimde
 * normal davranışa döner (bayat veri riski YOKTUR).
 */
function TableRowBase<T extends Record<string, unknown>>({
  row,
  rowIndex,
  rowKey,
  columns,
  selectable,
  isSelected,
  isExpanded,
  colSpanCount,
  rowActions,
  renderExpandedRow,
  onRowClick,
  onRowHover,
  onToggleSelectRow,
}: TableRowProps<T>) {
  return (
    <Fragment>
      <tr
        className={`isg-table-row border-b border-background-300/40 dark:border-background-400/35 ${isSelected ? 'isg-table-row-selected' : ''} ${onRowClick ? 'cursor-pointer' : ''}`}
        onClick={() => onRowClick?.(row)}
        onMouseEnter={() => onRowHover?.(row)}
      >
        {selectable && (
          <td className="isg-table-cell" onClick={(e) => e.stopPropagation()}>
            <label className="inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                aria-label="Satırı seç"
                className="peer sr-only"
                checked={isSelected}
                onChange={() => onToggleSelectRow(rowKey)}
              />
              <div className="w-4 h-4 rounded border-2 border-background-400 peer-checked:bg-primary-500 peer-checked:border-primary-500 flex items-center justify-center transition-colors">
                <i className="ri-check-line text-inverse text-xs opacity-0 peer-checked:opacity-100" />
              </div>
            </label>
          </td>
        )}
        {columns.map((col) => (
          <td
            key={col.key}
            className={`isg-table-cell text-foreground-800 lg:whitespace-nowrap ${col.align === 'center' ? 'text-center' : col.align === 'right' ? 'text-right' : ''}`}
          >
            {col.render ? col.render(row, rowIndex) : String(row[col.key as keyof T] ?? '')}
          </td>
        ))}
        {rowActions && (
          <td className="isg-table-cell" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-end gap-1">
              {rowActions(row)}
            </div>
          </td>
        )}
      </tr>
      {isExpanded && (
        <tr className="bg-background-100/70 dark:bg-background-300/20 border-b border-background-300/40 dark:border-background-400/15">
          <td colSpan={colSpanCount} className="isg-table-cell">
            {renderExpandedRow?.(row)}
          </td>
        </tr>
      )}
    </Fragment>
  );
}

const TableRow = memo(TableRowBase) as unknown as typeof TableRowBase;

/**
 * Global Shared Table motoru.
 *
 * PERFORMANS: Bu bileşen `useMediaQuery` ile breakpoint'i bilir ve aynı anda
 * TEK varyant render eder — mobilde kart, desktop'ta tablo. Önceden her kayıt
 * iki kez DOM'a basılıyordu (mobile kart + desktop tablo birlikte); artık yok.
 * Liste kaydırma / filtreleme / sayfa geçişlerinde DOM yükü yarıya iner.
 *
 * Satırlar `TableRow` (memo) ile çizilir; seçim ve alakasız state değişimlerinde
 * yalnızca değişen satır yeniden üretilir (büyük listelerde belirgin kazanç).
 */
export default function Table<T extends Record<string, unknown>>({
  data,
  columns,
  keyExtractor,
  selectable,
  selectedKeys = [],
  onSelectionChange,
  sortKey,
  sortDirection,
  onSort,
  rowActions,
  loading,
  emptyState,
  errorState,
  className = '',
  onRowClick,
  onRowHover,
  stickyHeader,
  density = 'default',
  mobileCardRenderer,
  expandedKeys = [],
  renderExpandedRow,
  footer,
}: TableProps<T>) {
  const isMobile = useMediaQuery('(max-width: 1023px)');

  const selectedSet = useMemo(() => new Set(selectedKeys), [selectedKeys]);
  const allKeys = useMemo(() => data.map(keyExtractor), [data, keyExtractor]);
  const isAllSelected = data.length > 0 && allKeys.every((k) => selectedSet.has(k));
  const isIndeterminate = data.length > 0 && !isAllSelected && allKeys.some((k) => selectedSet.has(k));
  const selectAllRef = useRef<HTMLInputElement>(null);

  // Seçim handler'ı KARARLI (useCallback []) tutulur; her seçim değişiminde tüm
  // satırların yeniden çizilmesini önlemek için güncel değerler ref üzerinden okunur.
  const selectedKeysRef = useRef(selectedKeys);
  selectedKeysRef.current = selectedKeys;
  const onSelectionChangeRef = useRef(onSelectionChange);
  onSelectionChangeRef.current = onSelectionChange;

  useEffect(() => {
    if (selectAllRef.current) {
      selectAllRef.current.indeterminate = isIndeterminate;
    }
  }, [isIndeterminate]);

  const toggleSelectAll = () => {
    if (!onSelectionChange) return;
    if (isAllSelected) {
      onSelectionChange(selectedKeys.filter((k) => !allKeys.includes(k)));
    } else {
      onSelectionChange([...new Set([...selectedKeys, ...allKeys])]);
    }
  };

  const toggleSelectRow = useCallback((key: string) => {
    const handler = onSelectionChangeRef.current;
    if (!handler) return;
    const current = selectedKeysRef.current;
    if (current.includes(key)) {
      handler(current.filter((k) => k !== key));
    } else {
      handler([...current, key]);
    }
  }, []);

  const handleSort = (key: string) => {
    if (onSort) onSort(key);
  };

  if (loading) {
    if (isMobile) {
      return (
        <div role="status" aria-label="Yükleniyor" className={`w-full ${className} space-y-2`}>
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 bg-background-200 dark:bg-background-300/45 rounded-xl animate-pulse" />
          ))}
        </div>
      );
    }
    return (
      <div role="status" aria-label="Yükleniyor" className={`w-full ${className} animate-pulse space-y-3`}>
        <div className="h-10 bg-background-200 dark:bg-background-300/45 rounded" />
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-12 bg-background-200 dark:bg-background-300/45 rounded" />
        ))}
      </div>
    );
  }

  if (errorState) return <div className={className}>{errorState}</div>;
  if (data.length === 0 && emptyState) return <div className={className}>{emptyState}</div>;

  // ── Mobil: Kart Görünümü (tek varyant) ──
  if (isMobile) {
    return (
      <div className={`w-full ${className} space-y-2`}>
        {data.map((row, idx) => {
          const key = keyExtractor(row);
          const isSelected = selectedSet.has(key);

          if (mobileCardRenderer) {
            return (
              <div
                key={key}
                onClick={() => onRowClick?.(row)}
                onMouseEnter={() => onRowHover?.(row)}
                className={onRowClick ? 'cursor-pointer' : ''}
              >
                {mobileCardRenderer(row)}
              </div>
            );
          }

          // Otomatik key-value kart layout
          const firstCol = columns[0];
          const restCols = columns.slice(1);

          return (
            <div
              key={key}
              className={`bg-background-100 dark:bg-background-200 border border-background-300/50 dark:border-background-400/25 rounded-xl p-3 transition-colors ${onRowClick ? 'cursor-pointer active:bg-background-200/70 dark:active:bg-background-300/40' : ''}`}
              onClick={() => onRowClick?.(row)}
              onMouseEnter={() => onRowHover?.(row)}
            >
              {/* Kart başlığı: ilk kolon + aksiyonlar */}
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  {selectable && (
                    <label
                      className="inline-flex items-center cursor-pointer flex-shrink-0"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <input
                        type="checkbox"
                        aria-label="Satırı seç"
                        className="peer sr-only"
                        checked={isSelected}
                        onChange={() => toggleSelectRow(key)}
                      />
                      <div className="w-4 h-4 rounded border-2 border-background-400 peer-checked:bg-primary-500 peer-checked:border-primary-500 flex items-center justify-center transition-colors">
                        <i className="ri-check-line text-inverse text-xs opacity-0 peer-checked:opacity-100" />
                      </div>
                    </label>
                  )}
                  <div className="min-w-0">
                    {firstCol?.render ? (
                      firstCol.render(row, idx)
                    ) : (
                      <p className="text-sm font-semibold text-foreground-800 truncate">
                        {String(row[firstCol?.key as keyof T] ?? '')}
                      </p>
                    )}
                  </div>
                </div>
                {rowActions && (
                  <div className="flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                    {rowActions(row)}
                  </div>
                )}
              </div>

              {/* Kalan kolonlar: metadata satırları */}
              {restCols.length > 0 && (
                <div className="mt-2 pt-2 border-t border-background-300/20 dark:border-background-400/20 space-y-1">
                  {restCols.map((col) => (
                    <div key={col.key} className="flex items-center justify-between gap-2">
                      <span className="text-xs text-foreground-500 flex-shrink-0">{col.header}</span>
                      <span className="text-sm text-foreground-700 text-right">
                        {col.render ? col.render(row, idx) : String(row[col.key as keyof T] ?? '')}
                      </span>
                    </div>
                  ))}
                </div>
              )}

              {renderExpandedRow && expandedKeys.includes(key) && (
                <div className="mt-2 pt-2 border-t border-background-300/20 dark:border-background-400/20">
                  {renderExpandedRow(row)}
                </div>
              )}
            </div>
          );
        })}
      </div>
    );
  }

  // ── Desktop: Tablo Görünümü (tek varyant) ──
  const densityCls = density === 'compact' ? 'isg-table-compact' : density === 'comfortable' ? 'isg-table-comfortable' : '';
  const colSpanCount = (selectable ? 1 : 0) + columns.length + (rowActions ? 1 : 0);
  return (
    <div className={`w-full ${className} ${densityCls} ${stickyHeader ? 'isg-table-sticky' : 'isg-table-scroll overflow-x-auto overscroll-x-contain'}`}>
      <table className="w-full text-sm">
        <thead className={stickyHeader ? 'sticky top-0 z-10' : ''}>
          <tr className={`border-b border-background-300/80 dark:border-background-400/40 ${stickyHeader ? 'bg-background-200 dark:bg-background-300/60' : 'bg-background-200/60 dark:bg-background-300/45'}`}>
            {selectable && (
              <th className="isg-table-head-cell w-10">
                <label className="inline-flex items-center cursor-pointer">
                  <input
                    ref={selectAllRef}
                    type="checkbox"
                    aria-label="Tümünü seç"
                    className="peer sr-only"
                    checked={isAllSelected}
                    onChange={toggleSelectAll}
                  />
                  <div className={`w-4 h-4 rounded border-2 flex items-center justify-center transition-colors ${isAllSelected || isIndeterminate ? 'bg-primary-500 border-primary-500' : 'border-background-400'}`}>
                    {isIndeterminate ? (
                      <i className="ri-subtract-line text-inverse text-xs" />
                    ) : (
                      <i className={`ri-check-line text-inverse text-xs ${isAllSelected ? 'opacity-100' : 'opacity-0'}`} />
                    )}
                  </div>
                </label>
              </th>
            )}
            {columns.map((col) => (
              <th
                key={col.key}
                tabIndex={col.sortable ? 0 : undefined}
                onKeyDown={col.sortable ? (e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleSort(col.key);
                  }
                } : undefined}
                className={`isg-table-head-cell text-left font-semibold uppercase tracking-wide text-foreground-500 dark:text-foreground-500 ${
                  col.sortable ? 'cursor-pointer select-none hover:text-foreground-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-primary-500 focus-visible:outline-offset-[-2px]' : ''
                } ${col.align === 'center' ? 'text-center' : col.align === 'right' ? 'text-right' : ''}`}
                style={{ width: col.width }}
                aria-sort={col.sortable ? (sortKey === col.key ? (sortDirection === 'asc' ? 'ascending' : 'descending') : 'none') : undefined}
                onClick={() => col.sortable && handleSort(col.key)}
              >
                <div className={`flex items-center gap-1 ${col.align === 'center' ? 'justify-center' : col.align === 'right' ? 'justify-end' : ''}`}>
                  {col.header}
                  {col.sortable && sortKey === col.key && (
                    sortDirection === 'asc' ? (
                      <i className="ri-arrow-up-s-line text-foreground-400" />
                    ) : (
                      <i className="ri-arrow-down-s-line text-foreground-400" />
                    )
                  )}
                  {col.sortable && sortKey !== col.key && (
                    <i className="ri-arrow-up-down-line text-foreground-400 text-xs" />
                  )}
                </div>
              </th>
            ))}
            {rowActions && <th className="isg-table-head-cell w-10" />}
          </tr>
        </thead>
        <tbody>
          {data.map((row, idx) => {
            const key = keyExtractor(row);
            const isSelected = selectedSet.has(key);
            const isExpanded = !!renderExpandedRow && expandedKeys.includes(key);
            return (
              <TableRow
                key={key}
                rowKey={key}
                row={row}
                rowIndex={idx}
                columns={columns}
                selectable={selectable}
                isSelected={isSelected}
                isExpanded={isExpanded}
                colSpanCount={colSpanCount}
                rowActions={rowActions}
                renderExpandedRow={renderExpandedRow}
                onRowClick={onRowClick}
                onRowHover={onRowHover}
                onToggleSelectRow={toggleSelectRow}
              />
            );
          })}
        </tbody>
        {footer && <tfoot>{footer}</tfoot>}
      </table>
    </div>
  );
}