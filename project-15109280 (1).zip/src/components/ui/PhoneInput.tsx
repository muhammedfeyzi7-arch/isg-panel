import { forwardRef, type InputHTMLAttributes } from 'react';

interface PhoneInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value'> {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  helpText?: string;
  required?: boolean;
  disabled?: boolean;
  containerClassName?: string;
  leftIcon?: React.ReactNode;
}

/**
 * Türkiye telefon numarası girişi. Yazdıkça otomatik formatlar:
 * "0532 123 45 67". +90 ülke kodunu ve boşlukları normalleştirir.
 * onChange her zaman formatlanmış görünen değeri döndürür.
 */
export function formatTRPhone(input: string): string {
  const digits = input.replace(/\D/g, '');
  if (!digits) return '';
  let d = digits;
  if (d.startsWith('90')) d = d.slice(2);
  if (!d.startsWith('0')) d = `0${d}`;
  d = d.slice(0, 11); // 0 + 10 hane
  const body = d.slice(1);
  const groups = [body.slice(0, 3), body.slice(3, 6), body.slice(6, 8), body.slice(8, 10)].filter((g) => g.length > 0);
  if (groups.length === 0) return '0';
  let out = `0${groups[0]}`;
  for (let i = 1; i < groups.length; i++) out += ` ${groups[i]}`;
  return out;
}

const PhoneInput = forwardRef<HTMLInputElement, PhoneInputProps>(function PhoneInput(
  { label, value, onChange, error, helpText, required, disabled, containerClassName = '', leftIcon, className = '', autoComplete = 'off', ...props },
  ref
) {
  const hasError = !!error;
  const stateCls = hasError ? 'isg-input-error' : '';

  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}
      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3 text-foreground-400 pointer-events-none">{leftIcon}</div>
        )}
        <input
          ref={ref}
          type="tel"
          inputMode="tel"
          autoComplete={autoComplete}
          value={value}
          onChange={(e) => onChange(formatTRPhone(e.target.value))}
          onFocus={(e) => {
            // Boş telefon alanına odaklanınca baştaki 0 otomatik gelir
            // (kullanıcı "05.." yazmak zorunda kalmaz).
            if (!value.trim()) onChange('0');
            props.onFocus?.(e);
          }}
          placeholder="0532 123 45 67"
          disabled={disabled}
          className={`isg-input w-full ${leftIcon ? 'pl-10' : ''} ${stateCls} ${
            disabled ? 'opacity-50 cursor-not-allowed' : ''
          } ${className}`}
          {...props}
        />
      </div>
      {hasError && (
        <p className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p className="isg-form-help">{helpText}</p>
      )}
    </div>
  );
});

export default PhoneInput;