/**
 * Tembel (lazy) yüklenen ağır modal bileşenleri için hafif bekleme iskeleti.
 *
 * Bu modallar yalnızca kullanıcı ilgili aksiyonu tetikleyince (örn. bildirime
 * tıklama, desteği açma) indirilir; indirme tamamlanana kadar bu iskelet gösterilir.
 * Böylece panel ilk açılışında bu modallar bundle'a dahil olmaz.
 */
export default function ModalFallback() {
  return (
    <div className="flex items-center justify-center py-12">
      <span
        className="inline-block w-7 h-7 border-2 border-primary-500 border-t-transparent rounded-full animate-spin"
        aria-hidden="true"
      />
    </div>
  );
}