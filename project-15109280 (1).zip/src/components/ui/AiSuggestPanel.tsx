import type { ReactNode } from 'react';

export interface AiSuggestion {
  id: string;
  title: string;
  description?: string;
  /** Öneri metni (vurgulu). */
  suggestion?: string;
  /** Kaynak etiketi (ör. "Kural", "AI", "Geçmiş"). */
  source?: string;
  /** Salt-okunur mu (aksiyon gösterme). */
  readOnly?: boolean;
}

interface AiSuggestPanelProps {
  suggestions: AiSuggestion[];
  title?: string;
  /** Tek öneri için "+ Ekle" aksiyonu. */
  onAdd?: (s: AiSuggestion) => void;
  /** "Tümünü Ekle" aksiyonu. */
  onAddAll?: () => void;
  /** "Yenile" aksiyonu. */
  onRefresh?: () => void;
  /** Kapatma aksiyonu (opsiyonel). */
  onClose?: () => void;
  loading?: boolean;
  emptyText?: string;
  addLabel?: string;
  className?: string;
  headerRight?: ReactNode;
}

/**
 * GLOBAL AI / ÖNERİ PANELİ — Shared UI tek kaynak.
 *
 * Referanstaki "AI Önerileri" panelinin ortak karşılığıdır ve tek bir modüle
 * özel DEĞİLDİR: Saha Denetim, Risk, Eğitim, Acil Durum ve gelecekteki tüm
 * AI/kural tabanlı öneri alanları bu bileşeni kullanır. Kaynak etiketi ile
 * öneri metni ayrı gösterilir; "+ Ekle" / "Tümünü Ekle" / "Yenile" aksiyonları
 * dışarıdan beslenir (business logic bu bileşene gömülmez).
 */
export default function AiSuggestPanel({
  suggestions,
  title = 'Öneriler',
  onAdd,
  onAddAll,
  onRefresh,
  onClose,
  loading = false,
  emptyText = 'Şu an için öneri yok.',
  addLabel = 'Ekle',
  className = '',
  headerRight,
}: AiSuggestPanelProps) {
  return (
    <div className={`isg-ai-panel p-3 flex flex-col min-w-0 ${className}`}>
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-7 h-7 rounded-md bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-sparkling-2-line text-primary-600 dark:text-primary-300 text-sm" />
          </span>
          <span className="isg-text-card-title text-foreground-900 truncate">{title}</span>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          {headerRight}
          {onRefresh && (
            <button
              type="button"
              onClick={onRefresh}
              className="isg-iconbtn isg-iconbtn-sm text-foreground-500 hover:text-primary-600 hover:bg-background-200"
              title="Yenile"
              aria-label="Yenile"
              disabled={loading}
            >
              <i className={`ri-refresh-line text-sm ${loading ? 'animate-spin' : ''}`} />
            </button>
          )}
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="isg-iconbtn isg-iconbtn-sm text-foreground-500 hover:text-foreground-800 hover:bg-background-200"
              title="Kapat"
              aria-label="Kapat"
            >
              <i className="ri-close-line text-sm" />
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-col gap-2 min-h-0 overflow-y-auto overflow-x-hidden isg-scroll-pane max-h-[38vh]">
        {suggestions.map((s) => (
          <div key={s.id} className="isg-ai-card p-2.5">
            <div className="flex items-start gap-2">
              <i className="ri-sparkling-2-line text-primary-500 text-xs mt-0.5 flex-shrink-0" />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <p className="text-xs font-semibold text-foreground-900">{s.title}</p>
                  {s.source && (
                    <span className="isg-text-nano px-1.5 py-0.5 rounded-full bg-secondary-100 text-secondary-900 dark:bg-secondary-50 dark:text-secondary-700">
                      {s.source}
                    </span>
                  )}
                </div>
                {s.description && <p className="isg-text-micro text-foreground-500 mt-0.5">{s.description}</p>}
                {s.suggestion && (
                  <p className="isg-text-micro text-primary-700 dark:text-primary-300 mt-1 leading-relaxed">
                    {s.suggestion}
                  </p>
                )}
                {onAdd && !s.readOnly && (
                  <button
                    type="button"
                    onClick={() => onAdd(s)}
                    className="mt-1.5 inline-flex items-center gap-1 text-[11px] font-semibold text-primary-600 dark:text-primary-300 hover:text-primary-700 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-add-line" /> {addLabel}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
        {suggestions.length === 0 && !loading && (
          <p className="text-xs text-foreground-400 text-center py-4">{emptyText}</p>
        )}
      </div>

      {onAddAll && suggestions.length > 0 && (
        <button
          type="button"
          onClick={onAddAll}
          className="mt-2 w-full isg-btn isg-btn-secondary isg-btn-sm justify-center"
        >
          <i className="ri-add-circle-line" /> Tümünü Ekle
        </button>
      )}
    </div>
  );
}