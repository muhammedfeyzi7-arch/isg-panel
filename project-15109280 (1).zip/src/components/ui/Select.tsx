import { Fragment, useId, useMemo, useRef, useState } from 'react';
import DropdownPanel from './DropdownPanel';
import { turkishIncludes } from '@/utils/turkishText';
import { listboxStep } from '@/hooks/useKeyboardNav';

export interface SelectOption {
  value: string;
  label: string;
  disabled?: boolean;
  /** Opsiyonel grup başlığı — verilirse dropdown'da gruplu başlık satırı gösterilir. */
  group?: string;
}

interface SelectProps {
  label?: string;
  error?: string;
  helpText?: string;
  options: SelectOption[];
  value?: string;
  defaultValue?: string;
  onChange?: (e: { target: { value: string; name?: string } }) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  searchable?: boolean;
  /** Kullanıcı listede olmayan serbest metni de yazabilsin mi? (combobox) */
  creatable?: boolean;
  loading?: boolean;
  leftIcon?: React.ReactNode;
  containerClassName?: string;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  name?: string;
  id?: string;
}

/**
 * Ortak Custom Select / Dropdown. Native <select> KULLANILMAZ.
 * Tüm form, filtre, modal ve tablo sistemlerinde tek dropdown standarttır.
 * Viewport'a göre aşağı/yukarı açılır, klavye (Yukarı/Aşağı/Enter/Esc) destekler.
 */
export default function Select({
  label,
  error,
  helpText,
  options,
  value,
  defaultValue,
  onChange,
  placeholder = 'Seçiniz',
  required,
  disabled,
  searchable,
  creatable,
  loading,
  leftIcon,
  containerClassName = '',
  className = '',
  size = 'md',
  name,
  id,
}: SelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const generatedId = useId();
  const fieldId = id ?? generatedId;
  const hasError = !!error;
  const errorId = hasError ? `${fieldId}-error` : undefined;
  const helpId = helpText ? `${fieldId}-help` : undefined;
  const describedBy = [errorId, helpId].filter(Boolean).join(' ') || undefined;
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const [internalValue, setInternalValue] = useState<string>(defaultValue ?? '');
  const anchorRef = useRef<HTMLButtonElement>(null);

  const currentValue = value !== undefined ? value : internalValue;
  const selectedLabel = useMemo(
    () => options.find((o) => o.value === currentValue)?.label ?? currentValue,
    [options, currentValue],
  );

  const filteredOptions = useMemo(() => {
    const q = query.trim();
    if (!q) return options;
    return options.filter((o) => turkishIncludes(o.label, q));
  }, [options, query]);

  // Serbest metin (combobox) modu: arama kutusu daima görünür ve listede olmayan
  // bir değer yazıldığında "... kullan" satırıyla doğrudan kabul edilebilir.
  const showSearch = searchable || creatable;
  const trimmedQuery = query.trim();
  const canCreate =
    !!creatable &&
    trimmedQuery !== '' &&
    !options.some((o) => o.value === trimmedQuery || o.label === trimmedQuery);

  const stateCls = hasError ? 'isg-input-error' : '';

  // Ölçü merkezi input token'ından gelir (sm/lg varyantları --d-input-*).
  const sizeCls = size === 'sm' ? 'isg-input-sm' : size === 'lg' ? 'isg-input-lg' : '';

  const select = (opt: SelectOption) => {
    if (opt.disabled) return;
    if (value === undefined) setInternalValue(opt.value);
    onChange?.({ target: { value: opt.value, name } });
    setQuery('');
    setOpen(false);
    setHighlightIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Home' || e.key === 'End') {
      e.preventDefault();
      setOpen(true);
      setHighlightIndex((prev) => {
        const count = filteredOptions.length;
        if (count === 0) return -1;
        return listboxStep(prev, e.key, count) ?? prev;
      });
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      if (!open) {
        setOpen(true);
      } else if (highlightIndex >= 0 && filteredOptions[highlightIndex]) {
        select(filteredOptions[highlightIndex]);
      } else if (creatable && trimmedQuery) {
        select({ value: trimmedQuery, label: trimmedQuery });
      } else if (filteredOptions.length === 1) {
        select(filteredOptions[0]);
      }
      return;
    }
    if (e.key === 'Escape') {
      setOpen(false);
      setHighlightIndex(-1);
      return;
    }
    if (e.key === 'Tab') {
      setOpen(false);
    }
  };

  return (
    <div className={`w-full relative ${containerClassName}`}>
      {label && (
        <label htmlFor={fieldId} className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}

      <button
        ref={anchorRef}
        id={fieldId}
        name={name}
        type="button"
        onClick={() => !disabled && !loading && setOpen((o) => !o)}
        onKeyDown={handleKeyDown}
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-invalid={hasError || undefined}
        aria-describedby={describedBy}
        className={`isg-input w-full flex items-center justify-between gap-2 text-left cursor-pointer ${sizeCls} ${stateCls} ${
          disabled ? 'opacity-50 cursor-not-allowed' : ''
        } ${className}`}
      >
        <span className="flex items-center gap-2 min-w-0 flex-1">
          {leftIcon && <span className="text-foreground-400 shrink-0">{leftIcon}</span>}
          <span className={`flex-1 truncate ${currentValue === '' ? 'text-foreground-500' : 'text-foreground-800'}`}>
            {currentValue === '' ? placeholder : selectedLabel}
          </span>
        </span>
        {loading ? (
          <span className="inline-block w-4 h-4 border-2 border-foreground-300 border-t-transparent rounded-full animate-spin shrink-0" />
        ) : open ? (
          <i className="ri-arrow-up-s-line text-foreground-400 shrink-0" />
        ) : (
          <i className="ri-arrow-down-s-line text-foreground-400 shrink-0" />
        )}
      </button>

      {open && !disabled && (
        <DropdownPanel
          open={open}
          anchorRef={anchorRef}
          onClose={() => setOpen(false)}
          role="listbox"
          className="isg-popover"
        >
          {showSearch && (
            <div className="p-2 border-b isg-divider">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    if (filteredOptions.length > 0) select(filteredOptions[0]);
                    else if (creatable && query.trim()) select({ value: query.trim(), label: query.trim() });
                  }
                }}
                placeholder={creatable ? 'Yazın veya listeden seçin...' : 'Ara...'}
                autoFocus
                className="isg-input isg-input-sm w-full"
              />
            </div>
          )}
          <div className="overflow-y-auto flex-1 min-h-0">
            {canCreate && (
              <button
                type="button"
                onClick={() => select({ value: trimmedQuery, label: trimmedQuery })}
                className="w-full flex items-center gap-2 px-3 py-2 text-left text-sm text-primary-700 dark:text-primary-400 hover:bg-primary-50 dark:hover:bg-primary-500/15 border-b isg-divider cursor-pointer"
              >
                <i className="ri-add-line flex-shrink-0" />
                <span className="truncate">&ldquo;{trimmedQuery}&rdquo; kullan</span>
              </button>
            )}
            {filteredOptions.length === 0 && !canCreate ? (
              <div className="p-4 text-sm text-foreground-400 text-center">Sonuç bulunamadı</div>
            ) : (
              filteredOptions.map((opt, idx) => {
                const isSelected = currentValue === opt.value;
                const isHighlighted = idx === highlightIndex;
                const showGroupHeader = !!opt.group && (idx === 0 || filteredOptions[idx - 1]?.group !== opt.group);
                return (
                  <Fragment key={opt.value}>
                    {showGroupHeader && (
                      <div className="px-3 pt-2.5 pb-1 isg-text-eyebrow text-foreground-400">
                        {opt.group}
                      </div>
                    )}
                    <button
                      type="button"
                      role="option"
                      aria-selected={isSelected}
                      onClick={() => select(opt)}
                      onMouseEnter={() => setHighlightIndex(idx)}
                      disabled={opt.disabled}
                      className={`w-full flex items-center justify-between px-3 py-2 text-left text-sm ${
                        opt.disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'
                      } ${
                        isSelected
                          ? 'bg-primary-50 dark:bg-primary-500/15 text-primary-700 dark:text-primary-700'
                          : isHighlighted
                          ? 'bg-background-200 dark:bg-background-300/40 text-foreground-800'
                          : 'text-foreground-800 hover:bg-background-200 dark:hover:bg-background-300/30'
                      }`}
                    >
                      <span className="truncate">{opt.label}</span>
                      {isSelected && <i className="ri-check-line text-primary-500" />}
                    </button>
                  </Fragment>
                );
              })
            )}
          </div>
        </DropdownPanel>
      )}

      {hasError && (
        <p id={errorId} className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p id={helpId} className="isg-form-help">{helpText}</p>
      )}
    </div>
  );
}