import { useEffect, useRef, useState, type ReactNode } from 'react';
import DropdownPanel from './DropdownPanel';
import { useRovingFocus } from '@/hooks/useKeyboardNav';

export interface ActionMenuItem {
  label: string;
  /** Remix Icon class'ı, örn. "ri-edit-line". */
  icon?: string;
  onClick: () => void;
  tone?: 'default' | 'danger';
  disabled?: boolean;
}

export interface ActionMenuSection {
  /** Bölüm başlığı (opsiyonel). */
  title?: string;
  items: ActionMenuItem[];
}

interface ActionMenuProps {
  /** Tetikleyici: bir etiket (metin) veya yalnızca ikon. */
  trigger?: ReactNode;
  triggerIcon?: string;
  items?: ActionMenuItem[];
  sections?: ActionMenuSection[];
  align?: 'start' | 'end';
  minWidth?: number;
  className?: string;
}

/**
 * GLOBAL AKSİYON MENÜSÜ (Shared UI tek kaynak).
 * "Daha fazla" (3 nokta) veya etiketli açılır aksiyon menüsü. Bölüm başlıkları
 * ve ayraçları destekler. Grid/liste satırları, kart başlıkları ve toolbar'lar
 * için ORTAK menü standardıdır. Meydana gelen ContextMenu ile AYNI yüzey
 * (`.isg-popover`) ve AYNI klavye navigasyonu kullanır; ayrı bir menü stili
 * kurmaz. İş mantığı içermez; yalnızca aksiyonları çağırır.
 */
export default function ActionMenu({
  trigger,
  triggerIcon = 'ri-more-2-line',
  items,
  sections,
  align = 'end',
  minWidth = 176,
  className = '',
}: ActionMenuProps) {
  const [open, setOpen] = useState(false);
  const anchorRef = useRef<HTMLButtonElement>(null);

  const allItems: ActionMenuItem[] = sections ? sections.flatMap((s) => s.items) : (items ?? []);

  const { itemRef, onKeyDown, focusIndex } = useRovingFocus({
    itemCount: allItems.length,
    orientation: 'vertical',
    activateOnNavigate: false,
    onEscape: () => setOpen(false),
  });

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => focusIndex(0), 0);
    return () => clearTimeout(t);
  }, [open, focusIndex]);

  const renderItem = (item: ActionMenuItem, idx: number) => (
    <button
      key={`${item.label}-${idx}`}
      type="button"
      ref={itemRef(idx)}
      role="menuitem"
      disabled={item.disabled}
      onClick={(e) => {
        e.stopPropagation();
        if (item.disabled) return;
        setOpen(false);
        item.onClick();
      }}
      onKeyDown={(e) => onKeyDown(e, idx)}
      className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 cursor-pointer whitespace-nowrap ${
        item.disabled
          ? 'opacity-40 cursor-not-allowed text-foreground-500'
          : item.tone === 'danger'
          ? 'text-danger-600 hover:bg-danger-50/60 dark:text-danger-400 dark:hover:bg-danger-500/15'
          : 'text-foreground-700 hover:bg-primary-50/70 dark:hover:bg-primary-500/15'
      }`}
    >
      {item.icon && <i className={`${item.icon} flex-shrink-0`} />}
      {item.label}
    </button>
  );

  let cursor = 0;

  return (
    <div className={`relative flex-shrink-0 ${className}`}>
      <button
        ref={anchorRef}
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setOpen((p) => !p);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Escape') setOpen(false);
        }}
        aria-label="Aksiyonlar"
        aria-haspopup="menu"
        aria-expanded={open}
        className={
          trigger
            ? 'isg-btn isg-btn-secondary'
            : 'isg-iconbtn isg-iconbtn-md text-foreground-500 hover:text-foreground-800 hover:bg-background-200'
        }
      >
        {trigger ?? <i className={triggerIcon} />}
      </button>

      <DropdownPanel
        open={open}
        anchorRef={anchorRef}
        onClose={() => setOpen(false)}
        role="menu"
        align={align}
        minWidth={minWidth}
        className="isg-popover py-1"
      >
        {sections
          ? sections.map((section, sIdx) => (
              <div key={`${section.title ?? 'sec'}-${sIdx}`} className={sIdx > 0 ? 'border-t isg-divider mt-1 pt-1' : ''}>
                {section.title && (
                  <div className="px-3 pt-2 pb-1 isg-text-caption font-semibold uppercase tracking-wide text-foreground-400">
                    {section.title}
                  </div>
                )}
                {section.items.map((item) => {
                  const node = renderItem(item, cursor);
                  cursor += 1;
                  return node;
                })}
              </div>
            ))
          : allItems.map((item) => {
              const node = renderItem(item, cursor);
              cursor += 1;
              return node;
            })}
      </DropdownPanel>
    </div>
  );
}