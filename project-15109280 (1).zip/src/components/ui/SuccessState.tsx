import Button from './Button';

interface SuccessStateProps {
  icon?: string;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void; icon?: string };
  className?: string;
}

/**
 * Global Success State — ekran-level başarı geri bildirimi (işlem tamamlandı,
 * gönderildi, oluşturuldu). Kısa/anlık başarılar için toast, ekran seviyesinde
 * kalıcı onay gereken durumlar için bu bileşen kullanılır.
 */
export default function SuccessState({
  icon = 'ri-checkbox-circle-line',
  title,
  description,
  action,
  className = '',
}: SuccessStateProps) {
  return (
    <div className={`flex flex-col items-center justify-center py-12 px-4 text-center ${className}`} role="status" aria-live="polite">
      <div aria-hidden="true" className="w-14 h-14 rounded-full bg-success-50 flex items-center justify-center mb-4">
        <i className={`${icon} text-2xl text-success-600`} />
      </div>
      <h3 className="isg-text-section text-foreground-800">{title}</h3>
      {description && <p className="mt-1 isg-text-body text-foreground-500 max-w-xs">{description}</p>}
      {action && (
        <Button variant="primary" size="sm" className="mt-4" onClick={action.onClick} leftIcon={<i className={action.icon || 'ri-arrow-right-line'} />}>
          {action.label}
        </Button>
      )}
    </div>
  );
}