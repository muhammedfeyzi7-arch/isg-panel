import { forwardRef, type InputHTMLAttributes } from 'react';

interface TcKimlikInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value'> {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  error?: string;
  helpText?: string;
  required?: boolean;
  disabled?: boolean;
  containerClassName?: string;
  leftIcon?: React.ReactNode;
}

/**
 * T.C. Kimlik No girişi — MODÜL GENELİ TEK GİRİŞ KAYNAĞI.
 *
 * Yazdıkça yalnızca rakam kabul eder ve 11 haneye kısıtlar; görünen değer her zaman
 * ham 11 haneli sayıdır ("12345678901"). Tüm paneller (OSGB / Firma / Uzman / Hekim)
 * ve Yönetim sihirbazları bu bileşeni kullanır; böylece maske/uzunluk davranışı her
 * yerde AYNI olur. Doğrulama (11 hane kontrolü) yine merkezi `personelValidation`
 * üzerinden yapılır; bu bileşen yalnızca giriş maskesini standartlaştırır.
 */
export function formatTcKimlik(input: string): string {
  return input.replace(/\D/g, '').slice(0, 11);
}

const TcKimlikInput = forwardRef<HTMLInputElement, TcKimlikInputProps>(function TcKimlikInput(
  { label, value, onChange, error, helpText, required, disabled, containerClassName = '', leftIcon, className = '', autoComplete = 'off', ...props },
  ref
) {
  const hasError = !!error;
  const stateCls = hasError ? 'isg-input-error' : '';

  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}
      <div className="relative flex items-center">
        {leftIcon && (
          <div className="absolute left-3 text-foreground-400 pointer-events-none">{leftIcon}</div>
        )}
        <input
          ref={ref}
          type="text"
          inputMode="numeric"
          autoComplete={autoComplete}
          value={value}
          onChange={(e) => onChange(formatTcKimlik(e.target.value))}
          maxLength={11}
          placeholder="12345678901"
          disabled={disabled}
          className={`isg-input w-full tabular-nums ${leftIcon ? 'pl-10' : ''} ${stateCls} ${
            disabled ? 'opacity-50 cursor-not-allowed' : ''
          } ${className}`}
          {...props}
        />
      </div>
      {hasError && (
        <p className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p className="isg-form-help">{helpText}</p>
      )}
    </div>
  );
});

export default TcKimlikInput;