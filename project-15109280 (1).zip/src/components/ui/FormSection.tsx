import type { ReactNode } from 'react';

interface FormSectionProps {
  icon: string;
  title: string;
  subtitle?: string;
  /**
   * Verilirse başlık ikonu yerine numaralı adım rozeti gösterilir (referans
   * tasarımdaki "1 / 2 / 3" bölüm başlıkları). Verilmezse mevcut ikon kutusu
   * kullanılır — tüm mevcut çağrı noktaları değişmeden çalışır.
   */
  step?: number;
  /** Başlığın sağına yerleştirilecek aksiyon(lar) (ör. Düzenle / Kaydet / Vazgeç). */
  headerRight?: ReactNode;
  children: ReactNode;
}

/**
 * Ortak form bölüm kartı — başlık ikonu + başlık + açıklama ve altında içerik.
 * Firma Ekle/Düzenle ve diğer form modalleri bu TEK bileşeni kullanır
 * (sayfaya özel kopya yazılmaz).
 */
export default function FormSection({ icon, title, subtitle, step, headerRight, children }: FormSectionProps) {
  return (
    <div className="isg-section isg-card-pad">
      <div className="flex items-center gap-3 mb-4">
        {typeof step === 'number' ? (
          <div className="w-9 h-9 rounded-full bg-primary-500 text-inverse flex items-center justify-center flex-shrink-0 text-sm font-semibold">
            {step}
          </div>
        ) : (
          <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className={`${icon} text-primary-600 dark:text-primary-400 text-base`} />
          </div>
        )}
        <div className="min-w-0 flex-1">
          <h4 className="isg-text-card-title text-foreground-800">{title}</h4>
          {subtitle && <p className="isg-text-caption text-foreground-500 mt-0.5">{subtitle}</p>}
        </div>
        {headerRight && <div className="flex items-center gap-2 flex-shrink-0">{headerRight}</div>}
      </div>
      {children}
    </div>
  );
}