import { useMemo, useState } from 'react';

interface CalendarMarker {
  /** 'YYYY-MM-DD' */
  date: string;
  /** Remix Icon class'ı, örn. "ri-circle-fill". */
  icon?: string;
  /** Nokta rengi (Tailwind text rengi class'ı). */
  className?: string;
}

interface CalendarProps {
  /** Seçili tarih 'YYYY-MM-DD'. */
  value?: string;
  onChange?: (date: string) => void;
  /** Ay başlığını açılışta göstermek için 'YYYY-MM-DD'; verilmezse value/bugün. */
  initialMonth?: string;
  min?: string;
  max?: string;
  markers?: CalendarMarker[];
  /** Sağ üstte "Bugün" butonunu göster. */
  showTodayButton?: boolean;
  className?: string;
}

const WEEKDAYS = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
const MONTHS = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
];

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

function toISO(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function parseISO(v?: string): Date | null {
  if (!v) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(v);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  return Number.isNaN(d.getTime()) ? null : d;
}

function startOfDay(d: Date): number {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
}

/**
 * GLOBAL TAKVİM (Shared UI tek kaynak).
 * Dashboard / panel / referans ekranlarındaki takvimlerde kullanılan ortak ay
 * ızgarası. İşlevsel takvim seçimi DatePicker'da; bu bileşen GÖRÜNÜRLÜK ve
 * seçim için merkezî takvim görünümüdür. Aynı token'ları, aynı hücre ve seçili
 * gün dilini paylaşır; sayfa bazında ayrı takvim stili üretilmez.
 */
export default function Calendar({
  value,
  onChange,
  initialMonth,
  min,
  max,
  markers = [],
  showTodayButton = true,
  className = '',
}: CalendarProps) {
  const selected = parseISO(value);
  const [viewMonth, setViewMonth] = useState<Date>(() => parseISO(initialMonth) ?? selected ?? new Date());

  const minDate = parseISO(min);
  const maxDate = parseISO(max);
  const today = new Date();

  const cells = useMemo(() => {
    const y = viewMonth.getFullYear();
    const m = viewMonth.getMonth();
    const firstWeekday = (new Date(y, m, 1).getDay() + 6) % 7; // Pazartesi = 0
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const prevMonthDays = new Date(y, m, 0).getDate();
    const arr: { date: Date; inMonth: boolean; iso: string }[] = [];
    for (let i = firstWeekday - 1; i >= 0; i -= 1) {
      const date = new Date(y, m - 1, prevMonthDays - i);
      arr.push({ date, inMonth: false, iso: toISO(date) });
    }
    for (let d = 1; d <= daysInMonth; d += 1) {
      const date = new Date(y, m, d);
      arr.push({ date, inMonth: true, iso: toISO(date) });
    }
    let next = 1;
    while (arr.length < 42) {
      const date = new Date(y, m + 1, next);
      arr.push({ date, inMonth: false, iso: toISO(date) });
      next += 1;
    }
    return arr.slice(0, 42);
  }, [viewMonth]);

  const isDisabledDay = (d: Date): boolean => {
    const t = startOfDay(d);
    if (minDate && t < startOfDay(minDate)) return true;
    if (maxDate && t > startOfDay(maxDate)) return true;
    return false;
  };

  const shiftMonth = (delta: number) => {
    setViewMonth((prev) => new Date(prev.getFullYear(), prev.getMonth() + delta, 1));
  };

  const markerMap = useMemo(() => {
    const map = new Map<string, CalendarMarker[]>();
    markers.forEach((mk) => {
      const list = map.get(mk.date) ?? [];
      list.push(mk);
      map.set(mk.date, list);
    });
    return map;
  }, [markers]);

  const headerButton = 'w-7 h-7 flex items-center justify-center rounded-md border border-background-300/60 dark:border-background-400/40 text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer';

  return (
    <div className={`isg-section p-3 ${className}`}>
      <div className="flex items-center justify-between mb-3">
        <span className="isg-text-card-title text-foreground-900 select-none">
          {MONTHS[viewMonth.getMonth()]} {viewMonth.getFullYear()}
        </span>
        <div className="flex items-center gap-1">
          <button type="button" onClick={() => shiftMonth(-1)} aria-label="Önceki ay" className={headerButton}>
            <i className="ri-arrow-left-s-line" />
          </button>
          <button type="button" onClick={() => shiftMonth(1)} aria-label="Sonraki ay" className={headerButton}>
            <i className="ri-arrow-right-s-line" />
          </button>
          {showTodayButton && (
            <button
              type="button"
              onClick={() => { setViewMonth(new Date()); onChange?.(toISO(new Date())); }}
              className="isg-btn isg-btn-secondary isg-btn-sm ml-1"
            >
              Bugün
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-7 gap-0.5 mb-1">
        {WEEKDAYS.map((w) => (
          <span key={w} className="h-7 flex items-center justify-center isg-text-caption font-medium text-foreground-500 select-none">
            {w}
          </span>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-0.5">
        {cells.map((c) => {
          const isSelected = selected ? toISO(selected) === c.iso : false;
          const isToday = toISO(today) === c.iso;
          const dayDisabled = isDisabledDay(c.date);
          const dayMarkers = markerMap.get(c.iso) ?? [];
          return (
            <button
              key={c.iso}
              type="button"
              disabled={dayDisabled}
              onClick={() => !dayDisabled && onChange?.(c.iso)}
              className={`relative h-9 rounded-md isg-text-caption flex items-center justify-center transition-colors cursor-pointer ${
                isSelected
                  ? 'bg-primary-500 text-inverse font-semibold'
                  : dayDisabled
                  ? 'text-foreground-300 dark:text-foreground-500/40 cursor-not-allowed'
                  : c.inMonth
                  ? 'text-foreground-800 hover:bg-primary-50 dark:hover:bg-primary-500/15'
                  : 'text-foreground-400 hover:bg-background-200 dark:hover:bg-background-300/40'
              } ${isToday && !isSelected ? 'text-primary-600 font-medium ring-1 ring-primary-300/60' : ''}`}
            >
              {c.date.getDate()}
              {dayMarkers.length > 0 && (
                <span className="absolute bottom-1 left-1/2 -translate-x-1/2 flex items-center gap-0.5">
                  {dayMarkers.slice(0, 3).map((mk, i) => (
                    <i key={i} className={`${mk.icon || 'ri-circle-fill'} text-[7px] ${mk.className || 'text-foreground-400'}`} />
                  ))}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}