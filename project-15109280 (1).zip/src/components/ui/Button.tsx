import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'danger' | 'success' | 'warning' | 'link' | 'icon';
  size?: 'xs' | 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  fullWidth?: boolean;
}

/**
 * Global Button — tüm panel/sekme/listelerde TEK button standardı.
 * Varyantlar: primary / secondary / outline / ghost / danger / success / link.
 *
 * Durum standardı (Shared UI tek kaynak):
 * - Hover/Active: yalnızca renk değişir, layout kaymaz (bkz. .isg-btn:active).
 * - Disabled: `.isg-btn:disabled` — tüm varyantlarda ortak, net biçimde soluk.
 * - Loading: içerik görünmez yapılır ama YERİ KORUNUR, spinner mutlak konumlanır
 *   → buton genişliği/yüksekliği loading geçişinde DEĞİŞMEZ (layout shift yok).
 */
const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', size = 'md', isLoading, leftIcon, rightIcon, fullWidth, children, className = '', disabled, ...props },
  ref
) {
  const base = 'isg-btn';
  const sizeCls = size === 'xs' ? 'isg-btn-xs' : size === 'sm' ? 'isg-btn-sm' : size === 'lg' ? 'isg-btn-lg' : '';
  const widthCls = fullWidth ? 'w-full' : '';

  const variantCls = {
    primary: 'isg-btn-primary',
    secondary: 'isg-btn-secondary',
    outline: 'isg-btn-outline',
    danger: 'isg-btn-danger',
    success: 'isg-btn-success',
    warning: 'isg-btn-warning',
    ghost: 'isg-btn-ghost',
    link: 'isg-btn-link',
    icon: 'isg-btn-icon',
  }[variant];

  const isDisabled = disabled || isLoading;

  return (
    <button
      ref={ref}
      className={`${base} ${variantCls} ${sizeCls} ${widthCls} ${isLoading ? 'cursor-wait' : ''} ${className}`}
      disabled={isDisabled}
      aria-busy={isLoading || undefined}
      {...props}
    >
      <span className={`isg-btn-content ${isLoading ? 'invisible' : ''}`}>
        {leftIcon}
        {children}
        {rightIcon}
      </span>
      {isLoading && (
        <span className="absolute inset-0 flex items-center justify-center" aria-hidden="true">
          <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
        </span>
      )}
    </button>
  );
});

export default Button;