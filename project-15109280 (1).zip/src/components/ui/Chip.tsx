import type { ReactNode } from 'react';

interface ChipProps {
  children: ReactNode;
  /** Opsiyonel sol ikon (remix ikon sınıfı ya da node). */
  icon?: ReactNode;
  /** Verilirse sağda "kaldır" (×) düğmesi gösterilir. */
  onRemove?: () => void;
  className?: string;
  /** "Kaldır" düğmesinin erişilebilirlik etiketi. */
  removeLabel?: string;
}

/**
 * GLOBAL CHIP / TAG — Shared UI tek kaynak.
 *
 * Seçilmiş etiketler, kapsam maddeleri, ekip üyeleri, doküman listeleri gibi
 * "yapıştırılabilir-kaldırılabilir" küçük etiket kutularının TEK kaynağıdır.
 * Geometri/tipografi/renk tamamen merkezi token'lardan gelir (Light ve Dark
 * aynı kuralları paylaşır); sayfa/modül kendi chip stilini ÜRETMEZ.
 *
 * Risk sihirbazı (Acil/Eğitim/Çalışma/Fine-Kinney/HAZOP) ve tüm diğer modüller
 * serbestçe kendi görsel chip versiyonunu oluşturamaz; bu bileşeni kullanır.
 */
export default function Chip({ children, icon, onRemove, className = '', removeLabel = 'Kaldır' }: ChipProps) {
  return (
    <span className={`isg-chip ${className}`}>
      {icon}
      {children}
      {onRemove && (
        <button
          type="button"
          onClick={onRemove}
          className="isg-chip-remove"
          aria-label={removeLabel}
        >
          <i className="ri-close-line" />
        </button>
      )}
    </span>
  );
}