import type { ReactNode } from 'react';
import type { SegmentTone } from './SegmentedControl';

export type StatusTone = 'success' | 'danger' | 'warning' | 'info' | 'neutral';

interface StatusBadgeProps {
  children: ReactNode;
  /** Doğrudan ton verilirse kullanılır. Verilmezse `status` metninden türetilir. */
  tone?: StatusTone;
  /**
   * İş durumu metni. Verilirse ilgili semantik tona eşlenir (Türkçe + yaygın
   * İngilizce karşılıklar). Böylece her modül kendi badge rengini YAZMAZ.
   */
  status?: string;
  icon?: ReactNode;
  className?: string;
}

/**
 * GLOBAL SEMANTİK DURUM ROZETİ — Shared UI tek kaynak.
 *
 * Uygun / Uygunsuz / Açık / Kapalı / Bekliyor / Tamamlandı / Devam Ediyor /
 * Onay Bekliyor ... TÜM iş durumları TEK semantic tone sistemini kullanır
 * (success / danger / warning / info / neutral). Renkler token'dan gelir
 * (`.isg-status`), Light/Dark otomatik doğru okunur. Sayfaya özel durum
 * rozeti CSS'i ÜRETİLMEZ.
 */
const TONE_RULES: { tone: StatusTone; match: RegExp }[] = [
  { tone: 'success', match: /(uygun$|tamam|kapal|onayl|aktif|ba[sş]ar|ge[çc]erli|tamamland|done|approved|active|closed|success|ok)/i },
  { tone: 'danger', match: /(uygunsuz|red|iptal|hata|ge[çc]ersiz|pasif|a[çc][ıi]k?$|fail|error|reject|invalid|inactive|open)/i },
  { tone: 'warning', match: /(bekliyor|onay bek|k[ıi]smen|uyar[ıi]|gecik|ask[ıi]da|beklemed|warning|pending|partial|expired)/i },
  { tone: 'info', match: /(devam|i[şs]lemde|yeni|bilgi|in progress|info|new)/i },
];

function deriveTone(status: string): StatusTone {
  for (const rule of TONE_RULES) {
    if (rule.match.test(status)) return rule.tone;
  }
  return 'neutral';
}

export default function StatusBadge({ children, tone, status, icon, className = '' }: StatusBadgeProps) {
  const resolved: StatusTone = tone ?? (status ? deriveTone(status) : 'neutral');
  return (
    <span className={`isg-status ${className}`} data-tone={resolved}>
      {icon}
      {children}
    </span>
  );
}

/** SegmentTone → StatusTone eşlemesi (durum kontrolleriyle tutarlılık için). */
export function segmentToStatusTone(tone: SegmentTone): StatusTone {
  if (tone === 'primary') return 'info';
  if (tone === 'success' || tone === 'danger' || tone === 'warning') return tone;
  return 'neutral';
}