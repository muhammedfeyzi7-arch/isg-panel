import { useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import Button from './Button';
import Select from './Select';
import MultiSelect from './MultiSelect';
import Search from './Search';
import DatePicker from './DatePicker';
import Badge from './Badge';
import MobileFilterSheet from './MobileFilterSheet';
import { useMediaQuery } from '@/hooks/useMediaQuery';

export type FilterFieldType =
  | 'select'
  | 'date'
  | 'text'
  | 'multi-select'
  | 'status'
  | 'date-range';

export type FilterValue = string | string[] | { from: string; to: string };

export interface FilterField {
  key: string;
  label: string;
  type: FilterFieldType;
  options?: { value: string; label: string }[];
  placeholder?: string;
}

interface FilterBarProps {
  filters: FilterField[];
  values: Record<string, FilterValue>;
  onChange: (key: string, value: FilterValue) => void;
  onReset: () => void;
  onSearch: (query: string) => void;
  searchPlaceholder?: string;
  searchDebounceMs?: number;
  /** Arama kutusuna yazılacak başlangıç değeri (ör. sekmeler arası geçişte). */
  initialSearch?: string;
  className?: string;
}

interface FilterChip {
  key: string;
  label: string;
  valueLabel: string;
  onRemove: () => void;
}

function isActiveValue(v: FilterValue | undefined): boolean {
  if (v === undefined || v === null) return false;
  if (typeof v === 'string') return v !== '';
  if (Array.isArray(v)) return v.length > 0;
  return !!(v.from || v.to);
}

function asString(v: FilterValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

function asArray(v: FilterValue | undefined): string[] {
  return Array.isArray(v) ? v : [];
}

function asRange(v: FilterValue | undefined): { from: string; to: string } {
  return v && typeof v === 'object' && !Array.isArray(v) ? v : { from: '', to: '' };
}

function emptyValueFor(type: FilterFieldType): FilterValue {
  if (type === 'multi-select') return [];
  if (type === 'date-range') return { from: '', to: '' };
  return '';
}

function withAllOption(options?: { value: string; label: string }[]): { value: string; label: string }[] {
  const hasEmpty = (options || []).some((o) => o.value === '');
  return hasEmpty ? (options || []) : [{ value: '', label: 'Tümü' }, ...(options || [])];
}

/**
 * Ortak Filter Motoru — tüm listeleme ekranlarında aynı filter UI kullanılır.
 * text, select, multi-select, status, date ve date-range filtre tiplerini destekler.
 *
 * - Arama yazarken CANLI olarak üst listeye bildirilir (Enter gerekmez).
 * - Her aktif filtre, altındaki çip listesinden TEK TEK kaldırılabilir.
 * - select/status filtreleri "Tümü" seçeneği ile tek başına sıfırlanabilir.
 *
 * MOBİL (Shared UI tek kaynak): Büyük filtre çubuğu ekranda SÜREKLİ görünmez.
 * Kompakt bir arama alanı + filtre ikonu (aktif filtre sayısı badge'i ile) kalır;
 * ikona basınca `MobileFilterSheet` alttan açılır. Desktop davranışı AYNEN korunur.
 */
export default function FilterBar({
  filters,
  values,
  onChange,
  onReset,
  onSearch,
  searchPlaceholder,
  searchDebounceMs = 300,
  initialSearch,
  className = '',
}: FilterBarProps) {
  const [searchQuery, setSearchQuery] = useState(initialSearch ?? '');
  const [sheetOpen, setSheetOpen] = useState(false);
  const isMobile = useMediaQuery('(max-width: 1023px)');

  const activeFilterCount = useMemo(
    () => filters.filter((f) => isActiveValue(values[f.key])).length,
    [filters, values],
  );

  const activeChips = useMemo<FilterChip[]>(() => {
    const chips: FilterChip[] = [];
    filters.forEach((filter) => {
      const v = values[filter.key];
      if (!isActiveValue(v)) return;

      if (Array.isArray(v)) {
        v.forEach((val) => {
          const opt = filter.options?.find((o) => o.value === val);
          chips.push({
            key: `${filter.key}:${val}`,
            label: filter.label,
            valueLabel: opt?.label ?? val,
            onRemove: () => onChange(filter.key, v.filter((x) => x !== val)),
          });
        });
        return;
      }

      if (typeof v === 'object' && v !== null) {
        const range = v as { from: string; to: string };
        chips.push({
          key: filter.key,
          label: filter.label,
          valueLabel: `${range.from || '…'} — ${range.to || '…'}`,
          onRemove: () => onChange(filter.key, emptyValueFor(filter.type)),
        });
        return;
      }

      const opt = filter.options?.find((o) => o.value === v);
      chips.push({
        key: filter.key,
        label: filter.label,
        valueLabel: opt?.label ?? String(v),
        onRemove: () => onChange(filter.key, emptyValueFor(filter.type)),
      });
    });
    return chips;
  }, [filters, values, onChange]);

  const hasActiveFilters = activeFilterCount > 0 || searchQuery !== '';

  const handleReset = () => {
    onReset();
    setSearchQuery('');
  };

  /** Tek filtre alanının kontrolü — desktop inline ve mobil sheet AYNI kaynağı kullanır. */
  const renderField = (filter: FilterField): ReactNode => {
    if (filter.type === 'select' || filter.type === 'status') {
      return (
        <Select
          size="sm"
          placeholder={filter.placeholder || filter.label}
          options={withAllOption(filter.options)}
          value={asString(values[filter.key])}
          onChange={(e) => onChange(filter.key, e.target.value)}
        />
      );
    }

    if (filter.type === 'multi-select') {
      return (
        <MultiSelect
          size="sm"
          placeholder={filter.placeholder || filter.label}
          options={filter.options || []}
          value={asArray(values[filter.key])}
          onChange={(vals) => onChange(filter.key, vals)}
          searchable
        />
      );
    }

    if (filter.type === 'date') {
      return (
        <DatePicker
          aria-label={filter.label}
          containerClassName="w-full"
          className="isg-input-sm"
          placeholder={filter.placeholder || 'Tarih'}
          value={asString(values[filter.key])}
          onChange={(e) => onChange(filter.key, e.target.value)}
        />
      );
    }

    if (filter.type === 'date-range') {
      return (
        <div className="flex items-center gap-1 min-w-0">
          <DatePicker
            aria-label={`${filter.label} başlangıç`}
            containerClassName="flex-1 min-w-0"
            className="isg-input-sm"
            placeholder="Başlangıç"
            value={asRange(values[filter.key]).from}
            onChange={(e) =>
              onChange(filter.key, {
                ...asRange(values[filter.key]),
                from: e.target.value,
              })
            }
          />
          <span className="text-foreground-400 text-xs flex-shrink-0">—</span>
          <DatePicker
            aria-label={`${filter.label} bitiş`}
            containerClassName="flex-1 min-w-0"
            className="isg-input-sm"
            placeholder="Bitiş"
            value={asRange(values[filter.key]).to}
            onChange={(e) =>
              onChange(filter.key, {
                ...asRange(values[filter.key]),
                to: e.target.value,
              })
            }
          />
        </div>
      );
    }

    if (filter.type === 'text') {
      return (
        <input
          type="text"
          aria-label={filter.label}
          className="isg-input isg-input-sm w-full"
          value={asString(values[filter.key])}
          onChange={(e) => onChange(filter.key, e.target.value)}
          placeholder={filter.placeholder || filter.label}
        />
      );
    }

    return null;
  };

  const chipsNode = activeChips.length > 0 ? (
    <div className="flex flex-wrap items-center gap-1.5">
      {activeChips.map((chip) => (
        <span
          key={chip.key}
          className="inline-flex items-center gap-1 pl-2 pr-1 py-0.5 max-w-full bg-secondary-100 dark:bg-secondary-500/20 text-secondary-800 dark:text-secondary-300 text-xs rounded-full"
        >
          <span className="font-medium whitespace-nowrap">{chip.label}:</span>
          <span className="max-w-[160px] truncate">{chip.valueLabel}</span>
          <button
            type="button"
            onClick={chip.onRemove}
            aria-label={`${chip.label} filtresini kaldır`}
            className="w-4 h-4 flex items-center justify-center hover:text-secondary-600 dark:hover:text-secondary-900 cursor-pointer flex-shrink-0"
          >
            <i className="ri-close-line" />
          </button>
        </span>
      ))}
    </div>
  ) : null;

  // ── MOBİL: kompakt arama + filtre ikonu (badge) → bottom sheet ──
  if (isMobile) {
    return (
      <div className={`flex flex-col gap-2 ${className}`}>
        <div className="flex items-center gap-2">
          <div className="flex-1 min-w-0">
            <Search
              placeholder={searchPlaceholder || 'Ara...'}
              value={searchQuery}
              onChange={(v) => setSearchQuery(v)}
              onSearch={onSearch}
              size="sm"
              debounceMs={searchDebounceMs}
            />
          </div>
          <button
            type="button"
            onClick={() => setSheetOpen(true)}
            aria-label="Filtreler"
            className={`relative isg-iconbtn isg-iconbtn-md border flex-shrink-0 transition-colors cursor-pointer ${
              activeFilterCount > 0
                ? 'bg-primary-500 text-inverse border-primary-500'
                : 'bg-background-100 dark:bg-background-200 text-foreground-600 border-background-300/70 dark:border-background-400/40'
            }`}
          >
            <i className="ri-filter-3-line text-lg" />
            {activeFilterCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 px-1 flex items-center justify-center rounded-full bg-danger-500 text-inverse isg-text-nano font-bold">
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>

        {chipsNode}

        {sheetOpen && (
          <MobileFilterSheet
            filters={filters}
            onReset={handleReset}
            onClose={() => setSheetOpen(false)}
            renderField={renderField}
            activeCount={activeFilterCount}
          />
        )}
      </div>
    );
  }

  // ── DESKTOP: mevcut davranış AYNEN korunur ──
  return (
    <div
      className={`flex flex-col gap-2 p-2.5 bg-background-50 dark:bg-background-100/70 rounded-lg border border-background-300/70 dark:border-background-400/40 ${className}`}
    >
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex-1 min-w-[200px]">
          <Search
            placeholder={searchPlaceholder || 'Ara...'}
            value={searchQuery}
            onChange={(v) => setSearchQuery(v)}
            onSearch={onSearch}
            size="sm"
            debounceMs={searchDebounceMs}
          />
        </div>

        {filters.map((filter) => (
          <div
            key={filter.key}
            className={
              filter.type === 'multi-select'
                ? 'min-w-[160px] flex-1 max-w-[220px]'
                : 'min-w-[130px] flex-1 max-w-[200px]'
            }
          >
            {renderField(filter)}
          </div>
        ))}

        {hasActiveFilters && (
          <div className="flex items-center gap-2">
            {activeFilterCount > 0 && (
              <Badge variant="info">{activeFilterCount} filtre</Badge>
            )}
            <Button variant="ghost" size="sm" onClick={handleReset}>
              <i className="ri-close-line" />
              Sıfırla
            </Button>
          </div>
        )}
      </div>

      {chipsNode}
    </div>
  );
}