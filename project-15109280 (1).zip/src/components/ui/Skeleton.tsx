import type { ReactNode } from 'react';

/**
 * MERKEZİ İSKELET (SKELETON) SİSTEMİ — Shared UI tek kaynak.
 *
 * Amaç: Modal/panel içeriği yüklenirken kullanıcıya "yükleniyor..." metni yerine
 * içeriğin GERÇEK düzenini taklit eden nötr bir iskelet göstermek. Böylece:
 *  - Ekran "boş + yazı" yerine dolu görünür (algılanan hız artar).
 *  - Layout yüklenmede zıplamaz; içerik gelince yerine oturur.
 *  - Tüm renkler tema token'larından gelir (light/dark uyumlu).
 *
 * KURAL: İskelet yalnızca GÖRSEL bir yer tutucudur; veri/iş mantığı içermez.
 */

interface SkeletonProps {
  className?: string;
}

/** Temel iskelet bloğu. Boyut `className` ile verilir (w-/h-). */
export function Skeleton({ className = '' }: SkeletonProps) {
  return (
    <div
      aria-hidden="true"
      className={`animate-pulse rounded-md bg-background-200 dark:bg-background-300/40 ${className}`}
    />
  );
}

/** Çok satırlı metin iskeleti. */
export function SkeletonText({ lines = 3, className = '' }: { lines?: number; className?: string }) {
  return (
    <div className={`space-y-2 ${className}`} aria-hidden="true">
      {Array.from({ length: lines }).map((_, i) => (
        <Skeleton key={i} className={`h-3 ${i === lines - 1 ? 'w-2/3' : 'w-full'}`} />
      ))}
    </div>
  );
}

/** Alan etiketi + değer ikilisi iskeleti (detay form alanları için). */
export function SkeletonField({ className = '' }: SkeletonProps) {
  return (
    <div className={`space-y-1.5 ${className}`} aria-hidden="true">
      <Skeleton className="h-2.5 w-20" />
      <Skeleton className="h-8 w-full" />
    </div>
  );
}

/** Kart iskeleti — başlık + gövde blokları. */
export function SkeletonCard({ title = true, lines = 3 }: { title?: boolean; lines?: number }) {
  return (
    <div className="rounded-lg border border-background-200/70 dark:border-background-400/20 bg-background-100 dark:bg-background-200/40 p-3">
      {title && <Skeleton className="h-3.5 w-28 mb-3" />}
      <SkeletonText lines={lines} />
    </div>
  );
}

/** Liste/satır iskeleti (tablo veya kayıt listesi yer tutucusu). */
export function ListSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="space-y-2" aria-hidden="true">
      {Array.from({ length: rows }).map((_, i) => (
        <div key={i} className="flex items-center gap-3 p-3 rounded-xl border border-background-200/70 dark:border-background-400/20">
          <Skeleton className="w-10 h-10 rounded-lg flex-shrink-0" />
          <div className="flex-1 min-w-0 space-y-2">
            <Skeleton className="h-3.5 w-1/3" />
            <Skeleton className="h-3 w-2/3" />
          </div>
          <Skeleton className="h-6 w-16 rounded-full flex-shrink-0" />
        </div>
      ))}
    </div>
  );
}

/**
 * Modal gövdesi iskeleti. Ağır modal CHUNK'ı (Suspense fallback) veya modal verisi
 * ilk kez yüklenirken kullanılır. `variant` içeriğin genel şeklini belirler.
 */
export function ModalSkeleton({ variant = 'detail', label }: { variant?: 'detail' | 'form' | 'list'; label?: ReactNode }) {
  return (
    <div className="p-1 space-y-4" role="status" aria-live="polite" aria-label={typeof label === 'string' ? label : 'Yükleniyor'}>
      {/* Üst başlık / özet şeridi */}
      <div className="flex items-center gap-3">
        <Skeleton className="w-12 h-12 rounded-lg flex-shrink-0" />
        <div className="flex-1 min-w-0 space-y-2">
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-3 w-1/2" />
        </div>
        <Skeleton className="h-8 w-24 rounded-md flex-shrink-0" />
      </div>

      {variant === 'list' ? (
        <ListSkeleton rows={6} />
      ) : variant === 'form' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <SkeletonField />
          <SkeletonField />
          <SkeletonField />
          <SkeletonField />
          <SkeletonField className="sm:col-span-2" />
          <SkeletonField className="sm:col-span-2" />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          <SkeletonCard lines={4} />
          <div className="space-y-3">
            <SkeletonCard lines={3} />
            <SkeletonCard lines={4} />
          </div>
          <div className="space-y-3">
            <SkeletonCard lines={3} />
            <SkeletonCard lines={5} />
          </div>
        </div>
      )}

      {/* Sekme şeridi iskeleti (detay varyantı) */}
      {variant === 'detail' && (
        <div className="flex items-center gap-2">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-8 w-24 rounded-full" />
          ))}
        </div>
      )}
    </div>
  );
}

export default Skeleton;