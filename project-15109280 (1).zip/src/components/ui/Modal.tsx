import { useRef, useEffect, useLayoutEffect, useCallback, useState, useMemo } from 'react';
import { useModalActions } from '@/hooks/useModal';
import { useConfirmActions } from '@/hooks/useConfirm';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import WizardStepper from './WizardStepper';
import { Z_LAYERS } from '@/utils/layers';
import {
  scaleByDensity,
  resolveModalWidth,
  resolveModalHeight,
  resolveDefaultModalHeight,
  isWideContentModal,
  resolveWideContentSize,
  MODAL_SIZE_PRESETS as SIZE_PRESETS,
  MODAL_VARIANT_DEFAULT_PRESET as VARIANT_DEFAULT_PRESET,
} from '@/lib/uiDensity';
import type { ModalOptions, WizardStep } from '@/hooks/useModal';

interface ModalWindowProps {
  modal: ModalOptions;
  isActive: boolean;
  minimized: boolean;
  minimizedIndex?: number;
  /** Ekranda duran modaller arasındaki görsel stack sırası (0 = en altta). */
  stackIndex?: number;
}

/** Stack offset adımı (px) ve en fazla kaç seviye offset uygulanacağı. */
const STACK_OFFSET_STEP = 28;
const STACK_OFFSET_MAX_LEVELS = 3;

// NOT: Modal boyut presetleri artık TEK KAYNAK olarak `@/lib/uiDensity`'de
// tanımlıdır (SIZE_PRESETS / VARIANT_DEFAULT_PRESET alias ile içe alınır).

const FOCUSABLE = 'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
const DROPDOWN_SELECTOR = '[role="listbox"], [role="combobox"], [role="option"], [role="menu"], [role="menuitem"], [aria-haspopup]';

const HEADER_KEEP = 48;
const EDGE_KEEP = 120;

/**
 * VIEWPORT GÜVENLİ BOŞLUĞU — Shared UI tek kaynak.
 * Bir standart modal hiçbir yönde browser viewport'unun dışına taşamaz:
 * içerik viewport'tan büyük olsa bile modal viewport'a SIĞAR ve yalnızca
 * BODY alanı dikey kaydırılır (header/footer sabit kalır). Bu, "modal
 * ekranın altına taşıyor / açılışta altta kalıyor / içerik kesiliyor"
 * durumunun merkezî çözümüdür. `fullscreen` ve maximize bundan muaftır.
 * KESİNLİKLE transform/zoom/scale DEĞİLDİR; gerçek viewport sınırıdır.
 */
const MODAL_VIEWPORT_V_MARGIN = 24; // üst + alt toplam 48px
const MODAL_VIEWPORT_H_MARGIN = 12; // sol + sağ toplam 24px

/** Modalın ulaşabileceği en büyük yükseklik (px). */
function viewportMaxHeight(): number {
  if (typeof window === 'undefined') return 720;
  return Math.max(240, window.innerHeight - MODAL_VIEWPORT_V_MARGIN * 2);
}

/** Modalın ulaşabileceği en büyük genişlik (px). */
function viewportMaxWidth(): number {
  if (typeof window === 'undefined') return 1080;
  return Math.max(280, window.innerWidth - MODAL_VIEWPORT_H_MARGIN * 2);
}

/**
 * Maximize durumunda modal viewport'a eşit dış boşluk bırakarak yerleşir.
 * SOL = SAĞ ve ÜST = ALT olacak şekilde dengeli margin kullanılır.
 * Topbar / sidebar modalı KISITLAMAZ — koordinat sistemi tam browser viewport'tur.
 */
const MAXIMIZE_MARGIN = 12;

/**
 * Minimize edilen modal sağ altta dock edilir.
 * Birden fazla minimize edilmiş modal aynı sağ hizayı paylaşarak alttan üste dikey stack olur.
 */
const MINIMIZED_WIDTH = 240;
const MINIMIZED_HEIGHT = 44;
const DOCK_MARGIN = 16;
const DOCK_GAP = 8;

type ResizeDir = 'n' | 's' | 'e' | 'w' | 'ne' | 'nw' | 'se' | 'sw';

interface DragState {
  startX: number;
  startY: number;
  baseLeft: number;
  baseTop: number;
}

interface ResizeState {
  startX: number;
  startY: number;
  baseW: number;
  baseH: number;
  baseLeft: number;
  baseTop: number;
  dir: ResizeDir;
}

interface PreMaximize {
  left: number;
  top: number;
  width: number;
  height: number | 'auto';
  freeMode: boolean;
}

/**
 * Minimize öncesi modalın gerçek durumu. Dock koordinatından tamamen bağımsızdır.
 * Restore edilirken modal bu state'e (NORMAL veya MAXIMIZED) geri döner.
 */
interface PreMinimize {
  left: number;
  top: number;
  width: number;
  height: number | 'auto';
  maximized: boolean;
  freeMode: boolean;
}

interface StateSnapshot {
  width: number;
  height: number | 'auto';
  left: number;
  top: number;
  modalMinWidth: number;
  modalMinHeight: number;
}

/**
 * Modal hareket alanı = browser viewport'un TAMAMI.
 * Topbar ve sidebar modalı SINIRLANDIRMAZ. Bu yüzden `main` elementine bakılmaz,
 * doğrudan viewport kullanılır. Document flow / sayfa scroll'u modal konumunu etkilemez.
 */
function getWorkspaceBounds() {
  return {
    left: 0,
    top: 0,
    width: window.innerWidth,
    height: window.innerHeight,
  };
}

/**
 * MODAL AÇILIŞ BOYUTU (Shared UI tek kaynak) — öncelik sırası:
 *  1) `fullscreen` / `size: 'full'` → neredeyse tam ekran.
 *  2) GENİŞ-İÇERİK modali (`isWideContentModal`) → viewport'un ~%95'i
 *     (genişlik + yükseklik). Bu, Firma Detayı gibi içerik yoğun ekranların
 *     standart açılış davranışıdır ve 5 panelin TAMAMINA tek merkezden uygulanır.
 *  3) Aksi halde açık `size`/`width` > `variant` varsayılanı > genel `md`;
 *     içeriği az olan kompakt modaller kontrollü boyutunda kalır.
 */
function resolveInitialSize(modal: ModalOptions) {
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const maxW = viewportMaxWidth();
  const maxH = viewportMaxHeight();

  if (modal.variant === 'fullscreen' || modal.size === 'full') {
    return { width: Math.min(vw - 40, maxW), height: Math.min(vh - 40, maxH) };
  }

  // ── İÇERİĞE-GÖRE (CONTENT-FIT) YÜKSEKLİK (Shared UI tek kaynak) ──
  // Sayfa `height: 'auto'` verdiyse sabit/hesaplı yükseklik DAYATILMAZ. Kutu
  // içeriğin doğal yüksekliği kadar büyür; içerik azsa gereksiz boş alan
  // bırakmaz, içerik viewport güvenliğini aşarsa yalnızca GÖVDE kaydırılır
  // (dış max-height + gövde scroll sözleşmesi bunu sağlar). Bu seçenek
  // GENİŞ-İÇERİK standardını da bilinçli olarak atlar; sayfa içerik-fit istedi.
  const isAutoHeight = modal.height === 'auto';

  // ── GENİŞ-İÇERİK STANDARDI (Shared UI tek kaynak) ──
  // Geniş içerikli modaller (Firma/Personel/Envanter/Evrak detayları, büyük
  // formlar, sihirbazlar, çok-kolonlu ekranlar) masaüstünde yaklaşık %95
  // genişlik ve %95 yükseklik kullanır. Eşik altındaki kompakt modaller
  // (onay/kısa detay/küçük form) mevcut kontrollü boyutlarını KORUR; böylece
  // "içeriği az olan modallar devasa görünmesin" kuralı da merkezden sağlanır.
  // Sınıflandırma `isWideContentModal` (uiDensity) ile TEK yerden yapılır; her
  // panel ayrı bir boyut kuralı yazmaz.
  if (!isAutoHeight && isWideContentModal(modal)) {
    return resolveWideContentSize();
  }

  // Boyut önceliği: açık `size` > `variant` varsayılanı > genel `md`.
  const preset = modal.size ?? (modal.variant ? VARIANT_DEFAULT_PRESET[modal.variant] : undefined) ?? 'md';
  // ── GENİŞLİK (Shared UI tek kaynak) ──
  // Sayfanın/presetin verdiği genişlik MUTLAK tasarım px'idir (yoğunlukla
  // KÜÇÜLTÜLMEZ) ve GLOBAL GENİŞLİK TAVANI + viewport ile sınırlanır. Böylece
  // 1120 / 1200 / 1240 / 1280 / 1400 gibi sayfa-özel geniş değerler modalı
  // gereksiz büyütemez. İçerik ölçümü (scrollWidth vb.) ile genişlik BÜYÜTME
  // YAPILMAZ.
  const width = Math.min(resolveModalWidth(modal.width ?? SIZE_PRESETS[preset] ?? 520, undefined, modal.wide || modal.preserveWidth), maxW);

  // ── YÜKSEKLİK (Shared UI tek kaynak) ──
  //  1) Sabit `height` verilmişse (belge/görsel/Excel/viewer gibi özel içerikler)
  //     o değer korunur; viewport'a kırpılır.
  //  2) Aksi halde içerik ÖLÇÜLMEZ; viewport'a göre KONTROLLÜ bir yükseklik
  //     kullanılır (`resolveDefaultModalHeight`). Küçük modaller `'auto'` kalır.
  // Böylece çerçeve İLK FRAME'de sabittir; sekme/veri değişiminde geometri
  // değişmez, "katlanma" ve gereksiz büyüme oluşmaz.
  const height: number | 'auto' = isAutoHeight
    ? 'auto'
    : typeof modal.height === 'number'
      ? Math.min(resolveModalHeight(modal.height), maxH)
      : resolveDefaultModalHeight(width);

  return { width, height };
}

function clampToWorkspace(left: number, top: number, width: number, height: number | 'auto') {
  const bounds = getWorkspaceBounds();
  const h = typeof height === 'number' ? height : 400;
  const keepX = Math.min(width, EDGE_KEEP);
  const keepY = Math.min(HEADER_KEEP, h);
  return {
    left: Math.min(Math.max(left, bounds.left - (width - keepX)), bounds.left + bounds.width - keepX),
    top: Math.min(Math.max(top, bounds.top), bounds.top + bounds.height - keepY),
  };
}

function computeInitialPosition(width: number, height: number | 'auto') {
  const bounds = getWorkspaceBounds();
  const h = typeof height === 'number' ? height : 400;
  const left = bounds.left + (bounds.width - width) / 2;
  const top = bounds.top + (bounds.height - h) / 2;
  return clampToWorkspace(left, top, width, height);
}

/**
 * MODAL HER AÇILIŞTA TEMİZ BAŞLAR — kalıcı geometry hafızası YOKTUR.
 * Konum/boyut her seferinde viewport'a göre yeniden hesaplanır ve modal
 * GERÇEK viewport merkezinde açılır. Önceki oturumdan kalan top/left/width/
 * height KESİNLİKLE kullanılmaz (localStorage/IndexedDB/context persistence yok).
 */
function resolveInitialLayout(modal: ModalOptions) {
  const { width, height } = resolveInitialSize(modal);
  const { left, top } = computeInitialPosition(width, height);
  return { left, top, width, height };
}

export default function Modal({ modal, isActive, minimized, minimizedIndex = 0, stackIndex = 0 }: ModalWindowProps) {
  const { closeModal, minimizeModal, restoreModal, setActiveModal } = useModalActions();
  const { confirm } = useConfirmActions();

  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [maximized, setMaximized] = useState(false);
  // KONUM MODU (Shared UI tek kaynak):
  //   false (varsayılan) = MERKEZLİ. Konum tamamen CSS ile çözülür
  //     (left/top %50 + translate(-50%,-50%)) → modal kendi GERÇEK boyutuna
  //     göre İLK PAINT'te tam viewport merkezinde olur. Auto-height içerik
  //     (spinner→veri, font/ikon yüklenmesi) paint'ten sonra değişse bile
  //     konum ayrı bir adımda düzeltilmez → zıplama YOKTUR.
  //   true = SERBEST. Kullanıcı elle taşıdı/boyutlandırdı (veya maximize) →
  //     absolute left/top. Bu pozisyon yalnızca açık oturum içindir; modal
  //     kapanınca silinir (kalıcı geometry hafızası YOK).
  const [freeMode, setFreeMode] = useState(false);

  const initialLayout = useMemo(() => resolveInitialLayout(modal), [modal.id]);
  const [left, setLeft] = useState(initialLayout.left);
  const [top, setTop] = useState(initialLayout.top);
  const [width, setWidth] = useState<number>(initialLayout.width);
  const [height, setHeight] = useState<number | 'auto'>(initialLayout.height);

  // Kullanıcı bu modalı elle taşıdı/boyutlandırdı mı? Taşıdıysa otomatik merkezleme durur.
  const userMovedRef = useRef(false);

  // Sürükleme başladı ama henüz GERÇEK bir hareket oldu mu? Tek tıklama
  // (hareketsiz bas-bırak) modal konumunu/boyutunu DEĞİŞTİRMEMELİDİR.
  // Bu bayrak, hareket eşiği (3px) aşıldığında true olur.
  const dragMovedRef = useRef(false);

  const [stepIndex, setStepIndex] = useState(modal.initialStep ?? 0);
  const [stepError, setStepError] = useState('');

  const modalRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const scrollTopRef = useRef(0);
  const dragStateRef = useRef<DragState | null>(null);
  const resizeStateRef = useRef<ResizeState | null>(null);
  const preMaximizeRef = useRef<PreMaximize | null>(null);
  const maximizedRef = useRef(false);
  const minimizedRef = useRef(minimized);
  minimizedRef.current = minimized;
  const freeModeRef = useRef(false);
  freeModeRef.current = freeMode;

  const preMinimizeRef = useRef<PreMinimize | null>(null);
  const wasMinimizedRef = useRef(minimized);

  // MINIMIZE → RESTORE state ayırımı:
  // Minimize edilirken modalın o anki gerçek geometry'si + maximized bayrağı yakalanır.
  // Restore edilirken bu state birebir geri yüklenir. Dock koordinatı ASLA normal state'e yazılmaz.
  // Böylece "sağ altta küçük dock → büyüt" durumunda modal dock konumunda büyümez,
  // önceki normal/maximized konumuna ve boyutuna döner.
  useEffect(() => {
    if (minimized && !wasMinimizedRef.current) {
      preMinimizeRef.current = {
        left,
        top,
        width: typeof width === 'number' ? width : (modalRef.current?.getBoundingClientRect().width ?? 520),
        height,
        maximized: maximizedRef.current,
        freeMode: freeModeRef.current,
      };
    } else if (!minimized && wasMinimizedRef.current) {
      const pm = preMinimizeRef.current;
      if (pm) {
        maximizedRef.current = pm.maximized;
        setMaximized(pm.maximized);
        setLeft(pm.left);
        setTop(pm.top);
        setWidth(pm.width);
        setHeight(pm.height);
        setFreeMode(pm.freeMode);
      }
      // Scroll konumunu geri yükle — içerik display:none'dan görünür hale geçtikten sonra.
      requestAnimationFrame(() => {
        if (bodyRef.current) bodyRef.current.scrollTop = scrollTopRef.current;
      });
    }
    wasMinimizedRef.current = minimized;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [minimized]);

  const isMobile = useMediaQuery('(max-width: 1023px)');

  // ── ZERO-JUMP MERKEZLEME (Shared UI tek kaynak) ──
  // Modalın VARSAYILAN konumu artık JS ile değil CSS layout ile çözülür
  // (bkz. render'daki `isCentered` dalı: left/top %50 + translate(-50%,-50%)).
  // Bu yüzden auto-height içerik (asenkron veri, font/ikon yüklenmesi) paint
  // sonrası büyüse bile AYRI bir "yeniden merkezle" adımı YOKTUR → zıplama
  // oluşmaz; tarayıcı boyut değişimini aynı layout geçişinde simetrik uygular.
  // Burada eskiden bulunan paint-sonrası ResizeObserver+rAF recenter zinciri
  // bilinçli olarak KALDIRILDI (tek merkez kaynağı: CSS).

  const latestPointerRef = useRef<{ clientX: number; clientY: number } | null>(null);
  const rafRef = useRef<number | null>(null);
  const restoreFocusRef = useRef<HTMLElement | null>(null);
  const enterLockRef = useRef(false);
  const stateRef = useRef<StateSnapshot>({
    width: initialLayout.width,
    height: initialLayout.height,
    left: initialLayout.left,
    top: initialLayout.top,
    modalMinWidth: scaleByDensity(modal.minWidth ?? 320),
    modalMinHeight: scaleByDensity(modal.minHeight ?? 200),
  });

  stateRef.current = {
    width, height, left, top,
    modalMinWidth: Math.min(scaleByDensity(modal.minWidth ?? 320), viewportMaxWidth()),
    modalMinHeight: Math.min(scaleByDensity(modal.minHeight ?? 200), viewportMaxHeight()),
  };

  const steps = useMemo<WizardStep[]>(() => modal.steps || [], [modal.steps]);
  const isWizard = steps.length > 0;

  // ── SHARED UI — SİHİRBAZ ADIM BOYUTU (merkezi yetenek) ──
  // Aktif adım kendi `width`/`height`/`size` değerini tanımladıysa modal o adıma
  // göre boyutlanır. Kullanıcı modalı elle taşıdıysa/boyutlandırdıysa otomatik
  // boyut UYGULANMAZ (kullanıcı tercihi korunur). Yalnızca açıkça tanımlı
  // değerler uygulanır — böylece adımlar arası aşırı zıplama oluşmaz.
  // useLayoutEffect: adım boyutu değişimi PAINT ÖNCESİ uygulanır; aksi halde
  // bir kare boyunca eski boyut + yeni içerik görünüp modal "zıplar".
  useLayoutEffect(() => {
    if (isMobile) return;
    if (userMovedRef.current) return;
    const step = steps[stepIndex];
    if (!step) return;
    const nextWidth = typeof step.width === 'number'
      ? resolveModalWidth(step.width)
      : (step.size ? resolveModalWidth(SIZE_PRESETS[step.size]) : undefined);
    if (typeof nextWidth === 'number') setWidth((w) => (w === nextWidth ? w : nextWidth));
    if (typeof step.height === 'number') {
      const nextHeight = resolveModalHeight(step.height);
      setHeight((h) => (h === nextHeight ? h : nextHeight));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [stepIndex, steps, isMobile]);

  // ── GENİŞLİK ÖLÇÜMÜ YOK (Shared UI tek kaynak) ──
  // Önceden içerik `scrollWidth`'i ölçülüp modal içeriğe göre GENİŞLETİLİYORDU.
  // Bu yaklaşım gizli/lazy sekme içeriği, tablolar ve haritalar yüzünden modalı
  // gereksiz genişletiyordu. Artık genişlik YALNIZCA merkezi preset + global
  // tavan + viewport'tan gelir; içerik genişliği modal genişliğini DEĞİŞTİRMEZ.

  // ── GEOMETRY LOCK (Shared UI tek kaynak) ──
  // Modal açıldığı anda dış geometrisi (genişlik + yükseklik) merkezi preset +
  // global tavan + viewport'tan BİR KEZ hesaplanır ve sabitlenir
  // (`resolveInitialLayout`). Sekme değişimi, veri yüklenmesi veya içerik
  // reflow'u bu kutu geometrisini DEĞİŞTİRMEZ — yalnızca İÇERİK değişir.
  // İçerik yüksekliği ölçülmediği için (önceki ResizeObserver tabanlı content-fit
  // kilidi KALDIRILDI) layout thrashing ve "katlanma" oluşmaz. Geometri yalnızca
  // kullanıcı resize/drag, minimize/maximize/restore veya gerçek viewport resize
  // ile değişebilir — sekme/veri/loading/API sonucu ile ASLA değişmez.

  useEffect(() => {
    restoreFocusRef.current = document.activeElement as HTMLElement;
    return () => {
      if (restoreFocusRef.current && typeof restoreFocusRef.current.focus === 'function') {
        restoreFocusRef.current.focus();
      }
    };
  }, []);

  useEffect(() => {
    if (isMobile || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(() => {
      if (!maximizedRef.current || minimizedRef.current) return;
      const bounds = getWorkspaceBounds();
      setLeft(MAXIMIZE_MARGIN);
      setTop(MAXIMIZE_MARGIN);
      setWidth(Math.max(bounds.width - MAXIMIZE_MARGIN * 2, 320));
      setHeight(Math.max(bounds.height - MAXIMIZE_MARGIN * 2, 200));
    });
    ro.observe(document.body);
    return () => ro.disconnect();
  }, [isMobile]);

  useEffect(() => {
    if (isMobile) return;
    const handleResize = () => {
      if (maximizedRef.current || minimizedRef.current) return;
      // MERKEZLİ MOD: konum tamamen CSS (left/top %50 + translate) ile çözülür.
      // Window resize / browser zoom / orientation değişince tarayıcı modalı
      // OTOMATİK olarak yeni merkeze yerleştirir — JS yeniden konumlandırma
      // (ve ona bağlı zıplama) YOKTUR.
      if (!freeModeRef.current) return;
      // SERBEST MOD (kullanıcı elle taşıdı): o oturumdaki pozisyon korunur,
      // yalnızca viewport İÇİNE clamp edilir.
      const el = modalRef.current;
      const currentW = el?.offsetWidth || (typeof width === 'number' ? width : 520);
      const currentH = el?.offsetHeight || (typeof height === 'number' ? height : 400);
      const clamped = clampToWorkspace(left, top, currentW, currentH);
      setLeft(clamped.left);
      setTop(clamped.top);
    };
    window.addEventListener('resize', handleResize);
    window.addEventListener('orientationchange', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
    };
  }, [isMobile, left, top, width, height]);

  useEffect(() => {
    if (!isActive || minimized) return;
    const t = setTimeout(() => {
      const el = modalRef.current;
      if (!el) return;
      const autofocus = el.querySelector<HTMLElement>('[data-autofocus]');
      const first = el.querySelector<HTMLElement>(FOCUSABLE);
      // ZERO-JUMP: focus, modal gövdesini kaydırıp içeriği oynatmasın.
      // `preventScroll` ile odaklanan öğe görünür alana "kaydırılarak" getirilmez;
      // modal geometrisi ve gövde scroll pozisyonu açılışta SABİT kalır.
      (autofocus || first)?.focus({ preventScroll: true });
    }, 50);
    return () => clearTimeout(t);
  }, [isActive, modal.id, minimized]);

  const handleCloseRequest = useCallback(() => {
    if (modal.closable === false) return;
    if (modal.unsaved) {
      confirm({
        title: 'Kaydedilmemiş değişiklikler',
        message: 'Kaydedilmemiş değişiklikleriniz var. Çıkmak istediğinize emin misiniz?',
        variant: 'warning',
        confirmText: 'Evet, Çık',
        cancelText: 'Vazgeç',
        onConfirm: () => closeModal(modal.id),
      });
    } else {
      closeModal(modal.id);
    }
  }, [modal.closable, modal.unsaved, modal.id, closeModal, confirm]);

  const handleMinimize = useCallback(() => {
    if (modal.minimizable === false) return;
    if (modal.unsaved) {
      confirm({
        title: 'Kaydedilmemiş değişiklikler',
        message: 'Kaydedilmemiş değişiklikleriniz var. Küçültmek istediğinize emin misiniz?',
        variant: 'warning',
        confirmText: 'Evet, Küçült',
        cancelText: 'Vazgeç',
        onConfirm: () => minimizeModal(modal.id),
      });
    } else {
      minimizeModal(modal.id);
    }
  }, [modal.minimizable, modal.unsaved, modal.id, minimizeModal, confirm]);

  const toggleMaximize = useCallback(() => {
    if (isMobile) return;
    if (!maximizedRef.current) {
      const bounds = getWorkspaceBounds();
      const rect = modalRef.current?.getBoundingClientRect();
      preMaximizeRef.current = {
        left: freeMode ? left : (rect?.left ?? left),
        top: freeMode ? top : (rect?.top ?? top),
        width: typeof width === 'number' ? width : (rect?.width ?? 520),
        height,
        freeMode,
      };
      maximizedRef.current = true;
      setMaximized(true);
      setFreeMode(true);
      setLeft(MAXIMIZE_MARGIN);
      setTop(MAXIMIZE_MARGIN);
      setWidth(Math.max(bounds.width - MAXIMIZE_MARGIN * 2, 320));
      setHeight(Math.max(bounds.height - MAXIMIZE_MARGIN * 2, 200));
    } else {
      maximizedRef.current = false;
      setMaximized(false);
      const pre = preMaximizeRef.current;
      if (pre) {
        setLeft(pre.left);
        setTop(pre.top);
        setWidth(pre.width);
        setHeight(pre.height);
        // Kullanıcı bu oturumda elle taşımadıysa (pre.freeMode=false) modal
        // yeniden MERKEZLİ moda döner → yine tam viewport merkezinde olur.
        setFreeMode(pre.freeMode);
        preMaximizeRef.current = null;
      }
    }
    setActiveModal(modal.id);
  }, [isMobile, modal.id, setActiveModal, left, top, width, height, freeMode]);

  // ── DOUBLE-CLICK MAXIMIZE / RESTORE (Shared UI tek kaynak) ──
  // Header'a ÇİFT tıklama → büyüt / önceki kullanıcı boyutuna dön.
  // TEK tıklama yalnızca odak/sürükleme davranışıdır; modal boyutunu
  // KESİNLİKLE değiştirmez. Bu karar sayfa bileşenlerine bırakılmaz;
  // yalnızca merkezi modal motorunda çözülür (sayfaya özel onClick hack'i YOK).
  const handleHeaderDoubleClick = useCallback((e: React.MouseEvent) => {
    if (isMobile) return;
    if (minimized) return;
    if (modal.maximizable === false) return;
    const target = e.target as HTMLElement;
    if (target.closest('button, input, select, textarea, a')) return;
    e.preventDefault();
    toggleMaximize();
  }, [isMobile, minimized, modal.maximizable, toggleMaximize]);

  const goToStep = useCallback((idx: number) => {
    const current = steps[stepIndex];
    if (current?.validate) {
      const result = current.validate();
      if (result === false) {
        setStepError('Bu adımı tamamlamadan ilerleyemezsiniz.');
        return;
      }
      if (typeof result === 'string') {
        setStepError(result);
        return;
      }
    }
    setStepError('');
    setStepIndex(Math.max(0, Math.min(idx, steps.length - 1)));
  }, [steps, stepIndex]);

  const handleDragStart = useCallback((e: React.PointerEvent) => {
    if (isMobile) return;
    if (e.button !== 0) return;
    if (minimized) return;
    const target = e.target as HTMLElement;
    if (target.closest('button, input, select, textarea')) return;
    e.preventDefault();

    // Maximize durumunda sürükleme HENÜZ uygulanmaz: TEK tıklama (hareketsiz
    // bas-bırak) modalı restore ETMEMELİ. Gerçek hareket ilk kez algılandığında
    // (applyFrame içinde, 3px eşiği) önceki boyuta dönülür ve sürükleme oradan
    // devam eder. Bu yüzden başlangıç referansı, maximize ise önceki konumdur.
    // MERKEZLİ modda ise GERÇEK görsel rect yakalanır; serbest (absolute) moda
    // geçiş ilk gerçek hareket anında (applyFrame) bu değerden yapılır → konum
    // sürekliliği korunur, zıplama olmaz. Saf tek tıklama konumu DEĞİŞTİRMEZ.
    const rect = modalRef.current?.getBoundingClientRect();
    const baseLeft = (maximizedRef.current && preMaximizeRef.current)
      ? preMaximizeRef.current.left
      : (freeMode ? left : (rect?.left ?? left));
    const baseTop = (maximizedRef.current && preMaximizeRef.current)
      ? preMaximizeRef.current.top
      : (freeMode ? top : (rect?.top ?? top));

    dragStateRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      baseLeft,
      baseTop,
    };
    dragMovedRef.current = false;
    setIsDragging(true);
    setActiveModal(modal.id);
  }, [isMobile, modal.id, setActiveModal, left, top, minimized, freeMode]);

  const handleHeaderPointerDown = useCallback((e: React.PointerEvent) => {
    // Minimize edilmiş modalın header'ına tıklanınca drag DEĞİL, restore yapılır.
    if (minimized) {
      e.preventDefault();
      restoreModal(modal.id);
      return;
    }
    handleDragStart(e);
  }, [minimized, restoreModal, modal.id, handleDragStart]);

  const handleResizeStart = useCallback((e: React.PointerEvent, dir: ResizeDir) => {
    if (isMobile) return;
    if (e.button !== 0) return;
    if (maximizedRef.current) return;
    e.preventDefault();
    e.stopPropagation();
    const rect = modalRef.current?.getBoundingClientRect();
    const baseLeft = freeMode ? left : (rect?.left ?? left);
    const baseTop = freeMode ? top : (rect?.top ?? top);
    const currentW = typeof width === 'number' ? width : (rect?.width ?? 520);
    const currentH = typeof height === 'number' ? height : (rect?.height ?? 400);
    // Merkezli moddan serbest moda geçiş: mevcut görsel rect left/top'a sabitlenir,
    // CSS transform kaldırılır → konum DEĞİŞMEZ (zıplama yok).
    if (!freeMode) {
      setLeft(baseLeft);
      setTop(baseTop);
      setFreeMode(true);
    }
    resizeStateRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      baseW: currentW,
      baseH: currentH,
      baseLeft,
      baseTop,
      dir,
    };
    userMovedRef.current = true;
    setIsResizing(true);
    setActiveModal(modal.id);
  }, [isMobile, modal.id, setActiveModal, left, top, width, height, freeMode]);

  useEffect(() => {
    if (!isDragging && !isResizing) return;

    const applyFrame = () => {
      const p = latestPointerRef.current;
      if (!p) return;
      const sRef = stateRef.current;
      const bounds = getWorkspaceBounds();

      if (isDragging && dragStateRef.current) {
        const dx = p.clientX - dragStateRef.current.startX;
        const dy = p.clientY - dragStateRef.current.startY;

        // Tek tıklama ile sürükleme ayırt edilir: 3px eşiği aşılmadan modal
        // konumu DEĞİŞMEZ. Eşik ilk kez aşıldığında, maximize edilmişse önceki
        // kullanıcı boyutuna dönülür ve sürükleme o konumdan devam eder.
        if (!dragMovedRef.current && (Math.abs(dx) > 3 || Math.abs(dy) > 3)) {
          dragMovedRef.current = true;
          userMovedRef.current = true;
          // Merkezli (CSS transform) moddan serbest (absolute) moda geç. baseLeft/
          // baseTop pointerdown anında GERÇEK rect'ten yakalandığı için konum aynı
          // kalır — geçiş tek karede ve zıplamasız gerçekleşir.
          setFreeMode(true);
          if (maximizedRef.current && preMaximizeRef.current) {
            const pre = preMaximizeRef.current;
            maximizedRef.current = false;
            setMaximized(false);
            setWidth(pre.width);
            setHeight(pre.height);
            setLeft(pre.left);
            setTop(pre.top);
            preMaximizeRef.current = null;
            dragStateRef.current = {
              ...dragStateRef.current,
              baseLeft: pre.left,
              baseTop: pre.top,
            };
          }
        }

        if (dragMovedRef.current) {
          const s = dragStateRef.current;
          const newLeft = s.baseLeft + (p.clientX - s.startX);
          const newTop = s.baseTop + (p.clientY - s.startY);
          const clamped = clampToWorkspace(newLeft, newTop, sRef.width, sRef.height);
          setLeft(clamped.left);
          setTop(clamped.top);
        }
      }

      if (isResizing && resizeStateRef.current) {
        const s = resizeStateRef.current;
        const dx = p.clientX - s.startX;
        const dy = p.clientY - s.startY;

        let newW = s.baseW;
        let newH = s.baseH;
        let newLeft = s.baseLeft;
        let newTop = s.baseTop;

        if (s.dir.includes('e')) newW = s.baseW + dx;
        if (s.dir.includes('s')) newH = s.baseH + dy;
        if (s.dir.includes('w')) { newW = s.baseW - dx; newLeft = s.baseLeft + dx; }
        if (s.dir.includes('n')) { newH = s.baseH - dy; newTop = s.baseTop + dy; }

        newW = Math.max(sRef.modalMinWidth, Math.min(newW, bounds.width));
        newH = Math.max(sRef.modalMinHeight, Math.min(newH, bounds.height));

        if (s.dir.includes('w')) {
          const minLeft = Math.min(s.baseLeft + s.baseW - sRef.modalMinWidth, bounds.width - sRef.modalMinWidth);
          newLeft = Math.max(0, Math.min(newLeft, minLeft));
        }
        if (s.dir.includes('n')) {
          const minTop = Math.min(s.baseTop + s.baseH - sRef.modalMinHeight, bounds.height - sRef.modalMinHeight);
          newTop = Math.max(0, Math.min(newTop, minTop));
        }

        setLeft(newLeft);
        setTop(newTop);
        setWidth(newW);
        setHeight(newH);
      }
    };

    const handleMove = (e: PointerEvent) => {
      latestPointerRef.current = { clientX: e.clientX, clientY: e.clientY };
      if (rafRef.current !== null) return;
      rafRef.current = requestAnimationFrame(() => {
        rafRef.current = null;
        applyFrame();
      });
    };

    const handleUp = () => {
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      const p = latestPointerRef.current;
      const sRef = stateRef.current;

      if (isDragging && dragStateRef.current && p) {
        // Yalnızca GERÇEK bir hareket olduysa konum uygulanır. Saf tek
        // tıklama (hareketsiz) hiçbir şey değiştirmez.
        if (dragMovedRef.current) {
          const s = dragStateRef.current;
          const clamped = clampToWorkspace(
            s.baseLeft + (p.clientX - s.startX),
            s.baseTop + (p.clientY - s.startY),
            sRef.width,
            sRef.height,
          );
          setLeft(clamped.left);
          setTop(clamped.top);
        }
      }
      if (isResizing && resizeStateRef.current && p) {
        const s = resizeStateRef.current;
        const dx = p.clientX - s.startX;
        const dy = p.clientY - s.startY;
        const newW = Math.max(sRef.modalMinWidth, s.baseW + (s.dir.includes('e') ? dx : s.dir.includes('w') ? -dx : 0));
        const newH = Math.max(sRef.modalMinHeight, s.baseH + (s.dir.includes('s') ? dy : s.dir.includes('n') ? -dy : 0));
        setWidth(newW);
        setHeight(newH);
      }
      dragStateRef.current = null;
      resizeStateRef.current = null;
      latestPointerRef.current = null;
      setIsDragging(false);
      setIsResizing(false);
    };

    window.addEventListener('pointermove', handleMove);
    window.addEventListener('pointerup', handleUp);
    window.addEventListener('pointercancel', handleUp);
    return () => {
      window.removeEventListener('pointermove', handleMove);
      window.removeEventListener('pointerup', handleUp);
      window.removeEventListener('pointercancel', handleUp);
    };
  }, [isDragging, isResizing, modal.id]);

  useEffect(() => {
    if (!isActive || minimized) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      // IME / kompozisyon (Türkçe ve diğer diller) sırasında Enter ve Escape
      // kompozisyonu onaylar/iptal eder; modalı tetiklememeli veya kapatmamalıdır.
      if (e.isComposing || (e as KeyboardEvent & { keyCode?: number }).keyCode === 229) return;

      if (e.key === 'Escape') {
        const target = e.target as HTMLElement;
        if (target.closest(DROPDOWN_SELECTOR)) return;
        if (modalRef.current?.querySelector('[aria-haspopup][aria-expanded="true"]')) return;
        e.preventDefault();
        handleCloseRequest();
        return;
      }

      if (e.key === 'Tab') {
        const el = modalRef.current;
        if (!el) return;
        const focusables = Array.from(el.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
          (f) => f.offsetParent !== null || f === document.activeElement,
        );
        if (focusables.length === 0) return;
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        const active = document.activeElement as HTMLElement;

        if (e.shiftKey) {
          if (active === first || !el.contains(active)) {
            e.preventDefault();
            last.focus();
          }
        } else {
          if (active === last || !el.contains(active)) {
            e.preventDefault();
            first.focus();
          }
        }
        return;
      }

      if (e.key === 'Enter') {
        if (e.defaultPrevented) return;
        const target = e.target as HTMLElement;
        const tag = target.tagName?.toLowerCase();
        // ── ÇOK SATIRLI ALAN SEMANTİĞİ (Shared UI tek kaynak) ──
        // textarea / zengin metin (contentEditable): DÜZ Enter → yeni satır
        // (submit YOK). Ctrl/Cmd + Enter → formun primary aksiyonu. Böylece
        // Enter standardı tüm modallarda TEK yerde yönetilir; sayfaya özel
        // keyboard hack'i yazılmaz ve "Enter yanlışlıkla submit ediyor" biter.
        const isMultiline = tag === 'textarea'
          || target.isContentEditable
          || !!target.closest('[contenteditable="true"]');
        const isModifierEnter = e.ctrlKey || e.metaKey;
        if (isMultiline && !isModifierEnter) return;
        if (target.closest('button')) return;
        if (!isModifierEnter && target.closest(DROPDOWN_SELECTOR)) return;
        if (enterLockRef.current) return;

        if (isWizard) {
          enterLockRef.current = true;
          setTimeout(() => { enterLockRef.current = false; }, 350);
          const last = stepIndex === steps.length - 1;
          if (last) {
            if (modal.onSubmit) modal.onSubmit();
          } else {
            goToStep(stepIndex + 1);
          }
        } else if (modal.onSubmit) {
          enterLockRef.current = true;
          setTimeout(() => { enterLockRef.current = false; }, 350);
          modal.onSubmit();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isActive, minimized, handleCloseRequest, isWizard, stepIndex, steps, goToStep, modal.onSubmit]);

  const isLastStep = isWizard && stepIndex === steps.length - 1;
  const heightStyle = typeof height === 'number' ? `${height}px` : 'auto';
  // Varsayılan konum modu = MERKEZLİ (CSS). Kullanıcı elle taşıdı/boyutlandırdı
  // veya maximize etti → SERBEST (absolute left/top).
  const isCentered = !maximized && !freeMode;

  // ── STACK OFFSET (Shared UI tek kaynak) ──
  // Aynı anda birden fazla FARKLI modal açıkken üst üste birebir aynı koordinatta
  // açılmaz; her yeni modal kontrollü bir offset ile sağa/aşağı kayar. Offset her
  // iki eksende de viewport İÇİNDE kalacak şekilde sınırlanır — böylece modal
  // ekran dışına asla taşmaz. Mobilde offset uygulanmaz (sheet davranışı).
  const stackOffset = useMemo(() => {
    if (isMobile || stackIndex <= 0 || maximized) return { x: 0, y: 0 };
    const vw = typeof window !== 'undefined' ? window.innerWidth : 1280;
    const vh = typeof window !== 'undefined' ? window.innerHeight : 800;
    const desired = Math.min(stackIndex, STACK_OFFSET_MAX_LEVELS) * STACK_OFFSET_STEP;
    const h = typeof height === 'number' ? height : 400;
    const maxX = Math.max(0, (vw - width) / 2 - MODAL_VIEWPORT_H_MARGIN);
    const maxY = Math.max(0, (vh - h) / 2 - MODAL_VIEWPORT_V_MARGIN);
    return { x: Math.min(desired, maxX), y: Math.min(desired, maxY) };
  }, [isMobile, stackIndex, width, height, maximized]);

  // ── GÖVDE YERLEŞİMİ (Shared UI tek kaynak) ──
  // bodyLayout: single (varsayılan, tek kolon) / twoColumn / threeColumn /
  // sidebar / split. Kolon yerleşimi modal GENİŞLİĞİNE göre (container query)
  // akar; dar modalda tek kolona iner, yatay taşma ÜRETMEZ. Saha Denetim gibi
  // yoğun ekranlar `bodyLayout="threeColumn"` (sol kategori + merkez + sağ özet)
  // ile; Risk Değerlendirmesi `sidebar` (sol kategori + merkez tablo) ile;
  // Firma/Personel Detay `twoColumn` ile aynı merkezi motoru kullanır.
  const isColumnLayout = modal.bodyLayout === 'twoColumn' || modal.bodyLayout === 'threeColumn'
    || modal.bodyLayout === 'sidebar' || modal.bodyLayout === 'split';
  const colsCls = modal.bodyLayout === 'threeColumn'
    ? 'isg-modal-body-cols-3'
    : modal.bodyLayout === 'sidebar'
      ? 'isg-modal-body-cols-sidebar'
      : 'isg-modal-body-cols-2';
  const bodyContent = isWizard ? steps[stepIndex].content : modal.content;
  const wrappedBodyContent = isColumnLayout ? (
    <div className={`isg-modal-body-cols ${colsCls}`}>{bodyContent}</div>
  ) : (
    bodyContent
  );

  const footerContent = typeof modal.footerActions === 'function'
    ? modal.footerActions({ close: handleCloseRequest, forceClose: () => closeModal(modal.id), id: modal.id })
    : modal.footerActions;

  const handleSubmitClick = useCallback(() => {
    if (isWizard && !isLastStep) {
      goToStep(stepIndex + 1);
      return;
    }
    if (modal.onSubmit) modal.onSubmit();
  }, [isWizard, isLastStep, stepIndex, goToStep, modal.onSubmit]);

  const resizeHandles: { dir: ResizeDir; className: string }[] = [
    { dir: 'n', className: 'top-0 left-2 right-2 h-1.5 cursor-n-resize' },
    { dir: 's', className: 'bottom-0 left-2 right-2 h-1.5 cursor-s-resize' },
    { dir: 'e', className: 'right-0 top-2 bottom-2 w-1.5 cursor-e-resize' },
    { dir: 'w', className: 'left-0 top-2 bottom-2 w-1.5 cursor-w-resize' },
    { dir: 'ne', className: 'top-0 right-0 w-4 h-4 cursor-ne-resize' },
    { dir: 'nw', className: 'top-0 left-0 w-4 h-4 cursor-nw-resize' },
    { dir: 'se', className: 'bottom-0 right-0 w-4 h-4 cursor-se-resize' },
    { dir: 'sw', className: 'bottom-0 left-0 w-4 h-4 cursor-sw-resize' },
  ];

  // Minimize dock konumu: sağ alt köşe, çoklu modal'da dikey stack (alttan üste).
  const minimizedStyle = {
    left: 'auto',
    top: 'auto',
    right: `${DOCK_MARGIN}px`,
    bottom: `${DOCK_MARGIN + minimizedIndex * (MINIMIZED_HEIGHT + DOCK_GAP)}px`,
    width: `${MINIMIZED_WIDTH}px`,
    height: 'auto',
  };

  return (
    <div
      ref={modalRef}
      role="dialog"
      aria-modal={minimized ? 'false' : 'true'}
      aria-label={modal.title}
      className={`fixed flex flex-col isg-modal-content overflow-hidden ${isMobile && !minimized ? 'isg-modal-mobile-full' : isMobile ? 'rounded-2xl' : 'rounded-lg'} ${isDragging || isResizing ? 'select-none' : ''}`}
      style={{
        ...(minimized
          ? minimizedStyle
          : isMobile
            ? {}
            : isCentered
              ? {
                  // MERKEZLİ MOD (Shared UI tek kaynak): konum JS ile değil CSS
                  // layout ile çözülür. `left/top %50` + `translate(-50%,-50%)`
                  // modalı kendi GERÇEK boyutuna göre tam viewport merkezine otur.
                  // İLK PAINT'te doğrudur — "önce render → sonra merkezle" adımı
                  // YOKTUR. Auto-height içerik veya font yüklenirken boyut değişse
                  // bile modal simetrik büyür/küçülüp merkezde kalır; ayrı bir konum
                  // düzeltmesi (zıplama) oluşmaz. CSS %50 merkezi ayrıca scrollbar
                  // hariç GÖRÜNÜR alana göre hesaplandığı için yarım scrollbar
                  // kayması da oluşmaz.
                  left: '50%',
                  top: '50%',
                  transform: `translate(calc(-50% + ${stackOffset.x}px), calc(-50% + ${stackOffset.y}px))`,
                  width: `${width}px`,
                  height: heightStyle,
                  maxHeight: `calc(100vh - ${MODAL_VIEWPORT_V_MARGIN * 2}px)`,
                  maxWidth: `calc(100vw - ${MODAL_VIEWPORT_H_MARGIN * 2}px)`,
                  minWidth: Math.min(scaleByDensity(modal.minWidth ?? 320), viewportMaxWidth()),
                  minHeight: Math.min(scaleByDensity(modal.minHeight ?? 200), viewportMaxHeight()),
                }
              : {
                  left: `${left}px`,
                  top: `${top}px`,
                  width: `${width}px`,
                  height: heightStyle,
                  maxHeight: maximized ? 'none' : `calc(100vh - ${MODAL_VIEWPORT_V_MARGIN * 2}px)`,
                  maxWidth: maximized ? 'none' : `calc(100vw - ${MODAL_VIEWPORT_H_MARGIN * 2}px)`,
                  minWidth: Math.min(scaleByDensity(modal.minWidth ?? 320), viewportMaxWidth()),
                  minHeight: Math.min(scaleByDensity(modal.minHeight ?? 200), viewportMaxHeight()),
                }),
        zIndex: minimized ? Z_LAYERS.minimizedModal + minimizedIndex : (modal.zIndex ?? Z_LAYERS.modalBase),
        display: 'flex',
        // GLOBAL KURAL: modalın KENDİSİNDE (dış çerçevede) scrollbar ASLA olmaz.
        // ÖNEMLİ: Yalnızca `overflow-x: hidden` verilirse, CSS sözleşmesi gereği
        // görünür eksen (`overflow-y`) otomatik olarak `auto`'ya döner ve modalın
        // TAMAMINA (başlık + adım çubuğu + footer dâhil) gereksiz bir DİKEY scroll
        // kazandırır. Bu yüzden iki eksen de hidden sabitlenir; kaydırma YALNIZCA
        // modal GÖVDESİNİN kendi iç scroll alanında olur (header/footer sabit kalır).
        overflowX: 'hidden',
        overflowY: 'hidden',
      }}
      onPointerDown={() => { if (!minimized) setActiveModal(modal.id); }}
    >
      {minimized && (
        <div
          className="flex items-center gap-2.5 pl-3 pr-1.5 py-2 bg-background-50 dark:bg-background-300 border border-background-300/50 dark:border-background-400/60 rounded-lg cursor-pointer select-none"
          onPointerDown={handleHeaderPointerDown}
          title="Geri aç"
        >
          <i className="ri-file-list-3-line text-sm text-primary-600 dark:text-primary-400 shrink-0" />
          <span className="flex-1 min-w-0 text-sm font-medium text-foreground-800 truncate">{modal.title}</span>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); restoreModal(modal.id); }}
            onPointerDown={(e) => e.stopPropagation()}
            className="w-6 h-6 flex items-center justify-center rounded text-foreground-500 hover:text-primary-600 hover:bg-background-200 transition-colors shrink-0"
            title="Geri aç / Büyüt"
            aria-label="Geri aç / Büyüt"
          >
            <i className="ri-fullscreen-line text-xs" />
          </button>
          {modal.closable !== false && (
            <button
              type="button"
            onClick={(e) => { e.stopPropagation(); closeModal(modal.id); }}
              onPointerDown={(e) => e.stopPropagation()}
              className="w-6 h-6 flex items-center justify-center rounded text-foreground-500 hover:text-danger-600 hover:bg-danger-100 transition-colors shrink-0"
              title="Kapat"
              aria-label="Kapat"
            >
              <i className="ri-close-line text-xs" />
            </button>
          )}
        </div>
      )}
      <div className={minimized ? 'hidden' : 'flex flex-col flex-1 min-h-0'}>
          {/* Header — drag alanı. Butonlar drag'i tetiklemez. */}
          <div
            className={`flex items-center justify-between isg-modal-head border-b isg-divider select-none flex-shrink-0 ${isMobile ? 'isg-modal-mobile-header' : ''} ${isDragging ? 'cursor-grabbing' : (minimized || isMobile ? 'cursor-default' : 'cursor-grab')}`}
            onPointerDown={handleHeaderPointerDown}
            onDoubleClick={handleHeaderDoubleClick}
          >
            <div className="flex-1 min-w-0 pr-3 flex items-center gap-3">
              {modal.headerIcon && (
                <span className="shrink-0 flex items-center justify-center">{modal.headerIcon}</span>
              )}
              <div className="min-w-0">
                <h3 className="isg-modal-title font-semibold text-foreground-950 truncate">{modal.title}</h3>
                {modal.description && (
                  <p className="text-sm text-foreground-500 truncate mt-0.5">{modal.description}</p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              {modal.headerExtra && (
                <div className="flex items-center gap-1.5 mr-1 flex-shrink-0">{modal.headerExtra}</div>
              )}
              {modal.minimizable !== false && !isMobile && (
                <button
                  type="button"
                  onClick={handleMinimize}
                  onPointerDown={(e) => e.stopPropagation()}
                  className="isg-iconbtn isg-iconbtn-md text-foreground-500 hover:text-foreground-800 hover:bg-background-200"
                  title="Küçült"
                  aria-label="Küçült"
                >
                  <i className="ri-subtract-line text-sm" />
                </button>
              )}
              {modal.maximizable !== false && !isMobile && (
                <button
                  type="button"
                  onClick={toggleMaximize}
                  onPointerDown={(e) => e.stopPropagation()}
                  className="isg-iconbtn isg-iconbtn-md text-foreground-500 hover:text-foreground-800 hover:bg-background-200"
                  title={maximized ? 'Önceki boyuta döndür' : 'Büyüt'}
                  aria-label={maximized ? 'Önceki boyuta döndür' : 'Büyüt'}
                >
                  <i className={maximized ? 'ri-fullscreen-exit-line text-sm' : 'ri-fullscreen-line text-sm'} />
                </button>
              )}
              {modal.closable !== false && (
                <button
                  type="button"
                  onClick={handleCloseRequest}
                  onPointerDown={(e) => e.stopPropagation()}
                  className="isg-iconbtn isg-iconbtn-md text-foreground-500 hover:text-danger-600 hover:bg-danger-100"
                  title="Kapat"
                  aria-label="Kapat"
                >
                  <i className="ri-close-line text-base" />
                </button>
              )}
            </div>
          </div>

          {/* ── SHARED WIZARD STEPPER (tek kaynak) ──
              Modal'ın yerleşik adım göstergesi artık ayrı bir "pill" sistemi
              DEĞİL; tüm wizard'ların kullandığı ortak `WizardStepper` bileşenidir.
              Adım geometrisi (daire + bağlantı çizgisi + alt etiket) tek merkezden
              gelir ve Dark/Light aynı düzeni paylaşır. Stepper header'ın ALTINDA,
              yatay ve merkezlidir; scroll olmaz (flex-shrink: 0). */}
          {isWizard && (
            <div className="border-b isg-divider flex-shrink-0">
              <WizardStepper
                steps={steps.map((s) => ({ title: s.title, shortTitle: s.shortTitle ?? s.title }))}
                current={stepIndex}
                onStepClick={goToStep}
              />
            </div>
          )}

          {/* Body — Shared UI gövde yerleşimi (tek kaynak):
              'scroll' (varsayılan): gövde kaydırılır, footer SABİT kalır.
              'fill': gövde kaydırmaz; içerik alanı doldurur ve kendi iç
              scroll'unu + footer'ını yönetir (çok adımlı sihirbazlar). Bu,
              "alt aksiyonlar içerikle kayıyor" sorununun merkezi çözümüdür. */}
          {modal.bodyLayout === 'fill' ? (
            <div className="flex-1 min-h-0 flex flex-col isg-modal-body overflow-hidden">
              {wrappedBodyContent}
              {stepError && (
                <p className="mt-2 text-xs text-danger-600 flex items-center gap-1">
                  <i className="ri-error-warning-line" />
                  {stepError}
                </p>
              )}
            </div>
          ) : (
            <div ref={bodyRef} onScroll={(e) => { scrollTopRef.current = e.currentTarget.scrollTop; }} className="flex-1 overflow-y-auto overflow-x-hidden isg-modal-body isg-scroll-pane min-h-0">
              {wrappedBodyContent}
              {stepError && (
                <p className="mt-2 text-xs text-danger-600 flex items-center gap-1">
                  <i className="ri-error-warning-line" />
                  {stepError}
                </p>
              )}
            </div>
          )}

          {/* Footer */}
          {(modal.showFooter || modal.footerActions || isWizard) && (
            <div className={`flex items-center justify-between gap-2 isg-modal-foot ${isMobile ? 'pb-safe-footer' : ''} border-t isg-divider flex-shrink-0`}>
              {/* SOL: İptal — yalnızca wizard'da ve özel aksiyon yoksa (referans alt bar). */}
              <div className="flex items-center gap-2">
                {isWizard && !footerContent && (
                  <button
                    type="button"
                    onClick={handleCloseRequest}
                    className="isg-btn isg-btn-ghost"
                  >
                    <i className="ri-close-line" /> İptal
                  </button>
                )}
              </div>
              {/* SAĞ: Önceki Adım + (varsa özel aksiyonlar) + Sonraki/Kaydet —
                  referans geometrisi: tüm wizard aksiyonları SAĞDA toplanır. */}
              <div className="flex items-center gap-2">
                {isWizard && stepIndex > 0 && (
                  <button
                    type="button"
                    onClick={() => goToStep(stepIndex - 1)}
                    className="isg-btn isg-btn-secondary"
                  >
                    <i className="ri-arrow-left-line" /> Geri
                  </button>
                )}
                {footerContent}
                {isWizard && (
                  <button
                    type="button"
                    onClick={handleSubmitClick}
                    className="isg-btn isg-btn-primary"
                    data-autofocus
                  >
                    {isLastStep ? (modal.submitLabel || 'Kaydet') : 'İleri'}
                    {!isLastStep && <i className="ri-arrow-right-line" />}
                  </button>
                )}
              </div>
            </div>
          )}
      </div>

      {/* Resize handles — 4 kenar + 4 köşe (desktop only) */}
      {!isMobile && !minimized && modal.resizable !== false && modal.variant !== 'fullscreen' && modal.size !== 'full' && !maximized && (
        <>
          {resizeHandles.map((h) => (
            <div
              key={h.dir}
              className={`absolute z-10 ${h.className}`}
              onPointerDown={(e) => handleResizeStart(e, h.dir)}
              title="Yeniden boyutlandır"
            />
          ))}
          <div className="absolute bottom-1 right-1 w-2 h-2 border-r-2 border-b-2 border-foreground-300 rounded-br-sm pointer-events-none" />
        </>
      )}
    </div>
  );
}