import type { ReactNode } from 'react';

type AlertVariant = 'info' | 'success' | 'warning' | 'danger';

interface AlertProps {
  variant?: AlertVariant;
  /** Kalın başlık satırı (opsiyonel). Örn: "Başarılı", "Uyarı". */
  title?: string;
  children?: ReactNode;
  /** Varsayılan ikonu geçersiz kılmak için tam Remix Icon class'ı. */
  icon?: string;
  /** Sağda aksiyon alanı (buton vb.). */
  action?: ReactNode;
  /** Verilirse sağ üstte kapatma butonu gösterilir. */
  onClose?: () => void;
  className?: string;
}

/**
 * GLOBAL ALERT / BİLDİRİM (Shared UI tek kaynak).
 * Renkli bilgi/uyarı blokları (başarı, bilgi, uyarı, hata) onlarca sayfaya
 * elle `bg-success-50 … border-success-200/50 …` olarak kopyalanmıştı.
 * Artık TEK bu bileşen üzerinden yönetilir; tema geçişinde (light/dark) renk
 * kontrastı merkezî token'lardan otomatik uyarlanır. İş mantığı içermez.
 */
const VARIANTS: Record<AlertVariant, { wrap: string; iconColor: string; defaultIcon: string }> = {
  info: {
    wrap: 'bg-primary-50 border-primary-200/60 dark:bg-primary-500/10 dark:border-primary-500/25',
    iconColor: 'text-primary-600 dark:text-primary-400',
    defaultIcon: 'ri-information-line',
  },
  success: {
    wrap: 'bg-success-50 border-success-200/60 dark:bg-success-500/10 dark:border-success-500/25',
    iconColor: 'text-success-600 dark:text-success-400',
    defaultIcon: 'ri-checkbox-circle-line',
  },
  warning: {
    wrap: 'bg-warning-50 border-warning-200/60 dark:bg-warning-500/10 dark:border-warning-500/25',
    iconColor: 'text-warning-600 dark:text-warning-400',
    defaultIcon: 'ri-alert-line',
  },
  danger: {
    wrap: 'bg-danger-50 border-danger-200/60 dark:bg-danger-500/10 dark:border-danger-500/25',
    iconColor: 'text-danger-600 dark:text-danger-400',
    defaultIcon: 'ri-error-warning-line',
  },
};

const TEXT_TONE: Record<AlertVariant, string> = {
  info: 'text-primary-800 dark:text-primary-300',
  success: 'text-success-800 dark:text-success-300',
  warning: 'text-warning-800 dark:text-warning-300',
  danger: 'text-danger-800 dark:text-danger-300',
};

export default function Alert({
  variant = 'info',
  title,
  children,
  icon,
  action,
  onClose,
  className = '',
}: AlertProps) {
  const cfg = VARIANTS[variant];

  return (
    <div role="alert" className={`flex items-start gap-2.5 rounded-lg border p-3 ${cfg.wrap} ${className}`}>
      <i className={`${icon || cfg.defaultIcon} ${cfg.iconColor} text-base leading-5 shrink-0 mt-px`} aria-hidden="true" />
      <div className="min-w-0 flex-1">
        {title && <p className={`isg-text-small font-semibold ${TEXT_TONE[variant]}`}>{title}</p>}
        {children && (
          <div className={`isg-text-small ${TEXT_TONE[variant]} ${title ? 'mt-0.5' : ''}`}>{children}</div>
        )}
      </div>
      {action && <div className="shrink-0">{action}</div>}
      {onClose && (
        <button
          type="button"
          onClick={onClose}
          aria-label="Kapat"
          className={`isg-iconbtn isg-iconbtn-sm shrink-0 ${cfg.iconColor} hover:bg-black/5 dark:hover:bg-white/10`}
        >
          <i className="ri-close-line" />
        </button>
      )}
    </div>
  );
}