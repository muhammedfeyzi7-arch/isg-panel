import type { ReactNode } from 'react';

interface SectionTitleProps {
  title: string;
  /** Başlığın altındaki açıklama satırı (opsiyonel). */
  desc?: string;
  /** Sağa yaslanan aksiyon/rozet alanı (opsiyonel). */
  right?: ReactNode;
  className?: string;
}

/**
 * GLOBAL BÖLÜM BAŞLIĞI — Shared UI tek kaynak.
 *
 * Modal/sihirbaz/form içindeki bölüm başlıklarının ("1. Temel Bilgiler",
 * "5. Rapor ve Önizleme" ...) TEK kaynağıdır. PageHeader (sayfa seviyesi, H1)
 * ile karıştırılmamalıdır; bu, İÇERİK bölümü (H2) başlığıdır.
 *
 * Tipografi (`isg-text-section` / `isg-text-caption`) ve boşluk tamamen merkezi
 * token'lardan gelir; renk hardcode EDİLMEZ. Light ve Dark aynı geometriyi
 * paylaşır. Modüller kendi bölüm başlığı stilini ÜRETMEZ, bu bileşeni kullanır.
 */
export default function SectionTitle({ title, desc, right, className = '' }: SectionTitleProps) {
  return (
    <div className={`flex flex-shrink-0 items-start justify-between gap-3 pb-3 ${className}`}>
      <div className="min-w-0">
        <h2 className="isg-text-section text-foreground-950">{title}</h2>
        {desc && <p className="mt-1 isg-text-caption leading-relaxed text-foreground-500">{desc}</p>}
      </div>
      {right}
    </div>
  );
}