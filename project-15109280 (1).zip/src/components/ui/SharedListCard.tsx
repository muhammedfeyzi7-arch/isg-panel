import type { ReactNode } from 'react';

/**
 * Global Shared List Card — İSGDenetim'deki TÜM mobil liste kartlarının
 * tek ortak bileşeni. Admin/OSGB/Firma/Uzman/Hekim/Logs gibi tüm CRUD ekranları
 * mobilde bu kartı kullanır. Sayfa bazında özel kart yazılmaz.
 *
 * Görsel standart: referans görsel (Duyurular mobil ekranı).
 * spacing, typography, border, radius hepsi bu tek kaynaktan yönetilir.
 */

export interface SharedListCardProps {
  /** Kayıt numarası / ID — kart üst sol (#D-2025-001 vb.) */
  recordNo?: string;
  /** İkon — sol tarafta renkli arka planlı kutu */
  icon?: string;
  /** İkon kutu arka plan rengi (Tailwind class) */
  iconBg?: string;
  /** İkon rengi (Tailwind class) */
  iconColor?: string;
  /** Ana başlık */
  title: string;
  /** Kısa özet/açıklama satırı */
  description?: string;
  /** Badge'ler — durum, kategori, öncelik vb. */
  badges?: ReactNode[];
  /** Alt metadata — tarih, şehir, kullanıcı vb. */
  metadata?: Array<{ label?: string; value: ReactNode; icon?: string }>;
  /** Sağ tarafta üç nokta context menüsü */
  actions?: ReactNode;
  /** Detay chevron gösterilsin mi (tıklanabilir kartlarda) */
  showChevron?: boolean;
  /** Tıklama callback'i */
  onClick?: () => void;
  /** Long press için data attribute */
  longPressKey?: string;
  className?: string;
  /** Ekstra rozet satırı (alt kısım — ek badge'ler) */
  extraBadges?: ReactNode[];
}

/**
 * Kompakt badge renderer — referans görseldeki pill badge stili.
 * Yeşil "Yayınlandı", turuncu "Sistem", mor "Tüm Kullanıcılar" gibi.
 */
export function ListCardBadge({
  children,
  variant = 'default',
  className = '',
}: {
  children: ReactNode;
  variant?: 'success' | 'warning' | 'danger' | 'info' | 'default' | 'secondary' | 'accent';
  className?: string;
}) {
  const variantCls: Record<string, string> = {
    success:   'bg-success-50   text-success-700',
    warning:   'bg-warning-50   text-warning-700',
    danger:    'bg-danger-50    text-danger-700',
    info:      'bg-primary-50   text-primary-700',
    secondary: 'bg-secondary-50 text-secondary-700',
    accent:    'bg-accent-50    text-accent-700',
    default:   'bg-background-200 text-foreground-600',
  };

  return (
    <span
      className={`inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded-full isg-stat-sub font-medium whitespace-nowrap ${variantCls[variant] || variantCls.default} ${className}`}
    >
      {children}
    </span>
  );
}

export default function SharedListCard({
  recordNo,
  icon,
  iconBg = 'bg-primary-50',
  iconColor = 'text-primary-600',
  title,
  description,
  badges = [],
  metadata = [],
  actions,
  showChevron = true,
  onClick,
  longPressKey,
  className = '',
  extraBadges = [],
}: SharedListCardProps) {
  return (
    <div
      className={`bg-background-100 dark:bg-background-200 border border-background-200/80 dark:border-background-400/30 rounded-xl p-2.5 transition-colors ${
        onClick ? 'cursor-pointer active:bg-background-200/60 dark:active:bg-background-300/40' : ''
      } ${className}`}
      onClick={onClick}
      {...(longPressKey ? { 'data-longpress-key': longPressKey } : {})}
    >
      <div className="flex items-start gap-2.5">
        {/* Sol: ikon kutu */}
        {icon && (
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${iconBg}`}>
            <i className={`${icon} text-sm ${iconColor}`} />
          </div>
        )}

        {/* Orta: içerik */}
        <div className="flex-1 min-w-0">
          {/* Üst satır: kayıt no + aksiyonlar */}
          {(recordNo || actions) && (
            <div className="flex items-center justify-between gap-1 mb-0.5">
              {recordNo && (
                <span className="isg-stat-sub font-medium text-foreground-500">{recordNo}</span>
              )}
              {!recordNo && <div />}
              {actions && (
                <div className="flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                  {actions}
                </div>
              )}
            </div>
          )}

          {/* Ana başlık */}
          <p className="text-sm font-semibold text-foreground-950 leading-tight line-clamp-1">{title}</p>

          {/* Açıklama */}
          {description && (
            <p className="isg-text-micro text-foreground-500 line-clamp-1 leading-snug">{description}</p>
          )}

          {/* Badge satırı */}
          {badges.length > 0 && (
            <div className="mt-1 flex flex-wrap items-center gap-1">
              {badges}
            </div>
          )}

          {/* Ekstra badge satırı */}
          {extraBadges.length > 0 && (
            <div className="mt-1 flex flex-wrap items-center gap-1">
              {extraBadges}
            </div>
          )}

          {/* Metadata satırı */}
          {metadata.length > 0 && (
            <div className="mt-1 flex flex-wrap items-center gap-x-2.5 gap-y-1">
              {metadata.map((item, idx) => (
                <span key={idx} className="flex items-center gap-1 isg-stat-sub text-foreground-500 min-w-0">
                  {item.icon && <i className={`${item.icon} text-[11px] flex-shrink-0`} />}
                  {item.label && <span className="text-foreground-500">{item.label}</span>}
                  <span className="truncate">{item.value}</span>
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Sağ: chevron */}
        {showChevron && onClick && !actions && (
          <div className="flex-shrink-0 text-foreground-400 self-center">
            <i className="ri-arrow-right-s-line text-base" />
          </div>
        )}
      </div>
    </div>
  );
}