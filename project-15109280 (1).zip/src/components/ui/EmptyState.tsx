import Button from './Button';

interface EmptyStateProps {
  icon?: string;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void; icon?: string };
  className?: string;
}

export default function EmptyState({ icon = 'ri-inbox-line', title, description, action, className = '' }: EmptyStateProps) {
  return (
    <div className={`flex flex-col items-center justify-center isg-empty px-4 text-center ${className}`}>
      <div aria-hidden="true" className="w-14 h-14 rounded-full bg-background-200 dark:bg-background-300/40 flex items-center justify-center mb-4">
        <i className={`${icon} text-2xl text-foreground-400`} />
      </div>
      <h3 className="isg-text-section text-foreground-800">{title}</h3>
      {description && <p className="mt-1 isg-text-body text-foreground-500 max-w-xs">{description}</p>}
      {action && (
        <Button variant="primary" size="sm" className="mt-4" onClick={action.onClick} leftIcon={<i className={action.icon || 'ri-add-line'} />}>
          {action.label}
        </Button>
      )}
    </div>
  );
}