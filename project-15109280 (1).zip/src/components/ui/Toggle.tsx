import { forwardRef, type InputHTMLAttributes } from 'react';

interface ToggleProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  labelOn?: string;
  labelOff?: string;
}

const Toggle = forwardRef<HTMLInputElement, ToggleProps>(function Toggle(
  { label, labelOn, labelOff, className = '', disabled, ...props },
  ref
) {
  return (
    <label className={`inline-flex items-center gap-2.5 cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}>
      <div className="relative">
        <input
          ref={ref}
          type="checkbox"
          role="switch"
          className="peer sr-only"
          disabled={disabled}
          {...props}
        />
        <div className={`w-11 h-6 rounded-full transition-colors duration-200
          peer-focus-visible:ring-2 peer-focus-visible:ring-primary-400/60
          ${props.checked ? 'bg-primary-500' : 'bg-background-400'}
          peer-disabled:bg-background-300
        `}>
          <div className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform duration-200
            ${props.checked ? 'translate-x-5' : 'translate-x-0'}
          `} />
        </div>
      </div>
      {label && (
        <span className="text-sm font-medium text-foreground-800">
          {props.checked ? (labelOn || label) : (labelOff || label)}
        </span>
      )}
    </label>
  );
});

export default Toggle;