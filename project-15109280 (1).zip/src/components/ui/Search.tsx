import { useEffect, useRef, useState } from 'react';

interface SearchProps {
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  onSearch?: (value: string) => void;
  className?: string;
  size?: 'sm' | 'md';
  autoFocus?: boolean;
  debounceMs?: number;
  loading?: boolean;
  resultCount?: number;
}

/**
 * Ortak Search componenti. Tüm listeleme ekranlarında tek arama sistemi olarak kullanılır.
 *
 * Önemli: input HER ZAMAN lokal state ile çalışır. Böylece kontrollü kullanımda
 * (value prop verilse bile) parmak klavyeden kalkmadan hızlı yazıldığında React
 * eski değeri geri yazıp harf yutmaz. Dışarıya bildirim (onChange/onSearch)
 * opsiyonel debounce ile yapılır; canlı filtreleme artık Enter'a gerek kalmadan çalışır.
 */
export default function Search({
  placeholder = 'Ara...',
  value,
  onChange,
  onSearch,
  className = '',
  size = 'md',
  autoFocus,
  debounceMs,
  loading,
  resultCount,
}: SearchProps) {
  const [internalValue, setInternalValue] = useState(value ?? '');
  const debounceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  // ── AUTOFILL KORUMASI (Shared UI tek kaynak) ──
  // Tarayıcı (özellikle Chrome) başka bir formdaki "ad/soyad" alanına yazılırken bu
  // arama kutusunu da aynı alan sanıp kendiliğinden dolduruyordu (personel eklerken
  // ad girince listenin arama alanına sızması). Input, ODAK ALMADIĞI sürece
  // salt-okunur (readOnly) tutulur; autofill motorları readOnly bir alana YAZAMAZ.
  // Odaklanınca açılır, odak kaybında tekrar kilitlenir — böylece arama kutusuna
  // başka bir formdan değer sızması kesin olarak engellenir.
  const [focused, setFocused] = useState(false);

  // Dış değer (parent) değiştiğinde input'u senkronize et.
  // Sadece value prop gerçekten değişince çalışır; yazma sırasında asla tetiklenmez.
  useEffect(() => {
    if (value !== undefined) {
      setInternalValue((prev) => (prev === value ? prev : value));
    }
  }, [value]);

  useEffect(() => {
    return () => {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
    };
  }, []);

  const emit = (v: string) => {
    onChange?.(v);
    onSearch?.(v);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = e.target.value;
    // Her zaman ANINDA lokal state'e yaz → harf yutulmaz, imleç zıplamaz.
    setInternalValue(v);
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    if (debounceMs) {
      debounceTimer.current = setTimeout(() => emit(v), debounceMs);
    } else {
      emit(v);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (debounceTimer.current) clearTimeout(debounceTimer.current);
      emit(internalValue);
    }
  };

  const clear = () => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    setInternalValue('');
    onChange?.('');
    onSearch?.('');
  };

  const currentValue = internalValue;
  // Ölçü varyantı merkezi Shared UI token'ından (--d-input-*).
  const sizeCls = size === 'sm' ? 'isg-input-sm' : '';

  // Sol/sağ padding'i INLINE veriyoruz: `.isg-input.isg-input-sm` kuralı (özgüllük 0,2,0)
  // `padding` shorthand'ı ile `pl-9`/`pr-*` utility'lerini EZİYOR ve arama ikonu
  // placeholder metninin ÜSTÜNE biniyordu. Inline stil her zaman kazandığı için ikon
  // ile metin arasındaki boşluk hem sm hem md boyutta garanti edilir.
  const hasRightSlot = !!loading || resultCount !== undefined || !!currentValue;
  const padLeft = '2.25rem';
  const padRight = hasRightSlot ? (size === 'sm' ? '3.25rem' : '3.75rem') : padLeft;

  return (
    <div role="search" className={`relative flex items-center ${className}`}>
      <i className="ri-search-line absolute left-3 text-foreground-400 pointer-events-none" />
      <input
        type="text"
        // name + autoComplete="off": tarayıcı autofill'i bu arama kutusunu başka bir
        // formdaki ad/soyad alanıyla eşleştirip (ekle alanlarına isim girildiğinde)
        // arama yerini kendiliğinden doldurmasın diye açıkça işaretlenir.
        name="isg-arama"
        autoComplete="off"
        spellCheck={false}
        aria-label={placeholder}
        value={currentValue}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        readOnly={!focused}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
        autoFocus={autoFocus}
        style={{ paddingLeft: padLeft, paddingRight: padRight }}
        className={`isg-input w-full ${sizeCls}`}
      />
      <div className="absolute right-2 flex items-center gap-1.5">
        {loading ? (
          <span className="inline-block w-4 h-4 border-2 border-foreground-300 border-t-transparent rounded-full animate-spin" />
        ) : resultCount !== undefined && !currentValue ? (
          <span className="text-xs text-foreground-400">{resultCount}</span>
        ) : null}
        {currentValue && (
          <button
            type="button"
            onClick={clear}
            className="text-foreground-400 hover:text-foreground-600 transition-colors cursor-pointer"
            aria-label="Temizle"
          >
            <i className="ri-close-circle-line" />
          </button>
        )}
      </div>
    </div>
  );
}