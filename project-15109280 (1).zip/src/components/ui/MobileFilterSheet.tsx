import { useEffect } from 'react';
import type { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import type { FilterField } from './FilterBar';
import { Z_LAYERS } from '@/utils/layers';
import { lockScroll, unlockScroll } from '@/lib/scrollLock';

/**
 * GLOBAL SHARED UI — MOBİL FİLTRE PANELİ (bottom sheet).
 *
 * Tüm listeleme ekranları (Firmalar / Personeller / Evraklar / Zimmet / Saha
 * Denetimleri / Envanter / Atamalar / Duyurular / Loglar ...) mobilde büyük
 * filtre çubuğunu EKRANDA SÜREKLİ GÖSTERMEZ. Bunun yerine kompakt arama + filtre
 * ikonu kalır; ikona basınca bu panel alttan açılır ve filtreler burada yönetilir.
 *
 * Filtre alanlarının kendisi `FilterBar`'dan `renderField` ile gelir (tek kaynak);
 * bu bileşen yalnızca mobil "kabuk"tur. Desktop bu paneli HİÇ görmez.
 *
 * `document.body`'ye portal edilir ki modal / container / transform içindeki
 * listelerde de doğru konumlanıp kırpılmasın.
 *
 * ANİMASYONSUZ standart: tak açılır, tak kapanır. Yalnızca dikey scroll eder.
 * Yatay taşma YOKTUR (alanlar tam genişlik, viewport'a uyar).
 */
export default function MobileFilterSheet({
  filters,
  onReset,
  onClose,
  renderField,
  activeCount,
}: {
  filters: FilterField[];
  onReset: () => void;
  onClose: () => void;
  renderField: (filter: FilterField) => ReactNode;
  activeCount: number;
}) {
  // Arka plan scroll kilidi — merkezi Shared UI utility'si.
  useEffect(() => {
    lockScroll('mobile-filter-sheet');
    return () => unlockScroll('mobile-filter-sheet');
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const sheetContent = (
    <div className="lg:hidden">
      {/* Overlay — statik, animasyonsuz */}
      <div
        className="isg-overlay fixed inset-0"
        style={{ zIndex: Z_LAYERS.bottomSheetOverlay }}
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Panel — alttan açılan sheet */}
      <div
        className="fixed left-0 right-0 bottom-0"
        style={{ zIndex: Z_LAYERS.bottomSheetPanel }}
        role="dialog"
        aria-modal="true"
        aria-label="Filtreler"
      >
        <div className="bg-background-100 dark:bg-background-200 rounded-t-2xl max-h-[80vh] flex flex-col overflow-hidden shadow-[0_-8px_32px_rgba(0,0,0,0.2)]">
          {/* Grabber */}
          <div className="flex justify-center pt-3 pb-1 flex-shrink-0">
            <div className="w-10 h-1.5 rounded-full bg-foreground-300/40" />
          </div>

          {/* Header */}
          <div className="flex items-center justify-between px-4 pb-2 flex-shrink-0">
            <h3 className="text-base font-semibold text-foreground-950 flex items-center gap-2">
              <i className="ri-filter-3-line text-foreground-500" />
              Filtreler
              {activeCount > 0 && (
                <span className="min-w-[18px] h-[18px] px-1 flex items-center justify-center rounded-full bg-primary-500 text-inverse isg-text-micro font-bold">
                  {activeCount}
                </span>
              )}
            </h3>
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer"
              aria-label="Kapat"
            >
              <i className="ri-close-line text-lg text-foreground-500" />
            </button>
          </div>

          {/* Alanlar — yalnızca dikey scroll */}
          <div className="flex-1 overflow-y-auto overflow-x-hidden px-4 pb-3 space-y-3 min-h-0">
            {filters.map((filter) => (
              <div key={filter.key} className="min-w-0">
                {renderField(filter)}
              </div>
            ))}
          </div>

          {/* Footer — sabit aksiyon şeridi */}
          <div
            className="flex items-center gap-2 px-4 py-3 border-t isg-divider flex-shrink-0"
            style={{ paddingBottom: 'calc(0.75rem + env(safe-area-inset-bottom))' }}
          >
            {activeCount > 0 && (
              <button type="button" onClick={onReset} className="isg-btn isg-btn-secondary flex-1">
                <i className="ri-close-line" />
                Temizle
              </button>
            )}
            <button type="button" onClick={onClose} className="isg-btn isg-btn-primary flex-1">
              <i className="ri-check-line" />
              Uygula
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  if (typeof document === 'undefined') return null;
  return createPortal(sheetContent, document.body);
}