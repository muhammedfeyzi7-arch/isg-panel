interface LoadingProps {
  size?: 'sm' | 'md' | 'lg';
  text?: string;
  fullPage?: boolean;
  className?: string;
}

export default function Loading({ size = 'md', text, fullPage, className = '' }: LoadingProps) {
  const sizeCls = {
    sm: 'w-5 h-5 border-2',
    md: 'w-8 h-8 border-2',
    lg: 'w-12 h-12 border-3',
  }[size];

  const content = (
    <div role="status" aria-live="polite" aria-label={text || 'Yükleniyor'} className={`flex flex-col items-center gap-3 ${className}`}>
      <div aria-hidden="true" className={`${sizeCls} border-foreground-300 border-t-primary-500 rounded-full animate-spin`} />
      {text && <p className="text-sm text-foreground-500 animate-pulse">{text}</p>}
    </div>
  );

  if (fullPage) {
    return (
      <div className="flex items-center justify-center min-h-[200px] w-full">
        {content}
      </div>
    );
  }

  return content;
}