import type { ReactNode } from 'react';
import type { SegmentTone } from './SegmentedControl';

export interface SummaryRow {
  key: string;
  label: string;
  value: number;
  /** Yüzde/progress hesabı için payda. Verilmezse progress gösterilmez. */
  total?: number;
  tone?: SegmentTone;
  icon?: string;
}

interface SummaryStatsProps {
  rows: SummaryRow[];
  /** Üstte genel bir tamamlanma yüzdesi göstermek için toplam/sayılan değer. */
  completed?: number;
  completedTotal?: number;
  title?: string;
  icon?: string;
  headerRight?: ReactNode;
  className?: string;
}

const toneText: Record<SegmentTone, string> = {
  neutral: 'text-foreground-700',
  success: 'text-success-700 dark:text-success-300',
  danger: 'text-danger-700 dark:text-danger-300',
  warning: 'text-warning-700 dark:text-warning-300',
  primary: 'text-primary-700 dark:text-primary-300',
};

/**
 * GLOBAL ÖZET / KPI PANELİ — Shared UI tek kaynak.
 *
 * Referanstaki "Denetim Özeti" kartının ortak karşılığı. Sayı + opsiyonel
 * progress bar + ton ile satırlar gösterir; üstte genel tamamlanma yüzdesi
 * verilebilir. Tüm modüller (Saha Denetim, Risk, Eğitim, Acil Durum ...) aynı
 * özet dilini paylaşır. Renkler tamamen token'dan gelir.
 */
export default function SummaryStats({
  rows,
  completed,
  completedTotal,
  title,
  icon = 'ri-bar-chart-line',
  headerRight,
  className = '',
}: SummaryStatsProps) {
  const pct = typeof completed === 'number' && completedTotal
    ? Math.round((completed / completedTotal) * 100)
    : null;

  return (
    <div className={`isg-section isg-card-pad ${className}`}>
      <div className="flex items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-7 h-7 rounded-md bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className={`${icon} text-primary-600 dark:text-primary-400 text-sm`} />
          </span>
          {title && <span className="isg-text-card-title text-foreground-900 truncate">{title}</span>}
        </div>
        {headerRight}
      </div>

      {pct !== null && (
        <div className="mb-3">
          <div className="flex items-center justify-between text-xs mb-1">
            <span className="text-foreground-500">Tamamlanan</span>
            <span className="font-semibold text-foreground-900">%{pct}</span>
          </div>
          <div className="isg-progress">
            <span style={{ width: `${pct}%` }} data-tone="primary" />
          </div>
        </div>
      )}

      <div className="flex flex-col gap-2.5">
        {rows.map((r) => {
          const tone = r.tone ?? 'neutral';
          const rowPct = typeof r.total === 'number' && r.total > 0 ? Math.round((r.value / r.total) * 100) : null;
          return (
            <div key={r.key}>
              <div className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-1.5 text-foreground-600 min-w-0">
                  {r.icon ? <i className={`${r.icon} text-foreground-400`} /> : <span className="w-2 h-2 rounded-full" style={{ backgroundColor: `oklch(var(--${tone === 'neutral' ? 'background' : tone}-500))` }} />}
                  <span className="truncate">{r.label}</span>
                </span>
                <span className={`font-semibold whitespace-nowrap ${toneText[tone]}`}>
                  {r.value}{rowPct !== null && <span className="text-foreground-400 font-normal"> · %{rowPct}</span>}
                </span>
              </div>
              {rowPct !== null && (
                <div className="isg-progress mt-1.5">
                  <span style={{ width: `${rowPct}%` }} data-tone={tone} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}