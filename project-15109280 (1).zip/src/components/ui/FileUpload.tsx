import { useCallback, useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import IconButton from './IconButton';
import {
  DEFAULT_MAX_UPLOAD_SIZE,
  describeAccept,
  formatFileSize,
  getFileExtension,
  getFileIcon,
  getFileKindLabel,
  isSameFile,
  validateUploadFile,
  verifyFileContent,
} from '@/lib/fileUpload';

export interface UploadFile {
  id: string;
  name: string;
  size: number;
  ext: string;
  mime: string;
  status: 'uploading' | 'done' | 'error';
  progress: number;
  errorMessage?: string;
  /** Gerçek tarayıcı File nesnesi. Gerçek sunucu yüklemeleri (evrak vb.) için taşınır. */
  raw?: File;
  /** Mükerrer dosya tespiti için son değişiklik zamanı. */
  lastModified?: number;
}

interface FileUploadProps {
  accept?: string;
  multiple?: boolean;
  maxSize?: number; // bytes
  maxFiles?: number;
  files?: UploadFile[];
  onChange?: (files: UploadFile[]) => void;
  label?: string;
  helpText?: string;
  error?: string;
  required?: boolean;
  disabled?: boolean;
  className?: string;
  /** Dropzone iç ikonu (verilmezse varsayılan yükleme ikonu). */
  dropIcon?: ReactNode;
  /** Dropzone başlık metni. Verilirse varsayılan "sürükle/göz at" metnini değiştirir. */
  heading?: ReactNode;
  /** Verilirse başlık altında "veya" + buton görünümlü etiket gösterilir. */
  browseLabel?: string;
  /** Dropzone konteynerine ek sınıflar (yalnızca boyut/boşluk için). */
  dropClassName?: string;
}

let fileIdCounter = 0;

/**
 * İSGDenetim ORTAK Dosya Yükleme Motoru (TEK KAYNAK).
 *
 * Tüm paneller (Admin/OSGB/Firma/Uzman/Hekim) ve gelecekteki tüm sayfa/sekme/form/
 * modal/özellikler bu motoru kullanır. Ayrı bir file upload sistemi OLUŞTURULAMAZ.
 *
 * KİLİT: URL ile dosya yükleme YOKTUR. Yalnızca bilgisayardan dosya seçme ve
 * sürükle & bırak desteklenir.
 *
 * Desteklenenler:
 * - Dosya seç butonu / bilgisayardan dosya seçme
 * - Drag & Drop (iç içe geçişlerde titremeyen sayaçlı takip)
 * - Multi-file desteği (multiple)
 * - Yükleme ilerleme göstergesi (progress) ve iptali
 * - Başarılı / hatalı yükleme durumu, tekrar dene, dosya değiştirme/kaldırma
 * - Uzantı + MIME türü + boyut doğrulaması (merkezi `@/lib/fileUpload`)
 * - Mükerrer dosya engeli (ad + boyut)
 * - Boş bırakma / geçersiz drop güvenliği
 * - Klavye erişilebilirliği (Enter / Space)
 */
export default function FileUpload({
  accept,
  multiple,
  maxSize = DEFAULT_MAX_UPLOAD_SIZE,
  maxFiles,
  files: controlledFiles,
  onChange,
  label,
  helpText,
  error,
  required,
  disabled,
  className = '',
  dropIcon,
  heading,
  browseLabel,
  dropClassName = '',
}: FileUploadProps) {
  const [internalFiles, setInternalFiles] = useState<UploadFile[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [notice, setNotice] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const timersRef = useRef<Record<string, ReturnType<typeof setInterval>>>({});
  const replaceIdRef = useRef<string | null>(null);
  // Drag sayaç: çocuk elemanlar arasında gezinirken onDragLeave tetiklenip
  // dropzone'un titremesini önler. Yalnızca gerçekten alandan çıkınca sıfırlanır.
  const dragDepthRef = useRef(0);

  const files = controlledFiles ?? internalFiles;

  // Kontrollü ve kontrolsüz kullanımı tek yerden yönetir. Her değişiklikte
  // hem onChange'i tetikler hem de (kontrolsüzse) iç state'i günceller.
  const applyFiles = useCallback(
    (updater: (prev: UploadFile[]) => UploadFile[]) => {
      if (controlledFiles === undefined) {
        setInternalFiles((prev) => {
          const next = updater(prev);
          onChange?.(next);
          return next;
        });
      } else {
        onChange?.(updater(controlledFiles));
      }
    },
    [controlledFiles, onChange],
  );

  // startUpload senkron dışı çalışır; güncel applyFiles'a her zaman erişmek için
  // ref tutarız (stale closure önlemi — evrak upload zincirinde dosya kaybını önler).
  const applyFilesRef = useRef(applyFiles);
  useEffect(() => {
    applyFilesRef.current = applyFiles;
  }, [applyFiles]);

  const filesRef = useRef(files);
  useEffect(() => {
    filesRef.current = files;
  }, [files]);

  const startUpload = useCallback((id: string) => {
    let progress = 0;
    const timer = setInterval(() => {
      progress += 20;
      const done = progress >= 100;
      applyFilesRef.current((prev) =>
        prev.map((f) =>
          f.id === id
            ? { ...f, progress: Math.min(progress, 100), status: done ? 'done' : 'uploading' }
            : f,
        ),
      );
      if (done) {
        clearInterval(timer);
        delete timersRef.current[id];
      }
    }, 200);
    timersRef.current[id] = timer;
  }, []);

  useEffect(() => {
    return () => {
      Object.values(timersRef.current).forEach(clearInterval);
    };
  }, []);

  const addFiles = useCallback(
    async (rawFiles: File[], replaceId?: string) => {
      if (disabled) return;
      if (!rawFiles || rawFiles.length === 0) return;

      const skipped: string[] = [];
      const existing = replaceId ? filesRef.current.filter((f) => f.id !== replaceId) : filesRef.current;

      const accepted: UploadFile[] = [];
      for (const raw of rawFiles) {
        // Mükerrer kontrolü (ad + boyut) — sessizce ikinci kayıt oluşturmaz.
        if (existing.some((f) => isSameFile(f, raw)) || accepted.some((f) => isSameFile(f, raw))) {
          skipped.push(`${raw.name} (zaten ekli)`);
          continue;
        }
        const errorMessage = validateUploadFile(raw, { accept, maxSize });
        accepted.push({
          id: `file-${++fileIdCounter}`,
          name: raw.name,
          size: raw.size,
          ext: getFileExtension(raw.name),
          mime: raw.type || '',
          status: errorMessage ? 'error' : 'uploading',
          progress: 0,
          errorMessage: errorMessage || undefined,
          raw,
          lastModified: raw.lastModified,
        });
      }

      // GUV-19: Uzantı/MIME doğrulaması geçen dosyaların GERÇEK içeriği (magic
      // bytes) de denetlenir → belge/görsel gibi görünen ama çalıştırılabilir/aktif
      // içerik taşıyan dosyalar yüklenmeden reddedilir.
      for (const f of accepted) {
        if (f.status === 'error' || !f.raw) continue;
        const contentError = await verifyFileContent(f.raw);
        if (contentError) {
          f.status = 'error';
          f.errorMessage = contentError;
        }
      }

      if (accepted.length === 0) {
        setNotice(skipped.length > 0 ? `Atlandı: ${skipped.join(', ')}` : '');
        return;
      }

      // Değiştirme (replace): hedef dosyayı yeni dosya ile yer değiştir.
      if (replaceId) {
        const replacement = accepted[0];
        applyFiles((prev) => {
          const idx = prev.findIndex((f) => f.id === replaceId);
          if (idx === -1) return prev;
          const next = [...prev];
          next[idx] = replacement;
          return next;
        });
        if (replacement.status === 'uploading') startUpload(replacement.id);
        setNotice(skipped.length > 0 ? `Atlandı: ${skipped.join(', ')}` : '');
        return;
      }

      // maxFiles sınırı: eklenebilecek kadarını al.
      const currentCount = filesRef.current.length;
      const allowed = maxFiles ? Math.max(0, maxFiles - currentCount) : accepted.length;
      const toAdd = accepted.slice(0, allowed);
      const overflow = accepted.length - toAdd.length;

      if (toAdd.length === 0) {
        setNotice(
          overflow > 0
            ? `En fazla ${maxFiles} dosya ekleyebilirsiniz.`
            : `Atlandı: ${skipped.join(', ')}`,
        );
        return;
      }

      applyFiles((prev) => (multiple ? [...prev, ...toAdd] : toAdd));
      toAdd.forEach((f) => {
        if (f.status === 'uploading') startUpload(f.id);
      });

      const notes: string[] = [];
      if (skipped.length > 0) notes.push(`Atlandı: ${skipped.join(', ')}`);
      if (overflow > 0 && maxFiles) notes.push(`En fazla ${maxFiles} dosya eklenebilir.`);
      setNotice(notes.join(' • '));
    },
    [disabled, accept, maxSize, maxFiles, multiple, applyFiles, startUpload],
  );

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      dragDepthRef.current = 0;
      setIsDragOver(false);
      if (disabled) return;
      const dropped = e.dataTransfer?.files;
      if (!dropped || dropped.length === 0) return; // metin/link drop'u yok say
      addFiles(Array.from(dropped));
    },
    [addFiles, disabled],
  );

  const handleDragEnter = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      if (disabled) return;
      dragDepthRef.current += 1;
      setIsDragOver(true);
    },
    [disabled],
  );

  const handleDragOver = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      if (disabled) return;
      if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
      if (!isDragOver) setIsDragOver(true);
    },
    [disabled, isDragOver],
  );

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    dragDepthRef.current = Math.max(0, dragDepthRef.current - 1);
    if (dragDepthRef.current === 0) setIsDragOver(false);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    const raw = Array.from(e.target.files);
    const replaceId = replaceIdRef.current;
    replaceIdRef.current = null;
    if (raw.length === 0) return;
    addFiles(replaceId ? raw.slice(0, 1) : raw, replaceId || undefined);
    e.target.value = '';
  };

  const removeFile = (id: string) => {
    if (timersRef.current[id]) {
      clearInterval(timersRef.current[id]);
      delete timersRef.current[id];
    }
    setNotice('');
    applyFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const retryFile = (id: string) => {
    setNotice('');
    applyFiles((prev) =>
      prev.map((f) =>
        f.id === id ? { ...f, status: 'uploading', progress: 0, errorMessage: undefined } : f,
      ),
    );
    startUpload(id);
  };

  const replaceFile = (id: string) => {
    replaceIdRef.current = id;
    inputRef.current?.click();
  };

  const hintText = helpText ?? `${describeAccept(accept)} · Maksimum ${formatFileSize(maxSize)}`;

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}

      <div
        onDragEnter={handleDragEnter}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={() => !disabled && inputRef.current?.click()}
        role="button"
        tabIndex={disabled ? -1 : 0}
        aria-label={label ? `${label} — dosya seç` : 'Dosya seç'}
        aria-disabled={disabled}
        onKeyDown={(e) => {
          if (disabled) return;
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            inputRef.current?.click();
          }
        }}
        className={`relative flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed p-6 cursor-pointer transition-colors ${
          isDragOver
            ? 'border-primary-400 bg-primary-50/50'
            : error
            ? 'border-danger-300 bg-danger-50/30'
            : 'border-background-300 bg-background-100 hover:bg-background-200'
        } ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${dropClassName}`}
      >
        {dropIcon ?? <i className="ri-upload-cloud-2-line text-2xl text-foreground-400" />}
        {heading || browseLabel ? (
          <>
            <p className="text-sm font-medium text-foreground-700 text-center">{heading}</p>
            {browseLabel && (
              <>
                <span className="text-xs text-foreground-400">veya</span>
                <span className="isg-btn isg-btn-primary isg-btn-sm pointer-events-none">
                  <i className="ri-upload-2-line" /> {browseLabel}
                </span>
              </>
            )}
          </>
        ) : (
          <p className="text-sm text-foreground-600 text-center">
            Dosyaları sürükleyip bırakın veya{' '}
            <span className="text-primary-500 font-medium">göz atın</span>
          </p>
        )}
        {hintText && <p className="text-xs text-foreground-400 text-center">{hintText}</p>}
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          className="hidden"
          onChange={handleChange}
          disabled={disabled}
        />
      </div>

      {notice && (
        <p className="mt-1.5 text-xs text-warning-600 flex items-start gap-1" role="status">
          <i className="ri-error-warning-line mt-px" />
          {notice}
        </p>
      )}

      {files.length > 0 && (
        <ul className="mt-3 space-y-2">
          {files.map((file) => (
            <li
              key={file.id}
              className="flex items-center gap-3 p-2.5 rounded-md border isg-divider bg-background-100"
            >
              <div className="w-9 h-9 rounded-md bg-background-200 flex items-center justify-center flex-shrink-0">
                <i className={`${getFileIcon(file.ext, file.mime)} text-foreground-500`} />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-medium text-foreground-800 truncate">{file.name}</p>
                  <span className="text-xs text-foreground-400 flex-shrink-0">
                    {formatFileSize(file.size)}
                  </span>
                </div>

                <div className="flex items-center gap-2 mt-0.5">
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase bg-secondary-100 text-secondary-900">
                    {getFileKindLabel(file.ext, file.mime)}
                  </span>
                </div>

                {file.status === 'uploading' && (
                  <div className="mt-1.5 h-1 rounded-full bg-background-200 overflow-hidden">
                    <div
                      className="h-full bg-primary-500 transition-all duration-200"
                      style={{ width: `${file.progress}%` }}
                    />
                  </div>
                )}
                {file.status === 'done' && (
                  <p className="mt-1 text-xs text-success-600 flex items-center gap-1">
                    <i className="ri-checkbox-circle-line" /> Yüklendi
                  </p>
                )}
                {file.status === 'error' && (
                  <p className="mt-1 text-xs text-danger-600 flex items-start gap-1">
                    <i className="ri-error-warning-line mt-px" />
                    {file.errorMessage || 'Dosya yüklenemedi.'}
                  </p>
                )}
              </div>

              <div className="flex items-center gap-1 flex-shrink-0">
                {file.status === 'uploading' && (
                  <IconButton
                    icon={<i className="ri-stop-circle-line" />}
                    variant="ghost"
                    size="sm"
                    label="Yüklemeyi iptal et"
                    onClick={() => removeFile(file.id)}
                  />
                )}
                {file.status === 'done' && (
                  <IconButton
                    icon={<i className="ri-refresh-line" />}
                    variant="ghost"
                    size="sm"
                    label="Dosyayı değiştir"
                    onClick={() => replaceFile(file.id)}
                  />
                )}
                {file.status === 'error' && (
                  <IconButton
                    icon={<i className="ri-refresh-line" />}
                    variant="ghost"
                    size="sm"
                    label="Tekrar dene"
                    onClick={() => retryFile(file.id)}
                  />
                )}
                <IconButton
                  icon={<i className="ri-close-line" />}
                  variant="ghost"
                  size="sm"
                  label="Kaldır"
                  onClick={() => removeFile(file.id)}
                />
              </div>
            </li>
          ))}
        </ul>
      )}

      {error && (
        <p className="mt-1.5 text-xs text-danger-600 flex items-center gap-1">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
    </div>
  );
}