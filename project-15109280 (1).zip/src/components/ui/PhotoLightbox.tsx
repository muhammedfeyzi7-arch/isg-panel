import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Z_LAYERS } from '@/utils/layers';
import { downloadBlobFile } from '@/lib/downloadFile';

export interface PhotoLightboxItem {
  src: string;
  alt?: string;
  fileName?: string;
}

interface PhotoLightboxProps {
  items: PhotoLightboxItem[];
  index?: number;
  onClose: () => void;
  onIndexChange?: (index: number) => void;
  title?: string;
  allowDownload?: boolean;
  /** Merkezi katman önceliği. Varsayılan: doküman önizleme katmanı. */
  zIndex?: number;
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

// ---------- İSGDenetim GLOBAL FOTOĞRAF GÖRÜNTÜLEYİCİ (TEK KAYNAK) ----------
// Tüm modüllerin (Saha Denetim, Risk, Tutanak, Envanter, Zimmet,
// Personel, Firma, Evrak, Mesajlaşma...) fotoğraf thumbnail'ine tıklanınca
// açtığı TEK merkezî lightbox. Yeni sekme/sayfa AÇMAZ, native image popup
// KULLANMAZ. Overlay tüm ekranı kaplar; fotoğraf oranı korunur (object-contain),
// zoom (tıkla/tekerlek), fare ile gezinme, çoklu galeride ileri/geri (ok
// tuşları + sayaç), ESC ile kapanma ve dış overlay tıklamasıyla kapanma
// davranışı buradan yönetilir. Renkler tema token mantığıyla, geometri light/dark
// ortaktır; sayfa bazlı ayrı lightbox ÜRETİLMEZ.

export default function PhotoLightbox({
  items,
  index = 0,
  onClose,
  onIndexChange,
  title,
  allowDownload = true,
  zIndex = Z_LAYERS.documentPreview,
}: PhotoLightboxProps) {
  const safeIndex = Math.min(Math.max(index, 0), Math.max(items.length - 1, 0));
  const [active, setActive] = useState(safeIndex);
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const stageRef = useRef<HTMLDivElement>(null);
  const dragRef = useRef({ dragging: false, moved: false, sx: 0, sy: 0, ox: 0, oy: 0 });

  const item = items[active];
  const hasGallery = items.length > 1;
  const currentTitle = title ?? item?.fileName ?? item?.alt ?? 'Fotoğraf';

  // Dışarıdan gelen indeks değişirse iç durumu eşitle.
  useEffect(() => {
    setActive(safeIndex);
  }, [safeIndex]);

  // Gezinmede zoom sıfırlanır.
  useEffect(() => {
    setScale(1);
    setOffset({ x: 0, y: 0 });
  }, [active]);

  const go = useCallback(
    (delta: number) => {
      if (items.length <= 1) return;
      setActive((prev) => {
        const next = (prev + delta + items.length) % items.length;
        onIndexChange?.(next);
        return next;
      });
    },
    [items.length, onIndexChange],
  );

  // Klavye: ESC kapatır, oklar gezinir. Capture fazı → alttaki modal/picker'a sızmaz.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopImmediatePropagation();
        e.preventDefault();
        onClose();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(-1);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        go(1);
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [go, onClose]);

  // Gövde kaydırma kilidi + odak.
  useEffect(() => {
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    stageRef.current?.focus();
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, []);

  // Tekerlek ile zoom.
  useEffect(() => {
    const el = stageRef.current;
    if (!el) return undefined;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      setScale((s) => clamp(s * (1 - e.deltaY * 0.0016), 1, 5));
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  // Zoom %100'e döndüğünde gezinme sıfırlanır.
  useEffect(() => {
    if (scale <= 1) setOffset({ x: 0, y: 0 });
  }, [scale]);

  const onPointerDown = (e: React.PointerEvent) => {
    if (scale <= 1) return;
    dragRef.current = { dragging: true, moved: false, sx: e.clientX, sy: e.clientY, ox: offset.x, oy: offset.y };
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = dragRef.current;
    if (!d.dragging) return;
    const dx = e.clientX - d.sx;
    const dy = e.clientY - d.sy;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) d.moved = true;
    setOffset({ x: d.ox + dx, y: d.oy + dy });
  };
  const onPointerUp = () => {
    dragRef.current.dragging = false;
  };

  const toggleZoom = () => {
    if (dragRef.current.moved) {
      dragRef.current.moved = false;
      return;
    }
    setScale((s) => (s > 1 ? 1 : 2.5));
  };

  const handleDownload = useCallback(async () => {
    if (!item?.src) return;
    try {
      const res = await fetch(item.src);
      const blob = await res.blob();
      // Merkezî indirme: anlamlı/güvenli dosya adı (UUID yok).
      downloadBlobFile(blob, item.fileName || item.alt || 'Fotograf');
    } catch {
      window.open(item.src, '_blank', 'noopener');
    }
  }, [item]);

  const navBtnClass =
    'isg-btn isg-btn-icon isg-btn-lg !text-white bg-white/10 hover:bg-white/25 backdrop-blur-sm cursor-pointer disabled:opacity-30';
  const toolBtnClass =
    'isg-btn isg-btn-icon isg-btn-md !text-white bg-white/10 hover:bg-white/25 backdrop-blur-sm cursor-pointer';

  const content = useMemo(() => {
    if (!item) return null;
    return (
      <div
        className="fixed inset-0 flex items-center justify-center"
        style={{ zIndex }}
        onClick={onClose}
        role="dialog"
        aria-modal="true"
        aria-label="Fotoğraf görüntüleyici"
      >
        {/* Arka perde — tema dan bağımsız koyu, fotoğraf okunurluğu için */}
        <div className="absolute inset-0 bg-black/85" aria-hidden="true" />

        {/* Üst şerit: başlık + sayaç + araçlar */}
        <div
          className="absolute top-0 left-0 right-0 z-10 flex items-center justify-between gap-3 px-3 py-3 md:px-5 md:py-4"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="min-w-0">
            <p className="truncate text-sm font-medium text-white/90">{currentTitle}</p>
            {hasGallery && (
              <p className="text-xs text-white/60">
                {active + 1} / {items.length}
              </p>
            )}
          </div>
          <div className="flex items-center gap-2">
            {allowDownload && (
              <button type="button" className={toolBtnClass} onClick={handleDownload} aria-label="İndir" title="İndir">
                <i className="ri-download-2-line" />
              </button>
            )}
            <button
              type="button"
              className={toolBtnClass}
              onClick={onClose}
              aria-label="Kapat"
              title="Kapat"
            >
              <i className="ri-close-line" />
            </button>
          </div>
        </div>

        {/* Sahne — fotoğraf oranı korunur, dışı kırpılmaz */}
        <div
          ref={stageRef}
          tabIndex={-1}
          className="isg-scroll-pane relative z-[5] flex h-full w-full items-center justify-center overflow-hidden p-4 outline-none md:p-16"
        >
          <img
            src={item.src}
            alt={item.alt || currentTitle}
            draggable={false}
            onClick={(e) => {
              e.stopPropagation();
              toggleZoom();
            }}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerLeave={onPointerUp}
            style={{
              transform: `translate(${offset.x}px, ${offset.y}px) scale(${scale})`,
              cursor: scale > 1 ? 'grab' : 'zoom-in',
              transition: dragRef.current.dragging ? 'none' : 'transform 0.15s ease',
            }}
            className="max-h-full max-w-full select-none object-contain"
          />

          {hasGallery && (
            <>
              <button
                type="button"
                className={`absolute left-3 top-1/2 -translate-y-1/2 ${navBtnClass}`}
                onClick={(e) => {
                  e.stopPropagation();
                  go(-1);
                }}
                aria-label="Önceki fotoğraf"
                title="Önceki"
              >
                <i className="ri-arrow-left-s-line" />
              </button>
              <button
                type="button"
                className={`absolute right-3 top-1/2 -translate-y-1/2 ${navBtnClass}`}
                onClick={(e) => {
                  e.stopPropagation();
                  go(1);
                }}
                aria-label="Sonraki fotoğraf"
                title="Sonraki"
              >
                <i className="ri-arrow-right-s-line" />
              </button>
            </>
          )}
        </div>

        {/* Alt sayaç (galeri) — ekranın altında sabit */}
        {hasGallery && (
          <div
            className="absolute bottom-4 left-1/2 z-10 -translate-x-1/2 rounded-full bg-white/10 px-3 py-1 text-xs font-medium text-white/90 backdrop-blur-sm"
            onClick={(e) => e.stopPropagation()}
          >
            {active + 1} / {items.length}
          </div>
        )}
      </div>
    );
  }, [item, active, items.length, hasGallery, currentTitle, scale, offset, allowDownload]);

  if (!item) return null;
  return createPortal(content, document.body);
}