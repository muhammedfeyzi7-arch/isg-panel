import {
  forwardRef,
  useCallback,
  useEffect,
  useId,
  useRef,
  useState,
  type ChangeEvent,
  type InputHTMLAttributes,
} from 'react';
import PickerPortal from './PickerPortal';

interface TimePickerProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helpText?: string;
  containerClassName?: string;
}

// ---------- İSGDenetim GLOBAL SAAT SEÇİCİ (TEK KAYNAK) ----------
// Native <input type="time"> yerine tüm sistem için tek merkezi saat paneli.
// API aynıdır: `value` = 'HH:MM', `onChange` bir input change event'i alır
// (event.target.value). Ayrı Saat (00-23) ve Dakika (00-59) kolonları; seçili
// değer belirgin; mouse + scroll + klavye ile seçilebilir; alana doğrudan
// yazılabilir ve geçersiz değer kabul edilmez. Panel viewport dışına taşmaz,
// modal katmanını bozmaz, ESC = iptal, Enter = onay.

const HOURS = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, '0'));
const MINUTES = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0'));

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

function isValidTime(hh: string, mm: string): boolean {
  const h = Number(hh);
  const m = Number(mm);
  return Number.isInteger(h) && h >= 0 && h <= 23 && Number.isInteger(m) && m >= 0 && m <= 59;
}

function parseTime(v?: string): { h: string; m: string } | null {
  if (!v) return null;
  const match = /^(\d{1,2}):(\d{2})$/.exec(v.trim());
  if (!match) return null;
  const hh = pad(Number(match[1]));
  const mm = pad(Number(match[2]));
  return isValidTime(hh, mm) ? { h: hh, m: mm } : null;
}

const TimePicker = forwardRef<HTMLInputElement, TimePickerProps>(function TimePicker(
  {
    label,
    error,
    helpText,
    containerClassName = '',
    className = '',
    required,
    id,
    value,
    onChange,
    disabled,
    placeholder,
    name,
  },
  ref,
) {
  const generatedId = useId();
  const fieldId = id ?? generatedId;
  const hasError = !!error;
  const errorId = hasError ? `${fieldId}-error` : undefined;
  const helpId = helpText ? `${fieldId}-help` : undefined;

  const valueStr = typeof value === 'string' ? value : '';
  const anchorRef = useRef<HTMLDivElement>(null);
  const hourColRef = useRef<HTMLDivElement>(null);
  const minuteColRef = useRef<HTMLDivElement>(null);
  const hourSelRef = useRef<HTMLButtonElement>(null);
  const minuteSelRef = useRef<HTMLButtonElement>(null);

  const [open, setOpen] = useState(false);
  const [text, setText] = useState(valueStr);
  const [selH, setSelH] = useState('00');
  const [selM, setSelM] = useState('00');

  // Dış değer değiştiğinde metni eşitle (kullanıcı yazmıyorken).
  useEffect(() => {
    setText(valueStr);
  }, [valueStr]);

  const emit = useCallback(
    (v: string) => {
      onChange?.({ target: { value: v, name } } as unknown as ChangeEvent<HTMLInputElement>);
    },
    [onChange, name],
  );

  const openPicker = useCallback(() => {
    if (disabled) return;
    const parsed = parseTime(valueStr);
    const now = new Date();
    setSelH(parsed ? parsed.h : pad(now.getHours()));
    setSelM(parsed ? parsed.m : pad(now.getMinutes()));
    setOpen(true);
  }, [disabled, valueStr]);

  useEffect(() => {
    if (!open) return undefined;
    const raf = requestAnimationFrame(() => {
      const scrollCenter = (col: HTMLDivElement | null, btn: HTMLButtonElement | null) => {
        if (!col || !btn) return;
        col.scrollTop = btn.offsetTop - col.clientHeight / 2 + btn.clientHeight / 2;
      };
      scrollCenter(hourColRef.current, hourSelRef.current);
      scrollCenter(minuteColRef.current, minuteSelRef.current);
    });
    return () => cancelAnimationFrame(raf);
  }, [open]);

  const handleTextChange = (e: ChangeEvent<HTMLInputElement>) => {
    // Yalnızca rakam ve tek ':' kabul edilir; aşırı uzunluk kırpılır.
    let raw = e.target.value.replace(/[^\d:]/g, '');
    if (raw.length > 5) raw = raw.slice(0, 5);
    setText(raw);
    const parsed = parseTime(raw);
    if (parsed) emit(`${parsed.h}:${parsed.m}`);
  };

  const handleBlur = () => {
    const parsed = parseTime(text);
    if (parsed) {
      setText(`${parsed.h}:${parsed.m}`);
      emit(`${parsed.h}:${parsed.m}`);
    } else {
      // Geçersiz / boş giriş kabul edilmez → son geçerli değere dön.
      setText(valueStr);
    }
  };

  const confirm = () => {
    emit(`${selH}:${selM}`);
    setOpen(false);
  };

  const panelKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      confirm();
    }
  };

  const describedBy = [errorId, helpId].filter(Boolean).join(' ') || undefined;

  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label htmlFor={fieldId} className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}

      <div ref={anchorRef} className="relative">
        <input
          ref={ref}
          id={fieldId}
          type="text"
          inputMode="numeric"
          name={name}
          value={text}
          disabled={disabled}
          placeholder={placeholder || 'ss:dd'}
          onChange={handleTextChange}
          onBlur={handleBlur}
          onClick={openPicker}
          onFocus={openPicker}
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown' && !open) {
              e.preventDefault();
              openPicker();
            }
          }}
          aria-haspopup="dialog"
          aria-expanded={open}
          aria-invalid={hasError || undefined}
          aria-describedby={describedBy}
          className={`isg-input w-full pr-8 ${hasError ? 'isg-input-error' : ''} ${className}`}
        />
        <button
          type="button"
          tabIndex={-1}
          aria-label="Saat seç"
          onClick={openPicker}
          disabled={disabled}
          className="absolute right-1.5 top-1/2 -translate-y-1/2 w-6 h-6 flex items-center justify-center rounded text-foreground-500 hover:text-foreground-800 cursor-pointer"
        >
          <i className="ri-time-line" />
        </button>
      </div>

      <PickerPortal anchorRef={anchorRef} open={open} onClose={() => setOpen(false)} onKeyDown={panelKeyDown} minWidth={180}>
        <div className="p-2.5 w-[180px]">
          <div className="grid grid-cols-2 gap-2 mb-2">
            <span className="text-center isg-text-micro font-semibold text-foreground-600">Saat</span>
            <span className="text-center isg-text-micro font-semibold text-foreground-600">Dakika</span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div ref={hourColRef} className="h-[180px] overflow-y-auto isg-scroll-pane rounded-md border border-background-300/60 dark:border-background-400/35 p-0.5">
              {HOURS.map((h) => {
                const active = h === selH;
                return (
                  <button
                    key={h}
                    type="button"
                    ref={active ? hourSelRef : undefined}
                    onClick={() => setSelH(h)}
                    className={`w-full h-7 rounded text-sm flex items-center justify-center transition-colors cursor-pointer ${
                      active
                        ? 'bg-primary-500 text-inverse font-semibold'
                        : 'text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40'
                    }`}
                  >
                    {h}
                  </button>
                );
              })}
            </div>

            <div ref={minuteColRef} className="h-[180px] overflow-y-auto isg-scroll-pane rounded-md border border-background-300/60 dark:border-background-400/35 p-0.5">
              {MINUTES.map((m) => {
                const active = m === selM;
                return (
                  <button
                    key={m}
                    type="button"
                    ref={active ? minuteSelRef : undefined}
                    onClick={() => setSelM(m)}
                    className={`w-full h-7 rounded text-sm flex items-center justify-center transition-colors cursor-pointer ${
                      active
                        ? 'bg-primary-500 text-inverse font-semibold'
                        : 'text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40'
                    }`}
                  >
                    {m}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex items-center justify-between gap-2 mt-2.5 pt-2.5 border-t border-background-300/40 dark:border-background-400/30">
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="isg-btn isg-btn-secondary isg-btn-sm"
            >
              İptal
            </button>
            <button type="button" onClick={confirm} className="isg-btn isg-btn-primary isg-btn-sm">
              Tamam
            </button>
          </div>
        </div>
      </PickerPortal>

      {hasError && (
        <p id={errorId} className="mt-1 text-xs text-danger-600 flex items-center gap-1">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p id={helpId} className="mt-1 text-xs text-foreground-500">{helpText}</p>
      )}
    </div>
  );
});

export default TimePicker;