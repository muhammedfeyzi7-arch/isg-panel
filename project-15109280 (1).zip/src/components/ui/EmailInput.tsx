import { useMemo, useRef, useState } from 'react';
import DropdownPanel from './DropdownPanel';
import { turkishIncludes } from '@/utils/turkishText';

const COMMON_DOMAINS = [
  'gmail.com',
  'hotmail.com',
  'outlook.com',
  'yahoo.com',
  'icloud.com',
  'yandex.com',
  'protonmail.com',
];

interface EmailInputProps {
  label?: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  error?: string;
  helpText?: string;
  containerClassName?: string;
  name?: string;
  id?: string;
  autoComplete?: string;
  onBlur?: () => void;
}

function isDomainComplete(domain: string): boolean {
  // İlk nokta girildiyse domain tamamlanmış sayılır. Çoklu TLD (.com.tr, .co.uk vb.)
  // yazımında öneri dropdown'ı yeniden açılıp kapanmaz (flicker önlenir); kullanıcı
  // kendi kurumsal domain'ini rahatça yazabilir.
  return domain.includes('.');
}

/**
 * Ortak e-posta girişi. "@" karakterinden sonra domain önerisi sunar
 * (gmail.com, outlook.com vb.). Kullanıcının girdiğini zorla değiştirmez,
 * yalnızca öneri verir. Enter/Tab ile öneri tamamlanabilir, Esc kapatır.
 * Autocomplete açıkken Enter form submit'ini tetiklemez.
 */
export default function EmailInput({
  label,
  value,
  onChange,
  placeholder = 'ornek@mail.com',
  required,
  disabled,
  error,
  helpText,
  containerClassName = '',
  name,
  id,
  autoComplete,
  onBlur,
}: EmailInputProps) {
  const [open, setOpen] = useState(false);
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const anchorRef = useRef<HTMLInputElement>(null);

  const atIndex = value.indexOf('@');
  const domainPart = atIndex >= 0 ? value.slice(atIndex + 1) : '';

  const suggestions = useMemo(() => {
    if (atIndex < 0 || isDomainComplete(domainPart)) return [];
    return COMMON_DOMAINS.filter((d) => turkishIncludes(d, domainPart));
  }, [atIndex, domainPart]);

  const shouldShow = open && suggestions.length > 0 && !disabled;

  const hasError = !!error;
  const stateCls = hasError ? 'isg-input-error' : '';

  const applySuggestion = (domain: string) => {
    const next = `${value.slice(0, atIndex + 1)}${domain}`;
    onChange(next);
    setOpen(false);
    setHighlightIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      if (suggestions.length === 0) return;
      e.preventDefault();
      setOpen(true);
      setHighlightIndex((prev) => {
        if (prev < 0) return e.key === 'ArrowDown' ? 0 : suggestions.length - 1;
        if (e.key === 'ArrowDown') return prev < suggestions.length - 1 ? prev + 1 : 0;
        return prev > 0 ? prev - 1 : suggestions.length - 1;
      });
      return;
    }
    if (e.key === 'Tab') {
      // Tab: kullanıcı açıkça tamamlamak istediğinde ilk öneriyi uygular (bilinçli aksiyon).
      if (open && highlightIndex >= 0 && suggestions[highlightIndex]) {
        e.preventDefault();
        applySuggestion(suggestions[highlightIndex]);
      } else if (open && suggestions.length > 0) {
        e.preventDefault();
        applySuggestion(suggestions[0]);
      }
      return;
    }
    if (e.key === 'Enter') {
      // Enter ARTIK email'i otomatik değiştirmez — kullanıcının girdiği değer korunur.
      setOpen(false);
      setHighlightIndex(-1);
      return;
    }
    if (e.key === 'Escape') {
      setOpen(false);
      setHighlightIndex(-1);
      return;
    }
  };

  return (
    <div className={`w-full relative ${containerClassName}`}>
      {label && (
        <label className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}
      <div className="relative">
        <i className="ri-mail-line absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400 pointer-events-none" />
        <input
          ref={anchorRef}
          id={id}
          name={name}
          type="email"
          value={value}
          onChange={(e) => {
            onChange(e.target.value);
            setOpen(true);
            setHighlightIndex(-1);
          }}
          onFocus={() => setOpen(true)}
          onBlur={onBlur}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          required={required}
          disabled={disabled}
          autoComplete={autoComplete}
          className={`isg-input w-full pl-9 ${stateCls} ${
            disabled ? 'opacity-50 cursor-not-allowed' : ''
          }`}
        />
      </div>

      {shouldShow && (
        <DropdownPanel
          open={open}
          anchorRef={anchorRef}
          onClose={() => setOpen(false)}
          className="isg-popover"
        >
          <div className="px-3 py-1.5 border-b isg-divider isg-text-micro text-foreground-400">
            Domain önerileri
          </div>
          <div className="overflow-y-auto flex-1 min-h-0">
          {suggestions.map((d, idx) => (
            <button
              key={d}
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={() => applySuggestion(d)}
              onMouseEnter={() => setHighlightIndex(idx)}
              className={`w-full flex items-center justify-between px-3 py-2 text-left text-sm ${
                idx === highlightIndex ? 'bg-primary-50 text-primary-700' : 'text-foreground-800 hover:bg-background-200'
              }`}
            >
              <span className="truncate">{value.slice(0, atIndex + 1)}{d}</span>
              <i className="ri-mail-add-line text-foreground-400" />
            </button>
          ))}
          </div>
        </DropdownPanel>
      )}

      {hasError && (
        <p className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p className="isg-form-help">{helpText}</p>
      )}
    </div>
  );
}