export type ListActionVariant = 'default' | 'danger' | 'warning' | 'success' | 'info';

export interface ListAction {
  label: string;
  icon?: string;
  variant?: ListActionVariant;
  onSelect: () => void;
}

interface ActionSheetProps {
  actions: ListAction[];
  onSelect: (action: ListAction) => void;
}

const textStyles: Record<ListActionVariant, string> = {
  default: 'text-foreground-700',
  danger: 'text-danger-600',
  warning: 'text-warning-600',
  success: 'text-success-600',
  info: 'text-primary-600',
};

const iconBgStyles: Record<ListActionVariant, string> = {
  default: 'bg-background-200 text-foreground-500',
  danger: 'bg-danger-100 text-danger-600',
  warning: 'bg-warning-100 text-warning-600',
  success: 'bg-success-100 text-success-600',
  info: 'bg-primary-100 text-primary-600',
};

/**
 * Global Action Sheet içerik renderer'ı. Global Mobile Bottom Sheet Engine'inin
 * `content` alanına verilir. Görsel dil mevcut bottom sheet referansıyla birebir
 * aynıdır (aynı spacing, radius, typography, dark/light token'ları).
 *
 * İçerik dinamiktir: her panel/sekme kendi gerçek `ListAction` listesini sağlar,
 * bu renderer aynı kalır.
 */
export default function ActionSheet({ actions, onSelect }: ActionSheetProps) {
  return (
    <div className="space-y-1">
      {actions.map((action, index) => {
        const variant = action.variant || 'default';
        return (
          <button
            key={`${action.label}-${index}`}
            type="button"
            onClick={() => onSelect(action)}
            className="w-full flex items-center gap-3 px-3 py-3 rounded-xl hover:bg-background-200 dark:hover:bg-background-300/40 active:bg-background-200 dark:active:bg-background-300/40 transition-colors text-left cursor-pointer"
          >
            {action.icon && (
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${iconBgStyles[variant]}`}>
                <i className={`${action.icon} text-base`} />
              </div>
            )}
            <span className={`flex-1 text-sm font-medium ${textStyles[variant]}`}>
              {action.label}
            </span>
            <i className="ri-arrow-right-s-line text-foreground-400 flex-shrink-0" />
          </button>
        );
      })}
    </div>
  );
}