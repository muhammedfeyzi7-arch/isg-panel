import { useEffect, useRef, useState } from 'react';
import DropdownPanel from './DropdownPanel';
import { useRovingFocus } from '@/hooks/useKeyboardNav';

export interface ContextMenuItem {
  label: string;
  /** Tam icon class'ı (renk dahil), örn. "ri-delete-bin-line" */
  icon: string;
  variant?: 'default' | 'danger';
  onClick: () => void;
}

interface ContextMenuProps {
  items: ContextMenuItem[];
  triggerIcon?: string;
}

/**
 * Ortak "3 nokta" bağlam menüsü — mobil kartlardaki ve satır aksiyonlarındaki
 * açılır menü için TEK kaynak. Admin/OSGB/Firma/Uzman/Hekim panellerinin tamamı
 * aynı bu bileşeni kullanır. Sayfaya özel popover menü YAZILAMAZ.
 *
 * Global DropdownPanel üzerinden body'ye portal edilir: kart/overflow tarafından
 * kırpılmaz, sağa hizalı açılır, ekran dışına taşarsa yön değiştirir, dışarı
 * tıklama/ESC ile kapanır. Z-index global katman standardını kullanır.
 *
 * Klavye: menü açılınca ilk öğeye odaklanır; Arrow Up/Down + Home/End ile
 * gezilir, Enter/Space native click ile seçer, Escape kapatır.
 */
export default function ContextMenu({
  items,
  triggerIcon = 'ri-more-2-line',
}: ContextMenuProps) {
  const [open, setOpen] = useState(false);
  const anchorRef = useRef<HTMLButtonElement>(null);

  const { itemRef, onKeyDown, focusIndex } = useRovingFocus({
    itemCount: items.length,
    orientation: 'vertical',
    activateOnNavigate: false,
    onEscape: () => setOpen(false),
  });

  // Menü açıldığında ilk öğeye odaklan — klavye navigasyonu için.
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => focusIndex(0), 0);
    return () => clearTimeout(t);
  }, [open, focusIndex]);

  return (
    <div className="relative flex-shrink-0">
      <button
        ref={anchorRef}
        type="button"
        onClick={(e) => {
          e.stopPropagation();
          setOpen((p) => !p);
        }}
        onKeyDown={(e) => {
          if (e.key === 'Escape') setOpen(false);
        }}
        className="w-10 h-10 flex items-center justify-center rounded-md hover:bg-background-200/60 transition-colors cursor-pointer text-foreground-500"
        aria-label="Daha fazla"
        aria-haspopup="menu"
        aria-expanded={open}
      >
        <i className={triggerIcon} />
      </button>

      <DropdownPanel
        open={open}
        anchorRef={anchorRef}
        onClose={() => setOpen(false)}
        role="menu"
        align="end"
        minWidth={160}
        className="isg-popover py-1"
      >
        {items.map((item, idx) => (
          <button
            key={item.label}
            type="button"
            ref={itemRef(idx)}
            role="menuitem"
            onClick={(e) => {
              e.stopPropagation();
              setOpen(false);
              item.onClick();
            }}
            onKeyDown={(e) => onKeyDown(e, idx)}
            className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 cursor-pointer whitespace-nowrap ${
              item.variant === 'danger'
                ? 'text-danger-600 hover:bg-danger-50/50 dark:text-danger-500 dark:hover:bg-danger-500/15'
                : 'text-foreground-700 hover:bg-primary-50/70 dark:hover:bg-primary-500/15'
            }`}
          >
            <i className={item.icon} />
            {item.label}
          </button>
        ))}
      </DropdownPanel>
    </div>
  );
}