import { useEffect, useRef } from 'react';
import { useToastActions, useToastState } from '@/hooks/useToast';
import type { ToastItem, ToastType } from '@/hooks/useToast';
import { Z_LAYERS } from '@/utils/layers';

// İkonlar: aynı anlam her yerde aynı ikon (Shared Icon dili).
const iconMap: Record<ToastType, string> = {
  success: 'ri-checkbox-circle-line',
  info: 'ri-information-line',
  warning: 'ri-alert-line',
  error: 'ri-close-circle-line',
};

// Semantic renk yalnızca accent olarak: -700 tonu hem light (derin) hem dark (açık) tema için okunaklı.
const iconColorMap: Record<ToastType, string> = {
  success: 'text-success-700',
  info: 'text-primary-700',
  warning: 'text-warning-700',
  error: 'text-danger-700',
};

const progressColorMap: Record<ToastType, string> = {
  success: 'bg-success-500',
  info: 'bg-primary-500',
  warning: 'bg-warning-500',
  error: 'bg-danger-500',
};

function ToastItemView({ toast, onClose }: { toast: ToastItem; onClose: (id: string) => void }) {
  // Hover pause: mouse üzerindeyken auto-dismiss timer durur, ayrılınca devam eder.
  const pausedRef = useRef(false);
  const progressRef = useRef<HTMLDivElement>(null);
  const duration = toast.duration ?? 0;

  // Timer + progress bar. Sadece bu toast'ı render eder (uygulamanın tamamını değil).
  // Progress genişliği doğrudan DOM üzerinden güncellenir — her tick'te state/render yok.
  useEffect(() => {
    if (!duration || duration <= 0) {
      if (progressRef.current) progressRef.current.style.width = '100%';
      return;
    }
    let remaining = duration;
    let last = performance.now();
    if (progressRef.current) progressRef.current.style.width = '100%';

    const timer = setInterval(() => {
      const now = performance.now();
      if (!pausedRef.current) {
        remaining -= now - last;
        if (remaining <= 0) {
          clearInterval(timer);
          onClose(toast.id);
          return;
        }
        if (progressRef.current) {
          progressRef.current.style.width = `${(remaining / duration) * 100}%`;
        }
      }
      last = now;
    }, 50);

    return () => clearInterval(timer);
  }, [duration, toast.id, onClose]);

  const handleAction = () => {
    toast.action?.onClick();
    onClose(toast.id);
  };

  return (
    <div
      className="pointer-events-auto w-full isg-toast shadow-modal dark:shadow-modal-dark rounded-lg overflow-hidden"
      role={toast.type === 'error' ? 'alert' : 'status'}
      onMouseEnter={() => { pausedRef.current = true; }}
      onMouseLeave={() => { pausedRef.current = false; }}
      onFocus={() => { pausedRef.current = true; }}
      onBlur={() => { pausedRef.current = false; }}
    >
      <div className="flex items-start gap-3 px-4 py-3">
        <i className={`${iconMap[toast.type]} text-lg mt-0.5 flex-shrink-0 ${iconColorMap[toast.type]}`} />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-foreground-950 leading-snug">{toast.title}</p>
          {toast.message && (
            <p className="text-xs mt-0.5 text-foreground-600 leading-relaxed break-words">{toast.message}</p>
          )}
          {toast.action && (
            <button
              onClick={handleAction}
              className="mt-2 text-xs font-semibold text-primary-700 hover:text-primary-800 whitespace-nowrap cursor-pointer"
            >
              {toast.action.label}
            </button>
          )}
        </div>
        <button
          onClick={() => onClose(toast.id)}
          className="flex-shrink-0 w-6 h-6 flex items-center justify-center rounded hover:bg-background-200 text-foreground-400 hover:text-foreground-700"
          aria-label="Kapat"
        >
          <i className="ri-close-line text-sm" />
        </button>
      </div>
      {toast.progress !== false && duration > 0 && (
        <div className="h-0.5 bg-background-200 w-full">
          <div
            ref={progressRef}
            className={`h-full ${progressColorMap[toast.type]}`}
            style={{ width: '100%' }}
          />
        </div>
      )}
    </div>
  );
}

export default function ToastManager() {
  const toasts = useToastState();
  const { removeToast } = useToastActions();

  if (toasts.length === 0) return null;

  return (
    <div
      className="fixed flex flex-col gap-2 pointer-events-none bottom-[calc(3rem+env(safe-area-inset-bottom)+0.5rem)] right-4 left-4 sm:left-auto sm:right-6 sm:bottom-6 sm:w-[380px]"
      style={{ zIndex: Z_LAYERS.toast }}
    >
      {toasts.map((toast) => (
        <ToastItemView key={toast.id} toast={toast} onClose={removeToast} />
      ))}
    </div>
  );
}