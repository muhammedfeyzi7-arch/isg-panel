import type { CSSProperties } from 'react';
import {
  ICON_REGISTRY,
  ICON_SIZES,
  ICON_TONES,
  resolveFileIcon,
  type IconSize,
  type IconTone,
} from '@/lib/icons/iconRegistry';

interface IconProps {
  /** Merkezî kayıttaki ikon adı (ör. "pdf", "download", "risk"). */
  name: string;
  /** Merkezî ölçek ya da doğrudan px (özel durumlar için). */
  size?: IconSize | number;
  /** Semantik ton. Verilmezse ikonun kayıtlı varsayılan tonu kullanılır. */
  tone?: IconTone;
  className?: string;
  /** Verilirse ikon anlamlı kabul edilir ve ekran okuyucuya bildirilir. */
  title?: string;
}

/**
 * MERKEZİ İKON BİLEŞENİ — İSGDenetim'in TEK ikon giriş noktası.
 *
 * Tüm modüller ikonu yalnızca buradan tüketir:
 *   <Icon name="pdf" size="md" />
 *   <Icon name="download" size="sm" tone="muted" />
 *
 * İkon adları, boyut ölçeği ve semantik tonlar `@/lib/icons/iconRegistry`
 * içinde TEK kaynaktan yönetilir. Böylece bir ikon/renk tek yerden değişince
 * TÜM panellerde, sekmelerde ve modallarda tutarlı biçimde güncellenir.
 */
export default function Icon({ name, size = 'md', tone, className = '', title }: IconProps) {
  const px = typeof size === 'number' ? size : ICON_SIZES[size];
  const def = ICON_REGISTRY[name];

  // Yerel vektör (SVG) ikon: dosya formatı ikonları bu yoldan render edilir.
  // Kendi marka renkleri olduğu için semantik ton uygulanmaz.
  if (def?.component) {
    const LocalIcon = def.component;
    return <LocalIcon size={px} className={className} title={title ?? def.label} />;
  }

  const glyph = def?.className ?? 'ri-question-line';
  const resolvedTone = tone ?? def?.tone;
  const toneCls = resolvedTone ? ICON_TONES[resolvedTone] : '';

  const style: CSSProperties = {
    fontSize: px,
    lineHeight: 1,
    width: px,
    height: px,
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
  };

  return (
    <i
      className={`${glyph} ${toneCls} ${className}`}
      style={style}
      title={title}
      aria-hidden={title ? undefined : true}
      aria-label={title}
    />
  );
}

interface FileIconProps {
  mime: string | null | undefined;
  name: string | null | undefined;
  size?: IconSize | number;
  /** Tonu zorlamak için (varsayılan: dosya türünün marka rengi). */
  tone?: IconTone;
  className?: string;
  title?: string;
}

/**
 * DOSYA FORMATI İKONU — gerçek formatı ve marka rengini temsil eder
 * (PDF kırmızı, Word mavi, Excel yeşil, PowerPoint turuncu). Tür çözümü
 * merkezî `resolveFileIcon` ile yapılır; tüm modüller aynı görsel dili kullanır.
 */
export function FileIcon({ mime, name, size = 'md', tone, className = '', title }: FileIconProps) {
  const resolved = resolveFileIcon(mime, name);
  return (
    <Icon
      name={resolved.name}
      size={size}
      tone={tone ?? resolved.tone}
      className={className}
      title={title}
    />
  );
}