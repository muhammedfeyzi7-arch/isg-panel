import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import type { ReactNode, RefObject } from 'react';
import { useDropdownPosition } from '@/hooks/useDropdown';
import { Z_LAYERS } from '@/utils/layers';

interface DropdownPanelProps<T extends HTMLElement> {
  open: boolean;
  anchorRef: RefObject<T | null>;
  onClose: () => void;
  className?: string;
  maxHeight?: number;
  gap?: number;
  minWidth?: number;
  align?: 'start' | 'end';
  role?: string;
  children: ReactNode;
}

/**
 * Global Viewport-Aware Dropdown Panel.
 *
 * Select/Autocomplete/MultiSelect/EmailInput gibi tüm dropdown/select bileşenleri
 * seçenek listesini bu TEK panel üzerinden render eder. Panel document.body'ye
 * portal edildiği için modal body overflow'u dahil hiçbir container tarafından
 * kırpılmaz; viewport'a göre aşağı/yukarı açılır, yetersiz alanda yüksekliği
 * kısıtlar. Dışarı tıklama (trigger ve panel dışı) ile kapanır.
 */
export default function DropdownPanel<T extends HTMLElement>({
  open,
  anchorRef,
  onClose,
  className = '',
  maxHeight,
  gap,
  minWidth,
  align,
  role,
  children,
}: DropdownPanelProps<T>) {
  const { panelRef, panelStyle } = useDropdownPosition<T>(open, anchorRef, { maxHeight, gap, minWidth, align });

  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;

  useEffect(() => {
    if (!open) return;

    const listener = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node;
      if (panelRef.current?.contains(target)) return;
      if (anchorRef.current?.contains(target)) return;
      onCloseRef.current();
    };

    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);
    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, [open, anchorRef]);

  if (!open) return null;

  return createPortal(
    <div
      ref={panelRef}
      role={role}
      style={{
        position: 'fixed',
        ...panelStyle,
        visibility: panelStyle ? 'visible' : 'hidden',
        zIndex: Z_LAYERS.dropdown,
      }}
      className={`flex flex-col overflow-hidden ${className}`}
    >
      {children}
    </div>,
    document.body,
  );
}