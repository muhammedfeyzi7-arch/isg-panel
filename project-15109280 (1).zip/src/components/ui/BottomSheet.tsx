import { useEffect, useRef, useState, useCallback } from 'react';
import { useBottomSheet } from '@/hooks/useBottomSheet';
import { Z_LAYERS } from '@/utils/layers';
import { lockScroll, unlockScroll } from '@/lib/scrollLock';

/**
 * Global Shared Mobile Bottom Sheet / Action Sheet Engine.
 *
 * ANİMASYONSUZ STANDART: Açılırken TAK görünür, kapanırken TAK kaybolur.
 * Slide-up/slide-down/fade/scale/spring yoktur. `transition` ve `animation`
 * hiçbir şekilde kullanılmaz. Overlay statik, sheet viewport'a sabittir.
 *
 * Drag-to-close (aşağı sürükleme) doğrudan parmak takibi olarak korunur:
 * bu bir animasyon DEĞİL, `translateY` yalnızca parmağa bağlı anlık değerdir.
 * Bırakınca eşik aşılmamışsa anında (transition olmadan) eski konuma döner.
 */
export default function BottomSheet() {
  const { isOpen, options, closeSheet } = useBottomSheet();
  const [dragY, setDragY] = useState(0);
  const dragStartY = useRef(0);
  const dragYRef = useRef(0);

  const handleDragStart = useCallback((e: React.PointerEvent) => {
    e.preventDefault();
    dragStartY.current = e.clientY;
    dragYRef.current = 0;
    setDragY(0);

    const onMove = (e: PointerEvent) => {
      const delta = e.clientY - dragStartY.current;
      if (delta > 0) {
        dragYRef.current = delta;
        setDragY(delta);
      }
    };

    const onUp = () => {
      if (dragYRef.current > 80) {
        closeSheet();
      }
      dragYRef.current = 0;
      setDragY(0);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };

    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  }, [closeSheet]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closeSheet();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, closeSheet]);

  // Arka plan scroll kilidi — merkezi Shared UI utility'si ile (body değil,
  // gerçek scroll konteyneri [data-isg-scroll] kilitlenir).
  useEffect(() => {
    if (!isOpen) return undefined;
    lockScroll('bottom-sheet');
    return () => unlockScroll('bottom-sheet');
  }, [isOpen]);

  if (!options) return null;

  return (
    <div className="lg:hidden">
      {/* Overlay — statik, opacity/fade animasyonu yok */}
      <div
        className="isg-overlay fixed inset-0"
        style={{
          pointerEvents: isOpen ? 'auto' : 'none',
          zIndex: Z_LAYERS.bottomSheetOverlay,
        }}
        onClick={closeSheet}
        aria-hidden={!isOpen}
      />

      {/* Sheet — statik konum, açılış/kapanış animasyonu yok */}
      <div
        className="fixed left-0 right-0 bottom-0"
        style={{
          transform: dragY > 0 ? `translateY(${dragY}px)` : 'none',
          zIndex: Z_LAYERS.bottomSheetPanel,
        }}
        role="dialog"
        aria-modal="true"
        aria-label={options.title || 'Panel'}
      >
        <div className="bg-background-100 dark:bg-background-200 rounded-t-2xl max-h-[80vh] flex flex-col overflow-hidden shadow-[0_-8px_32px_rgba(0,0,0,0.2)]">
          {/* Grabber */}
          <div
            className="flex justify-center pt-3 pb-1 flex-shrink-0 cursor-grab active:cursor-grabbing touch-none"
            onPointerDown={handleDragStart}
            aria-hidden="true"
          >
            <div className="w-10 h-1.5 rounded-full bg-foreground-300/40" />
          </div>

          {/* Header */}
          {(options.title || options.showClose) && (
            <div className="flex items-center justify-between px-4 pb-2 flex-shrink-0">
              {options.title ? (
                <h3 className="text-base font-semibold text-foreground-950">{options.title}</h3>
              ) : (
                <div />
              )}
              {options.showClose && (
                <button
                  onClick={closeSheet}
                  className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer"
                  aria-label="Kapat"
                >
                  <i className="ri-close-line text-lg text-foreground-500" />
                </button>
              )}
            </div>
          )}

          {/* Content */}
          <div
            className="flex-1 overflow-y-auto px-4 pt-0"
            style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom))' }}
          >
            {options.content}
          </div>
        </div>
      </div>
    </div>
  );
}