import { forwardRef, useId, type InputHTMLAttributes } from 'react';

interface CheckboxProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  error?: string;
  helpText?: string;
}

const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(function Checkbox(
  { label, error, helpText, className = '', disabled, ...props },
  ref
) {
  const hasError = !!error;
  const generatedId = useId();
  const errorId = hasError ? `${generatedId}-error` : undefined;
  const describedBy = errorId || undefined;

  return (
    <label className={`inline-flex items-start gap-2.5 cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${className}`}>
      <div className="relative flex items-center mt-0.5">
        <input
          ref={ref}
          type="checkbox"
          aria-describedby={describedBy}
          className="peer sr-only"
          disabled={disabled}
          {...props}
        />
        <div className={`w-[18px] h-[18px] min-w-[18px] min-h-[18px] rounded border-2 transition-all duration-150 flex items-center justify-center
          ${hasError ? 'border-danger-500 peer-checked:bg-danger-500 peer-checked:border-danger-500' : 'border-background-400 peer-checked:bg-primary-500 peer-checked:border-primary-500'}
          peer-focus-visible:ring-2 peer-focus-visible:ring-primary-400/60
          peer-disabled:bg-background-300 peer-disabled:border-background-300
        `}>
          <i className="ri-check-line text-inverse text-xs opacity-0 peer-checked:opacity-100 transition-opacity" />
        </div>
      </div>
      <div className="flex flex-col">
        {label && (
          <span className={`text-sm font-medium ${hasError ? 'text-danger-600' : 'text-foreground-800'}`}>
            {label}
          </span>
        )}
        {helpText && !error && (
          <span className="text-xs text-foreground-500">{helpText}</span>
        )}
        {error && (
          <span id={errorId} className="text-xs text-danger-600 flex items-center gap-1">
            <i className="ri-error-warning-line" />
            {error}
          </span>
        )}
      </div>
    </label>
  );
});

export default Checkbox;