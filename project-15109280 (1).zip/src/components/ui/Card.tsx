import type { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  title?: string;
  subtitle?: string;
  /** Başlığın solunda gösterilecek remix ikon sınıfı (ör. "ri-list-check-2"). */
  icon?: string;
  /** Başlığın sağına yerleştirilecek aksiyon(lar). `actions` ile aynıdır. */
  headerAction?: ReactNode;
  /** `headerAction` takma adı (referans slot adlandırması). */
  actions?: ReactNode;
  /** Tamamen özel başlık satırı. Verilirse title/subtitle/icon yerine geçer. */
  header?: ReactNode;
  footer?: ReactNode;
  className?: string;
  /** Gövdeye özel sınıflar (ör. scroll alanı). */
  bodyClassName?: string;
  /** Ölçü varyantı — kart padding standardı (Shared UI tek kaynak). */
  size?: 'compact' | 'default' | 'large';
  padding?: 'none' | 'sm' | 'md' | 'lg';
  noBorder?: boolean;
}

const paddingCls = {
  none: 'p-0',
  sm: 'isg-card-pad-sm',
  md: 'isg-card-pad',
  lg: 'isg-card-pad-lg',
};

const sizeToPadding: Record<NonNullable<CardProps['size']>, keyof typeof paddingCls> = {
  compact: 'sm',
  default: 'md',
  large: 'lg',
};

/**
 * GLOBAL CARD — Shared UI tek kaynak.
 * Referans standardı: (opsiyonel ikon kutusu) + başlık + açıklama + sağ aksiyon,
 * altında gövde ve (varsa) footer. Panel/kart/özet kartı/aksiyon kartı/bulgu
 * kartı HEPSİ bu tek bileşenden üretilir. Sayfaya özel radius/padding/card
 * background ÜRETİLMEZ. `padding` (geriye uyumlu) ve `size` (yeni, tercih edilen)
 * aynı ölçekten beslenir.
 */
export default function Card({
  children,
  title,
  subtitle,
  icon,
  headerAction,
  actions,
  header,
  footer,
  className = '',
  bodyClassName = '',
  size = 'default',
  padding,
  noBorder,
}: CardProps) {
  const pad = padding ?? sizeToPadding[size];
  const padCls = paddingCls[pad];
  const rightAction = headerAction ?? actions;
  const hasHeader = !!header || !!title || !!subtitle || !!rightAction;

  return (
    <div className={`isg-card overflow-hidden ${noBorder ? 'border-0' : ''} ${className}`}>
      {header ? (
        <div className={`${padCls} pb-0`}>{header}</div>
      ) : hasHeader ? (
        <div className={`flex items-start justify-between ${padCls} pb-0 ${rightAction ? 'gap-3' : ''}`}>
          <div className="min-w-0 flex items-center gap-2.5">
            {icon && (
              <span className="w-8 h-8 rounded-md bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                <i className={`${icon} text-primary-600 dark:text-primary-400 text-sm`} />
              </span>
            )}
            <div className="min-w-0">
              {title && <h3 className="isg-text-card-title text-foreground-950 truncate">{title}</h3>}
              {subtitle && <p className="mt-0.5 isg-text-caption text-foreground-500 truncate">{subtitle}</p>}
            </div>
          </div>
          {rightAction && <div className="flex items-center gap-1.5 flex-shrink-0">{rightAction}</div>}
        </div>
      ) : null}
      <div className={`${padCls} ${hasHeader ? 'pt-3' : ''} min-w-0 ${bodyClassName}`}>
        {children}
      </div>
      {footer && (
        <div className={`border-t isg-divider ${padCls} pt-3`}>
          {footer}
        </div>
      )}
    </div>
  );
}