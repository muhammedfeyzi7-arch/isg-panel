import { useCallback, useEffect, useLayoutEffect, useRef, useState, type ReactNode, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { Z_LAYERS } from '@/utils/layers';

// ---------- İSGDenetim ORTAK TARİH/SAAT PICKER KATMANI (TEK KAYNAK) ----------
// Global DatePicker ve TimePicker'ın açılır panelini yönetir. Sayfa/modül bazlı
// ikinci bir dropdown/portal sistemi YAZILMAZ. Panel `document.body`'ye portallanır
// (modal gövdesinin `overflow`'u içeriği kırpamaz), Z_LAYERS.dropdown katmanında
// açılır ve viewport dışına taşmaz: yer yoksa otomatik YUKARI konumlanır, yatayda
// viewport içine kırpılır. Scroll/resize'da yeniden konumlanır. Dış tıklamada kapanır.

interface PickerPortalProps {
  anchorRef: RefObject<HTMLElement | null>;
  open: boolean;
  onClose: () => void;
  children: ReactNode;
  /** Ölçüm öncesi varsayılan genişlik (px). */
  minWidth?: number;
  /** ESC / Enter gibi tuşların arka plana (modal) sızmasını engellemek için. */
  onKeyDown?: (e: React.KeyboardEvent) => void;
}

const EDGE = 8;
const GAP = 6;

export default function PickerPortal({
  anchorRef,
  open,
  onClose,
  children,
  minWidth = 0,
  onKeyDown,
}: PickerPortalProps) {
  const popRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);

  const reposition = useCallback(() => {
    const anchor = anchorRef.current;
    const pop = popRef.current;
    if (!anchor || !pop) return;
    const a = anchor.getBoundingClientRect();
    const pw = Math.max(pop.offsetWidth, minWidth);
    const ph = pop.offsetHeight;
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    let left = a.left;
    left = Math.max(EDGE, Math.min(left, vw - pw - EDGE));

    let top = a.bottom + GAP;
    if (top + ph > vh - EDGE) {
      const above = a.top - ph - GAP;
      top = above >= EDGE ? above : Math.max(EDGE, vh - ph - EDGE);
    }
    setPos({ top, left });
  }, [anchorRef, minWidth]);

  useLayoutEffect(() => {
    if (!open) return undefined;
    setPos(null);
    reposition();
    const raf = requestAnimationFrame(reposition);
    return () => cancelAnimationFrame(raf);
  }, [open, reposition]);

  useEffect(() => {
    if (!open) return undefined;
    const onScroll = () => reposition();
    const onResize = () => reposition();
    window.addEventListener('scroll', onScroll, true);
    window.addEventListener('resize', onResize);
    return () => {
      window.removeEventListener('scroll', onScroll, true);
      window.removeEventListener('resize', onResize);
    };
  }, [open, reposition]);

  // Dış tıklama → kapat. Anchor içine tıklamada kapatılmaz (buton kendi toggle'ını yönetir).
  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e: PointerEvent) => {
      const t = e.target as Node;
      if (popRef.current?.contains(t)) return;
      if (anchorRef.current?.contains(t)) return;
      onClose();
    };
    document.addEventListener('pointerdown', onDown, true);
    return () => document.removeEventListener('pointerdown', onDown, true);
  }, [open, onClose, anchorRef]);

  // ESC her zaman önce picker'ı kapatır; açık başka overlay olsa bile arka plana sızmaz.
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopImmediatePropagation();
        e.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [open, onClose]);

  if (!open) return null;

  return createPortal(
    <div
      ref={popRef}
      role="listbox"
      aria-label="Seçici"
      onKeyDown={onKeyDown}
      className="isg-popover fixed"
      style={{
        top: pos ? `${pos.top}px` : 0,
        left: pos ? `${pos.left}px` : 0,
        visibility: pos ? 'visible' : 'hidden',
        zIndex: Z_LAYERS.dropdown,
      }}
    >
      {children}
    </div>,
    document.body,
  );
}