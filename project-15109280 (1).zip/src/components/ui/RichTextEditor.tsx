import { useEffect, useRef } from 'react';
import { sanitizeHtml } from '@/lib/sanitizeHtml';

// ---------- Ortak zengin metin editörü (contentEditable + araç çubuğu) ----------
// Bağımsız paylaşılan bileşen: tutanak sihirbazına özel değildir. Kalın/italik/
// altı çizili + madde listeleri ve karakter sayacı sunar.

interface RichTextEditorProps {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
  maxLength?: number;
  minHeight?: number;
}

export function RichTextEditor({
  value,
  onChange,
  placeholder = 'Yazın...',
  maxLength = 5000,
  minHeight = 220,
}: RichTextEditorProps) {
  const ref = useRef<HTMLDivElement>(null);

  // Dış değer değiştiğinde (odak dışıyken) içeriği eşitle — yazarken imleç zıplamaz.
  // GUV-05/GUV-08: dışarıdan gelen `value` (örn. sunucudan yüklenen kayıtlı içerik)
  // doğrudan innerHTML'e basılmaz; önce merkezi sanitizer'dan geçirilir. Böylece eski
  // veya elle manipüle edilmiş içerikte kalan script/on* handler/javascript: URL'ler
  // DOM'a giremez (savunma derinliği).
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (document.activeElement === el) return;
    const clean = sanitizeHtml(value, 'rich');
    if (el.innerHTML !== clean) el.innerHTML = clean;
  }, [value]);

  const emit = () => {
    const el = ref.current;
    // GUV-05: kaydedilen HTML her zaman merkezi sanitizer'dan geçirilir (script,
    // on* handler ve javascript: URL'ler kayıt anında temizlenir).
    if (el) onChange(sanitizeHtml(el.innerHTML, 'rich'));
  };

  const exec = (cmd: string, arg?: string) => {
    ref.current?.focus();
    document.execCommand(cmd, false, arg);
    emit();
  };

  const plainLen = (ref.current?.innerText ?? '').length;

  const tools: { cmd: string; icon: string; title: string }[] = [
    { cmd: 'bold', icon: 'ri-bold', title: 'Kalın' },
    { cmd: 'italic', icon: 'ri-italic', title: 'İtalik' },
    { cmd: 'underline', icon: 'ri-underline', title: 'Altı çizili' },
    { cmd: 'insertUnorderedList', icon: 'ri-list-unordered', title: 'Madde listesi' },
    { cmd: 'insertOrderedList', icon: 'ri-list-ordered', title: 'Numaralı liste' },
  ];

  return (
    <div className="rounded-md border border-background-300/60 dark:border-background-400/40 bg-background-50 dark:bg-background-200/40 overflow-hidden">
      <div className="flex items-center gap-0.5 px-2 py-1.5 border-b border-background-300/30 dark:border-background-400/25">
        {tools.map((t) => (
          <button
            key={t.cmd}
            type="button"
            title={t.title}
            aria-label={t.title}
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => exec(t.cmd)}
            className="w-7 h-7 flex items-center justify-center rounded text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 hover:text-foreground-900 transition-colors cursor-pointer"
          >
            <i className={t.icon} />
          </button>
        ))}
        <div className="w-px h-5 bg-background-300/60 dark:bg-background-400/30 mx-1" />
        <button
          type="button"
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => exec('removeFormat')}
          className="ml-auto flex items-center gap-1 px-2 h-7 rounded text-xs text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer"
        >
          <i className="ri-eraser-line" /> Temizle
        </button>
      </div>
      <div className="relative">
        <div
          ref={ref}
          contentEditable
          suppressContentEditableWarning
          data-placeholder={placeholder}
          onInput={emit}
          onBlur={emit}
          style={{ minHeight }}
          className="isg-rte px-3 py-2.5 text-sm text-foreground-800 leading-relaxed outline-none"
        />
        {plainLen === 0 && (
          <span className="pointer-events-none absolute left-3 top-2.5 text-sm text-foreground-400">
            {placeholder}
          </span>
        )}
      </div>
      <div className="flex items-center justify-end px-3 py-1.5 border-t border-background-300/30 dark:border-background-400/25">
        <span className={`text-[11px] ${plainLen > maxLength ? 'text-danger-600' : 'text-foreground-400'}`}>
          {plainLen}/{maxLength}
        </span>
      </div>
    </div>
  );
}