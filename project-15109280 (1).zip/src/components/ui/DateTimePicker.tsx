import DatePicker from './DatePicker';
import TimePicker from './TimePicker';

interface DateTimePickerProps {
  label?: string;
  error?: string;
  helpText?: string;
  /** 'YYYY-MM-DDTHH:MM' biçiminde birleşik değer. */
  value?: string;
  onChange?: (e: { target: { value: string; name?: string } }) => void;
  name?: string;
  disabled?: boolean;
  required?: boolean;
  containerClassName?: string;
  /** Tarih ve saat yan yana mı (varsayılan) yoksa alt alta mı gösterilsin. */
  layout?: 'row' | 'column';
}

function splitDateTime(v?: string): { date: string; time: string } {
  if (!v) return { date: '', time: '' };
  const date = v.slice(0, 10);
  // 'YYYY-MM-DDTHH:MM' veya 'YYYY-MM-DD HH:MM'
  const timeMatch = /[T ](\d{2}:\d{2})/.exec(v);
  return { date, time: timeMatch ? timeMatch[1] : '' };
}

function combine(date: string, time: string): string {
  if (!date && !time) return '';
  if (date && time) return `${date}T${time}`;
  if (date) return `${date}T00:00`;
  return '';
}

/**
 * GLOBAL TARİH + SAAT SEÇİCİ (Shared UI tek kaynak).
 * Mevcut merkezi DatePicker ve TimePicker primitiflerini BİRLEŞTİRİR; kendi
 * takvim/saat panelini YENİDEN YAZMAZ. Tek `value` ('YYYY-MM-DDTHH:MM') ile
 * çalışır ve tek `onChange` üretir. Yeni bir ikinci tarih altyapısı oluşturmaz.
 */
export default function DateTimePicker({
  label,
  error,
  helpText,
  value,
  onChange,
  name,
  disabled,
  required,
  containerClassName = '',
  layout = 'row',
}: DateTimePickerProps) {
  const { date, time } = splitDateTime(value);

  const emit = (nextDate: string, nextTime: string) => {
    onChange?.({ target: { value: combine(nextDate, nextTime), name } });
  };

  return (
    <div className={`w-full ${containerClassName}`}>
      {label && (
        <label className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}
      <div className={layout === 'row' ? 'grid grid-cols-1 sm:grid-cols-2 gap-2' : 'space-y-2'}>
        <DatePicker
          value={date}
          onChange={(e) => emit(e.target.value, time)}
          disabled={disabled}
          placeholder="gg.aa.yyyy"
        />
        <TimePicker
          value={time}
          onChange={(e) => emit(date, e.target.value)}
          disabled={disabled}
          placeholder="ss:dd"
        />
      </div>
      {error && (
        <p className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!error && helpText && <p className="isg-form-help">{helpText}</p>}
    </div>
  );
}