import { useId, useMemo, useRef, useState } from 'react';
import DropdownPanel from './DropdownPanel';
import { turkishIncludes } from '@/utils/turkishText';
import { listboxStep } from '@/hooks/useKeyboardNav';

export interface AutocompleteOption {
  value: string;
  label: string;
}

interface AutocompleteProps {
  label?: string;
  error?: string;
  helpText?: string;
  options: AutocompleteOption[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  disabled?: boolean;
  loading?: boolean;
  containerClassName?: string;
  className?: string;
}

/**
 * Ortak Autocomplete / Search-Select componenti. Yazdıkça filtreler,
 * klavye (Yukarı/Aşağı/Enter/Esc) ile gezilebilir, viewport'a göre açılır.
 */
export default function Autocomplete({
  label,
  error,
  helpText,
  options,
  value,
  onChange,
  placeholder = 'Ara ve seç...',
  required,
  disabled,
  loading,
  containerClassName = '',
  className = '',
}: AutocompleteProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [highlightIndex, setHighlightIndex] = useState(-1);
  const generatedId = useId();
  const hasError = !!error;
  const errorId = hasError ? `${generatedId}-error` : undefined;
  const helpId = helpText ? `${generatedId}-help` : undefined;
  const describedBy = [errorId, helpId].filter(Boolean).join(' ') || undefined;
  const anchorRef = useRef<HTMLInputElement>(null);

  const selectedLabel = useMemo(
    () => options.find((o) => o.value === value)?.label || '',
    [options, value],
  );

  const filteredOptions = useMemo(() => {
    const q = query.trim();
    if (!q) return options;
    return options.filter((o) => turkishIncludes(o.label, q));
  }, [options, query]);

  const stateCls = hasError ? 'isg-input-error' : '';

  const select = (opt: AutocompleteOption) => {
    onChange(opt.value);
    setQuery('');
    setOpen(false);
    setHighlightIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!open && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
      setOpen(true);
      return;
    }
    if (e.key === 'Escape') {
      setOpen(false);
      setHighlightIndex(-1);
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightIndex((prev) =>
        prev < filteredOptions.length - 1 ? prev + 1 : 0,
      );
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightIndex((prev) =>
        prev > 0 ? prev - 1 : filteredOptions.length - 1,
      );
      return;
    }
    if (e.key === 'Home' || e.key === 'End') {
      e.preventDefault();
      setOpen(true);
      setHighlightIndex((prev) => {
        const count = filteredOptions.length;
        return listboxStep(prev, e.key, count) ?? prev;
      });
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      if (highlightIndex >= 0 && filteredOptions[highlightIndex]) {
        select(filteredOptions[highlightIndex]);
      }
    }
  };

  return (
    <div className={`w-full relative ${containerClassName}`}>
      {label && (
        <label htmlFor={`${generatedId}-input`} className="isg-form-label">
          {label}
          {required && <span className="text-danger-600 ml-0.5">*</span>}
        </label>
      )}

      <div className="relative">
        <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400 pointer-events-none" />
        <input
          ref={anchorRef}
          id={`${generatedId}-input`}
          type="text"
          role="combobox"
          aria-haspopup="listbox"
          aria-expanded={open}
          aria-invalid={hasError || undefined}
          aria-describedby={describedBy}
          value={open ? query : selectedLabel}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
            setHighlightIndex(-1);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          disabled={disabled}
          className={`isg-input w-full pl-9 pr-9 ${stateCls} ${
            disabled ? 'opacity-50 cursor-not-allowed' : ''
          } ${className}`}
        />
        {loading ? (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 inline-block w-4 h-4 border-2 border-foreground-300 border-t-transparent rounded-full animate-spin" />
        ) : (
          <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-foreground-400 pointer-events-none" />
        )}
      </div>

      {open && !disabled && (
        <DropdownPanel
          open={open}
          anchorRef={anchorRef}
          onClose={() => setOpen(false)}
          className="isg-popover"
        >
          <div className="overflow-y-auto flex-1 min-h-0">
          {filteredOptions.length === 0 ? (
            <div className="p-4 text-sm text-foreground-400 text-center">Sonuç bulunamadı</div>
          ) : (
            filteredOptions.map((opt, idx) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => select(opt)}
                onMouseEnter={() => setHighlightIndex(idx)}
                className={`w-full flex items-center justify-between px-3 py-2 text-left text-sm transition-colors ${
                  idx === highlightIndex
                    ? 'bg-primary-50 dark:bg-primary-500/15 text-primary-700 dark:text-primary-400'
                    : 'text-foreground-800 hover:bg-background-200 dark:hover:bg-background-300/40'
                }`}
              >
                <span className="truncate">{opt.label}</span>
                {value === opt.value && <i className="ri-check-line text-primary-500" />}
              </button>
            ))
          )}
          </div>
        </DropdownPanel>
      )}

      {hasError && (
        <p id={errorId} className="isg-form-error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      {!hasError && helpText && (
        <p id={helpId} className="isg-form-help">{helpText}</p>
      )}
    </div>
  );
}