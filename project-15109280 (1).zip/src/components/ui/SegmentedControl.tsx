import type { ReactNode } from 'react';

export type SegmentTone = 'neutral' | 'success' | 'danger' | 'warning' | 'primary';

export interface SegmentOption<T extends string> {
  value: T;
  label: string;
  /** Segment içi küçük ikon (ör. ri-check-line). */
  icon?: ReactNode;
  /** Seçili durumda uygulanacak renk tonu (durum kontrolleri için). */
  tone?: SegmentTone;
  disabled?: boolean;
  /**
   * Etiketin önünde küçük renk noktası (durum kodlu filtre sekmeleri için).
   * Sınıf token tabanlıdır (ör. "bg-success-500"); renk hardcode EDİLMEZ.
   */
  dotClassName?: string;
  /** Küçük sayısal sayaç rozeti (ör. filtre sekmesindeki kayıt adedi). */
  count?: number;
}

interface SegmentedControlProps<T extends string> {
  options: SegmentOption<T>[];
  value: T;
  onChange: (value: T) => void;
  size?: 'sm' | 'md';
  /** Tam genişlik (kart içinde satırı kaplar). Varsayılan: içerik genişliği. */
  fullWidth?: boolean;
  className?: string;
  ariaLabel?: string;
}

/**
 * GLOBAL SEGMENT / DURUM / FİLTRE KONTROLÜ — Shared UI tek kaynak.
 *
 * Referanstaki Uygun / Uygunsuz / Kısmen Uygun / Uygulanamaz gibi tüm segment
 * ve durum kontrolleri; ayrıca "Tümü / Taslak / Tamamlandı" gibi SAYAÇLI durum
 * filtre sekmeleri TEK kaynak. Görsel dil tamamen merkezi token'lardan gelir
 * (`.isg-seg` / `.isg-seg-btn` / `.isg-seg-count` / `.isg-seg-dot`); renkler
 * hardcode EDİLMEZ. Seçili durum tonu (success/danger/warning/primary) dolu
 * semantic renkle okunur. Light ve Dark aynı davranışı paylaşır.
 *
 * Sayfaya özel segment/status/sekme stili ÜRETİLMEZ; her yeni modül bu bileşeni
 * kullanır (önceki "elle yazılmış sayaçlı pill sekmesi" kopyaları tekilleşir).
 */
export default function SegmentedControl<T extends string>({
  options,
  value,
  onChange,
  size = 'md',
  fullWidth = false,
  className = '',
  ariaLabel,
}: SegmentedControlProps<T>) {
  return (
    <div
      role="radiogroup"
      aria-label={ariaLabel}
      className={`isg-seg ${fullWidth ? 'w-full' : ''} ${className}`}
    >
      {options.map((opt) => {
        const active = opt.value === value;
        return (
          <button
            key={opt.value}
            type="button"
            role="radio"
            aria-checked={active}
            data-active={active ? 'true' : 'false'}
            data-tone={opt.tone ?? 'neutral'}
            disabled={opt.disabled}
            onClick={() => !opt.disabled && onChange(opt.value)}
            className={`isg-seg-btn ${fullWidth ? 'flex-1' : ''} ${size === 'sm' ? 'isg-text-micro px-2 py-1' : ''} ${opt.disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {opt.dotClassName && <span className={`isg-seg-dot ${opt.dotClassName}`} aria-hidden="true" />}
            {opt.icon}
            {opt.label}
            {typeof opt.count === 'number' && <span className="isg-seg-count">{opt.count}</span>}
          </button>
        );
      })}
    </div>
  );
}