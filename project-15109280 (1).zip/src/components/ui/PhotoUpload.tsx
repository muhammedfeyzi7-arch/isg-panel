import { useMemo, useRef, useState, type ChangeEvent } from 'react';
import PhotoLightbox from './PhotoLightbox';

export interface PhotoItem {
  id: string;
  url: string | null;
  name?: string;
}

type PhotoTileSize = 'sm' | 'md' | 'lg';

/** Merkezî thumbnail boyut presetleri (px). Varsayılan: md. */
const TILE_PX: Record<PhotoTileSize, number> = { sm: 56, md: 72, lg: 96 };

interface PhotoUploadProps {
  items: PhotoItem[];
  onAdd?: (files: File[]) => void;
  onRemove?: (id: string) => void;
  max?: number;
  disabled?: boolean;
  accept?: string;
  label?: string;
  helpText?: string;
  /** Merkezî thumbnail boyutu. Varsayılan `md` (≈72px). */
  size?: PhotoTileSize;
  /** Geriye dönük uyumluluk: verilirse `size` yerine bu px kullanılır. */
  tileSize?: number;
  showAddLabel?: boolean;
  className?: string;
}

/**
 * GLOBAL FOTOĞRAF YÜKLEYİCİ — Shared UI tek kaynak.
 *
 * Referanstaki "Açılış Fotoğrafları / Fotoğraf Ekle / Ekler" alanının ortak
 * karşılığıdır: sabit oranlı kare thumbnail'lar + remove overlay + add tile +
 * tıklayınca büyütme (merkezî PhotoLightbox). Kanıt fotoğrafı, ekipman
 * fotoğrafı, personel fotoğrafı gibi TÜM kare-thumbnail alanları bu bileşeni
 * kullanır. Görsel dil `.isg-photo-tile` / `.isg-photo-add` token'larından
 * gelir; sayfaya özel thumbnail stili ÜRETİLMEZ.
 *
 * Thumbnail boyutu merkezî `size` presetinden gelir (sm/md/lg) — modüller
 * gereksiz küçük kare üretmez; varsayılan `md` okunur boyuttur.
 *
 * Kontrollüdür: dosya seçimi ve silme dışarıdan (`onAdd` / `onRemove`) yönetilir.
 * Gerçek yükleme (storage/edge) business logic'ine dokunmaz.
 */
export default function PhotoUpload({
  items,
  onAdd,
  onRemove,
  max,
  disabled = false,
  accept = 'image/jpeg,image/png,image/webp',
  label,
  helpText,
  size = 'md',
  tileSize,
  showAddLabel = true,
  className = '',
}: PhotoUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);
  const canAdd = !disabled && (typeof max !== 'number' || items.length < max);

  const px = tileSize ?? TILE_PX[size];

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = '';
    if (files.length === 0) return;
    const room = typeof max === 'number' ? Math.max(0, max - items.length) : files.length;
    if (room > 0) onAdd?.(files.slice(0, room));
  };

  // Lightbox yalnızca url'i olan kareler arasında gezinir.
  const viewable = useMemo(
    () =>
      items
        .filter((p) => !!p.url)
        .map((p) => ({ id: p.id, src: p.url as string, alt: p.name, fileName: p.name })),
    [items],
  );

  const openAt = (id: string) => {
    const i = viewable.findIndex((v) => v.id === id);
    if (i >= 0) setLightboxIndex(i);
  };

  return (
    <div className={`w-full ${className}`}>
      {label && <label className="isg-form-label">{label}</label>}

      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple
        className="hidden"
        onChange={handleChange}
        disabled={disabled}
      />

      <div className="flex flex-wrap items-center gap-2">
        {items.map((p) => (
          <div
            key={p.id}
            className="isg-photo-tile group flex-shrink-0"
            style={{ width: px, height: px }}
          >
            {p.url ? (
              <button
                type="button"
                onClick={() => openAt(p.id)}
                className="block w-full h-full cursor-zoom-in"
                aria-label="Fotoğrafı büyüt"
              >
                <img src={p.url} alt={p.name ?? 'Fotoğraf'} className="w-full h-full object-cover object-top" />
                <span className="pointer-events-none absolute inset-0 flex items-center justify-center bg-black/35 opacity-0 group-hover:opacity-100 transition-opacity">
                  <i className="ri-zoom-in-line text-white text-sm" />
                </span>
              </button>
            ) : (
              <span className="w-full h-full flex items-center justify-center">
                <i className="ri-image-line text-foreground-400" />
              </span>
            )}
            {onRemove && !disabled && (
              <button
                type="button"
                onClick={() => onRemove(p.id)}
                className="absolute inset-0 flex items-center justify-center bg-black/55 text-inverse opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                aria-label="Fotoğrafı kaldır"
                title="Kaldır"
              >
                <i className="ri-close-line text-sm" />
              </button>
            )}
          </div>
        ))}

        {canAdd && (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="isg-photo-add rounded-lg flex flex-col items-center justify-center flex-shrink-0 cursor-pointer"
            style={{ width: px, height: px }}
            title="Fotoğraf ekle"
            aria-label="Fotoğraf ekle"
          >
            <i className="ri-image-add-line text-base" />
          </button>
        )}

        {showAddLabel && (
          <button
            type="button"
            onClick={() => canAdd && inputRef.current?.click()}
            disabled={!canAdd}
            className="ml-1 inline-flex items-center gap-1 text-xs font-medium text-primary-600 dark:text-primary-300 hover:text-primary-700 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer whitespace-nowrap"
          >
            <i className="ri-add-line" /> Fotoğraf Ekle
          </button>
        )}
      </div>

      {helpText && <p className="isg-form-help">{helpText}</p>}

      {lightboxIndex !== null && viewable.length > 0 && (
        <PhotoLightbox
          items={viewable.map((v) => ({ src: v.src, alt: v.alt, fileName: v.fileName }))}
          index={lightboxIndex}
          onIndexChange={setLightboxIndex}
          onClose={() => setLightboxIndex(null)}
          title={viewable[lightboxIndex]?.fileName || 'Fotoğraf'}
        />
      )}
    </div>
  );
}