import { useState, type ReactNode } from 'react';

type Side = 'top' | 'bottom' | 'left' | 'right';

interface TooltipProps {
  content: ReactNode;
  children: ReactNode;
  side?: Side;
  /** Gecikme yok; sade ve hızlı. */
  className?: string;
}

/**
 * GLOBAL TOOLTIP (Shared UI tek kaynak).
 * Kısa açıklama/ipucu metinleri için TEK sözleşme: aynı yüzey token'ı
 * (`--surface-popover`), aynı radius, aynı tipografi ve aynı ok. Hover ve
 * klavye odağında (focus-within) görünür; erişilebilir (role="tooltip").
 * İş mantığı içermez.
 */

const SIDE_CLS: Record<Side, string> = {
  top: 'bottom-full left-1/2 -translate-x-1/2 mb-2',
  bottom: 'top-full left-1/2 -translate-x-1/2 mt-2',
  left: 'right-full top-1/2 -translate-y-1/2 mr-2',
  right: 'left-full top-1/2 -translate-y-1/2 ml-2',
};

const ARROW_CLS: Record<Side, string> = {
  top: 'top-full left-1/2 -translate-x-1/2 border-t-background-900/95 dark:border-t-background-700',
  bottom: 'bottom-full left-1/2 -translate-x-1/2 border-b-background-900/95 dark:border-b-background-700',
  left: 'left-full top-1/2 -translate-y-1/2 border-l-background-900/95 dark:border-l-background-700',
  right: 'right-full top-1/2 -translate-y-1/2 border-r-background-900/95 dark:border-r-background-700',
};

const ARROW_BORDER: Record<Side, string> = {
  top: 'border-x-transparent border-t-[5px] border-x-4 border-b-0',
  bottom: 'border-x-transparent border-b-[5px] border-x-4 border-t-0',
  left: 'border-y-transparent border-l-[5px] border-y-4 border-r-0',
  right: 'border-y-transparent border-r-[5px] border-y-4 border-l-0',
};

export default function Tooltip({ content, children, side = 'top', className = '' }: TooltipProps) {
  const [open, setOpen] = useState(false);

  return (
    <span
      className={`relative inline-flex ${className}`}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
    >
      {children}
      {open && (
        <span
          role="tooltip"
          className={`pointer-events-none absolute z-[1000] whitespace-nowrap rounded-md bg-background-900/95 px-2 py-1 text-xs font-medium text-background-50 shadow-lg dark:bg-background-700 dark:text-foreground-950 ${SIDE_CLS[side]}`}
        >
          {content}
          <span className={`absolute h-0 w-0 border-solid ${ARROW_BORDER[side]} ${ARROW_CLS[side]}`} aria-hidden="true" />
        </span>
      )}
    </span>
  );
}