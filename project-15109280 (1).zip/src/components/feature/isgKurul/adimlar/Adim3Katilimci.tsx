import { useMemo, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import { useToastActions } from '@/hooks/useToast';
import type { WizardApi, ToplantiTaslak } from '../useIsgKurulWizard';
import { friendlyKurulError } from '@/lib/isgKurulService';

const KATILIM_OPTIONS = [
  { value: 'belirsiz', label: 'Belirsiz' },
  { value: 'katilacak', label: 'Katılacak' },
  { value: 'katilmayacak', label: 'Katılmayacak' },
];

/** ADIM 3 — Katılımcılar / Çağrı ve Davet (gerçek e-posta gönderimi). */
export default function Adim3Katilimci({ ctx, taslak }: { ctx: WizardApi; taslak: ToplantiTaslak }) {
  const { addToast } = useToastActions();
  const [secili, setSecili] = useState<Set<string>>(new Set(ctx.katilimcilar.map((k) => k.id)));
  const [hepsi, setHepsi] = useState(true);
  const [gundemDahil, setGundemDahil] = useState(true);
  const [subject, setSubject] = useState(`İSG Kurulu Toplantı Çağrısı — ${taslak.toplantiNo || ''} (${taslak.tarih || ''})`);
  const [body, setBody] = useState(`Sayın İSG Kurulu Üyesi,\n\n${ctx.firma?.unvan ?? 'Firma'} İSG Kurulu toplantısı aşağıdaki bilgilerle yapılacaktır. Katılımınızı rica ederiz.\n\nTarih: ${taslak.tarih || '—'}\nSaat: ${taslak.saat || '—'}\nYer: ${taslak.yer || '—'}`);

  const emailAdresleri = useMemo(() => {
    const list = hepsi ? ctx.katilimcilar : ctx.katilimcilar.filter((k) => secili.has(k.id));
    return Array.from(new Set(list.map((k) => (k.email ?? '').trim()).filter((e) => e && e.includes('@'))));
  }, [ctx.katilimcilar, hepsi, secili]);

  const toggle = (id: string) => {
    setSecili((prev) => {
      const n = new Set(prev);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
    setHepsi(false);
  };

  const gonder = async () => {
    if (emailAdresleri.length === 0) {
      addToast({ title: 'Alıcı yok', message: 'Seçili üyelerin kayıtlı e-posta adresi yok.', type: 'warning' });
      return;
    }
    try {
      const n = await ctx.sendCagriMail({ to: emailAdresleri, subject, body, gundemDahil });
      addToast({ title: 'Gönderildi', message: `Toplantı çağrısı ${n} üyeye e-posta ile gönderildi.`, type: 'success' });
    } catch (e) {
      addToast({ title: 'Gönderilemedi', message: friendlyKurulError(e), type: 'error' });
    }
  };

  const katilimGuncelle = async (id: string, deger: string, neden: string | null) => {
    try { await ctx.saveKatilim(id, deger, neden); }
    catch (e) { addToast({ title: 'Hata', message: friendlyKurulError(e), type: 'error' }); }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
      {/* SOL — Katılımcılar */}
      <div className="space-y-3 min-w-0">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold text-foreground-900">Katılımcılar ({ctx.katilimcilar.length})</p>
          <button type="button" onClick={() => { setHepsi(true); }} className="text-xs text-primary-600 hover:underline cursor-pointer">Tümünü Seç</button>
        </div>
        {ctx.katilimcilar.length === 0 ? (
          <p className="text-xs text-foreground-400 text-center py-8">Önce Adım 1'de kurul üyelerini ekleyin.</p>
        ) : (
          <ul className="space-y-1.5">
            {ctx.katilimcilar.map((k) => (
              <li key={k.id} className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-2.5">
                <div className="flex items-center gap-2.5">
                  <input type="checkbox" checked={hepsi || secili.has(k.id)} onChange={() => toggle(k.id)} className="w-4 h-4 accent-primary-500 cursor-pointer" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground-900 truncate">{k.adSoyad}</p>
                    <p className="text-[11px] text-foreground-500 truncate">{k.rol}{k.email ? ` · ${k.email}` : ' · e-posta yok'}</p>
                  </div>
                  <Badge variant={k.katilim === 'katilacak' ? 'success' : k.katilim === 'katilmayacak' ? 'danger' : 'secondary'}>
                    {KATILIM_OPTIONS.find((o) => o.value === k.katilim)?.label ?? 'Belirsiz'}
                  </Badge>
                </div>
                <div className="flex items-center gap-2 mt-2">
                  <select value={k.katilim} onChange={(e) => katilimGuncelle(k.id, e.target.value, null)} className="isg-input isg-input-sm flex-1 cursor-pointer">
                    {KATILIM_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                  {k.katilim === 'katilmayacak' && (
                    <input defaultValue={k.katilmamaNedeni ?? ''} onBlur={(e) => katilimGuncelle(k.id, 'katilmayacak', e.target.value || null)} placeholder="Katılmama nedeni" className="isg-input isg-input-sm flex-1" />
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* SAĞ — E-posta */}
      <div className="space-y-3">
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2.5">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-foreground-900 flex items-center gap-1.5"><i className="ri-mail-send-line text-primary-500" /> Toplantı Çağrısı Gönder</p>
            <span className="text-[11px] text-foreground-500">{emailAdresleri.length} alıcı</span>
          </div>
          <Input label="Konu" value={subject} onChange={(e) => setSubject(e.target.value)} />
          <div>
            <span className="block text-sm font-medium text-foreground-800 mb-1">İçerik</span>
            <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={6} />
          </div>
          <label className="flex items-center gap-2 text-xs text-foreground-700 cursor-pointer">
            <input type="checkbox" checked={gundemDahil} onChange={(e) => setGundemDahil(e.target.checked)} className="w-4 h-4 accent-primary-500" />
            Toplantı gündemini e-postaya ekle
          </label>
          <Button variant="primary" size="sm" className="whitespace-nowrap w-full" leftIcon={<i className="ri-send-plane-line" />} isLoading={ctx.busy === 'mail'} onClick={gonder}>E-Posta ile Gönder</Button>
          <p className="text-[10px] text-foreground-500">Gönderim gerçek e-posta altyapısı (mail) üzerinden yapılır. Başarısız gönderimde başarı mesajı gösterilmez; geçmiş toplantı kaydında tutulur.</p>
        </div>

        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500 mb-2">Davet Önizleme</p>
          <p className="text-xs font-medium text-foreground-800">{subject}</p>
          <pre className="mt-1.5 text-[11px] text-foreground-600 whitespace-pre-wrap font-sans">{body}{gundemDahil ? `\n\nGÜNDEM\n${ctx.gundem.map((g) => `${g.siraNo}. ${g.baslik}`).join('\n')}` : ''}</pre>
        </div>
      </div>
    </div>
  );
}