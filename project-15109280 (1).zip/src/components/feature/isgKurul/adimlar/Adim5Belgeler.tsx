import { useMemo, useRef, useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Badge from '@/components/ui/Badge';
import { useToastActions } from '@/hooks/useToast';
import type { WizardApi } from '../useIsgKurulWizard';
import { indirKurulBelge } from '../useIsgKurulWizard';
import { friendlyKurulError, getBelgeSignedUrl, BELGE_TURU_LABEL, type KurulBelge } from '@/lib/isgKurulService';

type BelgeTur = 'cagri' | 'gundem' | 'tutanak' | 'karar_takip' | 'onceki_kararlar' | 'yapilamadi';

const BELGE_KARTLARI: { tur: BelgeTur; ikon: string; aciklama: string }[] = [
  { tur: 'cagri', ikon: 'ri-mail-send-line', aciklama: 'Üyelere gönderilen resmi toplantı davetiyesi. (Hazır şablon.)' },
  { tur: 'gundem', ikon: 'ri-list-ordered', aciklama: 'Toplantı gündem maddeleri belgesi. (Hazır şablon.)' },
  { tur: 'tutanak', ikon: 'ri-file-text-line', aciklama: 'Katılımcı, gündem, görüşme ve kararlarla kurul tutanağı.' },
  { tur: 'karar_takip', ikon: 'ri-checkbox-multiple-line', aciklama: 'Bu toplantının kararları ve sorumlu/termin takip formu.' },
  { tur: 'onceki_kararlar', ikon: 'ri-history-line', aciklama: 'Önceki dönemlerden açık/devam eden kararlar ve aksiyon takibi.' },
  { tur: 'yapilamadi', ikon: 'ri-calendar-close-line', aciklama: 'Toplantı yapılamadığına dair resmi tutanak. (Şablon + belge.)' },
];

/** ADIM 5 — Belgeler: kurul toplantısına ait tüm belgelerin üretimi/yüklenmesi. */
export default function Adim5Belgeler({ ctx }: { ctx: WizardApi }) {
  const { addToast } = useToastActions();
  const [bAd, setBAd] = useState('');
  const [bKategori, setBKategori] = useState('İSG Kurulu');
  const [bFile, setBFile] = useState<File | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const belgeGruplari = useMemo(() => {
    const m: Record<string, KurulBelge[]> = {};
    for (const b of ctx.belgeler) (m[b.belgeTuru] ??= []).push(b);
    return m;
  }, [ctx.belgeler]);

  const olustur = async (tur: BelgeTur) => {
    try {
      const r = await ctx.generateKurulBelge(tur);
      if (r) {
        indirKurulBelge(r.fileBase64, r.fileName);
        if (r.evrakHatasi) {
          // Belge üretildi ama Evraklar listesine yazılamadı: sessizce gizleme.
          addToast({ title: "Evraklar'a kaydedilemedi", message: `${BELGE_TURU_LABEL[tur]} oluşturuldu ancak Evraklar listesine eklenemedi: ${r.evrakHatasi}`, type: 'warning' });
        } else {
          addToast({ title: 'Belge oluşturuldu', message: `${BELGE_TURU_LABEL[tur]} oluşturuldu ve Evraklar'a kaydedildi.`, type: 'success' });
        }
      }
    } catch (e) {
      addToast({ title: 'Oluşturulamadı', message: friendlyKurulError(e), type: 'error' });
    }
  };

  const ac = async (b: KurulBelge) => {
    if (!b.storagePath) { addToast({ title: 'Dosya yok', message: 'Bu belge için dosya bulunamadı.', type: 'warning' }); return; }
    try {
      const url = await getBelgeSignedUrl(b.storagePath);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
      addToast({ title: 'Açılamadı', message: friendlyKurulError(e), type: 'error' });
    }
  };

  const kullaniciYukle = async () => {
    if (!bFile) { addToast({ title: 'Dosya seçin', message: 'Bir dosya seçmelisiniz.', type: 'warning' }); return; }
    try {
      await ctx.uploadKullaniciBelge(bFile, bAd.trim() || bFile.name, bKategori);
      setBAd(''); setBFile(null); if (fileRef.current) fileRef.current.value = '';
      addToast({ title: 'Belge yüklendi', message: 'Belge eklendi ve Evraklar\'a kaydedildi.', type: 'success' });
    } catch (e) {
      addToast({ title: 'Yüklenemedi', message: friendlyKurulError(e), type: 'error' });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_minmax(0,320px)] gap-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {BELGE_KARTLARI.map((k) => {
          const liste = belgeGruplari[k.tur] ?? [];
          return (
            <div key={k.tur} className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 flex flex-col">
              <div className="flex items-center gap-2">
                <span className="w-9 h-9 rounded-md bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-300 flex items-center justify-center flex-shrink-0"><i className={`${k.ikon} text-lg`} /></span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground-900 truncate">{BELGE_TURU_LABEL[k.tur]}</p>
                  <p className="text-[10px] text-foreground-500 line-clamp-2">{k.aciklama}</p>
                </div>
              </div>
              <div className="mt-2.5 flex items-center gap-1.5">
                <Button variant="primary" size="sm" className="whitespace-nowrap flex-1" leftIcon={<i className="ri-add-line" />} isLoading={ctx.busy === `belge-${k.tur}`} onClick={() => olustur(k.tur)}>Oluştur</Button>
                {liste.length > 0 && <Badge variant="success">{liste.length}</Badge>}
              </div>
              {liste.length > 0 && (
                <ul className="mt-2 space-y-1">
                  {liste.slice(0, 3).map((b) => (
                    <li key={b.id}>
                      <button type="button" onClick={() => ac(b)} className="w-full flex items-center gap-1.5 text-[11px] text-primary-600 hover:underline cursor-pointer text-left">
                        <i className="ri-download-2-line flex-shrink-0" /><span className="truncate">{b.dosyaAdi ?? b.belgeAdi ?? 'Belge'}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          );
        })}
      </div>

      {/* SAĞ — Kullanıcı belgesi */}
      <div className="space-y-3">
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2.5">
          <p className="text-sm font-semibold text-foreground-900 flex items-center gap-1.5"><i className="ri-upload-2-line text-primary-500" /> Kullanıcı Belgesi</p>
          <Input label="Belge Adı" value={bAd} onChange={(e) => setBAd(e.target.value)} placeholder="Örn: Yangın Söndürme Sistemi Bakım Tutanağı" />
          <Input label="Kategori" value={bKategori} onChange={(e) => setBKategori(e.target.value)} />
          <div>
            <span className="block text-sm font-medium text-foreground-800 mb-1">Dosya</span>
            <input ref={fileRef} type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,image/jpeg,image/png,image/webp" onChange={(e) => setBFile(e.target.files?.[0] ?? null)} className="isg-input w-full text-sm py-2" />
            {bFile && <p className="mt-1 text-[11px] text-foreground-500">{bFile.name} · {Math.round(bFile.size / 1024)} KB</p>}
          </div>
          <Button variant="primary" size="sm" className="whitespace-nowrap w-full" leftIcon={<i className="ri-save-line" />} isLoading={ctx.busy === 'belge-upload'} onClick={kullaniciYukle}>Yükle</Button>
          <p className="text-[10px] text-foreground-500">Belge adı serbesttir; katalog türüne bağlı olmak zorunda değildir. Belge seçili kategoriye kaydedilir.</p>
        </div>

        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500 mb-2">Toplantı Belgeleri ({ctx.belgeler.length})</p>
          {ctx.belgeler.length === 0 ? (
            <p className="text-xs text-foreground-400 text-center py-4">Henüz belge oluşturulmadı.</p>
          ) : (
            <ul className="space-y-1.5 max-h-[260px] overflow-y-auto pr-0.5">
              {ctx.belgeler.map((b) => (
                <li key={b.id} className="flex items-center gap-2">
                  <i className="ri-file-text-line text-foreground-400 flex-shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-foreground-800 truncate">{b.belgeAdi ?? BELGE_TURU_LABEL[b.belgeTuru] ?? 'Belge'}</p>
                    <p className="text-[10px] text-foreground-500">{BELGE_TURU_LABEL[b.belgeTuru] ?? b.belgeTuru}</p>
                  </div>
                  <button type="button" onClick={() => ac(b)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer" title="Aç / İndir"><i className="ri-eye-line text-xs" /></button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}