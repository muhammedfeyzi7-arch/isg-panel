import { useMemo, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Search from '@/components/ui/Search';
import type { WizardApi } from './useIsgKurulWizard';
import { KURUL_ZORUNLU_ROLLER, KURUL_ROL_OPTIONS } from '@/lib/isgKurulService';

const TEHLIKE_LABEL: Record<string, string> = {
  cok_tehlikeli: 'Çok Tehlikeli',
  tehlikeli: 'Tehlikeli',
  az_tehlikeli: 'Az Tehlikeli',
};

/** ADIM 1 — Kurul Bilgileri (firma/tesis/tehlike/dönem + zorunlu ve diğer kurul üyeleri). */
export default function Adim1Kurul({ ctx }: { ctx: WizardApi }) {
  const { firma, donem, uyeler, personelHavuz } = ctx;
  const [panel, setPanel] = useState<'none' | 'personel' | 'manual'>('none');
  const [editId, setEditId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [rol, setRol] = useState<string>('Diğer Üye');
  const [uyelikTuru, setUyelikTuru] = useState<'asil' | 'yedek'>('asil');
  // manuel form
  const [mAd, setMAd] = useState('');
  const [mSoyad, setMSoyad] = useState('');
  const [mRol, setMRol] = useState('Diğer Üye');
  const [mOzel, setMOzel] = useState('');
  const [mDepartman, setMDepartman] = useState('');
  const [mEmail, setMEmail] = useState('');
  const [mTel, setMTel] = useState('');

  const rolSet = useMemo(() => new Set(uyeler.map((u) => u.rol)), [uyeler]);
  const eksikZorunlu = useMemo(() => KURUL_ZORUNLU_ROLLER.filter((r) => !rolSet.has(r)), [rolSet]);

  const filtreli = useMemo(() => {
    const s = search.trim().toLocaleLowerCase('tr');
    if (!s) return personelHavuz;
    return personelHavuz.filter((p) => p.adSoyad.toLocaleLowerCase('tr').includes(s) || p.gorev.toLocaleLowerCase('tr').includes(s));
  }, [personelHavuz, search]);

  const kapat = () => { setPanel('none'); setEditId(null); setRol('Diğer Üye'); setUyelikTuru('asil'); setSearch(''); };

  const mevcutEkle = async () => {
    if (!editId) return;
    await ctx.addUyeFromPersonel(editId, rol, uyelikTuru);
    kapat();
  };

  const manuelEkle = async () => {
    const adSoyad = `${mAd} ${mSoyad}`.trim();
    if (!adSoyad) return;
    if (editId) {
      await ctx.updateUyeFields(editId, { adSoyad, rol: mRol, email: mEmail || null, telefon: mTel || null, departman: mDepartman || null, ozelGorev: mOzel || null });
    } else {
      await ctx.addManualUye({ adSoyad, rol: mRol, uyelikTuru, ozelGorev: mOzel, departman: mDepartman, email: mEmail, telefon: mTel });
    }
    setMAd(''); setMSoyad(''); setMOzel(''); setMDepartman(''); setMEmail(''); setMTel('');
    kapat();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,220px)_minmax(0,1fr)_minmax(0,300px)] gap-3">
      {/* SOL — Bağlam */}
      <div className="space-y-3">
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-3">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500 mb-2">Kurul Bilgileri</p>
          <BilgiSatiri label="Firma" value={firma?.unvan ?? '—'} />
          <BilgiSatiri label="Tesis / İşyeri" value={[firma?.ilce, firma?.il].filter(Boolean).join(' / ') || firma?.unvan || '—'} />
          <BilgiSatiri label="Tehlike Sınıfı" value={TEHLIKE_LABEL[firma?.tehlikeSinifi ?? ''] ?? '—'} />
          <BilgiSatiri label="Kurul Dönemi" value={donem ? `${donem.yil} 1. Dönem` : '—'} />
        </div>
        <div className="rounded-lg border border-primary-200/60 dark:border-primary-500/25 bg-primary-50 dark:bg-primary-500/10 p-3">
          <p className="text-xs font-medium text-foreground-800 flex items-center gap-1.5"><i className="ri-information-line" /> Yasal Bilgi</p>
          <p className="text-[11px] text-foreground-600 mt-1 leading-relaxed">
            İSG Kurulu; işveren/işveren vekili, İSG uzmanı, işyeri hekimi ve çalışan temsilcilerinden oluşur. Zorunlu üyeler eksikse kurul tamamlanamaz.
          </p>
        </div>
      </div>

      {/* ORTA — Üyeler */}
      <div className="space-y-3 min-w-0">
        {eksikZorunlu.length > 0 && (
          <div className="rounded-lg border border-warning-300/60 dark:border-warning-500/30 bg-warning-50 dark:bg-warning-500/10 px-3 py-2">
            <p className="text-xs font-medium text-foreground-800 flex items-center gap-1.5">
              <i className="ri-alert-line text-warning-600" /> Zorunlu üyeler eksik: {eksikZorunlu.length}
            </p>
            <div className="flex flex-wrap gap-1 mt-1.5">
              {eksikZorunlu.map((r) => <Badge key={r} variant="warning">{r}</Badge>)}
            </div>
          </div>
        )}

        <div className="flex items-center justify-between gap-2">
          <p className="text-sm font-semibold text-foreground-900">Kurul Üyeleri</p>
          <div className="flex items-center gap-1.5">
            <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-user-add-line" />} onClick={() => { setPanel('personel'); setEditId(null); }}>Mevcut Personelden Ekle</Button>
            <Button variant="primary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-add-line" />} onClick={() => { setPanel('manual'); setEditId(null); setMRol('Diğer Üye'); }}>Manuel Üye Ekle</Button>
          </div>
        </div>

        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 overflow-hidden">
          {uyeler.length === 0 ? (
            <p className="text-sm text-foreground-500 text-center py-10">Henüz kurul üyesi yok. Sağdan üye ekleyin.</p>
          ) : (
            <ul className="divide-y divide-background-200/70 dark:divide-background-400/20">
              {uyeler.map((u) => (
                <li key={u.id} className="flex items-center gap-2.5 px-3 py-2">
                  <span className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 text-[10px] font-semibold flex items-center justify-center flex-shrink-0">{u.adSoyad.slice(0, 2).toUpperCase()}</span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground-900 truncate">{u.adSoyad}{u.disUye && <span className="ml-1.5 text-[10px] text-accent-600 dark:text-accent-400">• manuel</span>}</p>
                    <p className="text-[11px] text-foreground-500 truncate">{u.rol}{u.departman ? ` · ${u.departman}` : ''}{u.email ? ` · ${u.email}` : ''}</p>
                  </div>
                  <Badge variant={u.uyelikTuru === 'asil' ? 'info' : 'secondary'}>{u.uyelikTuru === 'asil' ? 'Asil' : 'Yedek'}</Badge>
                  <button type="button" onClick={() => { setPanel('manual'); setEditId(u.id); setMAd(u.adSoyad.split(' ')[0] ?? ''); setMSoyad(u.adSoyad.split(' ').slice(1).join(' ')); setMRol(u.rol); setMOzel(u.ozelGorev ?? ''); setMDepartman(u.departman ?? ''); setMEmail(u.email ?? ''); setMTel(u.telefon ?? ''); }} className="w-7 h-7 rounded-md flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer" title="Düzenle"><i className="ri-pencil-line" /></button>
                  <button type="button" onClick={() => ctx.removeUye(u.id)} className="w-7 h-7 rounded-md flex items-center justify-center text-danger-500 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer" title="Sil"><i className="ri-delete-bin-line" /></button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* SAĞ — Üye Ekle / Düzenle */}
      <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
        {panel === 'none' ? (
          <div className="flex flex-col items-center justify-center text-center py-8 gap-2">
            <span className="w-10 h-10 rounded-full bg-background-200 dark:bg-background-300/40 flex items-center justify-center text-foreground-400"><i className="ri-user-settings-line text-lg" /></span>
            <p className="text-xs text-foreground-500">Üye eklemek veya düzenlemek için soldaki butonları kullanın.</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold text-foreground-900">{editId ? 'Üye Düzenle' : 'Üye Ekle'}</p>
              <button type="button" onClick={kapat} className="w-6 h-6 rounded flex items-center justify-center text-foreground-400 hover:bg-background-200 cursor-pointer"><i className="ri-close-line" /></button>
            </div>
            <div className="flex items-center gap-1 bg-background-100 dark:bg-background-200/60 rounded-full p-0.5">
              <TabBtn active={panel === 'personel'} onClick={() => setPanel('personel')} label="Mevcut Personel" />
              <TabBtn active={panel === 'manual'} onClick={() => setPanel('manual')} label="Manuel Giriş" />
            </div>

            {panel === 'personel' ? (
              <div className="space-y-2">
                <Search placeholder="Personel ara..." value={search} onSearch={setSearch} size="sm" debounceMs={250} />
                <div className="max-h-[220px] overflow-y-auto rounded-md border border-background-200/70 dark:border-background-400/25">
                  {filtreli.length === 0 ? (
                    <p className="text-xs text-foreground-400 text-center py-6">Personel bulunamadı.</p>
                  ) : filtreli.map((p) => (
                    <button key={p.id} type="button" onClick={() => setEditId(p.id)} className={`w-full text-left px-2.5 py-2 hover:bg-background-100 dark:hover:bg-background-200/50 cursor-pointer ${editId === p.id ? 'bg-primary-50 dark:bg-primary-500/15' : ''}`}>
                      <p className="text-xs font-medium text-foreground-800 truncate">{p.adSoyad}</p>
                      <p className="text-[10px] text-foreground-500 truncate">{p.gorev}</p>
                    </button>
                  ))}
                </div>
                <Select label="Kuruldaki Rol" options={KURUL_ROL_OPTIONS.map((r) => ({ value: r, label: r }))} value={rol} onChange={(e) => setRol(e.target.value)} />
                <UyelikTuruSec value={uyelikTuru} onChange={setUyelikTuru} />
                <Button variant="primary" size="sm" className="whitespace-nowrap w-full" leftIcon={<i className="ri-add-line" />} disabled={!editId} isLoading={ctx.busy === 'uye'} onClick={mevcutEkle}>Ekle</Button>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="grid grid-cols-2 gap-2">
                  <Input label="Ad" value={mAd} onChange={(e) => setMAd(e.target.value)} />
                  <Input label="Soyad" value={mSoyad} onChange={(e) => setMSoyad(e.target.value)} />
                </div>
                <Select label="Görev / Rol" options={KURUL_ROL_OPTIONS.map((r) => ({ value: r, label: r }))} value={mRol} onChange={(e) => setMRol(e.target.value)} />
                {!editId && <UyelikTuruSec value={uyelikTuru} onChange={setUyelikTuru} />}
                <Input label="Özel Görev (varsa)" value={mOzel} onChange={(e) => setMOzel(e.target.value)} />
                <Input label="Birim / Departman" value={mDepartman} onChange={(e) => setMDepartman(e.target.value)} />
                <Input label="E-posta (varsa)" value={mEmail} onChange={(e) => setMEmail(e.target.value)} />
                <Input label="Telefon (varsa)" value={mTel} onChange={(e) => setMTel(e.target.value)} />
                <Button variant="primary" size="sm" className="whitespace-nowrap w-full" leftIcon={<i className="ri-save-line" />} isLoading={ctx.busy === 'uye'} onClick={manuelEkle}>{editId ? 'Güncelle' : 'Kaydet'}</Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function BilgiSatiri({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-2 py-1">
      <span className="text-[11px] text-foreground-500 flex-shrink-0">{label}</span>
      <span className="text-xs text-foreground-800 text-right">{value}</span>
    </div>
  );
}

function TabBtn({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button type="button" onClick={onClick} className={`flex-1 px-2 py-1 rounded-full text-[11px] font-medium whitespace-nowrap cursor-pointer ${active ? 'bg-primary-500 text-inverse' : 'text-foreground-600'}`}>{label}</button>
  );
}

function UyelikTuruSec({ value, onChange }: { value: 'asil' | 'yedek'; onChange: (v: 'asil' | 'yedek') => void }) {
  return (
    <div>
      <span className="block text-sm font-medium text-foreground-800 mb-1">Üyelik Türü</span>
      <div className="flex items-center gap-1 bg-background-100 dark:bg-background-200/60 rounded-full p-0.5">
        <TabBtn active={value === 'asil'} onClick={() => onChange('asil')} label="Asil" />
        <TabBtn active={value === 'yedek'} onClick={() => onChange('yedek')} label="Yedek" />
      </div>
    </div>
  );
}