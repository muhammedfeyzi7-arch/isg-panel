import { useEffect, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import { useToastActions } from '@/hooks/useToast';
import type { WizardApi } from '../useIsgKurulWizard';
import { KARAR_DURUM_OPTIONS, KARAR_ONCELIK_OPTIONS, friendlyKurulError, fetchFirmaAcikKararlar, type Karar } from '@/lib/isgKurulService';

const DURUM_VARIANT: Record<string, 'default' | 'warning' | 'success' | 'info' | 'secondary' | 'danger' | 'accent'> = {
  acik: 'warning', devam_ediyor: 'info', tamamlandi: 'success', iptal: 'secondary', gecikti: 'danger',
};

/** ADIM 4 — Gündem & Kararlar (karar takip). */
export default function Adim4GundemKarar({ ctx }: { ctx: WizardApi }) {
  const { addToast } = useToastActions();
  const [kararMetni, setKararMetni] = useState('');
  const [sorumlu, setSorumlu] = useState('');
  const [termin, setTermin] = useState('');
  const [oncelik, setOncelik] = useState('orta');
  const [durum, setDurum] = useState('acik');
  const [acikKararlar, setAcikKararlar] = useState<Karar[]>([]);

  useEffect(() => {
    if (!ctx.firma) return;
    let alive = true;
    fetchFirmaAcikKararlar(ctx.firma.id, ctx.toplanti?.id ?? '')
      .then((r) => { if (alive) setAcikKararlar(r); })
      .catch(() => { if (alive) setAcikKararlar([]); });
    return () => { alive = false; };
  }, [ctx.firma, ctx.toplanti?.id]);

  const secenekler = ctx.personelHavuz.map((p) => ({ value: p.id, label: p.adSoyad }));

  const kararEkle = async () => {
    if (!kararMetni.trim()) return;
    try {
      await ctx.addKararMadde({ kararMetni: kararMetni.trim(), sorumluPersonelId: sorumlu || null, termin: termin || null, oncelik, durum });
      setKararMetni(''); setSorumlu(''); setTermin('');
      addToast({ title: 'Karar eklendi', message: 'Karar kaydedildi.', type: 'success' });
    } catch (e) {
      addToast({ title: 'Hata', message: friendlyKurulError(e), type: 'error' });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
      {/* SOL — Gündem & Görüşmeler */}
      <div className="space-y-2">
        <p className="text-sm font-semibold text-foreground-900">Gündem & Görüşmeler</p>
        {ctx.gundem.length === 0 ? (
          <p className="text-xs text-foreground-400 text-center py-8">Gündem maddesi yok. Adım 2'den ekleyin.</p>
        ) : (
          <ul className="space-y-2">
            {ctx.gundem.map((g) => (
              <li key={g.id} className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-2.5">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-md bg-background-200 dark:bg-background-300/40 text-foreground-600 text-[11px] font-semibold flex items-center justify-center flex-shrink-0">{g.siraNo}</span>
                  <p className="text-sm font-medium text-foreground-800 flex-1 min-w-0 truncate">{g.baslik}</p>
                  <label className="flex items-center gap-1 text-[11px] text-foreground-500 cursor-pointer">
                    <input type="checkbox" checked={g.goruldu} onChange={(e) => ctx.editGundem(g.id, { goruldu: e.target.checked })} className="w-3.5 h-3.5 accent-primary-500" /> Görüşüldü
                  </label>
                </div>
                <textarea defaultValue={g.gorusmeNotu ?? ''} onBlur={(e) => ctx.editGundem(g.id, { gorusmeNotu: e.target.value })} placeholder="Görüşme / açıklama notu..." rows={2} className="isg-input isg-input-sm w-full mt-2 resize-none" />
              </li>
            ))}
          </ul>
        )}

        {acikKararlar.length > 0 && (
          <div className="rounded-lg border border-warning-300/50 dark:border-warning-500/25 bg-warning-50/60 dark:bg-warning-500/10 p-2.5">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500 mb-1.5">Önceki Açık Kararlar ({acikKararlar.length})</p>
            <ul className="space-y-1">
              {acikKararlar.map((k) => (
                <li key={k.id} className="flex items-center gap-2">
                  <Badge variant={DURUM_VARIANT[k.durum] ?? 'default'}>{KARAR_DURUM_OPTIONS.find((o) => o.value === k.durum)?.label ?? k.durum}</Badge>
                  <span className="text-xs text-foreground-700 truncate flex-1 min-w-0">{k.kararMetni}</span>
                  {k.termin && <span className="text-[10px] text-foreground-500 whitespace-nowrap">{k.termin}</span>}
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* SAĞ — Kararlar */}
      <div className="space-y-2">
        <p className="text-sm font-semibold text-foreground-900">Kararlar ({ctx.kararlar.length})</p>
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-2.5 space-y-2">
          <Input label="Karar Metni" value={kararMetni} onChange={(e) => setKararMetni(e.target.value)} placeholder="Alınan karar..." />
          <div className="grid grid-cols-2 gap-2">
            <Select label="Sorumlu" options={secenekler} value={sorumlu} onChange={(e) => setSorumlu(e.target.value)} placeholder="Seçin" searchable />
            <DatePicker label="Termin" value={termin} onChange={(e) => setTermin(e.target.value)} />
            <Select label="Öncelik" options={KARAR_ONCELIK_OPTIONS.map((o) => ({ value: o.value, label: o.label }))} value={oncelik} onChange={(e) => setOncelik(e.target.value)} />
            <Select label="Durum" options={KARAR_DURUM_OPTIONS.map((o) => ({ value: o.value, label: o.label }))} value={durum} onChange={(e) => setDurum(e.target.value)} />
          </div>
          <Button variant="primary" size="sm" className="whitespace-nowrap w-full" leftIcon={<i className="ri-add-line" />} onClick={kararEkle}>Karar Ekle</Button>
        </div>

        {ctx.kararlar.length > 0 && (
          <ul className="space-y-1.5">
            {ctx.kararlar.map((k) => (
              <li key={k.id} className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-2.5">
                <div className="flex items-start gap-2">
                  <Badge variant="secondary">{k.kararNo ?? '—'}</Badge>
                  <p className="text-xs text-foreground-800 flex-1 min-w-0">{k.kararMetni}</p>
                  <button type="button" onClick={() => ctx.removeKarar(k.id)} className="w-6 h-6 rounded flex items-center justify-center text-danger-500 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer flex-shrink-0"><i className="ri-delete-bin-line text-xs" /></button>
                </div>
                <div className="flex flex-wrap items-center gap-2 mt-1.5">
                  <select value={k.durum} onChange={(e) => ctx.editKarar(k.id, { durum: e.target.value })} className="isg-input isg-input-sm w-auto cursor-pointer">
                    {KARAR_DURUM_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </select>
                  {k.sorumluAd && <span className="text-[11px] text-foreground-500">Sorumlu: {k.sorumluAd}</span>}
                  {k.termin && <span className="text-[11px] text-foreground-500">Termin: {k.termin}</span>}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}