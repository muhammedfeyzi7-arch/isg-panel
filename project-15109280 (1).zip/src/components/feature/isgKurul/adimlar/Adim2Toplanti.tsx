import { useState } from 'react';
import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import TimePicker from '@/components/ui/TimePicker';
import { useToastActions } from '@/hooks/useToast';
import type { ToplantiTaslak, WizardApi } from '../useIsgKurulWizard';
import { indirKurulBelge } from '../useIsgKurulWizard';
import { TOPLANTI_TUR_OPTIONS, friendlyKurulError } from '@/lib/isgKurulService';

const GUNDEM_SABLONU = [
  'Önceki toplantı kararlarının gözden geçirilmesi',
  'İş kazaları ve ramak kala olaylarının değerlendirilmesi',
  'Risk değerlendirmesi sonuçlarının görüşülmesi',
  'Acil durum planı ve tatbikat hazırlıkları',
  'Çalışanların İSG eğitim durumu',
  'Saha denetimleri bulguları',
  'Öneriler ve dilekler',
];

/** ADIM 2 — Toplantı Detayları, Gündem ve Çağrı Formu. */
export default function Adim2Toplanti({ ctx, taslak, setTaslak }: { ctx: WizardApi; taslak: ToplantiTaslak; setTaslak: (t: ToplantiTaslak) => void }) {
  const { addToast } = useToastActions();
  const [yeniBaslik, setYeniBaslik] = useState('');
  const [aiOneri, setAiOneri] = useState<{ baslik: string; aciklama: string; oncelik: string }[]>([]);

  const set = (patch: Partial<ToplantiTaslak>) => setTaslak({ ...taslak, ...patch });

  const kaydet = async () => {
    try {
      await ctx.saveToplantiBilgi(taslak);
      addToast({ title: 'Kaydedildi', message: 'Toplantı bilgileri güncellendi.', type: 'success' });
    } catch (e) {
      addToast({ title: 'Hata', message: friendlyKurulError(e), type: 'error' });
    }
  };

  const maddeEkle = async (baslik?: string) => {
    const b = (baslik ?? yeniBaslik).trim();
    if (!b) return;
    await ctx.addGundemMadde(b);
    setYeniBaslik('');
  };

  const sablonYukle = async () => {
    for (const b of GUNDEM_SABLONU) await ctx.addGundemMadde(b);
    addToast({ title: 'Şablon yüklendi', message: `${GUNDEM_SABLONU.length} gündem maddesi eklendi.`, type: 'success' });
  };

  const aiCalistir = async () => {
    try {
      const oneriler = await ctx.aiGundem();
      if (oneriler.length === 0) {
        addToast({ title: 'Öneri bulunamadı', message: 'AI önerisi üretilemedi veya veri yetersiz.', type: 'warning' });
        return;
      }
      setAiOneri(oneriler);
    } catch (e) {
      addToast({ title: 'AI hatası', message: friendlyKurulError(e), type: 'error' });
    }
  };

  const siraDegistir = async (idx: number, yon: -1 | 1) => {
    const a = ctx.gundem[idx];
    const b = ctx.gundem[idx + yon];
    if (!a || !b) return;
    await ctx.editGundem(a.id, { siraNo: b.siraNo });
    await ctx.editGundem(b.id, { siraNo: a.siraNo });
  };

  const cagriOlustur = async () => {
    try {
      const r = await ctx.generateKurulBelge('cagri');
      if (r) { indirKurulBelge(r.fileBase64, r.fileName); addToast({ title: 'Çağrı formu oluşturuldu', message: 'Çağrı formu oluşturuldu ve Evraklar\'a kaydedildi.', type: 'success' }); }
    } catch (e) {
      addToast({ title: 'Oluşturulamadı', message: friendlyKurulError(e), type: 'error' });
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_minmax(0,320px)] gap-3">
      <div className="space-y-3 min-w-0">
        {/* Toplantı Bilgileri */}
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-semibold text-foreground-900 flex items-center gap-1.5"><i className="ri-calendar-event-line text-primary-500" /> Toplantı Bilgileri</p>
            <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-save-line" />} isLoading={ctx.busy === 'toplanti'} onClick={kaydet}>Kaydet</Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <Input label="Toplantı No" value={taslak.toplantiNo} onChange={(e) => set({ toplantiNo: e.target.value })} />
            <DatePicker label="Toplantı Tarihi" required value={taslak.tarih} onChange={(e) => set({ tarih: e.target.value })} />
            <TimePicker label="Başlangıç Saati" value={taslak.saat} onChange={(e) => set({ saat: e.target.value })} />
            <Input label="Toplantı Yeri" value={taslak.yer} onChange={(e) => set({ yer: e.target.value })} />
            <Select label="Toplantı Türü" options={TOPLANTI_TUR_OPTIONS.map((t) => ({ value: t.value, label: t.label }))} value={taslak.tur} onChange={(e) => set({ tur: e.target.value })} />
            <DatePicker label="Çağrı Tarihi" value={taslak.cagriTarihi} onChange={(e) => set({ cagriTarihi: e.target.value })} />
          </div>
        </div>

        {/* Gündem */}
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
            <p className="text-sm font-semibold text-foreground-900 flex items-center gap-1.5"><i className="ri-list-ordered text-primary-500" /> Toplantı Gündemi</p>
            <div className="flex items-center gap-1.5">
              <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-file-list-line" />} onClick={sablonYukle}>Şablondan Yükle</Button>
              <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-sparkling-line" />} isLoading={ctx.busy === 'ai'} onClick={aiCalistir}>AI Öner</Button>
            </div>
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Input value={yeniBaslik} onChange={(e) => setYeniBaslik(e.target.value)} placeholder="Yeni gündem maddesi..." />
            <Button variant="primary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-add-line" />} onClick={() => maddeEkle()}>Ekle</Button>
          </div>
          {ctx.gundem.length === 0 ? (
            <p className="text-xs text-foreground-400 text-center py-6">Henüz gündem maddesi yok.</p>
          ) : (
            <ul className="space-y-1.5">
              {ctx.gundem.map((g, i) => (
                <li key={g.id} className="flex items-center gap-2 rounded-md border border-background-200/70 dark:border-background-400/20 px-2.5 py-1.5">
                  <span className="w-6 h-6 rounded-md bg-background-200 dark:bg-background-300/40 text-foreground-600 text-[11px] font-semibold flex items-center justify-center flex-shrink-0">{g.siraNo}</span>
                  <input value={g.baslik} onChange={(e) => ctx.editGundem(g.id, { baslik: e.target.value })} className="flex-1 bg-transparent text-sm text-foreground-800 focus:outline-none min-w-0" />
                  <button type="button" disabled={i === 0} onClick={() => siraDegistir(i, -1)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-400 hover:bg-background-200 disabled:opacity-30 cursor-pointer"><i className="ri-arrow-up-line text-xs" /></button>
                  <button type="button" disabled={i === ctx.gundem.length - 1} onClick={() => siraDegistir(i, 1)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-400 hover:bg-background-200 disabled:opacity-30 cursor-pointer"><i className="ri-arrow-down-line text-xs" /></button>
                  <button type="button" onClick={() => ctx.removeGundem(g.id)} className="w-6 h-6 rounded flex items-center justify-center text-danger-500 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer"><i className="ri-delete-bin-line text-xs" /></button>
                </li>
              ))}
            </ul>
          )}

          {aiOneri.length > 0 && (
            <div className="mt-2.5 rounded-md border border-accent-200/60 dark:border-accent-500/25 bg-accent-50 dark:bg-accent-500/10 p-2.5">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500 mb-1.5">AI Önerileri (onaylayınca eklenir)</p>
              <div className="space-y-1">
                {aiOneri.map((o, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <span className="flex-1 text-xs text-foreground-700 truncate">{o.baslik}</span>
                    <Button variant="ghost" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-add-line" />} onClick={() => { void maddeEkle(o.baslik); setAiOneri((p) => p.filter((_, j) => j !== idx)); }}>Ekle</Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SAĞ — Çağrı Formu */}
      <div className="space-y-3">
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
          <p className="text-sm font-semibold text-foreground-900 flex items-center gap-1.5 mb-2"><i className="ri-mail-send-line text-primary-500" /> Toplantı Çağrı Formu</p>
          <div className="rounded-md border border-dashed border-background-300 dark:border-background-400/40 bg-background-50 dark:bg-background-100/40 p-3 space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="w-8 h-8 rounded-md bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-300 flex items-center justify-center"><i className="ri-file-text-line" /></span>
              <div className="min-w-0">
                <p className="text-xs font-medium text-foreground-800 truncate">Çağrı Formu (DOCX)</p>
                <p className="text-[10px] text-foreground-500">Firma, işyeri, toplantı bilgileri, üyeler ve gündem ile üretilir.</p>
              </div>
            </div>
            <Button variant="primary" size="sm" className="whitespace-nowrap w-full" leftIcon={<i className="ri-add-line" />} isLoading={ctx.busy === 'belge-cagri'} onClick={cagriOlustur}>Çağrı Formu Oluştur</Button>
            <p className="text-[10px] text-foreground-500">Şablon sistem tarafından otomatik oluşturulur; oluşturulan belge Evraklar'a kaydedilir.</p>
          </div>
        </div>

        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
          <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500 mb-2">Toplantı Özeti</p>
          <OzetSatiri label="Toplantı No" value={taslak.toplantiNo || '—'} />
          <OzetSatiri label="Tarih / Saat" value={`${taslak.tarih || '—'} ${taslak.saat || ''}`} />
          <OzetSatiri label="Yer" value={taslak.yer || '—'} />
          <OzetSatiri label="Tür" value={TOPLANTI_TUR_OPTIONS.find((t) => t.value === taslak.tur)?.label ?? '—'} />
          <OzetSatiri label="Gündem" value={<Badge variant="info">{ctx.gundem.length} madde</Badge>} />
        </div>
      </div>
    </div>
  );
}

function OzetSatiri({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-2 py-1">
      <span className="text-[11px] text-foreground-500">{label}</span>
      <span className="text-xs text-foreground-800 text-right">{value}</span>
    </div>
  );
}