import { useCallback, useEffect, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import { useModalActions } from '@/hooks/useModal';
import {
  fetchKurul,
  fetchToplantilar,
  fetchUyeler,
  fetchBelgeler,
  TOPLANTI_DURUM_LABEL,
  BELGE_TURU_LABEL,
  type Kurul,
  type Toplanti,
  type KurulUye,
  type KurulBelge,
} from '@/lib/isgKurulService';
import IsgKurulSihirbaz from './IsgKurulSihirbaz';

interface Props {
  firmaId: string;
  role: 'uzman' | 'firma';
  onClose: () => void;
  onChanged?: () => void;
}

const DURUM_VARIANT: Record<string, 'default' | 'warning' | 'success' | 'info' | 'secondary' | 'danger' | 'accent'> = {
  planlandi: 'info', cagri_gonderildi: 'accent', devam_ediyor: 'warning', tamamlandi: 'success', iptal: 'secondary',
};

function tarihGoster(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

/**
 * EVRAKLAR → İSG KURULU bölümü. Firma bazlı kurul kayıtları, toplantılar ve belgeler.
 * Toplantı sihirbazını MEVCUT büyük modal yığını üzerinde açar (yeni modal motoru yok).
 */
export default function IsgKurulPanel({ firmaId, role, onClose, onChanged }: Props) {
  const { openModal, closeModal } = useModalActions();
  const [kurul, setKurul] = useState<Kurul | null>(null);
  const [toplantilar, setToplantilar] = useState<Toplanti[]>([]);
  const [uyeler, setUyeler] = useState<KurulUye[]>([]);
  const [belgeler, setBelgeler] = useState<KurulBelge[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const yukle = useCallback(() => {
    setLoading(true);
    setError(null);
    Promise.all([fetchKurul(firmaId), fetchToplantilar(firmaId), fetchBelgeler(firmaId)])
      .then(async ([k, t, b]) => {
        setKurul(k);
        setToplantilar(t);
        setBelgeler(b);
        if (k) setUyeler(await fetchUyeler(k.id));
        else setUyeler([]);
      })
      .catch((e) => setError(e instanceof Error ? e.message : 'Yüklenemedi'))
      .finally(() => setLoading(false));
  }, [firmaId]);

  useEffect(() => { yukle(); }, [yukle]);

  const sihirbazAc = useCallback(() => {
    const id = openModal({
      title: 'İSG Kurulu Toplantı Sihirbazı',
      description: 'İş Sağlığı ve Güvenliği Kurulu toplantısını 5 adımda oluşturun; çağrı, gündem ve belgeleri yönetin.',
      variant: 'large',
      wide: true,
      width: 1360,
      height: typeof window !== 'undefined' ? Math.max(700, window.innerHeight - 40) : 820,
      minWidth: 1024,
      minHeight: 620,
      showFooter: false,
      closable: true,
      resizable: true,
      maximizable: true,
      bodyLayout: 'fill',
      content: (
        <IsgKurulSihirbaz
          firmaId={firmaId}
          role={role}
          onClose={() => { closeModal(id); yukle(); onChanged?.(); }}
          onChanged={() => { onChanged?.(); }}
        />
      ),
    });
  }, [openModal, closeModal, firmaId, role, yukle, onChanged]);

  if (loading) return <div className="flex justify-center py-16"><Loading size="lg" text="İSG Kurulu yükleniyor..." /></div>;
  if (error) return <ErrorState message={error} onRetry={yukle} />;

  const ozetBelge = belgeler.length;

  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h3 className="text-base font-semibold text-foreground-950">İSG Kurulu</h3>
          <p className="text-xs text-foreground-500 mt-0.5">Kurul üyeleri, toplantılar, kararlar ve belgeleri yönetin.</p>
        </div>
        <Button variant="primary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-add-line" />} onClick={sihirbazAc}>
          İSG Kurulu Toplantısı Oluştur
        </Button>
      </div>

      {/* Özet */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <OzetKart ikon="ri-team-line" etiket="Kurul Üyesi" deger={uyeler.length} />
        <OzetKart ikon="ri-calendar-event-line" etiket="Toplantı" deger={toplantilar.length} />
        <OzetKart ikon="ri-file-list-3-line" etiket="Belge" deger={ozetBelge} />
        <OzetKart ikon="ri-checkbox-multiple-line" etiket="Son Toplantı" deger={toplantilar[0] ? tarihGoster(toplantilar[0].tarih) : '—'} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_minmax(0,300px)] gap-3">
        {/* Toplantılar */}
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 overflow-hidden">
          <div className="px-3 py-2 border-b border-background-200/70 dark:border-background-400/25 flex items-center justify-between">
            <p className="text-sm font-semibold text-foreground-900">Toplantılar</p>
            <span className="text-xs text-foreground-500">{toplantilar.length}</span>
          </div>
          {toplantilar.length === 0 ? (
            <EmptyState icon="ri-calendar-event-line" title="Toplantı yok" description="İlk İSG Kurulu toplantısını oluşturun." />
          ) : (
            <ul className="divide-y divide-background-200/70 dark:divide-background-400/20">
              {toplantilar.map((t) => (
                <li key={t.id} className="flex items-center gap-3 px-3 py-2.5">
                  <span className="w-9 h-9 rounded-md bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-300 flex items-center justify-center flex-shrink-0"><i className="ri-calendar-check-line" /></span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground-900 truncate">{t.toplantiNo || 'Toplantı'} · {tarihGoster(t.tarih)} {t.saat ?? ''}</p>
                    <p className="text-[11px] text-foreground-500 truncate">{t.yer || '—'}</p>
                  </div>
                  <Badge variant={DURUM_VARIANT[t.durum] ?? 'default'}>{TOPLANTI_DURUM_LABEL[t.durum] ?? t.durum}</Badge>
                  <Button variant="secondary" size="sm" className="whitespace-nowrap" onClick={sihirbazAc}>Aç</Button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Kurul Üyeleri + Belgeler */}
        <div className="space-y-3">
          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500 mb-2">Kurul Üyeleri</p>
            {uyeler.length === 0 ? (
              <p className="text-xs text-foreground-400 text-center py-3">Henüz üye yok.</p>
            ) : (
              <ul className="space-y-1.5">
                {uyeler.map((u) => (
                  <li key={u.id} className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-background-200 dark:bg-background-300/40 text-foreground-600 text-[9px] font-semibold flex items-center justify-center flex-shrink-0">{u.adSoyad.slice(0, 2).toUpperCase()}</span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs text-foreground-800 truncate">{u.adSoyad}</p>
                      <p className="text-[10px] text-foreground-500 truncate">{u.rol}</p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
            <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500 mb-2">Belgeler</p>
            {belgeler.length === 0 ? (
              <p className="text-xs text-foreground-400 text-center py-3">Henüz belge yok.</p>
            ) : (
              <ul className="space-y-1.5 max-h-[220px] overflow-y-auto pr-0.5">
                {belgeler.slice(0, 10).map((b) => (
                  <li key={b.id} className="flex items-center gap-2">
                    <i className="ri-file-text-line text-foreground-400 flex-shrink-0" />
                    <span className="text-xs text-foreground-700 truncate flex-1 min-w-0">{b.belgeAdi ?? BELGE_TURU_LABEL[b.belgeTuru] ?? 'Belge'}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      <div className="flex justify-end pt-1 border-t isg-divider">
        <Button variant="primary" size="sm" className="whitespace-nowrap" onClick={onClose}>Tamamla</Button>
      </div>
    </div>
  );
}

function OzetKart({ ikon, etiket, deger }: { ikon: string; etiket: string; deger: string | number }) {
  return (
    <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-2.5 flex items-center gap-2.5">
      <span className="w-9 h-9 rounded-md bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-300 flex items-center justify-center flex-shrink-0"><i className={`${ikon} text-lg`} /></span>
      <div className="min-w-0">
        <p className="text-[11px] text-foreground-500 truncate">{etiket}</p>
        <p className="text-base font-semibold text-foreground-950 leading-tight truncate">{deger}</p>
      </div>
    </div>
  );
}