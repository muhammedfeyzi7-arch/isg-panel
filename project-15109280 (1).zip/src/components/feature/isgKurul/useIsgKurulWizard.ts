import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  fetchFirmaBilgi,
  fetchPersonelHavuzu,
  fetchKurul,
  ensureKurul,
  ensureAktifDonem,
  fetchUyeler,
  upsertUye,
  deleteUye,
  fetchToplantilar,
  createToplanti,
  updateToplanti,
  fetchKatilimcilar,
  ensureKatilimcilar,
  updateKatilim,
  fetchGundem,
  addGundem,
  updateGundem,
  deleteGundem,
  fetchKararlar,
  addKarar,
  updateKarar,
  deleteKarar,
  fetchBelgeler,
  createBelgeRow,
  generateBelgeDocx,
  sendKurulMail,
  logGonderim,
  fetchGundemAi,
  updateKurul,
  BELGE_TURU_LABEL,
  type FirmaBilgi,
  type Kurul,
  type Donem,
  type KurulUye,
  type PersonelHavuz,
  type Toplanti,
  type Katilimci,
  type Gundem,
  type Karar,
  type KurulBelge,
} from '@/lib/isgKurulService';
import { uploadUretilenBelge, EVRAK_SOURCE_TYPE } from '@/lib/evrakSource';
import { fetchEvrakTurleri, friendlyEvrakError } from '@/lib/evrakService';

/** İSG Kurulu belge türleri (üretilen + şablon). */
export type BelgeTuru = 'cagri' | 'gundem' | 'tutanak' | 'karar_takip' | 'onceki_kararlar' | 'yapilamadi';

/** Belge türü → edge DOCX üretim aksiyonu. */
const BELGE_ACTION: Record<BelgeTuru, 'cagri-docx' | 'gundem-docx' | 'tutanak-docx' | 'karar-takip-docx' | 'onceki-kararlar-docx' | 'yapilamadi-docx'> = {
  cagri: 'cagri-docx',
  gundem: 'gundem-docx',
  tutanak: 'tutanak-docx',
  karar_takip: 'karar-takip-docx',
  onceki_kararlar: 'onceki-kararlar-docx',
  yapilamadi: 'yapilamadi-docx',
};

export interface ToplantiTaslak {
  toplantiNo: string;
  tarih: string;
  saat: string;
  yer: string;
  tur: string;
  cagriTarihi: string;
}

export interface WizardApi {
  firma: FirmaBilgi | null;
  kurul: Kurul | null;
  donem: Donem | null;
  toplanti: Toplanti | null;
  uyeler: KurulUye[];
  katilimcilar: Katilimci[];
  gundem: Gundem[];
  kararlar: Karar[];
  belgeler: KurulBelge[];
  personelHavuz: PersonelHavuz[];
  loading: boolean;
  error: string | null;
  busy: string | null;
  refresh: () => void;
  // üye
  addUyeFromPersonel: (personelId: string, rol: string, uyelikTuru: 'asil' | 'yedek') => Promise<void>;
  addManualUye: (data: { adSoyad: string; rol: string; uyelikTuru: 'asil' | 'yedek'; ozelGorev?: string; departman?: string; email?: string; telefon?: string }) => Promise<void>;
  updateUyeRol: (uyeId: string, rol: string) => Promise<void>;
  updateUyeFields: (uyeId: string, patch: Partial<KurulUye>) => Promise<void>;
  removeUye: (uyeId: string) => Promise<void>;
  setBaskanSekreter: (baskanId: string | null, sekreterId: string | null) => Promise<void>;
  // toplantı
  ensureToplanti: (taslak: ToplantiTaslak) => Promise<Toplanti | null>;
  saveToplantiBilgi: (taslak: ToplantiTaslak) => Promise<void>;
  // gündem
  addGundemMadde: (baslik: string, aciklama?: string) => Promise<void>;
  editGundem: (id: string, patch: Partial<Gundem>) => Promise<void>;
  removeGundem: (id: string) => Promise<void>;
  aiGundem: () => Promise<{ baslik: string; aciklama: string; oncelik: string }[]>;
  // katılımcı
  saveKatilim: (id: string, katilim: string, neden: string | null) => Promise<void>;
  sendCagriMail: (payload: { to: string[]; subject: string; body: string; gundemDahil: boolean }) => Promise<number>;
  // karar
  addKararMadde: (p: { kararMetni: string; sorumluPersonelId?: string | null; termin?: string | null; oncelik?: string | null; durum?: string; gundemId?: string | null }) => Promise<void>;
  editKarar: (id: string, patch: Partial<Karar>) => Promise<void>;
  removeKarar: (id: string) => Promise<void>;
  // belge
  generateKurulBelge: (tur: BelgeTuru) => Promise<{ fileName: string; fileBase64: string; evrakHatasi?: string } | null>;
  uploadKullaniciBelge: (file: File, ad: string, kategori: string) => Promise<void>;
}

function base64ToBlob(b64: string, mime: string): Blob {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

function downloadBlob(base64: string, fileName: string, mime: string) {
  const url = URL.createObjectURL(base64ToBlob(base64, mime));
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function indirKurulBelge(base64: string, fileName: string) {
  downloadBlob(base64, fileName, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
}

/**
 * İSG Kurulu toplantı sihirbazının durum/aksiyon hook'u.
 * Mevcut tablolar + edge function'lar üzerinden çalışır; yeni paralel sistem yoktur.
 */
export function useIsgKurulWizard(firmaId: string): WizardApi {
  const [firma, setFirma] = useState<FirmaBilgi | null>(null);
  const [kurul, setKurul] = useState<Kurul | null>(null);
  const [donem, setDonem] = useState<Donem | null>(null);
  const [toplanti, setToplanti] = useState<Toplanti | null>(null);
  const [uyeler, setUyeler] = useState<KurulUye[]>([]);
  const [katilimcilar, setKatilimcilar] = useState<Katilimci[]>([]);
  const [gundem, setGundem] = useState<Gundem[]>([]);
  const [kararlar, setKararlar] = useState<Karar[]>([]);
  const [belgeler, setBelgeler] = useState<KurulBelge[]>([]);
  const [personelHavuz, setPersonelHavuz] = useState<PersonelHavuz[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const evrakTurIdRef = useRef<string | null>(null);

  const toplantiId = toplanti?.id ?? '';

  const loadToplantiAlt = useCallback(async (tid: string) => {
    const [kat, gun, kar, bel] = await Promise.all([
      fetchKatilimcilar(tid).catch(() => [] as Katilimci[]),
      fetchGundem(tid).catch(() => [] as Gundem[]),
      fetchKararlar(tid).catch(() => [] as Karar[]),
      fetchBelgeler(firmaId, tid).catch(() => [] as KurulBelge[]),
    ]);
    setKatilimcilar(kat);
    setGundem(gun);
    setKararlar(kar);
    setBelgeler(bel);
  }, [firmaId]);

  const init = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const fb = await fetchFirmaBilgi(firmaId);
      if (!fb) throw new Error('FIRMA_YOK');
      setFirma(fb);
      const k = await ensureKurul(firmaId, fb.osgbId);
      setKurul(k);
      const d = await ensureAktifDonem(firmaId, k.id, fb.osgbId);
      setDonem(d);
      const u = await fetchUyeler(k.id);
      setUyeler(u);
      const ph = await fetchPersonelHavuzu(firmaId);
      setPersonelHavuz(ph);
      // Mevcut toplantı var mı? (panelden düzenleme akışı için ilk toplantıyı da yükler)
      const toplantilar = await fetchToplantilar(firmaId);
      if (toplantilar.length > 0) {
        const t = toplantilar[0];
        setToplanti(t);
        await loadToplantiAlt(t.id);
      }
    } catch (e) {
      setError(friendlyEvrakError(e));
    } finally {
      setLoading(false);
    }
  }, [firmaId, loadToplantiAlt]);

  useEffect(() => { void init(); }, [init]);

  const refreshUyeler = useCallback(async () => {
    if (!kurul) return;
    setUyeler(await fetchUyeler(kurul.id));
  }, [kurul]);

  const addUyeFromPersonel = useCallback(async (personelId: string, rol: string, uyelikTuru: 'asil' | 'yedek') => {
    if (!kurul || !firma) return;
    setBusy('uye');
    try {
      const p = personelHavuz.find((x) => x.id === personelId);
      await upsertUye({
        kurulId: kurul.id, osgbId: firma.osgbId, firmaId,
        rol, uyelikTuru, personelId, adSoyad: p?.adSoyad ?? null,
        email: p?.email ?? null, telefon: p?.telefon ?? null, disUye: false,
      });
      await refreshUyeler();
    } finally { setBusy(null); }
  }, [kurul, firma, firmaId, personelHavuz, refreshUyeler]);

  const addManualUye = useCallback(async (data: { adSoyad: string; rol: string; uyelikTuru: 'asil' | 'yedek'; ozelGorev?: string; departman?: string; email?: string; telefon?: string }) => {
    if (!kurul || !firma) return;
    setBusy('uye');
    try {
      await upsertUye({
        kurulId: kurul.id, osgbId: firma.osgbId, firmaId,
        rol: data.rol, uyelikTuru: data.uyelikTuru, disUye: true,
        adSoyad: data.adSoyad, email: data.email ?? null, telefon: data.telefon ?? null,
        departman: data.departman ?? null, ozelGorev: data.ozelGorev ?? null,
      });
      await refreshUyeler();
    } finally { setBusy(null); }
  }, [kurul, firma, firmaId, refreshUyeler]);

  const updateUyeRol = useCallback(async (uyeId: string, rol: string) => {
    await updateUyeFieldsInternal(uyeId, { rol });
    await refreshUyeler();
  }, [refreshUyeler]);

  const updateUyeFieldsInternal = async (uyeId: string, patch: Partial<KurulUye>) => {
    const u = uyeler.find((x) => x.id === uyeId);
    if (!u || !kurul || !firma) return;
    await upsertUye({
      kurulId: u.kurulId, osgbId: firma.osgbId, firmaId,
      rol: patch.rol ?? u.rol, uyelikTuru: patch.uyelikTuru ?? u.uyelikTuru,
      personelId: u.personelId, adSoyad: patch.adSoyad ?? u.adSoyad,
      email: patch.email ?? u.email, telefon: patch.telefon ?? u.telefon,
      departman: patch.departman ?? u.departman, ozelGorev: patch.ozelGorev ?? u.ozelGorev,
      disUye: u.disUye,
    }, uyeId);
  };

  const updateUyeFields = useCallback(async (uyeId: string, patch: Partial<KurulUye>) => {
    await updateUyeFieldsInternal(uyeId, patch);
    await refreshUyeler();
  }, [refreshUyeler, uyeler, kurul, firma]); // eslint-disable-line react-hooks/exhaustive-deps

  const removeUye = useCallback(async (uyeId: string) => {
    await deleteUye(uyeId);
    await refreshUyeler();
  }, [refreshUyeler]);

  const setBaskanSekreter = useCallback(async (baskanId: string | null, sekreterId: string | null) => {
    if (!kurul) return;
    await updateKurul(kurul.id, { baskanPersonelId: baskanId, sekreterPersonelId: sekreterId });
    setKurul({ ...kurul, baskanPersonelId: baskanId, sekreterPersonelId: sekreterId });
  }, [kurul]);

  const ensureToplanti = useCallback(async (taslak: ToplantiTaslak): Promise<Toplanti | null> => {
    if (!kurul || !donem || !firma) return null;
    if (toplanti) {
      await updateToplanti(toplanti.id, {
        toplantiNo: taslak.toplantiNo, tarih: taslak.tarih, saat: taslak.saat,
        yer: taslak.yer, tur: taslak.tur, cagriTarihi: taslak.cagriTarihi,
      });
      const guncel = { ...toplanti, ...taslak };
      setToplanti(guncel);
      await ensureKatilimcilar(guncel, firma.osgbId);
      await loadToplantiAlt(toplanti.id);
      return guncel;
    }
    const id = await createToplanti({
      kurulId: kurul.id, donemId: donem.id, osgbId: firma.osgbId, firmaId,
      toplantiNo: taslak.toplantiNo, tarih: taslak.tarih, saat: taslak.saat,
      yer: taslak.yer, tur: taslak.tur, cagriTarihi: taslak.cagriTarihi,
    });
    const yeni: Toplanti = {
      id, kurulId: kurul.id, donemId: donem.id, firmaId,
      toplantiNo: taslak.toplantiNo, tarih: taslak.tarih, saat: taslak.saat,
      yer: taslak.yer, tur: taslak.tur, durum: 'planlandi', cagriTarihi: taslak.cagriTarihi, aciklama: null,
    };
    setToplanti(yeni);
    await ensureKatilimcilar(yeni, firma.osgbId);
    await loadToplantiAlt(id);
    return yeni;
  }, [kurul, donem, firma, firmaId, toplanti, loadToplantiAlt]);

  const saveToplantiBilgi = useCallback(async (taslak: ToplantiTaslak) => {
    if (!toplanti) return;
    setBusy('toplanti');
    try {
      await ensureToplanti(taslak);
    } finally { setBusy(null); }
  }, [toplanti, ensureToplanti]);

  const addGundemMadde = useCallback(async (baslik: string, aciklama?: string) => {
    if (!toplanti || !donem || !kurul || !firma) return;
    await addGundem({
      toplantiId: toplanti.id, donemId: donem.id, kurulId: kurul.id, firmaId, osgbId: firma.osgbId,
      siraNo: gundem.length + 1, baslik, aciklama: aciklama ?? null,
    });
    setGundem(await fetchGundem(toplanti.id));
  }, [toplanti, donem, kurul, firma, gundem.length]);

  const editGundem = useCallback(async (id: string, patch: Partial<Gundem>) => {
    await updateGundem(id, patch);
    if (toplanti) setGundem(await fetchGundem(toplanti.id));
  }, [toplanti]);

  const removeGundem = useCallback(async (id: string) => {
    await deleteGundem(id);
    if (toplanti) setGundem(await fetchGundem(toplanti.id));
  }, [toplanti]);

  const aiGundem = useCallback(async () => {
    if (!kurul || !donem) return [];
    setBusy('ai');
    try {
      const res = await fetchGundemAi(firmaId, kurul.id, donem.id);
      return (res.oneriler ?? []).map((o) => ({ baslik: o.baslik, aciklama: o.aciklama, oncelik: o.oncelik }));
    } finally { setBusy(null); }
  }, [firmaId, kurul, donem]);

  const saveKatilim = useCallback(async (id: string, katilim: string, neden: string | null) => {
    await updateKatilim(id, katilim, neden);
    if (toplanti) setKatilimcilar(await fetchKatilimcilar(toplanti.id));
  }, [toplanti]);

  const sendCagriMail = useCallback(async (payload: { to: string[]; subject: string; body: string; gundemDahil: boolean }): Promise<number> => {
    if (!firma || !kurul || !donem || !toplanti) return 0;
    setBusy('mail');
    try {
      const gundemMetni = payload.gundemDahil
        ? `\n\nGÜNDEM\n${gundem.map((g) => `${g.siraNo}. ${g.baslik}`).join('\n')}`
        : '';
      const body = `${payload.body}${gundemMetni}`;
      const res = await sendKurulMail({ to: payload.to, subject: payload.subject, body });
      await logGonderim({
        firmaId, osgbId: firma.osgbId, kurulId: kurul.id, donemId: donem.id, toplantiId: toplanti.id,
        tur: 'cagri', yontem: 'email', durum: 'gonderildi', recipientTo: payload.to.join('; '),
        konu: payload.subject, icerik: body, mailLogId: res.mailLogId ?? null,
      });
      await updateToplanti(toplanti.id, { durum: 'cagri_gonderildi' });
      setToplanti({ ...toplanti, durum: 'cagri_gonderildi' });
      return payload.to.length;
    } catch (e) {
      await logGonderim({
        firmaId, osgbId: firma.osgbId, kurulId: kurul.id, donemId: donem.id, toplantiId: toplanti.id,
        tur: 'cagri', yontem: 'email', durum: 'hata', recipientTo: payload.to.join('; '),
        konu: payload.subject, hata: e instanceof Error ? e.message : String(e),
      });
      throw e;
    } finally { setBusy(null); }
  }, [firma, kurul, donem, toplanti, gundem, firmaId]);

  const addKararMadde = useCallback(async (p: { kararMetni: string; sorumluPersonelId?: string | null; termin?: string | null; oncelik?: string | null; durum?: string; gundemId?: string | null }) => {
    if (!toplanti || !donem || !kurul || !firma) return;
    await addKarar({
      toplantiId: toplanti.id, donemId: donem.id, kurulId: kurul.id, firmaId, osgbId: firma.osgbId,
      kararNo: `K-${String(kararlar.length + 1).padStart(2, '0')}`,
      gundemId: p.gundemId ?? null, kararMetni: p.kararMetni,
      sorumluPersonelId: p.sorumluPersonelId ?? null, termin: p.termin ?? null,
      oncelik: p.oncelik ?? 'orta', durum: p.durum ?? 'acik',
    });
    setKararlar(await fetchKararlar(toplanti.id));
  }, [toplanti, donem, kurul, firma, firmaId, kararlar.length]);

  const editKarar = useCallback(async (id: string, patch: Partial<Karar>) => {
    await updateKarar(id, patch);
    if (toplanti) setKararlar(await fetchKararlar(toplanti.id));
  }, [toplanti]);

  const removeKarar = useCallback(async (id: string) => {
    await deleteKarar(id);
    if (toplanti) setKararlar(await fetchKararlar(toplanti.id));
  }, [toplanti]);

  const evrakTurId = useCallback(async (): Promise<string | null> => {
    if (evrakTurIdRef.current) return evrakTurIdRef.current;
    try {
      const [tum] = await Promise.all([fetchEvrakTurleri()]);
      const t = tum.find((x) => x.code === 'ISG_KURULU' && x.ownerType === 'firma');
      evrakTurIdRef.current = t?.id ?? null;
      return evrakTurIdRef.current;
    } catch { return null; }
  }, []);

  const dalEtiket = (tur: string): string => BELGE_TURU_LABEL[tur] ?? tur;

  const generateKurulBelge = useCallback(async (tur: BelgeTuru): Promise<{ fileName: string; fileBase64: string; evrakHatasi?: string } | null> => {
    if (!toplanti || !kurul || !donem || !firma) return null;
    setBusy(`belge-${tur}`);
    try {
      // Toplantı belgesi satırı oluştur (edge function belgeId ile üretir).
      const belgeId = await createBelgeRow({
        toplantiId: toplanti.id, kurulId: kurul.id, donemId: donem.id, firmaId, osgbId: firma.osgbId,
        belgeTuru: tur, belgeAdi: dalEtiket(tur), durum: 'uretildi',
      });
      // Her tür kendi GERÇEK şablonundan üretilir (gündem / yapılamadı / karar takip ayrı belgelerdir).
      const r = await generateBelgeDocx(BELGE_ACTION[tur], belgeId);
      const result = { fileName: r.fileName, fileBase64: r.fileBase64 };
      // Merkezi Evrak Merkezi'ne kaydet (mevcut altyapı) — belge DB'de kaybolmasın.
      // Evraka yazılamazsa üretim yine başarılıdır ama kullanıcı sessizce kandırılmaz:
      // evrakHatasi döndürülür, Adim5 kullanıcıya uyarı gösterir.
      let evrakHatasi: string | undefined;
      try {
        const tid = await evrakTurId();
        await uploadUretilenBelge({
          firmaId,
          documentTypeId: tid,
          kategori: tid ? null : 'İSG Kurulu',
          title: `${dalEtiket(tur)}${toplanti.toplantiNo ? ` — ${toplanti.toplantiNo}` : ''}`,
          description: 'İSG Kurulu toplantı belgesi (üretilen belge).',
          sourceType: EVRAK_SOURCE_TYPE.ISG_KURULU,
          sourceId: toplanti.id,
          sourceRef: tur,
          blob: base64ToBlob(result.fileBase64, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'),
          fileName: result.fileName,
          revizeEt: true,
        });
      } catch (e) {
        evrakHatasi = friendlyEvrakError(e);
      }
      setBelgeler(await fetchBelgeler(firmaId, toplanti.id));
      return { ...result, evrakHatasi };
    } finally { setBusy(null); }
  }, [toplanti, kurul, donem, firma, firmaId, evrakTurId]);

  const uploadKullaniciBelge = useCallback(async (file: File, ad: string, kategori: string) => {
    if (!toplanti || !kurul || !donem || !firma) return;
    setBusy('belge-upload');
    try {
      // Kullanıcı belgesi: serbest isim; evrak_turleri zorunlu DEĞİL.
      const { uploadEvrak } = await import('@/lib/evrakService');
      const res = await uploadEvrak({
        ownerType: 'firma',
        firmaId,
        documentTypeId: null,
        kategori: kategori || 'İSG Kurulu',
        title: ad || file.name,
        description: `İSG Kurulu belgesi (${BELGE_TURU_LABEL.kullanici}).`,
        sourceType: EVRAK_SOURCE_TYPE.ISG_KURULU,
        sourceId: toplanti.id,
        sourceRef: 'kullanici',
        belgeDurumu: 'generated',
        file,
      });
      // Kurul belge satırına evraka ait STORAGE yolunu da yaz: böylece belge
      // Kurul modalından da preview/download ile açılabilir (aynı 'evraklar' bucket'ı).
      await createBelgeRow({
        toplantiId: toplanti.id, kurulId: kurul.id, donemId: donem.id, firmaId, osgbId: firma.osgbId,
        belgeTuru: 'kullanici', belgeAdi: ad || file.name, dosyaAdi: file.name,
        storagePath: res.storagePath ?? null, mimeType: file.type, fileSize: file.size, durum: 'yuklendi',
      });
      setBelgeler(await fetchBelgeler(firmaId, toplanti.id));
    } finally { setBusy(null); }
  }, [toplanti, kurul, donem, firma, firmaId]);

  return useMemo<WizardApi>(() => ({
    firma, kurul, donem, toplanti, uyeler, katilimcilar, gundem, kararlar, belgeler, personelHavuz,
    loading, error, busy, refresh: init,
    addUyeFromPersonel, addManualUye, updateUyeRol, updateUyeFields, removeUye, setBaskanSekreter,
    ensureToplanti, saveToplantiBilgi,
    addGundemMadde, editGundem, removeGundem, aiGundem,
    saveKatilim, sendCagriMail,
    addKararMadde, editKarar, removeKarar,
    generateKurulBelge, uploadKullaniciBelge,
  }), [
    firma, kurul, donem, toplanti, uyeler, katilimcilar, gundem, kararlar, belgeler, personelHavuz,
    loading, error, busy, init,
    addUyeFromPersonel, addManualUye, updateUyeRol, updateUyeFields, removeUye, setBaskanSekreter,
    ensureToplanti, saveToplantiBilgi, addGundemMadde, editGundem, removeGundem, aiGundem,
    saveKatilim, sendCagriMail, addKararMadde, editKarar, removeKarar,
    generateKurulBelge, uploadKullaniciBelge,
  ]);
}