import { useCallback, useEffect, useMemo, useState } from 'react';
import Button from '@/components/ui/Button';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import Badge from '@/components/ui/Badge';
import { useIsgKurulWizard, type ToplantiTaslak } from './useIsgKurulWizard';
import Adim1Kurul from './adimlar/Adim1Kurul';
import Adim2Toplanti from './adimlar/Adim2Toplanti';
import Adim3Katilimci from './adimlar/Adim3Katilimci';
import Adim4GundemKarar from './adimlar/Adim4GundemKarar';
import Adim5Belgeler from './adimlar/Adim5Belgeler';
import { KURUL_ZORUNLU_ROLLER } from '@/lib/isgKurulService';

interface Props {
  firmaId: string;
  role: 'uzman' | 'firma';
  onClose: () => void;
  onChanged?: () => void;
}

const ADIMLAR = [
  { no: 1, baslik: 'Kurul Bilgileri', alt: 'Üyeler ve yetkiler' },
  { no: 2, baslik: 'Toplantı Detayları', alt: 'Tarih, gündem ve planlama' },
  { no: 3, baslik: 'Katılımcılar', alt: 'Çağrı ve davet' },
  { no: 4, baslik: 'Gündem & Kararlar', alt: 'Görüşmeler ve aksiyonlar' },
  { no: 5, baslik: 'Belgeler', alt: 'Oluştur ve yönet' },
];

function bosTaslak(): ToplantiTaslak {
  const t = new Date();
  const tarih = t.toISOString().slice(0, 10);
  return { toplantiNo: `${t.getFullYear()}/01`, tarih, saat: '10:00', yer: '', tur: 'olagan', cagriTarihi: tarih };
}

/**
 * İSG KURULU TOPLANTI SİHİRBAZI — 5 adımlı tek büyük modal içeriği.
 * Mevcut SharedUI dilini kullanır; mevcut tablolar + edge function'larla çalışır.
 */
export default function IsgKurulSihirbaz({ firmaId, role: _role, onClose, onChanged }: Props) {
  const ctx = useIsgKurulWizard(firmaId);
  const [step, setStep] = useState(1);
  const [taslak, setTaslak] = useState<ToplantiTaslak>(bosTaslak());

  // Mevcut toplantı yüklenince taslağa yansıt.
  useEffect(() => {
    if (ctx.toplanti) {
      setTaslak({
        toplantiNo: ctx.toplanti.toplantiNo ?? '',
        tarih: ctx.toplanti.tarih ?? '',
        saat: ctx.toplanti.saat ?? '10:00',
        yer: ctx.toplanti.yer ?? '',
        tur: ctx.toplanti.tur || 'olagan',
        cagriTarihi: ctx.toplanti.cagriTarihi ?? '',
      });
    }
  }, [ctx.toplanti?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const eksikZorunlu = useMemo(() => {
    const set = new Set(ctx.uyeler.map((u) => u.rol));
    return KURUL_ZORUNLU_ROLLER.filter((r) => !set.has(r));
  }, [ctx.uyeler]);

  const ileri = useCallback(async () => {
    if (step === 1) {
      // Toplantıyı (yoksa) oluştur ki sonraki adımlar gündem/katılım/belge kaydedebilsin.
      await ctx.ensureToplanti(taslak);
      setStep(2);
      return;
    }
    if (step === 2) { await ctx.saveToplantiBilgi(taslak); setStep(3); return; }
    if (step < 5) setStep(step + 1);
  }, [step, ctx, taslak]);

  const tamamla = useCallback(() => {
    onChanged?.();
    onClose();
  }, [onChanged, onClose]);

  if (ctx.loading) {
    return <div className="flex justify-center py-20"><Loading size="lg" text="İSG Kurulu yükleniyor..." /></div>;
  }
  if (ctx.error) {
    return <ErrorState message={ctx.error} onRetry={ctx.refresh} />;
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Üst — 5 adımlı progress */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {ADIMLAR.map((a, i) => {
          const active = step === a.no;
          const done = step > a.no;
          return (
            <div key={a.no} className="flex items-center gap-1.5 flex-shrink-0">
              <button
                type="button"
                onClick={() => { if (a.no < step) setStep(a.no); }}
                className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-left cursor-pointer transition-colors ${
                  active
                    ? 'border-primary-300 bg-primary-50 dark:border-primary-500/40 dark:bg-primary-500/10'
                    : 'border-background-200/70 dark:border-background-400/25 hover:bg-background-100 dark:hover:bg-background-200/40'
                }`}
              >
                <span className={`w-6 h-6 rounded-full flex items-center justify-center text-[11px] font-semibold flex-shrink-0 ${
                  active ? 'bg-primary-500 text-inverse' : done ? 'bg-success-500 text-inverse' : 'bg-background-200 dark:bg-background-300/50 text-foreground-600'
                }`}>
                  {done ? <i className="ri-check-line" /> : a.no}
                </span>
                <span className="min-w-0">
                  <span className={`block text-xs font-semibold whitespace-nowrap ${active ? 'text-foreground-900' : 'text-foreground-700'}`}>{a.baslik}</span>
                  <span className="block text-[10px] text-foreground-500 whitespace-nowrap">{a.alt}</span>
                </span>
              </button>
              {i < ADIMLAR.length - 1 && <i className="ri-arrow-right-s-line text-foreground-300" />}
            </div>
          );
        })}
        <span className="ml-auto text-xs text-foreground-500 whitespace-nowrap">{step} / 5</span>
      </div>

      {/* Gövde */}
      <div className="min-h-[420px]">
        {step === 1 && <Adim1Kurul ctx={ctx} />}
        {step === 2 && <Adim2Toplanti ctx={ctx} taslak={taslak} setTaslak={setTaslak} />}
        {step === 3 && <Adim3Katilimci ctx={ctx} taslak={taslak} />}
        {step === 4 && <Adim4GundemKarar ctx={ctx} />}
        {step === 5 && <Adim5Belgeler ctx={ctx} />}
      </div>

      {/* Eksik zorunlu uyarı */}
      {eksikZorunlu.length > 0 && step >= 4 && (
        <div className="rounded-lg border border-warning-300/60 dark:border-warning-500/30 bg-warning-50 dark:bg-warning-500/10 px-3 py-2 flex items-center gap-2">
          <i className="ri-alert-line text-warning-600" />
          <span className="text-xs text-foreground-700">Zorunlu kurul üyeleri eksik olduğu için kurul tamamlanamaz: <strong>{eksikZorunlu.join(', ')}</strong></span>
        </div>
      )}

      {/* Alt bar */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t isg-divider">
        <Button variant="ghost" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-close-line" />} onClick={onClose}>Vazgeç</Button>
        <div className="flex items-center gap-2">
          <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-arrow-left-line" />} onClick={() => setStep((s) => Math.max(1, s - 1))} disabled={step === 1}>Geri</Button>
          {step < 5 ? (
            <Button variant="primary" size="sm" className="whitespace-nowrap" rightIcon={<i className="ri-arrow-right-line" />} onClick={ileri} isLoading={ctx.busy === 'toplanti'}>İleri</Button>
          ) : (
            <Button variant="primary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-check-double-line" />} onClick={tamamla} disabled={eksikZorunlu.length > 0}>
              {eksikZorunlu.length > 0 ? `${eksikZorunlu.length} zorunlu üye eksik` : 'Tamamla'}
            </Button>
          )}
        </div>
      </div>

      {/* Durum rozeti */}
      {ctx.toplanti && (
        <div className="flex items-center gap-2 text-[11px] text-foreground-500">
          <Badge variant="secondary">{ctx.toplanti.toplantiNo || 'Toplantı'}</Badge>
          <span>Toplantı kaydı: {ctx.toplanti.durum}</span>
        </div>
      )}
    </div>
  );
}