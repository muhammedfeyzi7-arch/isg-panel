import { useAuth } from '@/context/AuthContext';
import { useUzmanFirma } from '@/context/UzmanFirmaContext';
import { Z_LAYERS } from '@/utils/layers';
import Select from '@/components/ui/Select';
import BrandLogo from './BrandLogo';
import ThemeToggle from './ThemeToggle';
import NotificationBell from './NotificationBell';
import SupportButton from './support/SupportButton';
import UserProfile from './UserProfile';
import GlobalSearch from './search/UniversalSearch';

interface TopbarProps {
  sidebarCollapsed: boolean;
}

export default function Topbar({ sidebarCollapsed }: TopbarProps) {
  const { profile } = useAuth();
  const { firmalar, selectedFirmaId, setSelectedFirmaId } = useUzmanFirma();
  // Uzman VE Hekim aynı global firma seçicisini kullanır (ortak Personel mimarisi).
  const isFirmaScoped = profile?.role === 'uzman' || profile?.role === 'hekim';
  const isAdmin = profile?.role === 'admin';

  return (
    <header className="isg-topbar flex items-center justify-between px-3 lg:px-4 border-b isg-divider bg-background-100 flex-shrink-0 sticky top-0 shadow-[0_1px_0_0_rgba(0,0,0,0.05)] dark:shadow-none" style={{ zIndex: Z_LAYERS.topbar }}>
      <div className="flex items-center gap-3">
        {/* Mobile Logo — sidebar yok, topbar'da logo göster */}
        <div className="lg:hidden">
          <BrandLogo className="h-7" />
        </div>

        {/* Global modül arama (komut paleti) — aktif panelin gerçek menüsünden arar */}
        <GlobalSearch />

        {/* Uzman / Hekim: global firma seçici */}
        {isFirmaScoped && (
          <div className="hidden md:block w-[15rem] flex-shrink-0">
            <Select
              size="sm"
              searchable
              leftIcon={<i className="ri-building-4-line" />}
              options={[{ value: '', label: 'Tüm Firmalar' }, ...firmalar.map((f) => ({ value: f.id, label: f.unvan }))]}
              value={selectedFirmaId}
              onChange={(e) => setSelectedFirmaId(e.target.value)}
              placeholder="Tüm Firmalar"
            />
          </div>
        )}
      </div>

      <div className="flex items-center gap-1.5">
        <ThemeToggle />
        {!isAdmin && <SupportButton />}
        <NotificationBell />
        <UserProfile />
      </div>
    </header>
  );
}