import { useState, useCallback, useEffect, useRef, type ReactNode } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import TabBar from '@/components/ui/TabBar';
import type { TabBarItem } from '@/components/ui/TabBar';
import IsgGereksinimleriTab from '@/pages/osgb/firmalar/components/IsgGereksinimleriTab';
import FirmaDetayGenelBakis from '@/components/feature/firma-detay/FirmaDetayGenelBakis';
import FirmaDetaySozlesmeler from '@/components/feature/firma-detay/FirmaDetaySozlesmeler';
import FirmaDetayKatip from '@/components/feature/firma-detay/FirmaDetayKatip';
import { ISG_GEREKSINIM_PANELI_KEY, fetchIsgGereksinimPaneliData } from '@/components/feature/firma-detay/isg/IsgGereksinimPaneli';
import { preloadTabData } from '@/lib/tabDataCache';
import { useRealtimeRefresh } from '@/hooks/useRealtimeRefresh';
import { useModalActions } from '@/hooks/useModal';
import { extractRawMessage, friendlyErrorMessage } from '@/lib/errorMessages';
import { useToastActions } from '@/hooks/useToast';
import {
  type FirmaData,
  type FirmaInvite,
  type NaceKod,
  fetchFirma,
  fetchNaceById,
  fetchOsgbUnvan,
  inviteFirmaPanel,
  resendFirmaInvite,
  fetchFirmaInvites,
  resolveCalisanSayisi,
  friendlyFirmaHesapError,
  firmaHizmetiSonlandir,
  firmaHizmetiYenidenBaslat,
} from '@/lib/firmaService';
import {
  fetchFirmaGereksinimleri,
  calculateFirmaRequirements,
  HAZARD_CLASS_LABEL,
  type FirmaGereksinimRow,
} from '@/lib/gereksinimService';
import { fetchFirmaRoleRequirements, type RoleRequirementMap } from '@/lib/atamaRequirement';
import { tehlikeBadgeVariant, formatFirmaKonum, formatFirmaDateTime, formatFirmaDate } from '@/pages/osgb/firmalar/components/firmaUi';
import { getFirmaDetayPermissions, FIRMA_DETAY_ROLE_LABEL, type FirmaDetayRole } from '@/lib/firmaDetayPermissions';

type Sekme = 'genel' | 'katip' | 'isg' | 'sozlesme';

/** Modül dışından doğrudan bir sekmeye yönlendirmek için dışa açık sekme tipi. */
export type FirmaDetayTab = Sekme;

const inviteStatusInfo: Record<FirmaInvite['status'], { label: string; variant: 'success' | 'warning' | 'danger' | 'info' }> = {
  pending: { label: 'Davet Bekliyor', variant: 'info' },
  send_failed: { label: 'E-posta Gönderilemedi', variant: 'warning' },
  accepted: { label: 'Kabul Edildi', variant: 'success' },
  expired: { label: 'Süresi Doldu', variant: 'danger' },
  revoked: { label: 'İptal Edildi', variant: 'warning' },
};

/** Bu oturumda gereksinimleri tazelenmiş firma id'leri. */
const syncedFirmIds = new Set<string>();

interface FirmaDetayModalProps {
  firmaId: string;
  role: FirmaDetayRole;
  /** Modal açılırken aktif olacak sekme (varsayılan: genel). */
  initialSekme?: FirmaDetayTab;
  /** Modal doğrudan düzenleme modunda açılsın mı (liste "Düzenle" aksiyonu). */
  initialEdit?: boolean;
  onClose: () => void;
  onChanged?: () => void;
}

/**
 * TEK Firma Detay Modalı — rol bazlı görünüm ve yetki.
 *
 * Yapı (referans): üst firma özeti + istatistik kartları → 3 sekme
 * (Genel Bakış / İSG Gereksinimleri / Sözleşmeler).
 * Düzenleme AYNI modal içinde (view ↔ edit mode) yapılır; ayrı bir "Firma Düzenle"
 * modalı AÇILMAZ. Mevcut Shared UI (TabBar/Badge/Button/Modal/…) ve mevcut İSG
 * gereksinim motoru yeniden kullanılır.
 */
export default function FirmaDetayModal({ firmaId, role, initialSekme = 'genel', initialEdit = false, onClose, onChanged }: FirmaDetayModalProps) {
  const perms = getFirmaDetayPermissions(role);
  const [sekme, setSekme] = useState<Sekme>(initialSekme);
  const [firma, setFirma] = useState<FirmaData | null>(null);
  const [nace, setNace] = useState<NaceKod | null>(null);
  const [osgbUnvan, setOsgbUnvan] = useState<string | null>(null);
  const [gereksinimler, setGereksinimler] = useState<FirmaGereksinimRow[]>([]);
  const [roleReqs, setRoleReqs] = useState<RoleRequirementMap>({});
  const [invites, setInvites] = useState<FirmaInvite[]>([]);
  const [invitesLoading, setInvitesLoading] = useState(false);
  const [inviting, setInviting] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteAd, setInviteAd] = useState('');
  const [inviteSoyad, setInviteSoyad] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const { addToast } = useToastActions();
  const { openModal, closeModal } = useModalActions();
  const hizmetBusy = useRef(false);
  const [hizmetBusyState, setHizmetBusyState] = useState(false);
  const hizmetSonlandirModalIdRef = useRef('');

  const load = useCallback((silent = false) => {
    if (!silent) {
      setLoading(true);
      setError(null);
    }
    fetchFirma(firmaId)
      .then((f) => {
        setFirma(f);
        setInviteEmail(f.yetkiliEmail === '—' ? '' : f.yetkiliEmail);
        setInviteAd(f.yetkili === '—' ? '' : f.yetkili.split(' ')[0] ?? '');
        setInviteSoyad(f.yetkili === '—' ? '' : f.yetkili.split(' ').slice(1).join(' '));
        Promise.all([
          f.naceId ? fetchNaceById(f.naceId).catch(() => null) : Promise.resolve(null),
          fetchFirmaGereksinimleri(f.id, perms.isgScope).catch(() => [] as FirmaGereksinimRow[]),
          fetchFirmaRoleRequirements(f.id).catch(() => ({}) as RoleRequirementMap),
          fetchOsgbUnvan(f.osgbId).catch(() => null),
        ]).then(([naceData, reqs, roleReqsData, unvan]) => {
          setNace(naceData);
          setGereksinimler(reqs);
          setRoleReqs(roleReqsData);
          setOsgbUnvan(unvan);
        });
      })
      .catch((e) => {
        const raw = extractRawMessage(e);
        if (raw.includes('Firma bulunamadı') || raw.includes('row-level security') || raw.includes('permission denied') || raw.includes('policy')) {
          setError('Bu firma için aktif bir atamanız bulunmuyor veya firma erişimi kapalı.');
        } else {
          setError(friendlyErrorMessage(e, 'Firma detayı yüklenemedi.'));
        }
        setFirma(null);
      })
      .finally(() => setLoading(false));
  }, [firmaId, perms.isgScope]);

  // Realtime: firma / personel / gereksinim / atama değişikliğinde açık firma detayı
  // spinner göstermeden sessizce tazelenir — başka kullanıcının değişikliği F5 olmadan yansır.
  useRealtimeRefresh(['firmalar', 'firma_gereksinimleri', 'atamalar', 'personeller'], () => load(true));

  useEffect(() => {
    if (!firma) return;
    preloadTabData(ISG_GEREKSINIM_PANELI_KEY(firma.id, perms.isgScope), () => fetchIsgGereksinimPaneliData(firma, perms.isgScope));
  }, [firma, perms.isgScope]);

  useEffect(() => {
    let cancelled = false;
    // ÖNCE hızlı yükle: modal veriyi ANINDA gösterir (ilk açılışta ağır hesabı
    // beklemez). Gereksinim tazeleme ARKA PLANDA çalışır; bitince veri sessizce
    // (spinner göstermeden) tazelenir.
    load();
    const run = async () => {
      if (syncedFirmIds.has(firmaId)) return;
      syncedFirmIds.add(firmaId);
      try {
        // Yalnızca bu firmanın gereksinimleri tazelenir. Global "bayat firma" senkronu
        // kaldırıldı: ağırdı ve firma sıralamasını (updated_at) bozuyordu.
        await calculateFirmaRequirements(firmaId);
        if (!cancelled) load(true);
      } catch {
        // Tazeleme başarısız olsa da mevcut veriyle devam edilir.
      }
    };
    void run();
    return () => { cancelled = true; };
  }, [firmaId, load]);

  const loadInvites = useCallback(() => {
    if (!perms.panelYonet) return;
    setInvitesLoading(true);
    fetchFirmaInvites(firmaId)
      .then(setInvites)
      .catch(() => setInvites([]))
      .finally(() => setInvitesLoading(false));
  }, [firmaId, perms.panelYonet]);

  useEffect(() => {
    loadInvites();
  }, [loadInvites]);

  const handleInvite = useCallback(() => {
    if (!firma) return;
    const email = inviteEmail.trim();
    if (!email) {
      addToast({ title: 'E-posta gerekli', message: 'Firma paneli daveti için e-posta adresi girin.', type: 'warning' });
      return;
    }
    if (inviting) return;
    setInviting(true);
    inviteFirmaPanel(firma.id, email, inviteAd.trim() || null, inviteSoyad.trim() || null)
      .then((res) => {
        setFirma((prev) => (prev ? { ...prev, firmaPaneliVar: true } : prev));
        if (res.emailSent) {
          addToast({ title: 'Davet gönderildi', message: `${email} adresine firma paneli daveti gönderildi.`, type: 'success' });
        } else {
          addToast({ title: 'Panel açıldı, e-posta gönderilemedi', message: 'Davet kaydı oluşturuldu ancak e-posta gönderilemedi (Resend yapılandırılmamış).', type: 'warning' });
        }
        loadInvites();
        onChanged?.();
      })
      .catch((err) => addToast({ title: 'Davet gönderilemedi', message: friendlyFirmaHesapError(err), type: 'error' }))
      .finally(() => setInviting(false));
  }, [firma, inviteEmail, inviteAd, inviteSoyad, inviting, addToast, loadInvites, onChanged]);

  const handleResend = useCallback(
    (inv: FirmaInvite) => {
      if (!firma || inviting) return;
      setInviting(true);
      resendFirmaInvite(firma.id, inv.email, inv.firstName || null, inv.lastName || null)
        .then((res) => {
          if (res.emailSent) addToast({ title: 'Davet gönderildi', message: `${inv.email} adresine yeni davet gönderildi.`, type: 'success' });
          else addToast({ title: 'Davet oluşturuldu', message: 'Davet kaydı oluşturuldu ancak e-posta gönderilemedi.', type: 'warning' });
          loadInvites();
        })
        .catch((err) => addToast({ title: 'Davet gönderilemedi', message: friendlyFirmaHesapError(err), type: 'error' }))
        .finally(() => setInviting(false));
    },
    [firma, inviting, addToast, loadInvites],
  );

  const handleHizmetSonlandir = useCallback(() => {
    if (!firma || hizmetBusy.current) return;
    const id = openModal({
      title: 'Hizmeti Sonlandır',
      description: `${firma.ad} — firma hizmet yaşam döngüsü`,
      width: 480,
      minWidth: 380,
      minHeight: 300,
      showFooter: false,
      closable: true,
      content: (
        <HizmetSonlandirModal
          busy={hizmetBusyState}
          onCancel={() => closeModal(id)}
          onConfirm={(neden) => {
            hizmetBusy.current = true;
            setHizmetBusyState(true);
            firmaHizmetiSonlandir(firma.id, neden || null)
              .then(() => {
                addToast({ title: 'Hizmet sonlandırıldı', message: 'Firma "Hizmeti Sonlananlar" sekmesine taşındı.', type: 'success' });
                closeModal(id);
                load();
                onChanged?.();
              })
              .catch((e) => addToast({ title: 'Sonlandırılamadı', message: friendlyErrorMessage(e, 'Hizmet sonlandırılamadı.'), type: 'error' }))
              .finally(() => { hizmetBusy.current = false; setHizmetBusyState(false); });
          }}
        />
      ),
    });
    hizmetSonlandirModalIdRef.current = id;
  }, [firma, hizmetBusyState, openModal, closeModal, addToast, load, onChanged]);

  const handleHizmetYenidenBaslat = useCallback(() => {
    if (!firma || hizmetBusy.current) return;
    hizmetBusy.current = true;
    setHizmetBusyState(true);
    firmaHizmetiYenidenBaslat(firma.id)
      .then(() => {
        addToast({ title: 'Hizmet yeniden başlatıldı', message: 'Firma "Devam Eden Firmalar" sekmesine taşındı.', type: 'success' });
        // Yeniden başlatma sonrası gereksinimler GÜNCEL firma verisiyle OTOMATİK hesaplanır.
        // (Eski atamalar/planlar geri getirilmez; OSGB yeni atama + plan oluşturur.)
        calculateFirmaRequirements(firma.id).catch(() => {});
        load();
        onChanged?.();
      })
      .catch((e) => addToast({ title: 'İşlem başarısız', message: friendlyErrorMessage(e, 'Hizmet yeniden başlatılamadı.'), type: 'error' }))
      .finally(() => { hizmetBusy.current = false; setHizmetBusyState(false); });
  }, [firma, addToast, load, onChanged]);

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <i className="ri-loader-4-line animate-spin text-2xl text-primary-500" />
      </div>
    );
  }

  if (error || !firma) {
    return (
      <div className="py-10 text-center">
        <i className="ri-error-warning-line text-3xl text-warning-500 mb-2 block" />
        <p className="text-sm text-foreground-600">{error || 'Firma bulunamadı.'}</p>
      </div>
    );
  }

  const calisanDeger = resolveCalisanSayisi(firma);
  const hazardLabel = nace ? HAZARD_CLASS_LABEL[nace.tehlike_sinifi] : firma.tehlikeSinifiLabel;
  const sonHesaplama = gereksinimler.length > 0 ? gereksinimler[0].calculated_at : null;
  const hizmetSonlandi = !firma.isActive;

  const sekmeler: TabBarItem[] = [
    { key: 'genel', label: 'Genel Bilgiler', icon: 'ri-apps-2-line' },
    { key: 'katip', label: 'İSG-KATİP', icon: 'ri-links-line' },
    { key: 'isg', label: 'İSG Gereksinimleri', icon: 'ri-shield-check-line' },
    { key: 'sozlesme', label: 'Sözleşmeler', icon: 'ri-briefcase-line' },
  ];

  // Sağ kolona eklenen "Firma Paneli" yönetim kartı (mevcut davet akışı korunur).
  const panelKarti: ReactNode = perms.panelYonet ? (
    <div className="isg-section p-4">
      <div className="flex items-center gap-2 mb-3">
        <i className="ri-user-line text-primary-500 text-sm" />
        <h4 className="text-sm font-semibold text-foreground-800">Firma Paneli</h4>
      </div>
      <div className="space-y-3">
        <p className="text-xs text-foreground-600 leading-snug">
          {firma.firmaPaneliVar
            ? 'Firma paneli aktif. Yeni bir kullanıcıya davet gönderebilirsiniz.'
            : 'Firma paneli aktif değil.'}
        </p>
        <div className="grid grid-cols-2 gap-2">
          <PanelStateOption active={!firma.firmaPaneliVar} title="Panel Yok" description="Firma paneli aktif değil." />
          <PanelStateOption active={firma.firmaPaneliVar} title="Panel Var" description="Firma paneli kullanıcısı kayıtlı." />
        </div>
        <Input label="Davet E-postası" type="email" placeholder="yetkili@ornekmetal.com" value={inviteEmail} onChange={(e) => setInviteEmail(e.target.value)} />
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          <Input label="Ad" placeholder="Ad" value={inviteAd} onChange={(e) => setInviteAd(e.target.value)} />
          <Input label="Soyad" placeholder="Soyad" value={inviteSoyad} onChange={(e) => setInviteSoyad(e.target.value)} />
        </div>
        <Button variant="primary" size="sm" fullWidth isLoading={inviting} onClick={handleInvite} leftIcon={<i className="ri-mail-send-line" />} className="whitespace-nowrap">
          {firma.firmaPaneliVar ? 'Davet Gönder' : 'Paneli Aç ve Davet Gönder'}
        </Button>
        {firma.firmaPaneliVar && (
          <div className="space-y-2 pt-1">
            {invitesLoading ? (
              <p className="text-xs text-foreground-400 text-center py-2">Yükleniyor...</p>
            ) : invites.length === 0 ? (
              <p className="text-xs text-foreground-500 text-center py-2">Henüz davet gönderilmedi.</p>
            ) : (
              invites.map((inv) => {
                // Savunmacı fallback: DB beklenmeyen bir davet durumu döndürürse
                // (union dışı), harita lookup'ı undefined olup `info.variant` ÇÖKERTİRDİ.
                const info = inviteStatusInfo[inv.status] ?? { label: 'Bilinmiyor', variant: 'warning' as const };
                const canResend = inv.status === 'pending' || inv.status === 'send_failed' || inv.status === 'expired';
                return (
                  <div key={inv.id} className="flex items-center gap-2 p-2 bg-background-100 dark:bg-background-200/60 border border-background-300/20 dark:border-background-400/20 rounded-lg">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground-800 truncate">{[inv.firstName, inv.lastName].filter(Boolean).join(' ') || inv.email}</p>
                      <p className="text-[10px] text-foreground-500 truncate">{inv.email}</p>
                    </div>
                    {canResend && (
                      <button
                        type="button"
                        onClick={() => handleResend(inv)}
                        disabled={inviting}
                        className="w-7 h-7 flex items-center justify-center rounded-md text-foreground-500 hover:bg-background-200 cursor-pointer disabled:opacity-50 flex-shrink-0"
                        title="Yeniden Gönder"
                      >
                        <i className="ri-mail-send-line" />
                      </button>
                    )}
                    <Badge variant={info.variant}>{info.label}</Badge>
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
    </div>
  ) : (
    <div className="isg-section p-4">
      <div className="flex items-center gap-2 mb-3">
        <i className="ri-user-line text-primary-500 text-sm" />
        <h4 className="text-sm font-semibold text-foreground-800">Firma Paneli</h4>
      </div>
      <div className="flex items-center gap-2">
        <Badge variant={firma.firmaPaneliVar ? 'success' : 'secondary'}>{firma.firmaPaneliVar ? 'Panel Aktif' : 'Panel Yok'}</Badge>
        <span className="text-xs text-foreground-500">Panel yönetimi yalnızca OSGB yöneticisi tarafından yapılır.</span>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane no-scrollbar space-y-4">
      {/* ── ÜST ÖZET ── */}
      <div className="p-4 isg-section">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-12 h-12 rounded-xl bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
              <i className="ri-building-2-line text-primary-600 dark:text-primary-400 text-xl" />
            </div>
            <div className="min-w-0">
              <h3 className="text-base font-semibold text-foreground-950 truncate">{firma.ad}</h3>
              <p className="text-xs text-foreground-500 mt-0.5">{formatFirmaKonum(firma) || 'Konum bilgisi yok'}</p>
              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                {firma.isgKatipId ? <Badge variant="info">İSG-KATİP'te Kayıtlı</Badge> : <Badge variant="secondary">Manuel</Badge>}
                <Badge variant={tehlikeBadgeVariant(firma.tehlikeSinifi)}>{firma.tehlikeSinifiLabel}</Badge>
                <Badge variant={firma.firmaPaneliVar ? 'info' : 'secondary'}>{firma.firmaPaneliVar ? 'Panel Var' : 'Panel Yok'}</Badge>
                <Badge variant="accent">{FIRMA_DETAY_ROLE_LABEL[role]}</Badge>
                {hizmetSonlandi && <Badge variant="danger">Hizmet Sonlandı</Badge>}
              </div>
            </div>
          </div>

          <div className="flex flex-col gap-3 lg:items-end flex-shrink-0">
            <div className="flex flex-wrap items-center gap-2 self-start lg:self-auto">
              {perms.firmaDuzenle && firma.isActive && (
                <Button variant="ghost" size="sm" leftIcon={<i className="ri-stop-circle-line" />} onClick={handleHizmetSonlandir} disabled={hizmetBusyState} className="whitespace-nowrap text-danger-600 hover:text-danger-700">
                  Hizmeti Sonlandır
                </Button>
              )}
              {perms.firmaDuzenle && !firma.isActive && (
                <Button variant="primary" size="sm" leftIcon={<i className="ri-restart-line" />} onClick={handleHizmetYenidenBaslat} isLoading={hizmetBusyState} className="whitespace-nowrap">
                  Hizmeti Yeniden Başlat
                </Button>
              )}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
              <InfoCard icon="ri-group-line" label="Çalışan Sayısı" value={String(calisanDeger)} hint="Aktif çalışan" />
              <InfoCard icon="ri-price-tag-3-line" label="NACE Kodu" value={nace?.kod ?? '—'} />
              <InfoCard icon="ri-alert-line" label="Tehlike Sınıfı" value={hazardLabel} tone="danger" />
              <InfoCard icon="ri-links-line" label="İSG-KATİP" value={firma.isgKatipId ? (firma.isgGirdiDegisti ? 'Değişiklik Var' : 'Eşleşti') : 'Eşleşmedi'} />
              <InfoCard
                icon="ri-radio-button-line"
                label="Hizmet Durumu"
                value={firma.isActive ? 'Hizmet Devam Ediyor' : 'Hizmet Sonlandı'}
                hint={
                  firma.isActive
                    ? ([formatFirmaDate(firma.hizmetBaslangicTarihi), formatFirmaDate(firma.hizmetBitisTarihi)].filter((x) => x !== '—').join(' → ') || undefined)
                    : `Sonlandırma: ${formatFirmaDate(firma.hizmetSonlandirmaTarihi)}`
                }
              />
              <InfoCard icon="ri-calendar-check-line" label="Son Güncelleme" value={sonHesaplama ? formatFirmaDateTime(sonHesaplama) : '—'} />
            </div>
          </div>
        </div>

        {hizmetSonlandi && (
          <Alert variant="warning" className="mt-3" icon="ri-lock-2-line">
            Bu firmanın hizmeti sonlandırıldı. İşlem yapabilmek için firmayı <span className="font-semibold">Hizmeti Yeniden Başlat</span> ile yeniden aktif edin.
          </Alert>
        )}
      </div>

      <TabBar items={sekmeler} active={sekme} onChange={(k) => setSekme(k as Sekme)} size="sm" />

      {/* ── GENEL BAKIŞ ── */}
      {sekme === 'genel' && (
        <FirmaDetayGenelBakis
          firma={firma}
          nace={nace}
          osgbUnvan={osgbUnvan}
          roleReqs={roleReqs}
          sonHesaplama={sonHesaplama}
          onOpenSozlesmeler={() => setSekme('sozlesme')}
          onChanged={() => { load(); onChanged?.(); }}
          rightExtra={panelKarti}
          disabled={hizmetSonlandi}
          canEdit={perms.firmaDuzenle}
          autoEditSection={initialEdit ? 'firma' : undefined}
        />
      )}

      {/* ── İSG-KATİP ── */}
      {sekme === 'katip' && (
        <FirmaDetayKatip firma={firma} nace={nace} />
      )}

      {/* ── İSG GEREKSİNİMLERİ ── */}
      {sekme === 'isg' && (
        <IsgGereksinimleriTab
          row={firma}
          scope={perms.isgScope}
          messagingPath={perms.messagingPath}
          onRecalculated={() => load()}
          onClose={onClose}
        />
      )}

      {/* ── SÖZLEŞMELER ── */}
      {sekme === 'sozlesme' && (
        <FirmaDetaySozlesmeler
          firma={firma}
          nace={nace}
          osgbUnvan={osgbUnvan}
          roleReqs={roleReqs}
          sonHesaplama={sonHesaplama}
          canManage={!hizmetSonlandi && (role === 'osgb' || role === 'uzman' || role === 'hekim')}
          onChanged={load}
        />
      )}
      </div>
    </div>
  );
}

function HizmetSonlandirModal({ onConfirm, onCancel, busy }: { onConfirm: (neden: string) => void; onCancel: () => void; busy: boolean }) {
  const [neden, setNeden] = useState('');
  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-full bg-danger-50 dark:bg-danger-500/15 flex items-center justify-center flex-shrink-0">
          <i className="ri-error-warning-line text-danger-600 text-lg" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-foreground-900">Firma hizmetini sonlandırmak istediğinize emin misiniz?</p>
          <p className="text-xs text-foreground-500 mt-1">
            Firma "Hizmeti Sonlananlar" sekmesine taşınır. Sözleşme kayıtları SİLİNMEZ; geçmiş korunur.
          </p>
        </div>
      </div>
      <Textarea
        label="Sonlandırma nedeni"
        value={neden}
        onChange={(e) => setNeden(e.target.value)}
        maxLength={500}
        placeholder="Sonlandırma nedenini kısaca yazabilirsiniz (isteğe bağlı)"
      />
      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onCancel} disabled={busy} className="whitespace-nowrap">
          Vazgeç
        </Button>
        <Button variant="danger" size="sm" onClick={() => onConfirm(neden.trim())} isLoading={busy} leftIcon={<i className="ri-stop-circle-line" />} className="whitespace-nowrap">
          Hizmeti Sonlandır
        </Button>
      </div>
    </div>
  );
}

function PanelStateOption({ active, title, description }: { active: boolean; title: string; description: string }) {
  return (
    <div className={`flex items-start gap-2 rounded-lg border p-2.5 ${active ? 'border-primary-500 bg-primary-50/70 dark:bg-primary-500/10' : 'border-background-300/50 dark:border-background-400/35'}`}>
      <span className={`mt-0.5 w-[16px] h-[16px] min-w-[16px] rounded-full border-2 flex items-center justify-center ${active ? 'border-primary-500' : 'border-background-400'}`}>
        {active && <span className="w-2 h-2 rounded-full bg-primary-500" />}
      </span>
      <span className="min-w-0">
        <span className="block text-sm font-semibold text-foreground-800">{title}</span>
        <span className="block text-xs text-foreground-500 mt-0.5">{description}</span>
      </span>
    </div>
  );
}

function InfoCard({ icon, label, value, hint, tone }: { icon: string; label: string; value: string; hint?: string; tone?: 'danger' }) {
  return (
    <div className="min-w-[132px] rounded-lg border border-background-300/30 dark:border-background-400/25 bg-background-100/60 dark:bg-background-300/20 px-3 py-2">
      <div className="flex items-center gap-1.5">
        <i className={`${icon} text-xs ${tone === 'danger' ? 'text-danger-500' : 'text-foreground-400'}`} />
        <span className="text-[10px] font-semibold text-foreground-500 uppercase tracking-wide whitespace-nowrap">{label}</span>
      </div>
      <p className={`text-sm font-bold mt-1 leading-tight ${tone === 'danger' ? 'text-danger-600' : 'text-foreground-950'}`}>{value}</p>
      {hint && <p className="text-[10px] text-foreground-400 mt-0.5">{hint}</p>}
    </div>
  );
}