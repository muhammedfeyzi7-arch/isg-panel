import { useState, useEffect, useCallback, useMemo, useRef, type RefObject } from 'react';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import EmptyState from '@/components/ui/EmptyState';
import ContextMenu from '@/components/ui/ContextMenu';
import type { ContextMenuItem } from '@/components/ui/ContextMenu';
import { useToastActions } from '@/hooks/useToast';
import { useModalActions } from '@/hooks/useModal';
import type { FirmaData, NaceKod } from '@/lib/firmaService';
import type { RoleRequirementMap } from '@/lib/atamaRequirement';
import { formatFirmaDate, formatFirmaDateTime } from '@/pages/osgb/firmalar/components/firmaUi';
import YeniSozlesmeForm from '@/components/feature/firma-detay/YeniSozlesmeForm';
import {
  type SozlesmeData,
  fetchFirmaSozlesmeleri,
  getSozlesmeUrl,
  sonlandirFirmaSozlesme,
  friendlySozlesmeError,
  formatSozlesmeFileSize,
  fetchSozlesmeBelgeleri,
  uploadSozlesmeBelge,
  getSozlesmeBelgeUrl,
  type SozlesmeBelge,
} from '@/lib/firmaSozlesmeService';
import { requestKatipWorksites } from '@/lib/isgKatip/bridge';
import { filterHizmetRowsByWorksite, maskKatipExternalId } from '@/lib/isgKatip/pilot';
import { normalizeKatipContractActivity, type KatipContractActivityStatus } from '@/lib/isgKatip/contractActivity';
import { resolveKatipRole, resolveKatipRoleByCertId } from '@/lib/isgKatip/roleMapping';
import { normalizeKatipDate } from '@/lib/isgKatip/mapper';

type BadgeVariantLite = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'secondary' | 'accent';

const KATIP_DURUM: Record<KatipContractActivityStatus, { label: string; variant: BadgeVariantLite; aktif: boolean }> = {
  ACTIVE: { label: 'Aktif', variant: 'success', aktif: true },
  TERMINATED: { label: 'Sonlandırıldı', variant: 'danger', aktif: false },
  CANCELLED: { label: 'İptal Edildi', variant: 'danger', aktif: false },
  EXPIRED: { label: 'Süresi Sona Erdi', variant: 'warning', aktif: false },
  PENDING: { label: 'Onay Bekliyor', variant: 'info', aktif: false },
  UNKNOWN: { label: 'Belirsiz', variant: 'default', aktif: false },
};

function pick(row: unknown, key: string): unknown {
  if (typeof row !== 'object' || row === null) return undefined;
  return (row as Record<string, unknown>)[key];
}
function str(v: unknown): string {
  if (v == null) return '';
  return String(v).replace(/\s+/g, ' ').trim();
}
function daysUntil(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const t = new Date(`${dateStr}T00:00:00`).getTime();
  if (Number.isNaN(t)) return null;
  return Math.ceil((t - Date.now()) / 86400000);
}

/** İSG-KATİP satırı için görevlendirilen kişi + rol metni. */
function katipPersonelLabel(row: Record<string, unknown>): string {
  const ad = str(pick(row, 'gorevlendirilenKisiAdSoyad')) || '—';
  return ad;
}

/** İSG-KATİP satırı için sözleşme türü (rol bazlı). */
function katipRoleLabel(row: Record<string, unknown>): string {
  const idRes = resolveKatipRoleByCertId(pick(row, 'gorevlendirilenKisiSertifikaTipiId'));
  const res = idRes && idRes.role ? idRes : resolveKatipRole(pick(row, 'gorevlendirilenKisiSertifikaTipi'), pick(row, 'sozlesmeTipi'));
  const sinif = (res as { uzmanlikSinifi?: string | null }).uzmanlikSinifi ?? null;
  const base =
    res.role === 'isg_uzmani' ? 'İş Güvenliği Uzmanı'
      : res.role === 'isyeri_hekimi' ? 'İşyeri Hekimi'
        : res.role === 'dsp' ? 'Diğer Sağlık Personeli'
          : 'İSG-KATİP Sözleşmesi';
  return sinif ? `${base} (${sinif})` : base;
}

/** OSGB ↔ Firma sözleşmesi durum görünümü (gerçek kayıttan). */
function osgbDurumView(s: SozlesmeData): { label: string; variant: BadgeVariantLite } {
  const aktif = s.durum === 'aktif' && !s.sonlandirmaTarihi;
  const kalan = daysUntil(s.bitisTarihi);
  if (aktif && kalan != null && kalan < 0) return { label: 'Süresi Sona Erdi', variant: 'warning' };
  if (aktif) return { label: 'Aktif', variant: 'success' };
  return { label: s.durumLabel || 'Sona Erdi', variant: 'danger' };
}

interface FirmaDetaySozlesmelerProps {
  firma: FirmaData;
  nace: NaceKod | null;
  osgbUnvan: string | null;
  roleReqs: RoleRequirementMap;
  sonHesaplama: string | null;
  canManage?: boolean;
  onChanged?: () => void;
}

/** Sözleşme sonlandırma onay penceresi. */
function SonlandirModal({ onConfirm, onCancel, busy }: { onConfirm: (neden: string) => void; onCancel: () => void; busy: boolean }) {
  const [neden, setNeden] = useState('');
  return (
    <div className="space-y-4">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-full bg-danger-50 dark:bg-danger-500/15 flex items-center justify-center flex-shrink-0">
          <i className="ri-error-warning-line text-danger-600 text-lg" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-foreground-900">Bu sözleşmeyi sonlandırmak istediğinize emin misiniz?</p>
          <p className="text-xs text-foreground-500 mt-1">
            Sonlandırma sonrası sözleşme "Sonlandırıldı" durumuna geçer. Belge geçmişi ve kayıt SİLİNMEZ.
          </p>
        </div>
      </div>
      <textarea
        className="w-full min-h-[80px] rounded-md bg-background-100 dark:bg-background-300/25 border border-background-300/40 dark:border-background-400/30 px-3 py-2 text-sm text-foreground-800 focus:outline-none focus:ring-2 focus:ring-primary-400"
        placeholder="Sonlandırma nedenini kısaca yazabilirsiniz (isteğe bağlı)"
        maxLength={500}
        value={neden}
        onChange={(e) => setNeden(e.target.value)}
      />
      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onCancel} disabled={busy} className="whitespace-nowrap">Vazgeç</Button>
        <Button variant="danger" size="sm" onClick={() => onConfirm(neden.trim())} isLoading={busy} leftIcon={<i className="ri-close-circle-line" />} className="whitespace-nowrap">Sözleşmeyi Sonlandır</Button>
      </div>
    </div>
  );
}

/**
 * Firma Detay → Sözleşmeler sekmesi (referans tasarım).
 *
 * İki KAYNAK kesin biçimde ayrı iki kartta gösterilir ve birbirine karıştırılmaz:
 *   A) OSGB ↔ Firma Sözleşmeleri → OSGB tarafından oluşturulur/düzenlenir, belge yüklenebilir.
 *   B) İSG-KATİP Sözleşmeleri     → KATİP'ten otomatik senkron, SALT-OKUNUR.
 *
 * "İSGDenetim sözleşmesi" gibi uydurma bir kavram YOKTUR. Uygulama içi yazma yalnızca
 * OSGB ↔ Firma sözleşmesi kartından yapılır.
 */
export default function FirmaDetaySozlesmeler({
  firma,
  osgbUnvan,
  canManage = false,
  onChanged,
}: FirmaDetaySozlesmelerProps) {
  const { addToast } = useToastActions();
  const { openModal, closeModal } = useModalActions();

  const [db, setDb] = useState<SozlesmeData[]>([]);
  const [katipRows, setKatipRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [katipSync, setKatipSync] = useState<string | null>(null);
  const [katipSyncing, setKatipSyncing] = useState(false);
  const [katipError, setKatipError] = useState<string | null>(null);

  const [editing, setEditing] = useState<SozlesmeData | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const formRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const load = useCallback(() => {
    setLoading(true);
    setLoadError(null);
    fetchFirmaSozlesmeleri(firma.id)
      .then((rows) => setDb(rows))
      .catch((e) => setLoadError(friendlySozlesmeError(e)))
      .finally(() => setLoading(false));
  }, [firma.id]);

  useEffect(() => {
    load();
  }, [load]);

  const loadKatip = useCallback(() => {
    if (!firma.isgKatipId) {
      setKatipRows([]);
      return;
    }
    setKatipSyncing(true);
    setKatipError(null);
    requestKatipWorksites(6000)
      .then((res) => {
        if (!res.ok || !res.captured) {
          setKatipError(res.error || 'İSG-KATİP verisi alınamadı.');
          setKatipRows([]);
          return;
        }
        setKatipRows(filterHizmetRowsByWorksite((res.hizmetRows ?? []) as Record<string, unknown>[], firma.isgKatipId as string));
        setKatipSync(new Date().toISOString());
      })
      .catch(() => {
        setKatipError('İSG-KATİP verisi alınamadı.');
        setKatipRows([]);
      })
      .finally(() => setKatipSyncing(false));
  }, [firma.isgKatipId]);

  useEffect(() => {
    loadKatip();
  }, [loadKatip]);

  const selectedSozlesme = useMemo(() => db.find((s) => s.id === selectedId) ?? null, [db, selectedId]);

  const scrollToForm = useCallback(() => {
    formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, []);

  const handleView = useCallback(
    async (s: SozlesmeData) => {
      if (!s.storagePath) {
        addToast({ title: 'Dosya yok', message: 'Bu sözleşme için yüklenmiş bir dosya bulunmuyor.', type: 'warning' });
        return;
      }
      try {
        const url = await getSozlesmeUrl(s.id);
        window.open(url, '_blank', 'noopener,noreferrer');
      } catch (e) {
        addToast({ title: 'Dosya açılamadı', message: friendlySozlesmeError(e), type: 'error' });
      }
    },
    [addToast],
  );

  const handleSonlandir = useCallback(
    (s: SozlesmeData) => {
      const id = openModal({
        title: 'Sözleşmeyi Sonlandır',
        description: `${s.turLabel}${s.sozlesmeNo ? ` (${s.sozlesmeNo})` : ''}`,
        width: 480,
        minWidth: 380,
        minHeight: 300,
        showFooter: false,
        closable: true,
        content: (
          <SonlandirModal
            busy={busy}
            onCancel={() => closeModal(id)}
            onConfirm={(neden) => {
              setBusy(true);
              sonlandirFirmaSozlesme(s.id, neden || null)
                .then(() => {
                  addToast({ title: 'Sözleşme sonlandırıldı', message: 'Sözleşme "Sonlandırıldı" durumuna alındı.', type: 'success' });
                  closeModal(id);
                  load();
                  onChanged?.();
                })
                .catch((e) => addToast({ title: 'Sonlandırılamadı', message: friendlySozlesmeError(e), type: 'error' }))
                .finally(() => setBusy(false));
            }}
          />
        ),
      });
    },
    [openModal, closeModal, busy, addToast, load, onChanged],
  );

  const handleCreated = useCallback(() => {
    setEditing(null);
    setFormOpen(false);
    load();
    onChanged?.();
  }, [load, onChanged]);

  // OSGB ↔ Firma sözleşmeleri (A kartı)
  const osgbColumns: TableColumn<SozlesmeData>[] = [
    { key: 'no', header: 'Sözleşme No', render: (s) => <span className="text-sm font-medium text-foreground-800">{s.sozlesmeNo || '—'}</span> },
    { key: 'tur', header: 'Sözleşme Türü', render: (s) => <span className="text-sm text-foreground-700">{s.turLabel}</span> },
    { key: 'bas', header: 'Başlangıç Tarihi', render: (s) => <span className="text-sm text-foreground-600">{s.baslangicTarihi ? formatFirmaDate(s.baslangicTarihi) : '—'}</span> },
    { key: 'bit', header: 'Bitiş Tarihi', render: (s) => <span className="text-sm text-foreground-600">{s.bitisTarihi ? formatFirmaDate(s.bitisTarihi) : '—'}</span> },
    { key: 'durum', header: 'Durum', render: (s) => { const d = osgbDurumView(s); return <Badge variant={d.variant}>{d.label}</Badge>; } },
    { key: 'aciklama', header: 'Açıklama', render: (s) => <span className="text-sm text-foreground-600 line-clamp-2">{s.aciklama || '—'}</span> },
    {
      key: 'islem',
      header: 'İşlem',
      render: (s) => (
        <button type="button" onClick={() => setSelectedId(s.id)} className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-primary-600 hover:text-primary-700 hover:bg-primary-50 dark:hover:bg-primary-500/10 rounded-md transition-colors cursor-pointer whitespace-nowrap">
          <i className="ri-file-text-line" /> Detay
        </button>
      ),
    },
  ];

  const osgbRowActions = (s: SozlesmeData) => {
    if (!canManage) return <span className="text-sm text-foreground-400">—</span>;
    const aktif = s.durum === 'aktif' && !s.sonlandirmaTarihi;
    const items: ContextMenuItem[] = [
      { label: 'Düzenle', icon: 'ri-edit-line', onClick: () => { setEditing(s); setFormOpen(true); requestAnimationFrame(scrollToForm); } },
      { label: 'Belge Yükle', icon: 'ri-upload-2-line', onClick: () => { setSelectedId(s.id); requestAnimationFrame(() => fileInputRef.current?.click()); } },
    ];
    if (aktif) items.push({ label: 'Sonlandır', icon: 'ri-close-circle-line', variant: 'danger', onClick: () => handleSonlandir(s) });
    return <ContextMenu items={items} />;
  };

  // İSG-KATİP sözleşmeleri (B kartı)
  const katipContracts = useMemo(() => {
    const map = new Map<string, Record<string, unknown>>();
    for (const r of katipRows) {
      const id = str(pick(r, 'sozlesmeId'));
      if (!id) continue;
      if (!map.has(id)) map.set(id, r);
    }
    return [...map.values()];
  }, [katipRows]);

  const katipColumns: TableColumn<Record<string, unknown>>[] = [
    { key: 'no', header: 'Sözleşme No', render: (r) => <span className="text-sm font-medium text-foreground-800">{maskKatipExternalId(pick(r, 'sozlesmeId')) ?? '—'}</span> },
    { key: 'tur', header: 'Sözleşme Türü', render: (r) => <span className="text-sm text-foreground-700">{katipRoleLabel(r)}</span> },
    { key: 'bas', header: 'Başlangıç Tarihi', render: (r) => <span className="text-sm text-foreground-600">{formatFirmaDate(normalizeKatipDate(pick(r, 'sozlesmeBaslangicTarihi')))}</span> },
    { key: 'bit', header: 'Bitiş Tarihi', render: (r) => <span className="text-sm text-foreground-600">{formatFirmaDate(normalizeKatipDate(pick(r, 'sozlesmeBitisTarihi')))}</span> },
    { key: 'durum', header: 'Durum', render: (r) => { const d = KATIP_DURUM[normalizeKatipContractActivity(r).status]; return <Badge variant={d.variant}>{d.label}</Badge>; } },
    { key: 'personel', header: 'İlgili Personel', render: (r) => <span className="text-sm text-foreground-700">{katipPersonelLabel(r)}</span> },
    {
      key: 'islem',
      header: 'İşlem',
      render: () => (
        <span className="inline-flex items-center gap-1 text-[11px] text-foreground-400 whitespace-nowrap" title="İSG-KATİP sözleşmeleri salt-okunurdur.">
          <i className="ri-lock-line" /> Salt okunur
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-3 min-w-0">
      {/* ── A) OSGB ↔ Firma Sözleşmeleri ── */}
      <div className="isg-section p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between mb-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
              <i className="ri-file-shield-2-line text-base" />
            </div>
            <div className="min-w-0">
              <h4 className="text-sm font-semibold text-foreground-900">OSGB ↔ Firma Sözleşmeleri</h4>
              <p className="text-xs text-foreground-500 mt-0.5 leading-snug">OSGB'niz ile firma arasında yapılan hizmet sözleşmeleri.</p>
            </div>
          </div>
          {canManage && (
            <Button
              variant="primary"
              size="sm"
              leftIcon={<i className="ri-add-line" />}
              onClick={() => { setEditing(null); setFormOpen(true); requestAnimationFrame(scrollToForm); }}
              className="whitespace-nowrap flex-shrink-0"
            >
              Yeni OSGB Sözleşmesi Ekle
            </Button>
          )}
        </div>
        {loading ? (
          <div className="flex justify-center py-12"><i className="ri-loader-4-line animate-spin text-2xl text-primary-500" /></div>
        ) : loadError ? (
          <div className="py-10 text-center">
            <i className="ri-error-warning-line text-2xl text-danger-500 mb-2 block" />
            <p className="text-sm text-foreground-600">{loadError}</p>
            <Button variant="ghost" size="sm" className="mt-3" onClick={load}>Tekrar Dene</Button>
          </div>
        ) : db.length === 0 ? (
          <EmptyState
            icon="ri-file-shield-2-line"
            title="Henüz sözleşme bulunmuyor."
            description="Yeni OSGB Sözleşmesi Ekle ile bir hizmet sözleşmesi oluşturabilirsiniz."
          />
        ) : (
          <div className="overflow-x-auto">
            <Table data={db} columns={osgbColumns} keyExtractor={(s) => s.id} rowActions={osgbRowActions} density="compact" />
          </div>
        )}
      </div>

      {/* ── B) İSG-KATİP Sözleşmeleri ── */}
      <div className="isg-section p-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between mb-3">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
              <i className="ri-links-line text-base" />
            </div>
            <div className="min-w-0">
              <h4 className="text-sm font-semibold text-foreground-900">İSG-KATİP Sözleşmeleri</h4>
              <p className="text-xs text-foreground-500 mt-0.5 leading-snug">İSG-KATİP sisteminden çekilen sözleşme bilgileri.</p>
            </div>
          </div>
          {firma.isgKatipId && (
            <div className="flex items-center gap-3 flex-shrink-0">
              <div className="text-right">
                <p className="text-[10px] text-foreground-500 leading-none">Son Senkronizasyon</p>
                <p className="text-xs font-semibold text-foreground-800 mt-1 whitespace-nowrap">{katipSync ? formatFirmaDateTime(katipSync) : '—'}</p>
              </div>
              <Button variant="primary" size="sm" leftIcon={<i className={`ri-refresh-line ${katipSyncing ? 'animate-spin' : ''}`} />} isLoading={katipSyncing} onClick={loadKatip} className="whitespace-nowrap">
                Senkronize Et
              </Button>
            </div>
          )}
        </div>
        {!firma.isgKatipId ? (
          <div className="flex items-start gap-2 rounded-lg bg-background-100 dark:bg-background-300/20 px-3 py-2.5">
            <i className="ri-links-line text-foreground-400 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-foreground-500">Bu firma İSG-KATİP ile eşleşmemiş. KATİP sözleşmeleri yalnızca eşleşmiş firmalar için görüntülenir.</p>
          </div>
        ) : katipError ? (
          <div className="flex items-start gap-2 rounded-lg bg-background-100 dark:bg-background-300/20 px-3 py-2.5">
            <i className="ri-plug-line text-warning-600 mt-0.5 flex-shrink-0" />
            <p className="text-xs text-foreground-500">{katipError} KATİP verileri, tarayıcı eklentisinin yakaladığı gerçek verilerden gelir.</p>
          </div>
        ) : katipContracts.length === 0 ? (
          <p className="text-xs text-foreground-500 py-6 text-center">Bu işyeri için KATİP sözleşme kaydı bulunamadı.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table data={katipContracts} columns={katipColumns} keyExtractor={(r) => str(pick(r, 'sozlesmeId'))} density="compact" />
          </div>
        )}
      </div>

      {/* Seçili OSGB sözleşmesinin belge geçmişi */}
      {selectedSozlesme && (
        <BelgeGecmisi
          key={selectedSozlesme.id}
          sozlesme={selectedSozlesme}
          canManage={canManage}
          fileInputRef={fileInputRef}
          onChanged={() => { load(); onChanged?.(); }}
        />
      )}

      {/* Satır içi yeni/düzenle formu */}
      {canManage && (
        <div ref={formRef}>
          {formOpen || editing ? (
            <YeniSozlesmeForm
              key={editing?.id ?? 'new'}
              firmaId={firma.id}
              varsayilanHizmetVeren={osgbUnvan}
              duzenlenen={editing}
              onCreated={handleCreated}
              onCancel={() => { setEditing(null); setFormOpen(false); }}
            />
          ) : null}
        </div>
      )}
    </div>
  );
}

/** Seçili OSGB sözleşmesinin belge revizyon geçmişi. */
function BelgeGecmisi({
  sozlesme,
  canManage,
  fileInputRef,
  onChanged,
}: {
  sozlesme: SozlesmeData;
  canManage: boolean;
  fileInputRef: RefObject<HTMLInputElement | null>;
  onChanged: () => void;
}) {
  const { addToast } = useToastActions();
  const [belgeler, setBelgeler] = useState<SozlesmeBelge[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);

  const sozlesmeId = sozlesme.id;

  const loadBelgeler = useCallback(() => {
    setLoading(true);
    fetchSozlesmeBelgeleri(sozlesmeId)
      .then(setBelgeler)
      .catch(() => setBelgeler([]))
      .finally(() => setLoading(false));
  }, [sozlesmeId]);

  useEffect(() => {
    loadBelgeler();
  }, [loadBelgeler]);

  const handleBelgeGoruntule = useCallback(
    async (belge: SozlesmeBelge | null) => {
      try {
        const url = belge ? await getSozlesmeBelgeUrl(belge.id) : await getSozlesmeUrl(sozlesmeId);
        window.open(url, '_blank', 'noopener,noreferrer');
      } catch (e) {
        addToast({ title: 'Belge açılamadı', message: friendlySozlesmeError(e), type: 'error' });
      }
    },
    [sozlesmeId, addToast],
  );

  const handleUpload = useCallback(
    async (file: File) => {
      if (uploading) return;
      setUploading(true);
      try {
        const res = await uploadSozlesmeBelge(sozlesmeId, file);
        addToast({ title: 'Belge yüklendi', message: `Yeni belge revizyonu (rev ${res.revisionNo}) eklendi. Eski belge korundu.`, type: 'success' });
        loadBelgeler();
        onChanged();
      } catch (e) {
        addToast({ title: 'Belge yüklenemedi', message: friendlySozlesmeError(e), type: 'error' });
      } finally {
        setUploading(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    },
    [sozlesmeId, uploading, addToast, loadBelgeler, onChanged, fileInputRef],
  );

  const current = belgeler.find((b) => b.isCurrent) ?? null;
  const guncelBelgeVar = current != null || !!sozlesme.storagePath;

  return (
    <div className="isg-section p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <i className="ri-history-line text-primary-500 text-sm" />
          <h4 className="text-sm font-semibold text-foreground-800">Sözleşme Belgeleri ve Geçmişi</h4>
          <span className="text-xs text-foreground-500 truncate">— {sozlesme.sozlesmeNo || sozlesme.turLabel}</span>
        </div>
        {canManage && (
          <Button variant="primary" size="sm" leftIcon={<i className="ri-upload-2-line" />} isLoading={uploading} onClick={() => fileInputRef.current?.click()} className="whitespace-nowrap flex-shrink-0">
            Yeni Belge Yükle
          </Button>
        )}
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept=".pdf,.doc,.docx,.xls,.xlsx,image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void handleUpload(f);
        }}
      />

      {loading ? (
        <div className="flex justify-center py-6"><i className="ri-loader-4-line animate-spin text-lg text-primary-500" /></div>
      ) : !guncelBelgeVar ? (
        <p className="text-xs text-foreground-500">Bu sözleşme için yüklenmiş bir belge bulunmuyor.</p>
      ) : belgeler.length === 0 ? (
        <div className="flex items-center gap-3 rounded-lg border border-background-300/40 dark:border-background-400/30 p-3">
          <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
            <i className="ri-file-text-line" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <p className="text-sm font-medium text-foreground-800 truncate">{sozlesme.originalFileName || 'Sözleşme belgesi'}</p>
              <Badge variant="success">Güncel Belge</Badge>
            </div>
            <p className="text-[11px] text-foreground-500 mt-0.5">
              {sozlesme.fileSize != null ? `Yüklendi · ${formatSozlesmeFileSize(sozlesme.fileSize)}` : 'Yüklendi'}
            </p>
          </div>
          <Button variant="ghost" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={() => void handleBelgeGoruntule(null)} className="whitespace-nowrap flex-shrink-0">Görüntüle</Button>
        </div>
      ) : (
        <div className="space-y-2">
          {current && (
            <div className="flex items-center gap-3 rounded-lg border border-primary-200/60 dark:border-primary-500/30 bg-primary-50/40 dark:bg-primary-500/5 p-3">
              <div className="w-9 h-9 rounded-lg bg-primary-500 text-inverse flex items-center justify-center flex-shrink-0">
                <i className="ri-file-text-line" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-sm font-medium text-foreground-800 truncate">{current.originalFileName || 'Sözleşme belgesi'}</p>
                  <Badge variant="success">Güncel Belge</Badge>
                </div>
                <p className="text-[11px] text-foreground-500 mt-0.5">
                  Rev {current.revisionNo} · {formatFirmaDateTime(current.createdAt)} · {formatSozlesmeFileSize(current.fileSize)}
                  {current.uploadedByName ? ` · ${current.uploadedByName}` : ''}
                </p>
              </div>
              <Button variant="ghost" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={() => void handleBelgeGoruntule(current)} className="whitespace-nowrap">Görüntüle</Button>
            </div>
          )}
          {belgeler.filter((b) => !b.isCurrent).length > 0 && (
            <div className="rounded-lg border border-background-300/40 dark:border-background-400/30 divide-y divide-background-300/20 dark:divide-background-400/20">
              {belgeler
                .filter((b) => !b.isCurrent)
                .map((b) => (
                  <div key={b.id} className="flex items-center gap-3 px-3 py-2">
                    <i className="ri-file-text-line text-foreground-400 flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-foreground-700 truncate">{b.originalFileName || 'Belge'}</p>
                      <p className="text-[11px] text-foreground-500">
                        Rev {b.revisionNo} · {formatFirmaDateTime(b.createdAt)} · {formatSozlesmeFileSize(b.fileSize)}
                        {b.uploadedByName ? ` · ${b.uploadedByName}` : ''}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={() => void handleBelgeGoruntule(b)} className="whitespace-nowrap flex-shrink-0">Görüntüle</Button>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}