import { MapContainer, TileLayer, Circle, CircleMarker, ZoomControl } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

interface FirmaHaritaProps {
  /** Enlem (firma koordinatı). Yoksa Türkiye/varsayılan merkez kullanılır. */
  lat?: number | null;
  /** Boylam (firma koordinatı). */
  lng?: number | null;
  /** Geofence yarıçapı (metre) — varsa daire çizilir. */
  geofenceRadiusMeters?: number | null;
  /** Firma konumu işaretlensin mi (konum yoksa marker çizilmez). */
  showMarker?: boolean;
  /** Başlangıç zoom'u (konum yoksa daha geniş görünüm). */
  zoom?: number;
  /** Harita yüksekliği (px). */
  height?: number;
  /** Koordinat yoksa gösterilecek bilgi notu. */
  emptyHint?: string;
}

/**
 * Firma konum haritası — YALNIZCA bu bileşen Leaflet'i (react-leaflet + leaflet.css)
 * import eder. FirmaDetayModal bu bileşeni `lazy` ile çağırır; böylece Leaflet
 * (~150KB) firma detay modalı AÇILANA kadar indirilmez.
 *
 * Konum (lat/lng) YOKSA bile harita (varsayılan Türkiye görünümü veya il/ilçe
 * merkezi) GÖSTERİLİR; yalnızca marker çizilmez ve bilgi notu eklenir.
 */
export default function FirmaHarita({
  lat,
  lng,
  geofenceRadiusMeters,
  showMarker = true,
  zoom,
  height = 280,
  emptyHint,
}: FirmaHaritaProps) {
  const hasLoc = lat != null && lng != null;
  const center: [number, number] = hasLoc ? [lat as number, lng as number] : [39.0, 35.0];
  const resolvedZoom = zoom ?? (hasLoc ? 14 : 6);

  return (
    <MapContainer
      center={center}
      zoom={resolvedZoom}
      scrollWheelZoom={false}
      zoomControl={false}
      className="w-full z-0"
      style={{ height }}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <ZoomControl position="topright" />
      {hasLoc && showMarker && (
        <CircleMarker center={center} radius={8} pathOptions={{ color: '#c2410c', fillColor: '#ea580c', fillOpacity: 1, weight: 2 }} />
      )}
      {hasLoc && geofenceRadiusMeters != null && geofenceRadiusMeters > 0 && (
        <Circle center={center} radius={geofenceRadiusMeters} pathOptions={{ color: '#ea580c', fillColor: '#f59e0b', fillOpacity: 0.14, weight: 1.5 }} />
      )}
      {!hasLoc && emptyHint && (
        <div className="leaflet-control leaflet-bar absolute left-2 bottom-2 z-[500] max-w-[80%] rounded-md bg-background-100/95 px-2.5 py-1.5 text-[11px] text-foreground-700 border border-background-300/60 pointer-events-none">
          <i className="ri-information-line mr-1" />
          {emptyHint}
        </div>
      )}
    </MapContainer>
  );
}