import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToastActions } from '@/hooks/useToast';
import Button from '@/components/ui/Button';
import Loading from '@/components/ui/Loading';
import {
  createDirectConversation,
  fetchConversationDetail,
  sendMessage,
  markConversationRead,
  sortMessages,
  friendlyMesajlasmaError,
  type MesajlasmaMessage,
} from '@/lib/mesajlasmaService';

interface MesajlasmaModalProps {
  targetUserId: string;
  /** Hedef kişinin ad soyadı (başlık). */
  name: string;
  /** Hedef kişinin rol etiketi (örn. "İşyeri Hekimi"). */
  roleLabel: string;
  onClose: () => void;
}

/**
 * Firma Detay Modalı içinden "Mesaj At" ile açılan mesajlaşma modalı.
 *
 * ÖNEMLİ: Yeni bir mesajlaşma altyapısı KURMAZ. Mevcut `conversations` / `messages`
 * verisini ve mevcut `mesajlasma` edge function'ını kullanır. Firma Detay Modalı
 * KAPANMAZ; bu modal onun ÜSTÜNE yığın olarak açılır ve kapanınca Firma Detay görünür kalır.
 */
export default function MesajlasmaModal({ targetUserId, name, roleLabel, onClose }: MesajlasmaModalProps) {
  const { profile } = useAuth();
  const { addToast } = useToastActions();
  const [convId, setConvId] = useState<string | null>(null);
  const [messages, setMessages] = useState<MesajlasmaMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [text, setText] = useState('');
  const [sending, setSending] = useState(false);
  const [retryNonce, setRetryNonce] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  const load = useCallback(async (id: string) => {
    const detail = await fetchConversationDetail(id, { limit: 50 });
    setMessages(sortMessages(detail.messages));
  }, []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    createDirectConversation(targetUserId)
      .then(async (id) => {
        if (cancelled) return;
        setConvId(id);
        await load(id);
        await markConversationRead(id);
      })
      .catch((e) => { if (!cancelled) setError(friendlyMesajlasmaError(e)); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [targetUserId, load, retryNonce]);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages.length]);

  const handleSend = useCallback(async () => {
    const body = text.trim();
    if (!body || !convId || sending) return;
    setSending(true);
    try {
      await sendMessage({ conversationId: convId, messageType: 'text', body });
      setText('');
      await load(convId);
    } catch (e) {
      addToast({ type: 'error', title: 'Mesaj gönderilemedi', message: friendlyMesajlasmaError(e) });
    } finally {
      setSending(false);
    }
  }, [text, convId, sending, load, addToast]);

  const initial = (name || '?').trim().charAt(0).toUpperCase();

  return (
    <div className="flex flex-col h-[520px] max-h-[70vh] -m-1">
      {/* Başlık */}
      <div className="flex items-center gap-3 px-1 pb-3 border-b isg-divider flex-shrink-0">
        <div className="w-10 h-10 rounded-full bg-primary-50 dark:bg-primary-500/10 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0 font-semibold">
          {initial}
        </div>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-foreground-900 truncate">{name}</p>
          <p className="text-xs text-foreground-500">{roleLabel}</p>
        </div>
      </div>

      {/* Mesajlar */}
      <div ref={scrollRef} className="flex-1 min-h-0 overflow-y-auto py-4 space-y-3">
        {loading ? (
          <div className="flex justify-center py-8"><Loading size="sm" text="Konuşma yükleniyor..." /></div>
        ) : error ? (
          <div className="py-6 text-center">
            <i className="ri-error-warning-line text-2xl text-warning-500 mb-2 block" />
            <p className="text-sm text-foreground-600">{error}</p>
            <Button variant="outline" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={() => setRetryNonce((n) => n + 1)} className="mt-3 whitespace-nowrap">
              Tekrar Dene
            </Button>
          </div>
        ) : messages.length === 0 ? (
          <div className="py-8 text-center">
            <i className="ri-chat-3-line text-2xl text-foreground-400 mb-2 block" />
            <p className="text-sm text-foreground-600 font-medium">Henüz mesaj yok</p>
            <p className="text-xs text-foreground-500 mt-0.5">İlk mesajı siz gönderin.</p>
          </div>
        ) : (
          messages.map((m) => {
            const mine = m.senderId === profile?.id;
            return (
              <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[75%] px-3 py-2 rounded-xl text-sm leading-snug break-words ${mine ? 'bg-primary-500 text-background-50' : 'bg-background-100 dark:bg-background-300/40 text-foreground-800'}`}>
                  {m.body || (m.messageType === 'image' ? '📷 Görsel' : m.messageType === 'file' ? '📎 Dosya' : '')}
                  <div className={`text-[10px] mt-1 ${mine ? 'text-background-50/70' : 'text-foreground-400'}`}>
                    {new Date(m.createdAt).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Composer */}
      <div className="pt-3 border-t isg-divider flex items-center gap-2 flex-shrink-0">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void handleSend(); } }}
          placeholder="Mesajınızı yazın..."
          disabled={!convId || !!error}
          className="flex-1 px-3 py-2 text-sm rounded-md border border-background-300/40 dark:border-background-400/40 bg-background-50 dark:bg-background-200/60 text-foreground-900 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400 disabled:opacity-50"
        />
        <Button variant="primary" size="sm" onClick={() => void handleSend()} isLoading={sending} disabled={!text.trim() || !convId} className="whitespace-nowrap">
          Gönder
        </Button>
      </div>
    </div>
  );
}