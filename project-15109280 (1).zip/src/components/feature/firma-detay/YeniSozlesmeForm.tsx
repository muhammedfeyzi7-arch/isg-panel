import { useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import { useToastActions } from '@/hooks/useToast';
import {
  createFirmaSozlesme,
  updateFirmaSozlesme,
  friendlySozlesmeError,
  SOZLESME_TUR_OPTIONS,
  type SozlesmeTur,
  type SozlesmeData,
} from '@/lib/firmaSozlesmeService';

interface YeniSozlesmeFormProps {
  firmaId: string;
  /** Hizmet veren (varsayılan OSGB unvanı). */
  varsayilanHizmetVeren?: string | null;
  /** Dolu ise form DÜZENLEME modunda açılır; boş ise yeni sözleşme oluşturur. */
  duzenlenen?: SozlesmeData | null;
  onCreated: () => void;
  onCancel: () => void;
}

const TUR_SELECT_OPTIONS = SOZLESME_TUR_OPTIONS.map((o) => ({ value: o.value, label: o.label }));

const ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,image/jpeg,image/png,image/webp';
const MAX_SIZE = 15 * 1024 * 1024;

/**
 * Sözleşmeler sekmesinin ALTINDA yer alan satır içi form.
 * Yeni sözleşme ekler VEYA seçili sözleşmeyi düzenler. Ayrı bir modal AÇILMAZ
 * (referans tasarım: liste üstte, form altta, tek sayfa akışı).
 */
export default function YeniSozlesmeForm({ firmaId, varsayilanHizmetVeren, duzenlenen, onCreated, onCancel }: YeniSozlesmeFormProps) {
  const { addToast } = useToastActions();
  const isEdit = !!duzenlenen;
  const [tur, setTur] = useState<SozlesmeTur>(duzenlenen?.tur ?? 'isg_hizmet');
  const [sozlesmeNo, setSozlesmeNo] = useState(duzenlenen?.sozlesmeNo ?? '');
  const [hizmetVeren, setHizmetVeren] = useState(duzenlenen?.hizmetVeren ?? varsayilanHizmetVeren ?? '');
  const [baslangic, setBaslangic] = useState(duzenlenen?.baslangicTarihi ?? '');
  const [bitis, setBitis] = useState(duzenlenen?.bitisTarihi ?? '');
  const [aciklama, setAciklama] = useState(duzenlenen?.aciklama ?? '');
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    if (submitting) return;
    setError(null);
    if (!sozlesmeNo.trim()) {
      setError('Sözleşme No zorunludur.');
      return;
    }
    if (!baslangic) {
      setError('Başlangıç tarihi zorunludur.');
      return;
    }
    if (bitis && bitis < baslangic) {
      setError('Bitiş tarihi başlangıç tarihinden önce olamaz.');
      return;
    }
    setSubmitting(true);
    try {
      if (isEdit && duzenlenen) {
        await updateFirmaSozlesme(duzenlenen.id, {
          tur,
          sozlesmeNo: sozlesmeNo.trim() || null,
          hizmetVeren: hizmetVeren.trim() || null,
          aciklama: aciklama.trim() || null,
          baslangicTarihi: baslangic || null,
          bitisTarihi: bitis || null,
        });
        addToast({ title: 'Güncellendi', message: 'Sözleşme kaydı güncellendi.', type: 'success' });
      } else {
        await createFirmaSozlesme({
          firmaId,
          tur,
          sozlesmeNo: sozlesmeNo.trim() || null,
          hizmetVeren: hizmetVeren.trim() || null,
          aciklama: aciklama.trim() || null,
          baslangicTarihi: baslangic || null,
          bitisTarihi: bitis || null,
          file: files[0]?.raw ?? null,
        });
        addToast({ title: 'Sözleşme eklendi', message: 'Sözleşme kaydı başarıyla oluşturuldu.', type: 'success' });
      }
      onCreated();
    } catch (e) {
      setError(friendlySozlesmeError(e));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="isg-section">
      <div className="flex items-start gap-3 p-4 border-b isg-divider">
        <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
          <i className={isEdit ? 'ri-edit-line text-base' : 'ri-file-add-line text-base'} />
        </div>
        <div className="min-w-0">
          <h4 className="text-sm font-semibold text-foreground-900">{isEdit ? 'Sözleşmeyi Düzenle' : 'Yeni Sözleşme Ekle'}</h4>
          <p className="text-xs text-foreground-500 mt-0.5">
            {isEdit
              ? 'Seçili sözleşmenin bilgilerini güncelleyin.'
              : 'Firma için yeni bir sözleşme kaydı oluşturun ve dosyasını yükleyin.'}
          </p>
        </div>
      </div>

      <div className="p-4 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="sm:col-span-2">
            <Select label="Sözleşme Türü" required options={TUR_SELECT_OPTIONS} value={tur} onChange={(e) => setTur(e.target.value as SozlesmeTur)} />
          </div>
          <Input label="Sözleşme No" required placeholder="Örn: 2026/018" value={sozlesmeNo} onChange={(e) => setSozlesmeNo(e.target.value)} />
          <Input
            label="Hizmet Veren / İlgili Taraf"
            placeholder="Örn: ABC OSGB"
            value={hizmetVeren}
            onChange={(e) => setHizmetVeren(e.target.value)}
          />
          <DatePicker label="Başlangıç Tarihi" required value={baslangic} onChange={(e) => setBaslangic(e.target.value)} />
          <DatePicker label="Bitiş Tarihi" value={bitis} onChange={(e) => setBitis(e.target.value)} />
        </div>

        <div className={isEdit ? '' : 'grid grid-cols-1 lg:grid-cols-2 gap-4'}>
          <Textarea
            label="Açıklama"
            value={aciklama}
            onChange={(e) => setAciklama(e.target.value)}
            maxLength={500}
            placeholder="Sözleşme hakkında kısa açıklama (isteğe bağlı)"
          />
          {!isEdit && (
            <FileUpload
              label="Sözleşme Belgesi"
              accept={ACCEPT}
              maxSize={MAX_SIZE}
              multiple={false}
              files={files}
              onChange={setFiles}
              helpText="Dosyayı buraya sürükleyin veya göz atın · PDF, Word, Excel veya görsel · Maksimum 15 MB"
            />
          )}
        </div>

        {error && (
          <p className="text-sm text-danger-600 flex items-center gap-1.5">
            <i className="ri-error-warning-line" />
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-2 pt-1">
          <Button variant="ghost" size="sm" onClick={onCancel} disabled={submitting} className="whitespace-nowrap">
            Vazgeç
          </Button>
          <Button variant="primary" size="sm" leftIcon={<i className="ri-save-line" />} onClick={handleSubmit} isLoading={submitting} className="whitespace-nowrap">
            {isEdit ? 'Değişiklikleri Kaydet' : 'Sözleşmeyi Kaydet'}
          </Button>
        </div>
      </div>
    </div>
  );
}