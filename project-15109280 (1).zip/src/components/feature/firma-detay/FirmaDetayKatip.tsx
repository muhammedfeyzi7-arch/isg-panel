import { useEffect, useMemo, useState, type ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import EmptyState from '@/components/ui/EmptyState';
import Loading from '@/components/ui/Loading';
import { requestKatipWorksites } from '@/lib/isgKatip/bridge';
import { filterHizmetRowsByWorksite, maskKatipExternalId } from '@/lib/isgKatip/pilot';
import {
  normalizeKatipContractActivity,
  resolveKatipWorksiteActivity,
  type KatipContractActivityStatus,
} from '@/lib/isgKatip/contractActivity';
import { resolveKatipRole, resolveKatipRoleByCertId } from '@/lib/isgKatip/roleMapping';
import { normalizeKatipDate } from '@/lib/isgKatip/mapper';
import { formatFirmaDate, formatFirmaDateTime } from '@/pages/osgb/firmalar/components/firmaUi';
import type { FirmaData, NaceKod } from '@/lib/firmaService';

type BadgeVariantLite = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'secondary' | 'accent';

const STATUS_VIEW: Record<KatipContractActivityStatus, { label: string; variant: BadgeVariantLite }> = {
  ACTIVE: { label: 'Aktif', variant: 'success' },
  TERMINATED: { label: 'Sonlandırıldı', variant: 'danger' },
  CANCELLED: { label: 'İptal Edildi', variant: 'danger' },
  EXPIRED: { label: 'Süresi Sona Erdi', variant: 'warning' },
  PENDING: { label: 'Onay Bekliyor', variant: 'info' },
  UNKNOWN: { label: 'Belirsiz', variant: 'default' },
};

function pick(row: unknown, key: string): unknown {
  if (typeof row !== 'object' || row === null) return undefined;
  return (row as Record<string, unknown>)[key];
}
function str(v: unknown): string {
  if (v == null) return '';
  return String(v).replace(/\s+/g, ' ').trim();
}

function roleLabel(row: Record<string, unknown>): { label: string; sinif: string | null } {
  const idRes = resolveKatipRoleByCertId(pick(row, 'gorevlendirilenKisiSertifikaTipiId'));
  const res = idRes && idRes.role
    ? { role: idRes.role, uzmanlikSinifi: (idRes as { uzmanlikSinifi?: string | null }).uzmanlikSinifi ?? null }
    : resolveKatipRole(pick(row, 'gorevlendirilenKisiSertifikaTipi'), pick(row, 'sozlesmeTipi'));
  const label =
    res.role === 'isg_uzmani' ? 'İş Güvenliği Uzmanı'
      : res.role === 'isyeri_hekimi' ? 'İşyeri Hekimi'
        : res.role === 'dsp' ? 'Diğer Sağlık Personeli'
          : 'Bu Personel İSG-KATİP ile eşleşmemiş';
  const sinif = (res as { uzmanlikSinifi?: string | null }).uzmanlikSinifi ?? null;
  return { label: sinif ? `${label} (${sinif})` : label, sinif };
}

interface FirmaDetayKatipProps {
  firma: FirmaData;
  nace: NaceKod | null;
}

/**
 * Firma Detay → İSG-KATİP sekmesi (SALT-OKUMA).
 *
 * Bu sekmede YALNIZCA İSG-KATİP sisteminden alınabilen / KATİP kaynaklı veriler gösterilir.
 * Manuel İSGDenetim hesapları veya İSGDenetim'e özgü gereksinim sonuçları burada YER ALMAZ.
 *
 * Veri, tarayıcı eklentisinin HALİHAZIRDA yakaladığı gerçek KATİP hizmet sözleşmesi
 * satırlarından gelir (`requestKatipWorksites` → READ-ONLY interception belleği).
 * Yeni KATİP HTTP isteği ATILMAZ ve KATİP'e hiçbir YAZMA yapılmaz.
 */
export default function FirmaDetayKatip({ firma, nace }: FirmaDetayKatipProps) {
  const katipLinked = !!firma.isgKatipId;
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [loading, setLoading] = useState(true);
  const [bridgeError, setBridgeError] = useState<string | null>(null);
  const [captured, setCaptured] = useState(false);
  const [lastSync, setLastSync] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (!katipLinked) {
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    setBridgeError(null);
    requestKatipWorksites(6000)
      .then((res) => {
        if (cancelled) return;
        setCaptured(res.captured);
        if (!res.ok || !res.captured) {
          setBridgeError(res.error || 'İSG-KATİP verisi alınamadı.');
          setRows([]);
          return;
        }
        const filtered = filterHizmetRowsByWorksite(
          (res.hizmetRows ?? []) as Record<string, unknown>[],
          firma.isgKatipId as string,
        );
        setRows(filtered);
        setLastSync(new Date().toISOString());
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [katipLinked, firma.isgKatipId, refreshKey]);

  const worksite = rows[0] ?? null;

  const unvan = str(pick(worksite, 'hizmetAlanIsyeriUnvani')) || firma.ad;
  const sgkNo = str(pick(worksite, 'hizmetAlanIsyeriSgkDetSisNo'));
  const naceKodu = str(pick(worksite, 'hizmetAlanIsyeriNaceKodu')) || nace?.kod || '';
  const tehlike = str(pick(worksite, 'hizmetAlanIsyeriTehlikeSinifi'));
  const calisan = str(pick(worksite, 'hizmetAlanIsyeriCalisanSayisi'));
  const il = str(pick(worksite, 'hizmetAlanIsyeriIli'));
  const ilce = str(pick(worksite, 'hizmetAlanIsyeriIlcesi'));

  const contracts = useMemo(() => {
    const map = new Map<string, Record<string, unknown>>();
    for (const r of rows) {
      const id = str(pick(r, 'sozlesmeId'));
      if (!id) continue;
      if (!map.has(id)) map.set(id, r);
    }
    return [...map.values()];
  }, [rows]);

  const professionals = useMemo(() => {
    const map = new Map<string, Record<string, unknown>>();
    for (const r of rows) {
      const key =
        str(pick(r, 'gorevlendirilenKisiUserId')) ||
        str(pick(r, 'gorevlendirilenKisiTckn')) ||
        str(pick(r, 'gorevlendirilenKisiAdSoyad'));
      if (!key) continue;
      if (!map.has(key)) map.set(key, r);
    }
    return [...map.values()];
  }, [rows]);

  const worksiteActivity = useMemo(() => resolveKatipWorksiteActivity(rows), [rows]);

  const contractColumns: TableColumn<Record<string, unknown>>[] = [
    { key: 'no', header: 'Sözleşme No', render: (r) => <span className="text-sm font-medium text-foreground-800">{maskKatipExternalId(pick(r, 'sozlesmeId')) ?? '—'}</span> },
    {
      key: 'tur',
      header: 'Sözleşme Türü',
      render: (r) => {
        const role = roleLabel(r);
        return <span className="text-sm text-foreground-700">{role.label}</span>;
      },
    },
    { key: 'bas', header: 'Başlangıç Tarihi', render: (r) => <span className="text-sm text-foreground-600">{formatFirmaDate(normalizeKatipDate(pick(r, 'sozlesmeBaslangicTarihi')))}</span> },
    { key: 'bit', header: 'Bitiş Tarihi', render: (r) => <span className="text-sm text-foreground-600">{formatFirmaDate(normalizeKatipDate(pick(r, 'sozlesmeBitisTarihi')))}</span> },
    { key: 'durum', header: 'Durum', render: (r) => { const d = STATUS_VIEW[normalizeKatipContractActivity(r).status]; return <Badge variant={d.variant}>{d.label}</Badge>; } },
    { key: 'personel', header: 'İlgili Personel', render: (r) => <span className="text-sm text-foreground-700">{str(pick(r, 'gorevlendirilenKisiAdSoyad')) || '—'}</span> },
    { key: 'kaynak', header: 'Kaynak', render: () => <Badge variant="info">İSG-KATİP</Badge> },
  ];

  const professionalColumns: TableColumn<Record<string, unknown>>[] = [
    { key: 'id', header: 'KATİP Personel ID', render: (r) => <span className="text-sm text-foreground-600 tabular-nums">{maskKatipExternalId(pick(r, 'gorevlendirilenKisiUserId')) ?? '—'}</span> },
    { key: 'ad', header: 'Ad Soyad', render: (r) => <span className="text-sm font-medium text-foreground-800">{str(pick(r, 'gorevlendirilenKisiAdSoyad')) || '—'}</span> },
    {
      key: 'rol',
      header: 'Görev / Profil',
      render: (r) => {
        const role = roleLabel(r);
        return <Badge variant={role.sinif || role.label !== 'Bu Personel İSG-KATİP ile eşleşmemiş' ? 'info' : 'default'}>{role.label}</Badge>;
      },
    },
    {
      key: 'gorevDurum',
      header: 'Görevlendirme Durumu',
      render: (r) => { const d = STATUS_VIEW[normalizeKatipContractActivity(r).status]; return <Badge variant={d.variant}>{d.label}</Badge>; },
    },
    { key: 'bas', header: 'Başlangıç Tarihi', render: (r) => <span className="text-sm text-foreground-600">{formatFirmaDate(normalizeKatipDate(pick(r, 'sozlesmeBaslangicTarihi')))}</span> },
    { key: 'bit', header: 'Bitiş Tarihi', render: (r) => <span className="text-sm text-foreground-600">{formatFirmaDate(normalizeKatipDate(pick(r, 'sozlesmeBitisTarihi')))}</span> },
    { key: 'eslesme', header: 'Eşleşme Durumu', render: () => <Badge variant="success">Eşleşti</Badge> },
  ];

  // ── Eşleşmemiş firma ──
  if (!katipLinked) {
    return (
      <div className="isg-section p-4">
        <EmptyState
          icon="ri-links-line"
          title="Bu firma İSG-KATİP ile eşleşmemiş"
          description="İSG-KATİP bilgileri, yalnızca KATİP'ten aktarılmış (eşleşmiş) firmalar için görüntülenir. Manuel oluşturulan firmalarda KATİP verisi bulunmaz."
        />
      </div>
    );
  }

  // ── Yükleniyor (eklenti köprüsü yanıtı beklenirken boş ekran yerine durum gösterilir) ──
  if (loading) {
    return (
      <div className="isg-section p-4">
        <Loading size="lg" text="İSG-KATİP verisi yükleniyor..." />
      </div>
    );
  }

  return (
    <div className="space-y-3 min-w-0">
      {bridgeError && (
        <div className="isg-section p-4">
          <div className="flex items-start gap-2">
            <i className="ri-plug-line text-warning-600 mt-0.5 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-foreground-800">İSG-KATİP verisi alınamadı</p>
              <p className="text-xs text-foreground-500 mt-0.5">{bridgeError}</p>
              <p className="text-[11px] text-foreground-400 mt-1">
                KATİP verileri, tarayıcı eklentisinin yakaladığı gerçek verilerden gelir. Eklentinin kurulu ve İSG-KATİP oturumunun açık olduğundan emin olun.
              </p>
            </div>
          </div>
        </div>
      )}

      {!bridgeError && captured && rows.length === 0 && (
        <div className="isg-section p-4">
          <div className="flex items-start gap-2">
            <i className="ri-information-line text-primary-500 mt-0.5 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-sm font-semibold text-foreground-800">Bu işyeri için yakalanan KATİP kaydı bulunamadı</p>
              <p className="text-xs text-foreground-500 mt-0.5">
                Eklenti veri yakalamış ancak bu firmaya (KATİP işyeri kimliği) ait hizmet sözleşmesi satırı bulunamadı.
              </p>
            </div>
          </div>
        </div>
      )}

      {rows.length > 0 && (
        <>
          {/* İşyeri Bilgileri + Senkronizasyon Bilgileri */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 items-start">
            <div className="isg-section p-4 min-w-0">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                  <i className="ri-building-2-line text-primary-600 dark:text-primary-400 text-base" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-sm font-semibold text-foreground-800">İSG-KATİP İşyeri Bilgileri</h4>
                  <p className="text-xs text-foreground-500 mt-0.5">Bu bilgiler İSG-KATİP sisteminden alınan verilerdir.</p>
                </div>
              </div>
              <div className="grid grid-cols-2 lg:grid-cols-2 gap-3">
                <KatipField label="KATİP İşyeri ID" value={maskKatipExternalId(firma.isgKatipId) ?? '—'} />
                <KatipField label="İşyeri Ünvanı" value={unvan} className="col-span-2" />
                <KatipField label="SGK / DETSİS No" value={sgkNo} />
                <KatipField label="NACE Kodu" value={naceKodu} />
                <KatipField label="Tehlike Sınıfı" value={tehlike || firma.tehlikeSinifiLabel} />
                <KatipField label="KATİP Çalışan Sayısı" value={calisan || (firma.isgKatipCalisanSayisi != null ? String(firma.isgKatipCalisanSayisi) : '—')} />
                <KatipField label="İl" value={il || firma.il} />
                <KatipField label="İlçe" value={ilce || firma.ilce} />
                <KatipField
                  label="KATİP İşyeri Durumu"
                  className="col-span-2"
                  node={<div className="min-h-[38px] flex items-center px-3 py-2 rounded-md bg-background-100 dark:bg-background-300/25 border border-background-300/40 dark:border-background-400/30"><Badge variant={worksiteActivity.status === 'ACTIVE' ? 'success' : 'warning'}>{worksiteActivity.status === 'ACTIVE' ? 'Aktif' : 'Doğrulanamadı'}</Badge></div>}
                />
              </div>
            </div>

            <div className="isg-section p-4 min-w-0">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                    <i className="ri-refresh-line text-primary-600 dark:text-primary-400 text-base" />
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-sm font-semibold text-foreground-800">Senkronizasyon Bilgileri</h4>
                    <p className="text-xs text-foreground-500 mt-0.5">İSG-KATİP verilerinin son senkronizasyon durumu.</p>
                  </div>
                </div>
                <Button variant="primary" size="sm" leftIcon={<i className={`ri-refresh-line ${loading ? 'animate-spin' : ''}`} />} isLoading={loading} onClick={() => setRefreshKey((k) => k + 1)} className="whitespace-nowrap flex-shrink-0">
                  Şimdi Senkronize Et
                </Button>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <KatipField label="Son Senkronizasyon" value={lastSync ? formatFirmaDateTime(lastSync) : '—'} />
                <KatipField label="Senkronizasyon Durumu" node={<div className="min-h-[38px] flex items-center px-3 py-2 rounded-md bg-background-100 dark:bg-background-300/25 border border-background-300/40 dark:border-background-400/30"><Badge variant="success">Başarılı</Badge></div>} />
                <KatipField label="Son Alınan Veri" value="İşyeri, sözleşmeler ve personel bilgileri" className="col-span-2" />
                <KatipField label="Sonraki Otomatik Senkronizasyon" value="—" className="col-span-2" />
              </div>
              <div className="mt-3 flex items-start gap-2 rounded-lg bg-primary-50/70 dark:bg-primary-500/10 border border-primary-200/50 dark:border-primary-500/25 px-3 py-2.5">
                <i className="ri-information-line text-primary-600 dark:text-primary-400 mt-0.5 flex-shrink-0" />
                <p className="text-xs text-foreground-600 dark:text-foreground-500">
                  Bu sekmede yalnızca İSG-KATİP sisteminden alınabilen veriler gösterilmektedir.
                  Manuel eklenen bilgiler ve İSGDenetim'e özgü hesaplamalar bu sekmede yer almaz.
                </p>
              </div>
            </div>
          </div>

          {/* İSG-KATİP Sözleşmeleri */}
          <div className="isg-section p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                <i className="ri-file-shield-2-line text-primary-600 dark:text-primary-400 text-base" />
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-foreground-800">İSG-KATİP Sözleşmeleri</h4>
                <p className="text-xs text-foreground-500 mt-0.5">İşyeri için İSG-KATİP sistemindeki sözleşme bilgileri.</p>
              </div>
            </div>
            <div className="overflow-x-auto">
              <Table data={contracts} columns={contractColumns} keyExtractor={(r) => str(pick(r, 'sozlesmeId'))} density="compact" />
            </div>
          </div>

          {/* İSG-KATİP Personel / Görevlendirmeler */}
          <div className="isg-section p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                <i className="ri-team-line text-primary-600 dark:text-primary-400 text-base" />
              </div>
              <div className="min-w-0">
                <h4 className="text-sm font-semibold text-foreground-800">İSG-KATİP Personel / Görevlendirmeler</h4>
                <p className="text-xs text-foreground-500 mt-0.5">İşyeri için İSG-KATİP sistemindeki görevlendirme bilgileri.</p>
              </div>
            </div>
            <div className="overflow-x-auto">
              <Table data={professionals} columns={professionalColumns} keyExtractor={(r) => str(pick(r, 'gorevlendirilenKisiUserId')) || str(pick(r, 'gorevlendirilenKisiTckn')) || str(pick(r, 'gorevlendirilenKisiAdSoyad'))} density="compact" />
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function KatipField({ label, value, node, className = '' }: { label: string; value?: string; node?: ReactNode; className?: string }) {
  return (
    <div className={`min-w-0 ${className}`}>
      <span className="block text-xs text-foreground-500 mb-1">{label}</span>
      {node ?? (
        <div className="min-h-[38px] flex items-center px-3 py-2 rounded-md bg-background-100 dark:bg-background-300/25 border border-background-300/40 dark:border-background-400/30">
          <span className="text-sm font-medium text-foreground-800 break-words">{value || '—'}</span>
        </div>
      )}
    </div>
  );
}