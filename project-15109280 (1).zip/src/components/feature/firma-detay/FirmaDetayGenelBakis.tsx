import { lazy, Suspense, useState, useEffect, useRef, type ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import EmailInput from '@/components/ui/EmailInput';
import PhoneInput from '@/components/ui/PhoneInput';
import ProvinceSelect from '@/components/ui/ProvinceSelect';
import DistrictSelect from '@/components/ui/DistrictSelect';
import FormSection from '@/components/ui/FormSection';
import { useToastActions } from '@/hooks/useToast';
import type { FirmaData, NaceKod, TehlikeSinifi } from '@/lib/firmaService';
import { updateFirma, TEHLIKE_SINIFI_OPTIONS, resolveCalisanSayisi } from '@/lib/firmaService';
import NaceSelect, { type NaceSelectValue } from '@/pages/osgb/firmalar/components/NaceSelect';
import type { RoleRequirementMap } from '@/lib/atamaRequirement';
import { HAZARD_CLASS_LABEL, type HazardClass } from '@/lib/gereksinimService';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import { geocodeAddress } from '@/lib/geocode';
import { formatFirmaDate } from '@/pages/osgb/firmalar/components/firmaUi';

const FirmaHarita = lazy(() => import('@/components/feature/firma-detay/FirmaHarita'));

interface FirmaDetayGenelBakisProps {
  firma: FirmaData;
  nace: NaceKod | null;
  osgbUnvan: string | null;
  roleReqs: RoleRequirementMap;
  sonHesaplama: string | null;
  onOpenSozlesmeler: () => void;
  /** Kart-içi düzenleme kaydedildikten sonra üst bileşeni bilgilendirir (veriyi tazeler). */
  onChanged?: () => void;
  /** Sağ kolona eklenen ek içerik (ör. Firma Paneli yönetim kartı). */
  rightExtra?: ReactNode;
  /** Hizmeti sonlanmış firmada düzenleme aksiyonları kilitlenir. */
  disabled?: boolean;
  /**
   * Firma bilgilerini düzenleme izni (rol matrisinden gelir). `false` ise uzman/hekim
   * için Düzenle aksiyonu HİÇ gösterilmez — salt-okunur görünüm. Varsayılan: true.
   */
  canEdit?: boolean;
  /** Modal düzenleme modunda açıldığında ilgili kartın doğrudan düzenlemeye geçmesi için. */
  autoEditSection?: EditSection;
}

type EditSection = 'firma' | 'iletisim' | 'adres' | 'hizmet' | 'aciklama';

/**
 * Read-only bilgi alanı (açık zeminli, kenarlıklı değer kutusu).
 */
function ReadField({ label, value, node, className = '' }: { label: string; value?: string; node?: ReactNode; className?: string }) {
  return (
    <div className={`min-w-0 ${className}`}>
      <span className="block text-xs text-foreground-500 mb-1">{label}</span>
      {node ?? (
        <div className="min-h-[38px] flex items-center px-3 py-2 rounded-md bg-background-100 dark:bg-background-300/25 border border-background-300/40 dark:border-background-400/30">
          <span className="text-sm font-medium text-foreground-800 break-words">{value || '—'}</span>
        </div>
      )}
    </div>
  );
}

/**
 * Firma Detay → Genel Bilgiler sekmesi (referans tasarım).
 * Kartlar: Firma Bilgileri · İletişim ve Yetkili · Adres ve Konum · Firma Paneli ·
 * Hizmet Bilgileri · Açıklama ve Notlar.
 *
 * Düzenleme kartların KENDİ "Düzenle" butonlarından yapılır; üstte ayrı bir
 * "Firma Düzenle" butonu YOKTUR. Alanlar aynı kart içinde düzenlenir (yeni modal açılmaz).
 * Firma paneli (Panel Var / Panel Yok) yalnızca bu ekrandaki Firma Paneli kartından yönetilir.
 */
export default function FirmaDetayGenelBakis({
  firma,
  nace,
  onChanged,
  rightExtra,
  disabled = false,
  canEdit = true,
  autoEditSection,
}: FirmaDetayGenelBakisProps) {
  const { addToast } = useToastActions();
  // Rol düzenleme izni + hizmet bitiş kilidi birlikte değerlendirilir.
  const readOnly = disabled || !canEdit;
  const hazardLabel = nace ? HAZARD_CLASS_LABEL[nace.tehlike_sinifi] : firma.tehlikeSinifiLabel;
  const hazardVariant = (firma.tehlikeSinifi as HazardClass) === 'cok_tehlikeli' ? 'danger' : firma.tehlikeSinifi === 'tehlikeli' ? 'warning' : 'success';
  const katipKilitli = !!firma.isgKatipId;
  // GÖSTERİM: İSG-KATİP ile eşleşmişse KATİP çalışan sayısı (gereksinim motoruyla aynı).
  const efekti̇fCalisanSayisi = resolveCalisanSayisi(firma);
  // DÜZENLEME: merkezi (manuel) `calisan_sayisi` alanı.
  const calisanSayisi = firma.calisanSayisi ?? 0;

  const [editSection, setEditSection] = useState<EditSection | null>(null);
  const [saving, setSaving] = useState(false);
  const [draft, setDraft] = useState<Record<string, string>>({});

  // Konum (lat/lng) yoksa: il/ilçe adresine göre haritayı yakınlaştırmak için
  // fallback merkez çözülür. Böylece konum eklenmese de harita gösterilir.
  const hasLoc = firma.latitude != null && firma.longitude != null;
  const [mapFallback, setMapFallback] = useState<{ lat: number; lng: number } | null>(null);
  useEffect(() => {
    if (hasLoc) return undefined;
    const il = firma.il && firma.il !== '—' ? firma.il : null;
    const ilce = firma.ilce && firma.ilce !== '—' ? firma.ilce : null;
    if (!il) return undefined;
    let cancelled = false;
    geocodeAddress({ il, ilce }, 1)
      .then((r) => {
        if (!cancelled && r[0]) setMapFallback({ lat: r[0].lat, lng: r[0].lon });
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [firma.id, firma.il, firma.ilce, hasLoc]);

  const setD = (k: string, v: string) => setDraft((p) => ({ ...p, [k]: v }));

  const beginEdit = (section: EditSection) => {
    if (readOnly) return;
    const base: Record<string, string> = {};
    if (section === 'firma') {
      base.unvan = firma.ad === '—' ? '' : firma.ad;
      base.sicilNo = firma.sicilNo === '—' ? '' : firma.sicilNo;
      base.sgkDetsisNo = firma.sgkDetsisNo === '—' ? '' : firma.sgkDetsisNo;
      base.vergiNo = firma.vergiNo === '—' ? '' : firma.vergiNo;
      base.naceId = firma.naceId ?? '';
      base.tehlikeSinifi = firma.tehlikeSinifi;
      base.calisanSayisi = String(katipKilitli ? efekti̇fCalisanSayisi : calisanSayisi);
    } else if (section === 'iletisim') {
      base.telefon = firma.telefon === '—' ? '' : firma.telefon;
      base.email = firma.email === '—' ? '' : firma.email;
      const parts = firma.yetkili === '—' ? [] : firma.yetkili.split(' ');
      base.yetkiliAd = parts[0] ?? '';
      base.yetkiliSoyad = parts.slice(1).join(' ');
      base.yetkiliEmail = firma.yetkiliEmail === '—' ? '' : firma.yetkiliEmail;
      base.yetkiliTelefon = firma.yetkiliTelefon === '—' ? '' : firma.yetkiliTelefon;
    } else if (section === 'hizmet') {
      base.hizmetBaslangic = firma.hizmetBaslangicTarihi ?? '';
      base.hizmetBitis = firma.hizmetBitisTarihi ?? '';
    } else if (section === 'aciklama') {
      base.aciklama = firma.aciklama || '';
    } else {
      base.acikAdres = firma.acikAdres === '—' ? '' : firma.acikAdres;
      base.il = firma.il === '—' ? '' : firma.il;
      base.ilce = firma.ilce === '—' ? '' : firma.ilce;
      base.mahalle = firma.mahalle === '—' ? '' : firma.mahalle;
      base.caddeSokak = firma.caddeSokak === '—' ? '' : firma.caddeSokak;
      base.binaNo = firma.binaNo === '—' ? '' : firma.binaNo;
      base.daireKat = firma.daireKat === '—' ? '' : firma.daireKat;
    }
    setDraft(base);
    setEditSection(section);
  };

  const cancelEdit = () => {
    setEditSection(null);
    setDraft({});
  };

  // Liste satırındaki "Düzenle" aksiyonu modalı düzenleme modunda açtığında,
  // ilgili kartı otomatik olarak düzenlemeye geçirir (yalnızca bir kez).
  const autoEditDoneRef = useRef(false);
  useEffect(() => {
    if (!autoEditSection || autoEditDoneRef.current || readOnly) return;
    autoEditDoneRef.current = true;
    beginEdit(autoEditSection);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoEditSection, disabled]);

  const saveEdit = (section: EditSection) => {
    if (!firma || readOnly) return;
    if (section === 'firma' && !draft.unvan?.trim()) {
      addToast({ title: 'Firma unvanı zorunlu', message: 'Firma unvanı boş olamaz.', type: 'warning' });
      return;
    }
    const calisanNum = Math.max(0, Math.floor(Number(draft.calisanSayisi) || 0));
    const patch =
      section === 'firma'
        ? {
            unvan: draft.unvan.trim(),
            sicil_no: draft.sicilNo?.trim() || null,
            vergi_no: draft.vergiNo?.trim() || null,
            ...(katipKilitli ? {} : { sgk_detsis_no: draft.sgkDetsisNo?.trim() || null, nace_id: draft.naceId || null }),
            tehlike_sinifi: (draft.tehlikeSinifi || firma.tehlikeSinifi) as TehlikeSinifi,
            // İSG-KATİP ile eşleşen firmada çalışan sayısı KATİP'ten gelir; manuel alan YAZILMAZ.
            ...(katipKilitli ? {} : { calisan_sayisi: calisanNum, manuel_calisan_sayisi: calisanNum }),
          }
        : section === 'iletisim'
        ? {
            telefon: draft.telefon?.trim() || null,
            email: draft.email?.trim() || null,
            yetkili_ad: draft.yetkiliAd?.trim() || null,
            yetkili_soyad: draft.yetkiliSoyad?.trim() || null,
            yetkili_email: draft.yetkiliEmail?.trim() || null,
            yetkili_telefon: draft.yetkiliTelefon?.trim() || null,
          }
        : section === 'hizmet'
        ? {
            hizmet_baslangic_tarihi: draft.hizmetBaslangic || null,
            hizmet_bitis_tarihi: draft.hizmetBitis || null,
          }
        : section === 'aciklama'
        ? { aciklama: draft.aciklama?.trim() || null }
        : {
            acik_adres: draft.acikAdres?.trim() || null,
            il: draft.il || null,
            ilce: draft.ilce || null,
            mahalle: draft.mahalle?.trim() || null,
            cadde_sokak: draft.caddeSokak?.trim() || null,
            bina_no: draft.binaNo?.trim() || null,
            daire_kat: draft.daireKat?.trim() || null,
          };

    setSaving(true);
    updateFirma(firma.id, patch)
      .then(() => {
        addToast({ title: 'Kaydedildi', message: 'Firma bilgileri güncellendi.', type: 'success' });
        cancelEdit();
        onChanged?.();
      })
      .catch((e) => addToast({ title: 'Kaydedilemedi', message: friendlyErrorMessage(e, 'Firma bilgileri güncellenemedi.'), type: 'error' }))
      .finally(() => setSaving(false));
  };

  const headerAction = (section: EditSection) => {
    // Uzman/hekim: firma düzenleme yetkisi yok → düzenleme aksiyonu GÖSTERİLMEZ.
    if (!canEdit) return null;
    return editSection === section ? (
      <>
        <Button variant="ghost" size="sm" onClick={cancelEdit} disabled={saving} className="whitespace-nowrap">
          Vazgeç
        </Button>
        <Button variant="primary" size="sm" onClick={() => saveEdit(section)} isLoading={saving} leftIcon={<i className="ri-save-line" />} className="whitespace-nowrap">
          Kaydet
        </Button>
      </>
    ) : (
      <Button
        variant="ghost"
        size="sm"
        leftIcon={<i className="ri-edit-line" />}
        onClick={() => beginEdit(section)}
        disabled={editSection !== null || readOnly}
        className="whitespace-nowrap"
      >
        Düzenle
      </Button>
    );
  };

  const editing = (s: EditSection) => editSection === s;

  return (
    <div className="grid grid-cols-1 xl:grid-cols-2 gap-3 min-w-0 items-start">
      {/* 1 — Firma Bilgileri */}
      <FormSection icon="ri-building-2-line" title="Firma Bilgileri" subtitle="Firmanın kimlik ve sınıflandırma bilgileri." headerRight={headerAction('firma')}>
        {editing('firma') ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input label="Firma Unvanı" required value={draft.unvan ?? ''} onChange={(e) => setD('unvan', e.target.value)} containerClassName="sm:col-span-2" />
            <Input label="SGK Sicil Numarası / DETSİS No" value={draft.sgkDetsisNo ?? ''} onChange={(e) => setD('sgkDetsisNo', e.target.value)} disabled={katipKilitli} helpText={katipKilitli ? 'İSG-KATİP kaynağından senkronize edilir.' : undefined} />
            <Input label="Vergi Numarası" value={draft.vergiNo ?? ''} onChange={(e) => setD('vergiNo', e.target.value)} />
            <Input label="İşyeri Sicil No" value={draft.sicilNo ?? ''} onChange={(e) => setD('sicilNo', e.target.value)} />
            <Input
              label="Çalışan Sayısı"
              type="number"
              min={0}
              step={1}
              value={draft.calisanSayisi ?? ''}
              onChange={(e) => setD('calisanSayisi', e.target.value)}
              disabled={katipKilitli}
              helpText={katipKilitli ? `İSG-KATİP ile eşleştiği için çalışan sayısı İSG-KATİP'ten (${efekti̇fCalisanSayisi}) alınır.` : undefined}
            />
            <NaceSelect
              label="NACE Kodu"
              value={draft.naceId || null}
              onChange={(n: NaceSelectValue | null) => {
                setD('naceId', n?.id ?? '');
                if (n) setD('tehlikeSinifi', n.tehlikeSinifi);
              }}
              helpText={katipKilitli ? 'İSG-KATİP kaynağından senkronize edilir.' : 'NACE seçildiğinde tehlike sınıfı önerilir.'}
            />
            <Select label="Tehlike Sınıfı" options={TEHLIKE_SINIFI_OPTIONS} value={draft.tehlikeSinifi ?? ''} onChange={(e) => setD('tehlikeSinifi', e.target.value)} />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <ReadField label="Firma Unvanı" value={firma.ad} className="sm:col-span-2" />
            <ReadField label="SGK Sicil Numarası / DETSİS No" value={firma.sgkDetsisNo} />
            <ReadField label="Vergi Numarası" value={firma.vergiNo} />
            <ReadField
              label="NACE Kodu"
              node={
                <div className="min-h-[38px] flex flex-col justify-center px-3 py-2 rounded-md bg-background-100 dark:bg-background-300/25 border border-background-300/40 dark:border-background-400/30">
                  <span className="text-sm font-medium text-foreground-800">{nace?.kod ?? firma.naceKod ?? '—'}</span>
                  <span className="text-xs text-foreground-500 mt-0.5 leading-snug break-words">
                    {nace?.faaliyet_tanimi ?? 'Faaliyet tanımı bulunamadı'}
                  </span>
                </div>
              }
            />
            <ReadField label="Tehlike Sınıfı" node={<div className="min-h-[38px] flex items-center px-3 py-2 rounded-md bg-background-100 dark:bg-background-300/25 border border-background-300/40 dark:border-background-400/30"><Badge variant={hazardVariant}>{hazardLabel}</Badge></div>} />
            <ReadField label="Çalışan Sayısı" value={String(efekti̇fCalisanSayisi)} className="sm:col-span-2" />
          </div>
        )}
      </FormSection>

      {/* 2 — İletişim ve Yetkili */}
      <FormSection icon="ri-contacts-line" title="İletişim ve Yetkili" subtitle="Firma iletişim bilgileri ve yetkili kişi." headerRight={headerAction('iletisim')}>
        {editing('iletisim') ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <PhoneInput label="Telefon" value={draft.telefon ?? ''} onChange={(v) => setD('telefon', v)} leftIcon={<i className="ri-phone-line" />} />
            <EmailInput label="Firma E-posta" value={draft.email ?? ''} onChange={(v) => setD('email', v)} />
            <Input label="Yetkili Adı Soyadı" value={draft.yetkiliAd ?? ''} onChange={(e) => setD('yetkiliAd', e.target.value)} />
            <PhoneInput label="Yetkili Telefon" value={draft.yetkiliTelefon ?? ''} onChange={(v) => setD('yetkiliTelefon', v)} leftIcon={<i className="ri-phone-line" />} />
            <Input label="Yetkili Soyadı" value={draft.yetkiliSoyad ?? ''} onChange={(e) => setD('yetkiliSoyad', e.target.value)} />
            <EmailInput label="Yetkili E-posta" value={draft.yetkiliEmail ?? ''} onChange={(v) => setD('yetkiliEmail', v)} />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <ReadField label="Telefon" value={firma.telefon} />
            <ReadField label="Firma E-posta" value={firma.email} />
            <ReadField label="Yetkili Adı Soyadı" value={firma.yetkili} />
            <ReadField label="Yetkili Telefon" value={firma.yetkiliTelefon} />
            <ReadField label="Yetkili E-posta" value={firma.yetkiliEmail} className="sm:col-span-2" />
          </div>
        )}
      </FormSection>

      {/* 3 — Adres ve Konum */}
      <FormSection icon="ri-map-pin-line" title="Adres ve Konum" subtitle="Firmanın adres ve konum bilgileri. Ziyaret planı bu adrese göre yapılır." headerRight={headerAction('adres')}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="space-y-3 min-w-0">
              {editing('adres') ? (
                <>
                  <Textarea label="Açık Adres" rows={2} value={draft.acikAdres ?? ''} onChange={(e) => setD('acikAdres', e.target.value)} maxLength={300} />
                  <div className="grid grid-cols-2 gap-3">
                    <ProvinceSelect label="İl" value={draft.il ?? ''} onChange={(v) => { setD('il', v); setD('ilce', ''); }} />
                    <DistrictSelect label="İlçe" provinceValue={draft.il ?? ''} value={draft.ilce ?? ''} onChange={(v) => setD('ilce', v)} />
                    <Input label="Mahalle" value={draft.mahalle ?? ''} onChange={(e) => setD('mahalle', e.target.value)} />
                    <Input label="Cadde / Sokak" value={draft.caddeSokak ?? ''} onChange={(e) => setD('caddeSokak', e.target.value)} />
                    <Input label="Bina No" value={draft.binaNo ?? ''} onChange={(e) => setD('binaNo', e.target.value)} />
                    <Input label="Daire / Kat" value={draft.daireKat ?? ''} onChange={(e) => setD('daireKat', e.target.value)} />
                  </div>
                </>
              ) : (
                <>
                  <ReadField label="Açık Adres" value={firma.acikAdres} />
                  <div className="grid grid-cols-2 gap-3">
                    <ReadField label="İl" value={firma.il} />
                    <ReadField label="İlçe" value={firma.ilce} />
                    <ReadField label="Mahalle" value={firma.mahalle} />
                    <ReadField label="Cadde / Sokak" value={firma.caddeSokak} />
                    <ReadField label="Bina No" value={firma.binaNo} />
                    <ReadField label="Daire / Kat" value={firma.daireKat} />
                  </div>
                </>
              )}
            </div>
            <div className="min-w-0">
              <div className="rounded-lg overflow-hidden border border-background-300/40 dark:border-background-400/40">
                <Suspense
                  fallback={
                    <div className="flex items-center justify-center bg-background-100 dark:bg-background-200/50" style={{ height: 280 }}>
                      <i className="ri-loader-4-line animate-spin text-xl text-primary-500" />
                    </div>
                  }
                >
                  <FirmaHarita
                    lat={firma.latitude ?? mapFallback?.lat ?? null}
                    lng={firma.longitude ?? mapFallback?.lng ?? null}
                    geofenceRadiusMeters={firma.geofenceRadiusMeters}
                    showMarker={hasLoc}
                    zoom={hasLoc ? 14 : mapFallback ? 11 : 6}
                    height={280}
                    emptyHint={hasLoc ? undefined : 'Konum bilgisi kaydedilmemiş. Haritadan adres seçildiğinde burada işaretlenir.'}
                  />
                </Suspense>
              </div>
              <p className="mt-2 text-xs text-foreground-500 flex items-center gap-1">
                <i className="ri-information-line" />
                Bu konum ziyaret planlaması tarafından kullanılır.
              </p>
            </div>
          </div>
      </FormSection>

      {/* 4 — Firma Paneli (yalnızca buradan yönetilir) */}
      {rightExtra}

      {/* 5 — Hizmet Bilgileri */}
      <FormSection icon="ri-calendar-check-line" title="Hizmet Bilgileri" subtitle="Hizmet başlangıç/bitiş tarihleri ve durumu." headerRight={headerAction('hizmet')}>
        {editing('hizmet') ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input label="Hizmet Başlangıç Tarihi" type="date" value={draft.hizmetBaslangic ?? ''} onChange={(e) => setD('hizmetBaslangic', e.target.value)} />
            <Input label="Hizmet Bitiş Tarihi" type="date" value={draft.hizmetBitis ?? ''} onChange={(e) => setD('hizmetBitis', e.target.value)} />
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <ReadField label="Hizmet Başlangıç Tarihi" value={formatFirmaDate(firma.hizmetBaslangicTarihi)} />
            <ReadField label="Hizmet Bitiş Tarihi" value={formatFirmaDate(firma.hizmetBitisTarihi)} />
            <ReadField
              label="Hizmet Durumu"
              node={<div className="min-h-[38px] flex items-center px-3 py-2 rounded-md bg-background-100 dark:bg-background-300/25 border border-background-300/40 dark:border-background-400/30"><Badge variant={firma.isActive ? 'success' : 'danger'}>{firma.isActive ? 'Hizmet Devam Ediyor' : 'Hizmet Sonlandı'}</Badge></div>}
            />
            <ReadField label="Çalışan Sayısı" value={String(efekti̇fCalisanSayisi)} />
          </div>
        )}
      </FormSection>

      {/* 6 — Açıklama ve Notlar */}
      <FormSection icon="ri-file-text-line" title="Açıklama ve Notlar" subtitle="Firmaya özel notlar, faaliyet alanı vb. bilgiler." headerRight={headerAction('aciklama')}>
          {editing('aciklama') ? (
            <Textarea label="Açıklama" rows={3} maxLength={500} placeholder="Firmaya özel notlar, faaliyet alanı vb. bilgiler..." value={draft.aciklama ?? ''} onChange={(e) => setD('aciklama', e.target.value)} />
          ) : firma.aciklama ? (
            <p className="text-sm text-foreground-700 leading-relaxed whitespace-pre-wrap">{firma.aciklama}</p>
          ) : (
            <p className="text-sm text-foreground-400">Açıklama girilmemiş.</p>
          )}
      </FormSection>
    </div>
  );
}