import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import DonutChart from '@/components/feature/DonutChart';
import ErrorState from '@/components/ui/ErrorState';
import Loading from '@/components/ui/Loading';
import { useToastActions } from '@/hooks/useToast';
import { useExcelBrandMeta } from '@/hooks/useExcelBrandMeta';
import { useModalActions } from '@/hooks/useModal';
import EvrakUploadModal from '@/components/feature/evrak/EvrakUploadModal';
import GereksinimEksikPersonelModal from '@/pages/osgb/firmalar/components/GereksinimEksikPersonelModal';
import { fetchEvrakTurleri } from '@/lib/evrakService';
import type { FirmaData } from '@/lib/firmaService';
import { fetchNaceById } from '@/lib/firmaService';
import {
  calculateFirmaRequirements,
  fetchFirmaGereksinimleri,
  friendlyGereksinimError,
  HAZARD_CLASS_LABEL,
  type HazardClass,
  type GereksinimScope,
  type FirmaGereksinimRow,
} from '@/lib/gereksinimService';
import { fetchRequirementLegalMap, type RequirementLegalMap } from '@/lib/mevzuat';
import { exportBrandedWorkbook, type ExcelColumnDef, type ExcelDataRow } from '@/lib/excel/isgExcelCore';
import GereksinimTablosu from './GereksinimTablosu';
import {
  DURUM_VIEW,
  durumKeyOf,
  UST_KATEGORI_LABEL,
  ustKategoriOf,
  yasalSureText,
  type DurumKey,
  type DurumVariant,
  type UstKategori,
} from './gereksinimKategorileri';
import { useTabData } from '@/lib/tabDataCache';
import { matchesSearch } from '@/utils/turkishText';
import { logError } from '@/utils/errorLogger';

/** Merkezi cache anahtarı — modal açılışında prefetch ile aynı anahtar kullanılır. */
export const ISG_GEREKSINIM_PANELI_KEY = (firmaId: string, scope: GereksinimScope) =>
  ['isg-gereksinim-paneli', firmaId, scope] as const;

/**
 * İSG sekmesinin ilk görünümü için gerekli hafif veriyi toplar. Ağır atama/rol
 * motoruna gerek YOKTUR; yalnızca merkezi gereksinim sonucu, mevzuat/geçerlilik
 * haritası ve NACE çözümü yüklenir.
 */
export async function fetchIsgGereksinimPaneliData(row: FirmaData, scope: GereksinimScope) {
  const [gereksinimler, legalMap, nace] = await Promise.all([
    fetchFirmaGereksinimleri(row.id, scope),
    fetchRequirementLegalMap().catch(() => ( {} as RequirementLegalMap)),
    row.naceId ? fetchNaceById(row.naceId).catch(() => null) : Promise.resolve(null),
  ]);
  return { gereksinimler, legalMap, nace };
}

/** Referans kategori kartları (Eğitim / Sağlık / Evrak). */
const KART_DEFS: { key: UstKategori; title: string; icon: string; iconCls: string }[] = [
  { key: 'egitim', title: 'Eğitim Gereksinimleri', icon: 'ri-book-open-line', iconCls: 'bg-accent-100 text-accent-700 dark:bg-accent-500/15 dark:text-accent-400' },
  { key: 'saglik', title: 'Sağlık Gereksinimleri', icon: 'ri-heart-pulse-line', iconCls: 'bg-danger-50 text-danger-600 dark:bg-danger-500/15 dark:text-danger-400' },
  { key: 'evrak', title: 'Evrak ve Belgeler', icon: 'ri-file-list-3-line', iconCls: 'bg-primary-50 text-primary-600 dark:bg-primary-500/15 dark:text-primary-400' },
];

const DURUM_FILTER_OPTIONS = [
  { value: '', label: 'Durum: Tümü' },
  { value: 'tamamlandi', label: 'Tamamlandı' },
  { value: 'yaklasiyor', label: 'Süresi Yaklaşıyor' },
  { value: 'gecmis', label: 'Süresi Geçmiş' },
  { value: 'eksik', label: 'Eksik' },
  { value: 'bekliyor', label: 'Bekliyor' },
  { value: 'yok', label: 'Gereksinim Yok' },
];

const KATEGORI_FILTER_OPTIONS = [
  { value: '', label: 'Kategori: Tümü' },
  { value: 'egitim', label: 'Eğitim' },
  { value: 'saglik', label: 'Sağlık' },
  { value: 'evrak', label: 'Evrak' },
];

const EXPORT_STATUS_RULES = [
  { keyword: 'Tamamlandı', color: '1E7E34', bg: 'D4EDDA' },
  { keyword: 'Süresi Yaklaşıyor', color: '8A6100', bg: 'FFF3CD' },
  { keyword: 'Süresi Geçmiş', color: 'B02A2A', bg: 'F8D7DA' },
  { keyword: 'Eksik', color: 'B02A2A', bg: 'F8D7DA' },
  { keyword: 'Bekliyor', color: '8A6100', bg: 'FFF3CD' },
];

/** Eğitim gereksinimi → egitim_turu eşleşmesi (isg_kurallari.calculation_definition). */
const EGITIM_TURU_BY_CODE: Record<string, string> = {
  TEMEL_ISG_EGITIMI: 'temel_isg',
  YENILEME_EGITIMI: 'isg_yenileme',
  ISE_OZGUN_EGITIM: 'ise_ozgun',
};

export interface IsgGereksinimPaneliProps {
  row: FirmaData;
  scope: GereksinimScope;
  /** Geriye dönük uyumluluk için korunur (bu görünümde kullanılmaz). */
  messagingPath?: string;
  onRecalculated?: () => void;
  /** Modül bağlantısına gidilirken modalı kapatmak için (geriye dönük uyumluluk). */
  onClose?: () => void;
}

/**
 * Firma Detay → İSG Gereksinimleri sekmesi (referans tasarım).
 *
 * Yapı: Gereksinim Durumu özeti (donut + Eğitim/Sağlık/Evrak kategori kartları) →
 * filtre barı (arama · kategori · durum · tehlike sınıfı · Excel'e Aktar) →
 * gereksinim tablosu + sayfalama.
 *
 * Tüm sayı/süre/gereksinim merkezi rule engine + motor sonucundan gelir;
 * frontend'de formül veya hard-code değer YOKTUR.
 */
export default function IsgGereksinimPaneli({ row, scope, onRecalculated }: IsgGereksinimPaneliProps) {
  const { addToast } = useToastActions();
  const getBrandMeta = useExcelBrandMeta();
  const { openModal, closeModal } = useModalActions();
  const yukleModalIdRef = useRef('');
  const eksikModalIdRef = useRef('');

  const [recalculating, setRecalculating] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [reqSearch, setReqSearch] = useState('');
  const [kategoriFilter, setKategoriFilter] = useState('');
  const [durumFilter, setDurumFilter] = useState('');
  const [tehlikeFilter, setTehlikeFilter] = useState('');

  const { data, isInitialLoading: loading, error: loadError, refresh: load } = useTabData(
    ISG_GEREKSINIM_PANELI_KEY(row.id, scope),
    () => fetchIsgGereksinimPaneliData(row, scope),
  );

  const { data: evrakTypeByCode = {} } = useTabData('isg-evrak-type-by-code', async () => {
    const turlar = await fetchEvrakTurleri();
    const map: Record<string, string> = {};
    for (const t of turlar) {
      if (t.ownerType === 'firma' && t.code) map[t.code] = t.id;
    }
    return map;
  });
  const gereksinimler = data?.gereksinimler ?? [];
  const legalMap = data?.legalMap ?? {};
  const nace = data?.nace ?? null;
  const error = loadError ? friendlyGereksinimError(loadError) : null;

  const hazardClass: HazardClass = nace ? nace.tehlike_sinifi : row.tehlikeSinifi;
  const hazardLabel = HAZARD_CLASS_LABEL[hazardClass];
  const hazardVariant: DurumVariant = hazardClass === 'cok_tehlikeli' ? 'danger' : hazardClass === 'tehlikeli' ? 'warning' : 'success';

  const handleRecalculate = useCallback(() => {
    if (recalculating) return;
    setRecalculating(true);
    calculateFirmaRequirements(row.id)
      .then(() => {
        // HESAPLAMA BAŞARILI. Başarı bildirimi ÖNCE gösterilir; ardından UI tazeleme
        // adımları AYRI yürütülür. Bu adımlarda oluşabilecek bir arayüz/senkron hatası
        // artık "hesaplama başarısız" olarak YANSITILMAZ (yanlış hata kök nedeni buydu).
        addToast({ title: 'Gereksinimler hesaplandı', message: 'İSG gereksinimleri yeniden hesaplandı.', type: 'success' });
        try {
          onRecalculated?.();
        } catch (sideErr) {
          logError(sideErr, { componentName: 'IsgGereksinimPaneli', source: 'gereksinim-hesapla:onRecalculated' });
        }
        try {
          load();
        } catch (refreshErr) {
          logError(refreshErr, { componentName: 'IsgGereksinimPaneli', source: 'gereksinim-hesapla:refresh' });
        }
      })
      .catch((e) => {
        // GERÇEK hesaplama hatası: teknik detay UI'ya sızmaz ama console/log'da KORUNUR.
        logError(e, { componentName: 'IsgGereksinimPaneli', source: 'gereksinim-hesapla' });
        addToast({ title: 'Hesaplama başarısız', message: friendlyGereksinimError(e), type: 'error' });
      })
      .finally(() => setRecalculating(false));
  }, [recalculating, row.id, addToast, load, onRecalculated]);

  const autoSyncRanRef = useRef(false);
  useEffect(() => {
    if (!row.isActive || !row.isgGirdiDegisti) return;
    if (autoSyncRanRef.current) return;
    autoSyncRanRef.current = true;
    handleRecalculate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [row.isActive, row.isgGirdiDegisti]);

  // Şema güncellemesi sonrası eski kayıtlar 'reason' alanı taşımaz. Kayıtlar mevcut
  // ama açıklama boşsa MOTOR BİR KEZ tazelenir (yalnızca yönetim kapsamında, tek sefer).
  const reasonBackfillRef = useRef(false);
  useEffect(() => {
    if (scope !== 'osgb' || !row.isActive || loading || recalculating) return;
    if (reasonBackfillRef.current) return;
    if (gereksinimler.length === 0) return;
    if (gereksinimler.some((r) => r.reason)) return;
    reasonBackfillRef.current = true;
    handleRecalculate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, recalculating, gereksinimler, scope, row.isActive]);

  // ── Filtreleme ──
  const filteredRows = useMemo(() => {
    // Varsayılan: firmaya UYGULANMAYAN ("Gerekli Değil") gereksinimler listede GÖSTERİLMEZ.
    // Yalnızca durum filtresinden "Gerekli Değil" seçilirse görünür.
    let rows =
      durumFilter === 'yok'
        ? gereksinimler.filter((r) => durumKeyOf(r) === 'yok')
        : gereksinimler.filter((r) => durumKeyOf(r) !== 'yok');
    if (kategoriFilter) rows = rows.filter((r) => ustKategoriOf(r) === kategoriFilter);
    if (durumFilter && durumFilter !== 'yok') rows = rows.filter((r) => durumKeyOf(r) === durumFilter);
    if (tehlikeFilter && tehlikeFilter !== hazardClass) return [];
    // Arama TEK kaynaktan (matchesSearch) normalize edilir: trim + Türkçe harf + çoklu boşluk.
    if (reqSearch.trim()) {
      rows = rows.filter((r) => matchesSearch(`${r.title} ${r.requirement_code ?? ''}`, reqSearch));
    }
    return rows;
  }, [gereksinimler, kategoriFilter, durumFilter, tehlikeFilter, hazardClass, reqSearch]);

  // ── Durum özeti (donut) + kategori kartları ──
  // ÖNEMLİ: "Gerekli Değil" (not_applicable) EKSİK sayısına DAHİL EDİLMEZ; kendi
  // kovasında raporlanır. Böylece toplam/eksik sayısı yapay olarak şişmez.
  const stats = useMemo(() => {
    const cats: Record<UstKategori, { toplam: number; tamamlandi: number; eksik: number; yaklasan: number }> = {
      egitim: { toplam: 0, tamamlandi: 0, eksik: 0, yaklasan: 0 },
      saglik: { toplam: 0, tamamlandi: 0, eksik: 0, yaklasan: 0 },
      evrak: { toplam: 0, tamamlandi: 0, eksik: 0, yaklasan: 0 },
    };
    let gerekli = 0;
    let tamamlanan = 0;
    let eksik = 0;
    let yaklasan = 0;
    let gecmis = 0;
    let gerekliDegil = 0;
    let bekliyor = 0;
    for (const r of gereksinimler) {
      const k: DurumKey = durumKeyOf(r);
      if (k === 'yok') {
        // Firmaya uygulanmayan gereksinim: listeye ve eksik sayısına DAHİL EDİLMEZ.
        gerekliDegil += 1;
        continue;
      }
      const cat = ustKategoriOf(r);
      gerekli += 1;
      cats[cat].toplam += 1;
      if (k === 'tamamlandi') {
        cats[cat].tamamlandi += 1;
        tamamlanan += 1;
      } else if (k === 'yaklasiyor') {
        cats[cat].yaklasan += 1;
        yaklasan += 1;
      } else if (k === 'bekliyor') {
        bekliyor += 1;
      } else {
        // 'eksik' veya 'gecmis' → karşılanmamış sayılır
        cats[cat].eksik += 1;
        eksik += 1;
        if (k === 'gecmis') gecmis += 1;
      }
    }
    return { toplam: gereksinimler.length, gerekli, tamamlanan, eksik, yaklasan, gecmis, gerekliDegil, bekliyor, opsiyonel: 0, cats };
  }, [gereksinimler]);

  const tehlikeFilterOptions = useMemo(
    () => [
      { value: '', label: 'Tehlike Sınıfı: Tümü' },
      { value: 'az_tehlikeli', label: HAZARD_CLASS_LABEL.az_tehlikeli },
      { value: 'tehlikeli', label: HAZARD_CLASS_LABEL.tehlikeli },
      { value: 'cok_tehlikeli', label: HAZARD_CLASS_LABEL.cok_tehlikeli },
    ],
    [],
  );

  // ── Excel'e Aktar (mevcut global kurumsal Excel motoru) ──
  const handleExport = useCallback(async () => {
    if (exporting) return;
    setExporting(true);
    try {
      const meta = await getBrandMeta({ firmaId: row.id, firmaAdi: row.ad });
      const columns: ExcelColumnDef[] = [
        { header: 'Gereksinim Adı', key: 'ad', width: 42 },
        { header: 'Kategori', key: 'kategori', width: 16 },
        { header: 'Tehlike Sınıfı', key: 'tehlike', width: 16 },
        { header: 'Yasal Süre', key: 'sure', width: 14 },
        { header: 'Son Tamamlama', key: 'sonTamamlama', width: 16 },
        { header: 'Yenileme Tarihi', key: 'yenileme', width: 16 },
        { header: 'Durum', key: 'durum', width: 18 },
      ];
      const rows: ExcelDataRow[] = filteredRows.map((r) => ({
        values: {
          ad: r.title,
          kategori: UST_KATEGORI_LABEL[ustKategoriOf(r)],
          tehlike: hazardLabel,
          sure: yasalSureText(legalMap[r.requirement_code]),
          sonTamamlama: '—',
          yenileme: '—',
          durum: DURUM_VIEW[durumKeyOf(r)].label,
        },
      }));
      await exportBrandedWorkbook(
        {
          sheetName: 'İSG Gereksinimleri',
          title: 'İSG GEREKSİNİMLERİ',
          subtitle: `${row.ad} — firmanın hesaplanan İSG yasal gereksinimleri`,
          meta,
          columns,
          rows,
          statusKey: 'durum',
          statusRules: EXPORT_STATUS_RULES,
          footerNote: 'Gereksinimler merkezi İSG gereksinim motoru tarafından hesaplanmıştır.',
        },
        `isg-gereksinimleri-${row.ad.slice(0, 24).replace(/\s+/g, '-').toLocaleLowerCase('tr')}.xlsx`,
      );
    } catch (e) {
      addToast({ title: 'Excel oluşturulamadı', message: friendlyGereksinimError(e), type: 'error' });
    } finally {
      setExporting(false);
    }
  }, [exporting, getBrandMeta, row.id, row.ad, filteredRows, hazardLabel, legalMap, addToast]);

  const handleYukle = useCallback(
    (r: FirmaGereksinimRow) => {
      const evrakTypeId = evrakTypeByCode[r.requirement_code] ?? '';
      const id = openModal({
        title: `${r.title} — Evrak Yükle`,
        description: row.ad,
        width: 560,
        minWidth: 420,
        minHeight: 480,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: (
          <EvrakUploadModal
            role="uzman"
            initialFirmaId={row.id}
            initialRequirementId={r.id}
            initialDocumentTypeId={evrakTypeId}
            lockOwnerType="firma"
            onClose={() => closeModal(yukleModalIdRef.current)}
            onUploaded={() => load()}
          />
        ),
      });
      yukleModalIdRef.current = id;
    },
    [openModal, closeModal, row.id, row.ad, evrakTypeByCode, load],
  );

  const handleEksik = useCallback(
    (r: FirmaGereksinimRow) => {
      const egitimTuru = EGITIM_TURU_BY_CODE[r.requirement_code] ?? null;
      const personelKaynak = r.requirement_code === 'SAGLIK_GOZETIMI' ? 'saglik_muayenesi' : null;
      const id = openModal({
        title: `${r.title} — Eksik Personeller`,
        description: row.ad,
        width: 560,
        minWidth: 420,
        minHeight: 480,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: (
          <GereksinimEksikPersonelModal
            firmaId={row.id}
            requirementTitle={r.title}
            egitimTuru={egitimTuru}
            personelKaynak={personelKaynak}
            onClose={() => closeModal(eksikModalIdRef.current)}
          />
        ),
      });
      eksikModalIdRef.current = id;
    },
    [openModal, closeModal, row.id, row.ad],
  );

  if (loading) {
    return (
      <div className="flex justify-center py-12">
        <Loading size="lg" text="İSG gereksinimleri yükleniyor..." />
      </div>
    );
  }

  if (error) {
    return <ErrorState message={error} onRetry={load} />;
  }

  const canManage = scope === 'osgb';

  return (
    <div className="space-y-3 min-w-0">
      <div className="isg-section p-4">
        {/* Başlık + yeniden hesapla */}
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
          <div className="flex items-start gap-3 min-w-0">
            <div className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
              <i className="ri-shield-check-line text-base" />
            </div>
            <div className="min-w-0">
              <h4 className="text-sm font-semibold text-foreground-900">Gereksinim Durumu</h4>
              <p className="text-xs text-foreground-500 mt-0.5 leading-snug">Firma için hesaplanan İSG yasal gereksinimleri.</p>
            </div>
          </div>
          {canManage && (
            <Button
              variant="primary"
              size="sm"
              leftIcon={<i className={`ri-refresh-line ${recalculating ? 'animate-spin' : ''}`} />}
              isLoading={recalculating}
              onClick={handleRecalculate}
              className="whitespace-nowrap flex-shrink-0"
            >
              Gereksinimleri Yeniden Hesapla
            </Button>
          )}
        </div>

        {/* Özet: donut + kategori kartları */}
        <div className="grid grid-cols-1 lg:grid-cols-[300px_1fr] gap-3 mb-4">
          <div className="rounded-lg border border-background-300/25 dark:border-background-400/25 p-4 flex flex-col items-center justify-center">
            <DonutChart
              size={120}
              strokeWidth={18}
              total={stats.gerekli || 1}
              centerText={String(stats.gerekli)}
              centerLabel="Gerekli"
              data={[
                { label: 'Tamamlanan', value: stats.tamamlanan, color: 'success' },
                { label: 'Eksik', value: stats.eksik, color: 'danger' },
                { label: 'Süresi Yaklaşan', value: stats.yaklasan, color: 'warning' },
                { label: 'Bekliyor', value: stats.bekliyor, color: 'secondary' },
              ]}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {KART_DEFS.map((def) => {
              const c = stats.cats[def.key];
              return (
                <div key={def.key} className="rounded-lg border border-background-300/25 dark:border-background-400/25 p-3 flex flex-col">
                  <div className="flex items-center gap-2.5 mb-2.5">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${def.iconCls}`}>
                      <i className={`${def.icon} text-base`} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-foreground-800 leading-tight">{def.title}</p>
                      <p className="text-[11px] text-foreground-500 mt-0.5">Toplam {c.toplam}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-auto">
                    <OzStatCount icon="ri-checkbox-circle-line" value={c.tamamlandi} tone="success" />
                    <OzStatCount icon="ri-close-circle-line" value={c.eksik} tone="danger" />
                    <OzStatCount icon="ri-alert-line" value={c.yaklasan} tone="warning" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* KPI özet şeridi (referans tasarım korunur; sayılar merkezi motordan gelir) */}
        <KpiStrip
          gerekli={stats.gerekli}
          tamamlanan={stats.tamamlanan}
          eksik={stats.eksik}
          yaklasan={stats.yaklasan}
          bekliyor={stats.bekliyor}
          gerekliDegil={stats.gerekliDegil}
          opsiyonel={stats.opsiyonel}
        />

        {/* Filtre barı */}
        <div className="flex flex-col gap-3 mb-3 xl:flex-row xl:items-center xl:justify-between">
          <div className="xl:w-72">
            <Input
              placeholder="Gereksinim adı, kategori ara..."
              value={reqSearch}
              onChange={(e) => setReqSearch(e.target.value)}
              leftIcon={<i className="ri-search-line" />}
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:flex xl:items-center gap-2.5">
            <div className="xl:w-44">
              <Select options={KATEGORI_FILTER_OPTIONS} value={kategoriFilter} onChange={(e) => setKategoriFilter(e.target.value)} />
            </div>
            <div className="xl:w-48">
              <Select options={DURUM_FILTER_OPTIONS} value={durumFilter} onChange={(e) => setDurumFilter(e.target.value)} />
            </div>
            <div className="xl:w-52">
              <Select options={tehlikeFilterOptions} value={tehlikeFilter} onChange={(e) => setTehlikeFilter(e.target.value)} />
            </div>
            <Button
              variant="secondary"
              size="sm"
              leftIcon={<i className="ri-file-excel-2-line" />}
              onClick={() => void handleExport()}
              isLoading={exporting}
              disabled={filteredRows.length === 0}
              className="whitespace-nowrap"
            >
              Excel'e Aktar
            </Button>
          </div>
        </div>

        <GereksinimTablosu
          rows={filteredRows}
          legalMap={legalMap}
          hazardLabel={hazardLabel}
          hazardVariant={hazardVariant}
          canManage={canManage}
          emptyDescription={reqSearch || kategoriFilter || durumFilter || tehlikeFilter ? 'Filtreye uygun gereksinim bulunmuyor.' : undefined}
          onYukle={canManage ? handleYukle : undefined}
          onEksik={canManage ? handleEksik : undefined}
        />
      </div>

      {!row.isActive && (
        <div className="isg-section p-4 flex items-center gap-2 text-xs text-foreground-500">
          <i className="ri-pause-circle-line text-warning-500" />
          Bu firma pasif durumda olduğu için gereksinim hesaplanamaz.
        </div>
      )}
    </div>
  );
}

function KpiStrip(props: {
  gerekli: number;
  tamamlanan: number;
  eksik: number;
  yaklasan: number;
  bekliyor: number;
  gerekliDegil: number;
  opsiyonel: number;
}) {
  const items: { label: string; value: number; variant: DurumVariant }[] = [
    { label: 'Gerekli', value: props.gerekli, variant: 'info' },
    { label: 'Tamamlanan', value: props.tamamlanan, variant: 'success' },
    { label: 'Eksik', value: props.eksik, variant: 'danger' },
    { label: 'Süresi Yaklaşan', value: props.yaklasan, variant: 'warning' },
    { label: 'Bekliyor', value: props.bekliyor, variant: 'warning' },
    { label: 'Gerekli Değil', value: props.gerekliDegil, variant: 'default' },
    { label: 'Opsiyonel', value: props.opsiyonel, variant: 'default' },
  ];
  const tone: Record<DurumVariant, string> = {
    success: 'bg-success-50 text-success-700 dark:bg-success-500/10 dark:text-success-300',
    danger: 'bg-danger-50 text-danger-700 dark:bg-danger-500/10 dark:text-danger-300',
    warning: 'bg-warning-50 text-warning-700 dark:bg-warning-500/10 dark:text-warning-300',
    info: 'bg-primary-50 text-primary-700 dark:bg-primary-500/10 dark:text-primary-300',
    default: 'bg-background-200 text-foreground-700 dark:bg-background-300/40 dark:text-foreground-300',
  };
  return (
    <div className="flex flex-wrap items-center gap-2 mb-4">
      {items.map((it) => (
        <span
          key={it.label}
          className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs font-semibold ${tone[it.variant]}`}
        >
          <span className="text-foreground-500 font-normal">{it.label}</span>
          <span className="tabular-nums">{it.value}</span>
        </span>
      ))}
    </div>
  );
}

function OzStatCount({ icon, value, tone }: { icon: string; value: number; tone: 'success' | 'danger' | 'warning' }) {
  const cls =
    tone === 'success'
      ? 'bg-success-50 text-success-700 dark:bg-success-500/10 dark:text-success-300'
      : tone === 'danger'
        ? 'bg-danger-50 text-danger-700 dark:bg-danger-500/10 dark:text-danger-300'
        : 'bg-warning-50 text-warning-700 dark:bg-warning-500/10 dark:text-warning-300';
  return (
    <span className={`inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-semibold ${cls}`}>
      <i className={icon} />
      <span className="tabular-nums">{value}</span>
    </span>
  );
}