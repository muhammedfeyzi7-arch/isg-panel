import { useState, useMemo, useEffect, Fragment } from 'react';
import { formatIstanbulDate } from '@/lib/dateFormat';
import Badge from '@/components/ui/Badge';
import ContextMenu from '@/components/ui/ContextMenu';
import type { ContextMenuItem } from '@/components/ui/ContextMenu';
import type { FirmaGereksinimRow } from '@/lib/gereksinimService';
import { professionalTypeLabel } from '@/lib/gereksinimService';
import type { RequirementLegalMap } from '@/lib/mevzuat';
import {
  DURUM_VIEW,
  durumKeyOf,
  UST_KATEGORI_LABEL,
  ustKategoriOf,
  yasalSureText,
  type DurumVariant,
} from './gereksinimKategorileri';

const ICON_TONE: Record<DurumVariant, string> = {
  success: 'text-success-600 bg-success-50 dark:bg-success-500/15 dark:text-success-400',
  danger: 'text-danger-600 bg-danger-50 dark:bg-danger-500/15 dark:text-danger-400',
  warning: 'text-warning-600 bg-warning-50 dark:bg-warning-500/15 dark:text-warning-400',
  info: 'text-primary-600 bg-primary-50 dark:bg-primary-500/15 dark:text-primary-400',
  default: 'text-foreground-500 bg-background-200 dark:bg-background-300/40',
};

function formatDate(value: string | null | undefined): string {
  return formatIstanbulDate(value);
}

/** Sayfalama için sıkıştırılmış sayfa numarası listesi (ilk/son + aktif çevresi). */
function pageList(current: number, totalPages: number): (number | '...')[] {
  if (totalPages <= 7) return Array.from({ length: totalPages }, (_, i) => i + 1);
  const pages: (number | '...')[] = [1];
  const start = Math.max(2, current - 1);
  const end = Math.min(totalPages - 1, current + 1);
  if (start > 2) pages.push('...');
  for (let p = start; p <= end; p += 1) pages.push(p);
  if (end < totalPages - 1) pages.push('...');
  pages.push(totalPages);
  return pages;
}

export interface GereksinimTablosuProps {
  rows: FirmaGereksinimRow[];
  /** requirement_code → mevzuat/açıklama/geçerlilik haritası (Yasal Süre + Açıklama). */
  legalMap?: RequirementLegalMap;
  /** Firmanın tehlike sınıfı etiketi (Tehlike Sınıfı kolonu). */
  hazardLabel: string;
  /** Tehlike sınıfı rozet varyantı. */
  hazardVariant?: DurumVariant;
  /** Evrak yükleme / eksik personel aksiyonlarının gösterilip gösterilmeyeceği. */
  canManage?: boolean;
  /** Boş durumda gösterilecek açıklama. */
  emptyDescription?: string;
  onYukle?: (r: FirmaGereksinimRow) => void;
  onEksik?: (r: FirmaGereksinimRow) => void;
}

/**
 * Firma Detay → İSG Gereksinimleri tablosu (referans tasarım).
 *
 * Kolonlar: Gereksinim Adı | Kategori | Tehlike Sınıfı | Yasal Süre |
 *           Son Tamamlama | Yenileme Tarihi | Durum | İşlem  + sayfalama
 *
 * Tüm değerler merkezi motorun persist edilmiş sonucundan (`firma_gereksinimleri`)
 * ve mevzuat/geçerlilik haritasından gelir; burada formül/oran ÜRETİLMEZ.
 * Son Tamamlama / Yenileme Tarihi merkezi motorda tarih olarak tutulmadığından
 * şimdilik '—' gösterilir; veri modeli güncellendiğinde bu kolonlar dolacaktır.
 */
export default function GereksinimTablosu({
  rows,
  legalMap,
  hazardLabel,
  hazardVariant = 'warning',
  canManage = false,
  emptyDescription,
  onYukle,
  onEksik,
}: GereksinimTablosuProps) {
  const [openId, setOpenId] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 10;

  const total = rows.length;
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  // Filtre/arama değişince geçersiz sayfada kalmamak için sayfa sınırlanır.
  useEffect(() => {
    if (page > totalPages) setPage(1);
  }, [totalPages, page]);

  const pageRows = useMemo(
    () => rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    [rows, page],
  );

  if (total === 0) {
    return (
      <div className="rounded-lg border border-background-300/30 dark:border-background-400/25 px-4 py-8 text-center">
        <i className="ri-list-unordered text-2xl text-foreground-400" />
        <p className="mt-2 text-sm text-foreground-500">
          {emptyDescription ?? 'Bu firma için hesaplanmış gereksinim bulunmuyor.'}
        </p>
      </div>
    );
  }

  const startIdx = (page - 1) * PAGE_SIZE;
  const endIdx = Math.min(startIdx + PAGE_SIZE, total);

  return (
    <div className="space-y-3">
      <div className="overflow-x-auto -mx-1 px-1">
        <table className="w-full min-w-[1050px] border-collapse isg-mobile-cards">
          <thead>
            <tr className="border-b border-background-300/40 dark:border-background-400/30">
              <th scope="col" className="text-left py-2.5 px-2 text-[11px] font-semibold text-foreground-500 uppercase tracking-wide min-w-[220px]">Gereksinim Adı</th>
              <th scope="col" className="text-left py-2.5 px-2 text-[11px] font-semibold text-foreground-500 uppercase tracking-wide w-[120px]">Kategori</th>
              <th scope="col" className="text-left py-2.5 px-2 text-[11px] font-semibold text-foreground-500 uppercase tracking-wide w-[130px]">Tehlike Sınıfı</th>
              <th scope="col" className="text-left py-2.5 px-2 text-[11px] font-semibold text-foreground-500 uppercase tracking-wide w-[120px]">Yasal Süre</th>
              <th scope="col" className="text-left py-2.5 px-2 text-[11px] font-semibold text-foreground-500 uppercase tracking-wide w-[130px]">Son Tamamlama</th>
              <th scope="col" className="text-left py-2.5 px-2 text-[11px] font-semibold text-foreground-500 uppercase tracking-wide w-[130px]">Yenileme Tarihi</th>
              <th scope="col" className="text-left py-2.5 px-2 text-[11px] font-semibold text-foreground-500 uppercase tracking-wide w-[140px]">Durum</th>
              <th scope="col" className="text-right py-2.5 px-2 text-[11px] font-semibold text-foreground-500 uppercase tracking-wide w-[120px]">İşlem</th>
            </tr>
          </thead>
          <tbody>
            {pageRows.map((r) => {
              const dk = durumKeyOf(r);
              const dv = DURUM_VIEW[dk];
              const isOpen = openId === r.id;
              const kategori = UST_KATEGORI_LABEL[ustKategoriOf(r)];
              const legal = legalMap?.[r.requirement_code] ?? null;
              const sure = yasalSureText(legal);
              const aciklama = legal?.description ?? null;

              const menuItems: ContextMenuItem[] = [];
              menuItems.push({ label: isOpen ? 'Detayı Kapat' : 'Detay', icon: 'ri-eye-line', onClick: () => setOpenId((cur) => (cur === r.id ? null : r.id)) });
              if (canManage && onYukle) menuItems.push({ label: 'Evrak Yükle', icon: 'ri-upload-2-line', onClick: () => onYukle(r) });
              if (canManage && onEksik) menuItems.push({ label: 'Eksik Personeller', icon: 'ri-user-search-line', onClick: () => onEksik(r) });

              return (
                <Fragment key={r.id}>
                  <tr className="border-b border-background-300/20 dark:border-background-400/20 align-middle">
                    <td className="py-2.5 px-2" data-card="title">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <span className={`w-7 h-7 rounded-md flex items-center justify-center flex-shrink-0 ${ICON_TONE[dv.variant]}`}>
                          <i className={`${dv.icon} text-sm`} />
                        </span>
                        <span className="min-w-0">
                          <span className="block text-sm font-medium text-foreground-800 truncate">{r.title}</span>
                          {r.professional_type && (
                            <span className="block text-[11px] text-foreground-500 mt-0.5">{professionalTypeLabel(r.professional_type)}</span>
                          )}
                        </span>
                      </div>
                    </td>
                    <td className="py-2.5 px-2" data-label="Kategori">
                      <span className="text-xs text-foreground-600">{kategori}</span>
                    </td>
                    <td className="py-2.5 px-2" data-label="Tehlike Sınıfı">
                      <Badge variant={hazardVariant}>{hazardLabel}</Badge>
                    </td>
                    <td className="py-2.5 px-2 text-xs text-foreground-600 whitespace-nowrap" data-label="Yasal Süre">{sure}</td>
                    <td className="py-2.5 px-2 text-xs text-foreground-600 whitespace-nowrap" data-label="Son Tamamlama">—</td>
                    <td className="py-2.5 px-2 text-xs text-foreground-600 whitespace-nowrap" data-label="Yenileme Tarihi">—</td>
                    <td className="py-2.5 px-2" data-label="Durum">
                      <Badge variant={dv.variant}>{dv.label}</Badge>
                    </td>
                    <td className="py-2.5 px-2" data-card="actions">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => setOpenId((cur) => (cur === r.id ? null : r.id))}
                          className="px-2.5 py-1 text-xs font-semibold text-primary-600 hover:text-primary-700 hover:bg-primary-50 dark:hover:bg-primary-500/10 rounded-md transition-colors cursor-pointer whitespace-nowrap"
                        >
                          Detay
                        </button>
                        <ContextMenu items={menuItems} />
                      </div>
                    </td>
                  </tr>
                  {isOpen && (
                    <tr className="border-b border-background-300/20 dark:border-background-400/20">
                      <td colSpan={8} className="p-0">
                        <div className="px-4 pb-3 pt-1 bg-background-100/50 dark:bg-background-300/10">
                          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 pt-2">
                            <DetailStat label="Gerekli" value={r.required_quantity == null ? '—' : String(r.required_quantity)} />
                            <DetailStat label="Mevcut" value={r.current_quantity == null ? '—' : String(r.current_quantity)} />
                            <DetailStat label="Eksik" value={r.remaining_quantity == null ? '—' : String(r.remaining_quantity)} />
                            <DetailStat label="Yasal Süre" value={sure} />
                          </div>
                          {r.reason && (
                            <div className="mt-2.5 flex items-start gap-2 rounded-md bg-primary-50/60 dark:bg-primary-500/10 border border-primary-200/40 dark:border-primary-500/20 px-2.5 py-2">
                              <i className="ri-information-line text-primary-600 dark:text-primary-400 text-sm mt-0.5 flex-shrink-0" />
                              <p className="text-xs text-foreground-700 leading-snug">{r.reason}</p>
                            </div>
                          )}
                          {aciklama && (
                            <p className="mt-2.5 text-xs text-foreground-600 leading-snug">{aciklama}</p>
                          )}
                          <div className="mt-2.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-foreground-500">
                            {r.kalan_gun != null && (
                              <span>
                                Kalan gün: <span className="font-medium text-foreground-700">{r.kalan_gun} gün</span>
                              </span>
                            )}
                            <span>
                              Son hesaplama: <span className="font-medium text-foreground-700">{formatDate(r.calculated_at)}</span>
                            </span>
                            {legal?.sourceTitle && (
                              <a
                                href={legal.url ?? '#'}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-flex items-center gap-1 text-primary-600 hover:text-primary-700 font-medium cursor-pointer"
                              >
                                <i className="ri-external-link-line" />
                                {legal.sourceTitle}
                                {legal.article ? ` \u00b7 ${legal.article}` : ''}
                              </a>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Sayfalama */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t isg-divider">
        <span className="text-xs text-foreground-500 tabular-nums">{startIdx + 1}-{endIdx} / {total} kayıt</span>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page <= 1}
            aria-label="Önceki sayfa"
            className="w-7 h-7 rounded-md flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            <i className="ri-arrow-left-s-line" />
          </button>
          {pageList(page, totalPages).map((p, i) => (
            p === '...' ? (
              <span key={`e-${i}`} className="px-1.5 text-xs text-foreground-400">…</span>
            ) : (
              <button
                key={p}
                type="button"
                onClick={() => setPage(p)}
                className={`min-w-[28px] h-7 px-2 rounded-md text-xs font-semibold tabular-nums transition-colors cursor-pointer ${
                  p === page
                    ? 'bg-primary-500 text-inverse'
                    : 'text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40'
                }`}
              >
                {p}
              </button>
            )
          ))}
          <button
            type="button"
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            aria-label="Sonraki sayfa"
            className="w-7 h-7 rounded-md flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            <i className="ri-arrow-right-s-line" />
          </button>
        </div>
        <div className="flex items-center gap-2 text-xs text-foreground-500">
          <span>Sayfa başına:</span>
          <span className="font-semibold text-foreground-800 tabular-nums">{PAGE_SIZE}</span>
        </div>
      </div>
    </div>
  );
}

function DetailStat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md bg-background-50 dark:bg-background-200/40 border border-background-300/30 dark:border-background-400/25 px-2.5 py-1.5">
      <span className="block text-[10px] text-foreground-500 uppercase tracking-wide">{label}</span>
      <span className="block text-sm font-semibold text-foreground-900 tabular-nums mt-0.5">{value}</span>
    </div>
  );
}