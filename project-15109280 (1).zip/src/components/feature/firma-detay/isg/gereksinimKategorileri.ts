import type { FirmaGereksinimRow } from '@/lib/gereksinimService';

/** Kategori ikon kutusu renk eşlemesi (yalnızca semantik token'lar). */
export type KategoriTint = 'primary' | 'accent' | 'danger' | 'warning' | 'secondary';

export interface KategoriDef {
  key: string;
  title: string;
  desc: string;
  icon: string;
  tint: KategoriTint;
  /** Bu kategoriye ait requirement kodları (profesyonel kategori için kullanılmaz). */
  codes: string[];
  /** İSG Profesyonelleri kategorisi (professional_type != null satırları). */
  professional?: boolean;
  /** Kalan tüm kodları yakalayan varsayılan kategori. */
  catchAll?: boolean;
}

/**
 * Firma Detay → İSG Gereksinimleri kategori listesi (referans tasarım).
 * Sabit mevzuat/formül İÇERMEZ; yalnızca mevcut requirement kodlarının
 * görsel gruplamasıdır. Tüm gerekli/mevcut/eksik değerleri merkezi motordan gelir.
 */
export const GEREKSINIM_KATEGORILERI: KategoriDef[] = [
  {
    key: 'prof',
    title: 'İSG Profesyonelleri',
    desc: 'İş Güvenliği Uzmanı, İşyeri Hekimi ve Diğer Sağlık Personeli (DSP) gereksinimleri',
    icon: 'ri-shield-user-line',
    tint: 'primary',
    professional: true,
    codes: [],
  },
  {
    key: 'egitim',
    title: 'Eğitimler',
    desc: 'Çalışanlara verilmesi gereken zorunlu eğitimler',
    icon: 'ri-book-open-line',
    tint: 'accent',
    codes: [
      'TEMEL_ISG_EGITIMI',
      'YENILEME_EGITIMI',
      'ISE_OZGUN_EGITIM',
      'ISE_BASLAMA_EGITIMI',
      'BILGI_YENILEME',
      'MESLEKI_EGITIM',
      'YILLIK_EGITIM_PLANI',
    ],
  },
  {
    key: 'saglik',
    title: 'Sağlık Gözetimi',
    desc: 'Periyodik sağlık muayeneleri ve işe giriş/çıkış muayeneleri',
    icon: 'ri-heart-pulse-line',
    tint: 'danger',
    codes: ['SAGLIK_GOZETIMI'],
  },
  {
    key: 'acil',
    title: 'Acil Durum',
    desc: 'Acil durum planı, ekipler, tatbikat ve donanım gereksinimleri',
    icon: 'ri-alarm-warning-line',
    tint: 'warning',
    codes: [
      'ACIL_DURUM_PLANI',
      'ACIL_DURUM_TATBIKATI',
      'ACIL_SONDURME_EKIBI',
      'ACIL_KURTARMA_EKIBI',
      'ACIL_KORUMA_EKIBI',
      'ILKYARDIMCI',
    ],
  },
  {
    key: 'risk',
    title: 'Risk Değerlendirmesi',
    desc: 'Risk değerlendirmesi, gözden geçirme ve güncelleme gereksinimleri',
    icon: 'ri-shield-star-line',
    tint: 'primary',
    codes: [
      'RISK_DEGERLENDIRME',
      'KIMYASAL_RISK_DEGERLENDIRME',
      'KANSEROJEN_MARUZIYET_KONTROL',
      'PATLAMADAN_KORUNMA_DOKUMANI',
      'YUKSEKTE_CALISMA_KORUMA',
    ],
  },
  {
    key: 'kurul',
    title: 'İSG Kurulu',
    desc: 'İSG kurulu oluşturma ve toplantı gereksinimleri',
    icon: 'ri-group-line',
    tint: 'accent',
    codes: ['ISG_KURULU'],
  },
  {
    key: 'temsilci',
    title: 'Çalışan Temsilcisi',
    desc: 'Çalışan temsilcisi seçim gereksinimleri',
    icon: 'ri-user-voice-line',
    tint: 'secondary',
    codes: ['CALISAN_TEMSILCISI'],
  },
  {
    key: 'diger',
    title: 'Diğer Gereksinimler',
    desc: 'Mevzuatta yer alan diğer yükümlülükler',
    icon: 'ri-folder-2-line',
    tint: 'secondary',
    catchAll: true,
    codes: [],
  },
];

const CODE_TO_KATEGORI = new Map<string, string>();
for (const k of GEREKSINIM_KATEGORILERI) {
  if (k.professional || k.catchAll) continue;
  for (const c of k.codes) CODE_TO_KATEGORI.set(c, k.key);
}

/** Bir requirement satırının kategori anahtarını döner. */
export function kategoriKeyOf(r: Pick<FirmaGereksinimRow, 'requirement_code' | 'professional_type'>): string {
  if (r.professional_type) return 'prof';
  return CODE_TO_KATEGORI.get(r.requirement_code) ?? 'diger';
}

// ─────────────────────────────────────────────────────────────────────────────
// ÜST KATEGORİ (referans: Eğitim / Sağlık / Evrak)
// Belgedeki kategori kartları ve tablodaki "Kategori" kolonu bu 3'lü ayrımı kullanır.
// Ayrım, mevcut kategori gruplamasından türetilir; yeni bir veri motoru kurulmaz.
// ─────────────────────────────────────────────────────────────────────────────
export type UstKategori = 'egitim' | 'saglik' | 'evrak';

export const UST_KATEGORI_LABEL: Record<UstKategori, string> = {
  egitim: 'Eğitim',
  saglik: 'Sağlık',
  evrak: 'Evrak',
};

export function ustKategoriOf(r: Pick<FirmaGereksinimRow, 'requirement_code' | 'professional_type'>): UstKategori {
  const k = kategoriKeyOf(r);
  if (k === 'egitim') return 'egitim';
  if (k === 'saglik') return 'saglik';
  return 'evrak';
}

// ─────────────────────────────────────────────────────────────────────────────
// DURUM GÖRÜNÜMÜ (referans durum etiketleri)
// Durum KURALI burada üretilmez; merkezi motorun `status` + `gecerlilik_durumu`
// çıktısı birebir etikete çevrilir (Tamamlandı / Süresi Yaklaşıyor / Süresi Geçmiş / Eksik).
// ─────────────────────────────────────────────────────────────────────────────
export type DurumVariant = 'success' | 'warning' | 'danger' | 'default' | 'info';
export type DurumKey = 'tamamlandi' | 'yaklasiyor' | 'gecmis' | 'eksik' | 'bekliyor' | 'yok';

export const DURUM_VIEW: Record<DurumKey, { label: string; variant: DurumVariant; icon: string }> = {
  tamamlandi: { label: 'Tamamlandı', variant: 'success', icon: 'ri-checkbox-circle-line' },
  yaklasiyor: { label: 'Süresi Yaklaşıyor', variant: 'warning', icon: 'ri-time-line' },
  gecmis: { label: 'Süresi Geçmiş', variant: 'danger', icon: 'ri-error-warning-line' },
  eksik: { label: 'Eksik', variant: 'danger', icon: 'ri-close-circle-line' },
  bekliyor: { label: 'Bekliyor', variant: 'warning', icon: 'ri-time-line' },
  yok: { label: 'Gereksinim Yok', variant: 'default', icon: 'ri-subtract-line' },
};

export function durumKeyOf(r: Pick<FirmaGereksinimRow, 'status' | 'gecerlilik_durumu'>): DurumKey {
  if (r.status === 'not_applicable') return 'yok';
  if (r.status === 'verification_required') return 'bekliyor';
  if (r.status === 'missing' || r.status === 'critical') return 'eksik';
  if (r.gecerlilik_durumu === 'expiring') return 'yaklasiyor';
  if (r.gecerlilik_durumu === 'expired') return 'gecmis';
  return 'tamamlandi';
}

/** "Yasal Süre" kolonu: kuralın validity_duration/unit değerini okunur metne çevirir. */
export function yasalSureText(
  ref: { validityDuration?: number | null; validityUnit?: string | null } | null | undefined,
): string {
  if (!ref || ref.validityDuration == null || !ref.validityUnit) return '—';
  const d = ref.validityDuration;
  switch (ref.validityUnit) {
    case 'year':
      return `Yılda ${d}`;
    case 'month':
      return `Ayda ${d}`;
    case 'day':
      return `${d} günde bir`;
    default:
      return `${d} ${ref.validityUnit}`;
  }
}