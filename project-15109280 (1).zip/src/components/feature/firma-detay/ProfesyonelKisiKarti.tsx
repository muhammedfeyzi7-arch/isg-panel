import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import { formatFirmaDate } from '@/pages/osgb/firmalar/components/firmaUi';

type BadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'secondary' | 'accent';

interface ProfesyonelKisiKartiProps {
  adSoyad: string;
  rolLabel: string;
  uzmanlikSinifi?: string | null;
  atamaTarihi?: string | null;
  aylikHizmet?: string | null;
  durumLabel: string;
  durumVariant: BadgeVariant;
  /** Kartın sahibi oturumdaki kullanıcı ise "Ben" rozeti gösterilir. */
  isBen?: boolean;
  onMesajAt?: (() => void) | null;
  onKisiDetay?: (() => void) | null;
  extraActions?: ReactNode;
}

/**
 * Atanmış İSG profesyoneli (İş Güvenliği Uzmanı / İşyeri Hekimi / DSP) için ortak kişi kartı.
 * Tüm rollerde aynı kart kullanılır; aksiyonlar (mesaj / kişi detayı / atama işlemleri)
 * üst bileşen tarafından rol bazlı olarak verilir.
 */
export default function ProfesyonelKisiKarti({
  adSoyad,
  rolLabel,
  uzmanlikSinifi,
  atamaTarihi,
  aylikHizmet,
  durumLabel,
  durumVariant,
  isBen = false,
  onMesajAt,
  onKisiDetay,
  extraActions,
}: ProfesyonelKisiKartiProps) {
  return (
    <div className="flex flex-col gap-3 p-3 isg-section">
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-full bg-background-200 dark:bg-background-300/50 flex items-center justify-center flex-shrink-0">
          <i className="ri-user-line text-foreground-500 text-base" />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2 flex-wrap">
            <p className="text-sm font-semibold text-foreground-900 truncate">{adSoyad || '—'}</p>
            {isBen && <Badge variant="info">Ben</Badge>}
          </div>
          <p className="text-xs text-foreground-500 mt-0.5">{rolLabel}</p>
          <div className="flex flex-wrap items-center gap-1.5 mt-1.5">
            {uzmanlikSinifi && <Badge variant="secondary">{uzmanlikSinifi} Sınıfı</Badge>}
            <Badge variant={durumVariant}>{durumLabel}</Badge>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 pl-1">
        <div>
          <span className="text-[11px] text-foreground-400 block">Atama Tarihi</span>
          <span className="text-xs font-medium text-foreground-800">{atamaTarihi ? formatFirmaDate(atamaTarihi) : '—'}</span>
        </div>
        <div>
          <span className="text-[11px] text-foreground-400 block">Aylık Hizmet</span>
          <span className="text-xs font-medium text-foreground-800">{aylikHizmet || '—'}</span>
        </div>
      </div>

      {(onMesajAt || onKisiDetay || extraActions) && (
        <div className="flex flex-wrap items-center gap-2 pt-1">
          {onKisiDetay && (
            <button
              type="button"
              onClick={onKisiDetay}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-foreground-700 bg-background-100 dark:bg-background-300/40 border border-background-300/30 dark:border-background-400/30 rounded-md hover:bg-background-200 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-user-line" /> Kişi Detayı
            </button>
          )}
          {onMesajAt && (
            <button
              type="button"
              onClick={onMesajAt}
              className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-primary-700 bg-primary-50 dark:bg-primary-500/10 border border-primary-200/60 dark:border-primary-400/30 rounded-md hover:bg-primary-100 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-chat-3-line" /> Mesaj At
            </button>
          )}
          {extraActions}
        </div>
      )}
    </div>
  );
}