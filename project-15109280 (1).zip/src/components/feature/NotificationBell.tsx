import { useState, useRef, useEffect, useCallback, useMemo, lazy, Suspense } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useClickOutside } from '@/hooks/useDropdown';
import { useBottomSheet } from '@/hooks/useBottomSheet';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { useModalActions } from '@/hooks/useModal';
import { Z_LAYERS } from '@/utils/layers';
import ModalFallback from '@/components/ui/ModalFallback';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import { runWhenIdle } from '@/lib/idleScheduler';
import { coalesce } from '@/lib/requestCoalescer';
import {
  fetchNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  type SupportNotification,
} from '@/lib/supportService';
import {
  fetchZimmetNotifications,
  markZimmetNotificationRead,
  markAllZimmetNotificationsRead,
  type ZimmetNotification,
} from '@/lib/zimmetService';
import {
  fetchOperasyonNotifications,
  markOperasyonNotificationRead,
  markAllOperasyonNotificationsRead,
  type OperasyonNotification,
} from '@/lib/operasyonService';
import {
  fetchMesajlasmaNotifications,
  markMesajlasmaNotificationRead,
  markAllMesajlasmaNotificationsRead,
  type MesajlasmaNotification,
} from '@/lib/mesajlasmaService';
import {
  fetchUygunsuzlukNotifications,
  markUygunsuzlukNotificationRead,
  markAllUygunsuzlukNotificationsRead,
  type UygunsuzlukNotification,
} from '@/lib/sahaDenetimService';
import { getPanelFromPath, PANEL_NAV_CONFIG } from '@/components/feature/panelNavigation';
import { classifyPriority, PRIORITY_META, type BildirimModul, type BildirimPriority } from '@/lib/bildirim';
import { setPendingConversationId } from '@/lib/messagingTarget';
import {
  fetchZiyaretNotifications,
  markZiyaretNotificationRead,
  markAllZiyaretNotificationsRead,
  type ZiyaretNotification,
} from '@/lib/ziyaretBildirimService';
// Ağır detay modalları YALNIZCA zil menüsünden bir bildirime tıklanınca açılır.
// Bu yüzden tembel (lazy) yüklenirler; her panelin ilk açılışında bundle'a
// dahil olmazlar. Böylece üst çubuk + panel açılışı belirgin şekilde hafifler.
const AnnouncementReaderModal = lazy(() => import('@/components/feature/announcement/AnnouncementReaderModal'));
const ZimmetDetailModal = lazy(() => import('@/components/feature/zimmet/ZimmetDetailModal'));
const OperasyonDetailModal = lazy(() => import('@/components/feature/operasyon/OperasyonDetailModal'));
const UygunsuzlukDetailModal = lazy(() => import('@/pages/uzman/saha-denetimleri/components/UygunsuzlukDetailModal'));
const FirmaUygunsuzlukDetailModal = lazy(() => import('@/pages/firma/saha-denetimleri/components/FirmaUygunsuzlukDetailModal'));
const ZiyaretDetayModal = lazy(() => import('@/components/feature/ziyaretler/ZiyaretDetayModal'));



interface Notification {
  id: string;
  kind: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'info' | 'warning' | 'success' | 'error';
  ticketId: string | null;
  announcementId: string | null;
  zimmetId: string | null;
  operasyonEntityType: string | null;
  operasyonEntityId: string | null;
  conversationId: string | null;
  uygunsuzlukId: string | null;
  ziyaretId: string | null;
  createdAt: string;
}

const typeIcons = {
  info: 'ri-information-line text-primary-500',
  warning: 'ri-alert-line text-warning-600',
  success: 'ri-checkbox-circle-line text-success-600',
  error: 'ri-error-warning-line text-danger-600',
};

function notificationTitle(type: string): string {
  switch (type) {
    case 'ticket_created': return 'Yeni destek talebi';
    case 'message': return 'Yeni mesaj';
    case 'status_changed': return 'Destek talebi güncellendi';
    case 'ticket_closed': return 'Destek talebi kapatıldı';
    case 'announcement': return 'Duyuru';
    default: return 'Bildirim';
  }
}

function notificationIconType(type: string): 'info' | 'warning' | 'success' | 'error' {
  switch (type) {
    case 'ticket_created': return 'warning';
    case 'message': return 'info';
    case 'status_changed': return 'info';
    case 'ticket_closed': return 'success';
    case 'announcement': return 'info';
    default: return 'info';
  }
}

function zimmetTitle(type: string): string {
  switch (type) {
    case 'zimmet_atandi': return 'Yeni zimmet atandı';
    case 'zimmet_onaylandi': return 'Zimmet onaylandı';
    case 'zimmet_reddedildi': return 'Zimmet reddedildi';
    case 'zimmet_iade_talebi': return 'İade talebi başlatıldı';
    case 'zimmet_iade_gonderildi': return 'İade gönderildi';
    case 'zimmet_iade_kapatildi': return 'Zimmet kapatıldı';
    case 'zimmet_dusuruldu': return 'Zimmet düşürüldü';
    default: return 'Zimmet bildirimi';
  }
}

function isOperasyonKind(kind: string): boolean {
  return ['kaza_olusturuldu', 'ariza_olusturuldu', 'ariza_durum_guncellendi', 'operasyon_cevap', 'bakim_tarihi_geldi'].includes(kind);
}

/** ZV-02 — Ziyaret / izin-gün değişikliği talep bildirim türleri. */
function isZiyaretKind(kind: string): boolean {
  return kind.startsWith('izin_talebi_');
}

/** Bildirimden ortak modülü türetir (öncelik sınıflandırması için). */
function bellModul(n: Notification): BildirimModul {
  if (n.kind === 'announcement') return 'duyuru';
  if (n.kind.startsWith('zimmet')) return 'zimmet';
  if (isOperasyonKind(n.kind)) return 'operasyon';
  if (isZiyaretKind(n.kind)) return 'ziyaret';
  if (n.kind === 'yeni_mesaj') return 'mesajlasma';
  if (n.uygunsuzlukId) return 'uygunsuzluk';
  return 'destek';
}

function bellPriority(n: Notification): BildirimPriority {
  return classifyPriority(bellModul(n), n.kind);
}

function ziyaretTitle(type: string): string {
  switch (type) {
    case 'izin_talebi_olusturuldu': return 'Yeni izin talebi';
    case 'izin_talebi_onaylandi': return 'İzin talebi onaylandı';
    case 'izin_talebi_reddedildi': return 'İzin talebi reddedildi';
    case 'izin_talebi_geri_cekildi': return 'İzin talebi geri çekildi';
    default: return 'Ziyaret bildirimi';
  }
}

function ziyaretIconType(type: string): 'info' | 'warning' | 'success' | 'error' {
  switch (type) {
    case 'izin_talebi_olusturuldu': return 'warning';
    case 'izin_talebi_onaylandi': return 'success';
    case 'izin_talebi_reddedildi': return 'error';
    case 'izin_talebi_geri_cekildi': return 'info';
    default: return 'info';
  }
}

function mapZiyaretNotification(n: ZiyaretNotification): Notification {
  return {
    id: n.id,
    kind: n.type,
    title: ziyaretTitle(n.type),
    message: n.message,
    time: relativeTime(n.createdAt),
    read: n.read,
    type: ziyaretIconType(n.type),
    ticketId: null,
    announcementId: null,
    zimmetId: null,
    operasyonEntityType: null,
    operasyonEntityId: null,
    conversationId: null,
    uygunsuzlukId: null,
    ziyaretId: n.ziyaretId,
    createdAt: n.createdAt,
  };
}

function operasyonTitle(type: string): string {
  switch (type) {
    case 'kaza_olusturuldu': return 'Yeni kaza kaydı';
    case 'ariza_olusturuldu': return 'Yeni arıza talebi';
    case 'ariza_durum_guncellendi': return 'Arıza durumu güncellendi';
    case 'operasyon_cevap': return 'Yeni yanıt';
    case 'bakim_tarihi_geldi': return 'Bakım tarihi geldi';
    default: return 'Operasyon bildirimi';
  }
}

function relativeTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  const diff = Date.now() - d.getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return 'Şimdi';
  if (min < 60) return `${min} dk önce`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h} saat önce`;
  const days = Math.floor(h / 24);
  return `${days} gün önce`;
}

function mapNotification(n: SupportNotification): Notification {
  return {
    id: n.id,
    kind: n.type,
    title: notificationTitle(n.type),
    message: n.message,
    time: relativeTime(n.createdAt),
    read: n.read,
    type: notificationIconType(n.type),
    ticketId: n.ticketId,
    announcementId: n.announcementId,
    zimmetId: null,
    operasyonEntityType: null,
    operasyonEntityId: null,
    conversationId: null,
    uygunsuzlukId: null,
    ziyaretId: null,
    createdAt: n.createdAt,
  };
}

function mapZimmetNotification(n: ZimmetNotification): Notification {
  return {
    id: n.id,
    kind: n.type,
    title: zimmetTitle(n.type),
    message: n.message,
    time: relativeTime(n.createdAt),
    read: n.read,
    type: 'info',
    ticketId: null,
    announcementId: null,
    zimmetId: n.zimmetId,
    operasyonEntityType: null,
    operasyonEntityId: null,
    conversationId: null,
    uygunsuzlukId: null,
    ziyaretId: null,
    createdAt: n.createdAt,
  };
}

function mapOperasyonNotification(n: OperasyonNotification): Notification {
  const navigable = n.entityType === 'arac_operasyon' || n.entityType === 'ariza';
  return {
    id: n.id,
    kind: n.type,
    title: operasyonTitle(n.type),
    message: n.message,
    time: relativeTime(n.createdAt),
    read: n.read,
    type: 'info',
    ticketId: null,
    announcementId: null,
    zimmetId: null,
    operasyonEntityType: navigable ? n.entityType : null,
    operasyonEntityId: navigable ? n.entityId : null,
    conversationId: null,
    uygunsuzlukId: null,
    ziyaretId: null,
    createdAt: n.createdAt,
  };
}

function mapMesajlasmaNotification(n: MesajlasmaNotification): Notification {
  return {
    id: n.id,
    kind: 'yeni_mesaj',
    title: 'Yeni mesaj',
    message: n.message,
    time: relativeTime(n.createdAt),
    read: n.read,
    type: 'info',
    ticketId: null,
    announcementId: null,
    zimmetId: null,
    operasyonEntityType: null,
    operasyonEntityId: null,
    conversationId: n.conversationId,
    uygunsuzlukId: null,
    ziyaretId: null,
    createdAt: n.createdAt,
  };
}

function uygunsuzlukTitle(type: string): string {
  switch (type) {
    case 'uygunsuzluk_acildi': return 'Yeni uygunsuzluk';
    case 'kapatma_talebi': return 'Kapatma talebi';
    case 'uygunsuzluk_onaylandi': return 'Uygunsuzluk onaylandı';
    case 'uygunsuzluk_reddedildi': return 'Uygunsuzluk reddedildi';
    default: return 'Uygunsuzluk bildirimi';
  }
}

function uygunsuzlukIconType(type: string): 'info' | 'warning' | 'success' | 'error' {
  switch (type) {
    case 'kapatma_talebi': return 'warning';
    case 'uygunsuzluk_onaylandi': return 'success';
    case 'uygunsuzluk_reddedildi': return 'error';
    default: return 'info';
  }
}

function mapUygunsuzlukNotification(n: UygunsuzlukNotification): Notification {
  return {
    id: n.id,
    kind: n.type,
    title: uygunsuzlukTitle(n.type),
    message: n.message,
    time: relativeTime(n.createdAt),
    read: n.read,
    type: uygunsuzlukIconType(n.type),
    ticketId: null,
    announcementId: null,
    zimmetId: null,
    operasyonEntityType: null,
    operasyonEntityId: null,
    conversationId: null,
    uygunsuzlukId: n.uygunsuzlukId,
    ziyaretId: null,
    createdAt: n.createdAt,
  };
}

/** Mobile sheet içeriği — canlı state'e sahip ayrı component */
function NotificationList({
  notifications,
  onMarkAsRead,
  onMarkAllAsRead,
}: {
  notifications: Notification[];
  onMarkAsRead: (n: Notification) => void;
  onMarkAllAsRead: () => void;
}) {
  const unread = notifications.filter((n) => !n.read).length;
  return (
    <div>
      {unread > 0 && (
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs text-foreground-500">{unread} okunmamış bildirim</span>
          <button onClick={onMarkAllAsRead} className="text-xs text-primary-500 hover:text-primary-600 transition-colors cursor-pointer">
            Tümünü okundu olarak işaretle
          </button>
        </div>
      )}
      <div className="space-y-1">
        {notifications.length === 0 ? (
          <div className="py-6 text-center text-sm text-foreground-500">Bildirim yok</div>
        ) : (
          notifications.map((n) => (
            <button
              key={n.id}
              onClick={() => onMarkAsRead(n)}
              className={`w-full flex items-start gap-3 px-3 py-3 rounded-xl text-left transition-colors hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer ${!n.read ? 'bg-background-200/30 dark:bg-background-300/20' : ''}`}
            >
              <div className="relative w-8 h-8 rounded-full bg-background-200 flex items-center justify-center flex-shrink-0">
                <i className={n.kind === 'announcement' ? 'ri-megaphone-line text-accent-600' : n.kind.startsWith('zimmet') ? 'ri-handbag-line text-primary-500' : isOperasyonKind(n.kind) ? 'ri-tools-line text-primary-500' : isZiyaretKind(n.kind) ? 'ri-calendar-check-line text-primary-500' : typeIcons[n.type]} />
                <span className={`absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full ring-2 ring-background-50 dark:ring-background-100 ${PRIORITY_META[bellPriority(n)].dot}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm ${!n.read ? 'font-medium text-foreground-800' : 'text-foreground-700'}`}>{n.title}</p>
                <p className="text-xs text-foreground-500 mt-0.5">{n.message}</p>
                <p className="text-[10px] text-foreground-400 mt-1">{n.time}</p>
              </div>
              {!n.read && <span className="w-2 h-2 rounded-full bg-primary-500 flex-shrink-0 mt-1" />}
            </button>
          ))
        )}
      </div>
    </div>
  );
}

export default function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const ref = useRef<HTMLDivElement>(null);
  const { isOpen, options, openSheet, closeSheet } = useBottomSheet();
  const { openModal, closeModal } = useModalActions();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const isMobile = useMediaQuery('(max-width: 1023px)');

  // Kullanıcı PRİMİTİFİ: realtime kanalı ve veri yükleme YALNIZCA bu değere bağlanır.
  // Profil nesnesi referansı (ad/avatar güncellemesi gibi) değişse bile kanal YENİDEN
  // AÇILMAZ ve aynı veri gereksiz yere tekrar çekilmez.
  const profileId = profile?.id ?? null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  // Panele göre Bildirim Merkezi yolu (5 panel ortak sayfa).
  const bildirimCenterPath = useMemo(() => {
    const panel = getPanelFromPath(location.pathname);
    if (panel === 'osgb') return '/osgb-panel/bildirimler';
    if (panel === 'firma') return '/firma/bildirimler';
    if (panel === 'uzman') return '/uzman/bildirimler';
    if (panel === 'hekim') return '/hekim/bildirimler';
    return '/bildirimler';
  }, [location.pathname]);

  useClickOutside(ref, () => setOpen(false), open);

  const load = useCallback(async () => {
    if (!profileId) return;
    try {
      // Eşzamanlı tekrar tetiklemeleri (idle ön yükleme + zil açılışı + sekme dönüşü
      // + realtime burst) TEK in-flight ağ çağrısına indir. Biten çağrıdan SONRA gelen
      // yeni tetikleme yine TAZE veri çeker (coalesce yalnızca in-flight birleştirir).
      const merged = await coalesce(`notification-bell-load:${profileId}`, async () => {
        const [data, zimmetData, operasyonData, mesajlasmaData, uygunsuzlukData, ziyaretData] = await Promise.all([
          fetchNotifications(),
          fetchZimmetNotifications().catch(() => [] as ZimmetNotification[]),
          fetchOperasyonNotifications().catch(() => [] as OperasyonNotification[]),
          fetchMesajlasmaNotifications().catch(() => [] as MesajlasmaNotification[]),
          fetchUygunsuzlukNotifications().catch(() => [] as UygunsuzlukNotification[]),
          fetchZiyaretNotifications().catch(() => [] as ZiyaretNotification[]),
        ]);
        return [
          ...data.map(mapNotification),
          ...zimmetData.map(mapZimmetNotification),
          ...operasyonData.map(mapOperasyonNotification),
          ...mesajlasmaData.map(mapMesajlasmaNotification),
          ...uygunsuzlukData.map(mapUygunsuzlukNotification),
          ...ziyaretData.map(mapZiyaretNotification),
        ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      });
      setNotifications(merged);
    } catch {
      /* sessiz — bildirim yüklenemezse mevcut durum korunur */
    }
  }, [profileId]);

  // NOT (performans): İlk zil yüklemesi bilinçli olarak boşa (idle) ertelenir (aşağıda).
  // Burada ANINDA `load()` ÇAĞRILMAZ; aksi halde erteleme etkisiz kalır ve açılışta
  // gereksiz bir eşzamanlı istek üretilirdi. Zil açılınca + realtime + 30sn poll zaten tazeler.

  // Zil açılınca tazele (yeni gelen bildirimleri görmek için).
  useEffect(() => {
    if (open) load();
  }, [open, load]);

  // Realtime + poll fallback: bireysel bildirim eventleri oluşunca zili canlı günceller
  // (sayfa refresh'i gerekmez). Realtime koparsa 30sn poll güvenlik ağıdır.
  // RLS + user_id filtresi sayesinde her kullanıcı YALNIZCA kendi bildirim eventini alır.
  // Efekt yalnızca profileId + (stabil) load'a bağlı → ilgisiz profil güncellemesinde
  // kanal YENİDEN açılmaz.
  const refreshDebounceRef = useRef<number | null>(null);
  useEffect(() => {
    if (!profileId) return undefined;

    const scheduleLoad = () => {
      if (refreshDebounceRef.current) window.clearTimeout(refreshDebounceRef.current);
      refreshDebounceRef.current = window.setTimeout(() => {
        void load();
      }, 400);
    };

    const channel = supabase
      .channel('notification-bell-uygunsuzluk')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'uygunsuzluk_bildirimleri', filter: `user_id=eq.${profileId}` },
        scheduleLoad,
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'ziyaret_bildirimleri', filter: `user_id=eq.${profileId}` },
        scheduleLoad,
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'zimmet_bildirimleri', filter: `user_id=eq.${profileId}` },
        scheduleLoad,
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'operasyon_bildirimleri', filter: `user_id=eq.${profileId}` },
        scheduleLoad,
      )
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'mesajlasma_bildirimleri', filter: `user_id=eq.${profileId}` },
        scheduleLoad,
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'support_notifications', filter: `user_id=eq.${profileId}` },
        scheduleLoad,
      )
      .subscribe();

    // Poll güvenlik ağı: sekme GÖRÜNÜR iken 30sn'de bir tazeler. Sekme arka plana
    // geçince interval DURDURULUR (gereksiz timer/istek yok); sekme geri gelince
    // ANINDA tazelenir ve interval yeniden başlar → arka plan maliyeti ~sıfır,
    // dönüşte gecikme yok.
    let poll: number | null = null;
    const startPoll = () => {
      if (poll === null) {
        poll = window.setInterval(() => {
          if (document.visibilityState === 'visible') void load();
        }, 30000);
      }
    };
    const stopPoll = () => {
      if (poll !== null) {
        window.clearInterval(poll);
        poll = null;
      }
    };
    const onVisibility = () => {
      if (document.visibilityState === 'visible') {
        void load();
        startPoll();
      } else {
        stopPoll();
      }
    };
    // Ağ geri geldiğinde (realtime kopmuş olabilir) anında tazele.
    const onOnline = () => void load();
    if (document.visibilityState === 'visible') startPoll();
    document.addEventListener('visibilitychange', onVisibility);
    window.addEventListener('online', onOnline);

    return () => {
      void supabase.removeChannel(channel);
      stopPoll();
      document.removeEventListener('visibilitychange', onVisibility);
      window.removeEventListener('online', onOnline);
      if (refreshDebounceRef.current) window.clearTimeout(refreshDebounceRef.current);
    };
  }, [profileId, load]);

  const handleNotificationClick = useCallback(
    (n: Notification) => {
      // Operasyon bildirimi → operasyon detay modalını aç.
      if (n.operasyonEntityId && n.operasyonEntityType) {
        const mid = openModal({
          title: n.title,
          description: 'Operasyon Detayı',
          variant: 'detail',
          width: 560,
          minWidth: 440,
          minHeight: 460,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          content: (
            <Suspense fallback={<ModalFallback />}>
              <OperasyonDetailModal
                entityType={n.operasyonEntityType as 'arac_operasyon' | 'ariza'}
                entityId={n.operasyonEntityId}
                onClose={() => closeModal(mid)}
                onChanged={() => {
                  setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
                  markOperasyonNotificationRead(n.id).catch(() => undefined);
                }}
              />
            </Suspense>
          ),
        });
        return;
      }

      // Zimmet bildirimi → zimmet detay modalını aç; yüklenebilirse okundu işaretle.
      if (n.zimmetId) {
        const mid = openModal({
          title: n.title,
          description: 'Zimmet Detayı',
          variant: 'detail',
          width: 1100,
          minWidth: 440,
          minHeight: 520,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          bodyLayout: 'fill',
          content: (
            <Suspense fallback={<ModalFallback />}>
              <ZimmetDetailModal
                zimmetId={n.zimmetId}
                onClose={() => closeModal(mid)}
                onChanged={() => {
                  setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
                  markZimmetNotificationRead(n.id).catch(() => undefined);
                }}
              />
            </Suspense>
          ),
        });
        return;
      }

      // Uygunsuzluk bildirimi → ilgili Shared Detail Modal (uzman veya firma).
      if (n.uygunsuzlukId) {
        const isFirma = profile?.role === 'firma';
        const mid = openModal({
          title: n.title,
          description: 'Uygunsuzluk Detayı',
          variant: 'detail',
          width: 540,
          minWidth: 400,
          minHeight: 420,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          content: (
            <Suspense fallback={<ModalFallback />}>
              {isFirma ? (
                <FirmaUygunsuzlukDetailModal
                  uygunsuzlukId={n.uygunsuzlukId}
                  onClose={() => closeModal(mid)}
                  onChanged={() => undefined}
                />
              ) : (
                <UygunsuzlukDetailModal
                  uygunsuzlukId={n.uygunsuzlukId}
                  onClose={() => closeModal(mid)}
                  onChanged={() => undefined}
                />
              )}
            </Suspense>
          ),
        });
        setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
        markUygunsuzlukNotificationRead(n.id).catch(() => undefined);
        return;
      }

      // Duyuru bildirimi -> önce veriyi yükle; başarılıysa okundu işaretle.
      // Veri yüklenemez ya da erişim reddedilirse bildirim okundu YAPILMAZ.
      if (n.kind === 'announcement' && n.announcementId) {
        const mid = openModal({
          title: 'Duyuru',
          description: n.title,
          variant: 'detail',
          width: 560,
          minWidth: 420,
          minHeight: 460,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          content: (
            <Suspense fallback={<ModalFallback />}>
              <AnnouncementReaderModal
                announcementId={n.announcementId}
                onClose={() => closeModal(mid)}
                onLoaded={() => {
                  setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
                  markNotificationRead(n.id, n.kind).catch(() => undefined);
                }}
              />
            </Suspense>
          ),
        });
        // Bildirim listesini kapat ki modal öne çıksın.
        setOpen(false);
        if (isOpen) closeSheet();
        return;
      }

      // Mesajlaşma bildirimi → ilgili sohbeti aç.
      if (n.kind === 'yeni_mesaj') {
        setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
        markMesajlasmaNotificationRead(n.id).catch(() => undefined);
        if (n.conversationId) {
          setPendingConversationId(n.conversationId);
          const panel = getPanelFromPath(location.pathname);
          const msgPath = PANEL_NAV_CONFIG[panel].find((i) => i.path.endsWith('/mesajlasma'))?.path;
          if (msgPath) navigate(msgPath);
        }
        setOpen(false);
        if (isOpen) closeSheet();
        return;
      }

      // ZV-02 — Ziyaret detayı varsa ilgili ziyaret modalını aç.
      if (n.ziyaretId) {
        openModal({
          title: n.title,
          description: 'Ziyaret Detayı',
          variant: 'detail',
          width: 960,
          minWidth: 660,
          minHeight: 580,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          content: (
            <Suspense fallback={<ModalFallback />}>
              <ZiyaretDetayModal ziyaretId={n.ziyaretId} onChanged={() => undefined} />
            </Suspense>
          ),
        });
        setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
        markZiyaretNotificationRead(n.id).catch(() => undefined);
        setOpen(false);
        if (isOpen) closeSheet();
        return;
      }

      // ZV-02 — İzin/gün değişikliği bildirimi (ziyaret detayı yoksa ilgili panelin listesine git).
      if (isZiyaretKind(n.kind)) {
        setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
        markZiyaretNotificationRead(n.id).catch(() => undefined);
        const panel = getPanelFromPath(location.pathname);
        const listPath = PANEL_NAV_CONFIG[panel].find(
          (i) => i.path.endsWith('/ziyaretler') || i.path.endsWith('/ziyaret-planlama'),
        )?.path;
        if (listPath) navigate(listPath);
        setOpen(false);
        if (isOpen) closeSheet();
        return;
      }

      // Destek bildirimleri: mevcut davranış korunur (okundu işaretle).
      setNotifications((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
      markNotificationRead(n.id, n.kind).catch(() => undefined);
    },
    [openModal, closeModal, navigate, location.pathname, isOpen, closeSheet],
  );

  const markAllAsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    markAllNotificationsRead().catch(() => undefined);
    markAllZimmetNotificationsRead().catch(() => undefined);
    markAllOperasyonNotificationsRead().catch(() => undefined);
    markAllMesajlasmaNotificationsRead().catch(() => undefined);
    markAllUygunsuzlukNotificationsRead().catch(() => undefined);
    markAllZiyaretNotificationsRead().catch(() => undefined);
  }, []);

  const prevNotificationsRef = useRef(notifications);
  useEffect(() => {
    if (prevNotificationsRef.current !== notifications && isOpen && options?.title === 'Bildirimler') {
      openSheet({
        title: 'Bildirimler',
        showClose: true,
        content: (
          <NotificationList
            notifications={notifications}
            onMarkAsRead={handleNotificationClick}
            onMarkAllAsRead={markAllAsRead}
          />
        ),
      });
    }
    prevNotificationsRef.current = notifications;
  }, [notifications, isOpen, options, openSheet, handleNotificationClick, markAllAsRead]);

  const handleClick = () => {
    if (isMobile) {
      openSheet({
        title: 'Bildirimler',
        showClose: true,
        content: (
          <div>
            <NotificationList
              notifications={notifications}
              onMarkAsRead={handleNotificationClick}
              onMarkAllAsRead={markAllAsRead}
            />
            <button
              type="button"
              onClick={() => { closeSheet(); navigate(bildirimCenterPath); }}
              className="w-full flex items-center justify-center gap-1.5 py-2.5 mt-1 border-t isg-divider text-xs font-medium text-primary-600 hover:text-primary-700 transition-colors cursor-pointer"
            >
              <i className="ri-external-link-line" />
              Bildirim Merkezi'ni Aç
            </button>
          </div>
        ),
      });
    } else {
      setOpen((p) => !p);
    }
  };

  useEffect(() => runWhenIdle(() => {
    // PERFORMANS: Zil için ilk yükleme AÇILIŞ İÇİN KRİTİK DEĞİL. Boşta kalan zamana
    // ertelenir; böylece ilk ekranı/paneli besleyen kritik istekler ağ şeridini daha
    // erken kapar (ilk anlamlı içerik daha hızlı görünür). Zil açılınca zaten tazelenir.
    void load();
  }), [load]);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={handleClick}
        aria-label="Bildirimler"
        aria-haspopup="dialog"
        aria-expanded={!isMobile ? open : isOpen && options?.title === 'Bildirimler'}
        className="relative w-8 h-8 flex items-center justify-center rounded text-foreground-500 hover:text-foreground-700 hover:bg-background-200 transition-colors"
      >
        <i className="ri-notification-3-line" />
        {unreadCount > 0 && (
          <span className="absolute top-1 right-1 w-4 h-4 flex items-center justify-center rounded-full bg-danger-500 text-inverse text-[10px] font-bold">
            {unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 max-w-[calc(100vw-2rem)] isg-popover overflow-hidden" style={{ zIndex: Z_LAYERS.topbarDropdown }}>
          <div className="px-4 py-3 border-b isg-divider">
            <h3 className="text-sm font-semibold text-foreground-950">Bildirimler</h3>
          </div>
          <div className="max-h-72 overflow-y-auto px-4 py-3">
            <NotificationList
              notifications={notifications}
              onMarkAsRead={handleNotificationClick}
              onMarkAllAsRead={markAllAsRead}
            />
          </div>
          <button
            type="button"
            onClick={() => { setOpen(false); navigate(bildirimCenterPath); }}
            className="w-full flex items-center justify-center gap-1.5 py-2.5 border-t isg-divider text-xs font-medium text-primary-600 hover:text-primary-700 hover:bg-background-100 transition-colors cursor-pointer"
          >
            <i className="ri-external-link-line" />
            Bildirim Merkezi'ni Aç
          </button>
        </div>
      )}
    </div>
  );
}