import { useState, useCallback, useMemo, useRef, lazy, Suspense, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import useSWR from 'swr';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import IconButton from '@/components/ui/IconButton';
import Toggle from '@/components/ui/Toggle';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import FilterBar from '@/components/ui/FilterBar';
import type { FilterField, FilterValue } from '@/components/ui/FilterBar';
import Pagination from '@/components/ui/Pagination';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import { ModalSkeleton, ListSkeleton } from '@/components/ui/Skeleton';
import SharedListCard, { ListCardBadge } from '@/components/ui/SharedListCard';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import { useAuth } from '@/context/AuthContext';
import EkipmanEkleWizard from './EkipmanEkleWizard';
import QrTaramaModal from './QrTaramaModal';
import EkipmanIceriAktarModal from './EkipmanIceriAktarModal';
import EkipmanDisaAktarModal from './EkipmanDisaAktarModal';
import type { EkipmanExportOptions } from './EkipmanDisaAktarModal';
import TopluQrPdfModal from './TopluQrPdfModal';
import type { TopluQrPdfOptions } from './TopluQrPdfModal';
import ExcelIslemleriButton from './ExcelIslemleriButton';

// AĞIR DETAY MODALI — LAZY. EkipmanDetailModal (qrcode) yalnızca gerçekten
// açıldığında yüklenir; liste sayfası bu kütüphaneyi eager indirmez.
const EkipmanDetailModal = lazy(() => import('./EkipmanDetailModal'));

/** Lazy modal içeriği için ortak bekleme görünümü. */
function ModalLoadingFallback() {
  return <ModalSkeleton variant="detail" />;
}
import {
  type EkipmanData,
  type EkipmanKullanimDurumu,
  type EkipmanListQuery,
  type EkipmanKatalog,
  type EkipmanFirmaOption,
  fetchEkipmanlarPage,
  fetchEkipmanKatalog,
  fetchEkipmanFirmalari,
  deleteEkipman,
  topluSilEkipman,
  restoreEkipman,
  friendlyEkipmanError,
  buildEkipmanQrUrl,
} from '@/lib/ekipmanService';
import { downloadEkipmanExcel, downloadEkipmanCsv } from '@/lib/excel/ekipmanExcel';
import { exportEkipmanQrPdf, type QrEtiketRow } from '@/lib/pdf/qrEtiketPdf';
import { EKIPMAN_LISTE_KOLONLARI, EKIPMAN_LISTE_KOLON_SECENEKLERI } from '@/lib/ekipmanKolonlari';
import { useExcelBrandMeta } from '@/hooks/useExcelBrandMeta';
import { fetchFirma } from '@/lib/firmaService';
import {
  kullanimDurumuBadgeVariant,
  kontrolDurumuBadgeVariant,
  kullanimDurumuIcon,
  ekipmanIcon,
  formatEkipmanDate,
} from './ekipmanUi';

function asStr(v: FilterValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

const SORT_MAP: Record<string, string> = {
  ekipmanNo: 'ekipman_no',
  ad: 'ad',
  durum: 'kullanim_durumu',
};

/** Kolon anahtarı → liste hücresi. Kolonlar merkezi tanımdan (ekipmanKolonlari) gelir. */
function renderEkipmanHucre(key: string, r: EkipmanData): ReactNode {
  switch (key) {
    case 'ekipmanNo': return <span className="text-sm font-medium text-foreground-800">{r.ekipmanNo}</span>;
    case 'ad': return <span className="text-sm text-foreground-800">{r.ad}</span>;
    case 'tur': return <span className="text-sm text-foreground-600">{r.turAd}</span>;
    case 'firma': return <span className="text-sm text-foreground-600">{r.firmaUnvan}</span>;
    case 'marka': return <span className="text-sm text-foreground-600">{r.marka || '—'}</span>;
    case 'model': return <span className="text-sm text-foreground-600">{r.model || '—'}</span>;
    case 'seriNo': return <span className="text-sm text-foreground-600">{r.seriNo || '—'}</span>;
    case 'lokasyon': return <span className="text-sm text-foreground-600">{r.konum || '—'}</span>;
    case 'sonKontrol': return <span className="text-sm text-foreground-600">{r.sonKontrolTarihi ? formatEkipmanDate(r.sonKontrolTarihi) : '—'}</span>;
    case 'sonrakiKontrol': return <span className="text-sm text-foreground-600">{r.sonrakiKontrolTarihi ? formatEkipmanDate(r.sonrakiKontrolTarihi) : '—'}</span>;
    case 'kalanSure': return <Badge variant={kontrolDurumuBadgeVariant(r.kontrolDurumu)}>{r.kontrolDurumuLabel}</Badge>;
    case 'durum': return r.deletedAt
      ? <Badge variant="default" leftIcon={<i className="ri-archive-line" />}>Arşiv</Badge>
      : <Badge variant={kullanimDurumuBadgeVariant(r.kullanimDurumu)} leftIcon={<i className={kullanimDurumuIcon(r.kullanimDurumu)} />}>{r.kullanimDurumuLabel}</Badge>;
    default: return null;
  }
}

function MobileEkipmanCard({
  row,
  onDetail,
  onSil,
  onRestore,
  busy,
}: {
  row: EkipmanData;
  onDetail: (row: EkipmanData) => void;
  onSil: (row: EkipmanData) => void;
  onRestore: (row: EkipmanData) => void;
  busy: boolean;
}) {
  const deleted = !!row.deletedAt;
  return (
    <SharedListCard
      recordNo={row.ekipmanNo}
      icon={ekipmanIcon()}
      iconBg="bg-primary-50 dark:bg-primary-500/20"
      iconColor="text-primary-600 dark:text-primary-400"
      title={row.ad}
      description={[row.turAd, row.marka, row.model].filter((v) => v && v !== '—').join(' · ') || undefined}
      badges={[
        <ListCardBadge key="durum" variant={kullanimDurumuBadgeVariant(row.kullanimDurumu)}>{row.kullanimDurumuLabel}</ListCardBadge>,
        <ListCardBadge key="kontrol" variant={kontrolDurumuBadgeVariant(row.kontrolDurumu)}>
          {row.kontrolDurumuLabel}
        </ListCardBadge>,
      ]}
      metadata={[
        { label: 'Seri No', value: row.seriNo || '—' },
        { label: 'Sonraki Kontrol', value: asStr(row.sonrakiKontrolTarihi) ? formatEkipmanDate(row.sonrakiKontrolTarihi) : '—' },
      ]}
      actions={
        deleted ? (
          <IconButton
            icon={<i className="ri-refresh-line" />}
            variant="ghost"
            size="sm"
            disabled={busy}
            label="Yeniden Aktifleştir"
            onClick={() => onRestore(row)}
          />
        ) : (
          <IconButton
            icon={<i className="ri-delete-bin-line" />}
            variant="ghost"
            size="sm"
            disabled={busy}
            label="Sil"
            onClick={() => onSil(row)}
          />
        )
      }
      onClick={() => { if (!deleted) onDetail(row); }}
    />
  );
}

export default function EkipmanListesi() {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const { profile } = useAuth();

  const role = profile?.role ?? '';
  const isUzman = role === 'uzman';
  const isFirma = role === 'firma';
  // İçe aktarma hem Uzman (atamalı) hem Firma panelinde kullanılabilir.
  const canImport = isUzman || isFirma;
  const navigate = useNavigate();
  const getBrandMeta = useExcelBrandMeta();

  const wizardModalIdRef = useRef('');
  const detailModalIdRef = useRef('');
  const qrModalIdRef = useRef('');
  const iceriAktarModalIdRef = useRef('');
  const disaAktarModalIdRef = useRef('');
  const topluQrModalIdRef = useRef('');

  const [busyId, setBusyId] = useState<string | null>(null);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);

  const { data: katalog = { gruplar: [], turler: [], altTurler: [], sablonlar: [], alanlar: [], kurallar: [] } } =
    useSWR<EkipmanKatalog>('ekipman-katalog', fetchEkipmanKatalog);
  const { data: firmalar = [] } = useSWR<EkipmanFirmaOption[]>(
    isUzman ? 'ekipman-firmalari' : null,
    fetchEkipmanFirmalari,
  );
  // Firma paneli kullanıcısı için kendi firma unvanı (şablon başlığı/excel için).
  const kendiFirmaId = isFirma ? (profile?.firmaId ?? '') : '';
  const { data: kendiFirmaAdi = '' } = useSWR(
    kendiFirmaId ? ['ekipman-kendi-firma-ad', kendiFirmaId] : null,
    () => fetchFirma(kendiFirmaId).then((f) => f.ad).catch(() => ''),
  );

  const [searchQuery, setSearchQuery] = useState('');
  const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
  const [sortKey, setSortKey] = useState<string>('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [showPasif, setShowPasif] = useState(false);

  // Seçili firma — şablon başlığı ve dışa aktarma dosya adı için kullanılır.
  // Ekipman liste kolonları SABİTTİR; kullanıcının Excel'i bu yapıyı değiştirmez.
  const selectedFirmaId = isUzman ? asStr(filterValues['firma']) : (profile?.firmaId ?? '');

  const buildQuery = useCallback((): EkipmanListQuery => ({
    search: searchQuery || undefined,
    kullanimDurumu: (asStr(filterValues['durum']) as EkipmanKullanimDurumu | '') || '',
    turId: asStr(filterValues['tur']) || '',
    firmaId: isUzman ? asStr(filterValues['firma']) || '' : '',
    sortBy: (SORT_MAP[sortKey] || 'created_at') as EkipmanListQuery['sortBy'],
    sortDir,
    page,
    pageSize,
    includeDeleted: showPasif,
  }), [searchQuery, filterValues, sortKey, sortDir, page, pageSize, showPasif, isUzman]);

  const queryKey = useMemo(() => JSON.stringify(buildQuery()), [buildQuery]);
  const { data: pageData, error, isLoading, mutate } = useSWR(
    ['ekipmanlar', queryKey],
    () => fetchEkipmanlarPage(buildQuery()),
  );
  const rows = pageData?.data ?? [];
  const count = pageData?.count ?? 0;
  const loading = isLoading;
  const errorMsg = error ? friendlyEkipmanError(error) : null;

  const visibleKeys = rows.filter((r) => !r.deletedAt).map((r) => r.id);
  const selectedVisible = selectedKeys.filter((k) => visibleKeys.includes(k));

  const handleFilterChange = (key: string, value: FilterValue) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }));
    setPage(1);
    setSelectedKeys([]);
  };

  const handleReset = () => {
    setFilterValues({});
    setSearchQuery('');
    setPage(1);
    setSelectedKeys([]);
  };

  const handleSort = (key: string) => {
    if (!SORT_MAP[key]) return;
    if (sortKey === key) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortKey(key);
      setSortDir('desc');
    }
    setPage(1);
  };

  const handleOpenCreate = useCallback(() => {
    const id = openModal({
      title: 'Yeni Ekipman',
      description: 'Envanterinize yeni bir ekipman kaydı ekleyin.',
      variant: 'form',
      width: 880,
      minWidth: 520,
      minHeight: 520,
      bodyLayout: 'fill',
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EkipmanEkleWizard
          onClose={() => closeModal(wizardModalIdRef.current)}
          onSaved={() => { if (page === 1) mutate(); else setPage(1); }}
        />
      ),
    });
    wizardModalIdRef.current = id;
  }, [openModal, closeModal, mutate, page]);

  const handleQrTara = useCallback(() => {
    const id = openModal({
      title: 'QR Kod Tara',
      description: 'Ekipman etiketindeki QR kodu kameraya gösterin.',
      variant: 'form',
      width: 520,
      minWidth: 360,
      minHeight: 420,
      showFooter: false,
      closable: true,
      content: (
        <QrTaramaModal
          onClose={() => closeModal(qrModalIdRef.current)}
          onToken={(token) => {
            closeModal(qrModalIdRef.current);
            navigate(`/ekipman-qr/${encodeURIComponent(token)}`);
          }}
        />
      ),
    });
    qrModalIdRef.current = id;
  }, [openModal, closeModal, navigate]);

  const resolveFirmaAdi = useCallback(
    (firmaId: string): string => {
      if (firmaId) {
        const f = firmalar.find((x) => x.value === firmaId);
        if (f) return f.label;
      }
      const fromRows = rows.find((r) => r.firmaUnvan && r.firmaUnvan !== '—')?.firmaUnvan;
      return fromRows || kendiFirmaAdi || '';
    },
    [firmalar, rows, kendiFirmaAdi],
  );

  const handleIceriAktar = useCallback(() => {
    const firmaAdi = resolveFirmaAdi(selectedFirmaId);
    const id = openModal({
      title: 'Ekipmanları İçe Aktar',
      description: 'Excel dosyası ile toplu ekipman kaydı ekleyin.',
      headerIcon: (
        <span className="w-9 h-9 rounded-lg bg-success-600 flex items-center justify-center">
          <i className="ri-file-excel-2-fill text-lg text-inverse" />
        </span>
      ),
      variant: 'form',
      // ≤620 genişlik → modal yüksekliği İÇERİK KADAR (otomatik) hesaplanır;
      // altta devasa boş alan / gereksiz scroll oluşmaz (kompakt geometri).
      width: 600,
      minWidth: 460,
      minHeight: 240,
      height: 430,
      bodyLayout: 'fill',
      showFooter: false,
      closable: true,
      content: (
        <EkipmanIceriAktarModal
          firmalar={firmalar}
          turler={katalog.turler}
          defaultFirmaId={selectedFirmaId || undefined}
          firmaAdi={firmaAdi}
          getBrandMeta={() =>
            getBrandMeta({ firmaId: selectedFirmaId || (firmalar[0]?.value ?? ''), firmaAdi })
          }
          onClose={() => closeModal(iceriAktarModalIdRef.current)}
          onCompleted={() => { if (page === 1) mutate(); else setPage(1); }}
        />
      ),
    });
    iceriAktarModalIdRef.current = id;
  }, [openModal, closeModal, mutate, page, firmalar, katalog.turler, selectedFirmaId, resolveFirmaAdi, getBrandMeta]);

  // TEK KAYNAK: liste kolonları (src/lib/ekipmanKolonlari.ts). Liste UI + Excel
  // dışa aktarma + Excel şablonu aynı tanımı kullanır; bir yerde kolon eklenirse
  // diğerleri otomatik hizalanır (senkron bozulmaz).
  const exportBaseColumns = useMemo(() => EKIPMAN_LISTE_KOLON_SECENEKLERI, []);

  // GERÇEK dışa aktarma motoru: kapsam filtresi → sabit şema → seçilen
  // sütunlar → global Excel/CSV motoru → doğrudan indirme.
  const handleExport = useCallback(
    async (options: EkipmanExportOptions) => {
      const q = buildQuery();
      const kullanimDurumu = options.scope === 'aktif'
        ? 'aktif'
        : options.scope === 'arizali'
          ? 'arizali'
          : '';
      const full = await fetchEkipmanlarPage({
        ...q,
        kullanimDurumu: (kullanimDurumu as EkipmanKullanimDurumu | ''),
        page: 1,
        pageSize: 5000,
      });
      let data = full.data;
      if (options.scope === 'secili') {
        const set = new Set(selectedVisible);
        data = data.filter((d) => set.has(d.id));
      }
      if (data.length === 0) {
        throw new Error('Seçilen kapsamda dışa aktarılacak ekipman bulunamadı.');
      }

      const firmaId = selectedFirmaId || (data[0]?.firmaId ?? '');
      const firmaAdi = resolveFirmaAdi(firmaId) || (data[0]?.firmaUnvan ?? '');
      const rowsExcel = data.map((d) => ({
        ekipmanNo: d.ekipmanNo,
        ad: d.ad,
        tur: d.turAd,
        firma: d.firmaUnvan,
        marka: d.marka,
        model: d.model,
        seriNo: d.seriNo,
        lokasyon: d.konum,
        sonKontrol: d.sonKontrolTarihi ?? '',
        sonrakiKontrol: d.sonrakiKontrolTarihi ?? '',
        kullanimDurumu: d.kullanimDurumu,
        kullanimDurumuLabel: d.kullanimDurumuLabel,
      }));

      if (options.format === 'csv') {
        downloadEkipmanCsv(rowsExcel, options.baseKeys);
      } else {
        const meta = await getBrandMeta({ firmaId, firmaAdi });
        await downloadEkipmanExcel(rowsExcel, meta, options.baseKeys);
      }
    },
    [buildQuery, selectedVisible, selectedFirmaId, resolveFirmaAdi, getBrandMeta],
  );

  const handleDisaAktar = useCallback(() => {
    const id = openModal({
      title: 'Ekipmanları Dışa Aktar',
      description: 'Ekipman listelerini Excel dosyası olarak indirin.',
      headerIcon: (
        <span className="w-9 h-9 rounded-lg bg-success-600 flex items-center justify-center">
          <i className="ri-file-excel-2-fill text-lg text-inverse" />
        </span>
      ),
      variant: 'form',
      width: 760,
      minWidth: 520,
      minHeight: 420,
      height: 600,
      bodyLayout: 'fill',
      showFooter: false,
      closable: true,
      content: (
        <EkipmanDisaAktarModal
          baseColumns={exportBaseColumns}
          selectedCount={selectedVisible.length}
          onExport={handleExport}
          onClose={() => closeModal(disaAktarModalIdRef.current)}
        />
      ),
    });
    disaAktarModalIdRef.current = id;
  }, [openModal, closeModal, exportBaseColumns, selectedVisible.length, handleExport]);

  // GERÇEK toplu QR / PDF üretimi: kapsam → gerçek ekipman QR tokenları →
  // global PDF motoru (logo + kurumsal footer Kurumsal Ayarlar'dan) → indirme.
  const handleTopluQrGenerate = useCallback(
    async (options: TopluQrPdfOptions) => {
      const q = buildQuery();
      const full = await fetchEkipmanlarPage({ ...q, page: 1, pageSize: 5000 });
      let data = full.data.filter((d) => !d.deletedAt);
      if (options.scope === 'secili') {
        const set = new Set(selectedVisible);
        data = data.filter((d) => set.has(d.id));
      }
      if (data.length === 0) {
        throw new Error('Seçilen kapsamda ekipman bulunamadı.');
      }

      const firmaId = selectedFirmaId || (data[0]?.firmaId ?? '');
      const firmaAdi = resolveFirmaAdi(firmaId) || (data[0]?.firmaUnvan ?? '');
      const meta = await getBrandMeta({ firmaId, firmaAdi });

      const qrRows: QrEtiketRow[] = data.map((d) => ({
        ekipmanNo: d.ekipmanNo,
        ad: d.ad,
        tur: d.turAd,
        marka: d.marka,
        model: d.model,
        seriNo: d.seriNo,
        lokasyon: d.konum,
        qrUrl: buildEkipmanQrUrl(d.qrReference),
      }));

      await exportEkipmanQrPdf(qrRows, meta, {
        mode: options.mode,
        cols: options.cols,
        rows: options.rows,
      });
    },
    [buildQuery, selectedVisible, selectedFirmaId, resolveFirmaAdi, getBrandMeta],
  );

  const handleTopluQrPdf = useCallback(() => {
    const id = openModal({
      title: 'Toplu QR / PDF Oluştur',
      description: 'Ekipmanlar için QR etiket PDF dosyası oluşturun.',
      headerIcon: (
        <span className="w-9 h-9 rounded-lg bg-primary-500 flex items-center justify-center">
          <i className="ri-qr-code-line text-lg text-inverse" />
        </span>
      ),
      variant: 'form',
      width: 640,
      minWidth: 480,
      minHeight: 360,
      height: 600,
      bodyLayout: 'fill',
      showFooter: false,
      closable: true,
      content: (
        <TopluQrPdfModal
          selectedCount={selectedVisible.length}
          totalCount={count}
          onGenerate={handleTopluQrGenerate}
          onClose={() => closeModal(topluQrModalIdRef.current)}
        />
      ),
    });
    topluQrModalIdRef.current = id;
  }, [openModal, closeModal, selectedVisible.length, count, handleTopluQrGenerate]);

  const handleOpenDetail = useCallback(
    (row: EkipmanData) => {
      const id = openModal({
        // Aynı ekipmanın detayı zaten açıksa ikinci kopya açılmaz.
        dedupeKey: `ekipman-detay:${row.id}`,
        title: row.ad,
        description: `No: ${row.ekipmanNo}`,
        variant: 'detail',
        width: 1080,
        minWidth: 520,
        minHeight: 520,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: (
          <Suspense fallback={<ModalLoadingFallback />}>
            <EkipmanDetailModal row={row} onClose={() => closeModal(detailModalIdRef.current)} onChanged={() => mutate()} />
          </Suspense>
        ),
      });
      detailModalIdRef.current = id;
    },
    [openModal, closeModal, mutate],
  );

  const handleSil = useCallback(
    (row: EkipmanData) => {
      if (busyId) return;
      confirm({
        title: 'Ekipmanı Sil',
        message: `${row.ad} (${row.ekipmanNo}) operasyonel listeden çıkarılacak. Kayıt silinmez; geçmiş, belgeler ve QR ilişkisi korunur.`,
        variant: 'danger',
        confirmText: 'Evet, Sil',
        cancelText: 'Vazgeç',
        onConfirm: () => {
          setBusyId(row.id);
          deleteEkipman(row.id)
            .then(() => {
              addToast({ title: 'Silindi', message: `${row.ad} listeden çıkarıldı.`, type: 'success' });
              setSelectedKeys((prev) => prev.filter((k) => k !== row.id));
              mutate();
            })
            .catch((err) => addToast({ title: 'İşlem başarısız', message: friendlyEkipmanError(err), type: 'error' }))
            .finally(() => setBusyId(null));
        },
      });
    },
    [busyId, confirm, addToast, mutate],
  );

  const handleTopluSil = useCallback(() => {
    if (bulkBusy || selectedVisible.length === 0) return;
    confirm({
      title: 'Seçilen Ekipmanları Sil',
      message: `${selectedVisible.length} ekipman listeden çıkarılacak. Kayıtlar silinmez; geçmiş, belgeler ve QR ilişkileri korunur.`,
      variant: 'danger',
      confirmText: 'Evet, Sil',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setBulkBusy(true);
        topluSilEkipman(selectedVisible)
          .then((adet) => {
            addToast({ title: 'Silindi', message: `${adet} ekipman listeden çıkarıldı.`, type: 'success' });
            setSelectedKeys([]);
            mutate();
          })
          .catch((err) => addToast({ title: 'İşlem başarısız', message: friendlyEkipmanError(err), type: 'error' }))
          .finally(() => setBulkBusy(false));
      },
    });
  }, [bulkBusy, selectedVisible, confirm, addToast, mutate]);

  const handleRestore = useCallback(
    (row: EkipmanData) => {
      if (busyId) return;
      setBusyId(row.id);
      restoreEkipman(row.id)
        .then(() => {
          addToast({ title: 'Yeniden aktifleştirildi', message: `${row.ad} yeniden aktif duruma alındı.`, type: 'success' });
          mutate();
        })
        .catch((err) => addToast({ title: 'İşlem başarısız', message: friendlyEkipmanError(err), type: 'error' }))
        .finally(() => setBusyId(null));
    },
    [busyId, addToast, mutate],
  );

  const filters = useMemo<FilterField[]>(() => {
    const f: FilterField[] = [
      {
        key: 'tur',
        label: 'Tür',
        type: 'select',
        placeholder: 'Tür — Tümü',
        options: katalog.turler.map((t) => ({ value: t.id, label: t.ad })),
      },
      {
        key: 'durum',
        label: 'Kullanım Durumu',
        type: 'status',
        placeholder: 'Durum — Tümü',
        options: [
          { value: 'aktif', label: 'Aktif' },
          { value: 'arizali', label: 'Arızalı' },
          { value: 'bakimda', label: 'Bakımda' },
          { value: 'kullanim_disi', label: 'Kullanım Dışı' },
        ],
      },
    ];
    if (isUzman) {
      f.unshift({
        key: 'firma',
        label: 'Firma',
        type: 'select',
        placeholder: 'Firma — Tümü',
        options: firmalar.map((fr) => ({ value: fr.value, label: fr.label })),
      });
    }
    return f;
  }, [katalog.turler, firmalar, isUzman]);

  // Liste kolonları MERKEZİ tanımdan üretilir (ekipmanKolonlari).
  // "Ekipman Grubu" kaldırıldı; Marka / Model / Seri No eklendi.
  const columns: TableColumn<EkipmanData>[] = EKIPMAN_LISTE_KOLONLARI.map((kolon) => ({
    key: kolon.key,
    header: kolon.label,
    sortable: !!SORT_MAP[kolon.key],
    render: (r) => renderEkipmanHucre(kolon.key, r),
  }));

  const totalPages = Math.max(1, Math.ceil(count / pageSize));

  const hasActiveFilter = searchQuery !== '' || asStr(filterValues['tur']) !== '' || asStr(filterValues['durum']) !== '' || asStr(filterValues['firma']) !== '';

  return (
    <div className="isg-page">
      <PageHeader
        title="Ekipmanlar"
        subtitle={isUzman ? 'Yetkili olduğunuz firmaların iş ekipmanları' : 'Firmanıza ait iş ekipmanları'}
        className="flex-shrink-0"
        actions={
          <div className="flex items-center gap-2">
            {/* QR okutma yalnızca MOBİL içindir; masaüstünde gizlenir. */}
            <div className="lg:hidden">
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-qr-scan-2-line" />} onClick={handleQrTara}>
                QR Tara
              </Button>
            </div>
            <ExcelIslemleriButton
              onIceriAktar={handleIceriAktar}
              onDisaAktar={handleDisaAktar}
              onTopluQrPdf={handleTopluQrPdf}
              canImport={canImport}
            />
            <Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={handleOpenCreate}>
              Ekipman Ekle
            </Button>
          </div>
        }
      />

      <div className="isg-card flex flex-col p-3">
        <div className="flex items-center justify-end mb-2">
          <Toggle label="Arşivdekileri göster" checked={showPasif} onChange={(e) => { setShowPasif(e.target.checked); setPage(1); setSelectedKeys([]); }} />
        </div>
        <FilterBar
          filters={filters}
          values={filterValues}
          onChange={handleFilterChange}
          onReset={handleReset}
          onSearch={(v) => { setSearchQuery(v); setPage(1); setSelectedKeys([]); }}
          searchPlaceholder="Ara... ekipman no, ad, marka, model, seri no"
          searchDebounceMs={400}
        />

        <div className="mt-3 flex-1 min-h-0">
          {loading ? (
            <ListSkeleton rows={8} />
          ) : errorMsg ? (
            <ErrorState message={errorMsg} onRetry={() => mutate()} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon="ri-tools-line"
              title={hasActiveFilter ? 'Sonuç bulunamadı' : 'Henüz ekipman kaydı bulunmuyor.'}
              description={
                hasActiveFilter
                  ? 'Seçtiğiniz filtre kriterlerine uygun ekipman bulunmuyor.'
                  : 'Yeni ekipman ekleyerek başlayın.'
              }
              action={hasActiveFilter ? undefined : { label: 'Ekipman Ekle', onClick: handleOpenCreate, icon: 'ri-add-line' }}
            />
          ) : (
            <>
              <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
                <p className="text-xs text-foreground-500">
                  Toplam <span className="font-semibold text-foreground-800">{count}</span> ekipman
                </p>
                {selectedVisible.length > 0 && (
                  <Button variant="danger" size="sm" leftIcon={<i className="ri-delete-bin-line" />} isLoading={bulkBusy} onClick={handleTopluSil}>
                    Seçilenleri Sil ({selectedVisible.length})
                  </Button>
                )}
              </div>
              <div className="overflow-x-auto">
                <Table
                  data={rows}
                  columns={columns}
                  keyExtractor={(r) => r.id}
                  selectable
                  selectedKeys={selectedKeys}
                  onSelectionChange={setSelectedKeys}
                  sortKey={sortKey}
                  sortDirection={sortDir}
                  onSort={handleSort}
                  onRowClick={(row) => { if (!row.deletedAt) handleOpenDetail(row); }}
                  rowActions={(row) => row.deletedAt ? (
                    <IconButton
                      icon={<i className="ri-refresh-line" />}
                      variant="ghost"
                      size="sm"
                      disabled={busyId === row.id}
                      label="Yeniden Aktifleştir"
                      onClick={() => handleRestore(row)}
                    />
                  ) : (
                    <div className="flex items-center gap-1">
                      <IconButton
                        icon={<i className="ri-eye-line" />}
                        variant="ghost"
                        size="sm"
                        label="Detay"
                        onClick={() => handleOpenDetail(row)}
                      />
                      <IconButton
                        icon={<i className="ri-delete-bin-line" />}
                        variant="ghost"
                        size="sm"
                        disabled={busyId === row.id}
                        label="Sil"
                        onClick={() => handleSil(row)}
                      />
                    </div>
                  )}
                  mobileCardRenderer={(row) => (
                    <MobileEkipmanCard row={row} onDetail={handleOpenDetail} onSil={handleSil} onRestore={handleRestore} busy={busyId === row.id} />
                  )}
                />
              </div>
              <div className="mt-3 pt-3 border-t isg-divider">
                <Pagination
                  currentPage={page}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={count}
                  onPageChange={setPage}
                  onPageSizeChange={(size) => {
                    setPageSize(size);
                    setPage(1);
                  }}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}