import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import useSWR from 'swr';
import { useAuth } from '@/context/AuthContext';
import { useModalActions } from '@/hooks/useModal';
import KontrolEkleModal from '@/components/feature/ekipman/KontrolEkleModal';
import {
  type EkipmanQrData,
  type EkipmanKontrol,
  type EkipmanBelge,
  type EkipmanBakim,
  type EkipmanKatalog,
  fetchEkipmanBolum,
  fetchEkipmanKatalog,
  getBelgeUrl,
  mevzuatKuraliForTur,
  friendlyEkipmanError,
} from '@/lib/ekipmanService';
import type { QrBolum } from './QrOrtak';
import MobilOzet from './MobilOzet';
import MobilGenelBilgiler, { type GorselKaydi } from './MobilGenelBilgiler';
import MobilKontrolBolumu from './MobilKontrolBolumu';
import MobilBelgelerBolumu from './MobilBelgelerBolumu';
import MobilGorsellerBolumu from './MobilGorsellerBolumu';
import MobilBakimBolumu from './MobilBakimBolumu';
import MobilNotBolumu from './MobilNotBolumu';

const ALT_MENU: { key: QrBolum; label: string; icon: string }[] = [
  { key: 'genel', label: 'Genel Bilgiler', icon: 'ri-file-list-3-line' },
  { key: 'kontroller', label: 'Kontrol Kayıtları', icon: 'ri-clipboard-line' },
  { key: 'belgeler', label: 'Belgeler', icon: 'ri-folder-2-line' },
  { key: 'gorseller', label: 'Görseller', icon: 'ri-image-2-line' },
];

const BOLUM_BASLIK: Record<Exclude<QrBolum, 'ozet'>, string> = {
  genel: 'Genel Bilgiler',
  kontroller: 'Periyodik Kontrol Kayıtları',
  belgeler: 'Belgeler',
  gorseller: 'Görseller',
  bakimlar: 'Bakım Kayıtları',
  not: 'Not',
};

function homeForRole(role: string): string {
  switch (role) {
    case 'admin': return '/';
    case 'osgb_admin': return '/osgb-panel/genel-bakis';
    case 'firma': return '/firma/genel-bakis';
    case 'uzman': return '/uzman/genel-bakis';
    case 'hekim': return '/hekim/genel-bakis';
    default: return '/login';
  }
}

/**
 * MOBİL EKİPMAN GÖRÜNÜMÜ (QR sonrası).
 * Ana ekran kompakt ve kaydırmasızdır; detay bölümleri kullanıcı dokununca
 * TEMBEL yüklenir (kullanıcı "Belgeler"e basmadıysa belgeler çekilmez).
 * QR / Barkod kartı BURADA YOKTUR — kullanıcı QR'ı zaten okutmuştur.
 */
export default function MobilEkipmanGorunumu({ data }: { data: EkipmanQrData }) {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const { openModal, closeModal } = useModalActions();

  const [veri, setVeri] = useState<EkipmanQrData>(data);
  useEffect(() => { setVeri(data); }, [data]);

  const [bolum, setBolum] = useState<QrBolum>('ozet');

  const [kontroller, setKontroller] = useState<EkipmanKontrol[] | null>(null);
  const [kontrolLoading, setKontrolLoading] = useState(false);
  const [kontrolError, setKontrolError] = useState('');

  const [belgeler, setBelgeler] = useState<EkipmanBelge[] | null>(null);
  const [belgeLoading, setBelgeLoading] = useState(false);
  const [belgeError, setBelgeError] = useState('');

  const [gorseller, setGorseller] = useState<GorselKaydi[] | null>(null);
  const [gorselLoading, setGorselLoading] = useState(false);
  const [gorselError, setGorselError] = useState('');

  const [bakimlar, setBakimlar] = useState<EkipmanBakim[] | null>(null);
  const [bakimLoading, setBakimLoading] = useState(false);
  const [bakimError, setBakimError] = useState('');

  const kontrolModalRef = useRef('');
  const yuklenenRef = useRef<Set<QrBolum>>(new Set());

  // Katalog yalnızca gerektiğinde (belgeler bölümü veya kontrol ekleme) çekilir.
  const katalogKey = bolum === 'belgeler' || (bolum === 'kontroller' && veri.duzenleyebilir) ? 'ekipman-katalog' : null;
  const { data: katalog } = useSWR<EkipmanKatalog>(katalogKey, fetchEkipmanKatalog);

  const loadKontroller = useCallback(() => {
    setKontrolLoading(true);
    setKontrolError('');
    fetchEkipmanBolum(veri.id, 'kontroller')
      .then((d) => setKontroller(d.kontroller))
      .catch((e) => setKontrolError(friendlyEkipmanError(e)))
      .finally(() => setKontrolLoading(false));
  }, [veri.id]);

  const loadBelgeler = useCallback(() => {
    setBelgeLoading(true);
    setBelgeError('');
    fetchEkipmanBolum(veri.id, 'belgeler')
      .then((d) => setBelgeler(d.belgeler))
      .catch((e) => setBelgeError(friendlyEkipmanError(e)))
      .finally(() => setBelgeLoading(false));
  }, [veri.id]);

  const loadBakimlar = useCallback(() => {
    setBakimLoading(true);
    setBakimError('');
    fetchEkipmanBolum(veri.id, 'bakimlar')
      .then((d) => setBakimlar(d.bakimlar))
      .catch((e) => setBakimError(friendlyEkipmanError(e)))
      .finally(() => setBakimLoading(false));
  }, [veri.id]);

  const loadGorseller = useCallback(() => {
    setGorselLoading(true);
    setGorselError('');
    fetchEkipmanBolum(veri.id, 'fotograflar')
      .then(async (d) => {
        const list = await Promise.all(
          d.belgeler.map(async (b) => {
            try {
              const url = await getBelgeUrl(b.id, 'view');
              return { belge: b, url };
            } catch {
              return { belge: b, url: '' };
            }
          }),
        );
        setGorseller(list.filter((g) => g.url));
      })
      .catch((e) => setGorselError(friendlyEkipmanError(e)))
      .finally(() => setGorselLoading(false));
  }, [veri.id]);

  // Bölüm açılınca TEMBEL yükleme — bir kez. Hata olursa kullanıcı "Tekrar Dene" ile tetikler.
  useEffect(() => {
    const yukle = (b: QrBolum, fn: () => void) => {
      if (!yuklenenRef.current.has(b)) {
        yuklenenRef.current.add(b);
        fn();
      }
    };
    if (bolum === 'kontroller') yukle('kontroller', loadKontroller);
    if (bolum === 'belgeler') yukle('belgeler', loadBelgeler);
    if (bolum === 'bakimlar') yukle('bakimlar', loadBakimlar);
    if (bolum === 'gorseller' || bolum === 'genel') yukle('gorseller', loadGorseller);
  }, [bolum, loadKontroller, loadBelgeler, loadBakimlar, loadGorseller]);

  const handleYeniKontrol = useCallback(() => {
    const kural = katalog ? mevzuatKuraliForTur(katalog, veri.ekipmanTuruId) : null;
    const id = openModal({
      title: 'Periyodik Kontrol Ekle',
      description: veri.ekipmanNo,
      variant: 'form',
      width: 640,
      minWidth: 380,
      minHeight: 420,
      bodyLayout: 'fill',
      showFooter: false,
      closable: true,
      resizable: true,
      content: (
        <KontrolEkleModal
          ekipmanId={veri.id}
          kural={kural}
          onClose={() => closeModal(kontrolModalRef.current)}
          onSaved={() => {
            yuklenenRef.current.delete('kontroller');
            loadKontroller();
          }}
        />
      ),
    });
    kontrolModalRef.current = id;
  }, [katalog, veri.ekipmanTuruId, veri.ekipmanNo, veri.id, openModal, closeModal, loadKontroller]);

  const handlePaneleDon = useCallback(() => {
    navigate(homeForRole(profile?.role ?? ''), { replace: true });
  }, [navigate, profile]);

  const altMenu = useMemo(() => ALT_MENU, []);

  return (
    <div className="min-h-mobile-full bg-background-50 flex justify-center">
      <div className="relative w-full max-w-[520px] h-mobile-full flex flex-col bg-background-50 sm:border-x sm:border-background-300/40">
        {/* ── BAŞLIK ── */}
        <header className="isg-topbar flex-shrink-0 flex items-center gap-2.5 px-3 border-b border-background-300/30 dark:border-background-400/25 bg-background-100 dark:bg-background-200/60">
          {bolum === 'ozet' ? (
            <>
              <span className="w-8 h-8 rounded-lg bg-primary-500 flex items-center justify-center flex-shrink-0">
                <i className="ri-shield-check-line text-inverse text-base" />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold text-foreground-950 leading-tight truncate">İSGDenetim</p>
                <p className="text-[10px] text-foreground-500 leading-tight truncate">İş Sağlığı ve Güvenliği</p>
              </div>
              <button
                type="button"
                onClick={handlePaneleDon}
                aria-label="Panele dön"
                title="Panele Dön"
                className="w-8 h-8 rounded-md flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer flex-shrink-0"
              >
                <i className="ri-home-4-line" />
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => setBolum('ozet')}
                aria-label="Geri"
                className="w-8 h-8 -ml-1 rounded-md flex items-center justify-center text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer flex-shrink-0"
              >
                <i className="ri-arrow-left-line text-lg" />
              </button>
              <h1 className="flex-1 min-w-0 text-sm font-semibold text-foreground-950 truncate">{BOLUM_BASLIK[bolum]}</h1>
              {bolum === 'kontroller' && veri.duzenleyebilir && (
                <button
                  type="button"
                  onClick={handleYeniKontrol}
                  className="inline-flex items-center gap-1 h-8 px-2.5 rounded-md bg-primary-500 text-inverse text-xs font-medium hover:bg-primary-600 transition-colors cursor-pointer whitespace-nowrap flex-shrink-0"
                >
                  <i className="ri-add-line" />
                  Yeni Kontrol
                </button>
              )}
            </>
          )}
        </header>

        {/* ── İÇERİK ── */}
        <main className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane">
          {bolum === 'ozet' && <MobilOzet data={veri} onBolum={setBolum} />}
          {bolum === 'genel' && (
            <MobilGenelBilgiler
              data={veri}
              gorseller={gorseller ?? []}
              gorselLoading={gorselLoading}
              onBolum={setBolum}
            />
          )}
          {bolum === 'kontroller' && (
            <MobilKontrolBolumu
              data={veri}
              kontroller={kontroller}
              loading={kontrolLoading}
              error={kontrolError}
              onReload={() => { yuklenenRef.current.delete('kontroller'); loadKontroller(); }}
            />
          )}
          {bolum === 'belgeler' && (
            <MobilBelgelerBolumu
              data={veri}
              belgeler={belgeler}
              loading={belgeLoading}
              error={belgeError}
              onReload={() => { yuklenenRef.current.delete('belgeler'); loadBelgeler(); }}
            />
          )}
          {bolum === 'gorseller' && (
            <MobilGorsellerBolumu
              gorseller={gorseller ?? []}
              loading={gorselLoading}
              error={gorselError}
              onReload={() => { yuklenenRef.current.delete('gorseller'); loadGorseller(); }}
            />
          )}
          {bolum === 'bakimlar' && (
            <MobilBakimBolumu
              bakimlar={bakimlar}
              loading={bakimLoading}
              error={bakimError}
              onReload={() => { yuklenenRef.current.delete('bakimlar'); loadBakimlar(); }}
            />
          )}
          {bolum === 'not' && (
            <MobilNotBolumu data={veri} onSaved={(not) => setVeri((p) => ({ ...p, aciklama: not }))} />
          )}
        </main>

        {/* ── ALT MENÜ (yalnızca ana ekran) ── */}
        {bolum === 'ozet' && (
          <nav
            className="isg-bottom-nav flex-shrink-0 grid grid-cols-4 border-t border-background-300/30 dark:border-background-400/25 bg-background-100 dark:bg-background-200/60"
            style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
            aria-label="Ekipman bölümleri"
          >
            {altMenu.map((m) => (
              <button
                key={m.key}
                type="button"
                onClick={() => setBolum(m.key)}
                className="flex flex-col items-center justify-center gap-1 py-2.5 text-foreground-500 hover:text-primary-600 dark:hover:text-primary-400 transition-colors cursor-pointer"
              >
                <i className={`${m.icon} text-lg`} />
                <span className="text-[10px] font-medium">{m.label}</span>
              </button>
            ))}
          </nav>
        )}
      </div>
    </div>
  );
}