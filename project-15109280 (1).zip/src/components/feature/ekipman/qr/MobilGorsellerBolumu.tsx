import ImageViewer from '@/components/ui/ImageViewer';
import type { ImageViewerItem } from '@/components/ui/ImageViewer';
import Button from '@/components/ui/Button';
import { QrKart, QrBos, QrYukleniyor, formatQrDateTime } from './QrOrtak';
import type { GorselKaydi } from './MobilGenelBilgiler';

/** GÖRSELLER (referans 5) — ana görsel + galeri; tıklayınca merkezi önizleme açılır. */
export default function MobilGorsellerBolumu({
  gorseller,
  loading,
  error,
  onReload,
}: {
  gorseller: GorselKaydi[];
  loading: boolean;
  error: string;
  onReload: () => void;
}) {
  const galeri: ImageViewerItem[] = gorseller.map((g) => ({
    src: g.url,
    alt: g.belge.dosyaAdi,
    fileName: g.belge.dosyaAdi,
  }));
  const ana = gorseller[0] ?? null;
  const digerleri = gorseller.slice(1);

  return (
    <div className="space-y-3 p-3 pb-5">
      <QrKart title={`Görseller${gorseller.length > 0 ? ` (${gorseller.length})` : ''}`} icon="ri-image-2-line">
        {loading ? (
          <QrYukleniyor text="Görseller yükleniyor…" />
        ) : error ? (
          <div className="text-center py-6">
            <p className="text-xs text-danger-600 mb-2">{error}</p>
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={onReload}>Tekrar Dene</Button>
          </div>
        ) : !ana ? (
          <QrBos icon="ri-image-line" text="Bu ekipman için görsel bulunmuyor." />
        ) : (
          <div className="space-y-3">
            <ImageViewer
              src={ana.url}
              alt={ana.belge.dosyaAdi}
              fileName={ana.belge.dosyaAdi}
              gallery={galeri}
              index={0}
              showHoverIcon
              wrapperClassName="block w-full"
              imgClassName="w-full h-52 rounded-lg object-cover object-top border border-background-300/30 dark:border-background-400/25"
            />
            {digerleri.length > 0 && (
              <div className="grid grid-cols-3 gap-2">
                {digerleri.map((g, i) => (
                  <ImageViewer
                    key={g.belge.id}
                    src={g.url}
                    alt={g.belge.dosyaAdi}
                    fileName={g.belge.dosyaAdi}
                    gallery={galeri}
                    index={i + 1}
                    showHoverIcon
                    wrapperClassName="block w-full aspect-square rounded-lg overflow-hidden border border-background-300/30 dark:border-background-400/25"
                    imgClassName="w-full h-full object-cover object-top"
                  />
                ))}
              </div>
            )}
            <p className="text-[11px] text-foreground-400 flex items-center gap-1">
              <i className="ri-calendar-line" />
              Yükleme: {formatQrDateTime(ana.belge.createdAt)}
            </p>
          </div>
        )}
      </QrKart>
    </div>
  );
}