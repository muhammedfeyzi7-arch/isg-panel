import type { ReactNode } from 'react';
import type { EkipmanKontrolDurumu, EkipmanKullanimDurumu } from '@/lib/ekipmanService';
import StatusBadge, { type StatusTone } from '@/components/ui/StatusBadge';

/** QR mobil görünümünde açılabilen bölümler. */
export type QrBolum = 'ozet' | 'genel' | 'kontroller' | 'belgeler' | 'gorseller' | 'bakimlar' | 'not';

export type QrTone = 'success' | 'warning' | 'danger' | 'primary' | 'neutral';

const TONE_CLS: Record<QrTone, string> = {
  success: 'bg-success-100 text-success-700 dark:bg-success-500/15 dark:text-success-400',
  warning: 'bg-warning-100 text-warning-700 dark:bg-warning-500/15 dark:text-warning-400',
  danger: 'bg-danger-100 text-danger-700 dark:bg-danger-500/15 dark:text-danger-400',
  primary: 'bg-primary-100 text-primary-700 dark:bg-primary-500/15 dark:text-primary-400',
  neutral: 'bg-background-200 text-foreground-600 dark:bg-background-300/40 dark:text-foreground-500',
};

export function qrToneClass(tone: QrTone): string {
  return TONE_CLS[tone];
}

/** Kompakt durum badge'i — SharedUI StatusBadge'e delege eder (TEK rozet dili). */
export function QrBadge({ tone = 'neutral', icon, children }: { tone?: QrTone; icon?: string; children: ReactNode }) {
  const mapped: StatusTone = tone === 'primary' ? 'info' : tone;
  return (
    <StatusBadge tone={mapped} icon={icon ? <i className={icon} /> : undefined}>
      {children}
    </StatusBadge>
  );
}

export function qrKontrolTone(d: EkipmanKontrolDurumu): QrTone {
  switch (d) {
    case 'gelecek': return 'success';
    case 'bugun': return 'warning';
    case 'gecmis': return 'danger';
    default: return 'neutral';
  }
}

export function qrKullanimTone(d: EkipmanKullanimDurumu | string): QrTone {
  switch (d) {
    case 'aktif': return 'success';
    case 'arizali': return 'danger';
    case 'bakimda': return 'warning';
    default: return 'neutral';
  }
}

export function qrKullanimIcon(d: EkipmanKullanimDurumu | string): string {
  switch (d) {
    case 'aktif': return 'ri-checkbox-circle-line';
    case 'arizali': return 'ri-alert-line';
    case 'bakimda': return 'ri-tools-line';
    case 'kullanim_disi': return 'ri-pause-circle-line';
    default: return 'ri-tools-line';
  }
}

export function qrSonucTone(sonuc: string | null | undefined): QrTone {
  if (!sonuc) return 'neutral';
  const s = sonuc.toLocaleLowerCase('tr');
  if (s.includes('ağır') || s.includes('agir')) return 'danger';
  if (s.includes('uygun')) return 'success';
  return 'warning';
}

const AY_UZUN = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];

/** "17 Eylül 2026" — DATE (YYYY-MM-DD); timezone kayması olmadan. */
export function formatQrDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return '—';
  return `${d} ${AY_UZUN[m - 1]} ${y}`;
}

/** "17 Eylül 2026 15:23" — tam zaman damgası. */
export function formatQrDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return '—';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${dt.getDate()} ${AY_UZUN[dt.getMonth()]} ${dt.getFullYear()} ${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
}

/** Kompakt kart — başlık şeridi + gövde. Tüm mobil bölümler aynı kabuğu kullanır. */
export function QrKart({ title, icon, action, children }: { title: string; icon: string; action?: ReactNode; children: ReactNode }) {
  return (
    <section className="isg-card overflow-hidden">
      <div className="flex items-center justify-between gap-2 px-3.5 py-2.5 border-b isg-divider">
        <div className="flex items-center gap-2 min-w-0">
          <i className={`${icon} text-primary-600 dark:text-primary-400 text-base`} />
          <h3 className="text-sm font-semibold text-foreground-950 truncate">{title}</h3>
        </div>
        {action}
      </div>
      <div className="px-3.5 py-3">{children}</div>
    </section>
  );
}

/** Etiket / değer satırı. */
export function QrSatir({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 py-2 border-b isg-divider last:border-0">
      <span className="text-xs text-foreground-500 flex-shrink-0 pt-0.5">{label}</span>
      <span className="text-sm font-medium text-foreground-800 text-right break-words min-w-0">{value}</span>
    </div>
  );
}

/** Dokunulabilir alt bölüm satırı (chevron + isteğe bağlı sayaç). */
export function QrTus({
  icon,
  label,
  count,
  onClick,
}: {
  icon: string;
  label: string;
  count?: number;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg bg-background-100 dark:bg-background-200/40 border border-background-300/25 dark:border-background-400/20 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer text-left"
    >
      <span className="w-8 h-8 rounded-lg bg-primary-100 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
        <i className={`${icon} text-primary-600 dark:text-primary-400`} />
      </span>
      <span className="flex-1 min-w-0 text-sm font-medium text-foreground-800 truncate">{label}</span>
      {typeof count === 'number' && <span className="text-xs text-foreground-500">({count})</span>}
      <i className="ri-arrow-right-s-line text-foreground-400 text-lg" />
    </button>
  );
}

/** Küçük boş durum. */
export function QrBos({ icon, text }: { icon: string; text: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-1.5 py-8 text-center">
      <i className={`${icon} text-2xl text-foreground-400`} />
      <p className="text-xs text-foreground-500">{text}</p>
    </div>
  );
}

/** Bölüm yükleme görünümü. */
export function QrYukleniyor({ text = 'Yükleniyor…' }: { text?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-10">
      <span className="inline-block w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
      <span className="text-xs text-foreground-500">{text}</span>
    </div>
  );
}