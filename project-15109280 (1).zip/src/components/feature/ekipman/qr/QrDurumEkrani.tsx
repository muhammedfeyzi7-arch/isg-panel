import Button from '@/components/ui/Button';

export type QrDurumVariant = 'yukleniyor' | 'giris' | 'yetkisiz' | 'hata';

interface QrDurumEkraniProps {
  variant: QrDurumVariant;
  onPrimary?: () => void;
  onSecondary?: () => void;
}

interface QrDurumIcerik {
  icon: string;
  tone: string;
  title: string;
  description: string;
  primary?: string;
  secondary?: string;
}

const ICERIK: Record<Exclude<QrDurumVariant, 'yukleniyor'>, QrDurumIcerik> = {
  giris: {
    icon: 'ri-lock-2-line',
    tone: 'bg-primary-100 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400',
    title: 'Erişim Gerekli',
    description: 'Bu ekipmanın bilgilerini görüntülemek için yetkili İSGDenetim hesabınızla giriş yapmanız gerekir.',
    primary: 'Giriş Yap',
  },
  yetkisiz: {
    icon: 'ri-shield-cross-line',
    tone: 'bg-danger-100 dark:bg-danger-500/15 text-danger-600 dark:text-danger-400',
    title: 'Erişim Yetkiniz Yok',
    description: 'Bu ekipman, erişim yetkinizin bulunmadığı bir firmaya bağlıdır.',
    primary: 'Firmalarıma Dön',
  },
  hata: {
    icon: 'ri-wifi-off-line',
    tone: 'bg-warning-100 dark:bg-warning-500/15 text-warning-600 dark:text-warning-400',
    title: 'Erişim Doğrulanamadı',
    description: 'Ekipman erişimi şu anda doğrulanamadı. Lütfen bağlantınızı kontrol edip tekrar deneyin.',
    primary: 'Tekrar Dene',
    secondary: 'Firmalarıma Dön',
  },
};

/**
 * QR ERİŞİM KAPISI EKRANI — oturum/yetki yoksa gösterilir.
 * QR kodunun TEK BAŞINA bilgi açması yasaktır; bu ekranlar yalnızca durum
 * mesajı ve yönlendirme sunar, hiçbir ekipman verisi göstermez.
 */
export default function QrDurumEkrani({ variant, onPrimary, onSecondary }: QrDurumEkraniProps) {
  return (
    <div className="min-h-mobile-full flex items-center justify-center bg-background-50 px-4 py-10">
      <div className="w-full max-w-[420px]">
        <div className="isg-card p-6 text-center">
          {variant === 'yukleniyor' ? (
            <>
              <div className="flex justify-center mb-4">
                <span className="inline-block w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
              </div>
              <h1 className="text-base font-semibold text-foreground-950">Erişim doğrulanıyor…</h1>
              <p className="text-sm text-foreground-500 mt-1.5">
                Oturumunuz ve bu ekipmana erişim yetkiniz kontrol ediliyor.
              </p>
            </>
          ) : (
            <>
              <div className="flex justify-center mb-4">
                <span className={`w-14 h-14 rounded-2xl flex items-center justify-center ${ICERIK[variant].tone}`}>
                  <i className={`${ICERIK[variant].icon} text-2xl`} />
                </span>
              </div>
              <h1 className="text-base font-semibold text-foreground-950">{ICERIK[variant].title}</h1>
              <p className="text-sm text-foreground-500 mt-1.5">{ICERIK[variant].description}</p>

              {ICERIK[variant].primary && onPrimary && (
                <div className="mt-5">
                  <Button variant="primary" fullWidth leftIcon={<i className="ri-arrow-right-line" />} onClick={onPrimary}>
                    {ICERIK[variant].primary}
                  </Button>
                </div>
              )}
              {ICERIK[variant].secondary && onSecondary && (
                <div className="mt-2">
                  <Button variant="ghost" fullWidth onClick={onSecondary}>
                    {ICERIK[variant].secondary}
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
        <p className="text-center text-[11px] text-foreground-400 mt-4">
          <i className="ri-shield-check-line mr-1" />
          Ekipman bilgilerine erişim yalnızca yetkili oturumla mümkündür.
        </p>
      </div>
    </div>
  );
}