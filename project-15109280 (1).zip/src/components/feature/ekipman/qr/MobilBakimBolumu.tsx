import Button from '@/components/ui/Button';
import type { EkipmanBakim } from '@/lib/ekipmanService';
import { QrKart, QrBos, QrYukleniyor, formatQrDate } from './QrOrtak';

/** BAKIM KAYITLARI — kompakt kayıt listesi. */
export default function MobilBakimBolumu({
  bakimlar,
  loading,
  error,
  onReload,
}: {
  bakimlar: EkipmanBakim[] | null;
  loading: boolean;
  error: string;
  onReload: () => void;
}) {
  return (
    <div className="space-y-3 p-3 pb-5">
      <QrKart title={`Bakım Kayıtları${bakimlar ? ` (${bakimlar.length})` : ''}`} icon="ri-tools-line">
        {loading ? (
          <QrYukleniyor text="Bakım kayıtları yükleniyor…" />
        ) : error ? (
          <div className="text-center py-6">
            <p className="text-xs text-danger-600 mb-2">{error}</p>
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={onReload}>Tekrar Dene</Button>
          </div>
        ) : !bakimlar || bakimlar.length === 0 ? (
          <QrBos icon="ri-tools-line" text="Bu ekipman için henüz bakım kaydı bulunmuyor." />
        ) : (
          <div className="space-y-2">
            {bakimlar.map((m) => (
              <div key={m.id} className="rounded-lg border border-background-300/25 dark:border-background-400/20 bg-background-100 dark:bg-background-200/40 p-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-medium text-foreground-900 truncate">{m.bakimTuru || 'Bakım'}</p>
                  <span className="text-xs text-foreground-500 flex-shrink-0">{formatQrDate(m.bakimTarihi)}</span>
                </div>
                {m.yapilanIslem && <p className="text-sm text-foreground-700 mt-1 break-words">{m.yapilanIslem}</p>}
                {m.aciklama && <p className="text-xs text-foreground-600 mt-1 break-words">{m.aciklama}</p>}
                {m.bakimYapan && <p className="text-[11px] text-foreground-500 mt-1">Yapan: {m.bakimYapan}</p>}
                {m.sonrakiBakimTarihi && <p className="text-[11px] text-foreground-500">Sonraki bakım: {formatQrDate(m.sonrakiBakimTarihi)}</p>}
              </div>
            ))}
          </div>
        )}
      </QrKart>
    </div>
  );
}