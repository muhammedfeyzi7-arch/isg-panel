import type { EkipmanQrData } from '@/lib/ekipmanService';
import { periyotMetni } from '@/components/feature/ekipman/ekipmanUi';
import {
  QrBadge,
  qrKullanimTone,
  qrKullanimIcon,
  qrKontrolTone,
  formatQrDate,
  qrToneClass,
  type QrBolum,
} from './QrOrtak';

/** ANA EKRAN (referans 1) — kompakt, kaydırmasız özet + durum kartı. */
export default function MobilOzet({ data, onBolum }: { data: EkipmanQrData; onBolum: (b: QrBolum) => void }) {
  const kontrolTone = qrKontrolTone(data.kontrolDurumu);

  const durumBaslik = data.sonKontrolSonuc
    ? data.sonKontrolSonuc
    : data.kontrolDurumu === 'yok'
      ? 'Kontrol Kaydı Yok'
      : data.kontrolDurumu === 'gecmis'
        ? 'Kontrol Süresi Geçti'
        : 'Kontrol Uygun';

  const durumAlt = data.kontrolDurumu === 'gelecek'
    ? `Kontrole ${data.kontrolDurumuLabel}`
    : data.kontrolDurumu === 'bugun'
      ? 'Bugün kontrol zamanı'
      : data.kontrolDurumu === 'gecmis'
        ? `Kontrol süresi ${data.kontrolDurumuLabel}`
        : 'Periyodik kontrol kaydı bulunmuyor';

  const periyot = periyotMetni(data.kontrolPeriyodu);

  return (
    <div className="pb-4">
      {/* Kapak görsel */}
      <div className="px-3 pt-3">
        <button
          type="button"
          onClick={() => onBolum('gorseller')}
          className="group relative w-full h-40 rounded-lg overflow-hidden border border-background-300/30 dark:border-background-400/25 bg-background-200 dark:bg-background-300/40 cursor-pointer"
          aria-label="Ekipman görsellerini aç"
        >
          {data.kapakGorsel?.url ? (
            <img src={data.kapakGorsel.url} alt={data.ad} className="w-full h-full object-cover object-top" />
          ) : (
            <span className="absolute inset-0 flex flex-col items-center justify-center gap-1">
              <i className="ri-image-line text-2xl text-foreground-400" />
              <span className="text-[11px] text-foreground-400">Ekipman görseli yok</span>
            </span>
          )}
          <span className="absolute top-2.5 left-2.5">
            <QrBadge tone={qrKullanimTone(data.kullanimDurumu)} icon={qrKullanimIcon(data.kullanimDurumu)}>
              {data.kullanimDurumuLabel}
            </QrBadge>
          </span>
          <span className="absolute top-2.5 right-2.5 w-7 h-7 rounded-md bg-black/50 flex items-center justify-center">
            <i className="ri-expand-diagonal-line text-white text-sm" />
          </span>
          {data.sayilar.gorsel > 0 && (
            <span className="absolute bottom-2.5 right-2.5 inline-flex items-center gap-1 rounded-full bg-black/60 px-2 py-0.5 text-[11px] font-medium text-white">
              <i className="ri-image-2-line" />
              {data.sayilar.gorsel}
            </span>
          )}
        </button>
      </div>

      {/* Başlık + kod */}
      <div className="px-3.5 pt-3">
        <h1 className="text-lg font-bold text-foreground-950 leading-tight break-words">{data.ad}</h1>
        <p className="text-sm text-foreground-500 mt-0.5 font-mono">{data.ekipmanNo}</p>
      </div>

      {/* Tür / Grup */}
      <div className="grid grid-cols-2 gap-3 px-3.5 pt-3.5">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="w-9 h-9 rounded-lg bg-primary-100 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-tools-line text-primary-600 dark:text-primary-400" />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-foreground-900 truncate">{data.turAd}</p>
            <p className="text-[11px] text-foreground-500">Ekipman Türü</p>
          </div>
        </div>
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="w-9 h-9 rounded-lg bg-secondary-100 dark:bg-secondary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-apps-2-line text-secondary-600 dark:text-secondary-400" />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-semibold text-foreground-900 truncate">{data.grupAd}</p>
            <p className="text-[11px] text-foreground-500">Ekipman Grubu</p>
          </div>
        </div>
      </div>

      {/* Periyodik kontrol kartı */}
      <div className="px-3.5 pt-3.5">
        <button
          type="button"
          onClick={() => onBolum('kontroller')}
          className="w-full text-left rounded-lg border border-background-300/30 dark:border-background-400/25 bg-background-100 dark:bg-background-200/40 p-3.5 cursor-pointer transition-colors hover:bg-background-200 dark:hover:bg-background-300/40"
        >
          <div className="flex items-center gap-2">
            <i className="ri-calendar-check-line text-foreground-500" />
            <span className="text-xs font-medium text-foreground-600">Periyodik Kontrol</span>
          </div>

          <div className="mt-2.5 flex items-center gap-2">
            <span className={`w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 ${qrToneClass(kontrolTone)}`}>
              <i className={data.kontrolDurumu === 'gecmis' ? 'ri-close-line' : 'ri-check-line'} />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-bold text-foreground-950 truncate">{durumBaslik}</p>
              <p className="text-xs text-foreground-500">{durumAlt}</p>
            </div>
          </div>

          <div className="mt-3 pt-3 border-t isg-divider grid grid-cols-2 gap-3">
            <div className="min-w-0">
              <p className="text-[11px] text-foreground-500 flex items-center gap-1">
                <i className="ri-calendar-line" /> Son Kontrol Tarihi
              </p>
              <p className="text-sm font-semibold text-foreground-900 mt-0.5">{formatQrDate(data.sonKontrolTarihi)}</p>
            </div>
            <div className="min-w-0">
              <p className="text-[11px] text-foreground-500 flex items-center gap-1">
                <i className="ri-calendar-2-line" /> Sonraki Kontrol Tarihi
              </p>
              <p className="text-sm font-semibold text-foreground-900 mt-0.5">{formatQrDate(data.sonrakiKontrolTarihi)}</p>
            </div>
          </div>

          {periyot && (
            <p className="mt-2.5 text-[11px] text-foreground-500 flex items-center gap-1">
              <i className="ri-repeat-line" /> Kontrol Periyodu: <span className="font-medium text-foreground-700">{periyot}</span>
            </p>
          )}
        </button>
      </div>
    </div>
  );
}