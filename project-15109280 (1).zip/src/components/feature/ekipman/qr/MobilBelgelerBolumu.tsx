import useSWR from 'swr';
import Button from '@/components/ui/Button';
import StatusBadge from '@/components/ui/StatusBadge';
import BelgeEylemleri from '@/components/feature/ekipman/BelgeEylemleri';
import {
  type EkipmanQrData,
  type EkipmanBelge,
  type EkipmanKatalog,
  fetchEkipmanKatalog,
  mevzuatKuraliForTur,
} from '@/lib/ekipmanService';
import { belgeGorunum, formatFileSize } from '@/components/feature/ekipman/ekipmanUi';
import { QrKart, QrBos, QrYukleniyor, formatQrDate } from './QrOrtak';

/** BELGELER (referans 4) — gerekli belgeler + yüklü belgeler listesi. */
export default function MobilBelgelerBolumu({
  data,
  belgeler,
  loading,
  error,
  onReload,
}: {
  data: EkipmanQrData;
  belgeler: EkipmanBelge[] | null;
  loading: boolean;
  error: string;
  onReload: () => void;
}) {
  // Merkezi katalog (SWR dedup + cache) — yalnızca gerekli belge türleri için.
  const { data: katalog } = useSWR<EkipmanKatalog>('ekipman-katalog', fetchEkipmanKatalog);
  const kural = katalog ? mevzuatKuraliForTur(katalog, data.ekipmanTuruId) : null;
  const gereksinimler = kural?.belgeKurallari ?? [];

  const dokumanBelgeler = (belgeler ?? []).filter((b) => !(b.mimeType ?? '').toLowerCase().startsWith('image/'));

  return (
    <div className="space-y-3 p-3 pb-5">
      <div className="flex items-start gap-2 rounded-lg border border-primary-200/50 bg-primary-50/50 dark:bg-primary-500/10 dark:border-primary-500/25 p-3">
        <i className="ri-information-line text-primary-600 dark:text-primary-400 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-foreground-600 dark:text-foreground-500">
          Bu ekipman türü için önerilen belgeler aşağıda listelenmiştir. Belgeleri yükleyerek kayıt altına alabilirsiniz.
        </p>
      </div>

      {gereksinimler.length > 0 && (
        <QrKart title="Gerekli Belgeler" icon="ri-folder-shield-2-line">
          <div className="flex flex-col divide-y divide-background-300/20 dark:divide-background-400/15">
            {gereksinimler.map((g) => (
              <div key={g.code} className="flex items-center gap-2.5 py-2 first:pt-0 last:pb-0">
                <i className={`${g.required ? 'ri-file-warning-line text-danger-500' : 'ri-file-line text-foreground-400'}`} />
                <span className="flex-1 min-w-0 text-sm text-foreground-700 truncate">{g.name}</span>
                <StatusBadge tone={g.required ? 'danger' : 'neutral'}>
                  {g.required ? 'Zorunlu' : 'Opsiyonel'}
                </StatusBadge>
              </div>
            ))}
          </div>
        </QrKart>
      )}

      <QrKart title={`Yüklü Belgeler${belgeler ? ` (${dokumanBelgeler.length})` : ''}`} icon="ri-folder-2-line">
        {loading ? (
          <QrYukleniyor text="Belgeler yükleniyor…" />
        ) : error ? (
          <div className="text-center py-6">
            <p className="text-xs text-danger-600 mb-2">{error}</p>
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={onReload}>Tekrar Dene</Button>
          </div>
        ) : dokumanBelgeler.length === 0 ? (
          <QrBos icon="ri-file-3-line" text="Bu ekipmana ait belge bulunmuyor." />
        ) : (
          <div className="space-y-2">
            {dokumanBelgeler.map((b) => {
              const g = belgeGorunum(b.mimeType);
              return (
                <div key={b.id} className="flex items-center gap-2.5 rounded-lg border border-background-300/25 dark:border-background-400/20 bg-background-100 dark:bg-background-200/40 p-2.5">
                  <span className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${g.tone}`}>
                    <i className={`${g.icon} text-lg`} />
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground-800 truncate">{b.dosyaAdi}</p>
                    <p className="text-[11px] text-foreground-500">
                      {formatFileSize(b.sizeBytes)} · {formatQrDate(b.createdAt)}
                    </p>
                  </div>
                  <BelgeEylemleri belge={b} />
                </div>
              );
            })}
          </div>
        )}
      </QrKart>
    </div>
  );
}