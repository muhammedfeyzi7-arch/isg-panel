import { useState } from 'react';
import Button from '@/components/ui/Button';
import { useToastActions } from '@/hooks/useToast';
import { type EkipmanQrData, updateEkipman, friendlyEkipmanError } from '@/lib/ekipmanService';
import { QrKart } from './QrOrtak';

/** NOT (referans 6) — ekipman notu; yalnızca yetkili kullanıcı kaydedebilir. */
export default function MobilNotBolumu({ data, onSaved }: { data: EkipmanQrData; onSaved: (not: string) => void }) {
  const { addToast } = useToastActions();
  const [not, setNot] = useState(data.aciklama ?? '');
  const [busy, setBusy] = useState(false);

  const dirty = not.trim() !== (data.aciklama ?? '').trim();

  const handleKaydet = () => {
    if (busy || !data.duzenleyebilir) return;
    setBusy(true);
    updateEkipman(data.id, { aciklama: not.trim() })
      .then(() => {
        addToast({ title: 'Kaydedildi', message: 'Ekipman notu güncellendi.', type: 'success' });
        onSaved(not.trim());
      })
      .catch((err) => addToast({ title: 'Kaydedilemedi', message: friendlyEkipmanError(err), type: 'error' }))
      .finally(() => setBusy(false));
  };

  return (
    <div className="space-y-3 p-3 pb-5">
      <QrKart
        title="Not"
        icon="ri-sticky-note-line"
        action={
          data.duzenleyebilir ? (
            <Button variant="primary" size="sm" leftIcon={<i className="ri-save-line" />} isLoading={busy} disabled={!dirty} onClick={handleKaydet}>
              Kaydet
            </Button>
          ) : undefined
        }
      >
        <textarea
          value={not}
          onChange={(e) => setNot(e.target.value)}
          maxLength={500}
          readOnly={!data.duzenleyebilir}
          rows={8}
          placeholder={data.duzenleyebilir ? 'Bu ekipmanla ilgili not ekleyin…' : 'Not bulunmuyor.'}
          className="isg-input w-full resize-none leading-relaxed"
        />
        <p className="mt-1 text-[11px] text-foreground-400 text-right">{not.length}/500</p>
        <p className="mt-1 flex items-start gap-1.5 text-[11px] text-foreground-400">
          <i className="ri-information-line mt-0.5 flex-shrink-0" />
          {data.duzenleyebilir
            ? 'Bu not yalnızca bilgilendirme amaçlıdır.'
            : 'Not ekleme/düzenleme yetkiniz bulunmuyor. Yalnızca görüntüleyebilirsiniz.'}
        </p>
      </QrKart>
    </div>
  );
}