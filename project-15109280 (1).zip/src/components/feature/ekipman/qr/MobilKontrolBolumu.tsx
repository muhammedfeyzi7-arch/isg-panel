import Button from '@/components/ui/Button';
import {
  type EkipmanQrData,
  type EkipmanKontrol,
  mapKontrolMeta,
} from '@/lib/ekipmanService';
import { periyotMetni } from '@/components/feature/ekipman/ekipmanUi';
import {
  QrBadge,
  QrKart,
  QrBos,
  QrYukleniyor,
  qrKontrolTone,
  qrSonucTone,
  qrToneClass,
  formatQrDate,
} from './QrOrtak';

/** PERİYODİK KONTROL KAYITLARI (referans 3) — güncel durum + kontrol geçmişi. */
export default function MobilKontrolBolumu({
  data,
  kontroller,
  loading,
  error,
  onReload,
}: {
  data: EkipmanQrData;
  kontroller: EkipmanKontrol[] | null;
  loading: boolean;
  error: string;
  onReload: () => void;
}) {
  const tone = qrKontrolTone(data.kontrolDurumu);
  const durumBaslik = data.sonKontrolSonuc
    ? data.sonKontrolSonuc
    : data.kontrolDurumu === 'yok'
      ? 'Kontrol Kaydı Yok'
      : data.kontrolDurumu === 'gecmis'
        ? 'Kontrol Süresi Geçti'
        : 'Kontrol Uygun';
  const durumAlt = data.kontrolDurumu === 'gelecek'
    ? `Kontrole ${data.kontrolDurumuLabel}`
    : data.kontrolDurumu === 'bugun'
      ? 'Bugün kontrol zamanı'
      : data.kontrolDurumu === 'gecmis'
        ? `Kontrol süresi ${data.kontrolDurumuLabel}`
        : 'Periyodik kontrol kaydı bulunmuyor';
  const periyot = periyotMetni(data.kontrolPeriyodu);

  return (
    <div className="space-y-3 p-3 pb-5">
      <QrKart title="Güncel Durum" icon="ri-calendar-check-line">
        <div className="flex items-center gap-2.5">
          <span className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${qrToneClass(tone)}`}>
            <i className={data.kontrolDurumu === 'gecmis' ? 'ri-close-line' : 'ri-check-line'} />
          </span>
          <div className="min-w-0">
            <p className="text-base font-bold text-foreground-950 truncate">{durumBaslik}</p>
            <p className="text-xs text-foreground-500">{durumAlt}</p>
          </div>
        </div>

        <div className="mt-3 pt-3 border-t isg-divider grid grid-cols-2 gap-3">
          <div className="min-w-0">
            <p className="text-[11px] text-foreground-500 flex items-center gap-1">
              <i className="ri-calendar-line" /> Son Kontrol
            </p>
            <p className="text-sm font-semibold text-foreground-900 mt-0.5">{formatQrDate(data.sonKontrolTarihi)}</p>
          </div>
          <div className="min-w-0">
            <p className="text-[11px] text-foreground-500 flex items-center gap-1">
              <i className="ri-calendar-2-line" /> Sonraki Kontrol
            </p>
            <p className="text-sm font-semibold text-foreground-900 mt-0.5">{formatQrDate(data.sonrakiKontrolTarihi)}</p>
          </div>
        </div>

        {periyot && (
          <div className="mt-3 pt-3 border-t isg-divider flex items-center justify-between">
            <p className="text-[11px] text-foreground-500 flex items-center gap-1">
              <i className="ri-repeat-line" /> Kontrol Periyodu
            </p>
            <p className="text-sm font-semibold text-foreground-900">{periyot}</p>
          </div>
        )}
      </QrKart>

      <QrKart
        title={`Kontrol Geçmişi${kontroller ? ` (${kontroller.length})` : ''}`}
        icon="ri-history-line"
      >
        {loading ? (
          <QrYukleniyor text="Kontrol kayıtları yükleniyor…" />
        ) : error ? (
          <div className="text-center py-6">
            <p className="text-xs text-danger-600 mb-2">{error}</p>
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={onReload}>Tekrar Dene</Button>
          </div>
        ) : !kontroller || kontroller.length === 0 ? (
          <QrBos icon="ri-clipboard-line" text="Bu ekipman için henüz kontrol kaydı bulunmuyor." />
        ) : (
          <div className="space-y-2">
            {kontroller.map((k) => {
              const meta = mapKontrolMeta(k.metadata);
              return (
                <div key={k.id} className="rounded-lg border border-background-300/25 dark:border-background-400/20 bg-background-100 dark:bg-background-200/40 p-3">
                  <div className="flex items-start gap-2.5">
                    <span className="w-8 h-8 rounded-lg bg-secondary-100 dark:bg-secondary-500/15 flex items-center justify-center flex-shrink-0">
                      <i className="ri-file-text-line text-secondary-600 dark:text-secondary-400" />
                    </span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground-900 truncate">
                        Periyodik kontrol
                      </p>
                      <p className="text-xs text-foreground-500">{formatQrDate(k.kontrolTarihi)}</p>
                      <p className="text-[11px] text-foreground-500 mt-0.5">Sonraki kontrol: {formatQrDate(k.sonrakiKontrolTarihi)}</p>
                      {meta.yetkili ? (
                        <p className="text-[11px] text-foreground-500 mt-0.5">Yetkili: {[meta.yetkili, meta.meslek].filter(Boolean).join(' — ')}</p>
                      ) : null}
                    </div>
                    {k.sonuc ? <QrBadge tone={qrSonucTone(k.sonuc)}>{k.sonuc}</QrBadge> : null}
                  </div>
                </div>
              );
            })}
          </div>
        )}
        <p className="mt-2.5 flex items-start gap-1.5 text-[11px] text-foreground-400">
          <i className="ri-information-line mt-0.5 flex-shrink-0" />
          Tüm kontrol kayıtları kronolojik olarak listelenmektedir. Yeni kontrol eklendiğinde eski kayıtlar geçmişte korunur.
        </p>
      </QrKart>
    </div>
  );
}