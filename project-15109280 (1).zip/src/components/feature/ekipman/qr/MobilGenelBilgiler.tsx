import ImageViewer from '@/components/ui/ImageViewer';
import type { ImageViewerItem } from '@/components/ui/ImageViewer';
import type { EkipmanQrData, EkipmanBelge } from '@/lib/ekipmanService';
import {
  QrBadge,
  QrKart,
  QrSatir,
  QrTus,
  QrBos,
  qrKullanimTone,
  qrKullanimIcon,
  formatQrDateTime,
  type QrBolum,
} from './QrOrtak';

export interface GorselKaydi {
  belge: EkipmanBelge;
  url: string;
}

/** GENEL BİLGİLER (referans 2) — görsel + ekipman bilgileri + alt bölüm girişleri. */
export default function MobilGenelBilgiler({
  data,
  gorseller,
  gorselLoading,
  onBolum,
}: {
  data: EkipmanQrData;
  gorseller: GorselKaydi[];
  gorselLoading: boolean;
  onBolum: (b: QrBolum) => void;
}) {
  const galeri: ImageViewerItem[] = gorseller.map((g) => ({
    src: g.url,
    alt: g.belge.dosyaAdi,
    fileName: g.belge.dosyaAdi,
  }));
  const ana = gorseller[0] ?? null;
  const digerleri = gorseller.slice(1);

  return (
    <div className="space-y-3 p-3 pb-5">
      <QrKart title="Ekipman Görseli" icon="ri-image-line">
        {gorselLoading ? (
          <div className="h-40 rounded-lg bg-background-200 dark:bg-background-300/40 animate-pulse" />
        ) : ana ? (
          <div className="space-y-2">
            <ImageViewer
              src={ana.url}
              alt={ana.belge.dosyaAdi}
              fileName={ana.belge.dosyaAdi}
              gallery={galeri}
              index={0}
              showHoverIcon
              wrapperClassName="block w-full"
              imgClassName="w-full h-44 rounded-lg object-cover object-top border border-background-300/30 dark:border-background-400/25"
            />
            {digerleri.length > 0 && (
              <div className="flex gap-2 overflow-x-auto no-scrollbar pb-0.5">
                {digerleri.map((g, i) => (
                  <ImageViewer
                    key={g.belge.id}
                    src={g.url}
                    alt={g.belge.dosyaAdi}
                    fileName={g.belge.dosyaAdi}
                    gallery={galeri}
                    index={i + 1}
                    showHoverIcon
                    wrapperClassName="block w-16 h-16 rounded-lg overflow-hidden border border-background-300/30 dark:border-background-400/25 flex-shrink-0"
                    imgClassName="w-full h-16 object-cover object-top"
                  />
                ))}
              </div>
            )}
          </div>
        ) : (
          <QrBos icon="ri-image-line" text="Bu ekipman için görsel bulunmuyor." />
        )}
      </QrKart>

      <QrKart title="Ekipman Bilgileri" icon="ri-file-list-3-line">
        <div className="flex flex-col">
          <QrSatir label="Ekipman No" value={<span className="font-mono">{data.ekipmanNo}</span>} />
          <QrSatir label="Ekipman Adı" value={data.ad} />
          <QrSatir label="Ekipman Türü" value={data.turAd} />
          <QrSatir label="Ekipman Grubu" value={data.grupAd} />
          <QrSatir label="Firma" value={data.firmaUnvan} />
          <QrSatir label="Depo / Lokasyon" value={data.konum || '—'} />
          <QrSatir
            label="Kullanım Durumu"
            value={
              <QrBadge tone={qrKullanimTone(data.kullanimDurumu)} icon={qrKullanimIcon(data.kullanimDurumu)}>
                {data.kullanimDurumuLabel}
              </QrBadge>
            }
          />
          <QrSatir label="Oluşturma Tarihi" value={formatQrDateTime(data.createdAt)} />
        </div>
        <p className="mt-2.5 flex items-start gap-1.5 text-[11px] text-foreground-400">
          <i className="ri-information-line mt-0.5 flex-shrink-0" />
          Bu bilgiler ekipmana ait genel bilgilerdir.
        </p>
      </QrKart>

      <div className="space-y-2">
        <QrTus icon="ri-tools-line" label="Bakım Kayıtları" count={data.sayilar.bakim} onClick={() => onBolum('bakimlar')} />
        <QrTus icon="ri-sticky-note-line" label="Not" onClick={() => onBolum('not')} />
      </div>
    </div>
  );
}