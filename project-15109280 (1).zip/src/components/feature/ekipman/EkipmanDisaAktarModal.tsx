// ─────────────────────────────────────────────────────────────────────────────
// EKİPMANLARI DIŞA AKTAR MODALI
//
// 3 bölümlü akış (referans tasarım):
//   1) Dışa Aktarılacak Kayıtlar  (Tümü / Sadece aktif / Sadece arızalı / Seçili)
//   2) Dışa Aktarılacak Sütunlar  (sistemin STANDART sabit ekipman kolonları)
//   3) Dosya Formatı              (Excel .xlsx / CSV .csv)
//
// Sütun listesi SABİT standart ekipman kolonlarıdır. Kullanıcının içe aktardığı
// Excel'in kolonları bu listeyi DEĞİŞTİRMEZ. Seçilen sütun + kapsam + format
// gerçek export motoruna iletilir (yalnızca görsel buton DEĞİLDİR).
//
// GEOMETRİ: mevcut merkezi modal motoru kullanılır; kompakt genişlik, ekran
// ortasında, footer sabit, yatay scroll YOK. Kalıcı geometry hafızası YOK.
// ─────────────────────────────────────────────────────────────────────────────
import { useCallback, useMemo, useState } from 'react';
import Button from '@/components/ui/Button';
import Checkbox from '@/components/ui/Checkbox';
import Radio from '@/components/ui/Radio';
import { useToastActions } from '@/hooks/useToast';

export type EkipmanExportScope = 'tumu' | 'aktif' | 'arizali' | 'secili';
export type EkipmanExportFormat = 'xlsx' | 'csv';

export interface EkipmanExportColumn {
  key: string;
  label: string;
}

export interface EkipmanExportOptions {
  scope: EkipmanExportScope;
  format: EkipmanExportFormat;
  baseKeys: string[];
}

interface EkipmanDisaAktarModalProps {
  baseColumns: EkipmanExportColumn[];
  /** Listede seçili (aktif) ekipman sayısı — "Seçili ekipmanlar" bunu gerektirir. */
  selectedCount: number;
  onExport: (options: EkipmanExportOptions) => Promise<void>;
  onClose: () => void;
}

function NumberBadge({ n }: { n: number }) {
  return (
    <span className="w-6 h-6 rounded-full bg-primary-500 text-inverse text-xs font-bold flex items-center justify-center flex-shrink-0">
      {n}
    </span>
  );
}

export default function EkipmanDisaAktarModal({
  baseColumns,
  selectedCount,
  onExport,
  onClose,
}: EkipmanDisaAktarModalProps) {
  const { addToast } = useToastActions();

  const [scope, setScope] = useState<EkipmanExportScope>('tumu');
  const [format, setFormat] = useState<EkipmanExportFormat>('xlsx');
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(baseColumns.map((c) => c.key)),
  );
  const [busy, setBusy] = useState(false);

  const allKeys = useMemo(() => baseColumns.map((c) => c.key), [baseColumns]);
  const allSelected = selected.size === allKeys.length && allKeys.length > 0;

  const toggleKey = useCallback((key: string, checked: boolean) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(key);
      else next.delete(key);
      return next;
    });
  }, []);

  const selectAll = useCallback(() => setSelected(new Set(allKeys)), [allKeys]);
  const clearAll = useCallback(() => setSelected(new Set()), []);

  const exportDisabled = busy || selected.size === 0 || (scope === 'secili' && selectedCount === 0);

  const handleExport = useCallback(async () => {
    if (busy) return;
    if (selected.size === 0) {
      addToast({ title: 'Sütun seçin', message: 'Dışa aktarmak için en az bir sütun seçmelisiniz.', type: 'warning' });
      return;
    }
    if (scope === 'secili' && selectedCount === 0) {
      addToast({ title: 'Seçili ekipman yok', message: 'Listede seçim yapmadınız.', type: 'warning' });
      return;
    }
    const baseKeys = baseColumns.map((c) => c.key).filter((k) => selected.has(k));
    setBusy(true);
    try {
      await onExport({ scope, format, baseKeys });
      addToast({
        title: 'Dışa aktarma tamamlandı',
        message: format === 'csv' ? 'CSV dosyası indirildi.' : 'Excel dosyası indirildi.',
        type: 'success',
      });
      onClose();
    } catch (e) {
      const msg = e instanceof Error && e.message ? e.message : 'Dosya oluşturulamadı. Lütfen tekrar deneyin.';
      addToast({ title: 'Dışa aktarma başarısız', message: msg, type: 'error' });
    } finally {
      setBusy(false);
    }
  }, [busy, selected, scope, selectedCount, baseColumns, format, onExport, addToast, onClose]);

  return (
    <div
      className="flex flex-col"
      style={{
        margin: 'calc(var(--d-modal-body-py) * -1) calc(var(--d-modal-body-px) * -1)',
        height: 'calc(100% + var(--d-modal-body-py) * 2)',
      }}
    >
      <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden isg-scroll-pane px-4 py-3 space-y-4">
        {/* ── Bölüm 1: Dışa Aktarılacak Kayıtlar ── */}
        <div className="space-y-2.5">
          <div className="flex items-center gap-2.5">
            <NumberBadge n={1} />
            <h4 className="text-sm font-semibold text-foreground-900">Dışa Aktarılacak Kayıtlar</h4>
          </div>
          <div className="space-y-3 pl-8">
            <Radio
              name="ekipman-export-scope"
              value="tumu"
              checked={scope === 'tumu'}
              onChange={() => setScope('tumu')}
              label="Tüm ekipmanlar"
              helpText="Sistemdeki tüm ekipmanları dışa aktarır."
            />
            <Radio
              name="ekipman-export-scope"
              value="aktif"
              checked={scope === 'aktif'}
              onChange={() => setScope('aktif')}
              label="Sadece aktif ekipmanlar"
              helpText="Sadece aktif durumdaki ekipmanları dışa aktarır."
            />
            <Radio
              name="ekipman-export-scope"
              value="arizali"
              checked={scope === 'arizali'}
              onChange={() => setScope('arizali')}
              label="Sadece arızalı ekipmanlar"
              helpText="Sadece arızalı durumdaki ekipmanları dışa aktarır."
            />
            <Radio
              name="ekipman-export-scope"
              value="secili"
              checked={scope === 'secili'}
              onChange={() => setScope('secili')}
              disabled={selectedCount === 0}
              label="Seçili ekipmanlar"
              helpText={
                selectedCount === 0
                  ? 'Listede seçim yapmadınız.'
                  : 'Listede seçmiş olduğunuz ekipmanları dışa aktarır.'
              }
            />
          </div>
        </div>

        {/* ── Bölüm 2: Dışa Aktarılacak Sütunlar ── */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <NumberBadge n={2} />
              <h4 className="text-sm font-semibold text-foreground-900">Dışa Aktarılacak Sütunlar</h4>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="secondary" size="sm" onClick={selectAll} disabled={allSelected}>
                Tümünü Seç
              </Button>
              <Button variant="ghost" size="sm" onClick={clearAll} disabled={selected.size === 0}>
                Tümünü Kaldır
              </Button>
            </div>
          </div>
          <div className="rounded-md border border-background-300/60 bg-background-100/60 p-3">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2.5">
              {baseColumns.map((c) => (
                <Checkbox
                  key={c.key}
                  checked={selected.has(c.key)}
                  onChange={(e) => toggleKey(c.key, e.target.checked)}
                  label={c.label}
                />
              ))}
            </div>
          </div>
        </div>

        {/* ── Bölüm 3: Dosya Formatı ── */}
        <div className="space-y-2.5">
          <div className="flex items-center gap-2.5">
            <NumberBadge n={3} />
            <h4 className="text-sm font-semibold text-foreground-900">Dosya Formatı</h4>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-start gap-3 sm:gap-8 pl-8">
            <Radio
              name="ekipman-export-format"
              value="xlsx"
              checked={format === 'xlsx'}
              onChange={() => setFormat('xlsx')}
              label="Excel (.xlsx)"
              helpText="Önerilen format. Tüm biçimlendirmeler korunur."
            />
            <Radio
              name="ekipman-export-format"
              value="csv"
              checked={format === 'csv'}
              onChange={() => setFormat('csv')}
              label="CSV (.csv)"
              helpText="Daha küçük dosya boyutu. Sade veri formatı."
            />
          </div>
        </div>
      </div>

      {/* ── Footer (sabit, tam genişlik) ── */}
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-t isg-divider flex-shrink-0">
        <Button variant="ghost" onClick={onClose} disabled={busy}>
          İptal
        </Button>
        <Button
          variant="primary"
          leftIcon={busy ? undefined : <i className="ri-download-2-line" />}
          onClick={handleExport}
          isLoading={busy}
          disabled={exportDisabled}
        >
          {busy ? 'Dışa Aktarılıyor...' : 'Dışa Aktar'}
        </Button>
      </div>
    </div>
  );
}