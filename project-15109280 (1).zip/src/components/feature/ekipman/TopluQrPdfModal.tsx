// ─────────────────────────────────────────────────────────────────────────────
// TOPLU QR / PDF OLUŞTUR MODALI
//
// "Excel / PDF İşlemleri" menüsünden açılır. Referans tasarımına göre:
//   • Kapsam: Seçili ekipmanlar / Tüm ekipmanlar
//   • QR Formatı: A4 Çoklu QR  /  Tekli QR (sayfa başına 1 etiket)
//   • Sayfa Düzeni: 3×7 (21), 3×6 (18), 2×7 (14), 2×4 (8)
//   • Gerçek ekipman QR tokenlarından üretim (mock/örnek YOK)
//
// GEOMETRİ: kompakt modal, ekran ortasında; gereksiz scroll oluşmaz, gerçekten
// taşarsa yalnızca gövde kayar. Mevcut merkezî modal motoru kullanılır.
// ─────────────────────────────────────────────────────────────────────────────
import { useCallback, useMemo, useState } from 'react';
import Button from '@/components/ui/Button';
import Radio from '@/components/ui/Radio';
import Select from '@/components/ui/Select';
import { useToastActions } from '@/hooks/useToast';
import type { QrCiktiModu } from '@/lib/pdf/qrEtiketPdf';

export type QrKapsam = 'secili' | 'tumu';

export interface TopluQrPdfOptions {
  scope: QrKapsam;
  mode: QrCiktiModu;
  cols: number;
  rows: number;
}

interface TopluQrPdfModalProps {
  /** Listede seçili ekipman sayısı. */
  selectedCount: number;
  /** Kapsam dahilindeki toplam ekipman sayısı. */
  totalCount: number;
  onGenerate: (options: TopluQrPdfOptions) => Promise<void>;
  onClose: () => void;
}

const DUZENLER = [
  { value: '3x7', label: '3 × 7 (A4 – 21 QR kod)', cols: 3, rows: 7 },
  { value: '3x6', label: '3 × 6 (A4 – 18 QR kod)', cols: 3, rows: 6 },
  { value: '2x7', label: '2 × 7 (A4 – 14 QR kod)', cols: 2, rows: 7 },
  { value: '2x4', label: '2 × 4 (A4 – 8 QR kod)', cols: 2, rows: 4 },
];

export default function TopluQrPdfModal({
  selectedCount,
  totalCount,
  onGenerate,
  onClose,
}: TopluQrPdfModalProps) {
  const { addToast } = useToastActions();

  const [scope, setScope] = useState<QrKapsam>(selectedCount > 0 ? 'secili' : 'tumu');
  const [mode, setMode] = useState<QrCiktiModu>('grid');
  const [duzen, setDuzen] = useState('3x7');
  const [busy, setBusy] = useState(false);

  const layout = useMemo(
    () => DUZENLER.find((d) => d.value === duzen) ?? DUZENLER[0],
    [duzen],
  );

  const count = scope === 'secili' ? selectedCount : totalCount;
  const disabled = busy || count === 0;

  const handleGenerate = useCallback(async () => {
    if (busy) return;
    if (scope === 'secili' && selectedCount === 0) {
      addToast({ title: 'Seçili ekipman yok', message: 'Listede ekipman seçin veya "Tüm ekipmanlar" kapsamını seçin.', type: 'warning' });
      return;
    }
    setBusy(true);
    try {
      await onGenerate({ scope, mode, cols: layout.cols, rows: layout.rows });
      addToast({ title: 'PDF hazırlandı', message: `${count} ekipman için QR etiket PDF'i indirildi.`, type: 'success' });
      onClose();
    } catch (e) {
      const msg = e instanceof Error && e.message ? e.message : 'PDF oluşturulamadı. Lütfen tekrar deneyin.';
      addToast({ title: 'PDF oluşturulamadı', message: msg, type: 'error' });
    } finally {
      setBusy(false);
    }
  }, [busy, scope, selectedCount, onGenerate, addToast, onClose, count, mode, layout]);

  return (
    <div
      className="flex flex-col"
      style={{
        margin: 'calc(var(--d-modal-body-py) * -1) calc(var(--d-modal-body-px) * -1)',
        height: 'calc(100% + var(--d-modal-body-py) * 2)',
      }}
    >
      <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden isg-scroll-pane px-4 py-3 space-y-4">
        {/* ── Kapsam ── */}
        <div className="space-y-2.5">
          <h4 className="text-sm font-semibold text-foreground-900">Kapsam</h4>
          <div className="space-y-2.5">
            <Radio
              name="qr-kapsam"
              value="secili"
              checked={scope === 'secili'}
              onChange={() => setScope('secili')}
              disabled={selectedCount === 0}
              label={`Seçili ekipmanlar (${selectedCount})`}
              helpText={selectedCount === 0 ? 'Listede seçim yapmadınız.' : 'Listede seçmiş olduğunuz ekipmanların QR kodları üretilir.'}
            />
            <Radio
              name="qr-kapsam"
              value="tumu"
              checked={scope === 'tumu'}
              onChange={() => setScope('tumu')}
              label={`Tüm ekipmanlar (${totalCount})`}
              helpText="Kapsam dahilindeki tüm ekipmanların QR kodları üretilir."
            />
          </div>
        </div>

        {/* ── QR Formatı ── */}
        <div className="space-y-2.5">
          <h4 className="text-sm font-semibold text-foreground-900">QR Formatı</h4>
          <div className="space-y-2.5">
            <Radio
              name="qr-mod"
              value="grid"
              checked={mode === 'grid'}
              onChange={() => setMode('grid')}
              label="A4 Sayfası (Çoklu QR)"
              helpText="Bir sayfada birden fazla QR kodu (önerilen)."
            />
            <Radio
              name="qr-mod"
              value="single"
              checked={mode === 'single'}
              onChange={() => setMode('single')}
              label="Tekli QR"
              helpText="Her ekipman tek sayfada, büyük etiket olarak indirilir."
            />
          </div>
        </div>

        {/* ── Sayfa Düzeni (yalnızca çoklu) ── */}
        {mode === 'grid' && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-foreground-900">Sayfa Düzeni</h4>
            <Select
              options={DUZENLER.map((d) => ({ value: d.value, label: d.label }))}
              value={duzen}
              onChange={(e) => setDuzen(e.target.value)}
            />
          </div>
        )}

        {/* ── Aktarım bilgisi ── */}
        <div className="flex items-start gap-2 rounded-md border border-background-300/50 bg-background-100/70 px-3 py-2">
          <i className="ri-information-line text-primary-500 mt-px flex-shrink-0" />
          <p className="text-xs text-foreground-600">
            QR kodlar, ekipmanların üzerine yapıştırılabilir etiket formatında hazırlanır.
          </p>
        </div>
      </div>

      {/* ── Footer (sabit) ── */}
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-t isg-divider flex-shrink-0">
        <Button variant="ghost" onClick={onClose} disabled={busy}>
          İptal
        </Button>
        <Button
          variant="primary"
          leftIcon={busy ? undefined : <i className="ri-download-2-line" />}
          onClick={handleGenerate}
          isLoading={busy}
          disabled={disabled}
        >
          {busy ? 'PDF Hazırlanıyor...' : scope === 'secili' ? 'Seçili QR Kodlarını İndir' : 'Tüm QR Kodlarını İndir'}
        </Button>
      </div>
    </div>
  );
}