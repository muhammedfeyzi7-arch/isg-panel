import { useState } from 'react';
import IconButton from '@/components/ui/IconButton';
import { useToastActions } from '@/hooks/useToast';
import { getBelgeUrl, friendlyEkipmanError, type EkipmanBelge } from '@/lib/ekipmanService';

// Tarayıcıda inline önizlenebilen tipler (PDF + görseller + düz metin).
// Diğer formatlar (doc/xls/odt vb.) önizlenemez → kullanıcıya İndir yönlendirilir.
const PREVIEWABLE_MIME = new Set([
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/webp',
  'text/plain',
]);

export function isPreviewableBelge(mimeType: string | null): boolean {
  return !!mimeType && PREVIEWABLE_MIME.has(mimeType.toLowerCase());
}

interface BelgeEylemleriProps {
  belge: EkipmanBelge;
}

/**
 * Ortak belge erişim eylemleri — GÖRÜNTÜLE (inline preview) + İNDİR (attachment download).
 * Firma, Uzman ve mobil aynı bileşeni kullanır; yetki backend'de (`belge_url` action) doğrulanır.
 * Frontend yalnızca dosya tipine göre preview'in desteklenip desteklenmediğini belirler.
 */
export default function BelgeEylemleri({ belge }: BelgeEylemleriProps) {
  const { addToast } = useToastActions();
  const [busy, setBusy] = useState<'view' | 'download' | null>(null);

  const triggerDownload = (url: string) => {
    // Signed URL'de Content-Disposition: attachment olduğu için bu, sayfayı terk etmeden
    // (boş sekme açmadan) dosyayı indirir — masaüstü + Android Chrome + iOS Safari uyumlu.
    const a = document.createElement('a');
    a.href = url;
    a.rel = 'noopener';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const handleView = () => {
    if (!isPreviewableBelge(belge.mimeType)) {
      addToast({
        type: 'info',
        title: 'Önizlenemiyor',
        message: 'Bu dosya cihazınızda önizlenemiyor. İndirmek için İndir seçeneğini kullanabilirsiniz.',
      });
      return;
    }
    if (busy) return;
    setBusy('view');
    getBelgeUrl(belge.id, 'view')
      .then((url) => { window.open(url, '_blank', 'noopener'); })
      .catch((err) => addToast({ type: 'error', title: 'Görüntüleme başarısız', message: friendlyEkipmanError(err) }))
      .finally(() => setBusy(null));
  };

  const handleDownload = () => {
    if (busy) return;
    setBusy('download');
    getBelgeUrl(belge.id, 'download')
      .then((url) => { triggerDownload(url); })
      .catch((err) => addToast({ type: 'error', title: 'İndirme başarısız', message: friendlyEkipmanError(err) }))
      .finally(() => setBusy(null));
  };

  return (
    <div className="flex items-center gap-1.5 flex-shrink-0">
      <IconButton
        icon={<i className="ri-eye-line" />}
        variant="ghost"
        size="sm"
        label="Görüntüle"
        disabled={busy !== null}
        onClick={handleView}
      />
      <IconButton
        icon={<i className="ri-download-line" />}
        variant="ghost"
        size="sm"
        label="İndir"
        disabled={busy !== null}
        onClick={handleDownload}
      />
    </div>
  );
}