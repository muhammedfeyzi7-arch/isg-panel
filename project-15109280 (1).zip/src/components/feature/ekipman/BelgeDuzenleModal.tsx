import { useState } from 'react';
import Button from '@/components/ui/Button';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import DatePicker from '@/components/ui/DatePicker';
import { useToastActions } from '@/hooks/useToast';
import { guncelleBelge, friendlyEkipmanError, type EkipmanBelge } from '@/lib/ekipmanService';
import { BELGE_TURLERI } from './BelgeEkleModal';

interface BelgeDuzenleModalProps {
  belge: EkipmanBelge;
  onClose: () => void;
  onSaved: () => void;
}

/**
 * Ekipman belgesi/görseli META düzenleme modalı. Belge türü, belge tarihi,
 * geçerlilik bitişi ve açıklama güncellenir; dosyanın kendisi DEĞİŞMEZ.
 * Yetki/kapsam `ekipman` edge function'ında sunucu tarafında doğrulanır.
 */
export default function BelgeDuzenleModal({ belge, onClose, onSaved }: BelgeDuzenleModalProps) {
  const { addToast } = useToastActions();

  const [belgeTuru, setBelgeTuru] = useState(belge.belgeTuru ?? '');
  const [belgeTarihi, setBelgeTarihi] = useState(belge.belgeTarihi ?? '');
  const [gecerlilikBitis, setGecerlilikBitis] = useState(belge.gecerlilikBitis ?? '');
  const [aciklama, setAciklama] = useState(belge.aciklama ?? '');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setError('');
    if (!belgeTuru) {
      setError('Belge türü zorunludur.');
      return;
    }
    setSaving(true);
    try {
      await guncelleBelge(belge.id, {
        belgeTuru,
        belgeTarihi: belgeTarihi || null,
        gecerlilikBitis: gecerlilikBitis || null,
        aciklama: aciklama.trim() || null,
      });
      addToast({ title: 'Belge güncellendi', message: 'Belge bilgileri kaydedildi.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      setError(friendlyEkipmanError(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2 rounded-lg border border-background-300/40 bg-background-100/70 p-2.5 dark:border-background-400/20 dark:bg-background-200/40">
        <i className="ri-file-line text-foreground-400" />
        <span className="min-w-0 flex-1 truncate text-xs text-foreground-600">{belge.dosyaAdi}</span>
      </div>

      <Select
        label="Belge Türü"
        required
        options={BELGE_TURLERI}
        value={belgeTuru}
        onChange={(e) => setBelgeTuru(e.target.value)}
        placeholder="Belge türü seçin"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <DatePicker label="Belge Tarihi" value={belgeTarihi} onChange={(e) => setBelgeTarihi(e.target.value)} />
        <DatePicker label="Geçerlilik Bitişi" value={gecerlilikBitis} onChange={(e) => setGecerlilikBitis(e.target.value)} />
      </div>

      <Textarea
        label="Açıklama"
        value={aciklama}
        onChange={(e) => setAciklama(e.target.value)}
        maxLength={500}
        placeholder="Belgeyle ilgili kısa açıklama (isteğe bağlı)"
      />

      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={saving}>Vazgeç</Button>
        <Button variant="primary" size="sm" leftIcon={<i className="ri-save-line" />} onClick={handleSave} isLoading={saving}>Kaydet</Button>
      </div>
    </div>
  );
}