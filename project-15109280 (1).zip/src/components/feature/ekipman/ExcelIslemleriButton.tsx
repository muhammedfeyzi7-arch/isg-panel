// ─────────────────────────────────────────────────────────────────────────────
// EXCEL / PDF İŞLEMLERİ ▾ — Tek buton + kompakt işlem menüsü
//
// Ekipman modülündeki TÜM Excel + PDF işlemlerinin TEK giriş noktası:
//   • Excel İçe Aktar
//   • Excel Dışa Aktar
//   • Toplu QR / PDF Oluştur
// Ayrı ayrı Excel/CSV/QR butonları oluşturulmaz. Menü, mevcut global Viewport-Aware
// DropdownPanel üzerinden (portal + viewport konumlandırma) açılır — yeni bir menü
// motoru oluşturulmaz. Her alt eylem mevcut merkezî modal motoruyla açılır.
// ─────────────────────────────────────────────────────────────────────────────
import { useCallback, useRef, useState } from 'react';
import Button from '@/components/ui/Button';
import DropdownPanel from '@/components/ui/DropdownPanel';
import Icon from '@/components/ui/Icon';

interface ExcelIslemleriButtonProps {
  onIceriAktar: () => void;
  onDisaAktar: () => void;
  /** Toplu QR / PDF oluşturma (gerçek ekipman QR tokenlarından). */
  onTopluQrPdf: () => void;
  /** İçe aktarma yetkisi yoksa yalnızca dışa aktarma gösterilir. */
  canImport?: boolean;
  disabled?: boolean;
}

interface MenuItemProps {
  icon: string;
  label: string;
  onClick: () => void;
}

function MenuItem({ icon, label, onClick }: MenuItemProps) {
  return (
    <button
      type="button"
      role="menuitem"
      onClick={onClick}
      className="w-full flex items-center gap-2.5 px-3 py-2 text-sm text-foreground-700 hover:bg-background-200/70 dark:hover:bg-background-300/50 transition-colors cursor-pointer text-left whitespace-nowrap"
    >
      <span className="w-4 h-4 flex items-center justify-center flex-shrink-0">
        <i className={`${icon} text-base text-primary-500`} />
      </span>
      {label}
    </button>
  );
}

export default function ExcelIslemleriButton({
  onIceriAktar,
  onDisaAktar,
  onTopluQrPdf,
  canImport = true,
  disabled,
}: ExcelIslemleriButtonProps) {
  const [open, setOpen] = useState(false);
  const anchorRef = useRef<HTMLDivElement>(null);

  const run = useCallback((fn: () => void) => {
    setOpen(false);
    fn();
  }, []);

  return (
    <div ref={anchorRef} className="relative">
      <Button
        variant="secondary"
        size="sm"
        leftIcon={<Icon name="excel" size="md" />}
        rightIcon={<i className={`ri-arrow-down-s-line transition-transform ${open ? 'rotate-180' : ''}`} />}
        disabled={disabled}
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="menu"
        aria-expanded={open}
      >
        Excel / PDF İşlemleri
      </Button>
      <DropdownPanel
        open={open}
        anchorRef={anchorRef}
        onClose={() => setOpen(false)}
        role="menu"
        minWidth={210}
        className="rounded-lg border border-background-300/60 dark:border-background-400/50 bg-background-50 dark:bg-background-200 shadow-lg py-1"
      >
        {canImport && (
          <MenuItem icon="ri-upload-2-line" label="Excel İçe Aktar" onClick={() => run(onIceriAktar)} />
        )}
        <MenuItem icon="ri-download-2-line" label="Excel Dışa Aktar" onClick={() => run(onDisaAktar)} />
        <MenuItem icon="ri-qr-code-line" label="Toplu QR / PDF Oluştur" onClick={() => run(onTopluQrPdf)} />
      </DropdownPanel>
    </div>
  );
}