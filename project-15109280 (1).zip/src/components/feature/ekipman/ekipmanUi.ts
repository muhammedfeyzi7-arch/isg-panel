import type { EkipmanKullanimDurumu, EkipmanKontrolDurumu } from '@/lib/ekipmanService';
import { formatIstanbulDateTime } from '@/lib/dateFormat';
import { DOSYA_TUR_IKON, ICON_REGISTRY, ICON_TONES, dosyaTuruBul } from '@/lib/icons/iconRegistry';
import { downloadBlobFile as centralDownloadBlobFile } from '@/lib/downloadFile';

export type EkipmanBadgeVariant =
  | 'default'
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | 'secondary'
  | 'accent';

/** Kullanım durumu → badge rengi (aktif/arızalı/bakımda/kullanım dışı). */
export function kullanimDurumuBadgeVariant(d: EkipmanKullanimDurumu): EkipmanBadgeVariant {
  switch (d) {
    case 'aktif': return 'success';
    case 'arizali': return 'danger';
    case 'bakimda': return 'warning';
    case 'kullanim_disi': return 'secondary';
    default: return 'default';
  }
}

/** Periyodik kontrol durumu → badge rengi (türetilmiş gösterge). */
export function kontrolDurumuBadgeVariant(d: EkipmanKontrolDurumu): EkipmanBadgeVariant {
  switch (d) {
    case 'gecmis': return 'danger';
    case 'bugun': return 'warning';
    case 'gelecek': return 'success';
    case 'yok': return 'default';
    default: return 'default';
  }
}

/** Ekipman için genel ikon. Tür/grup bazlı özel ikonlar merkezi katalog genişletildiğinde bağlanır. */
export function ekipmanIcon(): string {
  return 'ri-tools-line';
}

export function kullanimDurumuIcon(d: EkipmanKullanimDurumu): string {
  switch (d) {
    case 'aktif': return 'ri-checkbox-circle-line';
    case 'arizali': return 'ri-alert-line';
    case 'bakimda': return 'ri-tools-line';
    case 'kullanim_disi': return 'ri-pause-circle-line';
    default: return 'ri-tools-line';
  }
}

const TR_MONTHS = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

/** Yalnızca tarih değeri (YYYY-MM-DD) — timezone kayması olmadan "5 Eyl 2026" üretir. */
export function formatEkipmanDate(iso: string | null): string {
  if (!iso) return '—';
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return '—';
  return `${d} ${TR_MONTHS[m - 1]} ${y}`;
}

/** Tam zaman damgası (created_at/updated_at) — "5 Eyl 2026 14:32". */
export function formatEkipmanDateTime(iso: string | null): string {
  return formatIstanbulDateTime(iso);
}

/** Görsel tipli belge mi? (Ekipman fotoğraf galerisi bu belgelerden beslenir.) */
export function isImageMime(mimeType: string | null | undefined): boolean {
  return !!mimeType && mimeType.toLowerCase().startsWith('image/');
}

/** Belge türüne göre ikon + renk tonu — MERKEZÎ dosya-ikonu sisteminden gelir.
 *  Böylece ekipman belgeleri de evrak/mesajlaşma ile AYNI format ikonlarını
 *  (PDF kırmızı, Word mavi, Excel yeşil, PowerPoint turuncu) kullanır. */
const BELGE_IKON_TILE: Record<string, string> = {
  pdf: 'bg-danger-50 dark:bg-danger-500/15',
  word: 'bg-primary-50 dark:bg-primary-500/15',
  excel: 'bg-success-50 dark:bg-success-500/15',
  powerpoint: 'bg-warning-50 dark:bg-warning-500/15',
  image: 'bg-primary-50 dark:bg-primary-500/15',
  archive: 'bg-warning-50 dark:bg-warning-500/15',
  text: 'bg-secondary-50 dark:bg-secondary-500/15',
  folder: 'bg-warning-50 dark:bg-warning-500/15',
  document: 'bg-background-200',
};

/** Belge türüne göre ikon + renk tonu (PDF/DOC/XLS/PPT/Görsel/Metin). */
export function belgeGorunum(mimeType: string | null | undefined): { icon: string; tone: string } {
  const tur = dosyaTuruBul(mimeType, null);
  const name = DOSYA_TUR_IKON[tur];
  const def = ICON_REGISTRY[name];
  return {
    icon: def.className,
    tone: `${BELGE_IKON_TILE[tur] ?? BELGE_IKON_TILE.document} ${ICON_TONES[def.tone ?? 'muted']}`,
  };
}

/** Bayt → okunabilir boyut ("512 KB", "2.1 MB"). */
export function formatFileSize(bytes: number | null | undefined): string {
  if (!bytes || bytes <= 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/** Blob'u tarayıcıda dosya olarak indirir. Ad, merkezî motorda güvenli hale getirilir. */
export function downloadBlob(blob: Blob, fileName: string): void {
  centralDownloadBlobFile(blob, fileName);
}

// Periyot birimi → Türkçe etiket. Backend boş/geçersiz birim döndürürse çıplak sayı gösterilir;
// frontend kendi başına "12 ay" gibi bir değer ÜRETMEZ.
const PERIYOT_BIRIM_LABEL: Record<string, string> = {
  month: 'ay',
  year: 'yıl',
  day: 'gün',
  week: 'hafta',
};

/** Mevzuat kontrol periyodunu okunabilir metne çevirir ("12 ay", "6 ay", null). */
export function periyotMetni(period: { value: number | null; unit: string } | null | undefined): string | null {
  if (!period || period.value == null) return null;
  const unit = PERIYOT_BIRIM_LABEL[period.unit] ?? period.unit;
  if (!unit) return String(period.value);
  return `${period.value} ${unit}`;
}

/**
 * Bir tarihe mevzuat periyodunu ekleyip önerilen "sonraki kontrol" tarihini döndürür
 * (YYYY-MM-DD). Periyot bilinmiyorsa veya tarih geçersizse null — uydurma tarih ÜRETİLMEZ.
 */
export function addPeriodToDate(
  dateIso: string,
  period: { value: number | null; unit: string } | null | undefined,
): string | null {
  if (!dateIso || !period || period.value == null) return null;
  const d = new Date(`${dateIso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  switch (period.unit) {
    case 'month': d.setMonth(d.getMonth() + period.value); break;
    case 'year': d.setFullYear(d.getFullYear() + period.value); break;
    case 'day': d.setDate(d.getDate() + period.value); break;
    case 'week': d.setDate(d.getDate() + period.value * 7); break;
    default: return null;
  }
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}