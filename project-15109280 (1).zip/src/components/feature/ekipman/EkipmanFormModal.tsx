import { useState, useEffect, useMemo, useCallback, type ChangeEvent } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import Toggle from '@/components/ui/Toggle';
import MultiSelect from '@/components/ui/MultiSelect';
import DatePicker from '@/components/ui/DatePicker';
import StatusBadge from '@/components/ui/StatusBadge';
import { useToastActions } from '@/hooks/useToast';
import { useAuth } from '@/context/AuthContext';
import BelgeEylemleri from './BelgeEylemleri';
import {
  type EkipmanData,
  type EkipmanKullanimDurumu,
  type EkipmanKatalog,
  type EkipmanTeknikAlan,
  type EkipmanFirmaOption,
  type EkipmanPersonelOption,
  type EkipmanMevzuatKurali,
  type EkipmanCreateKontrol,
  type EkipmanCreateBelge,
  type EkipmanKontrol,
  type EkipmanBelge,
  createEkipman,
  updateEkipman,
  uploadBelge,
  ekleKontrol,
  fetchEkipmanKatalog,
  fetchEkipmanFirmalari,
  fetchEkipmanPersonelleri,
  mevzuatKuraliForTur,
  periyodikKontrolGerekli,
  mapKontrolMeta,
  friendlyEkipmanError,
} from '@/lib/ekipmanService';
import { periyotMetni } from './ekipmanUi';

const KULLANIM_DURUMU_OPTIONS = [
  { value: 'aktif', label: 'Aktif' },
  { value: 'arizali', label: 'Arızalı' },
  { value: 'bakimda', label: 'Bakımda' },
  { value: 'kullanim_disi', label: 'Kullanım Dışı' },
];

const MAX_SIZE = 15 * 1024 * 1024;

// "Diğer" türler için isteğe bağlı manuel belge türleri — yalnızca öneri; hiçbiri mevzuat zorunluluğu değildir.
const MANUEL_BELGE_TURLERI = [
  { value: 'CE / Uygunluk Belgesi', label: 'CE / Uygunluk Belgesi' },
  { value: 'Türkçe Kullanım Kılavuzu', label: 'Türkçe Kullanım Kılavuzu' },
  { value: 'Üretici Teknik Dokümanı', label: 'Üretici Teknik Dokümanı' },
  { value: 'Kontrol Raporu', label: 'Kontrol Raporu' },
  { value: 'Bakım Belgesi', label: 'Bakım Belgesi' },
  { value: 'Uygunluk Belgesi', label: 'Uygunluk Belgesi' },
  { value: 'Diğer', label: 'Diğer' },
];

interface EkipmanFormModalProps {
  mode: 'create' | 'edit';
  initial?: EkipmanData & { kontroller?: EkipmanKontrol[]; belgeler?: EkipmanBelge[] };
  onClose: () => void;
  onSaved: () => void;
}

/** Seçili türün aktif (en güncel versiyon) şablonuna ait teknik alanlarını döndürür. */
function alanlarForTur(katalog: EkipmanKatalog, turId: string): EkipmanTeknikAlan[] {
  if (!turId) return [];
  const sablon = katalog.sablonlar
    .filter((s) => s.turId === turId)
    .sort((a, b) => b.versiyon - a.versiyon)[0];
  if (!sablon) return [];
  return katalog.alanlar
    .filter((a) => a.sablonId === sablon.id)
    .sort((a, b) => a.siralama - b.siralama);
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const idx = result.indexOf(',');
      resolve(idx >= 0 ? result.slice(idx + 1) : result);
    };
    reader.onerror = () => reject(new Error('Dosya okunamadı'));
    reader.readAsDataURL(file);
  });
}

// Periyodik kontrol form alanları (tek durum nesnesi). Backend `required_fields` bunlarla eşlenir.
interface KontrolFormState {
  kontrolTarihi: string;
  sonrakiKontrolTarihi: string;
  sonuc: string;
  yontem: string;
  kusur: string;
  yetkili: string;
  meslek: string;
  ekipnetNo: string;
  isgKatip: string;
  aciklama: string;
}

// Backend `required_fields` içindeki snake_case anahtar → kontrol form state anahtarı.
// Bilinmeyen anahtarlar yok sayılır (uydurulmaz).
const KONTROL_FIELD_KEY_MAP: Record<string, keyof KontrolFormState> = {
  kontrol_tarihi: 'kontrolTarihi',
  sonraki_kontrol_tarihi: 'sonrakiKontrolTarihi',
  sonuc: 'sonuc',
  yontem: 'yontem',
  kusur: 'kusur',
  yetkili: 'yetkili',
  meslek: 'meslek',
  ekipnet_no: 'ekipnetNo',
  isg_katip: 'isgKatip',
  aciklama: 'aciklama',
};

const KONTROL_FIELD_LABEL: Record<keyof KontrolFormState, string> = {
  kontrolTarihi: 'Kontrol Tarihi',
  sonrakiKontrolTarihi: 'Sonraki Kontrol Tarihi',
  sonuc: 'Sonuç',
  yontem: 'Kontrol Yöntemi',
  kusur: 'Kusur / Değerlendirme',
  yetkili: 'Yetkili Kişi',
  meslek: 'Meslek',
  ekipnetNo: 'EKİPNET Kayıt No',
  isgKatip: 'İSG-KATİP Sözleşme',
  aciklama: 'Açıklama',
};

const EMPTY_KONTROL: KontrolFormState = {
  kontrolTarihi: '',
  sonrakiKontrolTarihi: '',
  sonuc: '',
  yontem: '',
  kusur: '',
  yetkili: '',
  meslek: '',
  ekipnetNo: '',
  isgKatip: '',
  aciklama: '',
};

function kontrolStateFromRecord(k: EkipmanKontrol | undefined): KontrolFormState {
  if (!k) return { ...EMPTY_KONTROL };
  const meta = mapKontrolMeta(k.metadata);
  return {
    kontrolTarihi: k.kontrolTarihi ?? '',
    sonrakiKontrolTarihi: k.sonrakiKontrolTarihi ?? '',
    sonuc: k.sonuc ?? '',
    yontem: meta.yontem,
    kusur: meta.kusur,
    yetkili: meta.yetkili,
    meslek: meta.meslek,
    ekipnetNo: meta.ekipnetNo,
    isgKatip: meta.isgKatip,
    aciklama: meta.aciklama,
  };
}

function kontrolStateChanged(a: KontrolFormState, b: KontrolFormState): boolean {
  return (Object.keys(a) as Array<keyof KontrolFormState>).some((k) => a[k] !== b[k]);
}

export default function EkipmanFormModal({ mode, initial, onClose, onSaved }: EkipmanFormModalProps) {
  const { addToast } = useToastActions();
  const { profile } = useAuth();
  const role = profile?.role ?? '';

  const [katalog, setKatalog] = useState<EkipmanKatalog>({ gruplar: [], turler: [], altTurler: [], sablonlar: [], alanlar: [], kurallar: [] });
  const [firmalar, setFirmalar] = useState<EkipmanFirmaOption[]>([]);
  const [personeller, setPersoneller] = useState<EkipmanPersonelOption[]>([]);
  const [katalogLoading, setKatalogLoading] = useState(true);

  const [form, setForm] = useState({
    firmaId: initial?.firmaId ?? '',
    grupId: initial?.ekipmanGrubuId ?? '',
    turId: initial?.ekipmanTuruId ?? '',
    altTurId: initial?.ekipmanAltTuruId ?? '',
    sorumluPersonelId: initial?.sorumluPersonelId ?? '',
    ad: initial?.ad ?? '',
    marka: initial?.marka ?? '',
    model: initial?.model ?? '',
    seriNo: initial?.seriNo ?? '',
    imalYili: initial?.imalYili != null ? String(initial.imalYili) : '',
    konum: initial?.konum ?? '',
    aciklama: initial?.aciklama ?? '',
    kullanimAmaci: initial?.kullanimAmaci ?? '',
    kullanimDurumu: (initial?.kullanimDurumu ?? 'aktif') as EkipmanKullanimDurumu,
    teknik: (initial?.teknikOzellikler ?? {}) as Record<string, unknown>,
  });

  // Periyodik kontrol alanları (merkezi kural gerektiriyorsa veya kayıtlı kontrol varsa görünür).
  const [kontrol, setKontrol] = useState<KontrolFormState>(() =>
    kontrolStateFromRecord(initial?.kontroller?.[0]),
  );

  // Belge gereksinimleri → seçilen dosya eşlemesi (documentType → File).
  const [belgeDosyalari, setBelgeDosyalari] = useState<Record<string, File | null>>({});

  // "Diğer" / yapılandırılmamış türler için isteğe bağlı manuel belge (mevzuat zorunluluğu DEĞİL).
  const [manuelBelge, setManuelBelge] = useState<{ belgeTuru: string; aciklama: string; file: File | null }>({
    belgeTuru: '',
    aciklama: '',
    file: null,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState('');
  const [loading, setLoading] = useState(false);

  const isEdit = mode === 'edit';
  const isUzman = role === 'uzman';

  useEffect(() => {
    let cancelled = false;
    fetchEkipmanKatalog()
      .then((k) => { if (!cancelled) setKatalog(k); })
      .catch(() => { /* boş katalog — form yine de gösterilir */ })
      .finally(() => { if (!cancelled) setKatalogLoading(false); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!isUzman || isEdit) return;
    let cancelled = false;
    fetchEkipmanFirmalari()
      .then((f) => { if (!cancelled) setFirmalar(f); })
      .catch(() => { if (!cancelled) setFirmalar([]); });
    return () => { cancelled = true; };
  }, [isUzman, isEdit]);

  useEffect(() => {
    const firmaId = isEdit ? (initial?.firmaId ?? '') : isUzman ? form.firmaId : (profile?.firmaId ?? '');
    if (!firmaId) { setPersoneller([]); return; }
    let cancelled = false;
    fetchEkipmanPersonelleri(firmaId)
      .then((p) => { if (!cancelled) setPersoneller(p); })
      .catch(() => { if (!cancelled) setPersoneller([]); });
    return () => { cancelled = true; };
  }, [isEdit, isUzman, form.firmaId, initial?.firmaId, profile?.firmaId]);

  const set = useCallback((patch: Partial<typeof form>) => setForm((prev) => ({ ...prev, ...patch })), []);
  const setTeknik = useCallback((key: string, value: unknown) => {
    setForm((prev) => ({ ...prev, teknik: { ...prev.teknik, [key]: value } }));
  }, []);
  const setKontrolField = useCallback((patch: Partial<KontrolFormState>) => {
    setKontrol((prev) => ({ ...prev, ...patch }));
    (Object.keys(patch) as Array<keyof KontrolFormState>).forEach((key) => {
      setErrors((prev) => ({ ...prev, [`kontrol_${key}`]: '' }));
    });
  }, []);
  const clearError = (field: string) => setErrors((prev) => ({ ...prev, [field]: '' }));

  const grupOptions = useMemo(
    () => katalog.gruplar.map((g) => ({ value: g.id, label: g.ad })),
    [katalog.gruplar],
  );
  const turOptions = useMemo(
    () => katalog.turler.filter((t) => t.grupId === form.grupId).map((t) => ({ value: t.id, label: t.ad })),
    [katalog.turler, form.grupId],
  );
  const altTurOptions = useMemo(
    () => katalog.altTurler.filter((a) => a.turId === form.turId).map((a) => ({ value: a.id, label: a.ad })),
    [katalog.altTurler, form.turId],
  );
  // Türe özel teknik sorular (hacim vb.) sistemden KALDIRILDI. Teknik alanlar
  // hiçbir modda gösterilmez ve kayda gönderilmez.
  const teknikAlanlar: EkipmanTeknikAlan[] = [];
  const kural = useMemo<EkipmanMevzuatKurali | null>(
    () => mevzuatKuraliForTur(katalog, form.turId),
    [katalog, form.turId],
  );

  // Merkezi kuraldan periyodik kontrol zorunluluğu (backend ile birebir aynı mantık).
  const kontrolGerekli = periyodikKontrolGerekli(kural);
  const belgeGereksinimleri = kural?.belgeKurallari ?? [];
  const kontrolKriterleri = kural?.kontrolKriterleri ?? null;
  const yetkiliKisiKurallari = kural?.yetkiliKisiKurallari ?? [];
  // Doğrulanmış mevzuat kuralı olmayan türler ("Diğer" vb.) → manuel mod. Bu türlerde
  // zorunlu periyodik kontrol/belge/yetkili kuralı uydurulmaz; kullanıcı isteğe bağlı kayıt girer.
  const manuelMod = !katalogLoading && form.turId !== '' && kural === null;
  // Düzenlemede kural kontrol gerektirmese bile kayıtlı kontrol varsa bölüm gösterilir.
  const hasExistingKontrol = isEdit && (initial?.kontroller?.length ?? 0) > 0;
  const showKontrol = kontrolGerekli || hasExistingKontrol || manuelMod;
  // Kontrol bölümü başlığı: zorunlu kural varsa "Periyodik Kontrol", manuel girişte "Kontrol Bilgileri".
  const kontrolBaslik = kontrolGerekli ? 'Periyodik Kontrol' : 'Kontrol Bilgileri';
  // Backend kontrol kaydı için iki tarih de zorunludur.
  const hasKontrolTarihleri = kontrol.kontrolTarihi.trim() !== '' && kontrol.sonrakiKontrolTarihi.trim() !== '';

  // Yetkili meslek önerileri (backend'den gelen allowed_professions). Boşsa serbest metin kalır.
  const yetkiliMeslekOnerileri = useMemo(
    () => Array.from(new Set(yetkiliKisiKurallari.flatMap((r) => r.allowedProfessions))).filter(Boolean),
    [yetkiliKisiKurallari],
  );
  const yetkiliRolOnerileri = useMemo(
    () => Array.from(new Set(yetkiliKisiKurallari.flatMap((r) => r.allowedRoles))).filter(Boolean),
    [yetkiliKisiKurallari],
  );

  const mevcutBelgeler = isEdit ? (initial?.belgeler ?? []) : [];

  // Merkezi kural kontrol gerektiriyorsa zorunlu kontrol alanları. Kontrol + sonraki kontrol tarihi
  // backend persist için her zaman gerekli; ek alanlar `required_fields` içinden gelir.
  const zorunluKontrolAlanlari = useMemo(() => {
    const zorunlu = new Set<keyof KontrolFormState>();
    if (!kontrolGerekli) return zorunlu;
    zorunlu.add('kontrolTarihi');
    zorunlu.add('sonrakiKontrolTarihi');
    for (const key of kontrolKriterleri?.requiredFields ?? []) {
      const mapped = KONTROL_FIELD_KEY_MAP[key];
      if (mapped) zorunlu.add(mapped);
    }
    return zorunlu;
  }, [kontrolGerekli, kontrolKriterleri]);

  const resetTurBagimliAlanlar = useCallback(() => {
    set({ altTurId: '', teknik: {}, kullanimAmaci: '' });
    setKontrol({ ...EMPTY_KONTROL });
    setBelgeDosyalari({});
    setManuelBelge({ belgeTuru: '', aciklama: '', file: null });
  }, [set]);

  const handleGrupChange = (value: string) => {
    set({ grupId: value, turId: '' });
    resetTurBagimliAlanlar();
    clearError('grupId');
  };

  const handleTurChange = (value: string) => {
    set({ turId: value });
    resetTurBagimliAlanlar();
    clearError('turId');
  };

  const handleBelgeDosya = (documentType: string, e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] ?? null;
    setBelgeDosyalari((prev) => ({ ...prev, [documentType]: file }));
  };

  const validate = (): Record<string, string> => {
    const errs: Record<string, string> = {};
    if (isUzman && mode === 'create' && !form.firmaId) errs.firmaId = 'Firma seçimi zorunludur.';
    if (!isEdit && !form.grupId) errs.grupId = 'Ekipman grubu zorunludur.';
    if (!isEdit && !form.turId) errs.turId = 'Ekipman türü zorunludur.';
    if (!form.ad.trim()) errs.ad = 'Ekipman adı zorunludur.';
    for (const a of teknikAlanlar) {
      if (!a.zorunlu) continue;
      const v = form.teknik[a.fieldKey];
      if (v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0)) {
        errs[`teknik_${a.fieldKey}`] = `${a.label} zorunludur.`;
      }
    }
    // Periyodik kontrol gerekiyorsa zorunlu kontrol alanları doldurulmalı.
    if (kontrolGerekli) {
      for (const field of zorunluKontrolAlanlari) {
        if (!kontrol[field].trim()) {
          errs[`kontrol_${field}`] = `${KONTROL_FIELD_LABEL[field]} zorunludur.`;
        }
      }
    }
    // Zorunlu belgelerin dosyası seçilmeli (backend de doğrular; bu yalnızca görsel kontrol).
    // Düzenlemede kayıtlı bir belge zaten mevcutsa yeniden yüklemek gerekmez.
    for (const b of belgeGereksinimleri) {
      if (!b.required) continue;
      const mevcut = mevcutBelgeler.some((d) => d.belgeTuru === b.documentType);
      if (!mevcut && !belgeDosyalari[b.documentType]) {
        errs[`belge_${b.documentType}`] = `"${b.name}" belgesi zorunludur.`;
      }
    }
    return errs;
  };

  const buildTeknik = (): Record<string, unknown> => {
    const out: Record<string, unknown> = {};
    for (const a of teknikAlanlar) {
      const v = form.teknik[a.fieldKey];
      if (v === undefined || v === null || v === '') continue;
      if (a.veriTipi === 'multi_select') {
        out[a.fieldKey] = Array.isArray(v) ? v : [];
        continue;
      }
      if (a.veriTipi === 'boolean') {
        out[a.fieldKey] = v === true || v === 'true';
        continue;
      }
      if (a.veriTipi === 'number' || a.veriTipi === 'decimal') {
        const n = Number(v);
        if (Number.isFinite(n)) out[a.fieldKey] = n;
        continue;
      }
      out[a.fieldKey] = String(v);
    }
    return out;
  };

  const handleSubmit = async () => {
    if (loading) return;
    const errs = validate();
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setLoading(true);
    setSubmitError('');
    try {
      const teknik = buildTeknik();
      const base = {
        ad: form.ad.trim(),
        marka: form.marka.trim() || null,
        model: form.model.trim() || null,
        seriNo: form.seriNo.trim() || null,
        imalYili: form.imalYili ? Number(form.imalYili) : null,
        konum: form.konum.trim() || null,
        aciklama: form.aciklama.trim() || null,
        kullanimAmaci: form.kullanimAmaci.trim() || null,
        kullanimDurumu: form.kullanimDurumu,
        teknikOzellikler: teknik,
        altTurId: form.altTurId || null,
        sorumluPersonelId: form.sorumluPersonelId || null,
      };

      if (mode === 'create') {
        // Kontrol payload'ı: merkezi kural zorunlu kılıyorsa VEYA manuel modda kullanıcı
        // her iki tarihi de girdiyse (isteğe bağlı manuel kontrol kaydı) oluşturulur.
        let kontrolPayload: EkipmanCreateKontrol | null = null;
        if (kontrolGerekli || (manuelMod && hasKontrolTarihleri)) {
          kontrolPayload = {
            kontrolTarihi: kontrol.kontrolTarihi,
            sonrakiKontrolTarihi: kontrol.sonrakiKontrolTarihi,
            sonuc: kontrol.sonuc.trim() || null,
            metadata: {
              yontem: kontrol.yontem.trim() || null,
              kusur: kontrol.kusur.trim() || null,
              yetkili: kontrol.yetkili.trim() || null,
              meslek: kontrol.meslek.trim() || null,
              ekipnet_no: kontrol.ekipnetNo.trim() || null,
              isg_katip: kontrol.isgKatip.trim() || null,
              aciklama: kontrol.aciklama.trim() || null,
            },
          };
        }

        // Belge payload'ları: seçilen her dosyayı base64'e çevir (atomik create).
        const belgePayloads: EkipmanCreateBelge[] = [];
        for (const b of belgeGereksinimleri) {
          const file = belgeDosyalari[b.documentType];
          if (!file) continue;
          if (file.size > MAX_SIZE) {
            setSubmitError(`"${b.name}" dosyası 15 MB sınırını aşıyor.`);
            return;
          }
          const fileBase64 = await fileToBase64(file);
          belgePayloads.push({
            belgeTuru: b.documentType,
            fileName: file.name,
            mimeType: file.type || 'application/octet-stream',
            fileBase64,
          });
        }

        // Manuel mod ("Diğer") isteğe bağlı belge — mevzuat zorunluluğu değildir.
        if (manuelMod && manuelBelge.file) {
          if (manuelBelge.file.size > MAX_SIZE) {
            setSubmitError('Dosya boyutu 15 MB sınırını aşıyor.');
            return;
          }
          const fileBase64 = await fileToBase64(manuelBelge.file);
          belgePayloads.push({
            belgeTuru: manuelBelge.belgeTuru.trim() || 'Diğer',
            fileName: manuelBelge.file.name,
            mimeType: manuelBelge.file.type || 'application/octet-stream',
            fileBase64,
            aciklama: manuelBelge.aciklama.trim() || null,
          });
        }

        await createEkipman({
          firmaId: isUzman ? form.firmaId : (profile?.firmaId ?? ''),
          turId: form.turId,
          ...base,
          kontrol: kontrolPayload,
          belgeler: belgePayloads,
        });
        addToast({ title: 'Ekipman oluşturuldu', message: `${form.ad.trim()} başarıyla eklendi.`, type: 'success' });
      } else {
        // Dosya boyutlarını önceden doğrula (kısmi kayıt önlemek için).
        for (const b of belgeGereksinimleri) {
          const file = belgeDosyalari[b.documentType];
          if (file && file.size > MAX_SIZE) {
            setSubmitError(`"${b.name}" dosyası 15 MB sınırını aşıyor.`);
            return;
          }
        }

        await updateEkipman(initial!.id, base);

        // Periyodik kontrol: kayıtlı kontrol değiştiyse yeni kontrol kaydı eklenir (history modeli).
        const originalKontrol = kontrolStateFromRecord(initial?.kontroller?.[0]);
        const hasKontrolData = kontrol.kontrolTarihi.trim() !== '' || kontrol.sonrakiKontrolTarihi.trim() !== '';
        const kontrolDegisti = hasExistingKontrol
          ? kontrolStateChanged(originalKontrol, kontrol)
          : hasKontrolData;
        if (showKontrol && kontrolDegisti && kontrol.kontrolTarihi.trim() && kontrol.sonrakiKontrolTarihi.trim()) {
          await ekleKontrol({
            ekipmanId: initial!.id,
            kontrolTarihi: kontrol.kontrolTarihi,
            sonrakiKontrolTarihi: kontrol.sonrakiKontrolTarihi,
            sonuc: kontrol.sonuc.trim() || null,
            yontem: kontrol.yontem.trim() || null,
            kusur: kontrol.kusur.trim() || null,
            yetkili: kontrol.yetkili.trim() || null,
            meslek: kontrol.meslek.trim() || null,
            ekipnetNo: kontrol.ekipnetNo.trim() || null,
            isgKatip: kontrol.isgKatip.trim() || null,
            aciklama: kontrol.aciklama.trim() || null,
          });
        }

        // Gerekli belgeler: yeni seçilen dosyalar yüklenir (mevcut belgeler korunur).
        for (const b of belgeGereksinimleri) {
          const file = belgeDosyalari[b.documentType];
          if (!file) continue;
          await uploadBelge({ ekipmanId: initial!.id, belgeTuru: b.documentType, file });
        }

        // Manuel mod ("Diğer") isteğe bağlı belge.
        if (manuelMod && manuelBelge.file) {
          if (manuelBelge.file.size > MAX_SIZE) {
            setSubmitError('Dosya boyutu 15 MB sınırını aşıyor.');
            return;
          }
          await uploadBelge({
            ekipmanId: initial!.id,
            belgeTuru: manuelBelge.belgeTuru.trim() || 'Diğer',
            aciklama: manuelBelge.aciklama.trim() || null,
            file: manuelBelge.file,
          });
        }

        addToast({ title: 'Güncellendi', message: `${form.ad.trim()} başarıyla güncellendi.`, type: 'success' });
      }
      onSaved();
      onClose();
    } catch (err) {
      const msg = friendlyEkipmanError(err);
      setSubmitError(msg);
      addToast({ title: mode === 'create' ? 'Oluşturma başarısız' : 'Güncelleme başarısız', message: msg, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const renderTeknikAlan = (a: EkipmanTeknikAlan) => {
    const key = a.fieldKey;
    const err = errors[`teknik_${key}`];
    const common = {
      label: a.label,
      required: a.zorunlu,
      placeholder: a.placeholder ?? undefined,
      error: err,
    };

    if (a.veriTipi === 'textarea') {
      return (
        <Textarea
          key={key}
          {...common}
          value={typeof form.teknik[key] === 'string' ? (form.teknik[key] as string) : ''}
          onChange={(e) => { setTeknik(key, e.target.value); clearError(`teknik_${key}`); }}
        />
      );
    }
    if (a.veriTipi === 'boolean') {
      return (
        <div key={key} className="flex items-center gap-2 py-1">
          <Toggle
            label={a.label}
            checked={form.teknik[key] === true}
            onChange={(e) => { setTeknik(key, e.target.checked); clearError(`teknik_${key}`); }}
          />
          {a.zorunlu && <span className="text-danger-600">*</span>}
        </div>
      );
    }
    if (a.veriTipi === 'select') {
      return (
        <Select
          key={key}
          {...common}
          options={(a.secenekler ?? []).map((s) => ({ value: s, label: s }))}
          value={typeof form.teknik[key] === 'string' ? (form.teknik[key] as string) : ''}
          onChange={(e) => { setTeknik(key, e.target.value); clearError(`teknik_${key}`); }}
        />
      );
    }
    if (a.veriTipi === 'multi_select') {
      return (
        <MultiSelect
          key={key}
          label={a.label}
          required={a.zorunlu}
          error={err}
          options={(a.secenekler ?? []).map((s) => ({ value: s, label: s }))}
          value={Array.isArray(form.teknik[key]) ? (form.teknik[key] as string[]) : []}
          onChange={(vals) => { setTeknik(key, vals); clearError(`teknik_${key}`); }}
        />
      );
    }
    const type = a.veriTipi === 'number' || a.veriTipi === 'decimal' ? 'number' : a.veriTipi === 'date' ? 'date' : 'text';
    const raw = form.teknik[key];
    const val = raw == null ? '' : typeof raw === 'boolean' ? '' : Array.isArray(raw) ? '' : String(raw);
    return (
      <Input
        key={key}
        {...common}
        type={type}
        min={type === 'number' ? 0 : undefined}
        step={a.veriTipi === 'decimal' ? 'any' : undefined}
        value={val}
        onChange={(e) => { setTeknik(key, e.target.value); clearError(`teknik_${key}`); }}
      />
    );
  };

  return (
    <div className="space-y-4">
      {isUzman && mode === 'create' && (
        <Select
          label="Firma"
          required
          options={firmalar.map((f) => ({ value: f.value, label: f.label }))}
          value={form.firmaId}
          onChange={(e) => { set({ firmaId: e.target.value }); clearError('firmaId'); }}
          placeholder={firmalar.length === 0 ? 'Aktif atamanız bulunan firma yok' : 'Seçiniz'}
          error={errors.firmaId}
          disabled={firmalar.length === 0}
        />
      )}

      {isEdit ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input
            label="Ekipman Grubu"
            value={katalog.gruplar.find((g) => g.id === form.grupId)?.ad ?? '—'}
            disabled
            readOnly
          />
          <Input
            label="Ekipman Türü"
            value={katalog.turler.find((t) => t.id === form.turId)?.ad ?? '—'}
            disabled
            readOnly
          />
        </div>
      ) : (
        <>
          <Select
            label="Ekipman Grubu"
            required
            options={grupOptions}
            value={form.grupId}
            onChange={(e) => handleGrupChange(e.target.value)}
            placeholder="Seçiniz"
            error={errors.grupId}
            loading={katalogLoading}
          />
          <Select
            label="Ekipman Türü"
            required
            options={turOptions}
            value={form.turId}
            onChange={(e) => handleTurChange(e.target.value)}
            placeholder={form.grupId ? 'Seçiniz' : 'Önce grup seçiniz'}
            error={errors.turId}
            disabled={!form.grupId}
          />
          {altTurOptions.length > 0 && (
            <Select
              label="Ekipman Alt Türü"
              options={altTurOptions}
              value={form.altTurId}
              onChange={(e) => set({ altTurId: e.target.value })}
              placeholder="Opsiyonel — Seçiniz"
            />
          )}
        </>
      )}

      <Input
        label="Ekipman Adı"
        required
        placeholder="Örn. Köprülü Vinç No:1"
        value={form.ad}
        onChange={(e) => { set({ ad: e.target.value }); clearError('ad'); }}
        error={errors.ad}
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <Input label="Marka" value={form.marka} onChange={(e) => set({ marka: e.target.value })} />
        <Input label="Model" value={form.model} onChange={(e) => set({ model: e.target.value })} />
        <Input label="Seri No" value={form.seriNo} onChange={(e) => set({ seriNo: e.target.value })} />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Input
          label="İmalat Yılı"
          type="number"
          min={1900}
          max={2100}
          placeholder="Örn. 2020"
          value={form.imalYili}
          onChange={(e) => set({ imalYili: e.target.value })}
        />
        <Input label="Kullanım Yeri / Konum" placeholder="Örn. Üretim Alanı — Hat 2" value={form.konum} onChange={(e) => set({ konum: e.target.value })} />
      </div>

      <Select
        label="Sorumlu Personel"
        options={personeller.map((p) => ({ value: p.value, label: p.label }))}
        value={form.sorumluPersonelId}
        onChange={(e) => set({ sorumluPersonelId: e.target.value })}
        placeholder="Opsiyonel — Sorumlu personel seçin"
        disabled={personeller.length === 0}
      />

      <Textarea
        label="Açıklama"
        placeholder="Ekipmanla ilgili kısa açıklama"
        value={form.aciklama}
        onChange={(e) => set({ aciklama: e.target.value })}
        maxLength={500}
      />

      {manuelMod && (
        <Input
          label="Ekipmanın Gerçek Türü / Tanımı"
          placeholder="Örn. Hidrolik krikolu kaldırma platformu, taşınabilir vidalı kompresör..."
          value={form.kullanimAmaci}
          onChange={(e) => set({ kullanimAmaci: e.target.value })}
        />
      )}

      <Select
        label="Kullanım Durumu"
        options={KULLANIM_DURUMU_OPTIONS}
        value={form.kullanimDurumu}
        onChange={(e) => set({ kullanimDurumu: e.target.value as EkipmanKullanimDurumu })}
      />

      {teknikAlanlar.length > 0 && (
        <div className="pt-1 border-t isg-divider">
          <p className="text-xs font-semibold text-foreground-500 uppercase tracking-wider mb-3">Teknik Bilgiler</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {teknikAlanlar.map(renderTeknikAlan)}
          </div>
        </div>
      )}
      {manuelMod && (
        <div className="flex items-start gap-2 p-3 rounded-lg border border-background-300/30 bg-background-100 text-xs text-foreground-500">
          <i className="ri-information-line mt-0.5 flex-shrink-0" />
          <span>Bu ekipman türü için doğrulanmış mevzuat yapılandırması bulunmuyor. Ekipmanı genel bilgilerle kaydedebilir, varsa kontrol ve belge bilgilerini manuel olarak ekleyebilirsiniz.</span>
        </div>
      )}

      {showKontrol && (
        <div className="pt-1 border-t isg-divider">
          <p className="text-xs font-semibold text-foreground-500 uppercase tracking-wider mb-3">{kontrolBaslik}</p>

          {manuelMod && (
            <div className="mb-3 flex items-start gap-2 p-3 rounded-lg border border-background-300/30 bg-background-100 text-xs text-foreground-500">
              <i className="ri-information-line mt-0.5 flex-shrink-0 text-foreground-500" />
              <span>Bu ekipman türü için doğrulanmış zorunlu periyodik kontrol yapılandırması bulunmuyor. Aşağıdaki bilgiler isteğe bağlıdır ve mevzuat zorunluluğu ifade etmez.</span>
            </div>
          )}

          {kontrolKriterleri?.period?.value != null && (
            <div className="mb-3 flex items-center gap-2 p-3 rounded-lg border border-background-300/30 bg-background-100 text-sm text-foreground-700">
              <i className="ri-time-line flex-shrink-0 text-foreground-500" />
              <span>
                Kontrol periyodu: <span className="font-semibold">{periyotMetni(kontrolKriterleri.period)}</span>
                {kontrolKriterleri.period.source?.reference && (
                  <span className="text-foreground-400"> · {kontrolKriterleri.period.source.reference}</span>
                )}
              </span>
            </div>
          )}

          <div className="flex flex-col gap-3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <DatePicker label="Kontrol Tarihi" required={zorunluKontrolAlanlari.has('kontrolTarihi')} error={errors['kontrol_kontrolTarihi']} value={kontrol.kontrolTarihi} onChange={(e) => setKontrolField({ kontrolTarihi: e.target.value })} />
              <DatePicker label="Sonraki Kontrol Tarihi" required={zorunluKontrolAlanlari.has('sonrakiKontrolTarihi')} error={errors['kontrol_sonrakiKontrolTarihi']} value={kontrol.sonrakiKontrolTarihi} onChange={(e) => setKontrolField({ sonrakiKontrolTarihi: e.target.value })} />
            </div>

            {kontrolKriterleri && kontrolKriterleri.resultOptions.length > 0 ? (
              <Select
                label="Sonuç"
                required={zorunluKontrolAlanlari.has('sonuc')}
                error={errors['kontrol_sonuc']}
                options={kontrolKriterleri.resultOptions.map((o) => ({ value: o.code, label: o.label }))}
                value={kontrol.sonuc}
                onChange={(e) => setKontrolField({ sonuc: e.target.value })}
                placeholder="Sonuç seçin (isteğe bağlı)"
              />
            ) : (
              <Input
                label="Sonuç"
                required={zorunluKontrolAlanlari.has('sonuc')}
                error={errors['kontrol_sonuc']}
                value={kontrol.sonuc}
                onChange={(e) => setKontrolField({ sonuc: e.target.value })}
                placeholder="Sonuç (isteğe bağlı)"
              />
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {kontrolKriterleri && kontrolKriterleri.method.length > 0 ? (
                <Select
                  label="Kontrol Yöntemi"
                  required={zorunluKontrolAlanlari.has('yontem')}
                  error={errors['kontrol_yontem']}
                  options={kontrolKriterleri.method.map((m) => ({ value: m.code, label: m.name }))}
                  value={kontrol.yontem}
                  onChange={(e) => setKontrolField({ yontem: e.target.value })}
                  placeholder="Yöntem seçin"
                />
              ) : (
                <Input label="Kontrol Yöntemi" required={zorunluKontrolAlanlari.has('yontem')} error={errors['kontrol_yontem']} value={kontrol.yontem} onChange={(e) => setKontrolField({ yontem: e.target.value })} placeholder="Örn. Gözle muayene, NDT" />
              )}
              {kontrolKriterleri && kontrolKriterleri.defectOptions.length > 0 ? (
                <Select
                  label="Kusur / Değerlendirme"
                  required={zorunluKontrolAlanlari.has('kusur')}
                  error={errors['kontrol_kusur']}
                  options={kontrolKriterleri.defectOptions.map((o) => ({ value: o.code, label: o.label }))}
                  value={kontrol.kusur}
                  onChange={(e) => setKontrolField({ kusur: e.target.value })}
                  placeholder="Kusur seçin (varsa)"
                />
              ) : (
                <Input label="Kusur / Değerlendirme" required={zorunluKontrolAlanlari.has('kusur')} error={errors['kontrol_kusur']} value={kontrol.kusur} onChange={(e) => setKontrolField({ kusur: e.target.value })} placeholder="Tespit edilen kusur (varsa)" />
              )}
            </div>

            {kontrolKriterleri && kontrolKriterleri.criteria.length > 0 && (
              <div className="flex items-start gap-2 p-3 rounded-lg border border-background-300/30 bg-background-100 text-xs text-foreground-600">
                <i className="ri-list-check-3 flex-shrink-0 mt-0.5 text-foreground-500" />
                <div className="flex flex-col gap-0.5">
                  <span className="font-semibold text-foreground-700">Kontrol Kriterleri</span>
                  {kontrolKriterleri.criteria.map((c) => (
                    <span key={c.code}>{c.name}{c.description ? ` — ${c.description}` : ''}</span>
                  ))}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Input label="Yetkili Kişi" required={zorunluKontrolAlanlari.has('yetkili')} error={errors['kontrol_yetkili']} value={kontrol.yetkili} onChange={(e) => setKontrolField({ yetkili: e.target.value })} />
              {yetkiliMeslekOnerileri.length > 0 ? (
                <Select
                  label="Meslek"
                  required={zorunluKontrolAlanlari.has('meslek')}
                  error={errors['kontrol_meslek']}
                  options={yetkiliMeslekOnerileri.map((m) => ({ value: m, label: m }))}
                  value={kontrol.meslek}
                  onChange={(e) => setKontrolField({ meslek: e.target.value })}
                  placeholder="Meslek seçin"
                />
              ) : (
                <Input label="Meslek" required={zorunluKontrolAlanlari.has('meslek')} error={errors['kontrol_meslek']} value={kontrol.meslek} onChange={(e) => setKontrolField({ meslek: e.target.value })} />
              )}
            </div>

            {yetkiliRolOnerileri.length > 0 && (
              <div className="flex items-start gap-2 p-3 rounded-lg border border-background-300/30 bg-background-100 text-xs text-foreground-600">
                <i className="ri-shield-check-line flex-shrink-0 mt-0.5 text-foreground-500" />
                <span>Yetkili roller: {yetkiliRolOnerileri.join(', ')}</span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Input label="EKİPNET Kayıt No" required={zorunluKontrolAlanlari.has('ekipnetNo')} error={errors['kontrol_ekipnetNo']} value={kontrol.ekipnetNo} onChange={(e) => setKontrolField({ ekipnetNo: e.target.value })} placeholder="EKİPNET kayıt numarası" />
              <Input label="İSG-KATİP Sözleşme" required={zorunluKontrolAlanlari.has('isgKatip')} error={errors['kontrol_isgKatip']} value={kontrol.isgKatip} onChange={(e) => setKontrolField({ isgKatip: e.target.value })} placeholder="İSG-KATİP sözleşme/kontrat" />
            </div>
            <Textarea
              label="Açıklama"
              required={zorunluKontrolAlanlari.has('aciklama')}
              error={errors['kontrol_aciklama']}
              value={kontrol.aciklama}
              onChange={(e) => setKontrolField({ aciklama: e.target.value })}
              maxLength={500}
              placeholder="Kontrolle ilgili açıklama (isteğe bağlı)"
            />
          </div>
        </div>
      )}

      {belgeGereksinimleri.length > 0 && (
        <div className="pt-1 border-t isg-divider">
          <p className="text-xs font-semibold text-foreground-500 uppercase tracking-wider mb-1">Gerekli Belgeler</p>
          <p className="text-xs text-foreground-400 mb-3">Bu ekipman türü için merkezi kayıtlara göre istenen belgeler.</p>
          {mevcutBelgeler.length > 0 && (
            <div className="mb-3 flex flex-col gap-2">
              <p className="text-xs font-medium text-foreground-600">Mevcut Belgeler</p>
              {mevcutBelgeler.map((d) => (
                <div key={d.id} className="flex items-center gap-2 p-2 rounded-lg border border-background-300/30 bg-background-50">
                  <i className="ri-file-3-line text-secondary-600 flex-shrink-0" />
                  <span className="text-sm text-foreground-800 truncate flex-1">{d.dosyaAdi}</span>
                  <span className="text-[11px] text-foreground-500 whitespace-nowrap">{d.belgeTuru}</span>
                  <BelgeEylemleri belge={d} />
                </div>
              ))}
            </div>
          )}
          <div className="flex flex-col gap-3">
            {belgeGereksinimleri.map((b) => {
              const err = errors[`belge_${b.documentType}`];
              const mevcut = mevcutBelgeler.find((d) => d.belgeTuru === b.documentType);
              return (
                <div key={b.code} className="p-3 rounded-lg border border-background-300/30 bg-background-100">
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-sm font-medium text-foreground-800">{b.name}</span>
                    <StatusBadge tone={b.required ? 'danger' : 'neutral'}>{b.required ? 'Zorunlu' : 'Opsiyonel'}</StatusBadge>
                  </div>
                  {b.applicability && b.applicability !== 'always' && (
                    <p className="mb-1.5 text-xs text-foreground-500">Uygulama: {b.applicability}</p>
                  )}
                  {b.notes && (
                    <p className="mb-1.5 text-xs text-foreground-400">{b.notes}</p>
                  )}
                  {mevcut && (
                    <p className="mb-1.5 text-xs text-success-600 flex items-center gap-1">
                      <i className="ri-checkbox-circle-line" /> Yüklendi: {mevcut.dosyaAdi}
                    </p>
                  )}
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx,.xls,.xlsx,.odt,.ods,.txt,image/jpeg,image/png,image/webp"
                    onChange={(e) => { handleBelgeDosya(b.documentType, e); clearError(`belge_${b.documentType}`); }}
                    className="isg-input w-full text-sm py-2"
                  />
                  {belgeDosyalari[b.documentType] && (
                    <p className="mt-1 text-xs text-foreground-500 flex items-center gap-1">
                      <i className="ri-file-line" /> {belgeDosyalari[b.documentType]!.name} ({Math.round(belgeDosyalari[b.documentType]!.size / 1024)} KB)
                    </p>
                  )}
                  {err && (
                    <p className="mt-1 text-xs text-danger-600 flex items-center gap-1">
                      <i className="ri-error-warning-line" /> {err}
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {manuelMod && (
        <div className="pt-1 border-t isg-divider">
          <p className="text-xs font-semibold text-foreground-500 uppercase tracking-wider mb-1">Belgeler</p>
          <p className="text-xs text-foreground-400 mb-3">İsteğe bağlı. Bu ekipman türü için mevzuat gereği zorunlu belge yoktur; kendi belgelerinizi ekleyebilirsiniz.</p>

          {mevcutBelgeler.length > 0 && (
            <div className="mb-3 flex flex-col gap-2">
              <p className="text-xs font-medium text-foreground-600">Mevcut Belgeler</p>
              {mevcutBelgeler.map((d) => (
                <div key={d.id} className="flex items-center gap-2 p-2 rounded-lg border border-background-300/30 bg-background-50">
                  <i className="ri-file-3-line text-secondary-600 flex-shrink-0" />
                  <span className="text-sm text-foreground-800 truncate flex-1">{d.dosyaAdi}</span>
                  <span className="text-[11px] text-foreground-500 whitespace-nowrap">{d.belgeTuru}</span>
                  <BelgeEylemleri belge={d} />
                </div>
              ))}
            </div>
          )}

          <div className="flex flex-col gap-3">
            <Select
              label="Belge Türü"
              options={MANUEL_BELGE_TURLERI}
              value={manuelBelge.belgeTuru}
              onChange={(e) => setManuelBelge((prev) => ({ ...prev, belgeTuru: e.target.value }))}
              placeholder="Belge türü seçin (isteğe bağlı)"
            />
            <div>
              <label className="isg-form-label">Dosya</label>
              <input
                type="file"
                accept=".pdf,.doc,.docx,.xls,.xlsx,.odt,.ods,.txt,image/jpeg,image/png,image/webp"
                onChange={(e) => setManuelBelge((prev) => ({ ...prev, file: e.target.files?.[0] ?? null }))}
                className="isg-input w-full text-sm py-2"
              />
              {manuelBelge.file && (
                <p className="mt-1 text-xs text-foreground-500 flex items-center gap-1">
                  <i className="ri-file-line" /> {manuelBelge.file.name} ({Math.round(manuelBelge.file.size / 1024)} KB)
                </p>
              )}
            </div>
            <Textarea
              label="Açıklama"
              value={manuelBelge.aciklama}
              onChange={(e) => setManuelBelge((prev) => ({ ...prev, aciklama: e.target.value }))}
              maxLength={500}
              placeholder="Belgeyle ilgili kısa açıklama (isteğe bağlı)"
            />
          </div>
        </div>
      )}

      {submitError && (
        <Alert variant="danger">{submitError}</Alert>
      )}

      <div className="flex justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={loading}>İptal</Button>
        <Button
          variant="primary"
          size="sm"
          isLoading={loading}
          onClick={handleSubmit}
          leftIcon={mode === 'create' ? <i className="ri-add-line" /> : <i className="ri-save-line" />}
        >
          {mode === 'create' ? 'Ekipmanı Oluştur' : 'Kaydet'}
        </Button>
      </div>
    </div>
  );
}