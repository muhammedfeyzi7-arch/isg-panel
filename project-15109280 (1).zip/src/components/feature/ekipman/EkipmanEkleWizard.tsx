import { useState, useEffect, useMemo, useCallback } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import DatePicker from '@/components/ui/DatePicker';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import StatusBadge from '@/components/ui/StatusBadge';
import { useToastActions } from '@/hooks/useToast';
import { useAuth } from '@/context/AuthContext';
import {
  type EkipmanKullanimDurumu,
  type EkipmanKatalog,
  type EkipmanMevzuatKurali,
  type EkipmanCreateBelge,
  type EkipmanFirmaOption,
  createEkipman,
  fetchEkipmanKatalog,
  fetchEkipmanFirmalari,
  mevzuatKuraliForTur,
  periyodikKontrolGerekli,
  friendlyEkipmanError,
} from '@/lib/ekipmanService';
import { periyotMetni, addPeriodToDate } from './ekipmanUi';

const KULLANIM_DURUMU_OPTIONS = [
  { value: 'aktif', label: 'Aktif' },
  { value: 'arizali', label: 'Arızalı' },
  { value: 'bakimda', label: 'Bakımda' },
  { value: 'kullanim_disi', label: 'Kullanım Dışı' },
];

const VARSAYILAN_SONUC = [
  { value: 'Uygun', label: 'Uygun' },
  { value: 'Hafif Kusur', label: 'Hafif Kusur' },
  { value: 'Ağır Kusur', label: 'Ağır Kusur' },
];

const MANUEL_DEGER = '__manuel__';
const MAX_SIZE = 15 * 1024 * 1024;
const BELGE_ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.odt,.ods,.txt,image/jpeg,image/png,image/webp';

interface EkipmanEkleWizardProps {
  onClose: () => void;
  onSaved: () => void;
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      const idx = result.indexOf(',');
      resolve(idx >= 0 ? result.slice(idx + 1) : result);
    };
    reader.onerror = () => reject(new Error('Dosya okunamadı'));
    reader.readAsDataURL(file);
  });
}

/**
 * YENİ EKİPMAN — 2 adımlı sihirbaz (referans UI).
 * Adım 1: Temel Bilgiler + Periyodik Kontrol Bilgileri.
 * Adım 2: Gerekli Belgeler + Not.
 * Geometri modal motoru tarafından sabitlenir; adım değişimi yalnızca içeriği değiştirir.
 */
export default function EkipmanEkleWizard({ onClose, onSaved }: EkipmanEkleWizardProps) {
  const { addToast } = useToastActions();
  const { profile } = useAuth();
  const isUzman = (profile?.role ?? '') === 'uzman';

  const [step, setStep] = useState(0);

  const [katalog, setKatalog] = useState<EkipmanKatalog>({ gruplar: [], turler: [], altTurler: [], sablonlar: [], alanlar: [], kurallar: [] });
  const [firmalar, setFirmalar] = useState<EkipmanFirmaOption[]>([]);
  const [katalogLoading, setKatalogLoading] = useState(true);

  const [form, setForm] = useState({
    firmaId: '',
    grupId: '',
    manuelGrup: '',
    turId: '',
    altTurId: '',
    manuelTur: '',
    ad: '',
    marka: '',
    model: '',
    seriNo: '',
    kullanimDurumu: 'aktif' as EkipmanKullanimDurumu,
    kontrolTarihi: '',
    sonrakiKontrolTarihi: '',
    sonuc: '',
    ekipnetNo: '',
    isgKatip: '',
  });
  const [not, setNot] = useState('');

  // requirement document_type → seçilen dosya (zorunlu/opsiyonel belgeler).
  const [belgeFiles, setBelgeFiles] = useState<Record<string, UploadFile[]>>({});
  // Kural olmayan türler (manuel) için genel belgeler.
  const [genelFiles, setGenelFiles] = useState<UploadFile[]>([]);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetchEkipmanKatalog()
      .then((k) => { if (!cancelled) setKatalog(k); })
      .catch(() => { /* boş katalog — form gösterilir */ })
      .finally(() => { if (!cancelled) setKatalogLoading(false); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!isUzman) return;
    let cancelled = false;
    fetchEkipmanFirmalari()
      .then((f) => { if (!cancelled) setFirmalar(f); })
      .catch(() => { if (!cancelled) setFirmalar([]); });
    return () => { cancelled = true; };
  }, [isUzman]);

  const set = useCallback((patch: Partial<typeof form>) => setForm((prev) => ({ ...prev, ...patch })), []);
  const clearError = (field: string) => setErrors((prev) => ({ ...prev, [field]: '' }));

  const grupOptions = useMemo(
    () => [
      ...katalog.gruplar.map((g) => ({ value: g.id, label: g.ad })),
      { value: MANUEL_DEGER, label: 'Diğer / Manuel Ekle' },
    ],
    [katalog.gruplar],
  );

  // Manuel grup/tür için kanonik katalog hedefleri ("Diğer İş Ekipmanları" / "Diğer").
  const DIG_GRUP = useMemo(() => katalog.gruplar.find((g) => g.kod === 'DIG') ?? null, [katalog.gruplar]);
  const DIG_TUR = useMemo(() => katalog.turler.find((t) => t.kod === 'DDIG') ?? null, [katalog.turler]);
  const manuelGrupMod = form.grupId === MANUEL_DEGER;

  const grupTurleri = useMemo(
    () => (manuelGrupMod ? [] : katalog.turler.filter((t) => t.grupId === form.grupId)),
    [katalog.turler, form.grupId, manuelGrupMod],
  );

  const turOptions = useMemo(
    () => [
      ...grupTurleri.map((t) => ({ value: t.id, label: t.ad })),
      { value: MANUEL_DEGER, label: 'Manuel Gir' },
    ],
    [grupTurleri],
  );

  const altTurOptions = useMemo(
    () => katalog.altTurler.filter((a) => a.turId === form.turId).map((a) => ({ value: a.id, label: a.ad })),
    [katalog.altTurler, form.turId],
  );

  const manuelTurSecim = form.turId === MANUEL_DEGER;
  const manuelMod = manuelTurSecim || manuelGrupMod;

  // Manuel girildiğinde kullanılacak gerçek katalog türü = grubun "Diğer" türü.
  const manuelTurId = useMemo(() => {
    if (manuelGrupMod) return DIG_TUR?.id ?? '';
    if (!manuelTurSecim) return '';
    const diger = grupTurleri.find((t) => t.ad === 'Diğer' || t.kod.endsWith('DIG'));
    return diger?.id ?? DIG_TUR?.id ?? '';
  }, [manuelGrupMod, manuelTurSecim, grupTurleri, DIG_TUR]);

  const effectiveTurId = manuelGrupMod
    ? (DIG_TUR?.id ?? '')
    : (manuelTurSecim ? manuelTurId : form.turId);

  const kural: EkipmanMevzuatKurali | null = useMemo(
    () => mevzuatKuraliForTur(katalog, effectiveTurId),
    [katalog, effectiveTurId],
  );
  const kontrolGerekli = periyodikKontrolGerekli(kural);
  const belgeGereksinimleri = kural?.belgeKurallari ?? [];
  const kriterler = kural?.kontrolKriterleri ?? null;
  const periyot = kriterler?.period ?? null;

  const sonucOptions = useMemo(
    () => (kriterler?.resultOptions?.length
      ? kriterler.resultOptions.map((o) => ({ value: o.code, label: o.label }))
      : VARSAYILAN_SONUC),
    [kriterler],
  );

  const resetTurBagimli = useCallback(() => {
    set({ altTurId: '', sonuc: '', kontrolTarihi: '', sonrakiKontrolTarihi: '' });
    setBelgeFiles({});
    setGenelFiles([]);
  }, [set]);

  const handleGrupChange = (value: string) => {
    set({ grupId: value, turId: value === MANUEL_DEGER ? MANUEL_DEGER : '' });
    resetTurBagimli();
    clearError('grupId');
  };

  const handleTurChange = (value: string) => {
    set({ turId: value, manuelTur: value === MANUEL_DEGER ? form.manuelTur : '' });
    resetTurBagimli();
    clearError('turId');
  };

  const handleKontrolTarihi = (value: string) => {
    setForm((prev) => {
      const next = { ...prev, kontrolTarihi: value };
      if (value && !prev.sonrakiKontrolTarihi && periyot) {
        const oneri = addPeriodToDate(value, periyot);
        if (oneri) next.sonrakiKontrolTarihi = oneri;
      }
      return next;
    });
  };

  const validateStep1 = (): boolean => {
    const errs: Record<string, string> = {};
    if (isUzman && !form.firmaId) errs.firmaId = 'Firma seçimi zorunludur.';
    if (!form.grupId) errs.grupId = 'Ekipman grubu zorunludur.';
    if (manuelGrupMod && !form.manuelGrup.trim()) errs.manuelGrup = 'Ekipman grubunu yazın.';
    if (!form.turId) errs.turId = 'Ekipman türü zorunludur.';
    if (manuelMod && !form.manuelTur.trim()) errs.manuelTur = 'Ekipman türünü yazın.';
    if (!form.ad.trim()) errs.ad = 'Ekipman adı zorunludur.';
    if (kontrolGerekli && !form.kontrolTarihi) errs.kontrolTarihi = 'Son kontrol tarihi zorunludur.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleNext = () => {
    if (validateStep1()) {
      setStep(1);
      setSubmitError('');
    }
  };

  const handleSubmit = async () => {
    if (loading) return;
    setSubmitError('');
    // Adım 1 alanları her zaman yeniden doğrulanır (kullanıcı geri dönüp değiştirmiş olabilir).
    if (!validateStep1()) { setStep(0); return; }

    if (manuelMod && !manuelTurId) {
      setSubmitError('Bu grup için manuel tür kaydı bulunamıyor. Lütfen listeden bir tür seçin.');
      setStep(0);
      return;
    }
    // Zorunlu belgeler seçilmiş mi?
    const eksik: string[] = [];
    for (const b of belgeGereksinimleri) {
      if (!b.required) continue;
      const f = belgeFiles[b.documentType]?.[0]?.raw;
      if (!f) eksik.push(b.name);
    }
    if (eksik.length > 0) {
      setSubmitError(`Zorunlu belgeler eksik: ${eksik.join(', ')}`);
      return;
    }

    setLoading(true);
    try {
      const belgeler: EkipmanCreateBelge[] = [];
      for (const b of belgeGereksinimleri) {
        const raw = belgeFiles[b.documentType]?.[0]?.raw;
        if (!raw) continue;
        if (raw.size > MAX_SIZE) throw new Error(`"${b.name}" dosyası 15 MB sınırını aşıyor.`);
        belgeler.push({
          belgeTuru: b.documentType,
          fileName: raw.name,
          mimeType: raw.type || 'application/octet-stream',
          fileBase64: await fileToBase64(raw),
        });
      }
      // Kural olmayan (manuel) türlerde genel belgeler isteğe bağlıdır.
      for (const uf of genelFiles) {
        const raw = uf.raw;
        if (!raw) continue;
        if (raw.size > MAX_SIZE) throw new Error(`"${raw.name}" dosyası 15 MB sınırını aşıyor.`);
        belgeler.push({
          belgeTuru: 'Diğer',
          fileName: raw.name,
          mimeType: raw.type || 'application/octet-stream',
          fileBase64: await fileToBase64(raw),
        });
      }

      await createEkipman({
        firmaId: isUzman ? form.firmaId : (profile?.firmaId ?? ''),
        turId: effectiveTurId,
        altTurId: form.altTurId || null,
        ad: form.ad.trim(),
        marka: form.marka.trim() || null,
        model: form.model.trim() || null,
        seriNo: form.seriNo.trim() || null,
        kullanimDurumu: form.kullanimDurumu,
        kullanimAmaci: [
          manuelGrupMod ? `Grup: ${form.manuelGrup.trim()}` : '',
          manuelMod ? `Tür: ${form.manuelTur.trim()}` : '',
        ].filter(Boolean).join(' · ') || null,
        aciklama: not.trim() || null,
        teknikOzellikler: {},
        kontrol: form.kontrolTarihi && form.sonrakiKontrolTarihi
          ? {
              kontrolTarihi: form.kontrolTarihi,
              sonrakiKontrolTarihi: form.sonrakiKontrolTarihi,
              sonuc: form.sonuc.trim() || null,
              metadata: {
                ekipnet_no: form.ekipnetNo.trim() || null,
                isg_katip: form.isgKatip.trim() || null,
              },
            }
          : null,
        belgeler,
      });

      addToast({ title: 'Ekipman oluşturuldu', message: `${form.ad.trim()} başarıyla eklendi.`, type: 'success' });
      onSaved();
      onClose();
    } catch (err) {
      const msg = friendlyEkipmanError(err);
      setSubmitError(msg);
    } finally {
      setLoading(false);
    }
  };

  const isSonucRequired = false; // §6: gereksiz zorunlu alan yok

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* STEPPER */}
      <div className="flex items-center justify-center gap-2 pb-3 flex-shrink-0">
        <StepNode index={1} title="Ekipman Bilgileri" subtitle="Temel bilgiler ve kontrol bilgileri" state={step === 0 ? 'active' : 'done'} />
        <span className={`h-px w-10 sm:w-16 ${step >= 1 ? 'bg-primary-500' : 'bg-background-300 dark:bg-background-400/40'}`} />
        <StepNode index={2} title="Belgeler ve Not" subtitle="Gerekli belgeleri yükleyin." state={step === 1 ? 'active' : 'todo'} />
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane pr-0.5">
        {step === 0 ? (
          <div className="space-y-3">
            {/* TEMEL BİLGİLER */}
            <div className="isg-card p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                  <i className="ri-tools-line text-primary-600 dark:text-primary-400" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-foreground-950">Temel Bilgiler</h4>
                  <p className="text-xs text-foreground-500">Ekipmana ait genel bilgileri girin.</p>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {isUzman && (
                  <Select
                    label="Firma"
                    required
                    options={firmalar.map((f) => ({ value: f.value, label: f.label }))}
                    value={form.firmaId}
                    onChange={(e) => { set({ firmaId: e.target.value }); clearError('firmaId'); }}
                    placeholder={firmalar.length === 0 ? 'Aktif atamanız bulunan firma yok' : 'Seçiniz'}
                    error={errors.firmaId}
                    disabled={firmalar.length === 0}
                  />
                )}
                <Select
                  label="Ekipman Grubu"
                  required
                  options={grupOptions}
                  value={form.grupId}
                  onChange={(e) => handleGrupChange(e.target.value)}
                  placeholder="Seçiniz"
                  error={errors.grupId}
                  loading={katalogLoading}
                />
                {manuelGrupMod && (
                  <Input
                    label="Ekipman Grubu (Manuel)"
                    required
                    placeholder="Örn. Özel Üretim Tezgâhları"
                    value={form.manuelGrup}
                    onChange={(e) => { set({ manuelGrup: e.target.value }); clearError('manuelGrup'); }}
                    error={errors.manuelGrup}
                  />
                )}
                <Select
                  label="Ekipman Türü"
                  required
                  options={turOptions}
                  value={form.turId}
                  onChange={(e) => handleTurChange(e.target.value)}
                  placeholder={form.grupId ? 'Seçiniz' : 'Önce grup seçiniz'}
                  error={errors.turId}
                  disabled={!form.grupId}
                />
                {manuelMod ? (
                  <Input
                    label="Ekipman Türü (Manuel)"
                    required
                    placeholder="Örn. Hidrolik krikolu kaldırma platformu"
                    value={form.manuelTur}
                    onChange={(e) => { set({ manuelTur: e.target.value }); clearError('manuelTur'); }}
                    error={errors.manuelTur}
                  />
                ) : altTurOptions.length > 0 ? (
                  <Select
                    label="Ekipman Alt Türü"
                    options={altTurOptions}
                    value={form.altTurId}
                    onChange={(e) => set({ altTurId: e.target.value })}
                    placeholder="Opsiyonel — Seçiniz"
                  />
                ) : null}
                <Input
                  label="Ekipman Adı"
                  required
                  placeholder="Örn. 4. Mobil Vinç No:1"
                  value={form.ad}
                  onChange={(e) => { set({ ad: e.target.value }); clearError('ad'); }}
                  error={errors.ad}
                />
                <Input
                  label="Marka"
                  placeholder="Örn. Caterpillar"
                  value={form.marka}
                  onChange={(e) => set({ marka: e.target.value })}
                />
                <Input
                  label="Model"
                  placeholder="Örn. 320D"
                  value={form.model}
                  onChange={(e) => set({ model: e.target.value })}
                />
                <Input
                  label="Seri No"
                  placeholder="Örn. CAT0320DXXXX"
                  value={form.seriNo}
                  onChange={(e) => set({ seriNo: e.target.value })}
                />
                <Select
                  label="Kullanım Durumu"
                  required
                  options={KULLANIM_DURUMU_OPTIONS}
                  value={form.kullanimDurumu}
                  onChange={(e) => set({ kullanimDurumu: e.target.value as EkipmanKullanimDurumu })}
                />
              </div>
            </div>

            {/* PERİYODİK KONTROL BİLGİLERİ */}
            <div className="isg-card p-4">
              <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                    <i className="ri-calendar-check-line text-primary-600 dark:text-primary-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-foreground-950">Periyodik Kontrol Bilgileri</h4>
                    <p className="text-xs text-foreground-500">Ekipmana ait periyodik kontrol bilgilerini girin.</p>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-primary-50 dark:bg-primary-500/15 text-[11px] text-primary-700 dark:text-primary-400">
                  <i className="ri-information-line" />
                  Kontrol periyodu, ekipman türüne göre otomatik önerilir.
                </span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <Input
                  label="Kontrol Periyodu"
                  value={periyotMetni(periyot) ? `${periyotMetni(periyot)} (Önerilen)` : kontrolGerekli ? '—' : 'Zorunlu değil'}
                  disabled
                  readOnly
                />
                <DatePicker
                  label="Son Kontrol Tarihi"
                  required={kontrolGerekli}
                  value={form.kontrolTarihi}
                  onChange={(e) => { handleKontrolTarihi(e.target.value); clearError('kontrolTarihi'); }}
                  error={errors.kontrolTarihi}
                />
                <DatePicker
                  label="Sonraki Kontrol Tarihi"
                  value={form.sonrakiKontrolTarihi}
                  onChange={(e) => set({ sonrakiKontrolTarihi: e.target.value })}
                />
                <Select
                  label="Sonuç"
                  required={isSonucRequired}
                  options={sonucOptions}
                  value={form.sonuc}
                  onChange={(e) => set({ sonuc: e.target.value })}
                  placeholder="Seçiniz"
                />
                <Input
                  label="EKİPNET Kayıt No"
                  value={form.ekipnetNo}
                  onChange={(e) => set({ ekipnetNo: e.target.value })}
                  placeholder="EKİPNET kayıt numarası"
                />
                <Input
                  label="İSG-KATİP Sözleşme"
                  value={form.isgKatip}
                  onChange={(e) => set({ isgKatip: e.target.value })}
                  placeholder="İSG-KATİP sözleşme/kontrat"
                />
              </div>
              {!kontrolGerekli && (
                <p className="mt-2 text-xs text-foreground-400">
                  Bu ekipman türü için doğrulanmış zorunlu periyodik kontrol yapılandırması bulunmuyor; bilgiler isteğe bağlıdır.
                </p>
              )}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            {/* GEREKLİ BELGELER */}
            <div className="isg-card p-4">
              <div className="flex items-start justify-between gap-3 mb-3 flex-wrap">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                    <i className="ri-folder-2-line text-primary-600 dark:text-primary-400" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-foreground-950">Gerekli Belgeler</h4>
                    <p className="text-xs text-foreground-500">Bu ekipman türü için merkezi kayıtlara göre istenen belgeleri yükleyin.</p>
                  </div>
                </div>
                {belgeGereksinimleri.length > 0 && (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-primary-50 dark:bg-primary-500/15 text-[11px] text-primary-700 dark:text-primary-400">
                    <i className="ri-information-line" />
                    Ekipman türüne göre zorunlu belgeler listelenmektedir.
                  </span>
                )}
              </div>

              {belgeGereksinimleri.length > 0 ? (
                <div className="space-y-3">
                  {belgeGereksinimleri.map((b) => (
                    <div key={b.code} className="rounded-lg border border-background-300/25 dark:border-background-400/20 p-3">
                      <div className="flex items-center justify-between gap-2 mb-2">
                        <span className="text-sm font-medium text-foreground-800">{b.name}</span>
                        <StatusBadge tone={b.required ? 'danger' : 'neutral'}>
                          {b.required ? 'Zorunlu' : 'Opsiyonel'}
                        </StatusBadge>
                      </div>
                      <FileUpload
                        accept={BELGE_ACCEPT}
                        files={belgeFiles[b.documentType] ?? []}
                        onChange={(files) => setBelgeFiles((prev) => ({ ...prev, [b.documentType]: files }))}
                        helpText="PDF, JPG, PNG, DOC, DOCX (Maks. 15 MB)"
                      />
                    </div>
                  ))}
                </div>
              ) : (
                <div>
                  <p className="text-xs text-foreground-500 mb-2">
                    Bu ekipman türü için mevzuat gereği zorunlu belge yoktur. İsteğe bağlı belge ekleyebilirsiniz.
                  </p>
                  <FileUpload
                    accept={BELGE_ACCEPT}
                    multiple
                    files={genelFiles}
                    onChange={setGenelFiles}
                    helpText="PDF, JPG, PNG, DOC, DOCX (Maks. 15 MB)"
                  />
                </div>
              )}
            </div>

            {/* NOT */}
            <div className="isg-card p-4">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-8 h-8 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                  <i className="ri-sticky-note-line text-primary-600 dark:text-primary-400" />
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-foreground-950">Not</h4>
                  <p className="text-xs text-foreground-500">Bu ekipmanla ilgili ek bilgi, açıklama veya not ekleyebilirsiniz.</p>
                </div>
              </div>
              <Textarea
                value={not}
                onChange={(e) => setNot(e.target.value)}
                maxLength={500}
                placeholder="Not eklemek isterseniz..."
              />
              <p className="mt-1 text-[11px] text-foreground-400 text-right">{not.length}/500</p>
            </div>
          </div>
        )}

        {submitError && (
          <Alert variant="danger" className="mt-3">{submitError}</Alert>
        )}
      </div>

      {/* FOOTER */}
      <div className="flex items-center justify-between gap-2 pt-3 mt-3 border-t isg-divider flex-shrink-0">
        {step === 0 ? (
          <Button variant="ghost" size="sm" leftIcon={<i className="ri-close-line" />} onClick={onClose} disabled={loading}>İptal</Button>
        ) : (
          <Button variant="ghost" size="sm" leftIcon={<i className="ri-arrow-left-line" />} onClick={() => setStep(0)} disabled={loading}>Geri</Button>
        )}
        {step === 0 ? (
          <Button variant="primary" size="sm" rightIcon={<i className="ri-arrow-right-line" />} onClick={handleNext}>
            Devam
          </Button>
        ) : (
          <Button variant="primary" size="sm" leftIcon={<i className="ri-check-line" />} isLoading={loading} onClick={handleSubmit}>
            Ekipmanı Kaydet
          </Button>
        )}
      </div>
    </div>
  );
}

/** Sihirbaz adım düğümü (referans tasarımdaki büyük daire + başlık/alt başlık). */
function StepNode({ index, title, subtitle, state }: { index: number; title: string; subtitle: string; state: 'active' | 'done' | 'todo' }) {
  return (
    <div className="flex items-center gap-2.5">
      <span className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${
        state === 'done'
          ? 'bg-primary-500 text-inverse'
          : state === 'active'
            ? 'bg-primary-500 text-inverse'
            : 'bg-background-200 dark:bg-background-300/50 text-foreground-500'
      }`}>
        {state === 'done' ? <i className="ri-check-line" /> : index}
      </span>
      <div className="min-w-0 hidden sm:block">
        <p className={`text-sm font-semibold whitespace-nowrap ${state === 'todo' ? 'text-foreground-500' : 'text-foreground-950'}`}>{title}</p>
        <p className="text-[11px] text-foreground-400 whitespace-nowrap">{subtitle}</p>
      </div>
    </div>
  );
}