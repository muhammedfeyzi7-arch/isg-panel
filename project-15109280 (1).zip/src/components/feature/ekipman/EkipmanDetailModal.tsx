import { useState, useEffect, useRef, useMemo, type ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import EmptyState from '@/components/ui/EmptyState';
import ImageViewer, { type ImageViewerItem } from '@/components/ui/ImageViewer';
import DropdownPanel from '@/components/ui/DropdownPanel';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import QRCode from 'qrcode';
import {
  type EkipmanData,
  type EkipmanDetailData,
  type EkipmanKatalog,
  type EkipmanBelge,
  type EkipmanKontrol,
  fetchEkipmanDetail,
  fetchEkipmanKatalog,
  deleteEkipman,
  silBelge,
  uploadBelge,
  getBelgeUrl,
  mapKontrolMeta,
  mevzuatKuraliForTur,
  periyodikKontrolGerekli,
  getPeriodicControlTimeStatus,
  buildEkipmanQrUrl,
  yenileEkipmanQr,
  friendlyEkipmanError,
} from '@/lib/ekipmanService';
import {
  kullanimDurumuBadgeVariant,
  kontrolDurumuBadgeVariant,
  kullanimDurumuIcon,
  formatEkipmanDate,
  formatEkipmanDateTime,
  belgeGorunum,
  isImageMime,
  formatFileSize,
  periyotMetni,
  downloadBlob,
} from './ekipmanUi';
import EkipmanFormModal from './EkipmanFormModal';
import BelgeEkleModal from './BelgeEkleModal';
import BelgeDuzenleModal from './BelgeDuzenleModal';
import KontrolEkleModal from './KontrolEkleModal';
import BakimEkleModal from './BakimEkleModal';
import BelgeEylemleri from './BelgeEylemleri';

interface EkipmanDetailModalProps {
  row: EkipmanData;
  onClose: () => void;
  onChanged: () => void;
}

function isAgirKusur(sonuc: string | null): boolean {
  if (!sonuc) return false;
  const s = sonuc.toLocaleLowerCase('tr');
  return s.includes('ağır') || s.includes('agir');
}

function sonucVariant(sonuc: string): 'danger' | 'success' | 'warning' {
  if (isAgirKusur(sonuc)) return 'danger';
  return sonuc.toLocaleLowerCase('tr').includes('uygun') ? 'success' : 'warning';
}

/** Görsel belgelerin yetkili signed URL'lerini yükler; sıralı galeri modeli üretir. */
function useFotoGaleri(fotoBelgeler: EkipmanBelge[]) {
  const [urls, setUrls] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const idsKey = useMemo(() => fotoBelgeler.map((b) => b.id).join(','), [fotoBelgeler]);

  useEffect(() => {
    let cancelled = false;
    if (fotoBelgeler.length === 0) { setUrls({}); setLoading(false); return () => { cancelled = true; }; }
    setLoading(true);
    Promise.all(
      fotoBelgeler.map((b) =>
        getBelgeUrl(b.id, 'view')
          .then((u) => [b.id, u] as const)
          .catch(() => [b.id, ''] as const),
      ),
    ).then((pairs) => {
      if (!cancelled) {
        setUrls(Object.fromEntries(pairs));
        setLoading(false);
      }
    });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idsKey, fotoBelgeler.length]);

  const gallery: ImageViewerItem[] = fotoBelgeler
    .filter((b) => urls[b.id])
    .map((b) => ({ src: urls[b.id], alt: b.dosyaAdi, fileName: b.dosyaAdi }));

  const indexOf = (id: string): number => fotoBelgeler.filter((b) => urls[b.id]).findIndex((b) => b.id === id);

  return { urls, loading, gallery, indexOf };
}

interface MenuItem {
  key: string;
  label: string;
  icon: string;
  onClick: () => void;
  danger?: boolean;
}

/** Ortak aksiyon menüsü — Modal Engine ile uyumlu (DropdownPanel + portal). */
function ActionMenu({
  items,
  label,
  icon = 'ri-more-2-line',
  variant = 'ghost',
  align = 'end',
}: {
  items: MenuItem[];
  label?: string;
  icon?: string;
  variant?: 'ghost' | 'secondary' | 'primary';
  align?: 'start' | 'end';
}) {
  const [open, setOpen] = useState(false);
  const anchorRef = useRef<HTMLButtonElement | null>(null);

  const btnClass = variant === 'primary'
    ? 'inline-flex items-center gap-1.5 px-3 h-9 rounded-md bg-primary-500 text-inverse text-sm font-medium hover:bg-primary-600 transition-colors cursor-pointer whitespace-nowrap'
    : variant === 'secondary'
      ? 'inline-flex items-center gap-1.5 px-3 h-9 rounded-md bg-background-100 border border-background-300/40 text-foreground-700 text-sm font-medium hover:bg-background-200 transition-colors cursor-pointer whitespace-nowrap'
      : 'inline-flex items-center justify-center w-9 h-9 rounded-md text-foreground-600 hover:bg-background-200 transition-colors cursor-pointer';

  return (
    <>
      <button
        ref={anchorRef}
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={btnClass}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={label ?? 'İşlemler'}
      >
        {label ? (
          <>
            <i className={icon} />
            <span>{label}</span>
            <i className="ri-arrow-down-s-line" />
          </>
        ) : (
          <i className={icon} />
        )}
      </button>
      <DropdownPanel
        open={open}
        anchorRef={anchorRef}
        onClose={() => setOpen(false)}
        align={align}
        minWidth={200}
        className="isg-popover"
      >
        <div className="p-1 flex flex-col" role="menu">
          {items.map((it) => (
            <button
              key={it.key}
              type="button"
              role="menuitem"
              onClick={() => { setOpen(false); it.onClick(); }}
              className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm text-left transition-colors cursor-pointer whitespace-nowrap ${
                it.danger
                  ? 'text-danger-600 hover:bg-danger-500/10'
                  : 'text-foreground-700 hover:bg-background-200/70'
              }`}
            >
              <i className={`${it.icon} text-base`} />
              {it.label}
            </button>
          ))}
        </div>
      </DropdownPanel>
    </>
  );
}

/** Etiket + değer satırı (referans tasarımdaki ikonlu bilgi satırı). */
function Row({ icon, label, value }: { icon: string; label: string; value: ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5 border-b isg-divider last:border-0">
      <span className="flex items-center gap-2 text-xs text-foreground-500 flex-shrink-0">
        <i className={`${icon} text-foreground-400`} />
        {label}
      </span>
      <span className="text-sm font-medium text-foreground-800 text-right break-words min-w-0">{value}</span>
    </div>
  );
}

export default function EkipmanDetailModal({ row, onClose, onChanged }: EkipmanDetailModalProps) {
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const { openModal, closeModal } = useModalActions();

  const [localRow, setLocalRow] = useState<EkipmanDetailData>({ ...row, belgeler: [], kontroller: [], bakimlar: [], gecmis: [] });
  const [busy, setBusy] = useState(false);
  const [katalog, setKatalog] = useState<EkipmanKatalog>({ gruplar: [], turler: [], altTurler: [], sablonlar: [], alanlar: [], kurallar: [] });
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [qrLoading, setQrLoading] = useState(true);
  const [qrBusy, setQrBusy] = useState(false);
  const [fotoUploading, setFotoUploading] = useState(false);

  const editModalIdRef = useRef('');
  const belgeModalIdRef = useRef('');
  const belgeDuzenleModalIdRef = useRef('');
  const kontrolModalIdRef = useRef('');
  const bakimModalIdRef = useRef('');
  const fotoInputRef = useRef<HTMLInputElement>(null);

  // Yetkili tüm roller (uzman dahil) ekipmanı yönetebilir; backend de scope doğrular.
  const canManage = true;

  const refresh = () => {
    fetchEkipmanDetail(row.id).then(setLocalRow).catch(() => {});
  };

  useEffect(() => {
    let cancelled = false;
    fetchEkipmanDetail(row.id)
      .then((fresh) => { if (!cancelled) setLocalRow(fresh); })
      .catch(() => { /* satır zaten yetkili; sessiz korunur */ });
    return () => { cancelled = true; };
  }, [row.id]);

  useEffect(() => {
    let cancelled = false;
    fetchEkipmanKatalog()
      .then((k) => { if (!cancelled) setKatalog(k); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setQrLoading(true);
    // QR, uygulamanın GÜVENLİ QR kapısına giden tam URL'i taşır. URL yalnızca
    // opak erişim anahtarını içerir; firma/ekipman/kullanıcı kimliği İÇERMEZ.
    QRCode.toDataURL(buildEkipmanQrUrl(localRow.qrReference), { width: 240, margin: 1 })
      .then((url) => { if (!cancelled) setQrDataUrl(url); })
      .catch(() => { if (!cancelled) setQrDataUrl(''); })
      .finally(() => { if (!cancelled) setQrLoading(false); });
    return () => { cancelled = true; };
  }, [localRow.qrReference]);

  const altTurAd = useMemo(
    () => katalog.altTurler.find((a) => a.id === localRow.ekipmanAltTuruId)?.ad ?? '—',
    [katalog.altTurler, localRow.ekipmanAltTuruId],
  );

  const kural = mevzuatKuraliForTur(katalog, localRow.ekipmanTuruId);
  const kontrolGerekli = periyodikKontrolGerekli(kural);
  const kontrolEksik = kontrolGerekli && localRow.kontroller.length === 0;
  const kontrolSure = getPeriodicControlTimeStatus(localRow.sonrakiKontrolTarihi);
  const kontrolPeriyot = periyotMetni(kural?.kontrolKriterleri?.period ?? null);

  const fotoBelgeler = localRow.belgeler.filter((b) => isImageMime(b.mimeType));
  const dokumanBelgeler = localRow.belgeler.filter((b) => !isImageMime(b.mimeType));
  const { urls: fotoUrls, gallery: fotoGaleri, indexOf: fotoIndex } = useFotoGaleri(fotoBelgeler);

  // TEK KAYNAK: kontrol geçmişi backend'den gelir. Aynı ekipman + aynı kontrol
  // tarihi için (varsa eski) tekrarlı kayıtlar gösterimde TEKİLLEŞTİRİLİR; en
  // güncel/ilk kayıt esas alınır. Böylece özet ve geçmiş aynı kaydı iki kez
  // göstermez ve "Kayıtlar (N)" sayısı gerçek geçmişi yansıtır.
  const benzersizKontroller = useMemo(() => {
    const gorulen = new Set<string>();
    const sonuc: EkipmanKontrol[] = [];
    for (const k of localRow.kontroller) {
      const anahtar = k.kontrolTarihi || k.id;
      if (gorulen.has(anahtar)) continue;
      gorulen.add(anahtar);
      sonuc.push(k);
    }
    return sonuc;
  }, [localRow.kontroller]);

  const sonKontrol = localRow.kontroller[0] ?? null;
  const sonKontrolMeta = sonKontrol ? mapKontrolMeta(sonKontrol.metadata) : null;
  const agirKusur = localRow.kontroller.some((k) => isAgirKusur(k.sonuc));
  const kontrolUyari = kontrolGerekli && (kontrolEksik || kontrolSure.state === 'gecmis' || kontrolSure.state === 'bugun');

  const fotoKart = fotoBelgeler[0] ?? null;
  const digerFoto = fotoBelgeler.slice(1);

  const handleFotoEkle = (files: FileList | null) => {
    if (!files || files.length === 0 || fotoUploading) return;
    const list = Array.from(files).filter((f) => isImageMime(f.type));
    if (list.length === 0) {
      addToast({ title: 'Geçersiz dosya', message: 'Yalnızca JPG, PNG veya WEBP yükleyebilirsiniz.', type: 'error' });
      return;
    }
    setFotoUploading(true);
    Promise.all(list.map((file) => uploadBelge({ ekipmanId: localRow.id, belgeTuru: 'Fotoğraf', file })))
      .then(() => {
        addToast({ title: 'Fotoğraf eklendi', message: `${list.length} fotoğraf yüklendi.`, type: 'success' });
        refresh();
        onChanged();
      })
      .catch((err) => addToast({ title: 'Yükleme başarısız', message: friendlyEkipmanError(err), type: 'error' }))
      .finally(() => setFotoUploading(false));
  };

  const handleBelgeSil = (belge: EkipmanBelge, tip: 'foto' | 'belge') => {
    confirm({
      title: tip === 'foto' ? 'Fotoğrafı Sil' : 'Belgeyi Sil',
      message: tip === 'foto'
        ? 'Bu ekipman fotoğrafını silmek istediğinize emin misiniz? Bu işlem geri alınamaz.'
        : `${belge.dosyaAdi} kalıcı olarak silinecek. Bu işlem geri alınamaz.`,
      variant: 'danger',
      confirmText: 'Evet, Sil',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        silBelge(belge.id)
          .then(() => {
            addToast({ title: 'Silindi', message: tip === 'foto' ? 'Fotoğraf kalıcı olarak silindi.' : `${belge.dosyaAdi} silindi.`, type: 'success' });
            refresh();
            onChanged();
          })
          .catch((err) => addToast({ title: 'Silme başarısız', message: friendlyEkipmanError(err), type: 'error' }));
      },
    });
  };

  const handleEdit = () => {
    if (!canManage) return;
    const id = openModal({
      title: 'Ekipman Düzenle',
      description: localRow.ekipmanNo,
      variant: 'form',
      width: 680,
      minWidth: 440,
      minHeight: 480,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EkipmanFormModal
          mode="edit"
          initial={localRow}
          onClose={() => closeModal(editModalIdRef.current)}
          onSaved={() => { refresh(); onChanged(); }}
        />
      ),
    });
    editModalIdRef.current = id;
  };

  const handleBelgeEkle = () => {
    const id = openModal({
      title: 'Belge Ekle',
      description: localRow.ekipmanNo,
      variant: 'form',
      width: 560,
      minWidth: 400,
      minHeight: 420,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <BelgeEkleModal
          ekipmanId={localRow.id}
          onClose={() => closeModal(belgeModalIdRef.current)}
          onSaved={() => { refresh(); onChanged(); }}
        />
      ),
    });
    belgeModalIdRef.current = id;
  };

  const handleBelgeDuzenle = (belge: EkipmanBelge) => {
    if (!canManage) return;
    const id = openModal({
      title: 'Belgeyi Düzenle',
      description: belge.dosyaAdi,
      variant: 'form',
      width: 560,
      minWidth: 400,
      minHeight: 420,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <BelgeDuzenleModal
          belge={belge}
          onClose={() => closeModal(belgeDuzenleModalIdRef.current)}
          onSaved={() => { refresh(); onChanged(); }}
        />
      ),
    });
    belgeDuzenleModalIdRef.current = id;
  };

  const handleKontrolEkle = () => {
    const id = openModal({
      title: 'Periyodik Kontrol Ekle',
      description: localRow.ekipmanNo,
      variant: 'form',
      width: 640,
      minWidth: 420,
      minHeight: 420,
      bodyLayout: 'fill',
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <KontrolEkleModal
          ekipmanId={localRow.id}
          kural={kural}
          onClose={() => closeModal(kontrolModalIdRef.current)}
          onSaved={() => { refresh(); onChanged(); }}
        />
      ),
    });
    kontrolModalIdRef.current = id;
  };

  const handleBakimEkle = () => {
    const id = openModal({
      title: 'Bakım Kaydı Ekle',
      description: localRow.ekipmanNo,
      variant: 'form',
      width: 560,
      minWidth: 400,
      minHeight: 480,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <BakimEkleModal
          ekipmanId={localRow.id}
          onClose={() => closeModal(bakimModalIdRef.current)}
          onSaved={() => { refresh(); onChanged(); }}
        />
      ),
    });
    bakimModalIdRef.current = id;
  };

  const handleKaldir = () => {
    if (busy) return;
    confirm({
      title: 'Ekipmanı Sil',
      message: `${localRow.ad} (${localRow.ekipmanNo}) operasyonel listeden çıkarılacak. Kayıt silinmez; geçmiş, belgeler ve fotoğraflar korunur.`,
      variant: 'danger',
      confirmText: 'Evet, Sil',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setBusy(true);
        deleteEkipman(localRow.id)
          .then(() => {
            addToast({ title: 'Silindi', message: `${localRow.ad} listeden çıkarıldı.`, type: 'success' });
            onChanged();
            onClose();
          })
          .catch((err) => addToast({ title: 'İşlem başarısız', message: friendlyEkipmanError(err), type: 'error' }))
          .finally(() => setBusy(false));
      },
    });
  };

  // QR KODUNU İNDİR — gerçek PNG indirme. QR GÜVENLİK MİMARİSİ DEĞİŞMEZ;
  // QR yine yalnızca opak erişim anahtarını taşır. Burada yalnızca önizlemeden
  // bağımsız yüksek çözünürlüklü bir PNG üretilip blob üzerinden indirilir
  // (bazı tarayıcılar data: URL indirmesini engellediği için blob kullanılır).
  const handleQrIndir = () => {
    const url = buildEkipmanQrUrl(localRow.qrReference);
    if (!url) {
      addToast({ title: 'QR indirilemedi', message: 'Ekipmanın QR erişim anahtarı bulunamadı.', type: 'error' });
      return;
    }
    QRCode.toDataURL(url, { width: 1024, margin: 2, errorCorrectionLevel: 'M' })
      .then((dataUrl) => {
        const comma = dataUrl.indexOf(',');
        const meta = dataUrl.slice(0, comma);
        const base64 = dataUrl.slice(comma + 1);
        const mime = /:(.*?);/.exec(meta)?.[1] ?? 'image/png';
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
        downloadBlob(new Blob([bytes], { type: mime }), `${localRow.ekipmanNo}_QR.png`);
        addToast({ title: 'QR indirildi', message: `${localRow.ekipmanNo}_QR.png indirildi.`, type: 'success' });
      })
      .catch(() => addToast({ title: 'QR indirilemedi', message: 'QR görseli oluşturulamadı. Lütfen tekrar deneyin.', type: 'error' }));
  };

  const handleQrYenile = () => {
    if (qrBusy) return;
    confirm({
      title: "QR Erişim Anahtarını Yenile",
      message: 'Mevcut QR kod anında geçersiz olur ve yazdırılmış/eski QR kodlarla erişim sağlanamaz. Yeni QR kod üretilir. Ekipman kaydı ve numarası değişmez.',
      variant: 'warning',
      confirmText: 'Evet, Yenile',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setQrBusy(true);
        yenileEkipmanQr(localRow.id)
          .then(() => {
            addToast({ title: 'QR yenilendi', message: 'Eski QR kod geçersiz kılındı; yeni QR kod üretildi.', type: 'success' });
            refresh();
            onChanged();
          })
          .catch((err) => addToast({ title: 'Yenileme başarısız', message: friendlyEkipmanError(err), type: 'error' }))
          .finally(() => setQrBusy(false));
      },
    });
  };

  const ekleMenu: MenuItem[] = [
    { key: 'foto', label: 'Fotoğraf Ekle', icon: 'ri-image-add-line', onClick: () => fotoInputRef.current?.click() },
    { key: 'belge', label: 'Belge Ekle', icon: 'ri-file-add-line', onClick: handleBelgeEkle },
    { key: 'kontrol', label: 'Periyodik Kontrol Ekle', icon: 'ri-clipboard-line', onClick: handleKontrolEkle },
    { key: 'bakim', label: 'Bakım Kaydı Ekle', icon: 'ri-tools-line', onClick: handleBakimEkle },
  ];

  const islemMenu: MenuItem[] = [
    { key: 'duzenle', label: 'Düzenle', icon: 'ri-edit-line', onClick: handleEdit },
    { key: 'qr', label: 'QR Kodunu İndir', icon: 'ri-qr-code-line', onClick: handleQrIndir },
  ];

  return (
    <div className="space-y-3">
      <input
        ref={fotoInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        multiple
        className="hidden"
        onChange={(e) => { handleFotoEkle(e.target.files); e.target.value = ''; }}
      />

      {/* Üst aksiyon + durum satırı */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex flex-wrap items-center gap-1.5">
          <Badge variant={kullanimDurumuBadgeVariant(localRow.kullanimDurumu)} leftIcon={<i className={kullanimDurumuIcon(localRow.kullanimDurumu)} />}>
            {localRow.kullanimDurumuLabel}
          </Badge>
          <Badge variant={kontrolDurumuBadgeVariant(kontrolSure.state)}>
            Kontrol: {kontrolSure.label}
          </Badge>
        </div>
        {canManage && (
          <div className="flex items-center gap-1.5 flex-wrap">
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-edit-line" />} onClick={handleEdit}>Düzenle</Button>
            <Button variant="danger" size="sm" leftIcon={<i className="ri-delete-bin-line" />} onClick={handleKaldir} disabled={busy}>Sil</Button>
            <ActionMenu items={ekleMenu} label="Ekle" icon="ri-add-line" variant="primary" />
            <ActionMenu items={islemMenu} />
          </div>
        )}
      </div>

      {agirKusur && (
        <div className="flex items-center gap-3 p-3 bg-danger-50 dark:bg-danger-500/10 border border-danger-200/60 rounded-lg">
          <div className="w-9 h-9 rounded-lg bg-danger-100 dark:bg-danger-500/20 flex items-center justify-center flex-shrink-0">
            <i className="ri-alert-line text-danger-600 text-lg" />
          </div>
          <div>
            <p className="text-sm font-semibold text-danger-700 dark:text-danger-500">Kullanım dışı — Ağır kusur</p>
            <p className="text-xs text-danger-600 dark:text-danger-400">En güncel kontrol kaydında ağır kusur tespit edilmiştir. İlgili mevzuat gereği kullanımı yasaktır.</p>
          </div>
        </div>
      )}

      {kontrolUyari && (
        <div className={`flex items-center gap-3 p-3 rounded-lg border ${
          kontrolEksik || kontrolSure.state === 'gecmis'
            ? 'bg-danger-50 dark:bg-danger-500/10 border-danger-200/60'
            : 'bg-warning-50 dark:bg-warning-500/10 border-warning-200/60'
        }`}>
          <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${
            kontrolEksik || kontrolSure.state === 'gecmis' ? 'bg-danger-100 dark:bg-danger-500/20' : 'bg-warning-100 dark:bg-warning-500/20'
          }`}>
            <i className={`${kontrolEksik || kontrolSure.state === 'gecmis' ? 'ri-alert-line text-danger-600' : 'ri-time-line text-warning-600'} text-lg`} />
          </div>
          <div className="flex-1 min-w-0">
            <p className={`text-sm font-semibold ${kontrolEksik || kontrolSure.state === 'gecmis' ? 'text-danger-700 dark:text-danger-500' : 'text-warning-700 dark:text-warning-500'}`}>
              {kontrolEksik ? 'Periyodik kontrol kaydı yok' : kontrolSure.state === 'gecmis' ? 'Periyodik kontrol süresi geçti' : 'Bugün periyodik kontrol zamanı'}
            </p>
            <p className={`text-xs ${kontrolEksik || kontrolSure.state === 'gecmis' ? 'text-danger-600 dark:text-danger-400' : 'text-warning-600 dark:text-warning-400'}`}>
              {kontrolEksik
                ? 'Bu ekipman türü mevzuat gereği periyodik kontrole tabidir; henüz kontrol kaydı bulunmuyor.'
                : `Kontrol durumu: ${localRow.kontrolDurumuLabel}. Yeni kontrol yapılıp kayıt güncellenmelidir.`}
            </p>
          </div>
          {canManage && (
            <Button variant="primary" size="sm" onClick={handleKontrolEkle}>
              {kontrolEksik ? 'Kontrol Ekle' : 'Kontrolü Güncelle'}
            </Button>
          )}
        </div>
      )}

      {/* İki kolonlu içerik */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* SOL KOLON */}
        <div className="space-y-3">
          <Card
            title="Ekipman Bilgileri"
            padding="md"
            headerAction={
              <button
                type="button"
                onClick={handleEdit}
                className="inline-flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-edit-line" />
                Düzenle
              </button>
            }
          >
            <div className="flex flex-col">
              <Row icon="ri-hashtag" label="Ekipman No" value={<span className="font-semibold">{localRow.ekipmanNo}</span>} />
              <Row icon="ri-tools-line" label="Ekipman Adı" value={localRow.ad} />
              <Row icon="ri-apps-2-line" label="Ekipman Grubu" value={localRow.grupAd} />
              <Row icon="ri-settings-3-line" label="Ekipman Türü" value={localRow.turAd} />
              <Row icon="ri-git-branch-line" label="Ekipman Alt Türü" value={altTurAd} />
              <Row icon="ri-building-2-line" label="Firma" value={localRow.firmaUnvan} />
              <Row icon="ri-price-tag-3-line" label="Marka" value={localRow.marka || '—'} />
              <Row icon="ri-cpu-line" label="Model" value={localRow.model || '—'} />
              <Row icon="ri-barcode-line" label="Seri No" value={localRow.seriNo || '—'} />
              <Row icon="ri-map-pin-line" label="Depo / Lokasyon" value={localRow.konum || '—'} />
              <Row
                icon="ri-checkbox-circle-line"
                label="Durum"
                value={
                  <Badge variant={kullanimDurumuBadgeVariant(localRow.kullanimDurumu)} leftIcon={<i className={kullanimDurumuIcon(localRow.kullanimDurumu)} />}>
                    {localRow.kullanimDurumuLabel}
                  </Badge>
                }
              />
            </div>
          </Card>

          <Card
            title="Periyodik Kontrol Bilgileri"
            padding="md"
            headerAction={canManage ? (
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={handleKontrolEkle}>
                Yeni Kontrol
              </Button>
            ) : undefined}
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-5">
              <Row icon="ri-calendar-check-line" label="Son Kontrol Tarihi" value={formatEkipmanDate(sonKontrol?.kontrolTarihi ?? null)} />
              <Row icon="ri-calendar-2-line" label="Sonraki Kontrol Tarihi" value={formatEkipmanDate(localRow.sonrakiKontrolTarihi)} />
              <Row icon="ri-timer-line" label="Kalan Süre" value={<Badge variant={kontrolDurumuBadgeVariant(kontrolSure.state)}>{kontrolSure.label}</Badge>} />
              <Row
                icon="ri-shield-check-line"
                label="Kontrol Durumu"
                value={sonKontrol?.sonuc
                  ? <Badge variant={sonucVariant(sonKontrol.sonuc)}>{sonKontrol.sonuc}</Badge>
                  : '—'}
              />
              <Row icon="ri-repeat-line" label="Kontrol Periyodu" value={kontrolPeriyot ?? (kontrolGerekli ? '—' : 'Zorunlu değil')} />
              {sonKontrolMeta && (sonKontrolMeta.yetkili || sonKontrolMeta.meslek) ? (
                <Row icon="ri-user-star-line" label="Kontrolü Yapan" value={[sonKontrolMeta.yetkili, sonKontrolMeta.meslek].filter(Boolean).join(' — ')} />
              ) : null}
            </div>
          </Card>

          <Card
            title={`Periyodik Kontrol Kayıtları (${benzersizKontroller.length})`}
            padding="md"
          >
            {benzersizKontroller.length === 0 ? (
              <EmptyState icon="ri-clipboard-line" title="Kayıt yok" description="Bu ekipman için henüz periyodik kontrol kaydı bulunmuyor." />
            ) : (
              <div className="space-y-2">
                {benzersizKontroller.map((k, idx) => {
                  const meta = mapKontrolMeta(k.metadata);
                  const agir = isAgirKusur(k.sonuc);
                  const ekliBelgeler = dokumanBelgeler.filter((b) => b.kontrolId === k.id);
                  return (
                    <div key={k.id} className="p-2.5 bg-background-100/70 dark:bg-background-200/40 border border-background-300/20 dark:border-background-400/20 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-lg bg-secondary-100 dark:bg-secondary-500/15 flex items-center justify-center flex-shrink-0">
                          <i className="ri-clipboard-line text-secondary-600 dark:text-secondary-400" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-foreground-800 truncate">
                            Periyodik kontrol · {formatEkipmanDate(k.kontrolTarihi)}
                          </p>
                          <p className="text-xs text-foreground-500 truncate">Sonraki kontrol: {formatEkipmanDate(k.sonrakiKontrolTarihi)}</p>
                          {meta.yetkili ? <p className="text-xs text-foreground-500 truncate">Yetkili: {[meta.yetkili, meta.meslek].filter(Boolean).join(' — ')}</p> : null}
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          {k.sonuc && <Badge variant={agir ? 'danger' : k.sonuc.toLocaleLowerCase('tr').includes('uygun') ? 'success' : 'warning'}>{k.sonuc}</Badge>}
                          <Badge variant="secondary" size="sm">{idx + 1}</Badge>
                        </div>
                      </div>
                      {ekliBelgeler.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1.5">
                          {ekliBelgeler.map((b) => (
                            <span key={b.id} className="inline-flex items-center gap-1 pl-2.5 pr-1 h-8 rounded-md bg-background-200/60 dark:bg-background-300/40 text-xs text-foreground-700">
                              <i className="ri-attachment-2 text-foreground-400" />
                              <span className="max-w-[180px] truncate">{b.dosyaAdi}</span>
                              <BelgeEylemleri belge={b} />
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          <Card
            title="Not"
            padding="md"
            headerAction={canManage ? (
              <button
                type="button"
                onClick={handleEdit}
                className="inline-flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-edit-line" />
                Düzenle
              </button>
            ) : undefined}
          >
            {localRow.aciklama ? (
              <p className="text-sm text-foreground-700 whitespace-pre-wrap">{localRow.aciklama}</p>
            ) : (
              <p className="text-sm text-foreground-400">Bu ekipman için not bulunmuyor. Düzenle ile ekleyebilirsiniz.</p>
            )}
            <p className="mt-2 text-[11px] text-foreground-400 text-right">{(localRow.aciklama ?? '').length}/500</p>
          </Card>
        </div>

        {/* SAĞ KOLON */}
        <div className="space-y-3">
          <Card
            title={`Ekipman Görselleri${fotoBelgeler.length > 0 ? ` (${fotoBelgeler.length})` : ''}`}
            padding="md"
            headerAction={canManage ? (
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-add-line" />} disabled={fotoUploading} onClick={() => fotoInputRef.current?.click()}>
                {fotoUploading ? 'Yükleniyor...' : 'Ekle'}
              </Button>
            ) : undefined}
          >
            {fotoBelgeler.length === 0 ? (
              <button
                type="button"
                onClick={() => fotoInputRef.current?.click()}
                disabled={!canManage || fotoUploading}
                className="w-full h-40 rounded-lg border-2 border-dashed border-background-300/50 flex flex-col items-center justify-center gap-2 text-foreground-400 hover:bg-background-100 transition-colors cursor-pointer disabled:cursor-default disabled:opacity-70"
              >
                <i className="ri-image-add-line text-2xl" />
                <span className="text-xs">Fotoğraf ekle (JPG, PNG, WEBP)</span>
              </button>
            ) : (
              <div className="space-y-2">
                {fotoKart && (
                  <div className="relative rounded-lg overflow-hidden border border-background-300/40 bg-background-100">
                    <ImageViewer
                      src={fotoUrls[fotoKart.id]}
                      alt={fotoKart.dosyaAdi}
                      fileName={fotoKart.dosyaAdi}
                      gallery={fotoGaleri}
                      index={fotoIndex(fotoKart.id)}
                      showHoverIcon
                      imgClassName="w-full h-40 object-cover object-top"
                    />
                    {canManage && (
                      <div className="absolute top-2 right-2 z-10 flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleBelgeDuzenle(fotoKart)}
                          title="Fotoğraf bilgilerini düzenle"
                          aria-label="Düzenle"
                          className="inline-flex items-center gap-1 px-2 h-8 rounded-md bg-black/60 text-inverse text-xs font-medium hover:bg-black/80 transition-colors cursor-pointer whitespace-nowrap"
                        >
                          <i className="ri-edit-line" />
                          Düzenle
                        </button>
                        <button
                          type="button"
                          onClick={() => handleBelgeSil(fotoKart, 'foto')}
                          title="Fotoğrafı sil"
                          aria-label="Fotoğrafı sil"
                          className="inline-flex items-center gap-1 px-2 h-8 rounded-md bg-black/60 text-inverse text-xs font-medium hover:bg-danger-600 transition-colors cursor-pointer whitespace-nowrap"
                        >
                          <i className="ri-delete-bin-line" />
                          Sil
                        </button>
                      </div>
                    )}
                  </div>
                )}
                <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                  {digerFoto.map((b) => (
                    <div key={b.id} className="relative w-16 h-16 rounded-lg overflow-hidden border border-background-300/40 bg-background-100 flex-shrink-0">
                      <ImageViewer
                        src={fotoUrls[b.id]}
                        alt={b.dosyaAdi}
                        fileName={b.dosyaAdi}
                        gallery={fotoGaleri}
                        index={fotoIndex(b.id)}
                        showHoverIcon
                        imgClassName="w-full h-16 object-cover object-top"
                      />
                      {canManage && (
                        <div className="absolute top-0.5 right-0.5 z-10 flex items-center gap-0.5">
                          <button
                            type="button"
                            onClick={() => handleBelgeDuzenle(b)}
                            title="Düzenle"
                            aria-label="Düzenle"
                            className="w-6 h-6 rounded-full bg-black/60 text-inverse flex items-center justify-center hover:bg-black/80 transition-colors cursor-pointer"
                          >
                            <i className="ri-edit-line text-xs" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleBelgeSil(b, 'foto')}
                            title="Fotoğrafı sil"
                            aria-label="Fotoğrafı sil"
                            className="w-6 h-6 rounded-full bg-black/60 text-inverse flex items-center justify-center hover:bg-danger-600 transition-colors cursor-pointer"
                          >
                            <i className="ri-delete-bin-line text-xs" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))}
                  {canManage && (
                    <button
                      type="button"
                      onClick={() => fotoInputRef.current?.click()}
                      disabled={fotoUploading}
                      title="Fotoğraf ekle"
                      aria-label="Fotoğraf ekle"
                      className="w-16 h-16 rounded-lg border-2 border-dashed border-background-300/60 flex items-center justify-center text-foreground-400 hover:bg-background-100 transition-colors cursor-pointer flex-shrink-0 disabled:opacity-60"
                    >
                      <i className="ri-add-line text-lg" />
                    </button>
                  )}
                </div>
              </div>
            )}
          </Card>

          <Card
            title={`Belgeler (${dokumanBelgeler.length})`}
            padding="md"
            headerAction={<Button variant="secondary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={handleBelgeEkle}>Belge Ekle</Button>}
          >
            {dokumanBelgeler.length === 0 ? (
              <p className="text-xs text-foreground-500 py-2">Bu ekipmana ait belge bulunmuyor.</p>
            ) : (
              <div className="space-y-2">
                {dokumanBelgeler.map((b) => {
                  const g = belgeGorunum(b.mimeType);
                  return (
                    <div key={b.id} className="flex items-center gap-3 p-2.5 bg-background-100/70 dark:bg-background-200/40 border border-background-300/20 dark:border-background-400/20 rounded-lg">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${g.tone}`}>
                        <i className={`${g.icon} text-lg`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground-800 truncate">{b.dosyaAdi}</p>
                        <div className="mt-0.5 flex flex-wrap items-center gap-2.5 text-[11px] text-foreground-500">
                          <span className="flex items-center gap-1"><i className="ri-file-info-line" />{formatFileSize(b.sizeBytes)}</span>
                          <span className="flex items-center gap-1"><i className="ri-calendar-line" />{formatEkipmanDateTime(b.createdAt)}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <BelgeEylemleri belge={b} />
                        {canManage && (
                          <IconButtonSil
                            icon="ri-edit-line"
                            label="Düzenle"
                            onClick={() => handleBelgeDuzenle(b)}
                          />
                        )}
                        {canManage && (
                          <IconButtonSil onClick={() => handleBelgeSil(b, 'belge')} />
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </Card>

          <Card
            title="QR / Barkod"
            padding="md"
            headerAction={canManage ? (
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} isLoading={qrBusy} onClick={handleQrYenile}>
                QR'ı Yenile
              </Button>
            ) : <i className="ri-qr-code-line text-secondary-500" />}
          >
            <div className="flex items-start gap-4">
              <div className="p-2 bg-white dark:bg-background-100 rounded-lg border border-background-300/30 flex-shrink-0">
                {qrLoading ? (
                  <div className="w-28 h-28 bg-background-200 dark:bg-background-300/40 rounded animate-pulse flex items-center justify-center">
                    <span className="text-[10px] text-foreground-500">Üretiliyor...</span>
                  </div>
                ) : qrDataUrl ? (
                  <img src={qrDataUrl} alt="Ekipman QR kodu" className="w-28 h-28" />
                ) : (
                  <div className="w-28 h-28 flex items-center justify-center text-[10px] text-foreground-500">QR yok</div>
                )}
              </div>
              <div className="flex-1 min-w-0 space-y-2">
                <Row icon="ri-barcode-line" label="Barkod" value={<span className="font-mono">{localRow.ekipmanNo}</span>} />
                <Row
                  icon="ri-key-2-line"
                  label="Erişim Anahtarı"
                  value={<span className="font-mono break-all text-xs">{localRow.qrReference}</span>}
                />
                <Row icon="ri-calendar-line" label="Oluşturma Tarihi" value={formatEkipmanDate(localRow.createdAt.slice(0, 10))} />
                <Button variant="secondary" size="sm" leftIcon={<i className="ri-download-line" />} onClick={handleQrIndir} disabled={!qrDataUrl}>QR Kodunu İndir</Button>
              </div>
            </div>
            <p className="mt-3 text-[11px] text-foreground-400">Bu QR yalnızca güvenli bir erişim anahtarı taşır; tek başına yetki sağlamaz. Okutan kişinin oturumu ve firmaya erişim yetkisi sunucuda doğrulanır.</p>
          </Card>

          <Card
            title={`Bakım Kayıtları (${localRow.bakimlar.length})`}
            padding="md"
            headerAction={canManage ? (
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={handleBakimEkle}>Ekle</Button>
            ) : undefined}
          >
            {localRow.bakimlar.length === 0 ? (
              <div className="flex items-center gap-2 py-1 text-sm text-foreground-500">
                <i className="ri-tools-line text-foreground-400" />
                Bu ekipmana ait bakım kaydı bulunmuyor.
              </div>
            ) : (
              <div className="space-y-1.5">
                {localRow.bakimlar.map((m) => (
                  <div key={m.id} className="flex items-start gap-2.5 p-2.5 bg-background-100/70 dark:bg-background-200/40 border border-background-300/20 dark:border-background-400/20 rounded-lg">
                    <div className="w-8 h-8 rounded-lg bg-secondary-100 dark:bg-secondary-500/15 flex items-center justify-center flex-shrink-0">
                      <i className="ri-tools-line text-secondary-600 dark:text-secondary-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-sm font-medium text-foreground-800 truncate">{m.bakimTuru || 'Bakım'}</p>
                        <span className="text-xs text-foreground-500 flex-shrink-0">{formatEkipmanDate(m.bakimTarihi)}</span>
                      </div>
                      {m.yapilanIslem && <p className="text-xs text-foreground-600 truncate mt-0.5">{m.yapilanIslem}</p>}
                      <p className="text-[11px] text-foreground-500 mt-0.5 flex flex-wrap gap-x-3">
                        {m.bakimYapan ? <span>Yapan: {m.bakimYapan}</span> : null}
                        {m.sonrakiBakimTarihi ? <span>Sonraki: {formatEkipmanDate(m.sonrakiBakimTarihi)}</span> : null}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

/** Belge satırındaki küçük ikon aksiyonu (varsayılan: sil). */
function IconButtonSil({
  onClick,
  icon = 'ri-delete-bin-line',
  label = 'Sil',
}: {
  onClick: () => void;
  icon?: string;
  label?: string;
}) {
  const danger = icon === 'ri-delete-bin-line';
  return (
    <button
      type="button"
      onClick={onClick}
      title={label}
      aria-label={label}
      className={`inline-flex items-center justify-center w-8 h-8 rounded-md text-foreground-500 transition-colors cursor-pointer flex-shrink-0 ${
        danger ? 'hover:text-danger-600 hover:bg-danger-100' : 'hover:text-primary-600 hover:bg-primary-100/70'
      }`}
    >
      <i className={icon} />
    </button>
  );
}