import { useState } from 'react';
import Button from '@/components/ui/Button';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import DatePicker from '@/components/ui/DatePicker';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import { useToastActions } from '@/hooks/useToast';
import { uploadBelge, friendlyEkipmanError } from '@/lib/ekipmanService';

const MAX_SIZE = 15 * 1024 * 1024;

// GLOBAL dosya motorunun kabul ettiği türler (PDF/DOC/XLS/PPT/görsel).
const BELGE_ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,image/jpeg,image/png,image/webp';

// Periyodik Kontrol Raporu'nun özel akışı korunur; kullanıcı bunun dışında da
// istediği belgeyi (kullanım kılavuzu, uygunluk, CE, bakım, teknik doküman,
// fotoğraf, diğer) yükleyebilir. Hiçbiri hukuki zorunluluk ifade etmez.
export const BELGE_TURLERI = [
  { value: 'Periyodik Kontrol Raporu', label: 'Periyodik Kontrol Raporu' },
  { value: 'Kullanım Kılavuzu', label: 'Kullanım Kılavuzu' },
  { value: 'Uygunluk Belgesi', label: 'Uygunluk Belgesi' },
  { value: 'CE Belgesi', label: 'CE Belgesi' },
  { value: 'Bakım Belgesi', label: 'Bakım Belgesi' },
  { value: 'Teknik Doküman', label: 'Teknik Doküman' },
  { value: 'Fotoğraf', label: 'Fotoğraf' },
  { value: 'Diğer', label: 'Diğer' },
];

interface BelgeEkleModalProps {
  ekipmanId: string;
  onClose: () => void;
  onSaved: () => void;
}

export default function BelgeEkleModal({ ekipmanId, onClose, onSaved }: BelgeEkleModalProps) {
  const { addToast } = useToastActions();

  const [belgeTuru, setBelgeTuru] = useState('');
  const [belgeTarihi, setBelgeTarihi] = useState('');
  const [gecerlilikBitis, setGecerlilikBitis] = useState('');
  const [aciklama, setAciklama] = useState('');
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    setError('');
    const raw = files[0]?.raw;
    if (!belgeTuru) {
      setError('Belge türü zorunludur.');
      return;
    }
    if (!raw) {
      setError('Bir dosya seçmelisiniz.');
      return;
    }
    if (raw.size > MAX_SIZE) {
      setError('Dosya boyutu 15 MB sınırını aşıyor.');
      return;
    }
    setSubmitting(true);
    try {
      await uploadBelge({
        ekipmanId,
        belgeTuru,
        belgeTarihi: belgeTarihi || null,
        gecerlilikBitis: gecerlilikBitis || null,
        aciklama: aciklama.trim() || null,
        file: raw,
      });
      addToast({ title: 'Belge yüklendi', message: 'Belge ekipmana eklendi.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      setError(friendlyEkipmanError(e));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <Select
        label="Belge Türü"
        required
        options={BELGE_TURLERI}
        value={belgeTuru}
        onChange={(e) => setBelgeTuru(e.target.value)}
        placeholder="Belge türü seçin"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <DatePicker label="Belge Tarihi" value={belgeTarihi} onChange={(e) => setBelgeTarihi(e.target.value)} />
        <DatePicker label="Geçerlilik Bitişi" value={gecerlilikBitis} onChange={(e) => setGecerlilikBitis(e.target.value)} />
      </div>

      <Textarea
        label="Açıklama"
        value={aciklama}
        onChange={(e) => setAciklama(e.target.value)}
        maxLength={500}
        placeholder="Belgeyle ilgili kısa açıklama (isteğe bağlı)"
      />

      {/* GLOBAL dosya yükleme motoru — ikinci bir upload motoru oluşturulmaz. */}
      <FileUpload
        label="Dosya"
        required
        accept={BELGE_ACCEPT}
        maxSize={MAX_SIZE}
        files={files}
        onChange={setFiles}
        helpText="PDF, DOC, DOCX, XLS, XLSX, PPT, PPTX, JPG, JPEG, PNG, WEBP (Maks. 15 MB)"
      />

      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={submitting}>Vazgeç</Button>
        <Button variant="primary" size="sm" leftIcon={<i className="ri-upload-2-line" />} onClick={handleSubmit} isLoading={submitting}>Yükle</Button>
      </div>
    </div>
  );
}