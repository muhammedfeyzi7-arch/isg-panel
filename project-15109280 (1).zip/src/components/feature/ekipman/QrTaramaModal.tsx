import { useEffect, useRef, useState } from 'react';
import Alert from '@/components/ui/Alert';
import { Html5Qrcode } from 'html5-qrcode';
import Button from '@/components/ui/Button';

const SCANNER_ID = 'isg-ekipman-qr-reader';

/**
 * QR metninden güvenli ekipman erişim anahtarını (token) çıkarır.
 * - Tam URL (…/ekipman-qr/<token>) → token
 * - Ham UUID (eski QR'lar) → doğrudan token
 * Erişim anahtarı TEK BAŞINA yetki değildir; backend oturum + firma yetkisi
 * kontrolünü yapar.
 */
export function extractEkipmanQrToken(raw: string): string {
  const text = (raw ?? '').trim();
  if (!text) return '';
  const urlMatch = text.match(/ekipman-qr\/([^/?#\s]+)/i);
  if (urlMatch) return decodeURIComponent(urlMatch[1]);
  const uuid = text.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
  if (uuid) return uuid[0];
  return '';
}

interface QrTaramaModalProps {
  onClose: () => void;
  onToken: (token: string) => void;
}

/**
 * ORTAK QR TARAYICI — ekipman modülüne gömülmez; merkezi bir bileşendir.
 * Kamera ile QR okur, tokenı çıkarır ve çağırana verir. Yetki kontrolü bu
 * bileşende YAPILMAZ; güvenli kapı (qr_resolve) backend'de çalışır.
 */
export default function QrTaramaModal({ onClose, onToken }: QrTaramaModalProps) {
  const [starting, setStarting] = useState(true);
  const [error, setError] = useState('');
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const doneRef = useRef(false);
  const onTokenRef = useRef(onToken);
  onTokenRef.current = onToken;

  useEffect(() => {
    let cancelled = false;
    let scanner: Html5Qrcode | null = null;

    const start = async () => {
      try {
        scanner = new Html5Qrcode(SCANNER_ID, { verbose: false });
        scannerRef.current = scanner;
        await scanner.start(
          { facingMode: 'environment' },
          { fps: 10, qrbox: { width: 240, height: 240 } },
          (decoded) => {
            if (doneRef.current) return;
            const token = extractEkipmanQrToken(decoded);
            if (!token) return;
            doneRef.current = true;
            const s = scannerRef.current;
            const finish = () => onTokenRef.current(token);
            if (s) {
              s.stop().then(() => s.clear()).catch(() => {}).finally(finish);
            } else {
              finish();
            }
          },
          () => { /* kare hatası — yoksay */ },
        );
        if (!cancelled) setStarting(false);
      } catch (e) {
        if (!cancelled) {
          setStarting(false);
          const msg = (e as Error)?.message ?? '';
          setError(
            /permission|denied|NotAllowed/i.test(msg)
              ? 'Kamera izni verilmedi. Tarayıcı ayarlarından kamera iznini açıp tekrar deneyin.'
              : 'Kamera başlatılamadı. Kameranız olan bir cihaz kullandığınızdan emin olun.',
          );
        }
      }
    };

    start();

    return () => {
      cancelled = true;
      const s = scannerRef.current;
      if (s) {
        s.stop().then(() => s.clear()).catch(() => {});
      }
    };
  }, []);

  return (
    <div className="flex flex-col gap-3">
      <div className="relative w-full overflow-hidden rounded-lg border border-background-300/40 bg-black">
        <div id={SCANNER_ID} className="w-full [&_video]:w-full [&_video]:h-auto" />
        {starting && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/70 text-white">
            <span className="inline-block w-7 h-7 border-2 border-white/70 border-t-transparent rounded-full animate-spin" />
            <span className="text-xs">Kamera başlatılıyor…</span>
          </div>
        )}
      </div>

      {error && (
        <Alert variant="danger">{error}</Alert>
      )}

      <div className="flex items-center gap-2 p-3 rounded-lg border border-background-300/25 dark:border-background-400/25 bg-background-100 dark:bg-background-200/40">
        <i className="ri-shield-check-line text-primary-600 dark:text-primary-400 flex-shrink-0" />
        <p className="text-xs text-foreground-500">
          QR kod yalnızca bir erişim anahtarı taşır. Okutan kişinin oturumu ve firmaya erişim yetkisi sunucuda doğrulanmadan ekipman bilgileri açılmaz.
        </p>
      </div>

      <div className="flex justify-end">
        <Button variant="ghost" size="sm" leftIcon={<i className="ri-close-line" />} onClick={onClose}>
          Kapat
        </Button>
      </div>
    </div>
  );
}