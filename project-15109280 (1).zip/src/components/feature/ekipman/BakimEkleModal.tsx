import { useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import DatePicker from '@/components/ui/DatePicker';
import { useToastActions } from '@/hooks/useToast';
import { ekleBakim, friendlyEkipmanError } from '@/lib/ekipmanService';

interface BakimEkleModalProps {
  ekipmanId: string;
  onClose: () => void;
  onSaved: () => void;
}

export default function BakimEkleModal({ ekipmanId, onClose, onSaved }: BakimEkleModalProps) {
  const { addToast } = useToastActions();

  const [bakimTarihi, setBakimTarihi] = useState('');
  const [bakimTuru, setBakimTuru] = useState('');
  const [yapilanIslem, setYapilanIslem] = useState('');
  const [aciklama, setAciklama] = useState('');
  const [bakimYapan, setBakimYapan] = useState('');
  const [sonrakiBakimTarihi, setSonrakiBakimTarihi] = useState('');
  const [notlar, setNotlar] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    setError('');
    if (!bakimTarihi) {
      setError('Bakım tarihi zorunludur.');
      return;
    }
    setSubmitting(true);
    try {
      await ekleBakim({
        ekipmanId,
        bakimTarihi,
        bakimTuru: bakimTuru.trim() || null,
        yapilanIslem: yapilanIslem.trim() || null,
        aciklama: aciklama.trim() || null,
        bakimYapan: bakimYapan.trim() || null,
        sonrakiBakimTarihi: sonrakiBakimTarihi || null,
        notlar: notlar.trim() || null,
      });
      addToast({ title: 'Bakım eklendi', message: 'Bakım kaydı oluşturuldu.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      setError(friendlyEkipmanError(e));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <DatePicker label="Bakım Tarihi" required value={bakimTarihi} onChange={(e) => setBakimTarihi(e.target.value)} />
        <Input label="Bakım Türü" value={bakimTuru} onChange={(e) => setBakimTuru(e.target.value)} placeholder="Örn. Periyodik, Arıza, ..." />
      </div>

      <Textarea label="Yapılan İşlem" value={yapilanIslem} onChange={(e) => setYapilanIslem(e.target.value)} maxLength={500} placeholder="Yapılan işlem açıklaması" />
      <Textarea label="Açıklama" value={aciklama} onChange={(e) => setAciklama(e.target.value)} maxLength={500} placeholder="Bakımla ilgili açıklama" />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Input label="Bakım Yapan / Servis" value={bakimYapan} onChange={(e) => setBakimYapan(e.target.value)} />
        <DatePicker label="Sonraki Bakım Tarihi" value={sonrakiBakimTarihi} onChange={(e) => setSonrakiBakimTarihi(e.target.value)} />
      </div>

      <Textarea label="Notlar" value={notlar} onChange={(e) => setNotlar(e.target.value)} maxLength={500} placeholder="Ek notlar (isteğe bağlı)" />

      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={submitting}>Vazgeç</Button>
        <Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={handleSubmit} isLoading={submitting}>Bakım Ekle</Button>
      </div>
    </div>
  );
}