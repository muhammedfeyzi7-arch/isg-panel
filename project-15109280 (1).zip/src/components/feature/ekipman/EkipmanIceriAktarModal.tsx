// ─────────────────────────────────────────────────────────────────────────────
// EKİPMANLARI İÇE AKTAR MODALI
//
// Tek adımlı içe aktarma: dosya seç → seçenekler → Aktar. Excel ÖNİZLEMESİ,
// sütun eşleştirme ekranı ve ara adım YOKTUR.
//
// ÖNEMLİ: İSGDenetim ekipman Excel ŞABLONU sistemin STANDART şablonudur ve
// korunur. Kullanıcı bu şablonu indirip doldurur. Kullanıcı FARKLI kolonlara
// sahip bir Excel yüklerse mevcut sistem alanları otomatik eşleştirilmeye
// çalışılır; eşleşmeyen kolonlar import dışında bırakılır. Kullanıcının Excel
// kolonları EKİPMAN LİSTELEME ŞEMASINI (sabit kolonlar) KESİNLİKLE DEĞİŞTİRMEZ.
//
// GEOMETRİ: kompakt genişlik, ekran ortasında, gereksiz dikey/yatay scroll YOK;
// header + footer sabit, yalnızca gövde gerekirse kayar. Gövde dolgusu modal
// motorunun CSS değişkenleriyle nötrlenir (density'den bağımsız).
// ─────────────────────────────────────────────────────────────────────────────
import { useCallback, useEffect, useMemo, useState } from 'react';
import Button from '@/components/ui/Button';
import Icon from '@/components/ui/Icon';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import Select from '@/components/ui/Select';
import { useToastActions } from '@/hooks/useToast';
import { parseImportFile } from '@/lib/import/excel';
import {
  analyzeEkipmanImport,
  resolveEkipmanSheet,
} from '@/lib/ekipmanImport';
import {
  type EkipmanFirmaOption,
  iceAktarEkipman,
  friendlyEkipmanError,
} from '@/lib/ekipmanService';
import { downloadEkipmanTemplate } from '@/lib/excel/ekipmanExcel';
import type { ExcelBrandMeta } from '@/lib/excel/isgExcelCore';
import type { ParsedFile } from '@/lib/import/types';

const ACCEPT = '.xlsx,.xls,.csv';
const MAX_SIZE = 20 * 1024 * 1024;

interface EkipmanIceriAktarModalProps {
  firmalar: EkipmanFirmaOption[];
  turler: { id: string; ad: string; kod: string; grupId: string }[];
  /** Firma seçilmemişse (tek erişimli kullanıcı) kullanılacak firma. */
  defaultFirmaId?: string;
  /** Şablon başlığında/kolonlarında kullanılacak firma adı. */
  firmaAdi: string;
  /** Şablon indirilirken kullanılacak marka meta üreteci (gerçek logo + firma bilgisi). */
  getBrandMeta: () => Promise<ExcelBrandMeta>;
  onClose: () => void;
  onCompleted: () => void;
}

function NumberBadge({ n }: { n: number }) {
  return (
    <span className="w-6 h-6 rounded-full bg-primary-500 text-inverse text-xs font-bold flex items-center justify-center flex-shrink-0">
      {n}
    </span>
  );
}

function OptionCheck({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <label className="flex items-center gap-2.5 cursor-pointer select-none">
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="peer sr-only"
      />
      <span className={`w-5 h-5 rounded-md border-2 flex items-center justify-center transition-colors ${checked ? 'bg-primary-500 border-primary-500' : 'border-background-400'}`}>
        <i className={`ri-check-line text-xs text-inverse ${checked ? '' : 'opacity-0'}`} />
      </span>
      <span className="text-sm text-foreground-700">{label}</span>
    </label>
  );
}

export default function EkipmanIceriAktarModal({
  firmalar,
  turler,
  defaultFirmaId,
  firmaAdi,
  getBrandMeta,
  onClose,
  onCompleted,
}: EkipmanIceriAktarModalProps) {
  const { addToast } = useToastActions();

  const [files, setFiles] = useState<UploadFile[]>([]);
  const [parsed, setParsed] = useState<ParsedFile | null>(null);
  const [parsing, setParsing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [templateBusy, setTemplateBusy] = useState(false);

  const [updateExisting, setUpdateExisting] = useState(true);
  const [skipInvalid, setSkipInvalid] = useState(true);
  const [firstRowHeader, setFirstRowHeader] = useState(false);
  void firstRowHeader; // Başlık satırı parse sırasında otomatik tespit edilir.

  // Tür kolonu olmayan Excel'lerde kullanılacak varsayılan tür (kullanıcının Excel'i yok sayılmaz).
  const [fallbackTurId, setFallbackTurId] = useState('');

  const handleFilesChange = useCallback(
    async (next: UploadFile[]) => {
      setFiles(next);
      const raw = next[0]?.raw;
      if (!raw) {
        setParsed(null);
        return;
      }
      setParsing(true);
      try {
        const p = await parseImportFile(raw);
        setParsed(p);
      } catch {
        setParsed(null);
        addToast({ title: 'Dosya okunamadı', message: 'Excel/CSV dosyası ayrıştırılamadı.', type: 'error' });
      } finally {
        setParsing(false);
      }
    },
    [addToast],
  );

  // İSGDenetim şablonu gibi üst başlık bloğu olan dosyalarda gerçek tablo başlık
  // satırını bulup veriyi oradan başlatır. Düz Excel'de değişiklik olmaz.
  const resolved = useMemo(() => {
    if (!parsed || parsed.sheets.length === 0) return null;
    return resolveEkipmanSheet(parsed.sheets[0]);
  }, [parsed]);

  // Kolonlar otomatik eşleştirilir (kullanıcıya eşleştirme ekranı GÖSTERİLMEZ);
  // eşleşmeyen kolonlar import dışında bırakılır ve liste şeması DEĞİŞMEZ.
  const analysis = useMemo(() => {
    if (!resolved) return null;
    return analyzeEkipmanImport(resolved.sheet, {
      firmalar,
      turler,
      defaultFirmaId,
      fallbackTurId: fallbackTurId || undefined,
      headerRowNumber: resolved.headerRowNumber,
    });
  }, [resolved, firmalar, turler, defaultFirmaId, fallbackTurId]);

  const importableCount = analysis?.importable.length ?? 0;
  const errorCount = analysis?.rowErrors.length ?? 0;

  // Tür değerleri eşleşmiyor ve hiç satır aktarılamıyorsa kullanıcıya varsayılan tür seçtir.
  const hasTurErrors = !!analysis && analysis.rowErrors.some((e) => e.message.includes('tür'));
  const needsTurFallback = turler.length > 0 && (!!fallbackTurId || (importableCount === 0 && hasTurErrors));

  // Aktar butonunun neden pasif olduğunu insan dilinde açıklar.
  const disabledReason = useMemo(() => {
    if (!parsed || files.length === 0) return 'Aktarmak için bir Excel dosyası seçin.';
    if (parsing) return 'Dosya inceleniyor...';
    if (needsTurFallback && !fallbackTurId) {
      return 'Excel\'de ekipman türü bulunamadı. Lütfen yukarıdan varsayılan bir tür seçin.';
    }
    if (importableCount === 0) {
      return analysis?.rowErrors[0]?.message ?? 'Dosyada geçerli ekipman satırı bulunamadı.';
    }
    if (!skipInvalid && errorCount > 0) {
      return `${errorCount} satırda hata var. Aktarmak için "Hata durumunda geçerli satırları yine içe aktar" seçeneğini işaretleyin.`;
    }
    return '';
  }, [parsed, files.length, parsing, needsTurFallback, fallbackTurId, importableCount, errorCount, skipInvalid, analysis]);

  const canImport = !!parsed && !parsing && importableCount > 0 && (skipInvalid || errorCount === 0);

  const handleTemplate = useCallback(async () => {
    if (templateBusy) return;
    setTemplateBusy(true);
    try {
      const meta = await getBrandMeta();
      await downloadEkipmanTemplate(meta);
      if (!firmaAdi) {
        addToast({
          title: 'Şablon indirildi',
          message: 'Firma bilgileri boş kaldı. Firma filtresini seçerek tekrar indirirseniz logo ve firma bilgileri otomatik dolar.',
          type: 'warning',
        });
      }
    } catch {
      addToast({ title: 'Şablon indirilemedi', message: 'Excel şablonu oluşturulamadı.', type: 'error' });
    } finally {
      setTemplateBusy(false);
    }
  }, [templateBusy, getBrandMeta, firmaAdi, addToast]);

  const handleImport = useCallback(async () => {
    if (busy) return;
    if (!parsed || !analysis) {
      addToast({ title: 'Dosya gerekli', message: 'Lütfen önce bir Excel dosyası seçin.', type: 'warning' });
      return;
    }
    if (analysis.importable.length === 0) {
      addToast({
        title: 'İçe aktarılacak kayıt yok',
        message: analysis.rowErrors[0]?.message ?? 'Dosyada geçerli satır bulunamadı.',
        type: 'error',
      });
      return;
    }
    if (!skipInvalid && analysis.rowErrors.length > 0) {
      addToast({
        title: 'Hatalı satırlar var',
        message: `${analysis.rowErrors.length} satırda hata var. Aktarmak için "Hata durumunda geçerli satırları yine içe aktar" seçeneğini işaretleyin.`,
        type: 'warning',
      });
      return;
    }

    setBusy(true);
    try {
      // Eşleşmeyen kolonlar firma özel alanı olarak OLUŞTURULMAZ; liste şeması sabittir.
      const res = await iceAktarEkipman({
        updateExisting,
        rows: analysis.importable,
        customFields: [],
      });
      onCompleted();
      if (res.errors > 0) {
        const firstErr = res.rows.find((r) => r.action === 'error')?.message;
        addToast({
          title: 'İçe aktarma tamamlandı (kısmi)',
          message: `${res.created} oluşturuldu, ${res.updated} güncellendi, ${res.errors} hata${firstErr ? ` · ${firstErr}` : ''}.`,
          type: 'warning',
        });
      } else {
        addToast({
          title: 'İçe aktarma tamamlandı',
          message: `${res.created} oluşturuldu, ${res.updated} güncellendi.`,
          type: 'success',
        });
        onClose();
      }
    } catch (e) {
      addToast({ title: 'İçe aktarma başarısız', message: friendlyEkipmanError(e), type: 'error' });
    } finally {
      setBusy(false);
    }
  }, [busy, parsed, analysis, skipInvalid, updateExisting, addToast, onCompleted, onClose]);

  return (
    <div
      className="flex flex-col"
      style={{
        // Modal gövde dolgusunu (density'den bağımsız) nötrle → içerik + footer
        // tam genişlik, footer modalın en altına sabitlenir.
        margin: 'calc(var(--d-modal-body-py) * -1) calc(var(--d-modal-body-px) * -1)',
        height: 'calc(100% + var(--d-modal-body-py) * 2)',
      }}
    >
      <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden isg-scroll-pane px-4 py-3 space-y-3">
        {/* ── Bölüm 1: Excel Dosyasını Seç ── */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <NumberBadge n={1} />
            <h4 className="text-sm font-semibold text-foreground-900">Excel Dosyasını Seç</h4>
          </div>
          <Button
            variant="secondary"
            size="sm"
            leftIcon={<i className="ri-download-2-line" />}
            onClick={handleTemplate}
            isLoading={templateBusy}
          >
            Excel Şablonunu İndir
          </Button>
        </div>

        <FileUpload
          accept={ACCEPT}
          multiple={false}
          maxFiles={1}
          maxSize={MAX_SIZE}
          files={files}
          onChange={handleFilesChange}
          dropIcon={<Icon name="excel" size="xl" />}
          heading="Excel dosyanızı buraya sürükleyip bırakın"
          browseLabel="Dosya Seç"
          dropClassName="min-h-[104px] py-3.5"
        />

        <p className="text-xs text-foreground-500">Desteklenen format: XLSX, XLS, CSV</p>

        {parsing && (
          <p className="text-xs text-foreground-500 flex items-center gap-1.5">
            <i className="ri-loader-4-line animate-spin" /> Dosya inceleniyor...
          </p>
        )}

        {/* Excel'de tür kolonu yoksa: varsayılan tür seçimi (kullanıcının Excel'i yok sayılmaz). */}
        {parsed && !parsing && needsTurFallback && (
          <div className="flex items-center gap-2 rounded-md border border-background-300/60 bg-background-100 px-2.5 py-2">
            <span className="text-xs font-medium text-foreground-600 shrink-0 whitespace-nowrap">Varsayılan Ekipman Türü</span>
            <Select
              size="sm"
              containerClassName="flex-1 min-w-0"
              placeholder="Tür seçin..."
              value={fallbackTurId}
              onChange={(e) => setFallbackTurId(e.target.value)}
              options={turler.map((t) => ({ value: t.id, label: t.ad }))}
            />
          </div>
        )}

        {/* Uzman firma seçmeden aktarırsa yol göster */}
        {firmalar.length > 0 && !defaultFirmaId && (
          <p className="text-xs text-foreground-500 flex items-start gap-1.5">
            <i className="ri-lightbulb-line text-accent-500 mt-px" />
            <span>Tek firmaya aktarmak için üstteki Firma filtresini seçin; birden fazla firmaya aktarmak için Excel&apos;deki FİRMA sütununu doldurun.</span>
          </p>
        )}

        {/* ── Canlı analiz özeti (kullanıcı ne olduğunu görsün) ── */}
        {parsed && !parsing && analysis && (
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 rounded-md bg-background-100 px-3 py-2 text-xs">
            <span className="inline-flex items-center gap-1 text-success-600">
              <i className="ri-checkbox-circle-line" />
              {importableCount} kayıt hazır
            </span>
            {errorCount > 0 && (
              <span className="inline-flex items-center gap-1 text-warning-600">
                <i className="ri-error-warning-line" />
                {errorCount} satır atlanacak
              </span>
            )}
          </div>
        )}

        {parsed && !parsing && errorCount > 0 && analysis?.rowErrors[0] && (
          <p className="text-xs text-warning-600 flex items-start gap-1.5">
            <i className="ri-error-warning-line mt-px" />
            <span>Satır {analysis.rowErrors[0].row}: {analysis.rowErrors[0].message}</span>
          </p>
        )}

        {/* ── Bölüm 2: İçe Aktarma Seçenekleri ── */}
        <div className="flex items-center gap-2.5 pt-0.5">
          <NumberBadge n={2} />
          <h4 className="text-sm font-semibold text-foreground-900">İçe Aktarma Seçenekleri</h4>
        </div>

        <div className="space-y-2.5 pl-8">
          <OptionCheck checked={updateExisting} onChange={setUpdateExisting} label="Var olan ekipmanları güncelle" />
          <OptionCheck checked={skipInvalid} onChange={setSkipInvalid} label="Hata durumunda geçerli satırları yine içe aktar" />
          <OptionCheck checked={firstRowHeader} onChange={setFirstRowHeader} label="İlk satırı başlık olarak kullan" />
        </div>
      </div>

      {/* ── Footer (sabit, tam genişlik) ── */}
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-t isg-divider flex-shrink-0">
        <div className="min-w-0">
          <Button variant="ghost" onClick={onClose} disabled={busy}>
            İptal
          </Button>
        </div>
        <div className="flex items-center gap-3 min-w-0">
          {!canImport && disabledReason && !busy && (
            <span className="hidden sm:block text-xs text-foreground-500 truncate max-w-[280px]" title={disabledReason}>
              {disabledReason}
            </span>
          )}
          <Button
            variant="primary"
            leftIcon={busy ? undefined : <i className="ri-upload-cloud-2-line" />}
            onClick={handleImport}
            isLoading={busy}
            disabled={!canImport || busy}
          >
            {busy ? 'Aktarılıyor...' : 'Aktar'}
          </Button>
        </div>
      </div>
    </div>
  );
}