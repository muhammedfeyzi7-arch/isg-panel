import { useState, useMemo } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import DatePicker from '@/components/ui/DatePicker';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import { useToastActions } from '@/hooks/useToast';
import {
  ekleKontrol,
  friendlyEkipmanError,
  type EkipmanMevzuatKurali,
  type KontrolBelgeInput,
} from '@/lib/ekipmanService';
import { periyotMetni, addPeriodToDate } from './ekipmanUi';

// Mevzuat kuralı sonuç/kusur/yöntem seçeneği tanımlamıyorsa (veya "Diğer" türlerde)
// kullanılan varsayılan sonuç seçenekleri. Sistem kendi kusur sınıflandırmasını üretmez;
// kullanıcının girdiği gerçek rapor sonucunu aynen saklar.
const VARSAYILAN_SONUC = [
  { value: 'Uygun', label: 'Uygun' },
  { value: 'Hafif Kusur', label: 'Hafif Kusur' },
  { value: 'Ağır Kusur', label: 'Ağır Kusur' },
];

const BELGE_ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png,.webp';
const BELGE_MAX_SIZE = 15 * 1024 * 1024;
const BELGE_TIP_IPUCU = 'PDF, DOC, DOCX, XLS, XLSX, JPG, JPEG, PNG, WEBP · Maksimum 15 MB';

// Kontrol kaydına bağlanacak belge türleri (hepsi OPSİYONEL).
const BELGE_TURLERI = {
  kontrol: 'Periyodik Kontrol Belgesi',
  ekipnet: 'EKİPNET Kayıt Belgesi',
  isgKatip: 'İSG-KATİP Sözleşme',
} as const;

interface KontrolEkleModalProps {
  ekipmanId: string;
  onClose: () => void;
  onSaved: () => void;
  /** Seçili türün merkezi mevzuat kuralı — periyot/öneri/seçenekler buradan türetilir. */
  kural?: EkipmanMevzuatKurali | null;
}

/** Yüklenen kontrol belgelerini (hata durumundakiler hariç) servis girdisine çevirir. */
function toBelgeInputs(files: UploadFile[], belgeTuru: string): KontrolBelgeInput[] {
  return files
    .filter((f) => f.raw && f.status !== 'error')
    .map((f) => ({ belgeTuru, file: f.raw as File }));
}

export default function KontrolEkleModal({ ekipmanId, onClose, onSaved, kural }: KontrolEkleModalProps) {
  const { addToast } = useToastActions();

  const [kontrolTarihi, setKontrolTarihi] = useState('');
  const [sonrakiKontrolTarihi, setSonrakiKontrolTarihi] = useState('');
  const [sonuc, setSonuc] = useState('');
  const [yontem, setYontem] = useState('');
  const [kusur, setKusur] = useState('');
  const [yetkili, setYetkili] = useState('');
  const [meslek, setMeslek] = useState('');
  const [ekipnetNo, setEkipnetNo] = useState('');
  const [isgKatip, setIsgKatip] = useState('');
  const [aciklama, setAciklama] = useState('');

  // OPSİYONEL belgeler — hiçbiri zorunlu değildir. Belge olmadan da kaydedilebilir.
  const [kontrolBelge, setKontrolBelge] = useState<UploadFile[]>([]);
  const [ekipnetBelge, setEkipnetBelge] = useState<UploadFile[]>([]);
  const [isgKatipBelge, setIsgKatipBelge] = useState<UploadFile[]>([]);

  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const kriterler = kural?.kontrolKriterleri ?? null;
  const periyot = kriterler?.period ?? null;

  // Mevzuat seçenekleri; kural tanımlamamışsa varsayılanlara düş (uydurma yok).
  const sonucOptions = useMemo(
    () => (kriterler?.resultOptions?.length ? kriterler.resultOptions.map((o) => ({ value: o.code, label: o.label })) : VARSAYILAN_SONUC),
    [kriterler],
  );
  const yontemOptions = useMemo(
    () => (kriterler?.method ?? []).map((m) => ({ value: m.code, label: m.name })),
    [kriterler],
  );
  const kusurOptions = useMemo(
    () => (kriterler?.defectOptions ?? []).map((o) => ({ value: o.code, label: o.label })),
    [kriterler],
  );

  const yetkiliMeslekler = useMemo(
    () => Array.from(new Set((kural?.yetkiliKisiKurallari ?? []).flatMap((r) => r.allowedProfessions))).filter(Boolean),
    [kural],
  );

  const handleKontrolTarihiChange = (value: string) => {
    setKontrolTarihi(value);
    // Kontrol tarihi girilince, mevzuat periyodu biliniyorsa "sonraki kontrol" tarihini
    // otomatik öner (kullanıcı elle değiştirebilir). Periyot yoksa uydurma tarih ÜRETİLMEZ.
    if (value && !sonrakiKontrolTarihi && periyot) {
      const oneri = addPeriodToDate(value, periyot);
      if (oneri) setSonrakiKontrolTarihi(oneri);
    }
  };

  const handleSubmit = async () => {
    // ÇİFT GÖNDERİM KORUMASI — butona hızlı iki kez basılsa da tek kayıt oluşur.
    if (submitting) return;
    setError('');
    if (!kontrolTarihi) {
      setError('Kontrol tarihi zorunludur.');
      return;
    }
    if (!sonrakiKontrolTarihi) {
      setError('Sonraki kontrol tarihi zorunludur.');
      return;
    }
    setSubmitting(true);
    try {
      await ekleKontrol({
        ekipmanId,
        kontrolTarihi,
        sonrakiKontrolTarihi,
        sonuc: sonuc || null,
        yontem: yontem.trim() || null,
        kusur: kusur.trim() || null,
        yetkili: yetkili.trim() || null,
        meslek: meslek.trim() || null,
        ekipnetNo: ekipnetNo.trim() || null,
        isgKatip: isgKatip.trim() || null,
        aciklama: aciklama.trim() || null,
        belgeler: [
          ...toBelgeInputs(kontrolBelge, BELGE_TURLERI.kontrol),
          ...toBelgeInputs(ekipnetBelge, BELGE_TURLERI.ekipnet),
          ...toBelgeInputs(isgKatipBelge, BELGE_TURLERI.isgKatip),
        ],
      });
      addToast({ title: 'Kontrol eklendi', message: 'Periyodik kontrol kaydı oluşturuldu. Önceki kayıt geçmişte korunur.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      setError(friendlyEkipmanError(e));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    // bodyLayout: 'fill' ile kullanılır: gövde tek parça, yalnızca alan bölgesi
    // kaydırılır; footer SABİT kalır. Modal geometrisi sabittir; gereksiz büyüme yok.
    <div className="flex flex-col h-full">
      <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane">
        <div className="flex flex-col gap-3 pb-1">
          {periyot && (
            <div className="flex items-center gap-2 p-2.5 rounded-lg border border-primary-200/50 bg-primary-50/50 text-sm text-foreground-700">
              <i className="ri-time-line flex-shrink-0 text-primary-600" />
              <span>
                Mevzuat kontrol periyodu: <span className="font-semibold">{periyotMetni(periyot)}</span>
                {periyot.source?.reference ? <span className="text-foreground-400"> · {periyot.source.reference}</span> : null}
              </span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <DatePicker label="Kontrol Tarihi" required value={kontrolTarihi} onChange={(e) => handleKontrolTarihiChange(e.target.value)} />
            <DatePicker label="Sonraki Kontrol Tarihi" required value={sonrakiKontrolTarihi} onChange={(e) => setSonrakiKontrolTarihi(e.target.value)} />
          </div>

          <Select
            label="Sonuç"
            options={sonucOptions}
            value={sonuc}
            onChange={(e) => setSonuc(e.target.value)}
            placeholder="Sonuç seçin (isteğe bağlı)"
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {yontemOptions.length > 0 ? (
              <Select
                label="Kontrol Yöntemi"
                options={yontemOptions}
                value={yontem}
                onChange={(e) => setYontem(e.target.value)}
                placeholder="Yöntem seçin"
              />
            ) : (
              <Input label="Kontrol Yöntemi" value={yontem} onChange={(e) => setYontem(e.target.value)} placeholder="Örn. Gözle muayene" />
            )}

            {kusurOptions.length > 0 ? (
              <Select
                label="Kusur / Değerlendirme"
                options={kusurOptions}
                value={kusur}
                onChange={(e) => setKusur(e.target.value)}
                placeholder="Kusur seçin (varsa)"
              />
            ) : (
              <Input label="Kusur / Değerlendirme" value={kusur} onChange={(e) => setKusur(e.target.value)} placeholder="Tespit edilen kusur (varsa)" />
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input label="Yetkili Kişi" value={yetkili} onChange={(e) => setYetkili(e.target.value)} />
            {yetkiliMeslekler.length > 0 ? (
              <Select
                label="Meslek"
                options={yetkiliMeslekler.map((m) => ({ value: m, label: m }))}
                value={meslek}
                onChange={(e) => setMeslek(e.target.value)}
                placeholder="Meslek seçin"
              />
            ) : (
              <Input label="Meslek" value={meslek} onChange={(e) => setMeslek(e.target.value)} />
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input label="EKİPNET Kayıt No" value={ekipnetNo} onChange={(e) => setEkipnetNo(e.target.value)} placeholder="EKİPNET kayıt numarası" />
            <Input label="İSG-KATİP Sözleşme" value={isgKatip} onChange={(e) => setIsgKatip(e.target.value)} placeholder="İSG-KATİP sözleşme/kontrat" />
          </div>

          <Textarea
            label="Açıklama"
            value={aciklama}
            onChange={(e) => setAciklama(e.target.value)}
            maxLength={500}
            placeholder="Kontrolle ilgili açıklama (isteğe bağlı)"
          />

          {/* OPSİYONEL KONTROL BELGELERİ — sistem Word/DOCX ÜRETMEZ; belgeyi kullanıcı yükler. */}
          <div className="mt-1 rounded-lg border border-background-300/30 dark:border-background-400/25 bg-background-100/60 dark:bg-background-200/30 p-3">
            <div className="flex items-start gap-2 mb-3">
              <i className="ri-attachment-2 text-foreground-500 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-foreground-800">Kontrol Belgeleri</p>
                <p className="text-xs text-foreground-500">
                  Belgeler isteğe bağlıdır. Yüklediğiniz belgeler bu kontrol kaydı ve ekipmanın Belgeler bölümü ile
                  ilişkilendirilir; sonradan önizleme/indirme mevcut belge görüntüleyici üzerinden yapılır.
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <FileUpload
                label="Periyodik Kontrol Belgesi"
                accept={BELGE_ACCEPT}
                multiple={false}
                maxFiles={1}
                maxSize={BELGE_MAX_SIZE}
                files={kontrolBelge}
                onChange={setKontrolBelge}
                helpText={`Yetkili kişi/kuruluş tarafından düzenlenen periyodik kontrol belgesini yükleyin. ${BELGE_TIP_IPUCU}`}
              />
              <FileUpload
                label="EKİPNET Belgesi"
                accept={BELGE_ACCEPT}
                multiple={false}
                maxFiles={1}
                maxSize={BELGE_MAX_SIZE}
                files={ekipnetBelge}
                onChange={setEkipnetBelge}
                helpText={`EKİPNET kayıt belgesini yükleyin. ${BELGE_TIP_IPUCU}`}
              />
              <FileUpload
                label="İSG-KATİP Sözleşme Belgesi"
                accept={BELGE_ACCEPT}
                multiple={false}
                maxFiles={1}
                maxSize={BELGE_MAX_SIZE}
                files={isgKatipBelge}
                onChange={setIsgKatipBelge}
                helpText={`İSG-KATİP sözleşme belgesini yükleyin. ${BELGE_TIP_IPUCU}`}
              />
            </div>
          </div>

          {error && (
            <p className="text-sm text-danger-600 flex items-center gap-1.5">
              <i className="ri-error-warning-line" />
              {error}
            </p>
          )}
        </div>
      </div>

      {/* SABİT FOOTER — içerik kaydırılırken yerinde kalır. */}
      <div className="flex-shrink-0 border-t isg-divider mt-3 pt-3 flex items-center justify-end gap-2">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={submitting}>Vazgeç</Button>
        <Button
          variant="primary"
          size="sm"
          leftIcon={<i className="ri-add-line" />}
          onClick={handleSubmit}
          isLoading={submitting}
        >
          Kontrol Ekle
        </Button>
      </div>
    </div>
  );
}