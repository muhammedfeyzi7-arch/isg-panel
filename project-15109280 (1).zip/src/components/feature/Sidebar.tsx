import { useNavigate, useLocation } from 'react-router-dom';
import { useState, useRef, lazy, Suspense } from 'react';
import { useAdminProfile } from '@/context/AdminProfileContext';
import { useAuth } from '@/context/AuthContext';
import { useMesajlasma } from '@/context/MesajlasmaContext';
import { useTheme } from '@/context/ThemeContext';
import { useModalActions } from '@/hooks/useModal';
import { useClickOutside } from '@/hooks/useDropdown';
import Avatar from '@/components/ui/Avatar';
import BrandLogo from './BrandLogo';
import ModalFallback from '@/components/ui/ModalFallback';

// Profil modalı yalnızca menüden açılınca yüklenir (tembel).
const ProfileModal = lazy(() => import('./ProfileModal'));
import KatipSidebarStatus from './isgKatip/KatipSidebarStatus';
import { Z_LAYERS } from '@/utils/layers';
import { getPanelFromPath, PANEL_NAV_CONFIG, PANEL_ROLE_LABEL } from './panelNavigation';
import { prefetchRoute } from '@/lib/routePrefetch';

interface SidebarProps {
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export default function Sidebar({ collapsed, onToggleCollapse }: SidebarProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { profile, fullName } = useAdminProfile();
  const { signOut } = useAuth();
  const { unreadCount } = useMesajlasma();
  const { theme, setTheme } = useTheme();
  const { openModal, closeModal } = useModalActions();
  const panel = getPanelFromPath(location.pathname);
  const navItems = PANEL_NAV_CONFIG[panel];
  const ayarlarPath = PANEL_NAV_CONFIG[panel].find((i) => i.label === 'Ayarlar')?.path ?? '/ayarlar';

  const [profileOpen, setProfileOpen] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const profileModalIdRef = useRef('');

  useClickOutside(profileRef, () => setProfileOpen(false), profileOpen);

  const THEME_ORDER = ['auto', 'light', 'dark'] as const;
  const THEME_LABEL: Record<string, string> = {
    auto: 'A',
    light: 'Açık',
    dark: 'Koyu',
  };
  const THEME_ICON: Record<string, string> = {
    auto: 'ri-contrast-line',
    light: 'ri-sun-line',
    dark: 'ri-moon-line',
  };

  const cycleTheme = () => {
    const idx = THEME_ORDER.indexOf(theme);
    setTheme(THEME_ORDER[(idx + 1) % THEME_ORDER.length]);
  };

  const handleOpenProfile = (initialTab: 'profil' | 'sifre' = 'profil') => {
    setProfileOpen(false);
    const id = openModal({
      title: 'Profil Ayarları',
      description: 'Kişisel bilgilerinizi ve şifrenizi yönetin.',
      width: 520,
      minWidth: 400,
      minHeight: 400,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <Suspense fallback={<ModalFallback />}>
          <ProfileModal onClose={() => closeModal(id)} modalIdRef={profileModalIdRef} initialTab={initialTab} />
        </Suspense>
      ),
      footerActions: null,
    });
    profileModalIdRef.current = id;
  };

  const handleNav = (path: string) => {
    navigate(path);
  };

  const handleAyarlar = () => {
    setProfileOpen(false);
    navigate(ayarlarPath);
  };

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  return (
    <aside
      className={`isg-sidebar flex flex-col flex-shrink-0 h-full transition-[width] duration-200 ${collapsed ? 'lg:w-16' : 'lg:w-60'}`}
      style={{ width: collapsed ? '4rem' : '15rem' }}
    >
      {/* Logo area */}
      <div className="flex items-center justify-between h-16 px-3 border-b isg-sidebar-sep flex-shrink-0">
        <div className={`flex items-center overflow-hidden ${collapsed ? 'justify-center w-full' : ''}`}>
          {collapsed ? (
            <BrandLogo variant="mark" className="h-10 w-10" />
          ) : (
            <BrandLogo variant="full" className="h-14" />
          )}
        </div>
        {!collapsed && (
          <button
            onClick={onToggleCollapse}
            aria-label="Menüyü daralt"
            className="isg-sidebar-navbtn w-7 h-7 flex items-center justify-center rounded lg:flex hidden"
          >
            <i className="ri-arrow-left-s-line" />
          </button>
        )}
      </div>

      {/* Nav + KATİP Durumu (OSGB) + Collapse — üst grup (scroll) */}
      <div className="flex-1 min-h-0 overflow-y-auto">
      <nav className="py-3 px-2">
        <div>
          {navItems.map((item) => {
            const active = isActive(item.path);
            const badge = item.label === 'Mesajlaşma' ? (unreadCount > 0 ? unreadCount : undefined) : item.badge;
            return (
              <button
                key={item.path}
                onClick={() => handleNav(item.path)}
                onMouseEnter={() => prefetchRoute(item.path)}
                onFocus={() => prefetchRoute(item.path)}
                className={`w-full isg-sidebar-link ${active ? 'active' : ''} ${collapsed ? 'justify-center px-3' : ''}`}
                title={collapsed ? item.label : undefined}
              >
                <i className={`${item.icon} text-lg ${active ? 'text-primary-600 dark:text-primary-300' : ''} ${collapsed ? 'mx-auto' : ''}`} />
                {!collapsed && (
                  <span className="flex-1 text-left truncate">{item.label}</span>
                )}
                {!collapsed && badge !== undefined && (
                  <span className={`flex-shrink-0 min-w-5 h-5 flex items-center justify-center rounded-full text-[10px] font-bold text-inverse px-1 ${item.badgeColor || 'bg-primary-500'}`}>
                    {badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>

      {/* İSG-KATİP Bağlantı Durumu — yalnızca OSGB panelinde (gerçek durum) */}
      {panel === 'osgb' && <KatipSidebarStatus collapsed={collapsed} />}

      {/* Collapse toggle for collapsed state */}
      {collapsed && (
        <button
          onClick={onToggleCollapse}
          aria-label="Menüyü genişlet"
          className="isg-sidebar-navbtn w-full h-10 flex items-center justify-center border-t isg-sidebar-sep"
        >
          <i className="ri-arrow-right-s-line" />
        </button>
      )}
      </div>

      {/* User mini — her zaman en altta */}
      <div ref={profileRef} className="relative mt-auto px-3 py-3 border-t isg-sidebar-sep flex-shrink-0">
        <button
          onClick={() => setProfileOpen((p) => !p)}
          aria-haspopup="menu"
          aria-expanded={profileOpen}
          aria-label="Kullanıcı menüsü"
          className={`isg-sidebar-navbtn w-full flex items-center gap-2.5 rounded-lg cursor-pointer px-2 py-1.5 ${collapsed ? 'justify-center' : ''}`}
        >
          <Avatar src={profile.avatar || undefined} name={fullName} size="sm" />
          {!collapsed && (
            <div className="min-w-0 overflow-hidden flex-1 text-left">
              <p className="isg-sidebar-fg-strong text-sm font-medium truncate">{fullName}</p>
              <p className="isg-sidebar-fg-muted text-xs truncate">{PANEL_ROLE_LABEL[panel]}</p>
            </div>
          )}
          {!collapsed && (
            <i className={`ri-arrow-down-s-line isg-sidebar-fg-muted text-sm transition-transform duration-150 ${profileOpen ? 'rotate-180' : ''}`} />
          )}
        </button>

        {profileOpen && (
          <div
            className="absolute bottom-full right-0 mb-2 w-56 max-w-[calc(100vw-2rem)] isg-popover overflow-hidden"
            style={{ zIndex: Z_LAYERS.topbarDropdown }}
          >
            <div className="px-4 py-3 border-b isg-divider flex items-center gap-2.5">
              <Avatar src={profile.avatar || undefined} name={fullName} size="sm" />
              <div className="min-w-0">
                <p className="text-sm font-medium text-foreground-800 truncate">{fullName}</p>
                <p className="text-xs text-foreground-500 truncate">{PANEL_ROLE_LABEL[panel]}</p>
              </div>
            </div>
            <div className="py-1">
              <button
                onClick={() => handleOpenProfile('profil')}
                className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors text-left cursor-pointer"
              >
                <i className="ri-user-line text-foreground-400" />
                Profilim
              </button>
              <button
                onClick={handleAyarlar}
                className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors text-left cursor-pointer"
              >
                <i className="ri-settings-3-line text-foreground-400" />
                Ayarlar
              </button>
              <button
                onClick={() => handleOpenProfile('sifre')}
                className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors text-left cursor-pointer"
              >
                <i className="ri-shield-keyhole-line text-foreground-400" />
                Güvenlik
              </button>
              <button
                onClick={cycleTheme}
                className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors text-left cursor-pointer"
              >
                <i className="ri-contrast-2-line text-foreground-400" />
                Tema
                <span className="ml-auto flex items-center gap-1 text-xs text-foreground-500">
                  <i className={THEME_ICON[theme]} />
                  {THEME_LABEL[theme]}
                </span>
              </button>
            </div>
            <div className="border-t isg-divider py-1">
              <button
                onClick={() => { setProfileOpen(false); signOut(); }}
                className="w-full flex items-center gap-2.5 px-4 py-2 text-sm text-danger-600 hover:bg-danger-50 dark:hover:bg-danger-50/10 transition-colors text-left cursor-pointer"
              >
                <i className="ri-logout-box-r-line" />
                Çıkış Yap
              </button>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}