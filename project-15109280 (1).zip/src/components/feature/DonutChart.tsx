type SegmentColor = 'success' | 'warning' | 'danger' | 'primary' | 'accent' | 'secondary';

interface DonutSegment {
  label: string;
  value: number;
  color: SegmentColor;
}

interface DonutChartProps {
  data: DonutSegment[];
  total: number;
  size?: number;
  strokeWidth?: number;
  /** Legend'de yüzde sütununu gösterir. Varsayılan true; KPI kartlarında false kullanılır. */
  showPercent?: boolean;
  /** Lejantı gizler (kompakt KPI donut'ları için). Varsayılan false. */
  hideLegend?: boolean;
  /** Merkezde gösterilecek metin (varsayılan: total). */
  centerText?: string;
  /** Merkez alt etiketi (varsayılan: "Toplam"). */
  centerLabel?: string;
}

// Renkler yalnızca semantik scale rollerinden türetilir — hex/rgb hardcode YOKTUR.
// SVG stroke için text-* (currentColor), lejant noktası için bg-* kullanılır.
const STROKE_COLOR: Record<SegmentColor, string> = {
  success: 'text-success-500',
  warning: 'text-warning-500',
  danger: 'text-danger-500',
  primary: 'text-primary-500',
  accent: 'text-accent-500',
  secondary: 'text-secondary-500',
};

const DOT_COLOR: Record<SegmentColor, string> = {
  success: 'bg-success-500',
  warning: 'bg-warning-500',
  danger: 'bg-danger-500',
  primary: 'bg-primary-500',
  accent: 'bg-accent-500',
  secondary: 'bg-secondary-500',
};

export default function DonutChart({ data, total, size = 180, strokeWidth = 24, showPercent = true, hideLegend = false, centerText, centerLabel }: DonutChartProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;

  const segments = data.map((item) => {
    const dash = (item.value / total) * circumference;
    const segment = { ...item, dash, offset };
    offset += dash;
    return segment;
  });

  return (
    <div className="flex items-center gap-6">
      <div className="relative flex-shrink-0">
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="transform -rotate-90">
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="currentColor"
            className="text-background-300"
            strokeWidth={strokeWidth}
          />
          {segments.map((s, i) => (
            <circle
              key={i}
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke="currentColor"
              className={STROKE_COLOR[s.color]}
              strokeWidth={strokeWidth}
              strokeDasharray={`${s.dash} ${circumference - s.dash}`}
              strokeDashoffset={-s.offset}
              strokeLinecap="round"
            />
          ))}
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-foreground-950">{centerText ?? total}</span>
          <span className="text-xs text-foreground-500">{centerLabel ?? 'Toplam'}</span>
        </div>
      </div>

      {!hideLegend && (
      <div className="flex flex-col gap-2.5">
        {segments.map((s, i) => (
          <div key={i} className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${DOT_COLOR[s.color]}`} />
            <span className="text-sm text-foreground-700">{s.label}</span>
            <span className="text-sm font-semibold text-foreground-950 ml-auto">{s.value}</span>
            {showPercent && <span className="text-xs text-foreground-500">%{((s.value / total) * 100).toFixed(1)}</span>}
          </div>
        ))}
      </div>
      )}
    </div>
  );
}