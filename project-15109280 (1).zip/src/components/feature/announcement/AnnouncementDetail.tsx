import { useEffect, useState, useCallback, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import ContextMenu from '@/components/ui/ContextMenu';
import AnnouncementForm from './AnnouncementForm';
import { downloadBlobFile } from '@/lib/downloadFile';
import {
  ANNOUNCEMENT_TARGET_OPTIONS,
  priorityLabel,
  statusLabel,
  targetsLabel,
  formatDateTime,
  formatBytes,
  fetchAnnouncement,
  updateAnnouncementStatus,
  getAnnouncementAttachmentUrl,
  friendlyAnnouncementError,
  type Announcement,
} from '@/lib/announcementService';

const statusVariant = (s: string): 'warning' | 'success' | 'secondary' | 'default' => {
  switch (s) {
    case 'draft': return 'warning';
    case 'published': return 'success';
    case 'archived': return 'secondary';
    default: return 'default';
  }
};

const priorityVariant = (p: string): 'danger' | 'warning' | 'info' | 'default' => {
  switch (p) {
    case 'critical': return 'danger';
    case 'important': return 'warning';
    case 'normal': return 'info';
    default: return 'default';
  }
};

interface AnnouncementDetailProps {
  announcementId: string;
  onClose: () => void;
  onChanged?: () => void;
  onLoaded?: () => void;
}

function InfoRow({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1.5">
      <span className="text-xs text-foreground-500 flex-shrink-0">{label}</span>
      <span className="text-sm font-medium text-foreground-800 text-right min-w-0">{children}</span>
    </div>
  );
}

/**
 * Ortak duyuru detay modalı içeriği. Admin (tam yönetim) ve diğer paneller
 * (salt-okunur, NotificationBell üzerinden) aynı bileşeni kullanır.
 */
export default function AnnouncementDetail({ announcementId, onClose, onChanged, onLoaded }: AnnouncementDetailProps) {
  const { profile } = useAuth();
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();

  const isAdmin = profile?.role === 'admin';

  const [data, setData] = useState<Announcement | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [coverUrl, setCoverUrl] = useState('');

  const onLoadedRef = useRef(onLoaded);
  useEffect(() => {
    onLoadedRef.current = onLoaded;
  }, [onLoaded]);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const a = await fetchAnnouncement(announcementId);
      setData(a);
      onLoadedRef.current?.();
      const cover = a.attachments.find((att) => att.mimeType?.startsWith('image/'));
      if (cover) {
        getAnnouncementAttachmentUrl(cover.filePath).then(setCoverUrl).catch(() => undefined);
      } else {
        setCoverUrl('');
      }
    } catch (e) {
      setError(friendlyAnnouncementError(e));
    } finally {
      setLoading(false);
    }
  }, [announcementId]);

  useEffect(() => {
    load();
  }, [load]);

  const handleStatus = async (status: string, label: string) => {
    if (busy) return;
    setBusy(true);
    try {
      await updateAnnouncementStatus(announcementId, status);
      await load();
      onChanged?.();
      addToast({ title: 'Duyuru güncellendi', message: label, type: 'success' });
    } catch (e) {
      addToast({ title: 'Hata', message: friendlyAnnouncementError(e), type: 'error' });
    } finally {
      setBusy(false);
    }
  };

  const handlePublish = () => handleStatus('published', 'Duyuru yayınlandı, bildirimler gönderildi.');
  const handleArchive = () => {
    confirm({
      title: 'Yayından Kaldır',
      message: `"${data?.title ?? ''}" duyurusu yayından kaldırılacak. Yayından kaldırılan duyuru yeni bildirim üretmez.`,
      variant: 'warning',
      confirmText: 'Evet, Yayından Kaldır',
      cancelText: 'Vazgeç',
      onConfirm: () => handleStatus('archived', 'Duyuru yayından kaldırıldı.'),
    });
  };
  const handleRepublish = () => handleStatus('published', 'Duyuru yeniden yayınlandı, bildirimler gönderildi.');

  const handleEdit = () => {
    if (!data) return;
    const id = openModal({
      title: 'Duyuruyu Düzenle',
      description: data.title,
      variant: 'form',
      width: 720,
      minWidth: 440,
      minHeight: 520,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      bodyLayout: 'fill',
      content: (
        <AnnouncementForm
          mode="edit"
          announcement={data}
          onClose={() => closeModal(id)}
          onSaved={() => {
            closeModal(id);
            load();
            onChanged?.();
            addToast({ title: 'Güncellendi', message: 'Duyuru başarıyla güncellendi.', type: 'success' });
          }}
        />
      ),
    });
  };

  const handleDownload = async (filePath: string, fileName: string) => {
    try {
      const url = await getAnnouncementAttachmentUrl(filePath);
      // Yetkili içerik fetch edilir; indirilen ad MERKEZÎ motorda anlamlı/güvenli
      // yapılır (UUID yok). Yeni sekme AÇILMAZ.
      const res = await fetch(url);
      if (!res.ok) throw new Error('fetch');
      const blob = await res.blob();
      downloadBlobFile(blob, fileName);
    } catch {
      addToast({ title: 'Hata', message: 'Dosya indirilemedi.', type: 'error' });
    }
  };

  if (loading) {
    return (
      <div className="space-y-3">
        <div className="h-16 bg-background-200 dark:bg-background-300/40 rounded-lg animate-pulse" />
        <div className="h-32 bg-background-200 dark:bg-background-300/40 rounded-lg animate-pulse" />
        <div className="h-24 bg-background-200 dark:bg-background-300/40 rounded-lg animate-pulse" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="text-center py-8 text-foreground-500">
        <i className="ri-error-warning-line text-3xl mb-2 block" />
        <p className="text-sm">{error || 'Duyuru yüklenemedi.'}</p>
        <Button variant="secondary" size="sm" className="mt-3" onClick={load}>Tekrar Dene</Button>
      </div>
    );
  }

  const targetChecked = (value: string) => data.targets.includes('all') || data.targets.includes(value);

  return (
    <div className="space-y-3">
      {/* Üst kart: ikon + badge + başlık + action menu */}
      <div className="isg-section p-3.5">
        <div className="flex items-start gap-3">
          <div className="w-12 h-12 rounded-xl bg-primary-500/10 flex items-center justify-center flex-shrink-0">
            <i className="ri-megaphone-line text-primary-600 text-xl" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant={priorityVariant(data.priority)} size="sm">{priorityLabel(data.priority)}</Badge>
              <Badge variant={statusVariant(data.status)} size="sm">{statusLabel(data.status)}</Badge>
            </div>
            <p className="text-lg font-semibold text-foreground-950 mt-1.5 break-words">{data.title}</p>
          </div>
          {isAdmin && (
            <ContextMenu
              items={[
                { label: 'Düzenle', icon: 'ri-edit-line', onClick: handleEdit },
                ...(data.status === 'draft' ? [{ label: 'Yayınla', icon: 'ri-megaphone-line text-primary-500', onClick: handlePublish }] : []),
                ...(data.status === 'published' ? [{ label: 'Yayından Kaldır', icon: 'ri-archive-line', variant: 'danger' as const, onClick: handleArchive }] : []),
                ...(data.status === 'archived' ? [{ label: 'Yeniden Yayınla', icon: 'ri-megaphone-line text-primary-500', onClick: handleRepublish }] : []),
              ]}
            />
          )}
        </div>
      </div>

      {/* İçerik: kapak görseli + duyuru içeriği */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="rounded-xl overflow-hidden border border-background-300/20 dark:border-background-400/20 bg-background-100 dark:bg-background-300/30 aspect-[4/3] flex items-center justify-center">
          {coverUrl ? (
            <img src={coverUrl} alt={data.title} className="w-full h-full object-cover" />
          ) : (
            <div className="flex flex-col items-center text-foreground-400">
              <i className="ri-image-line text-3xl" />
              <span className="text-xs mt-1">Görsel yok</span>
            </div>
          )}
        </div>
        <div className="isg-section p-4">
          <div className="flex items-center gap-2 mb-2">
            <i className="ri-file-text-line text-primary-500 text-sm" />
            <h5 className="text-sm font-semibold text-foreground-800">Duyuru İçeriği</h5>
          </div>
          <p className="text-sm text-foreground-700 whitespace-pre-wrap leading-relaxed">{data.content}</p>
        </div>
      </div>

      {/* Alt kartlar: Genel Bilgiler / Hedef Panel / Ek Dosyalar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="isg-section p-4">
          <div className="flex items-center gap-2 mb-2">
            <i className="ri-information-line text-primary-500 text-sm" />
            <h5 className="text-sm font-semibold text-foreground-800">Genel Bilgiler</h5>
          </div>
          <div className="divide-y divide-background-300/15 dark:divide-background-400/15">
            <InfoRow label="Oluşturulma">{formatDateTime(data.createdAt)}</InfoRow>
            <InfoRow label="Güncelleme">{formatDateTime(data.updatedAt)}</InfoRow>
            <InfoRow label="Oluşturan">{data.creatorName}</InfoRow>
            <InfoRow label="Durum"><Badge variant={statusVariant(data.status)} size="sm">{statusLabel(data.status)}</Badge></InfoRow>
            <InfoRow label="Öncelik"><Badge variant={priorityVariant(data.priority)} size="sm">{priorityLabel(data.priority)}</Badge></InfoRow>
          </div>
        </div>

        <div className="isg-section p-4">
          <div className="flex items-center gap-2 mb-2">
            <i className="ri-focus-3-line text-primary-500 text-sm" />
            <h5 className="text-sm font-semibold text-foreground-800">Hedef Panel</h5>
          </div>
          <div className="space-y-1.5">
            {ANNOUNCEMENT_TARGET_OPTIONS.map((t) => {
              const checked = targetChecked(t.value);
              return (
                <div key={t.value} className="flex items-center gap-2">
                  <i className={`${t.icon} text-sm ${checked ? 'text-primary-500' : 'text-foreground-400'}`} />
                  <span className={`text-sm flex-1 ${checked ? 'text-foreground-800 font-medium' : 'text-foreground-400'}`}>{t.label}</span>
                  {checked && <i className="ri-check-line text-primary-500 text-sm" />}
                </div>
              );
            })}
          </div>
          <p className="text-[11px] text-foreground-500 mt-2">{targetsLabel(data.targets)}</p>
        </div>

        <div className="isg-section p-4">
          <div className="flex items-center gap-2 mb-2">
            <i className="ri-attachment-2 text-primary-500 text-sm" />
            <h5 className="text-sm font-semibold text-foreground-800">Ek Dosyalar</h5>
          </div>
          {data.attachments.length === 0 ? (
            <p className="text-xs text-foreground-500">Ek dosya yok.</p>
          ) : (
            <div className="space-y-2">
              {data.attachments.map((att) => (
                <button
                  key={att.id}
                  type="button"
                  onClick={() => handleDownload(att.filePath, att.fileName)}
                  className="w-full flex items-center gap-2.5 p-2.5 bg-background-100 dark:bg-background-300/30 border border-background-300/20 dark:border-background-400/20 rounded-lg hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer text-left"
                >
                  <span className="w-8 h-8 rounded-md bg-primary-500/10 text-primary-600 flex items-center justify-center flex-shrink-0">
                    <i className="ri-file-3-line text-sm" />
                  </span>
                  <span className="flex-1 min-w-0">
                    <span className="block text-xs font-medium text-foreground-800 truncate">{att.fileName}</span>
                    <span className="block text-[10px] text-foreground-500 mt-0.5">{formatBytes(att.fileSize)}</span>
                  </span>
                  <i className="ri-download-2-line text-foreground-500 flex-shrink-0" />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Aksiyonlar */}
      <div className="flex items-center justify-between gap-2 pt-1">
        <div>
          {isAdmin && (
            <Button variant="ghost" size="sm" onClick={handleEdit} leftIcon={<i className="ri-edit-line" />}>
              Düzenle
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && data.status === 'published' && (
            <Button variant="danger" size="sm" isLoading={busy} onClick={handleArchive} leftIcon={<i className="ri-archive-line" />}>
              Yayından Kaldır
            </Button>
          )}
          {isAdmin && data.status === 'draft' && (
            <Button variant="primary" size="sm" isLoading={busy} onClick={handlePublish} leftIcon={<i className="ri-megaphone-line" />}>
              Yayınla
            </Button>
          )}
          {isAdmin && data.status === 'archived' && (
            <Button variant="secondary" size="sm" isLoading={busy} onClick={handleRepublish} leftIcon={<i className="ri-megaphone-line" />}>
              Yeniden Yayınla
            </Button>
          )}
          <Button variant="secondary" size="sm" onClick={onClose} leftIcon={<i className="ri-close-line" />}>
            Kapat
          </Button>
        </div>
      </div>
    </div>
  );
}