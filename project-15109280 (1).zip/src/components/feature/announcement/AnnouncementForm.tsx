import { useState, useCallback } from 'react';
import useSWR from 'swr';
import { useToastActions } from '@/hooks/useToast';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import Checkbox from '@/components/ui/Checkbox';
import Radio from '@/components/ui/Radio';
import AttachmentPicker from '@/components/feature/support/AttachmentPicker';
import {
  ANNOUNCEMENT_PRIORITY_OPTIONS,
  ANNOUNCEMENT_TARGET_OPTIONS,
  createAnnouncement,
  updateAnnouncement,
  uploadAnnouncementAttachment,
  deleteAnnouncementAttachment,
  getAnnouncementAttachmentUrl,
  fetchOsgbOptions,
  friendlyAnnouncementError,
  formatBytes,
  type Announcement,
  type AnnouncementAttachment,
  type OsgbOption,
} from '@/lib/announcementService';

interface AnnouncementFormProps {
  mode: 'create' | 'edit';
  announcement?: Announcement;
  onClose: () => void;
  onSaved: () => void;
}

/**
 * Ortak duyuru oluşturma / düzenleme formu. Sadece Admin kullanır.
 * Sol kolon: başlık + içerik + dosya ekle. Sağ kolon: öncelik + hedef + yayın durumu.
 * OSGB Yönetim hedefi seçilirse belirli OSGB'ler seçilebilir. Dosyalar gerçek Storage'a yüklenir.
 */
export default function AnnouncementForm({ mode, announcement, onClose, onSaved }: AnnouncementFormProps) {
  const { addToast } = useToastActions();
  const [title, setTitle] = useState(announcement?.title ?? '');
  const [content, setContent] = useState(announcement?.content ?? '');
  const [priority, setPriority] = useState(announcement?.priority ?? 'normal');
  const [targets, setTargets] = useState<string[]>(announcement?.targets ?? []);
  const [osgbIds, setOsgbIds] = useState<string[]>(announcement?.osgbIds ?? []);
  const [publish, setPublish] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [existing, setExisting] = useState<AnnouncementAttachment[]>(announcement?.attachments ?? []);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');

  const { data: osgbOptions = [] } = useSWR<OsgbOption[]>('announcement-osgb-options', fetchOsgbOptions);

  const toggleTarget = useCallback((val: string) => {
    setTargets((prev) => {
      if (val === 'all') {
        return prev.includes('all') ? [] : ['all'];
      }
      const withoutAll = prev.filter((t) => t !== 'all');
      if (withoutAll.includes(val)) {
        if (val === 'osgb') setOsgbIds([]);
        return withoutAll.filter((t) => t !== val);
      }
      return [...withoutAll, val];
    });
    setSubmitError('');
  }, []);

  const toggleOsgb = useCallback((id: string) => {
    setOsgbIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }, []);

  const validate = (): boolean => {
    const errs: Record<string, string> = {};
    if (!title.trim()) errs.title = 'Başlık zorunludur.';
    if (!content.trim()) errs.content = 'İçerik zorunludur.';
    if (targets.length === 0) errs.targets = 'En az bir hedef panel seçmelisiniz.';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const uploadFiles = useCallback(async (announcementId: string): Promise<number> => {
    let failed = 0;
    const seen = new Set(existing.map((a) => `${a.fileName}::${a.fileSize}`));
    for (const file of files) {
      const sig = `${file.name}::${file.size}`;
      if (seen.has(sig)) continue;
      seen.add(sig);
      try {
        await uploadAnnouncementAttachment(announcementId, file);
      } catch {
        failed += 1;
      }
    }
    return failed;
  }, [files, existing]);

  const handleDeleteExisting = useCallback(async (att: AnnouncementAttachment) => {
    try {
      await deleteAnnouncementAttachment(att.id, att.filePath);
      setExisting((prev) => prev.filter((a) => a.id !== att.id));
      addToast({ title: 'Ek silindi', message: `${att.fileName} kaldırıldı.`, type: 'success' });
    } catch (e) {
      addToast({ title: 'Ek silinemedi', message: friendlyAnnouncementError(e), type: 'error' });
    }
  }, [addToast]);

  const handleViewExisting = useCallback(async (att: AnnouncementAttachment) => {
    try {
      const url = await getAnnouncementAttachmentUrl(att.filePath);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch {
      addToast({ title: 'Hata', message: 'Dosya açılamadı.', type: 'error' });
    }
  }, [addToast]);

  const handleSubmit = async () => {
    if (submitting) return;
    if (!validate()) return;
    setSubmitting(true);
    setSubmitError('');
    try {
      let failedFiles = 0;
      if (mode === 'create') {
        const id = await createAnnouncement({ title, content, priority, targets, osgbIds, publish });
        failedFiles = await uploadFiles(id);
      } else if (announcement) {
        await updateAnnouncement(announcement.id, { title, content, priority, targets, osgbIds });
        failedFiles = await uploadFiles(announcement.id);
      }
      if (failedFiles > 0) {
        addToast({
          title: 'Bazı dosyalar eklenemedi',
          message: `${failedFiles} dosya yüklenemedi; duyuru kaydedildi.`,
          type: 'warning',
        });
      }
      onSaved();
    } catch (e) {
      setSubmitError(friendlyAnnouncementError(e));
    } finally {
      setSubmitting(false);
    }
  };

  const primaryLabel = mode === 'create' ? (publish ? 'Hemen Yayınla' : 'Taslak Kaydet') : 'Kaydet';

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="flex-1 overflow-y-auto overflow-x-hidden min-h-0 space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Sol kolon */}
          <div className="lg:col-span-2 space-y-3">
            <Input
              label="Başlık"
              placeholder="Duyuru başlığını girin..."
              required
              maxLength={150}
              value={title}
              onChange={(e) => { setTitle(e.target.value); setErrors((p) => ({ ...p, title: '' })); }}
              error={errors.title}
              helpText={`${title.length} / 150`}
            />

            <Textarea
              label="İçerik"
              placeholder="Duyuru içeriğini buraya yazın..."
              required
              maxLength={4000}
              value={content}
              onChange={(e) => { setContent(e.target.value); setErrors((p) => ({ ...p, content: '' })); }}
              error={errors.content}
              helpText={`${content.length} / 4000`}
              rows={10}
            />
          </div>

          {/* Sağ kolon */}
          <div className="space-y-3">
            <Select
              label="Öncelik"
              required
              options={ANNOUNCEMENT_PRIORITY_OPTIONS}
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              leftIcon={<i className="ri-flag-line" />}
            />

            <div>
              <label className="block mb-2 text-sm font-medium text-foreground-800">
                Hedef Panel <span className="text-danger-600">*</span>
              </label>
              <div className="space-y-1.5">
                {ANNOUNCEMENT_TARGET_OPTIONS.map((t) => {
                  const active = targets.includes(t.value) || (t.value !== 'all' && targets.includes('all'));
                  const reallyActive = targets.includes(t.value);
                  return (
                    <div
                      key={t.value}
                      className={`flex items-center gap-2.5 p-2.5 border rounded-lg transition-colors ${
                        active ? 'border-primary-400/60 bg-primary-50/40 dark:bg-primary-500/10' : 'border-background-300/20 dark:border-background-400/20 hover:border-background-400/50'
                      }`}
                    >
                      <Checkbox
                        checked={targets.includes(t.value)}
                        disabled={t.value !== 'all' && targets.includes('all')}
                        onChange={() => toggleTarget(t.value)}
                      />
                      <span
                        onClick={() => { if (!(t.value !== 'all' && targets.includes('all'))) toggleTarget(t.value); }}
                        className="flex items-center gap-2.5 flex-1 cursor-pointer"
                      >
                        <i className={`${t.icon} text-sm ${active ? 'text-primary-600' : 'text-foreground-500'}`} />
                        <span className="flex-1 text-sm font-medium text-foreground-800">{t.label}</span>
                        {reallyActive && <i className="ri-check-line text-primary-500 flex-shrink-0" />}
                      </span>
                    </div>
                  );
                })}
              </div>
              {errors.targets && (
                <p className="mt-1.5 text-xs text-danger-600 flex items-center gap-1">
                  <i className="ri-error-warning-line" />
                  {errors.targets}
                </p>
              )}
            </div>

            {/* OSGB seçimi: yalnız "OSGB Yönetim" hedefi seçilince görünür. */}
            {targets.includes('osgb') && !targets.includes('all') && (
              <div className="border border-primary-200/50 dark:border-primary-500/20 rounded-lg p-3 bg-primary-50/30 dark:bg-primary-500/5">
                <div className="flex items-center gap-2 mb-2">
                  <i className="ri-building-4-line text-primary-500 text-sm" />
                  <p className="text-sm font-medium text-foreground-800">Hedef OSGB</p>
                </div>
                <p className="text-xs text-foreground-500 mb-2">
                  Belirli OSGB seçmezseniz tüm OSGB yöneticilerine gönderilir.
                </p>
                {osgbOptions.length === 0 ? (
                  <p className="text-xs text-foreground-400">OSGB listesi yüklenemedi.</p>
                ) : (
                  <div className="max-h-40 overflow-y-auto space-y-1.5 pr-1">
                    {osgbOptions.map((o) => {
                      const active = osgbIds.includes(o.id);
                      return (
                        <Checkbox
                          key={o.id}
                          checked={active}
                          onChange={() => toggleOsgb(o.id)}
                          label={o.unvan}
                        />
                      );
                    })}
                  </div>
                )}
                {osgbIds.length > 0 && (
                  <p className="mt-2 text-xs text-primary-700">{osgbIds.length} OSGB seçildi.</p>
                )}
              </div>
            )}
          </div>

          {/* Alt sol: Dosya Ekle */}
          <div className="lg:col-span-2 space-y-3">
            {/* Mevcut ekler (edit): görüntüle / sil */}
            {existing.length > 0 && (
              <div>
                <label className="isg-form-label">Mevcut Ekler</label>
                <div className="space-y-2">
                  {existing.map((att) => (
                    <div key={att.id} className="flex items-center gap-2.5 p-2.5 bg-background-100 dark:bg-background-200/50 border border-background-300/20 rounded-lg">
                      <i className="ri-file-line text-foreground-400 text-sm flex-shrink-0" />
                      <span className="text-xs font-medium text-foreground-800 truncate flex-1">{att.fileName}</span>
                      <span className="text-[10px] text-foreground-400 flex-shrink-0">{formatBytes(att.fileSize)}</span>
                      <button type="button" onClick={() => handleViewExisting(att)} className="text-foreground-400 hover:text-primary-600 cursor-pointer" title="Görüntüle">
                        <i className="ri-eye-line" />
                      </button>
                      <button type="button" onClick={() => handleDeleteExisting(att)} className="text-foreground-400 hover:text-danger-600 cursor-pointer" title="Sil">
                        <i className="ri-delete-bin-line" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="isg-form-label">Dosya Ekle (İsteğe Bağlı)</label>
              <AttachmentPicker files={files} onChange={setFiles} disabled={submitting} />
            </div>
          </div>

          {/* Alt sağ: Yayın Durumu */}
          <div className="space-y-3">
            {mode === 'create' && (
              <div>
                <label className="block mb-2 text-sm font-medium text-foreground-800">
                  Yayın Durumu <span className="text-danger-600">*</span>
                </label>
                <div className="space-y-1.5">
                  <div className={`flex items-start gap-3 p-2.5 border rounded-lg transition-colors ${!publish ? 'border-primary-400/60 bg-primary-50/40 dark:bg-primary-500/10' : 'border-background-300/20 dark:border-background-400/20 hover:border-background-400/50'}`}>
                    <Radio name="publish" checked={!publish} onChange={() => setPublish(false)} />
                    <div className="cursor-pointer flex-1" onClick={() => setPublish(false)}>
                      <p className="text-sm font-medium text-foreground-800">Taslak Kaydet</p>
                      <p className="text-xs text-foreground-500 mt-0.5">Bildirim gönderilmez, sonra yayınlarsınız.</p>
                    </div>
                  </div>
                  <div className={`flex items-start gap-3 p-2.5 border rounded-lg transition-colors ${publish ? 'border-primary-400/60 bg-primary-50/40 dark:bg-primary-500/10' : 'border-background-300/20 dark:border-background-400/20 hover:border-background-400/50'}`}>
                    <Radio name="publish" checked={publish} onChange={() => setPublish(true)} />
                    <div className="cursor-pointer flex-1" onClick={() => setPublish(true)}>
                      <p className="text-sm font-medium text-foreground-800">Hemen Yayınla</p>
                      <p className="text-xs text-foreground-500 mt-0.5">Hedef kullanıcılara bildirim gönderilir.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {submitError && (
          <p className="text-xs text-danger-600 flex items-center gap-1">
            <i className="ri-error-warning-line" />
            {submitError}
          </p>
        )}
      </div>

      <div className="flex items-center justify-end gap-2 pt-3 border-t border-background-300/30 flex-shrink-0 mt-3">
        <Button variant="ghost" onClick={onClose} disabled={submitting}>İptal</Button>
        <Button
          variant="primary"
          isLoading={submitting}
          onClick={handleSubmit}
          leftIcon={mode === 'create' && publish ? <i className="ri-megaphone-line" /> : <i className="ri-save-line" />}
        >
          {primaryLabel}
        </Button>
      </div>
    </div>
  );
}