import { useCallback, useEffect, useRef, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import { useToastActions } from '@/hooks/useToast';
import { downloadBlobFile } from '@/lib/downloadFile';
import {
  priorityLabel,
  formatDateTime,
  formatBytes,
  fetchAnnouncement,
  getAnnouncementAttachmentUrl,
  friendlyAnnouncementError,
  type Announcement,
  type AnnouncementAttachment,
} from '@/lib/announcementService';

interface AnnouncementReaderModalProps {
  announcementId: string;
  onClose: () => void;
  /** Duyuru başarıyla yüklendiğinde çağrılır (okundu işaretlemek için). */
  onLoaded?: () => void;
}

const priorityVariant = (p: string): 'danger' | 'warning' | 'info' | 'default' => {
  switch (p) {
    case 'critical': return 'danger';
    case 'important': return 'warning';
    case 'normal': return 'info';
    default: return 'default';
  }
};

/** Önceliğe göre renk tonu — sol aksan çubuğu ve ikon kutusu için. */
function priorityTone(p: string): { bar: string; soft: string } {
  switch (p) {
    case 'critical':
      return { bar: 'bg-danger-500', soft: 'bg-danger-50 text-danger-700 dark:bg-danger-50/40' };
    case 'important':
      return { bar: 'bg-warning-500', soft: 'bg-warning-50 text-warning-700 dark:bg-warning-50/40' };
    default:
      return { bar: 'bg-primary-500', soft: 'bg-primary-50 text-primary-700 dark:bg-primary-50/40' };
  }
}

function isImage(att: AnnouncementAttachment): boolean {
  return (att.mimeType || '').startsWith('image/');
}

/**
 * Bildirimden açılan DUYURU OKUYUCU modalı (salt-okunur).
 *
 * Admin dışı paneller (OSGB / Firma / Uzman / Hekim) bu modalı bildirim
 * zilinden açar. Yönetim işlemleri (düzenle/yayınla/arşivle) GÖSTERİLMEZ;
 * yalnızca duyuru içeriği, öncelik, tarih ve ek dosyalar sunulur.
 */
export default function AnnouncementReaderModal({ announcementId, onClose, onLoaded }: AnnouncementReaderModalProps) {
  const { addToast } = useToastActions();
  const [data, setData] = useState<Announcement | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [busyId, setBusyId] = useState('');

  const onLoadedRef = useRef(onLoaded);
  useEffect(() => {
    onLoadedRef.current = onLoaded;
  }, [onLoaded]);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const a = await fetchAnnouncement(announcementId);
      setData(a);
      if (onLoadedRef.current) onLoadedRef.current();
      const cover = a.attachments.find(isImage);
      if (cover) {
        getAnnouncementAttachmentUrl(cover.filePath).then(setCoverUrl).catch(() => setCoverUrl(''));
      } else {
        setCoverUrl('');
      }
    } catch (e) {
      setError(friendlyAnnouncementError(e));
    } finally {
      setLoading(false);
    }
  }, [announcementId]);

  useEffect(() => {
    load();
  }, [load]);

  const handleDownload = async (att: AnnouncementAttachment) => {
    setBusyId(att.id);
    try {
      const url = await getAnnouncementAttachmentUrl(att.filePath);
      // Yetkili içerik fetch edilir; indirilen ad MERKEZÎ motorda anlamlı/güvenli
      // yapılır (UUID yok). Yeni sekme AÇILMAZ.
      const res = await fetch(url);
      if (!res.ok) throw new Error('fetch');
      const blob = await res.blob();
      downloadBlobFile(blob, att.fileName);
    } catch {
      addToast({ title: 'Hata', message: 'Dosya indirilemedi. Lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setBusyId('');
    }
  };

  if (loading) {
    return (
      <div className="space-y-3">
        <div className="h-24 bg-background-200 dark:bg-background-300/45 rounded-xl animate-pulse" />
        <div className="h-40 bg-background-200 dark:bg-background-300/45 rounded-xl animate-pulse" />
        <div className="h-20 bg-background-200 dark:bg-background-300/45 rounded-xl animate-pulse" />
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="text-center py-10 text-foreground-500">
        <div className="w-12 h-12 mx-auto rounded-full bg-background-100 dark:bg-background-300/30 flex items-center justify-center mb-3">
          <i className="ri-error-warning-line text-xl text-danger-500" />
        </div>
        <p className="text-sm">{error || 'Duyuru yüklenemedi.'}</p>
        <Button variant="secondary" size="sm" className="mt-3" onClick={load} leftIcon={<i className="ri-refresh-line" />}>
          Tekrar Dene
        </Button>
      </div>
    );
  }

  const tone = priorityTone(data.priority);
  const nonCoverAttachments = data.attachments.filter((att) => att.filePath !== data.attachments.find(isImage)?.filePath);
  const publishedLabel = data.publishedAt ? formatDateTime(data.publishedAt) : formatDateTime(data.createdAt);

  return (
    <div className="space-y-3">
      {/* Başlık bloğu: öncelik aksanı + ikon + başlık + meta */}
      <div className="relative overflow-hidden rounded-xl bg-background-100 dark:bg-background-300/30 p-4">
        <div className={`absolute left-0 top-0 h-full w-1.5 ${tone.bar}`} />
        <div className="flex items-start gap-3 pl-2">
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${tone.soft}`}>
            <i className="ri-megaphone-line text-xl" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant={priorityVariant(data.priority)} size="sm">{priorityLabel(data.priority)}</Badge>
              <span className="text-xs text-foreground-500 flex items-center gap-1">
                <i className="ri-calendar-line" />
                {publishedLabel}
              </span>
            </div>
            <h3 className="text-lg font-semibold text-foreground-950 mt-2 break-words">{data.title}</h3>
            <p className="text-xs text-foreground-500 mt-1 flex items-center gap-1">
              <i className="ri-user-star-line" />
              {data.creatorName}
            </p>
          </div>
        </div>
      </div>

      {/* Kapak görseli (varsa) */}
      {coverUrl && (
        <div className="rounded-xl overflow-hidden border isg-divider bg-background-100 dark:bg-background-300/30 aspect-[16/9]">
          <img src={coverUrl} alt={data.title} className="w-full h-full object-cover" />
        </div>
      )}

      {/* İçerik */}
      <div className="isg-section p-4">
        <div className="flex items-center gap-2 mb-2">
          <i className="ri-file-text-line text-primary-500 text-sm" />
          <h5 className="text-sm font-semibold text-foreground-800">Duyuru İçeriği</h5>
        </div>
        <p className="text-sm text-foreground-700 leading-relaxed whitespace-pre-wrap break-words">{data.content}</p>
      </div>

      {/* Ek dosyalar */}
      {nonCoverAttachments.length > 0 && (
        <div className="isg-section p-4">
          <div className="flex items-center gap-2 mb-2.5">
            <i className="ri-attachment-2 text-primary-500 text-sm" />
            <h5 className="text-sm font-semibold text-foreground-800">Ek Dosyalar ({nonCoverAttachments.length})</h5>
          </div>
          <div className="space-y-2">
            {nonCoverAttachments.map((att) => (
              <button
                key={att.id}
                type="button"
                onClick={() => handleDownload(att)}
                disabled={busyId === att.id}
                className="w-full flex items-center gap-2.5 p-2.5 bg-background-100 dark:bg-background-300/30 border isg-divider rounded-lg hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer text-left disabled:opacity-60"
              >
                <span className="w-9 h-9 rounded-lg bg-primary-500/10 text-primary-600 flex items-center justify-center flex-shrink-0">
                  <i className={isImage(att) ? 'ri-image-line' : 'ri-file-3-line'} />
                </span>
                <span className="flex-1 min-w-0">
                  <span className="block text-sm font-medium text-foreground-800 truncate">{att.fileName}</span>
                  <span className="block text-[11px] text-foreground-500 mt-0.5">{formatBytes(att.fileSize)}</span>
                </span>
                {busyId === att.id ? (
                  <i className="ri-loader-4-line animate-spin text-foreground-500 flex-shrink-0" />
                ) : (
                  <i className="ri-download-2-line text-foreground-500 flex-shrink-0" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Aksiyonlar */}
      <div className="flex justify-end pt-0.5">
        <Button variant="secondary" size="sm" className="whitespace-nowrap" onClick={onClose} leftIcon={<i className="ri-close-line" />}>
          Kapat
        </Button>
      </div>
    </div>
  );
}