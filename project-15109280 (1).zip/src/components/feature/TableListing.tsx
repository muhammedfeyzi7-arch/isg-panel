import { useState, useMemo, useCallback } from 'react';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import FilterBar from '@/components/ui/FilterBar';
import type { FilterField, FilterValue } from '@/components/ui/FilterBar';
import Pagination from '@/components/ui/Pagination';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import ActionSheet, { type ListAction } from '@/components/ui/ActionSheet';
import { useLongPress } from '@/hooks/useLongPress';
import { useBottomSheet } from '@/hooks/useBottomSheet';
import { matchesSearch } from '@/utils/turkishText';

interface TableListingProps<T extends Record<string, unknown>> {
  data: T[];
  columns: TableColumn<T>[];
  keyExtractor: (row: T) => string;
  title?: string;
  subtitle?: string;
  headerActions?: React.ReactNode;
  filters?: FilterField[];
  searchable?: boolean;
  searchPlaceholder?: string;
  searchDebounceMs?: number;
  selectable?: boolean;
  onSelectionChange?: (keys: string[]) => void;
  bulkActions?: (selection: { keys: string[]; rows: T[] }, helpers: { clear: () => void }) => React.ReactNode;
  rowActions?: (row: T) => React.ReactNode;
  pageSize?: number;
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  emptyAction?: { label: string; onClick: () => void; icon?: string };
  onRowClick?: (row: T) => void;
  className?: string;
  /**
   * Mobil kart görünümü. Verilmezse tablo mobilde de gösterilir
   * (ancak yatay scroll yok, hücreler kırılır).
   * Bu prop verildiğinde: mobilde kart, desktop'ta tablo.
   */
  mobileCardRenderer?: (row: T) => React.ReactNode;
  /**
   * Mobil long-press action sheet. Verilirse mobil kartlara uzun basılınca
   * alttan açılan Global Action Sheet gösterilir. İçerik her panelin gerçek
   * işlemlerine göre dinamik sağlanır; yeni işlem uydurulmaz.
   */
  longPressActions?: (row: T) => ListAction[];
  longPressTitle?: (row: T) => string;
}

function isActiveValue(v: FilterValue | undefined): boolean {
  if (v === undefined || v === null) return false;
  if (typeof v === 'string') return v !== '';
  if (Array.isArray(v)) return v.length > 0;
  return !!(v.from || v.to);
}

/**
 * Tek ortak Listing/Table Motoru. Admin, OSGB, Firma, Uzman ve Hekim
 * panellerinin tamamı bu motoru kullanır. Veri ve kolonlar değişebilir,
 * motor ve davranış değişmez.
 *
 * Mobil: mobileCardRenderer varsa kart görünümü, yoksa responsive tablo.
 * Desktop: her zaman tablo.
 */
export default function TableListing<T extends Record<string, unknown>>({
  data,
  columns,
  keyExtractor,
  title,
  subtitle,
  headerActions,
  filters = [],
  searchable = true,
  searchPlaceholder,
  searchDebounceMs = 300,
  selectable = false,
  onSelectionChange,
  bulkActions,
  rowActions,
  pageSize = 10,
  loading,
  error,
  onRetry,
  emptyAction,
  onRowClick,
  className = '',
  mobileCardRenderer,
  longPressActions,
  longPressTitle,
}: TableListingProps<T>) {
  const [currentPage, setCurrentPage] = useState(1);
  const [currentPageSize, setCurrentPageSize] = useState(pageSize);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [sortKey, setSortKey] = useState<string | undefined>(undefined);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const isMobile = useMediaQuery('(max-width: 1023px)');

  const handleSelectionChange = useCallback(
    (keys: string[]) => {
      setSelectedKeys(keys);
      onSelectionChange?.(keys);
    },
    [onSelectionChange],
  );

  // Seçili satırlar: her satır için O(m) `.includes` yerine tek geçişte Set ile
  // O(1) arama (büyük listelerde + çoklu seçimde belirgin kazanç).
  const selectedRows = useMemo(() => {
    const selected = new Set(selectedKeys);
    return data.filter((row) => selected.has(keyExtractor(row)));
  }, [data, selectedKeys, keyExtractor]);

  const handleSort = useCallback(
    (key: string) => {
      if (sortKey === key) {
        setSortDirection((prev) => (prev === 'asc' ? 'desc' : 'asc'));
      } else {
        setSortKey(key);
        setSortDirection('asc');
      }
    },
    [sortKey],
  );

  const processedData = useMemo(() => {
    let result = [...data];

    // Search — satırdaki TÜM ham değerlerde (kolonlarla sınırlı değil).
    // Böylece marka+model gibi türetilmiş/render edilen kolonlar da bulunur.
    if (searchQuery.trim()) {
      const q = searchQuery.trim();
      result = result.filter((row) =>
        Object.values(row as Record<string, unknown>).some((val) => {
          if (val === null || val === undefined) return false;
          if (typeof val === 'object') return false;
          return matchesSearch(String(val), q);
        }),
      );
    }

    // Filtreler (select, text, multi-select, status, date, date-range)
    Object.entries(filterValues).forEach(([key, value]) => {
      if (!isActiveValue(value)) return;
      result = result.filter((row) => {
        const rowVal = String(row[key as keyof T] ?? '').toLowerCase();

        if (Array.isArray(value)) {
          if (value.length === 0) return true;
          return value.some((v) => rowVal.includes(v.toLowerCase()));
        }

        if (typeof value === 'object' && value !== null) {
          const range = value as { from: string; to: string };
          const dateStr = String(row[key as keyof T] ?? '');
          if (range.from && dateStr < range.from) return false;
          if (range.to && dateStr > range.to) return false;
          return true;
        }

        return rowVal.includes(String(value).toLowerCase());
      });
    });

    // Sıralama (per-kolon, sadece sortable kolonlar)
    if (sortKey) {
      result.sort((a, b) => {
        const aVal = String(a[sortKey as keyof T] ?? '');
        const bVal = String(b[sortKey as keyof T] ?? '');
        return sortDirection === 'asc'
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      });
    }

    return result;
    // NOT: `columns` bilinçli olarak bağımlılık DIŞINDA — filtre/arama/sıralama
    // hesabı kolonlara bağlı DEĞİL. Kolon referansı değişse bile (ör. inline tanım)
    // tüm veri kümesi boşuna yeniden taranmaz.
  }, [data, searchQuery, filterValues, sortKey, sortDirection]);

  const totalPages = Math.max(1, Math.ceil(processedData.length / currentPageSize));
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * currentPageSize;
    return processedData.slice(start, start + currentPageSize);
  }, [processedData, currentPage, currentPageSize]);

  const activeFilterCount = useMemo(
    () => filters.filter((f) => isActiveValue(filterValues[f.key])).length,
    [filters, filterValues],
  );

  const handleFilterChange = (key: string, value: FilterValue) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }));
    setCurrentPage(1);
  };

  const handleFilterReset = () => {
    setFilterValues({});
    setSearchQuery('');
    setCurrentPage(1);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setCurrentPage(1);
  };

  const { openSheet, closeSheet } = useBottomSheet();

  const openActionSheet = useCallback(
    (row: T) => {
      const actions = longPressActions?.(row);
      if (!actions || actions.length === 0) return;
      openSheet({
        title: longPressTitle ? longPressTitle(row) : 'İşlemler',
        content: (
          <ActionSheet
            actions={actions}
            onSelect={(action) => {
              closeSheet();
              action.onSelect();
            }}
          />
        ),
        showClose: true,
      });
    },
    [longPressActions, longPressTitle, openSheet, closeSheet],
  );

  const longPressHandlers = useLongPress({
    onLongPress: (key) => {
      const row = data.find((r) => keyExtractor(r) === key);
      if (row) openActionSheet(row);
    },
    disabled: !longPressActions,
  });

  const showFilters = searchable || filters.length > 0;

  return (
    <div className={`flex flex-col ${className}`}>
      <div className="isg-card flex flex-col lg:flex-1 lg:min-h-0 lg:overflow-hidden">
        {(title || subtitle || headerActions) && (
          <div className={`flex items-start justify-between p-3 pb-0 ${headerActions ? 'gap-3' : ''}`}>
            <div className="min-w-0">
              {title && <h3 className="isg-text-card-title text-foreground-950">{title}</h3>}
              {subtitle && <p className="isg-text-caption text-foreground-500">{subtitle}</p>}
            </div>
            {headerActions && <div className="flex-shrink-0">{headerActions}</div>}
          </div>
        )}

        <div className={`flex flex-col lg:flex-1 lg:min-h-0 p-3 ${title || subtitle || headerActions ? 'pt-2' : ''}`}>
          {showFilters && (
            <div className="mb-3 flex-shrink-0">
              <FilterBar
                filters={filters}
                values={filterValues}
                onChange={handleFilterChange}
                onReset={handleFilterReset}
                onSearch={handleSearch}
                searchPlaceholder={searchPlaceholder}
                searchDebounceMs={searchDebounceMs}
              />
            </div>
          )}

          {loading ? (
            <div className="flex-1 flex flex-col gap-2">
              <div className="h-9 bg-background-200 dark:bg-background-300/50 rounded-md animate-pulse" />
              {Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  className="h-11 bg-background-200 dark:bg-background-300/45 rounded-md animate-pulse"
                  style={{ animationDelay: `${i * 50}ms` }}
                />
              ))}
            </div>
          ) : error ? (
            <ErrorState message={error} onRetry={onRetry} />
          ) : processedData.length === 0 ? (
            <EmptyState
              title={searchQuery || activeFilterCount > 0 ? 'Kayıt bulunamadı' : 'Henüz veri bulunmuyor'}
              description={searchQuery || activeFilterCount > 0 ? 'Arama veya filtre kriterlerinize uygun kayıt bulunamadı.' : 'Arama kriterlerini değiştirin veya yeni kayıt ekleyin.'}
              action={searchQuery || activeFilterCount > 0 ? { label: 'Filtreleri Temizle', onClick: handleFilterReset, icon: 'ri-close-line' } : emptyAction}
            />
          ) : (
            <>
              <div className="flex items-center justify-between mb-2 flex-shrink-0">
                <p className="text-xs text-foreground-500">
                  Toplam{' '}
                  <span className="font-semibold text-foreground-800">
                    {processedData.length}
                  </span>{' '}
                  kayıt
                  {activeFilterCount > 0 || searchQuery
                    ? ' (filtre uygulandı)'
                    : ''}
                </p>
                <p className="text-xs text-foreground-400">
                  {currentPage}/{totalPages}
                </p>
              </div>

              {selectable && selectedKeys.length > 0 && (
                <div className="mb-3 flex-shrink-0">
                  {bulkActions ? (
                    bulkActions(
                      { keys: selectedKeys, rows: selectedRows },
                      { clear: () => setSelectedKeys([]) },
                    )
                  ) : (
                    <p className="text-sm text-primary-600">
                      {selectedKeys.length} kayıt seçildi
                    </p>
                  )}
                </div>
              )}

              {/* Mobil kart görünümü (mobileCardRenderer varsa, yalnızca mobilde) */}
              {mobileCardRenderer && isMobile && (
                <div
                  className="space-y-2"
                  {...(longPressActions ? longPressHandlers : {})}
                >
                  {paginatedData.map((row) => (
                    <div
                      key={keyExtractor(row)}
                      {...(longPressActions ? { 'data-longpress-key': keyExtractor(row) } : {})}
                      onClick={() => onRowClick?.(row)}
                      className={onRowClick ? 'cursor-pointer' : ''}
                    >
                      {mobileCardRenderer(row)}
                    </div>
                  ))}
                </div>
              )}

              {/* Tablo (desktop) / mobil auto-kart (mobileCardRenderer yoksa) — tek varyant */}
              {(!mobileCardRenderer || !isMobile) && (
                <div className="lg:flex-1 lg:min-h-0 lg:overflow-auto">
                  <Table
                    data={paginatedData}
                    columns={columns}
                    keyExtractor={keyExtractor}
                    selectable={selectable}
                    selectedKeys={selectedKeys}
                    onSelectionChange={handleSelectionChange}
                    sortKey={sortKey}
                    sortDirection={sortDirection}
                    onSort={handleSort}
                    rowActions={rowActions}
                    onRowClick={onRowClick}
                    stickyHeader
                  />
                </div>
              )}

              {totalPages >= 1 && (
                <div className="mt-3 pt-3 border-t isg-divider flex-shrink-0">
                  <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    pageSize={currentPageSize}
                    totalItems={processedData.length}
                    onPageChange={setCurrentPage}
                    onPageSizeChange={(size) => {
                      setCurrentPageSize(size);
                      setCurrentPage(1);
                    }}
                  />
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}