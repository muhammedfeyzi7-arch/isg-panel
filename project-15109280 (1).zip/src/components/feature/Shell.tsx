import { useState } from 'react';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import BottomNav from './BottomNav';
import { UzmanFirmaProvider } from '@/context/UzmanFirmaContext';
import { UniversalSearchProvider } from './search/UniversalSearchContext';
import { usePanelRoutePrefetch } from '@/hooks/useRoutePrefetch';

interface ShellProps {
  children: React.ReactNode;
}

export default function Shell({ children }: ShellProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  // Mevcut panelin görünen sekme chunk'larını boşta önceden indir → sekme
  // geçişleri chunk indirme beklemeden (neredeyse anında) açılır.
  usePanelRoutePrefetch();

  return (
    <UzmanFirmaProvider>
    <UniversalSearchProvider>
    <div className="h-app-screen overflow-hidden flex bg-background-50 text-foreground-950">
      {/* Sidebar — desktop only */}
      <div className="hidden lg:block">
        <Sidebar
          collapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed((p) => !p)}
        />
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 min-h-0">
        <Topbar sidebarCollapsed={sidebarCollapsed} />
        {/* pb-bottom-nav = bottom nav yüksekliği + safe area */}
        <main data-isg-scroll className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden p-3 md:p-4 lg:p-6 pb-bottom-nav lg:pb-6">
          {children}
        </main>
      </div>

      {/* Bottom Navigation — mobile only */}
      <BottomNav />
    </div>
    </UniversalSearchProvider>
    </UzmanFirmaProvider>
  );
}