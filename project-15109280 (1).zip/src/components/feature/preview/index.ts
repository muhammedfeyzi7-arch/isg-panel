/**
 * MERKEZİ DOCUMENT PREVIEW ENGINE — Ortak giriş noktası.
 *
 * Tüm modüller PDF / görsel / DOCX / XLSX önizlemesini buradan tüketir:
 *
 *   import { DocumentPreviewEngine, DocumentPreviewModal } from '@/components';
 *   // veya doğrudan:
 *   import { DocumentPreviewEngine } from '@/components/feature/preview';
 */
export { default as DocumentPreviewEngine } from '@/components/feature/preview/DocumentPreviewEngine';
export { default as SharedDocumentPreview } from '@/components/feature/preview/SharedDocumentPreview';
export { default as DocumentPreviewModal } from '@/components/feature/preview/DocumentPreviewModal';
export { usePdfDocument } from '@/components/feature/preview/usePdfDocument';
export type {
  PreviewDocumentSource,
  PreviewDocumentMeta,
  PreviewKind,
  PreviewViewerHandle,
  PreviewViewerState,
} from '@/components/feature/preview/types';
export type { SharedDocumentPreviewProps } from '@/components/feature/preview/SharedDocumentPreview';
export {
  detectPreviewKind,
  previewKindLabel,
  previewKindIcon,
  friendlyPreviewError,
  PREVIEW_DEFAULT_STATE,
} from '@/components/feature/preview/types';