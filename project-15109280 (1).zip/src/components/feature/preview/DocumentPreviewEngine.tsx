import {
  forwardRef,
  lazy,
  Suspense,
  useCallback,
  useEffect,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { PreviewViewerHandle, PreviewViewerState } from './types';
import {
  detectPreviewKind,
  friendlyPreviewError,
  previewKindLabel,
  PREVIEW_DEFAULT_STATE,
} from './types';
import type { PreviewDocumentSource } from './types';
import ViewerToolbar from '@/components/feature/preview/components/ViewerToolbar';
import ThumbnailRail, { THUMB_RAIL_WIDTH } from '@/components/feature/preview/components/ThumbnailRail';
import type { SelectMode } from '@/components/feature/preview/components/ThumbnailRail';
import {
  PreviewErrorView,
  PreviewLoadingView,
  UnsupportedFileView,
} from '@/components/feature/preview/components/PreviewStateViews';
import { usePdfDocument } from '@/components/feature/preview/usePdfDocument';
import { useMediaQuery } from '@/hooks/useMediaQuery';

/**
 * VIEWER ADAPTÖRLERİ — LAZY (React.lazy + Suspense).
 *
 * Bu motor tüm türleri destekler ama her belge açılışında TÜM renderer'ları
 * yüklemek zorunda DEĞİLDİR. Daha önce statik import edildikleri için bir görsel
 * ya da PDF açmak bile xlsx (Excel), docx-preview (Word) ve jszip (PowerPoint)
 * gibi ağır kütüphaneleri indiriyordu. Artık yalnızca AKTİF belgenin türüne
 * karşılık gelen renderer, o belge gerçekten açıldığında dinamik yüklenir.
 */
const PdfViewer = lazy(() => import('@/components/feature/preview/viewers/PdfViewer'));
const ImageViewerAdapter = lazy(() => import('@/components/feature/preview/viewers/ImageViewerAdapter'));
const DocxPreviewAdapter = lazy(() => import('@/components/feature/preview/viewers/DocxPreviewAdapter'));
const XlsxPreviewAdapter = lazy(() => import('@/components/feature/preview/viewers/XlsxPreviewAdapter'));
const PptxPreviewAdapter = lazy(() => import('@/components/feature/preview/viewers/PptxPreviewAdapter'));

export interface DocumentPreviewEngineProps {
  source: PreviewDocumentSource;
  initialPage?: number;
  title?: string;
  /** Thumbnail rayından çoklu sayfa seçimi aktif mi? (varsayılan: kapalı) */
  selectable?: boolean;
  /** Kontrollü seçim (verilmezse motor kendi içinde yönetir). */
  selectedPages?: number[];
  defaultSelectedPages?: number[];
  onSelectionChange?: (pages: number[]) => void;
  onDownload?: () => void;
  downloadBusy?: boolean;
  onStateChange?: (state: PreviewViewerState) => void;
  className?: string;
  /** Araç çubuğunu göster (gömülü kullanımda gizlenebilir). */
  showToolbar?: boolean;
  /**
   * Belge İLK AÇILDIĞINDAKİ varsayılan ölçek modu.
   *  - 'page' (varsayılan): tüm sayfayı konteynere sığdırır (küçük kağıt görünümü).
   *  - 'width': sayfa GENİŞLİĞİNİ doldurur → okunabilir (~%80-90) açılış; belge
   *    dikey olarak kendi içinde kaydırılır. Detay/önizleme modalları için uygundur.
   */
  defaultFit?: 'page' | 'width';
}

/**
 * MERKEZİ DOCUMENT PREVIEW ENGINE
 *
 * Tek giriş noktası. Doküman türünü tespit eder ve uygun adapter'ı çalıştırır:
 *   PDF → PdfViewer (PDF.js worker + virtualization) + ThumbnailRail
 *   Görsel → ImageViewerAdapter
 *   DOCX → DocxPreviewAdapter
 *   XLSX → XlsxPreviewAdapter
 *   Diğer → UnsupportedFileView (+ İndir)
 *
 * Ortak UI (ViewerToolbar / ThumbnailRail) tüm türlerde aynıdır. Dosya içeriği
 * DEĞİŞTİRİLMEZ; baytlar yalnızca `source.getBytes` (yetkilendirilmiş) ile alınır.
 */
const DocumentPreviewEngine = forwardRef<PreviewViewerHandle, DocumentPreviewEngineProps>(
  function DocumentPreviewEngine(
    {
      source,
      initialPage = 1,
      title,
      selectable = false,
      selectedPages,
      defaultSelectedPages,
      onSelectionChange,
      onDownload,
      downloadBusy,
      onStateChange,
      className,
      showToolbar = true,
      defaultFit = 'page',
    },
    ref,
  ) {
    const kind = useMemo(
      () => detectPreviewKind(source.mimeType, source.fileName),
      [source.mimeType, source.fileName],
    );

    const isDesktop = useMediaQuery('(min-width: 768px)');
    // Dokunmatik cihazda Ctrl/Shift olmadığı için düz dokunuşla çoklu seçim yapılır.
    const coarsePointer = useMediaQuery('(pointer: coarse)');
    const [railOpen, setRailOpen] = useState(isDesktop);
    useEffect(() => {
      setRailOpen(isDesktop);
    }, [isDesktop]);

    const rootRef = useRef<HTMLDivElement | null>(null);
    const viewerRef = useRef<PreviewViewerHandle | null>(null);
    const [viewerState, setViewerState] = useState<PreviewViewerState>({
      ...PREVIEW_DEFAULT_STATE,
      page: initialPage,
    });
    const [isFullscreen, setIsFullscreen] = useState(false);

    /* ---- PDF dokümanı (yalnızca kind==='pdf' iken yüklenir) ---- */
    const pdf = usePdfDocument(source.cacheKey, source.getBytes, kind === 'pdf');

    /* ---- Görsel: yetkilendirilmiş baytlardan blob URL ---- */
    const [imageUrl, setImageUrl] = useState<string | null>(null);
    const [imageLoading, setImageLoading] = useState(false);
    const [imageError, setImageError] = useState<string | null>(null);

    useEffect(() => {
      if (kind !== 'image') return undefined;

      // Doğrudan URL verilmişse bayt çekmeden göster (CORS'tan bağımsız).
      if (source.url) {
        setImageError(null);
        setImageLoading(false);
        setImageUrl(source.url);
        return undefined;
      }

      let cancelled = false;
      let created: string | null = null;
      setImageLoading(true);
      setImageError(null);
      setImageUrl(null);

      source
        .getBytes()
        .then((bytes) => {
          if (cancelled) return;
          created = URL.createObjectURL(new Blob([bytes], { type: source.mimeType || 'image/*' }));
          setImageUrl(created);
        })
        .catch((e) => {
          if (!cancelled) setImageError(friendlyPreviewError(e));
        })
        .finally(() => {
          if (!cancelled) setImageLoading(false);
        });

      return () => {
        cancelled = true;
        if (created) URL.revokeObjectURL(created);
      };
    }, [kind, source]);

    /* ---- Tam ekran ---- */
    useEffect(() => {
      const onChange = () => {
        const el = rootRef.current;
        setIsFullscreen(!!el && document.fullscreenElement === el);
      };
      document.addEventListener('fullscreenchange', onChange);
      return () => document.removeEventListener('fullscreenchange', onChange);
    }, []);

    const toggleFullscreen = useCallback(() => {
      const el = rootRef.current;
      if (!el) return;
      if (document.fullscreenElement === el) {
        document.exitFullscreen?.().catch(() => {});
      } else {
        el.requestFullscreen?.().catch(() => {});
      }
    }, []);

    /* ---- Seçim (tek / çoklu / shift aralık / ctrl-çoklu / kaldırma) ---- */
    const controlled = selectedPages !== undefined;
    const [internalSelection, setInternalSelection] = useState<number[]>(defaultSelectedPages ?? []);
    const selection = controlled ? (selectedPages as number[]) : internalSelection;
    const anchorRef = useRef<number | null>(null);

    const emitSelection = useCallback(
      (next: number[]) => {
        if (!controlled) setInternalSelection(next);
        onSelectionChange?.(next);
      },
      [controlled, onSelectionChange],
    );

    const handleSelectPage = useCallback(
      (page: number, mode: SelectMode) => {
        const prev = selection;
        let next: number[];
        if (mode === 'range' && anchorRef.current !== null) {
          const a = anchorRef.current;
          const lo = Math.min(a, page);
          const hi = Math.max(a, page);
          const range: number[] = [];
          for (let i = lo; i <= hi; i += 1) range.push(i);
          next = Array.from(new Set([...prev, ...range])).sort((x, y) => x - y);
        } else if (mode === 'toggle') {
          next = prev.includes(page)
            ? prev.filter((p) => p !== page)
            : [...prev, page].sort((x, y) => x - y);
          anchorRef.current = page;
        } else if (prev.length === 1 && prev[0] === page) {
          next = []; // tek seçili sayfaya tekrar tıkla → seçimi kaldır
          anchorRef.current = null;
        } else {
          next = [page];
          anchorRef.current = page;
        }
        emitSelection(next);
      },
      [selection, emitSelection],
    );

    /* ---- Durum yayını ---- */
    const handleViewerState = useCallback(
      (s: PreviewViewerState) => {
        setViewerState(s);
        onStateChange?.(s);
      },
      [onStateChange],
    );

    /* ---- Dış kontrol arayüzü ---- */
    useImperativeHandle(
      ref,
      () => ({
        next: () => viewerRef.current?.next(),
        prev: () => viewerRef.current?.prev(),
        goTo: (n: number) => viewerRef.current?.goTo(n),
        zoomIn: () => viewerRef.current?.zoomIn(),
        zoomOut: () => viewerRef.current?.zoomOut(),
        fitPage: () => viewerRef.current?.fitPage(),
        fitWidth: () => viewerRef.current?.fitWidth(),
        rotate: () => viewerRef.current?.rotate(),
        setZoom: (z: number) => viewerRef.current?.setZoom?.(z),
      }),
      [],
    );

    const showRail =
      kind === 'pdf' &&
      !!pdf.doc &&
      pdf.pageCount > 1 &&
      !pdf.loading &&
      !pdf.error;

    const renderBody = () => {
      if (kind === 'pdf') {
        if (pdf.loading) return <PreviewLoadingView text="Belge yükleniyor…" />;
        if (pdf.error) {
          return (
            <PreviewErrorView message={pdf.error} onRetry={pdf.retry} onDownload={onDownload} />
          );
        }
        if (!pdf.doc) return <PreviewLoadingView text="Belge yükleniyor…" />;
        return (
          <PdfViewer
            ref={viewerRef}
            doc={pdf.doc}
            cacheKey={source.cacheKey}
            initialPage={initialPage}
            initialFit={defaultFit}
            onState={handleViewerState}
          />
        );
      }

      if (kind === 'image') {
        if (imageLoading) return <PreviewLoadingView text="Görsel yükleniyor…" />;
        if (imageError || !imageUrl) {
          return (
            <PreviewErrorView message={imageError ?? 'Görsel yüklenemedi.'} onDownload={onDownload} />
          );
        }
        return (
          <ImageViewerAdapter
            ref={viewerRef}
            src={imageUrl}
            alt={source.fileName}
            onState={handleViewerState}
          />
        );
      }

      if (kind === 'docx') {
        return (
          <DocxPreviewAdapter
            ref={viewerRef}
            getBytes={source.getBytes}
            initialFit={defaultFit}
            onState={handleViewerState}
            onDownload={onDownload}
          />
        );
      }

      if (kind === 'xlsx') {
        return (
          <XlsxPreviewAdapter
            ref={viewerRef}
            getBytes={source.getBytes}
            onState={handleViewerState}
            onDownload={onDownload}
          />
        );
      }

      if (kind === 'pptx') {
        return (
          <PptxPreviewAdapter
            ref={viewerRef}
            getBytes={source.getBytes}
            onState={handleViewerState}
            onDownload={onDownload}
          />
        );
      }

      return (
        <UnsupportedFileView fileName={source.fileName} kind={kind} onDownload={onDownload} />
      );
    };

    return (
      <div
        ref={rootRef}
        className={`flex flex-col h-full min-h-0 bg-background-50 dark:bg-background-100 ${className ?? ''}`}
      >
        {showToolbar && kind !== 'unsupported' && (
          <ViewerToolbar
            title={title ?? source.fileName}
            page={viewerState.page}
            pageCount={viewerState.count}
            onGoTo={(n) => viewerRef.current?.goTo(n)}
            zoomPercent={Math.round(viewerState.zoom * 100)}
            onZoomIn={() => viewerRef.current?.zoomIn()}
            onZoomOut={() => viewerRef.current?.zoomOut()}
            onFitWidth={() => viewerRef.current?.fitWidth()}
            onFitPage={() => viewerRef.current?.fitPage()}
            onRotate={() => viewerRef.current?.rotate()}
            isFullscreen={isFullscreen}
            onToggleFullscreen={toggleFullscreen}
            onToggleRail={showToolbar && showRail ? () => setRailOpen((v) => !v) : undefined}
            railOpen={railOpen}
            onDownload={onDownload}
            downloadBusy={downloadBusy}
            canPage={kind === 'pdf' || kind === 'docx' || kind === 'pptx'}
            canZoom={kind === 'pdf' || kind === 'image' || kind === 'docx' || kind === 'xlsx' || kind === 'pptx'}
            canRotate={kind === 'pdf'}
          />
        )}

        <div className="relative flex-1 min-h-0 flex">
          {showRail && railOpen && (
            <div
              className="absolute md:static inset-y-0 left-0 z-20 h-full flex-shrink-0"
              style={{ width: THUMB_RAIL_WIDTH }}
            >
              <ThumbnailRail
                doc={pdf.doc}
                cacheKey={source.cacheKey}
                pageCount={pdf.pageCount}
                currentPage={viewerState.page}
                rotation={viewerState.rotation}
                onNavigate={(p) => viewerRef.current?.goTo(p)}
                selectable={selectable}
                selectedPages={selection}
                onSelectPage={handleSelectPage}
                touchMultiSelect={coarsePointer}
              />
            </div>
          )}

          {showRail && railOpen && !isDesktop && (
            <button
              type="button"
              aria-label="Sayfa panelini kapat"
              onClick={() => setRailOpen(false)}
              className="isg-overlay absolute inset-0 z-10 md:hidden cursor-default"
            />
          )}

          <Suspense fallback={<PreviewLoadingView text="Görüntüleyici hazırlanıyor…" />}>
            {renderBody()}
          </Suspense>
        </div>
      </div>
    );
  },
);

export default DocumentPreviewEngine;

export { previewKindLabel };