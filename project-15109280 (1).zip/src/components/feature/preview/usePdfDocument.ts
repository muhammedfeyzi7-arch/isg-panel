import { useCallback, useEffect, useRef, useState } from 'react';
import type { PDFDocumentProxy } from 'pdfjs-dist';
import { acquirePdf, releasePdf } from '@/components/feature/preview/pdf/pdfEngine';
import { friendlyPreviewError } from '@/components/feature/preview/types';

interface UsePdfDocumentResult {
  doc: PDFDocumentProxy | null;
  pageCount: number;
  loading: boolean;
  error: string | null;
  retry: () => void;
}

/**
 * PDF dokümanını (cache'li motor üzerinden) yükler. `enabled=false` iken hiçbir
 * ağ/render işi yapmaz. Unmount veya cacheKey değişiminde referans bırakılır.
 */
export function usePdfDocument(
  cacheKey: string,
  getBytes: () => Promise<ArrayBuffer>,
  enabled: boolean,
): UsePdfDocumentResult {
  const [doc, setDoc] = useState<PDFDocumentProxy | null>(null);
  const [pageCount, setPageCount] = useState(0);
  const [loading, setLoading] = useState(enabled);
  const [error, setError] = useState<string | null>(null);
  const [retryKey, setRetryKey] = useState(0);

  const getBytesRef = useRef(getBytes);
  getBytesRef.current = getBytes;

  useEffect(() => {
    if (!enabled) {
      setDoc(null);
      setPageCount(0);
      setLoading(false);
      return undefined;
    }
    let cancelled = false;
    let acquired = false;

    // ÖNEMLİ: Yeni doküman yüklenirken ÖNCEKİ dokümanı KORUYORUZ (setDoc(null) YAPMA).
    // Aksi hâlde görüntüleyici sökülür; kullanıcının seçtiği sayfa/zoom sıfırlanır ve
    // "önizleme kendi kendine yeniden ölçekleniyor" hissi oluşur. Yeni doküman gelince
    // tek seferde değiştirilir; görüntüleyici bileşeni mount kalır.
    setLoading(true);
    setError(null);

    acquirePdf(cacheKey, () => getBytesRef.current())
      .then((d) => {
        acquired = true;
        if (cancelled) {
          releasePdf(cacheKey);
          return;
        }
        setDoc(d);
        setPageCount(d.numPages);
        setLoading(false);
      })
      .catch((e) => {
        if (cancelled) return;
        setError(friendlyPreviewError(e));
        setLoading(false);
      });

    return () => {
      cancelled = true;
      if (acquired) releasePdf(cacheKey);
    };
  }, [cacheKey, enabled, retryKey]);

  const retry = useCallback(() => setRetryKey((k) => k + 1), []);

  return { doc, pageCount, loading, error, retry };
}