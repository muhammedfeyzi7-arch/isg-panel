import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { WheelEvent as ReactWheelEvent } from 'react';
import JSZip from 'jszip';
import { friendlyPreviewError } from '@/components/feature/preview/types';
import type { PreviewViewerHandle, PreviewViewerState } from '@/components/feature/preview/types';
import { sanitizeHtml } from '@/lib/sanitizeHtml';
import {
  PreviewErrorView,
  PreviewLoadingView,
} from '@/components/feature/preview/components/PreviewStateViews';

const MIN_ZOOM = 0.3;
const MAX_ZOOM = 3;
const ZOOM_STEP = 1.2;
const VIEW_PADDING = 56;
const THUMB_WIDTH = 150;
const WHEEL_LOCK_MS = 320;
const EMU_PER_PX = 9525;
const DEFAULT_SLIDE = { width: 960, height: 540 }; // 16:9
const DEFAULT_ASPECT = DEFAULT_SLIDE.height / DEFAULT_SLIDE.width;

type FitMode = 'none' | 'width' | 'page';

interface PptxPreviewAdapterProps {
  getBytes: () => Promise<ArrayBuffer>;
  onState?: (s: PreviewViewerState) => void;
  onDownload?: () => void;
}

interface Slide {
  html: string;
}

function clampZoom(z: number): number {
  return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Number(z.toFixed(3))));
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function decodeXml(s: string): string {
  return s
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}

/** Slayt XML'inden paragraf metinlerini sırayla çıkarır. */
function paragraphsOf(xml: string): string[] {
  const out: string[] = [];
  const paraRegex = /<a:p(?:\s[^>]*)?>[\s\S]*?<\/a:p>|<a:p\/>/g;
  const paras = xml.match(paraRegex) ?? [];
  paras.forEach((p) => {
    const runs = Array.from(p.matchAll(/<a:t>([\s\S]*?)<\/a:t>/g)).map((m) => m[1]);
    const text = decodeXml(runs.join('')).replace(/\s+/g, ' ').trim();
    if (text) out.push(text);
  });
  return out;
}

/** rels XML'inden Id → Target eşlemesi. */
function relationshipsOf(xml: string): Record<string, string> {
  const map: Record<string, string> = {};
  const re = /<Relationship\b[^>]*\bId="([^"]+)"[^>]*\bTarget="([^"]+)"[^>]*\/?>/g;
  let m = re.exec(xml);
  while (m) {
    map[m[1]] = m[2];
    m = re.exec(xml);
  }
  return map;
}

/** Bir göreli yolu taban dosyaya göre çözer (../media/x.png vb.). */
function resolvePath(baseFile: string, rel: string): string {
  const parts = baseFile.split('/');
  parts.pop();
  const segs = [...parts, ...rel.split('/')];
  const out: string[] = [];
  segs.forEach((s) => {
    if (s === '.' || s === '') return;
    if (s === '..') out.pop();
    else out.push(s);
  });
  return out.join('/');
}

/**
 * PowerPoint (PPTX) önizleme adapter'ı — slayt bazlı.
 *
 * PPTX bir ZIP'tir; içinden slayt XML'leri okunur, metin ve görseller çıkarılır
 * ve her slayt basit bir "slayt kutusu" olarak çizilir. Sol rayda gerçek slayt
 * küçük görüntüleri bulunur; zoom / sığdırma / tekerlekle slayt geçişi çalışır.
 * View engine sözleşmesine (PreviewViewerHandle) uyar — motorun ortak toolbar'ı
 * tarafından sürülür. Eski .ppt (ikili) biçimi XML olmadığından desteklenmez.
 */
const PptxPreviewAdapter = forwardRef<PreviewViewerHandle, PptxPreviewAdapterProps>(
  function PptxPreviewAdapter({ getBytes, onState, onDownload }, ref) {
    const viewportRef = useRef<HTMLDivElement | null>(null);
    const stageRef = useRef<HTMLDivElement | null>(null);
    const wheelLockRef = useRef<number | null>(null);
    const urlsRef = useRef<string[]>([]);

    const getBytesRef = useRef(getBytes);
    getBytesRef.current = getBytes;

    const [slides, setSlides] = useState<Slide[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [retryKey, setRetryKey] = useState(0);
    const [page, setPage] = useState(1);
    const [baseSize, setBaseSize] = useState(DEFAULT_SLIDE);
    const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
    const [fitMode, setFitMode] = useState<FitMode>('page');
    const [manualZoom, setManualZoom] = useState(1);

    const pageRef = useRef(page);
    pageRef.current = page;
    const pageCountRef = useRef(slides.length);
    pageCountRef.current = slides.length;
    const scaleRef = useRef(1);

    const revokeUrls = useCallback(() => {
      urlsRef.current.forEach((u) => URL.revokeObjectURL(u));
      urlsRef.current = [];
    }, []);

    /* ---- PPTX'i çöz: slayt sırası + metin + görseller ---- */
    useEffect(() => {
      let cancelled = false;
      setLoading(true);
      setError(null);
      setSlides([]);
      revokeUrls();

      (async () => {
        try {
          const bytes = await getBytesRef.current();
          if (cancelled) return;
          const zip = await JSZip.loadAsync(bytes);
          if (cancelled) return;

          // Slayt dosyalarını sırala (önce presentation.xml sırası, sonra sayısal).
          let slidePaths: string[] = [];
          const presRelsFile = zip.file('ppt/_rels/presentation.xml.rels');
          const presFile = zip.file('ppt/presentation.xml');
          if (presFile && presRelsFile) {
            const [presXml, relXml] = await Promise.all([
              presFile.async('string'),
              presRelsFile.async('string'),
            ]);
            const relMap = relationshipsOf(relXml);
            const idList = Array.from(presXml.matchAll(/<p:sldId\b[^>]*r:id="([^"]+)"/g)).map(
              (m) => m[1],
            );
            slidePaths = idList
              .map((id) => relMap[id])
              .filter((t): t is string => !!t)
              .map((t) => resolvePath('ppt/presentation.xml', t))
              .filter((p) => zip.file(p));
          }
          if (slidePaths.length === 0) {
            slidePaths = Object.keys(zip.files)
              .filter((p) => /^ppt\/slides\/slide\d+\.xml$/.test(p))
              .sort((a, b) => {
                const na = parseInt(a.match(/(\d+)\.xml$/)?.[1] ?? '0', 10);
                const nb = parseInt(b.match(/(\d+)\.xml$/)?.[1] ?? '0', 10);
                return na - nb;
              });
          }
          if (slidePaths.length === 0) throw new Error('Sunuda slayt bulunamadı.');

          // Slayt boyutu (EMU → px).
          let width = DEFAULT_SLIDE.width;
          let height = DEFAULT_SLIDE.height;
          if (presFile) {
            const presXml = await presFile.async('string');
            const sz = presXml.match(/<p:sldSz\b[^>]*cx="(\d+)"[^>]*cy="(\d+)"/);
            if (sz) {
              width = Math.max(320, Math.round(parseInt(sz[1], 10) / EMU_PER_PX));
              height = Math.max(200, Math.round(parseInt(sz[2], 10) / EMU_PER_PX));
            }
          }

          const mediaUrlCache = new Map<string, string>();
          const madeUrls: string[] = [];

          const built: Slide[] = [];
          for (const slidePath of slidePaths) {
            const file = zip.file(slidePath);
            if (!file) continue;
            const xml = await file.async('string');
            if (cancelled) return;

            const paras = paragraphsOf(xml);

            // Görselleri çöz (r:embed → media dosyası → blob URL).
            const relPath = slidePath.replace('slides/', 'slides/_rels/') + '.rels';
            const relFile = zip.file(relPath);
            const images: string[] = [];
            if (relFile) {
              const relXml = await relFile.async('string');
              const relMap = relationshipsOf(relXml);
              const embeds = Array.from(xml.matchAll(/r:embed="([^"]+)"/g)).map((m) => m[1]);
              for (const rid of embeds) {
                const target = relMap[rid];
                if (!target) continue;
                const mediaPath = resolvePath(slidePath, target);
                if (!zip.file(mediaPath)) continue;
                let url = mediaUrlCache.get(mediaPath);
                if (!url) {
                  const blob = await zip.file(mediaPath)?.async('blob');
                  if (blob) {
                    url = URL.createObjectURL(blob);
                    mediaUrlCache.set(mediaPath, url);
                    madeUrls.push(url);
                  }
                }
                if (url && !images.includes(url)) images.push(url);
              }
            }

            const title = paras[0] ?? '';
            const body = paras.slice(1);
            const bodyHtml = body.length
              ? `<ul class="pptx-slide-body">${body
                  .map((t) => `<li>${escapeHtml(t)}</li>`)
                  .join('')}</ul>`
              : '';
            const imgHtml = images.length
              ? `<div class="pptx-slide-media">${images
                  .map((u) => `<img src="${u}" alt="" />`)
                  .join('')}</div>`
              : '';
            built.push({
              html: `<div class="pptx-slide-inner"><div class="pptx-slide-title">${
                title ? escapeHtml(title) : '&nbsp;'
              }</div>${bodyHtml}${imgHtml}</div>`,
            });
          }

          if (cancelled) {
            madeUrls.forEach((u) => URL.revokeObjectURL(u));
            return;
          }
          urlsRef.current = madeUrls;
          setBaseSize({ width, height });
          setSlides(built);
          setPage(1);
          setFitMode('page');
          setManualZoom(1);
        } catch (e) {
          if (!cancelled) setError(friendlyPreviewError(e));
        } finally {
          if (!cancelled) setLoading(false);
        }
      })();

      return () => {
        cancelled = true;
      };
    }, [retryKey, revokeUrls]);

    useEffect(() => () => revokeUrls(), [revokeUrls]);

    /* ---- Konteyner boyutu → fit hesabı ---- */
    useLayoutEffect(() => {
      const el = viewportRef.current;
      if (!el) return undefined;
      const measure = () => setContainerSize({ width: el.clientWidth, height: el.clientHeight });
      measure();
      if (typeof ResizeObserver === 'undefined') return undefined;
      const ro = new ResizeObserver(measure);
      ro.observe(el);
      return () => ro.disconnect();
    }, []);

    const scale = useMemo(() => {
      if (containerSize.width === 0) return clampZoom(manualZoom);
      const availW = Math.max(80, containerSize.width - VIEW_PADDING);
      const availH = Math.max(80, containerSize.height - VIEW_PADDING);
      if (fitMode === 'width') return clampZoom(availW / baseSize.width);
      if (fitMode === 'page') {
        return clampZoom(Math.min(availW / baseSize.width, availH / baseSize.height));
      }
      return clampZoom(manualZoom);
    }, [containerSize, baseSize, fitMode, manualZoom]);

    scaleRef.current = scale;

    const goTo = useCallback((n: number) => {
      setPage((prev) => {
        const next = Math.max(1, Math.min(Math.round(n), pageCountRef.current || 1));
        return next === prev ? prev : next;
      });
    }, []);

    /* ---- Tekerlek: slayt sığıyorsa slayt geç; sığmıyorsa doğal kaydır ---- */
    const handleWheel = useCallback(
      (e: ReactWheelEvent<HTMLDivElement>) => {
        const vp = viewportRef.current;
        if (!vp) return;
        const overflowing = vp.scrollHeight > vp.clientHeight + 4 || vp.scrollWidth > vp.clientWidth + 4;
        if (overflowing || e.deltaY === 0) return;
        if (wheelLockRef.current != null) return;
        wheelLockRef.current = window.setTimeout(() => {
          wheelLockRef.current = null;
        }, WHEEL_LOCK_MS);
        if (e.deltaY > 0) goTo(pageRef.current + 1);
        else goTo(pageRef.current - 1);
      },
      [goTo],
    );

    useEffect(
      () => () => {
        if (wheelLockRef.current != null) window.clearTimeout(wheelLockRef.current);
      },
      [],
    );

    useEffect(() => {
      if (loading || error) return;
      onState?.({ page, count: Math.max(1, slides.length), zoom: scale, rotation: 0 });
    }, [page, slides.length, scale, loading, error, onState]);

    useImperativeHandle(
      ref,
      () => ({
        next: () => goTo(pageRef.current + 1),
        prev: () => goTo(pageRef.current - 1),
        goTo: (n: number) => goTo(n),
        zoomIn: () => {
          setFitMode('none');
          setManualZoom(clampZoom(scaleRef.current * ZOOM_STEP));
        },
        zoomOut: () => {
          setFitMode('none');
          setManualZoom(clampZoom(scaleRef.current / ZOOM_STEP));
        },
        fitPage: () => setFitMode('page'),
        fitWidth: () => setFitMode('width'),
        rotate: () => {},
      }),
      [goTo],
    );

    if (error) {
      return (
        <PreviewErrorView
          title="Sunu önizlenemedi"
          message={error}
          onRetry={() => setRetryKey((k) => k + 1)}
          onDownload={onDownload}
        />
      );
    }

    if (loading || slides.length === 0) {
      return <PreviewLoadingView text="Sunu içeriği hazırlanıyor…" />;
    }

    const ratio = THUMB_WIDTH / (baseSize.width || DEFAULT_SLIDE.width);
    const thumbHeight = Math.max(28, Math.round((baseSize.height || DEFAULT_SLIDE.height) * ratio));
    const current = slides[page - 1];

    return (
      <div className="flex-1 min-h-0 flex">
        {slides.length > 1 && (
          <aside className="hidden md:flex w-[176px] flex-shrink-0 flex-col border-r border-background-300/60 dark:border-background-400/30 bg-background-100 dark:bg-background-200/40 overflow-hidden">
            <div className="flex-shrink-0 px-2.5 py-2 text-[11px] font-semibold uppercase tracking-wide text-foreground-500">
              Slaytlar ({slides.length})
            </div>
            <div className="flex-1 overflow-y-auto px-2 pb-3 flex flex-col gap-2 isg-scroll-pane">
              {slides.map((s, index) => {
                const active = page === index + 1;
                return (
                  <button
                    key={index}
                    type="button"
                    onClick={() => goTo(index + 1)}
                    aria-label={`Slayt ${index + 1}`}
                    aria-current={active}
                    className="flex flex-col items-center gap-1 cursor-pointer"
                  >
                    <span
                      className={`block w-full overflow-hidden rounded-md bg-white ${
                        active ? 'ring-2 ring-primary-500' : 'ring-1 ring-background-300/70 hover:ring-primary-300'
                      }`}
                      style={{ height: thumbHeight }}
                    >
                      <span
                        className="block origin-top-left"
                        style={{
                          width: baseSize.width,
                          height: baseSize.height,
                          transform: `scale(${ratio})`,
                        }}
                        // GUV-08: PPTX'ten türetilen HTML enjekte edilmeden önce sanitize edilir.
                        dangerouslySetInnerHTML={{ __html: sanitizeHtml(s.html, 'preview') }}
                      />
                    </span>
                    <span
                      className={`text-[11px] tabular-nums ${
                        active ? 'text-primary-600 font-semibold' : 'text-foreground-500'
                      }`}
                    >
                      {index + 1}
                    </span>
                  </button>
                );
              })}
            </div>
          </aside>
        )}

        <div
          ref={viewportRef}
          tabIndex={0}
          onWheel={handleWheel}
          onKeyDown={(e) => {
            if (e.key === 'ArrowRight' || e.key === 'PageDown') {
              e.preventDefault();
              goTo(pageRef.current + 1);
            } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
              e.preventDefault();
              goTo(pageRef.current - 1);
            }
          }}
          className="relative flex-1 min-h-0 overflow-auto bg-background-200/60 dark:bg-background-300/25 outline-none isg-scroll-pane"
        >
          <div className="flex min-h-full w-full items-start justify-center p-4 md:p-6">
            <div
              ref={stageRef}
              className="isg-paper pptx-stage origin-top shrink-0 border border-background-300/50 dark:border-background-400/40"
              style={{
                width: baseSize.width,
                height: baseSize.height,
                zoom: scale,
              }}
              // GUV-08: PPTX'ten türetilen HTML ana sahnede de enjekte edilmeden önce sanitize edilir.
              dangerouslySetInnerHTML={{ __html: sanitizeHtml(current?.html ?? '', 'preview') }}
            />
          </div>
        </div>
      </div>
    );
  },
);

export default PptxPreviewAdapter;

export { DEFAULT_ASPECT };