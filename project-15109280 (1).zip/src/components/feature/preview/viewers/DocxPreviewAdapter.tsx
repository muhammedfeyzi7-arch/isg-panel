import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { WheelEvent as ReactWheelEvent } from 'react';
import { renderAsync } from 'docx-preview';
import { friendlyPreviewError } from '@/components/feature/preview/types';
import type { PreviewViewerHandle, PreviewViewerState } from '@/components/feature/preview/types';
import { sanitizeHtml } from '@/lib/sanitizeHtml';
import {
  PreviewErrorView,
  PreviewLoadingView,
} from '@/components/feature/preview/components/PreviewStateViews';

const MIN_ZOOM = 0.25;
const MAX_ZOOM = 4;
const ZOOM_STEP = 1.2;
const VIEW_PADDING = 56;
const THUMB_WIDTH = 92;
const DEFAULT_PAGE = { width: 794, height: 1123 };
const WHEEL_LOCK_MS = 320;
/**
 * Bir sayfa kutusu, sayfa yüksekliğinin bu katından fazla taşıyorsa (yani belge
 * gerçekten birkaç sayfayı tek kutuya sıkıştırmışsa) yeniden bölünür. KÜÇÜK
 * taşmalar (ör. hafif satır kayması) YENİDEN BÖLMEYİ TETİKLEMEZ — böylece
 * docx-preview'ın doğru ürettiği 2 sayfa, yanlışlıkla 4 sayfaya bölünmez ve
 * önizleme gerçek Word çıktısıyla örtüşür.
 */
const OVERFLOW_TOLERANCE = 2.2;
const CHROME_TAGS = ['HEADER', 'FOOTER'];

type FitMode = 'none' | 'width' | 'page';

interface DocxPreviewAdapterProps {
  getBytes: () => Promise<ArrayBuffer>;
  /** İlk açılıştaki ölçek modu ('page' = tam sayfa, 'width' = okunabilir genişliğe sığdır). */
  initialFit?: FitMode;
  onState?: (s: PreviewViewerState) => void;
  onDownload?: () => void;
}

function clampZoom(z: number): number {
  return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Number(z.toFixed(3))));
}

function px(v: string | null | undefined): number {
  const n = parseFloat(v ?? '');
  return Number.isFinite(n) ? n : 0;
}

function isEl(node: Element): node is HTMLElement {
  return typeof (node as HTMLElement).style !== 'undefined';
}

/** Belge host'undan gerçek sayfa (`section.docx`) elemanlarını toplar. */
function collectSections(host: HTMLElement): HTMLElement[] {
  const wrapper = host.querySelector('.docx-wrapper') as HTMLElement | null;
  const root: HTMLElement = wrapper ?? host;

  let sections = Array.from(root.querySelectorAll('section.docx')) as HTMLElement[];
  if (sections.length === 0) {
    sections = Array.from(root.children).filter(
      (el): el is HTMLElement => el.tagName === 'SECTION',
    );
  }
  return sections;
}

/** Sayfa kutusunun gerçek yüksekliği (sectPr → docx-preview'ın uyguladığı ölçü). */
function pageHeightOf(section: HTMLElement): number {
  const inline = px(section.style.height) || px(section.style.minHeight);
  if (inline > 200) return inline;
  const cs = getComputedStyle(section);
  const h = px(cs.height);
  if (h > 200) return h;
  return section.offsetHeight || DEFAULT_PAGE.height;
}

/** Bir bloğun kapladığı dikey alan (yükseklik + dikey marjlar). */
function blockHeight(el: HTMLElement): number {
  const cs = getComputedStyle(el);
  return el.getBoundingClientRect().height + px(cs.marginTop) + px(cs.marginBottom);
}

/** Sayfa üst/alt bilgisi (HEADER/FOOTER) elemanları. */
function chromeNodesOf(section: HTMLElement): HTMLElement[] {
  return Array.from(section.children).filter(
    (el): el is HTMLElement => isEl(el) && CHROME_TAGS.includes(el.tagName),
  );
}

/**
 * Bir sayfanın gövde bloklarını çıkarır. docx-preview bazen gövdeyi tek bir
 * sarmalayıcı içine koyar; o durumda sarmalayıcıyı (bodyShell) ve içindeki
 * blokları ayrı ayrı döndürürüz ki bloklar sayfalar arasında taşınabilsin.
 */
function flowBlocksOf(section: HTMLElement): { bodyShell: HTMLElement | null; blocks: HTMLElement[] } {
  const kids = Array.from(section.children).filter(isEl);
  const body = kids.filter((el) => !CHROME_TAGS.includes(el.tagName));
  if (body.length === 1) {
    const inner = Array.from(body[0].children).filter(isEl);
    if (inner.length > 1 && body[0].children.length === inner.length) {
      return { bodyShell: body[0], blocks: inner };
    }
  }
  return { bodyShell: null, blocks: body };
}

/** Belge gerçekten tek birkaç uzun sayfaya sıkışmış mı? (yeniden bölme gerekli mi) */
function needsRepagination(sections: HTMLElement[]): boolean {
  if (sections.length === 0) return false;
  const pageH = pageHeightOf(sections[0]);
  if (pageH <= 0) return false;
  return sections.some((s) => Math.max(s.scrollHeight, s.offsetHeight) > pageH * OVERFLOW_TOLERANCE);
}

/**
 * İÇERİK TABANLI YENİDEN SAYFALAMA.
 *
 * docx-preview sayfaları yalnızca belgede hazır bulunan sayfa sonu işaretlerine
 * göre böler; içeriği sayfa yüksekliğine göre yeniden akıtamaz. Bu yüzden
 * işaretleri eksik/yetersiz belgeler (ör. 51 sayfa → 5 kutu) yanlış bölünür.
 *
 * Bu fonksiyon render edilmiş sayfa kutularını gerçek sayfa ölçüsüne göre
 * YENİDEN PAKETLER: her bloğun yüksekliğini ölçer, sayfaya sığmıyorsa yeni bir
 * sayfa kutusu açar. Üst/alt bilgi (HEADER/FOOTER) her sayfada tekrarlanır.
 * Böylece "N sayfa" gerçekten N ayrı sayfa olur ve sol ray 1·2·3…N gider.
 */
function repaginate(wrapper: HTMLElement, sections: HTMLElement[]): HTMLElement[] {
  const template = sections[0];
  if (!template) return sections;

  const pageH = pageHeightOf(template);
  const cs = getComputedStyle(template);
  const padTop = px(cs.paddingTop);
  const padBottom = px(cs.paddingBottom);

  const chrome = chromeNodesOf(template);
  const headerNodes = chrome.filter((n) => n.tagName === 'HEADER');
  const footerNodes = chrome.filter((n) => n.tagName === 'FOOTER');

  // Sabit konumlu (absolute/fixed) üst-alt bilgi akıştan yer kaplamaz.
  const chromeHeight = chrome.reduce((sum, n) => {
    const pos = getComputedStyle(n).position;
    return sum + (pos === 'absolute' || pos === 'fixed' ? 0 : blockHeight(n));
  }, 0);

  const usable = Math.max(160, pageH - padTop - padBottom - chromeHeight);
  // Kenarda kalan bir bloğu gereğinden erken yeni sayfaya taşımamak için küçük pay.
  const fitLimit = usable * 1.03;
  const { bodyShell: templateShell } = flowBlocksOf(template);

  const out: HTMLElement[] = [];
  let page: HTMLElement | null = null;
  let host: HTMLElement | null = null;
  let used = 0;
  let placed = 0;

  const startPage = () => {
    const shell = template.cloneNode(false) as HTMLElement;
    shell.style.display = '';
    shell.removeAttribute('id');
    headerNodes.forEach((n) => shell.appendChild(n.cloneNode(true)));
    if (templateShell) {
      const inner = templateShell.cloneNode(false) as HTMLElement;
      shell.appendChild(inner);
      host = inner;
    } else {
      host = shell;
    }
    page = shell;
    used = 0;
    placed = 0;
  };

  const endPage = () => {
    if (!page || placed === 0) return;
    footerNodes.forEach((n) => page?.appendChild(n.cloneNode(true)));
    out.push(page);
    page = null;
    host = null;
  };

  sections.forEach((section) => {
    const { blocks } = flowBlocksOf(section);
    if (blocks.length === 0) return;
    startPage();
    blocks.forEach((block) => {
      const h = blockHeight(block);
      if (placed > 0 && used + h > fitLimit) {
        endPage();
        startPage();
      }
      host?.appendChild(block);
      used += h;
      placed += 1;
    });
    endPage();
  });

  if (out.length === 0) return sections;
  wrapper.replaceChildren(...out);
  return out;
}

/**
 * Word (DOCX) önizleme adapter'ı — TEK SAYFA GÖRÜNÜMÜ + GERÇEK SAYFALAMA.
 *
 * docx-preview belgeyi sayfa `<section>`'larına böler. Bu adapter:
 *   • Render sonrası içeriği ÖLÇÜP gerçek sayfa kutularına yeniden paketler
 *     → sayfa sayısı belgedeki içerikle örtüşür (ör. 51 sayfa → 51 kutu),
 *     sayfalar bitişik/tek blok görünmez.
 *   • Ortada AYNI ANDA YALNIZCA BİR SAYFA gösterir.
 *   • Zoom (+/−, genişliğe sığdır, sayfaya sığdır) GERÇEKTEN çalışır; toolbar
 *     yüzdesi gerçek ölçeği yansıtır, sayfa sağ kenara taşmaz.
 *   • Konteyner boyutunu ResizeObserver ile izler → "sığdır" doğru hesaplanır.
 *   • Solda "Sayfalar (N)" rayı ile GERÇEK sayfa küçük görüntülerini gösterir;
 *     tıklayınca o sayfaya atlar. Sayfa sığıyorsa tekerlek sayfa geçirir.
 *
 * ÖNEMLİ: `className` alanı docx-preview'ın sayfa `<section>` sınıfıdır ve
 * varsayılan stil seçicisi buna bağlıdır (`section.docx`) — korunur.
 */
const DocxPreviewAdapter = forwardRef<PreviewViewerHandle, DocxPreviewAdapterProps>(
  function DocxPreviewAdapter({ getBytes, initialFit = 'page', onState, onDownload }, ref) {
    const viewportRef = useRef<HTMLDivElement | null>(null);
    const stageRef = useRef<HTMLDivElement | null>(null);
    const hostRef = useRef<HTMLDivElement | null>(null);
    const styleRef = useRef<HTMLDivElement | null>(null);
    const sectionsRef = useRef<HTMLElement[]>([]);
    const wheelLockRef = useRef<number | null>(null);

    const getBytesRef = useRef(getBytes);
    getBytesRef.current = getBytes;

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [retryKey, setRetryKey] = useState(0);
    const [pageCount, setPageCount] = useState(1);
    const [page, setPage] = useState(1);
    const [baseSize, setBaseSize] = useState<{ width: number; height: number }>(DEFAULT_PAGE);
    const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
    const [fitMode, setFitMode] = useState<FitMode>(initialFit);
    const [manualZoom, setManualZoom] = useState(1);
    const [thumbs, setThumbs] = useState<string[]>([]);

    const pageRef = useRef(page);
    pageRef.current = page;
    const pageCountRef = useRef(pageCount);
    pageCountRef.current = pageCount;
    const scaleRef = useRef(1);

    /** Yalnızca aktif sayfayı gösterir, diğerlerini gizler. */
    const applyActive = useCallback((active: number) => {
      const list = sectionsRef.current;
      for (let i = 0; i < list.length; i += 1) {
        list[i].style.display = i === active - 1 ? '' : 'none';
      }
    }, []);

    /* ---- Belgeyi render et + gerçek sayfalara yeniden paketle ---- */
    useEffect(() => {
      let cancelled = false;
      setLoading(true);
      setError(null);
      setThumbs([]);
      setPageCount(1);
      setPage(1);
      sectionsRef.current = [];

      const host = hostRef.current;
      const style = styleRef.current;
      if (host) host.innerHTML = '';
      if (style) style.innerHTML = '';

      const waitFonts = async () => {
        try {
          await (document as Document & { fonts?: { ready?: Promise<unknown> } }).fonts?.ready;
        } catch {
          /* fonts API yoksa sorun değil */
        }
      };

      (async () => {
        try {
          const bytes = await getBytesRef.current();
          if (cancelled || !hostRef.current) return;

          // Yazı tipleri yüklenmeden render edilirse sayfa yükseklikleri yanlış
          // ölçülür ve sayfa bölünmesi hatalı çıkar. Bu yüzden fonts.ready beklenir.
          await waitFonts();
          if (cancelled || !hostRef.current) return;

          const renderOptions = {
            className: 'docx',
            inWrapper: true,
            ignoreWidth: false,
            ignoreHeight: false,
            breakPages: true,
            // Word'ün "son render edilen sayfa sonu" işaretlerine SAYGI gösterilir.
            ignoreLastRenderedPageBreak: false,
            renderHeaders: true,
            renderFooters: true,
            renderFootnotes: true,
            renderEndnotes: true,
          };

          await renderAsync(bytes.slice(0), hostRef.current, styleRef.current ?? undefined, renderOptions);
          if (cancelled || !hostRef.current) return;

          // Belge kendi yazı tiplerini (@font-face) getiriyorsa ölçüm için yüklenmesini bekle.
          const hasEmbeddedFonts = !!styleRef.current?.textContent?.includes('@font-face');
          if (hasEmbeddedFonts) {
            await waitFonts();
            if (cancelled || !hostRef.current) return;
            hostRef.current.innerHTML = '';
            await renderAsync(
              bytes.slice(0),
              hostRef.current,
              styleRef.current ?? undefined,
              renderOptions,
            );
            if (cancelled || !hostRef.current) return;
          }

          // Sayfa bölünmesi bir sonraki frame'de tamamlanabilir; DOM oturunca topla.
          await new Promise<void>((r) => requestAnimationFrame(() => r()));
          if (cancelled || !hostRef.current) return;

          const hostEl = hostRef.current;
          let list = collectSections(hostEl);
          if (list.length === 0) list = [hostEl];

          // Ölçüm ve yeniden paketleme için ölçek %100 olmalı (aksi halde yükseklikler yanlış).
          const stage = stageRef.current;
          const prevZoom = stage?.style.zoom ?? '';
          if (stage) stage.style.zoom = '1';

          const wrapper = (list[0]?.parentElement as HTMLElement | null) ?? null;
          if (wrapper && wrapper.classList.contains('docx-wrapper') && needsRepagination(list)) {
            try {
              list = repaginate(wrapper, list);
            } catch {
              /* yeniden paketleme başarısız olursa docx-preview çıktısı korunur */
            }
          }

          const first = list[0] ?? hostEl;
          const width = first.offsetWidth || DEFAULT_PAGE.width;
          const height = first.offsetHeight || DEFAULT_PAGE.height;

          if (stage) stage.style.zoom = prevZoom || String(scaleRef.current);

          sectionsRef.current = list;
          applyActive(1);

          // Küçük görüntüler: her sayfa `.docx-wrapper` ile sarılır ki docx sayfa
          // stili (ölçü, beyaz kağıt, kenar boşlukları) küçük önizlemede de geçerli olsun.
          const thumbHtml = list.map((section) => {
            const clone = section.cloneNode(true) as HTMLElement;
            clone.style.display = '';
            clone.style.margin = '0';
            return `<div class="docx-wrapper">${clone.outerHTML}</div>`;
          });

          setBaseSize({ width, height });
          setPageCount(list.length);
          setThumbs(thumbHtml);
          setPage(1);
          setFitMode(initialFit);
          setManualZoom(1);
        } catch (e) {
          if (!cancelled) setError(friendlyPreviewError(e));
        } finally {
          if (!cancelled) setLoading(false);
        }
      })();

      return () => {
        cancelled = true;
      };
    }, [retryKey, applyActive, initialFit]);

    /* ---- Konteyner boyutu → fit hesabı (ResizeObserver) ---- */
    useLayoutEffect(() => {
      const el = viewportRef.current;
      if (!el) return undefined;
      const measure = () => setContainerSize({ width: el.clientWidth, height: el.clientHeight });
      measure();
      if (typeof ResizeObserver === 'undefined') return undefined;
      const ro = new ResizeObserver(measure);
      ro.observe(el);
      return () => ro.disconnect();
    }, []);

    /* ---- Etkin ölçek: fit modu aktifse konteynere göre, değilse manuel zoom ---- */
    const scale = useMemo(() => {
      if (containerSize.width === 0) return clampZoom(manualZoom);
      const availW = Math.max(80, containerSize.width - VIEW_PADDING);
      const availH = Math.max(80, containerSize.height - VIEW_PADDING);
      if (fitMode === 'width') return clampZoom(Math.min(1, availW / baseSize.width));
      if (fitMode === 'page') {
        return clampZoom(Math.min(availW / baseSize.width, availH / baseSize.height));
      }
      return clampZoom(manualZoom);
    }, [containerSize, baseSize, fitMode, manualZoom]);

    scaleRef.current = scale;

    /* ---- Zoom'u ölçekle (ölçüm sırasında daima %100'de tutulur) ---- */
    useEffect(() => {
      const stage = stageRef.current;
      if (!stage) return;
      stage.style.zoom = loading || error ? '1' : String(scale);
    }, [scale, loading, error]);

    /* ---- Aktif sayfayı uygula + kaydırmayı başa al ---- */
    useEffect(() => {
      applyActive(page);
      const vp = viewportRef.current;
      if (vp) vp.scrollTo({ top: 0, left: 0 });
    }, [page, applyActive]);

    /* ---- Sayfa değiştir ---- */
    const goTo = useCallback((n: number) => {
      setPage((prev) => {
        const next = Math.max(1, Math.min(Math.round(n), pageCountRef.current || 1));
        return next === prev ? prev : next;
      });
    }, []);

    /* ---- Tekerlek: sayfa yetiyorsa yukarı/aşağı sayfa geç; sığmıyorsa doğal kaydır ---- */
    const handleWheel = useCallback(
      (e: ReactWheelEvent<HTMLDivElement>) => {
        const vp = viewportRef.current;
        if (!vp) return;
        const overflowing =
          vp.scrollHeight > vp.clientHeight + 4 || vp.scrollWidth > vp.clientWidth + 4;
        if (overflowing) return;
        if (e.deltaY === 0) return;
        if (wheelLockRef.current != null) return;
        wheelLockRef.current = window.setTimeout(() => {
          wheelLockRef.current = null;
        }, WHEEL_LOCK_MS);
        if (e.deltaY > 0) goTo(pageRef.current + 1);
        else goTo(pageRef.current - 1);
      },
      [goTo],
    );

    useEffect(
      () => () => {
        if (wheelLockRef.current != null) window.clearTimeout(wheelLockRef.current);
      },
      [],
    );

    /* ---- Durum yayını (toolbar tarafından tüketilir) ---- */
    useEffect(() => {
      if (loading || error) return;
      onState?.({ page, count: Math.max(1, pageCount), zoom: scale, rotation: 0 });
    }, [page, pageCount, scale, loading, error, onState]);

    useImperativeHandle(
      ref,
      () => ({
        next: () => goTo(pageRef.current + 1),
        prev: () => goTo(pageRef.current - 1),
        goTo: (n: number) => goTo(n),
        zoomIn: () => {
          setFitMode('none');
          setManualZoom(clampZoom(scaleRef.current * ZOOM_STEP));
        },
        zoomOut: () => {
          setFitMode('none');
          setManualZoom(clampZoom(scaleRef.current / ZOOM_STEP));
        },
        fitPage: () => setFitMode('page'),
        fitWidth: () => setFitMode('width'),
        rotate: () => {},
      }),
      [goTo],
    );

    if (error) {
      return (
        <PreviewErrorView
          title="Belge önizlenemedi"
          message={error}
          onRetry={() => setRetryKey((k) => k + 1)}
          onDownload={onDownload}
        />
      );
    }

    const ratio = THUMB_WIDTH / (baseSize.width || DEFAULT_PAGE.width);
    const thumbHeight = Math.max(
      24,
      Math.round((baseSize.height || DEFAULT_PAGE.height) * ratio),
    );
    const showRail = !loading && thumbs.length > 1;

    return (
      <div className="flex-1 min-h-0 flex">
        {/* SOL: Sayfalar rayı */}
        {showRail && (
          <aside className="hidden md:flex w-[128px] flex-shrink-0 flex-col border-r border-background-300/60 dark:border-background-400/30 bg-background-100 dark:bg-background-200/40 overflow-hidden">
            <div className="flex-shrink-0 px-2.5 py-2 text-[11px] font-semibold uppercase tracking-wide text-foreground-500">
              Sayfalar ({pageCount})
            </div>
            <div className="flex-1 overflow-y-auto px-2 pb-3 flex flex-col gap-2 isg-scroll-pane">
              {thumbs.map((html, index) => {
                const active = page === index + 1;
                return (
                  <button
                    key={index}
                    type="button"
                    onClick={() => goTo(index + 1)}
                    aria-label={`Sayfa ${index + 1}`}
                    aria-current={active}
                    className="flex flex-col items-center gap-1 cursor-pointer"
                  >
                    <span
                      className={`docx-thumb block w-full overflow-hidden rounded-md ${
                        active
                          ? 'ring-2 ring-primary-500'
                          : 'ring-1 ring-background-300/70 hover:ring-primary-300'
                      }`}
                      style={{ height: thumbHeight }}
                    >
                      <span
                        className="docx-thumb-scale block"
                        style={{
                          width: baseSize.width,
                          height: baseSize.height,
                          transform: `scale(${ratio})`,
                        }}
                        // docx-preview'ın ürettiği güvenli sayfa HTML'i (script içermez).
                        dangerouslySetInnerHTML={{ __html: sanitizeHtml(html, 'preview') }}
                      />
                    </span>
                    <span
                      className={`text-[11px] tabular-nums ${
                        active ? 'text-primary-600 font-semibold' : 'text-foreground-500'
                      }`}
                    >
                      {index + 1}
                    </span>
                  </button>
                );
              })}
            </div>
          </aside>
        )}

        {/* ORTA: yalnızca aktif sayfa (ortalanmış, ölçeklenmiş) */}
        <div
          ref={viewportRef}
          tabIndex={0}
          onWheel={handleWheel}
          onKeyDown={(e) => {
            if (e.key === 'ArrowRight' || e.key === 'PageDown') {
              e.preventDefault();
              goTo(pageRef.current + 1);
            } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
              e.preventDefault();
              goTo(pageRef.current - 1);
            }
          }}
          className="relative flex-1 min-h-0 overflow-auto bg-background-200/60 dark:bg-background-300/25 outline-none isg-scroll-pane"
        >
          <div className="flex min-h-full w-full p-4 md:p-6">
            <div ref={stageRef} className="docx-paged m-auto">
              <div ref={styleRef} className="docx-preview-styles" />
              <div ref={hostRef} className="docx-preview-canvas" />
            </div>
          </div>
          {loading && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-background-200/60 dark:bg-background-300/25">
              <PreviewLoadingView text="Belge içeriği hazırlanıyor…" />
            </div>
          )}
        </div>
      </div>
    );
  },
);

export default DocxPreviewAdapter;