import { forwardRef, useCallback, useEffect, useImperativeHandle, useState } from 'react';
import type { PreviewViewerHandle, PreviewViewerState } from '@/components/feature/preview/types';

const MIN_ZOOM = 0.3;
const MAX_ZOOM = 5;
const ZOOM_STEP = 1.2;

interface ImageViewerAdapterProps {
  src: string;
  alt: string;
  onState?: (s: PreviewViewerState) => void;
}

/**
 * Görsel (JPG / JPEG / PNG / WEBP) adapter'ı — merkezi motora bağlanır.
 * Zoom / sığdırma gerçek çalışır; sayfalama tek sayfa olduğundan pasiftir.
 */
const ImageViewerAdapter = forwardRef<PreviewViewerHandle, ImageViewerAdapterProps>(
  function ImageViewerAdapter({ src, alt, onState }, ref) {
    const [zoom, setZoom] = useState(1);

    useEffect(() => {
      onState?.({ page: 1, count: 1, zoom, rotation: 0 });
    }, [zoom, onState]);

    useEffect(() => {
      setZoom(1);
    }, [src]);

    const clamp = useCallback((z: number) => Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Number(z.toFixed(3)))), []);

    useImperativeHandle(
      ref,
      () => ({
        next: () => {},
        prev: () => {},
        goTo: () => {},
        zoomIn: () => setZoom((z) => clamp(z * ZOOM_STEP)),
        zoomOut: () => setZoom((z) => clamp(z / ZOOM_STEP)),
        fitPage: () => setZoom(1),
        fitWidth: () => setZoom(1),
        rotate: () => {},
      }),
      [clamp],
    );

    return (
      <div className="flex-1 min-h-0 overflow-auto bg-background-200/60 dark:bg-background-300/25 flex items-start justify-center p-4 isg-scroll-pane">
        <img
          src={src}
          alt={alt}
          className="max-w-full h-auto origin-top rounded-md bg-white dark:bg-background-100 shadow-sm"
          style={{ transform: `scale(${zoom})` }}
          draggable={false}
        />
      </div>
    );
  },
);

export default ImageViewerAdapter;