import { forwardRef, useCallback, useEffect, useImperativeHandle, useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { friendlyPreviewError } from '@/components/feature/preview/types';
import Icon from '@/components/ui/Icon';
import { sanitizeHtml } from '@/lib/sanitizeHtml';
import { readWorkbookSafe } from '@/lib/spreadsheet/readWorkbook';
import type { PreviewViewerHandle, PreviewViewerState } from '@/components/feature/preview/types';
import { PreviewErrorView, PreviewLoadingView } from '@/components/feature/preview/components/PreviewStateViews';

const MIN_ZOOM = 0.3;
const MAX_ZOOM = 3;
const ZOOM_STEP = 1.2;

interface SheetHtml {
  name: string;
  html: string;
}

interface XlsxPreviewAdapterProps {
  getBytes: () => Promise<ArrayBuffer>;
  onState?: (s: PreviewViewerState) => void;
  onDownload?: () => void;
}

/**
 * Excel (XLSX / XLS / CSV) önizleme adapter'ı — mevcut çalışan SheetJS altyapısı
 * merkezi motora bağlanır. Her sayfa gerçek hücre değerleriyle tabloya dönüştürülür,
 * sekmelerle gezilir. Zoom gerçek CSS ölçeklemedir.
 */
const XlsxPreviewAdapter = forwardRef<PreviewViewerHandle, XlsxPreviewAdapterProps>(
  function XlsxPreviewAdapter({ getBytes, onState, onDownload }, ref) {
    const [sheets, setSheets] = useState<SheetHtml[]>([]);
    const [active, setActive] = useState(0);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [retryKey, setRetryKey] = useState(0);
    const [zoom, setZoom] = useState(1);

    const getBytesRef = useRef(getBytes);
    getBytesRef.current = getBytes;

    useEffect(() => {
      let cancelled = false;
      setLoading(true);
      setError(null);
      (async () => {
        try {
          const bytes = await getBytesRef.current();
          const wb = readWorkbookSafe(bytes.slice(0));
          const parsed: SheetHtml[] = wb.SheetNames.map((name) => ({
            name,
            html: XLSX.utils.sheet_to_html(wb.Sheets[name], {}),
          }));
          if (cancelled) return;
          setSheets(parsed);
          setActive(0);
        } catch (e) {
          if (!cancelled) setError(friendlyPreviewError(e));
        } finally {
          if (!cancelled) setLoading(false);
        }
      })();
      return () => {
        cancelled = true;
      };
    }, [retryKey]);

    useEffect(() => {
      onState?.({ page: 1, count: 1, zoom, rotation: 0 });
    }, [zoom, onState]);

    const clamp = useCallback((z: number) => Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Number(z.toFixed(3)))), []);

    useImperativeHandle(
      ref,
      () => ({
        next: () => {},
        prev: () => {},
        goTo: () => {},
        zoomIn: () => setZoom((z) => clamp(z * ZOOM_STEP)),
        zoomOut: () => setZoom((z) => clamp(z / ZOOM_STEP)),
        fitPage: () => setZoom(1),
        fitWidth: () => setZoom(1),
        rotate: () => {},
      }),
      [clamp],
    );

    const current = useMemo(() => sheets[active] ?? null, [sheets, active]);

    if (error) {
      return (
        <PreviewErrorView
          title="Belge önizlenemedi"
          message={error}
          onRetry={() => setRetryKey((k) => k + 1)}
          onDownload={onDownload}
        />
      );
    }

    if (loading) return <PreviewLoadingView text="Tablo içeriği hazırlanıyor…" />;

    return (
      <div className="flex-1 min-h-0 overflow-auto bg-background-200/60 dark:bg-background-300/25 p-3 isg-scroll-pane">
        <div className="flex flex-col gap-2">
          {sheets.length > 1 && (
            <div className="flex items-center gap-1.5 flex-wrap">
              {sheets.map((s, i) => (
                <button
                  key={s.name}
                  type="button"
                  onClick={() => setActive(i)}
                  className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors cursor-pointer whitespace-nowrap border ${
                    active === i
                      ? 'bg-primary-500 border-primary-500 text-inverse'
                      : 'bg-background-100 border-background-200/80 text-foreground-600 hover:bg-background-200 dark:bg-background-200 dark:border-background-400/30'
                  }`}
                >
                  <Icon name="excel" size="xs" /> {s.name}
                </button>
              ))}
            </div>
          )}
          <div
            className="xlsx-preview-body overflow-auto rounded-md isg-paper p-3 border border-background-200 origin-top"
            style={{ transform: `scale(${zoom})` }}
            // SheetJS'in ürettiği güvenli tablo HTML'i (script içermez).
            dangerouslySetInnerHTML={{ __html: sanitizeHtml(current?.html ?? '', 'preview') }}
          />
        </div>
      </div>
    );
  },
);

export default XlsxPreviewAdapter;