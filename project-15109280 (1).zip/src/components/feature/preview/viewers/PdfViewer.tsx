import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { WheelEvent as ReactWheelEvent } from 'react';
import type { PDFDocumentProxy } from 'pdfjs-dist';
import {
  getPdfPageSize,
  renderPdfPage,
  renderThumbnail,
  RENDER_PRIORITY,
  type PdfRenderHandle,
} from '@/components/feature/preview/pdf/pdfEngine';
import { THUMB_WIDTH } from '@/components/feature/preview/components/ThumbnailRail';
import { friendlyPreviewError } from '@/components/feature/preview/types';
import type { PreviewViewerHandle, PreviewViewerState } from '@/components/feature/preview/types';

const MIN_ZOOM = 0.25;
const MAX_ZOOM = 5;
const ZOOM_STEP = 1.2;
const VIEW_PADDING = 48;
const WHEEL_LOCK_MS = 320;

type FitMode = 'none' | 'width' | 'page';

interface PdfViewerProps {
  doc: PDFDocumentProxy;
  cacheKey: string;
  initialPage?: number;
  /** İlk açılıştaki ölçek modu ('page' = tam sayfa, 'width' = okunabilir genişliğe sığdır). */
  initialFit?: FitMode;
  onState?: (s: PreviewViewerState) => void;
  /** Seçili sayfaları vurgulamak için (galeri görünümü yok; opsiyonel bilgi). */
  onPageRenderError?: (message: string) => void;
}

function clampZoom(z: number): number {
  return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, Number(z.toFixed(3))));
}

/**
 * GERÇEK PDF görüntüleyici — tek merkezi motorun PDF çekirdeği.
 *
 * • Yalnızca AKTİF sayfa render edilir (108 / 600+ sayfa DOM'a basılmaz).
 * • Sayfa/zoom değişiminde önceki render task İPTAL edilir (RenderTask.cancel).
 * • Zoom / "genişliğe sığdır" / "sayfaya sığdır" / döndürme gerçek çalışır.
 * • Render hatası tüm görüntüleyiciyi kilitlemez; o sayfa için "Tekrar Dene" gösterilir.
 */
const PdfViewer = forwardRef<PreviewViewerHandle, PdfViewerProps>(function PdfViewer(
  { doc, cacheKey, initialPage = 1, initialFit = 'page', onState, onPageRenderError },
  ref,
) {
  const [pageCount, setPageCount] = useState(doc.numPages || 1);
  const [page, setPage] = useState(() => Math.max(1, Math.min(initialPage, doc.numPages || 1)));
  const [manualZoom, setManualZoom] = useState(1);
  const [fitMode, setFitMode] = useState<FitMode>(initialFit);
  const [rotations, setRotations] = useState<Record<number, number>>({});
  const [containerSize, setContainerSize] = useState({ width: 0, height: 0 });
  const [baseSize, setBaseSize] = useState<{ width: number; height: number } | null>(null);
  const [renderError, setRenderError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const outerRef = useRef<HTMLDivElement | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const renderHandleRef = useRef<PdfRenderHandle | null>(null);
  const pageRef = useRef(page);
  pageRef.current = page;
  const wheelLockRef = useRef<number | null>(null);

  const rotation = rotations[page] ?? 0;
  const rotationRef = useRef(rotation);
  rotationRef.current = rotation;

  // Doküman değişince sayfa sayısını ve başlangıç sayfasını sıfırla.
  useEffect(() => {
    setPageCount(doc.numPages || 1);
    setPage((p) => Math.max(1, Math.min(p, doc.numPages || 1)));
  }, [doc]);

  // Aktif sayfanın taban boyutunu (rotation ile) ölç.
  useEffect(() => {
    let cancelled = false;
    setRenderError(null);
    getPdfPageSize(doc, page, rotation)
      .then((size) => {
        if (!cancelled) setBaseSize(size);
      })
      .catch(() => {
        if (!cancelled) setBaseSize(null);
      });
    return () => {
      cancelled = true;
    };
  }, [doc, page, rotation]);

  // Konteyner boyutu (fit hesabı için).
  // ÖNEMLİ: Sabit, kaydırma çubuğu OLMAYAN dış kabı ölçüyoruz. Kaydırılabilir iç
  // kabı ölçmek; canvas büyüyünce görünen scrollbar'ın ölçümü değiştirmesiyle
  // "fit → büyü → scrollbar → küçül → ..." döngüsü (zoom kendi kendine büyüyor)
  // yaratıyordu. Dış kap hiç scrollbar almadığından ölçüm sabit ve kararlıdır.
  useLayoutEffect(() => {
    const el = outerRef.current;
    if (!el) return undefined;
    const measure = () => setContainerSize({ width: el.clientWidth, height: el.clientHeight });
    measure();
    if (typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  // Etkin ölçek: fit modu aktifse konteynere göre, değilse manuel zoom.
  const scale = useMemo(() => {
    if (!baseSize || containerSize.width === 0) return clampZoom(manualZoom);
    const availW = Math.max(80, containerSize.width - VIEW_PADDING);
    const availH = Math.max(80, containerSize.height - VIEW_PADDING);
    if (fitMode === 'width') return clampZoom(Math.min(1, availW / baseSize.width));
    if (fitMode === 'page') return clampZoom(Math.min(availW / baseSize.width, availH / baseSize.height));
    return clampZoom(manualZoom);
  }, [baseSize, containerSize, fitMode, manualZoom]);

  const scaleRef = useRef(scale);
  scaleRef.current = scale;

  // Asıl render: aktif sayfa. Değişimde önceki iş iptal edilir.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    setRenderError(null);

    const handle = renderPdfPage({ doc, pageNumber: page, scale, rotation, canvas });
    renderHandleRef.current = handle;

    handle.promise.catch((e) => {
      if ((e as Error)?.name === 'AbortError') return;
      const msg = friendlyPreviewError(e);
      setRenderError(msg);
      onPageRenderError?.(msg);
    });

    return () => {
      handle.cancel();
    };
  }, [doc, page, scale, rotation, reloadKey, onPageRenderError]);

  // Yakın sayfaları DÜŞÜK ÖNCELİKLE ön-yükle (thumbnail önbelleğine) — rail ve
  // sayfa geçişi ışıldar. Ray ile AYNI genişlik kullanılır (aksi hâlde cache
  // anahtarı uyuşmaz, boşa render olur). Sayfa değişince ÖNCEKİ ön-yükleme İPTAL
  // edilir → hızlı gezinmede birikip CPU'yu boğmaz. Aktif sayfa render'ı merkezi
  // kuyrukta her zaman bunlardan daha yüksek önceliklidir.
  useEffect(() => {
    const controller = new AbortController();
    const neighbors = [page - 1, page + 1].filter((p) => p >= 1 && p <= pageCount);
    neighbors.forEach((p) => {
      renderThumbnail(
        doc,
        cacheKey,
        p,
        rotations[p] ?? 0,
        THUMB_WIDTH,
        controller.signal,
        RENDER_PRIORITY.NEAR_PAGE,
      ).catch(() => {});
    });
    return () => controller.abort();
  }, [doc, cacheKey, page, pageCount, rotations]);

  useEffect(() => {
    onState?.({ page, count: pageCount, zoom: scale, rotation });
  }, [page, pageCount, scale, rotation, onState]);

  const goToImpl = useCallback(
    (n: number) => {
      setPage((prev) => {
        const next = Math.max(1, Math.min(Math.round(n), pageCount || 1));
        return next === prev ? prev : next;
      });
    },
    [pageCount],
  );

  /* ---- Tekerlek: sayfa ekrana tam sığıyorsa (taşma yok) aşağı/yukarı sayfa
     geçirir; zoom yapılmışsa belge doğal olarak kaydırılır. Kullanıcının
     "aşağı kaydırıyorum ama sonraki sayfaya geçmiyor" sorununu çözer. ---- */
  const handleWheel = useCallback(
    (e: ReactWheelEvent<HTMLDivElement>) => {
      const el = scrollRef.current;
      if (!el) return;
      const overflowing = el.scrollHeight > el.clientHeight + 4 || el.scrollWidth > el.clientWidth + 4;
      if (overflowing || e.deltaY === 0) return;
      if (pageCount <= 1) return;
      if (wheelLockRef.current != null) return;
      wheelLockRef.current = window.setTimeout(() => {
        wheelLockRef.current = null;
      }, WHEEL_LOCK_MS);
      if (e.deltaY > 0) goToImpl(pageRef.current + 1);
      else goToImpl(pageRef.current - 1);
    },
    [goToImpl, pageCount],
  );

  useEffect(
    () => () => {
      if (wheelLockRef.current != null) window.clearTimeout(wheelLockRef.current);
    },
    [],
  );

  useImperativeHandle(
    ref,
    () => ({
      next: () => goToImpl(pageRef.current + 1),
      prev: () => goToImpl(pageRef.current - 1),
      goTo: (n: number) => goToImpl(n),
      zoomIn: () => {
        setFitMode('none');
        setManualZoom(clampZoom(scaleRef.current * ZOOM_STEP));
      },
      zoomOut: () => {
        setFitMode('none');
        setManualZoom(clampZoom(scaleRef.current / ZOOM_STEP));
      },
      fitPage: () => setFitMode('page'),
      fitWidth: () => setFitMode('width'),
      setZoom: (z: number) => {
        setFitMode('none');
        setManualZoom(clampZoom(z));
      },
      rotate: () => {
        setRotations((r) => {
          const current = r[pageRef.current] ?? 0;
          return { ...r, [pageRef.current]: (current + 90) % 360 };
        });
      },
    }),
    [goToImpl],
  );

  const handleRetry = useCallback(() => {
    setRenderError(null);
    setReloadKey((k) => k + 1);
  }, []);

  return (
    <div ref={outerRef} className="relative flex-1 h-full min-h-0 overflow-hidden">
      <div
        ref={scrollRef}
        tabIndex={0}
        onWheel={handleWheel}
        onKeyDown={(e) => {
          if (e.key === 'ArrowRight' || e.key === 'PageDown') {
            e.preventDefault();
            goToImpl(pageRef.current + 1);
          } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
            e.preventDefault();
            goToImpl(pageRef.current - 1);
          }
        }}
        className="h-full w-full overflow-auto bg-background-200/60 dark:bg-background-300/25 outline-none isg-scroll-pane"
      >
        {renderError ? (
          <div className="flex h-full flex-col items-center justify-center gap-3 px-4 text-center">
            <div className="w-12 h-12 rounded-full bg-background-200 dark:bg-background-300/40 flex items-center justify-center">
              <i className="ri-error-warning-line text-foreground-500 text-2xl" />
            </div>
            <div className="max-w-sm">
              <p className="text-sm font-semibold text-foreground-800">
                {page}. sayfa görüntülenemedi
              </p>
              <p className="text-xs text-foreground-500 mt-1">{renderError}</p>
            </div>
            <button
              type="button"
              onClick={handleRetry}
              className="isg-btn isg-btn-secondary isg-btn-sm"
            >
              <i className="ri-refresh-line" /> Tekrar Dene
            </button>
          </div>
        ) : (
          <div className="flex min-h-full w-full items-start justify-center p-4 md:p-6">
            <div className="isg-paper shadow-sm border border-background-300/50 dark:border-background-400/40">
              <canvas ref={canvasRef} className="block" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
});

export default PdfViewer;