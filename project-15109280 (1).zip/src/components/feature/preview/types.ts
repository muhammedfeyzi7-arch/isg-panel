/**
 * MERKEZİ DOCUMENT PREVIEW ENGINE — Ortak tipler ve sözleşme (contract).
 *
 * Bu motor İSGDenetim'de PDF / görsel / DOCX / XLSX doküman önizlemesinin TEK
 * kaynağıdır. Farklı modüller (Personel Dosyaları, Firma Evrakları, Risk
 * Değerlendirmesi, Acil Durum, İSG Kurulu, Toplu Evrak) kendi viewer'larını
 * yazmak yerine bu motoru `PreviewDocumentSource` sözleşmesiyle besler.
 *
 * Güvenlik: Motor dosya içeriğini DEĞİŞTİRMEZ, yalnızca görüntü durumu üretir.
 * Baytlar her zaman ÇAĞIRAN tarafından yetkilendirilmiş bir fonksiyonla getirilir.
 */

import { DOSYA_TUR_IKON, ICON_REGISTRY } from '@/lib/icons/iconRegistry';

export type PreviewKind = 'pdf' | 'image' | 'docx' | 'xlsx' | 'pptx' | 'unsupported';

/**
 * Belge bilgi panelinde gösterilecek İSTEĞE BAĞLI metadata.
 * Yalnızca gerçekten var olan alanlar doldurulur; boş alan için SAHTE veri
 * ÜRETİLMEZ — panel yalnızca dolu alanları gösterir.
 */
export interface PreviewDocumentMeta {
  belgeAdi?: string;
  dosyaTuru?: string;
  dosyaBoyutu?: string;
  klasor?: string;
  belgeTarihi?: string;
  yuklemeTarihi?: string;
  yukleyen?: string;
  durum?: string;
  revizyon?: string;
  gecerlilik?: string;
  aciklama?: string;
  etiketler?: string[];
}

/**
 * Çağıran modülün motora verdiği doküman tanımı.
 * `getBytes` yetki kontrolünden (scope / RLS / IDOR) geçmiş ham baytları döndürmelidir.
 */
export interface PreviewDocumentSource {
  /** Cache anahtarı — aynı doküman için sabit olmalı (ör. `${evrakId}:${revisionNo}`). */
  cacheKey: string;
  /** Görünen dosya adı (indirme ve tür tespiti için kullanılır). */
  fileName: string;
  /** MIME türü (null olabilir; tür dosya adından da tespit edilir). */
  mimeType: string | null;
  /** Yetkilendirilmiş ham baytlar. Motor bu fonksiyon dışında veriye erişmez. */
  getBytes: () => Promise<ArrayBuffer>;
  /**
   * Opsiyonel: doğrudan gösterilebilir URL (yalnızca görsel türü için).
   * Verilirse motor bayt çekmek yerine bu URL'i doğrudan render eder — böylece
   * CORS kısıtlı uzak görseller de aynı merkezi modalda güvenle gösterilir.
   */
  url?: string;
  /** Opsiyonel: dosya boyutu (bilgi amaçlı). */
  fileSize?: number | null;
  /** Opsiyonel: belge meta verileri (isteğe bağlı). */
  meta?: PreviewDocumentMeta;
}

/** Viewer bileşenlerinin dışarıya açtığı zorunlu kontrol arayüzü. */
export interface PreviewViewerHandle {
  next: () => void;
  prev: () => void;
  goTo: (page: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  fitPage: () => void;
  fitWidth: () => void;
  rotate: () => void;
  /** Belirli bir ölçeğe (%100 = 1) ayarlar. Desteklemeyen viewer'lar için opsiyoneldir. */
  setZoom?: (zoom: number) => void;
}

/** Viewer'ın yayınladığı görüntü durumu (toolbar + thumbnail rayı bunu tüketir). */
export interface PreviewViewerState {
  page: number;
  count: number;
  /** Etkin ölçek (1 = %100). */
  zoom: number;
  /** Aktif sayfanın döndürme açısı. */
  rotation: number;
}

export const PREVIEW_DEFAULT_STATE: PreviewViewerState = {
  page: 1,
  count: 1,
  zoom: 1,
  rotation: 0,
};

const IMAGE_EXT = ['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'svg'];
const DOCX_EXT = ['docx', 'doc'];
const XLSX_EXT = ['xlsx', 'xls', 'csv'];
const PPTX_EXT = ['pptx', 'ppt'];

function extOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i >= 0 ? name.slice(i + 1).toLowerCase() : '';
}

/**
 * MIME + uzantıdan önizleme türünü tespit eder. MIME yanlış/boş olsa bile dosya
 * adı fallback'i çalışır; hiçbiri uymazsa 'unsupported'.
 */
export function detectPreviewKind(mimeType: string | null, fileName: string): PreviewKind {
  const mime = (mimeType ?? '').toLowerCase();
  const ext = extOf(fileName);

  if (mime === 'application/pdf' || ext === 'pdf') return 'pdf';
  if (mime.startsWith('image/') || IMAGE_EXT.includes(ext)) return 'image';
  if (
    mime.includes('wordprocessingml') ||
    mime === 'application/msword' ||
    DOCX_EXT.includes(ext)
  ) {
    return 'docx';
  }
  if (
    mime.includes('spreadsheet') ||
    mime.includes('ms-excel') ||
    mime.includes('csv') ||
    XLSX_EXT.includes(ext)
  ) {
    return 'xlsx';
  }
  if (PPTX_EXT.includes(ext)) {
    return 'pptx';
  }
  return 'unsupported';
}

/** Türü kullanıcıya gösterilecek okunur etikete çevirir. */
export function previewKindLabel(kind: PreviewKind): string {
  switch (kind) {
    case 'pdf':
      return 'PDF Belgesi';
    case 'image':
      return 'Görsel';
    case 'docx':
      return 'Word Belgesi';
    case 'xlsx':
      return 'Excel Tablosu';
    case 'pptx':
      return 'PowerPoint Sunusu';
    default:
      return 'Belge';
  }
}

/** Dosya-formatı ikon sınıfı — MERKEZÎ ikon kaydından (tek kaynak).
 *  Formatı temsil eden dolgulu aile kullanılır (PDF kırmızı, Word mavi,
 *  Excel yeşil, PowerPoint turuncu); önizleme motoru ile evrak/mesajlaşma
 *  aynı ikon dilini paylaşır. */
export function previewKindIcon(kind: PreviewKind): string {
  const map: Record<PreviewKind, string> = {
    pdf: ICON_REGISTRY[DOSYA_TUR_IKON.pdf].className,
    image: ICON_REGISTRY[DOSYA_TUR_IKON.image].className,
    docx: ICON_REGISTRY[DOSYA_TUR_IKON.word].className,
    xlsx: ICON_REGISTRY[DOSYA_TUR_IKON.excel].className,
    pptx: ICON_REGISTRY[DOSYA_TUR_IKON.powerpoint].className,
    unsupported: ICON_REGISTRY.document.className,
  };
  return map[kind];
}

/** pdf.js / ağ hatalarını kullanıcıya anlaşılır Türkçe mesaja çevirir. */
export function friendlyPreviewError(error: unknown): string {
  const e = error as { name?: string; message?: string } | null;
  const name = e?.name ?? '';
  const msg = (e?.message ?? '').toLowerCase();

  if (name === 'PasswordException' || msg.includes('password')) {
    return 'Bu PDF şifre korumalı. Şifreli belgeler tarayıcıda görüntülenemez.';
  }
  if (name === 'InvalidPDFException' || msg.includes('invalid pdf') || msg.includes('bozuk')) {
    return 'Belge bozuk veya geçerli bir PDF değil.';
  }
  if (name === 'MissingPDFException' || msg.includes('missing')) {
    return 'Belge dosyası bulunamadı.';
  }
  if (msg.includes('network') || msg.includes('failed to fetch') || msg.includes('load failed')) {
    return 'Ağ bağlantısı kesildi. Belge içeriği indirilemedi.';
  }
  if (name === 'AbortError' || msg.includes('abort')) {
    return 'İşlem iptal edildi.';
  }
  return e?.message || 'Belge açılırken beklenmeyen bir hata oluştu.';
}