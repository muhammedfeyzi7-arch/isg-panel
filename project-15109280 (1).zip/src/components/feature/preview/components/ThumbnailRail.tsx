import { forwardRef, useCallback, useEffect, useRef, useState, type MouseEvent as ReactMouseEvent } from 'react';
import type { PDFDocumentProxy } from 'pdfjs-dist';
import { renderThumbnail, RENDER_PRIORITY } from '@/components/feature/preview/pdf/pdfEngine';

/**
 * THUMBNAIL + RAY GENİŞLİĞİ — TEK KAYNAK.
 *
 * Ray, thumbnail'den gereksiz yere GENİŞ OLMAZ: panel yalnızca thumbnail +
 * yatay iç boşluk kadar yer kaplar. Böylece belge görüntüleme alanına MAKSİMUM
 * alan kalır (sol panel ana içeriği daraltmaz). Ray kapsayıcısı bu değeri
 * doğrudan tüketir → thumbnail genişliği değişince panel de otomatik uyar.
 */
export const THUMB_WIDTH = 132;
/** Yatay iç boşluk (px-2 → 2 × 8px). */
export const THUMB_RAIL_WIDTH = THUMB_WIDTH + 16;
const ROW_GAP = 10;
const LABEL_HEIGHT = 22; // sayfa numarası satırı
const BUFFER_ROWS = 4; // viewport dışında ön-render edilecek satır
const DEFAULT_ASPECT = 1.414; // A4 portre (h/w) — ölçüm gelene kadar
const RENDER_TIMEOUT_MS = 20000; // güvenlik ağı: render asla sonsuza kadar "loading" kalmaz

export type SelectMode = 'single' | 'toggle' | 'range';

interface ThumbnailRailProps {
  doc: PDFDocumentProxy | null;
  cacheKey: string;
  pageCount: number;
  currentPage: number;
  rotation: number;
  onNavigate: (page: number) => void;
  selectable?: boolean;
  selectedPages: number[];
  onSelectPage?: (page: number, mode: SelectMode) => void;
  /** Dokunmatik cihaz: düz dokunuş çoklu seçim yapar (Ctrl/Shift olmadığı için). */
  touchMultiSelect?: boolean;
}

/**
 * Tek thumbnail hücresi — pencere (windowing) içinde mount edilince render edilir.
 */
function ThumbCell({
  doc,
  cacheKey,
  page,
  rotation,
  height,
  priority,
  active,
  selected,
  selectable,
  touchMultiSelect,
  onNavigate,
  onSelectPage,
}: {
  doc: PDFDocumentProxy | null;
  cacheKey: string;
  page: number;
  rotation: number;
  height: number;
  priority: number;
  active: boolean;
  selected: boolean;
  selectable: boolean;
  touchMultiSelect: boolean;
  onNavigate: (page: number) => void;
  onSelectPage: (page: number, mode: SelectMode) => void;
}) {
  const [url, setUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  const [retryKey, setRetryKey] = useState(0);

  // Öncelik ref üzerinden okunur: kaydırma sırasında öncelik değişse bile render
  // yeniden BAŞLATILMAZ (abort+restart churn'ü yok). Yalnızca kuyruk sırasını etkiler.
  const priorityRef = useRef(priority);
  priorityRef.current = priority;

  useEffect(() => {
    if (!doc) return undefined;
    const controller = new AbortController();
    let settled = false;
    setFailed(false);

    const timer = window.setTimeout(() => {
      if (settled) return;
      settled = true;
      controller.abort();
      setFailed(true);
    }, RENDER_TIMEOUT_MS);

    renderThumbnail(doc, cacheKey, page, rotation, THUMB_WIDTH, controller.signal, priorityRef.current)
      .then((dataUrl) => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        setUrl(dataUrl);
        setFailed(false);
      })
      .catch(() => {
        if (settled) return;
        settled = true;
        window.clearTimeout(timer);
        setFailed(true);
      });

    return () => {
      settled = true;
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [doc, cacheKey, page, rotation, retryKey]);

  const handleClick = (e: ReactMouseEvent<HTMLButtonElement>) => {
    onNavigate(page);
    if (!selectable || !onSelectPage) return;
    let mode: SelectMode = 'single';
    if (e.shiftKey) mode = 'range';
    else if (e.ctrlKey || e.metaKey) mode = 'toggle';
    else if (touchMultiSelect) mode = 'toggle';
    onSelectPage(page, mode);
  };

  return (
    <div className="flex flex-col items-center gap-1" style={{ minHeight: height + LABEL_HEIGHT }}>
      <button
        type="button"
        onClick={handleClick}
        className={`relative block w-full rounded-md overflow-hidden border-2 bg-white dark:bg-background-100 transition-colors cursor-pointer ${
          selected
            ? 'border-primary-500'
            : active
              ? 'border-primary-400'
              : 'border-background-300/70 hover:border-primary-300'
        }`}
        style={{ height }}
        aria-label={`Sayfa ${page}`}
        aria-pressed={selectable ? selected : undefined}
      >
        {url ? (
          <img
            src={url}
            alt={`Sayfa ${page}`}
            className="w-full h-full object-contain bg-white dark:bg-background-100"
            draggable={false}
          />
        ) : (
          <span className="absolute inset-0 flex items-center justify-center bg-background-200/70 dark:bg-background-300/40">
            {failed ? (
              <span
                role="button"
                tabIndex={0}
                title="Tekrar dene"
                aria-label={`${page}. sayfa önizlemesini tekrar dene`}
                onClick={(e) => {
                  e.stopPropagation();
                  setFailed(false);
                  setUrl(null);
                  setRetryKey((k) => k + 1);
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.stopPropagation();
                    setFailed(false);
                    setUrl(null);
                    setRetryKey((k) => k + 1);
                  }
                }}
                className="w-6 h-6 flex items-center justify-center rounded-full text-foreground-500 hover:text-primary-600 hover:bg-background-50/70 cursor-pointer"
              >
                <i className="ri-refresh-line text-sm" />
              </span>
            ) : (
              <span className="w-4 h-4 border-2 border-primary-400/70 border-t-transparent rounded-full animate-spin" />
            )}
          </span>
        )}

        {selectable && selected && (
          <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-primary-500 text-inverse flex items-center justify-center shadow">
            <i className="ri-check-line text-[10px]" />
          </span>
        )}
      </button>
      <span className={`text-xs tabular-nums ${active ? 'text-primary-600 font-semibold' : 'text-foreground-500'}`}>
        {page}
      </span>
    </div>
  );
}

/**
 * Sol sayfa thumbnail rayı — TEK KOLON (alt alta) + pencereleme (windowing).
 *
 * Küçük sayfa seçiciler yan yana değil ALT ALTA dizilir. Yüzlerce (600+) sayfada
 * bile DOM'a yalnızca viewport civarındaki hücreler basılır → bellek sabit kalır.
 * Aktif sayfa değişince ray o sayfaya yumuşakça kaydırılır; aşağı kaydırdıkça
 * sonraki sayfalar doğal akışla görünür.
 */
const ThumbnailRail = forwardRef<HTMLDivElement, ThumbnailRailProps>(function ThumbnailRail(
  {
    doc,
    cacheKey,
    pageCount,
    currentPage,
    rotation,
    onNavigate,
    selectable,
    selectedPages,
    onSelectPage,
    touchMultiSelect = false,
  },
  ref,
) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const rafRef = useRef<number | null>(null);
  const [scrollTop, setScrollTop] = useState(0);
  const [viewHeight, setViewHeight] = useState(0);
  const [aspect, setAspect] = useState(DEFAULT_ASPECT);

  useEffect(() => {
    if (!doc) return undefined;
    let cancelled = false;
    doc
      .getPage(1)
      .then((p) => {
        const vp = p.getViewport({ scale: 1 });
        if (!cancelled && vp.width > 0) setAspect(vp.height / vp.width);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [doc]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return undefined;
    const measure = () => setViewHeight(el.clientHeight);
    measure();
    if (typeof ResizeObserver === 'undefined') return undefined;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  useEffect(
    () => () => {
      if (rafRef.current != null) cancelAnimationFrame(rafRef.current);
    },
    [],
  );

  const handleScroll = useCallback(() => {
    if (rafRef.current != null) return;
    rafRef.current = requestAnimationFrame(() => {
      rafRef.current = null;
      if (containerRef.current) setScrollTop(containerRef.current.scrollTop);
    });
  }, []);

  const thumbHeight = Math.round(THUMB_WIDTH * aspect);
  const rowHeight = thumbHeight + LABEL_HEIGHT + ROW_GAP;
  const totalRows = Math.max(1, Math.max(0, pageCount));

  const effectiveView = Math.max(viewHeight, 1);
  const firstRow = Math.max(0, Math.floor(scrollTop / rowHeight) - BUFFER_ROWS);
  const lastRow = Math.min(
    totalRows - 1,
    Math.floor((scrollTop + effectiveView) / rowHeight) + BUFFER_ROWS,
  );

  const startPage = firstRow + 1;
  const endPage = Math.min(pageCount, lastRow + 1);
  const topPad = firstRow * rowHeight;
  const bottomPad = Math.max(0, (totalRows - 1 - lastRow) * rowHeight);

  // Gerçekte GÖRÜNÜR satırlar (ön-render tamponu HARİÇ) — thumbnail önceliği için:
  // görünür thumbnail'lar tampon thumbnail'lardan önce render edilir.
  const viewFirstRow = Math.max(0, Math.floor(scrollTop / rowHeight));
  const viewLastRow = Math.min(totalRows - 1, Math.floor((scrollTop + effectiveView) / rowHeight));

  const pages: number[] = [];
  for (let p = startPage; p <= endPage; p += 1) pages.push(p);

  // Aktif sayfa değişince rayı o sayfaya kaydır.
  useEffect(() => {
    const el = containerRef.current;
    if (!el || pageCount <= 1) return;
    const row = Math.max(0, currentPage - 1);
    const top = row * rowHeight;
    if (top < el.scrollTop || top + rowHeight > el.scrollTop + el.clientHeight) {
      el.scrollTo({ top: Math.max(0, top - el.clientHeight / 3), behavior: 'smooth' });
    }
  }, [currentPage, rowHeight, pageCount]);

  const selectedSet = new Set(selectedPages);

  return (
    <div
      ref={(node) => {
        containerRef.current = node;
        if (typeof ref === 'function') ref(node);
        else if (ref) (ref as { current: HTMLDivElement | null }).current = node;
      }}
      onScroll={handleScroll}
      className="h-full overflow-y-auto bg-background-100 dark:bg-background-200/40 border-r border-background-300/60 dark:border-background-400/30 isg-scroll-pane"
    >
      <div className="sticky top-0 z-10 bg-background-100 dark:bg-background-200/60 px-2.5 py-2 text-[11px] font-semibold uppercase tracking-wide text-foreground-500 border-b border-background-300/40 dark:border-background-400/20">
        Sayfalar ({pageCount})
      </div>
      <div className="px-2 py-2.5">
        <div style={{ height: topPad }} aria-hidden />
        <div className="flex flex-col gap-2.5">
          {pages.map((p) => {
            const row = p - 1;
            const inView = row >= viewFirstRow && row <= viewLastRow;
            const priority = p === currentPage
              ? RENDER_PRIORITY.ACTIVE_PAGE
              : inView
                ? RENDER_PRIORITY.VISIBLE_THUMB
                : RENDER_PRIORITY.BUFFER_THUMB;
            return (
              <ThumbCell
                key={`${p}-${rotation}`}
                doc={doc}
                cacheKey={cacheKey}
                page={p}
                rotation={rotation}
                height={thumbHeight}
                priority={priority}
                active={p === currentPage}
                selected={selectedSet.has(p)}
                selectable={!!selectable}
                touchMultiSelect={touchMultiSelect}
                onNavigate={onNavigate}
                onSelectPage={onSelectPage ?? (() => {})}
              />
            );
          })}
        </div>
        <div style={{ height: bottomPad }} aria-hidden />
      </div>
    </div>
  );
});

export default ThumbnailRail;