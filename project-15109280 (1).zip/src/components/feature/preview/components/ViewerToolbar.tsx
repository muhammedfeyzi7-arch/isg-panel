import { useEffect, useState } from 'react';

const TOOL_BTN =
  'inline-flex items-center justify-center w-8 h-8 rounded-md text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-default';

interface ViewerToolbarProps {
  title: string;
  page: number;
  pageCount: number;
  onGoTo: (page: number) => void;
  zoomPercent: number;
  onZoomIn: () => void;
  onZoomOut: () => void;
  onFitWidth: () => void;
  onFitPage: () => void;
  onRotate: () => void;
  isFullscreen: boolean;
  onToggleFullscreen: () => void;
  onToggleRail?: () => void;
  railOpen?: boolean;
  onDownload?: () => void;
  downloadBusy?: boolean;
  /** Sayfalama (sayfa no + ileri/geri) aktif mi? */
  canPage?: boolean;
  /** Zoom + sığdırma aktif mi? */
  canZoom?: boolean;
  /** Döndürme aktif mi? (yalnızca PDF) */
  canRotate?: boolean;
}

/**
 * Ortak görüntüleyici araç çubuğu — sayfa gezinme + zoom + sığdırma + döndürme +
 * tam ekran. Tüm viewer'lar (PDF/görsel/DOCX/XLSX) aynı çubuğu kullanır.
 * Referans ekran: [sayfa] / toplam · zoom − · % · + · sığdır · döndür · tam ekran.
 */
export default function ViewerToolbar({
  title,
  page,
  pageCount,
  onGoTo,
  zoomPercent,
  onZoomIn,
  onZoomOut,
  onFitWidth,
  onFitPage,
  onRotate,
  isFullscreen,
  onToggleFullscreen,
  onToggleRail,
  railOpen,
  onDownload,
  downloadBusy,
  canPage = true,
  canZoom = true,
  canRotate = true,
}: ViewerToolbarProps) {
  const [draft, setDraft] = useState(String(page));

  useEffect(() => {
    setDraft(String(page));
  }, [page]);

  const commit = () => {
    const n = parseInt(draft, 10);
    if (Number.isFinite(n)) onGoTo(n);
    else setDraft(String(page));
  };

  return (
    <div className="flex items-center gap-2 px-2 md:px-3 h-12 flex-shrink-0 border-b border-background-300/50 dark:border-background-400/30 bg-background-50 dark:bg-background-200/40">
      {/* Sol: ray aç/kapa (mobil) + başlık */}
      <div className="flex items-center gap-2 min-w-0 flex-1">
        {onToggleRail && (
          <button
            type="button"
            className={`${TOOL_BTN} md:hidden`}
            onClick={onToggleRail}
            aria-label="Sayfa panelini aç/kapat"
            title="Sayfalar"
            aria-pressed={railOpen}
          >
            <i className="ri-layout-left-line text-base" />
          </button>
        )}
        <span className="text-sm font-medium text-foreground-800 truncate hidden sm:block">{title}</span>
      </div>

      {/* Orta: gezinme + zoom + araçlar */}
      <div className="flex items-center gap-1 flex-shrink-0">
        <div className="flex items-center gap-1 rounded-md border border-background-300/70 dark:border-background-400/40 bg-background-50 dark:bg-background-100 px-1 py-0.5">
          <button
            type="button"
            className={`${TOOL_BTN} !w-6 !h-6`}
            onClick={() => onGoTo(page - 1)}
            disabled={!canPage || pageCount <= 1 || page <= 1}
            aria-label="Önceki sayfa"
            title="Önceki sayfa"
          >
            <i className="ri-arrow-left-s-line text-base" />
          </button>
          <input
            type="text"
            inputMode="numeric"
            value={draft}
            disabled={!canPage || pageCount <= 1}
            onChange={(e) => setDraft(e.target.value.replace(/[^0-9]/g, ''))}
            onBlur={commit}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                commit();
              }
            }}
            className="w-9 text-center text-xs tabular-nums bg-transparent text-foreground-800 outline-none disabled:opacity-60"
            aria-label="Sayfa numarası"
          />
          <span className="text-xs text-foreground-400 tabular-nums">/ {pageCount}</span>
          <button
            type="button"
            className={`${TOOL_BTN} !w-6 !h-6`}
            onClick={() => onGoTo(page + 1)}
            disabled={!canPage || pageCount <= 1 || page >= pageCount}
            aria-label="Sonraki sayfa"
            title="Sonraki sayfa"
          >
            <i className="ri-arrow-right-s-line text-base" />
          </button>
        </div>

        <button
          type="button"
          className={TOOL_BTN}
          onClick={onZoomOut}
          disabled={!canZoom}
          aria-label="Uzaklaştır"
          title="Uzaklaştır"
        >
          <i className="ri-subtract-line text-base" />
        </button>
        <span className="text-xs tabular-nums text-foreground-700 w-11 text-center">{zoomPercent}%</span>
        <button
          type="button"
          className={TOOL_BTN}
          onClick={onZoomIn}
          disabled={!canZoom}
          aria-label="Yakınlaştır"
          title="Yakınlaştır"
        >
          <i className="ri-add-line text-base" />
        </button>

        <span className="mx-0.5 h-4 w-px bg-background-300 dark:bg-background-400/40" />

        <button
          type="button"
          className={TOOL_BTN}
          onClick={onFitWidth}
          disabled={!canZoom}
          aria-label="Genişliğe sığdır"
          title="Genişliğe sığdır"
        >
          <i className="ri-arrow-right-line text-base" />
        </button>
        <button
          type="button"
          className={TOOL_BTN}
          onClick={onFitPage}
          disabled={!canZoom}
          aria-label="Sayfaya sığdır"
          title="Sayfaya sığdır"
        >
          <i className="ri-aspect-ratio-line text-base" />
        </button>
        {canRotate && (
          <button
            type="button"
            className={TOOL_BTN}
            onClick={onRotate}
            aria-label="Döndür"
            title="Döndür"
          >
            <i className="ri-refresh-line text-base" />
          </button>
        )}
        <button
          type="button"
          className={TOOL_BTN}
          onClick={onToggleFullscreen}
          aria-label={isFullscreen ? 'Tam ekrandan çık' : 'Tam ekran'}
          title={isFullscreen ? 'Tam ekrandan çık' : 'Tam ekran'}
        >
          <i className={`${isFullscreen ? 'ri-fullscreen-exit-line' : 'ri-fullscreen-line'} text-base`} />
        </button>

        {onDownload && (
          <>
            <span className="mx-0.5 h-4 w-px bg-background-300 dark:bg-background-400/40" />
            <button
              type="button"
              className={TOOL_BTN}
              onClick={onDownload}
              disabled={downloadBusy}
              aria-label="İndir"
              title="İndir"
            >
              <i className={`ri-download-2-line text-base ${downloadBusy ? 'animate-pulse' : ''}`} />
            </button>
          </>
        )}
      </div>

      <div className="flex-1" />
    </div>
  );
}