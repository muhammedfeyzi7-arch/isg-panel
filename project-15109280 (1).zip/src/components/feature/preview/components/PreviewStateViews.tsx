import Button from '@/components/ui/Button';
import { previewKindIcon } from '@/components/feature/preview/types';
import type { PreviewKind } from '@/components/feature/preview/types';

interface LoadingViewProps {
  text?: string;
}

export function PreviewLoadingView({ text = 'Belge yükleniyor…' }: LoadingViewProps) {
  return (
    <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-3">
      <span className="w-9 h-9 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" />
      <p className="text-sm text-foreground-600">{text}</p>
    </div>
  );
}

interface ErrorViewProps {
  title?: string;
  message: string;
  onRetry?: () => void;
  onDownload?: () => void;
}

export function PreviewErrorView({ title = 'Belge açılamadı', message, onRetry, onDownload }: ErrorViewProps) {
  return (
    <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-3 px-4 text-center">
      <div className="w-12 h-12 rounded-full bg-background-200 dark:bg-background-300/40 flex items-center justify-center">
        <i className="ri-error-warning-line text-foreground-500 text-2xl" />
      </div>
      <div className="max-w-sm">
        <p className="text-sm font-semibold text-foreground-800">{title}</p>
        <p className="text-xs text-foreground-500 mt-1">{message}</p>
      </div>
      <div className="flex items-center gap-2">
        {onRetry && (
          <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={onRetry}>
            Tekrar Dene
          </Button>
        )}
        {onDownload && (
          <Button variant="primary" size="sm" leftIcon={<i className="ri-download-2-line" />} onClick={onDownload}>
            Dosyayı İndir
          </Button>
        )}
      </div>
    </div>
  );
}

interface UnsupportedViewProps {
  fileName: string;
  kind: PreviewKind;
  onDownload?: () => void;
}

/** Desteklenmeyen dosya türü için şık "önizleme yok" ekranı + indirme. */
export function UnsupportedFileView({ fileName, kind, onDownload }: UnsupportedViewProps) {
  return (
    <div className="flex-1 min-h-0 flex flex-col items-center justify-center gap-3 px-4 text-center">
      <div className="w-16 h-16 rounded-full bg-secondary-100 dark:bg-secondary-500/20 flex items-center justify-center">
        <i className={`${previewKindIcon(kind)} text-secondary-700 dark:text-secondary-300 text-3xl`} />
      </div>
      <div className="max-w-sm">
        <p className="text-sm font-semibold text-foreground-800">Bu dosya tarayıcıda önizlenemez</p>
        <p className="text-xs text-foreground-500 mt-1">
          {fileName} formatı uygulama içinde görüntülenemiyor. Dosyayı indirip cihazınızda açabilirsiniz.
        </p>
      </div>
      {onDownload && (
        <Button variant="primary" size="sm" leftIcon={<i className="ri-download-2-line" />} onClick={onDownload}>
          Dosyayı İndir
        </Button>
      )}
    </div>
  );
}