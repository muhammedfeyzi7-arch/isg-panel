import type { PDFDocumentProxy, PDFPageProxy } from 'pdfjs-dist';
import { loadPdfjsRuntime } from '@/lib/pdfjsRuntime';

interface PdfjsAssets {
  wasmUrl: string;
  cMapUrl: string;
  fontUrl: string;
}

let pdfjsAssets: PdfjsAssets | null = null;

/**
 * PDF.js runtime'ını (paylaşılan lazy yükleyici üzerinden) + CDN asset URL'lerini
 * (wasm/cMap/font) tek sefer hazırlar. pdfjs yalnızca ilk PDF'te yüklenir; varlık
 * URL'leri pdfjs sürümüyle eşleşecek şekilde burada üretilir.
 */
async function loadPdfjsEngineRuntime() {
  const lib = await loadPdfjsRuntime();
  if (!pdfjsAssets) {
    const base = `https://unpkg.com/pdfjs-dist@${lib.version}/`;
    pdfjsAssets = {
      wasmUrl: `${base}wasm/`,
      cMapUrl: `${base}cmaps/`,
      fontUrl: `${base}standard_fonts/`,
    };
  }
  return { lib, assets: pdfjsAssets };
}

/**
 * PDF MOTORU (production-grade, tek kaynak)
 *
 * Buradaki tüm PDF.js altyapısı tek yerde toplanır:
 *   • PDF.js Worker (ana UI thread'i bloklamaz)
 *   • Doküman cache'i (LRU, sınırlı) — aynı PDF tekrar açılınca yeniden parse edilmez
 *   • Merkezi RENDER KUYRUĞU — eşzamanlı render sayısı sınırlı + öncelikli
 *     (aktif sayfa > yakın sayfa > görünür thumbnail > tampon thumbnail). 600+
 *     sayfalı belgede onlarca render aynı anda başlatılıp CPU boğulmaz.
 *   • İptal edilebilir render (RenderTask.cancel + AbortSignal) — hızlı sayfa
 *     değişiminde/gezinmede eski iş ölür ve kuyruktan çıkar (slot işgal etmez)
 *   • Thumbnail önbelleği (sınırlı LRU, genişlik-duyarlı) — kaydırma sırasında
 *     yeniden render edilmez; belge atılınca thumbnail'ler de temizlenir
 *
 * RENDER SAĞLAMLIĞI:
 *   • Eşzamanlılık tek merkezi kuyruktan yönetilir (MAX_CONCURRENT_RENDERS).
 *     Böylece "aktif sayfa + onlarca thumbnail aynı anda" durumu oluşmaz ve aktif
 *     sayfa önceliği sayesinde asla aç kalmaz.
 *   • Tüm render'lar OPAK BEYAZ zemin ile yapılır (background: '#ffffff' + alpha:false).
 *     Şeffaf render'da taranmış sayfaların soluk/parçalı görünmesi bu şekilde önlenir.
 *   • Her render AbortSignal ile iptal edilebilir; iptal edilen iş kaynağı serbest
 *     bırakır ve asla başka işleri bloklamaz.
 */

/*
 * TARANMIŞ (scanned) PDF GÖRÜNTÜ KATMANI — KRİTİK KÖK NEDEN DÜZELTMESİ
 * ------------------------------------------------------------------
 * PDF.js 5.x sürümünde JBIG2 ve JPEG2000 (JPX) ile sıkıştırılmış taranmış
 * sayfa görüntüleri artık WASM çözücülerle açılır (jbig2.wasm / openjpeg.wasm).
 * `wasmUrl` verilmezse PDF.js bu görüntüleri "Unable to decode image" ile
 * atlar; sayfadaki vektör katman (imza, damga, çizgi) çizilir ama taranmış
 * görüntü katmanı boş kalır → belge ekranda silik/belli olmaz.
 *
 * Aynı şekilde bazı PDF'lerin gömülü font/CMap verisi eksiktir; bunları da
 * bildirmezsek metin katmanı çizilmez. Üç kaynağı da (wasm + cMap + font)
 * pdfjs-dist paketinin kendi sürümüyle eşleşecek şekilde CDN'den veriyoruz.
 * (Bu URL'ler artık lazy runtime ile birlikte, pdfjs yüklenirken üretilir.)
 */

/* ------------------------------------------------------------------ */
/* PDF doküman cache'i (LRU, refcount'lu)                              */
/* ------------------------------------------------------------------ */
interface DocEntry {
  key: string;
  promise: Promise<PDFDocumentProxy>;
  doc: PDFDocumentProxy | null;
  refs: number;
  lastUsed: number;
}

const MAX_DOCS = 3;
const docCache = new Map<string, DocEntry>();

/** Aynı dokümanı (cacheKey) paralel isteklerde TEK kez parse eder. */
function createEntry(key: string, getBytes: () => Promise<ArrayBuffer>): DocEntry {
  const entry: DocEntry = {
    key,
    refs: 0,
    doc: null,
    lastUsed: Date.now(),
    promise: (async () => {
      const bytes = await getBytes();
      // PDF.js runtime'ı yalnızca burada (ilk PDF) yüklenir.
      const { lib, assets } = await loadPdfjsEngineRuntime();
      // PDF.js'e verilen buffer'ı KOPYALAYARAK veririz: PDF.js worker'a transfer
      // ettiğinde orijinal buffer detached olabilir. Kopya sayesinde kaynak baytlar
      // (ör. gerçek PDF üretimi) hiçbir zaman bozulmaz.
      const data = new Uint8Array(bytes.slice(0));
      const task = lib.getDocument({
        data,
        // Taranmış JBIG2/JPX görüntüleri ve eksik font/cMap için kaynaklar.
        wasmUrl: assets.wasmUrl,
        cMapUrl: assets.cMapUrl,
        cMapPacked: true,
        standardFontDataUrl: assets.fontUrl,
      });
      const doc = await task.promise;
      entry.doc = doc;
      return doc;
    })(),
  };
  return entry;
}

function evictIfNeeded() {
  if (docCache.size <= MAX_DOCS) return;
  const idle = [...docCache.values()]
    .filter((e) => e.refs <= 0 && e.doc !== null)
    .sort((a, b) => a.lastUsed - b.lastUsed);
  for (const e of idle) {
    if (docCache.size <= MAX_DOCS) break;
    docCache.delete(e.key);
    clearThumbCacheFor(e.key); // belge atılınca thumbnail'leri de bellekten temizle
    e.doc?.destroy().catch(() => {});
  }
}

/**
 * Dokümanı önbellekten alır veya yükler ve bir referans tutar.
 * Bitince MUTLAKA `releasePdf(cacheKey)` çağrılmalıdır.
 */
export async function acquirePdf(
  cacheKey: string,
  getBytes: () => Promise<ArrayBuffer>,
): Promise<PDFDocumentProxy> {
  let entry = docCache.get(cacheKey);
  if (!entry) {
    entry = createEntry(cacheKey, getBytes);
    docCache.set(cacheKey, entry);
  }
  entry.refs += 1;
  entry.lastUsed = Date.now();
  try {
    const doc = await entry.promise;
    evictIfNeeded();
    return doc;
  } catch (err) {
    entry.refs = Math.max(0, entry.refs - 1);
    docCache.delete(cacheKey);
    throw err;
  }
}

/** Referansı bırakır; boşta kalan dokümanlar sınır aşılırsa bellekten atılır. */
export function releasePdf(cacheKey: string) {
  const entry = docCache.get(cacheKey);
  if (!entry) return;
  entry.refs = Math.max(0, entry.refs - 1);
  entry.lastUsed = Date.now();
  evictIfNeeded();
}

/* ------------------------------------------------------------------ */
/* RENDER KUYRUĞU — merkezi eşzamanlılık + öncelik kontrolü (tek kaynak)*/
/* ------------------------------------------------------------------ */
/**
 * PDF render'ları (aktif sayfa + thumbnail + ön-yükleme) TEK merkezi kuyruktan
 * geçer. PDF.js render'ı CPU-yoğundur; onlarca thumbnail + aktif sayfa aynı anda
 * başlatılırsa ana thread ve worker boğulur, UI kilitlenir. Burada eşzamanlı
 * render sayısı SABİT bir üst sınırla sınırlanır ve işler ÖNCELİK sırasına göre
 * çalıştırılır (aktif sayfa > yakın sayfa > görünür thumbnail > tampon thumbnail).
 * İptal edilen (AbortSignal) bekleyen işler kuyruktan çıkarılır → iptal edilen iş
 * slot işgal etmez, aktif sayfa asla aç kalmaz.
 */
export const RENDER_PRIORITY = {
  ACTIVE_PAGE: 0,
  NEAR_PAGE: 1,
  VISIBLE_THUMB: 2,
  BUFFER_THUMB: 3,
} as const;

/** Aynı anda çalışabilecek maksimum render sayısı (CPU kilidini önler). */
const MAX_CONCURRENT_RENDERS = 2;

interface WaitItem {
  priority: number;
  seq: number;
  resolve: () => void;
  reject: (e: unknown) => void;
  signal?: AbortSignal;
  onAbort?: () => void;
}

let renderActive = 0;
let renderSeq = 0;
const renderQueue: WaitItem[] = [];

function acquireRenderSlot(priority: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) return Promise.reject(new DOMException('Aborted', 'AbortError'));
  if (renderActive < MAX_CONCURRENT_RENDERS) {
    renderActive += 1;
    return Promise.resolve();
  }
  return new Promise<void>((resolve, reject) => {
    const item: WaitItem = { priority, seq: renderSeq, resolve, reject, signal };
    renderSeq += 1;
    if (signal) {
      item.onAbort = () => {
        const idx = renderQueue.indexOf(item);
        if (idx >= 0) {
          renderQueue.splice(idx, 1);
          reject(new DOMException('Aborted', 'AbortError'));
        }
      };
      signal.addEventListener('abort', item.onAbort, { once: true });
    }
    renderQueue.push(item);
    renderQueue.sort((a, b) => a.priority - b.priority || a.seq - b.seq);
  });
}

function releaseRenderSlot() {
  const next = renderQueue.shift();
  if (next) {
    if (next.signal && next.onAbort) next.signal.removeEventListener('abort', next.onAbort);
    next.resolve(); // slot devredilir; renderActive sabit kalır
  } else {
    renderActive = Math.max(0, renderActive - 1);
  }
}

/* ------------------------------------------------------------------ */
/* Sayfa render'ı (iptal edilebilir, atomik commit)                    */
/* ------------------------------------------------------------------ */
export interface PdfRenderHandle {
  promise: Promise<void>;
  cancel: () => void;
}

interface CancellableRenderTask {
  cancel: () => void;
  promise: Promise<void>;
}

const WHITE = '#ffffff';

/**
 * Tek bir PDF sayfasını render eder. İptal edilebilir; canvas iç çözünürlüğü DPR ile
 * ölçeklenir → ekranda net görünür. GÖRÜNÜR canvas'a doğrudan render EDİLMEZ: önce
 * görünmez canvas'a tam sayfa çizilir, yalnızca iş TAMAMEN bitince tek bir drawImage
 * ile aktarılır (atomik commit). Böylece iptal edilen render'lar görünür canvas'ı
 * yarım/soluk bırakamaz.
 */
export function renderPdfPage(opts: {
  doc: PDFDocumentProxy;
  pageNumber: number;
  scale: number;
  rotation: number;
  canvas: HTMLCanvasElement;
}): PdfRenderHandle {
  let cancelled = false;
  let renderTask: CancellableRenderTask | null = null;
  let offscreen: HTMLCanvasElement | null = null;
  const abort = new AbortController();

  const promise = (async () => {
    const page = await opts.doc.getPage(opts.pageNumber);
    if (cancelled) return;

    const viewport = page.getViewport({ scale: opts.scale, rotation: opts.rotation });
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const cssWidth = Math.max(1, Math.floor(viewport.width));
    const cssHeight = Math.max(1, Math.floor(viewport.height));
    const pxWidth = Math.max(1, Math.floor(viewport.width * dpr));
    const pxHeight = Math.max(1, Math.floor(viewport.height * dpr));

    offscreen = document.createElement('canvas');
    offscreen.width = pxWidth;
    offscreen.height = pxHeight;
    const offCtx = offscreen.getContext('2d', { alpha: false });
    if (!offCtx) throw new Error('Canvas bağlamı oluşturulamadı.');
    offCtx.fillStyle = WHITE;
    offCtx.fillRect(0, 0, pxWidth, pxHeight);

    // Merkezi render kuyruğundan slot al — aktif sayfa EN YÜKSEK önceliktedir.
    // Bu bekleme sırasında iptal edilirse kuyruktan çıkar ve render başlamaz.
    await acquireRenderSlot(RENDER_PRIORITY.ACTIVE_PAGE, abort.signal);
    try {
      if (cancelled) return;
      renderTask = page.render({
        canvasContext: offCtx,
        viewport,
        background: WHITE,
        transform: dpr !== 1 ? [dpr, 0, 0, dpr, 0, 0] : undefined,
      } as unknown as Parameters<typeof page.render>[0]) as unknown as CancellableRenderTask;

      await renderTask.promise;
    } catch (err) {
      // İptal normaldir; gerçek hatayı yukarı taşı.
      if (cancelled) return;
      throw err;
    } finally {
      releaseRenderSlot();
    }
    if (cancelled) return;

    const { canvas } = opts;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas bağlamı oluşturulamadı.');
    if (canvas.width !== pxWidth) canvas.width = pxWidth;
    if (canvas.height !== pxHeight) canvas.height = pxHeight;
    canvas.style.width = `${cssWidth}px`;
    canvas.style.height = `${cssHeight}px`;
    ctx.drawImage(offscreen, 0, 0);
  })();

  // Kaynakları (offscreen canvas) her durumda serbest bırak.
  promise
    .catch(() => {
      /* hata/iptal yukarıda ele alınır; burada sadece temizlik yapılır */
    })
    .finally(() => {
      if (offscreen) {
        offscreen.width = 0;
        offscreen.height = 0;
        offscreen = null;
      }
    });

  return {
    promise,
    cancel: () => {
      cancelled = true;
      // Kuyrukta bekliyorsa slot işgal etmeden çıkması için sinyali iptal et.
      abort.abort();
      try {
        renderTask?.cancel();
      } catch {
        /* render zaten bitmişse yok say */
      }
    },
  };
}

/** Sayfa taban boyutu (scale=1, verilen rotation ile) — zoom / sığdırma hesabı için. */
export async function getPdfPageSize(
  doc: PDFDocumentProxy,
  pageNumber: number,
  rotation: number,
): Promise<{ width: number; height: number }> {
  const page: PDFPageProxy = await doc.getPage(pageNumber);
  const vp = page.getViewport({ scale: 1, rotation });
  return { width: vp.width, height: vp.height };
}

/* ------------------------------------------------------------------ */
/* Thumbnail render + önbellek (sınırlı LRU)                           */
/* ------------------------------------------------------------------ */
const MAX_THUMBS = 120;
const thumbCache = new Map<string, string>();

function thumbKey(cacheKey: string, pageNumber: number, rotation: number, cssWidth: number) {
  // Genişlik de anahtara dahildir: farklı amaçlar (rail vs. ön-yükleme) farklı
  // çözünürlükte thumbnail üretir; biri diğerinin yanlış boyutlu sonucunu ALMAZ.
  return `${cacheKey}|${pageNumber}|${rotation}|${Math.round(cssWidth)}`;
}

export function getCachedThumb(
  cacheKey: string,
  pageNumber: number,
  rotation: number,
  cssWidth: number,
): string | null {
  const key = thumbKey(cacheKey, pageNumber, rotation, cssWidth);
  const hit = thumbCache.get(key);
  if (hit) {
    // LRU: son kullanılanı sona taşı.
    thumbCache.delete(key);
    thumbCache.set(key, hit);
    return hit;
  }
  return null;
}

function setCachedThumb(
  cacheKey: string,
  pageNumber: number,
  rotation: number,
  cssWidth: number,
  url: string,
) {
  const key = thumbKey(cacheKey, pageNumber, rotation, cssWidth);
  thumbCache.set(key, url);
  while (thumbCache.size > MAX_THUMBS) {
    const oldest = thumbCache.keys().next().value;
    if (oldest === undefined) break;
    thumbCache.delete(oldest);
  }
}

/**
 * Tek sayfayı küçük (thumbnail) çözünürlükte JPEG dataURL olarak üretir.
 *
 * • OPAK BEYAZ zemin (background) ile render edilir → taranmış belgeler soluk/şeffaf çıkmaz.
 * • `signal` verilirse iptal edilebilir: hücre ekrandan çıkınca render iptal edilir ve
 *   kaynak serbest bırakılır. İptal edilen bir iş ASLA diğer render'ları bloklamaz.
 * • Sonuç önbelleğe yazılır; tekrar viewport'a giren hücre anında (cache hit) gelir.
 */
export async function renderThumbnail(
  doc: PDFDocumentProxy,
  cacheKey: string,
  pageNumber: number,
  rotation: number,
  cssWidth: number,
  signal?: AbortSignal,
  priority: number = RENDER_PRIORITY.VISIBLE_THUMB,
): Promise<string> {
  const cached = getCachedThumb(cacheKey, pageNumber, rotation, cssWidth);
  if (cached) return cached;
  if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

  const page = await doc.getPage(pageNumber);
  if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

  const base = page.getViewport({ scale: 1, rotation });
  const scale = cssWidth / Math.max(1, base.width);
  const viewport = page.getViewport({ scale, rotation });

  // Merkezi render kuyruğu: eşzamanlılık sınırlı + öncelikli çalışır.
  // (İptal edilirse beklerken kuyruktan çıkar; slot işgal etmez.)
  await acquireRenderSlot(priority, signal);
  try {
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');

    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.floor(viewport.width));
    canvas.height = Math.max(1, Math.floor(viewport.height));
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) throw new Error('Canvas bağlamı oluşturulamadı.');
    ctx.fillStyle = WHITE;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    const task = page.render({
      canvasContext: ctx,
      viewport,
      background: WHITE,
    } as unknown as Parameters<typeof page.render>[0]) as unknown as CancellableRenderTask;

    const onAbort = () => {
      try {
        task.cancel();
      } catch {
        /* yok say */
      }
    };
    if (signal) signal.addEventListener('abort', onAbort, { once: true });

    try {
      await task.promise;
    } catch (err) {
      canvas.width = 0;
      canvas.height = 0;
      throw err;
    } finally {
      if (signal) signal.removeEventListener('abort', onAbort);
    }

    if (signal?.aborted) {
      canvas.width = 0;
      canvas.height = 0;
      throw new DOMException('Aborted', 'AbortError');
    }

    const url = canvas.toDataURL('image/jpeg', 0.82);
    setCachedThumb(cacheKey, pageNumber, rotation, cssWidth, url);
    // Yerel canvas'ı serbest bırak.
    canvas.width = 0;
    canvas.height = 0;
    return url;
  } finally {
    releaseRenderSlot();
  }
}

/** Belirli bir dokümanın thumbnail önbelleğini temizler (doküman kapanınca vb.). */
export function clearThumbCacheFor(cacheKey: string) {
  const prefix = `${cacheKey}|`;
  for (const key of [...thumbCache.keys()]) {
    if (key.startsWith(prefix)) thumbCache.delete(key);
  }
}