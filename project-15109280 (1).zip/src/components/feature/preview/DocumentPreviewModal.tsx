import { forwardRef } from 'react';
import SharedDocumentPreview from '@/components/feature/preview/SharedDocumentPreview';
import type {
  PreviewDocumentSource,
  PreviewViewerHandle,
  PreviewViewerState,
} from '@/components/feature/preview/types';

interface DocumentPreviewModalProps {
  /** Tek doküman (klasik kullanım). */
  source?: PreviewDocumentSource;
  /** Çoklu doküman (galeri) — verilirse `source` yok sayılır ve gezinme eklenir. */
  sources?: PreviewDocumentSource[];
  /** Galeri başlangıç indeksi. */
  initialIndex?: number;
  /** Galeri aktif indeksi değişince tetiklenir. */
  onIndexChange?: (index: number) => void;
  title?: string;
  onClose: () => void;
  onDownload?: () => void;
  downloadBusy?: boolean;
  onPrint?: () => void;
  selectable?: boolean;
  selectedPages?: number[];
  defaultSelectedPages?: number[];
  onSelectionChange?: (pages: number[]) => void;
  onStateChange?: (state: PreviewViewerState) => void;
  initialPage?: number;
}

/**
 * ORTAK DOKÜMAN ÖNİZLEME MODALI — geriye dönük uyumluluk sarmalayıcısı.
 *
 * Sistemde belge açmanın TEK standardı artık `SharedDocumentPreview`'dır.
 * Bu bileşen yalnızca eski çağrı sözleşmesini (props) koruyup aynı merkeze
 * delege eder; böylece ikinci bir önizleme modalı oluşmaz.
 */
const DocumentPreviewModal = forwardRef<PreviewViewerHandle, DocumentPreviewModalProps>(
  function DocumentPreviewModal(props, ref) {
    return <SharedDocumentPreview ref={ref} {...props} mode="modal" />;
  },
);

export default DocumentPreviewModal;