import {
  forwardRef,
  useCallback,
  useEffect,
  useId,
  useImperativeHandle,
  useMemo,
  useRef,
  useState,
} from 'react';
import { createPortal } from 'react-dom';
import { Z_LAYERS } from '@/utils/layers';
import { lockScroll, unlockScroll } from '@/lib/scrollLock';
import DocumentPreviewEngine from '@/components/feature/preview/DocumentPreviewEngine';
import {
  detectPreviewKind,
  previewKindIcon,
  previewKindLabel,
  PREVIEW_DEFAULT_STATE,
} from '@/components/feature/preview/types';
import type {
  PreviewDocumentSource,
  PreviewViewerHandle,
  PreviewViewerState,
} from '@/components/feature/preview/types';

const HEADER_BTN =
  'inline-flex items-center justify-center w-8 h-8 rounded-md text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/50 hover:text-foreground-900 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-default';

const FOOT_BTN =
  'inline-flex items-center gap-1.5 h-8 px-3 rounded-md text-xs font-medium border border-background-300/70 dark:border-background-400/40 bg-background-50 dark:bg-background-200/40 text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer whitespace-nowrap disabled:opacity-40 disabled:cursor-default';

function formatBytes(bytes?: number | null): string | null {
  if (!bytes || bytes <= 0) return null;
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/** Belge baytlarını gizli iframe ile yazdırır (PDF/görsel). */
async function printSource(source: PreviewDocumentSource): Promise<void> {
  const bytes = await source.getBytes();
  const blob = new Blob([bytes], { type: source.mimeType || 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const iframe = document.createElement('iframe');
  iframe.setAttribute('aria-hidden', 'true');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.src = url;
  iframe.onload = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      /* yoksay */
    }
  };
  document.body.appendChild(iframe);
  window.setTimeout(() => {
    if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
    URL.revokeObjectURL(url);
  }, 60000);
}

function MetaRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1.5 border-b border-background-200/60 dark:border-background-400/20 last:border-0">
      <span className="text-xs text-foreground-500 flex-shrink-0">{label}</span>
      <span className="text-xs text-foreground-800 text-right min-w-0 break-words">{value}</span>
    </div>
  );
}

interface MetaPanelProps {
  source: PreviewDocumentSource;
}

/** Sağ kolon — Belge Bilgileri. Yalnızca GERÇEK veriler gösterilir; boş alan üretilmez. */
function MetaPanel({ source }: MetaPanelProps) {
  const kind = detectPreviewKind(source.mimeType, source.fileName);
  const meta = source.meta ?? {};
  const size = meta.dosyaBoyutu ?? formatBytes(source.fileSize) ?? null;

  const rows: { label: string; value: string }[] = [
    { label: 'Belge Adı', value: meta.belgeAdi ?? source.fileName },
    { label: 'Dosya Türü', value: meta.dosyaTuru ?? previewKindLabel(kind) },
  ];
  if (size) rows.push({ label: 'Dosya Boyutu', value: size });
  if (meta.klasor) rows.push({ label: 'Klasör', value: meta.klasor });
  if (meta.belgeTarihi) rows.push({ label: 'Belge Tarihi', value: meta.belgeTarihi });
  if (meta.yuklemeTarihi) rows.push({ label: 'Yükleme Tarihi', value: meta.yuklemeTarihi });
  if (meta.yukleyen) rows.push({ label: 'Yükleyen', value: meta.yukleyen });
  if (meta.durum) rows.push({ label: 'Durum', value: meta.durum });
  if (meta.revizyon) rows.push({ label: 'Revizyon', value: meta.revizyon });
  if (meta.gecerlilik) rows.push({ label: 'Geçerlilik', value: meta.gecerlilik });
  if (meta.aciklama) rows.push({ label: 'Açıklama', value: meta.aciklama });

  return (
    <aside className="h-full w-full lg:w-[300px] flex-shrink-0 flex flex-col bg-background-50 dark:bg-background-100 border-l border-background-300/50 dark:border-background-400/30 overflow-hidden">
      <div className="flex-shrink-0 px-3 py-2.5 border-b border-background-300/40 dark:border-background-400/25 flex items-center gap-2">
        <i className="ri-information-line text-primary-600 dark:text-primary-400 text-sm" />
        <p className="text-xs font-semibold uppercase tracking-wide text-foreground-600">Belge Bilgileri</p>
      </div>
      <div className="flex-1 min-h-0 overflow-y-auto px-3 py-1.5 isg-scroll-pane">
        {rows.map((r) => (
          <MetaRow key={r.label} label={r.label} value={r.value} />
        ))}
        {meta.etiketler && meta.etiketler.length > 0 && (
          <div className="py-2">
            <p className="text-xs text-foreground-500 mb-1.5">Etiketler</p>
            <div className="flex flex-wrap gap-1.5">
              {meta.etiketler.map((t) => (
                <span
                  key={t}
                  className="inline-flex items-center rounded-full bg-secondary-100 dark:bg-secondary-500/20 text-secondary-900 dark:text-secondary-300 px-2 py-0.5 text-[11px] font-medium"
                >
                  {t}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}

export interface SharedDocumentPreviewProps {
  /** Tek doküman. */
  source?: PreviewDocumentSource;
  /** Çoklu doküman (galeri) — verilirse `source` yok sayılır ve doküman gezinmesi eklenir. */
  sources?: PreviewDocumentSource[];
  initialIndex?: number;
  onIndexChange?: (index: number) => void;
  title?: string;
  onClose?: () => void;
  onDownload?: () => void;
  downloadBusy?: boolean;
  onPrint?: () => void;
  selectable?: boolean;
  selectedPages?: number[];
  defaultSelectedPages?: number[];
  onSelectionChange?: (pages: number[]) => void;
  onStateChange?: (state: PreviewViewerState) => void;
  initialPage?: number;
  /** 'modal' = tam ekran katman (varsayılan) · 'embedded' = akış içinde gömülü. */
  mode?: 'modal' | 'embedded';
  className?: string;
}

/**
 * SHARED DOCUMENT PREVIEW — İSGDenetim'in TEK merkezî belge önizleme bileşeni.
 *
 * Amacı: uygulamanın her yerinde (Evraklar, Tutanaklar, Risk, Planlar, Acil Durum,
 * Personel/Firma detay, wizard son adımları, manuel yüklenen ekler) belge açmanın
 * TEK standardı olmak. Yeni bir modal/viewer yazılmaz; bu bileşen çağrılır.
 *
 * Layout (referans): başlık şeridi · orta viewer (motor toolbar'ı) · sağ Belge
 * Bilgileri · altta SABİT aksiyon barı (Kapat · Önceki/Sonraki + sayfa sayacı).
 * PDF/Word/Excel/PowerPoint/görsel tür tespiti merkezî motordan gelir.
 */
const SharedDocumentPreview = forwardRef<PreviewViewerHandle, SharedDocumentPreviewProps>(
  function SharedDocumentPreview(props, ref) {
    const {
      source,
      sources,
      initialIndex,
      onIndexChange,
      title,
      onClose,
      onDownload,
      downloadBusy,
      onPrint,
      selectable,
      selectedPages,
      defaultSelectedPages,
      onSelectionChange,
      onStateChange,
      initialPage,
      mode = 'modal',
      className,
    } = props;

    const lockId = useId();
    const previewLockId = lockId;

    const list = useMemo(
      () => (sources && sources.length > 0 ? sources : source ? [source] : []),
      [sources, source],
    );
    const [index, setIndex] = useState(() =>
      Math.min(Math.max(initialIndex ?? 0, 0), Math.max(list.length - 1, 0)),
    );

    useEffect(() => {
      if (initialIndex === undefined) return;
      setIndex(Math.min(Math.max(initialIndex, 0), Math.max(list.length - 1, 0)));
    }, [initialIndex, list.length]);

    const active = list[Math.min(index, Math.max(list.length - 1, 0))];
    const coklu = list.length > 1;

    const engineRef = useRef<PreviewViewerHandle | null>(null);
    useImperativeHandle(
      ref,
      () => ({
        next: () => engineRef.current?.next(),
        prev: () => engineRef.current?.prev(),
        goTo: (n: number) => engineRef.current?.goTo(n),
        zoomIn: () => engineRef.current?.zoomIn(),
        zoomOut: () => engineRef.current?.zoomOut(),
        fitPage: () => engineRef.current?.fitPage(),
        fitWidth: () => engineRef.current?.fitWidth(),
        rotate: () => engineRef.current?.rotate(),
        setZoom: (z: number) => engineRef.current?.setZoom?.(z),
      }),
      [],
    );

    const [viewerState, setViewerState] = useState<PreviewViewerState>(PREVIEW_DEFAULT_STATE);
    const [metaOpen, setMetaOpen] = useState(false);
    const [printBusy, setPrintBusy] = useState(false);

    const kind = active ? detectPreviewKind(active.mimeType, active.fileName) : 'unsupported';
    const canPrint = kind === 'pdf' || kind === 'image';
    const hasMeta = !!active?.meta;

    const handleState = useCallback(
      (s: PreviewViewerState) => {
        setViewerState(s);
        onStateChange?.(s);
      },
      [onStateChange],
    );

    const gitBelge = useCallback(
      (delta: number) => {
        if (list.length === 0) return;
        const next = (index + delta + list.length) % list.length;
        setIndex(next);
        onIndexChange?.(next);
      },
      [index, list.length, onIndexChange],
    );

    const handlePrint = useCallback(async () => {
      if (!active) return;
      if (onPrint) {
        onPrint();
        return;
      }
      setPrintBusy(true);
      try {
        await printSource(active);
      } finally {
        setPrintBusy(false);
      }
    }, [active, onPrint]);

    /* ---- Klavye: Esc kapat · ← → sayfa · +/- zoom (yakalama fazı → çift tetik yok) ---- */
    useEffect(() => {
      if (mode !== 'modal' || !onClose) return undefined;
      const onKey = (e: KeyboardEvent) => {
        const t = e.target as HTMLElement | null;
        const tag = t?.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || t?.isContentEditable) return;
        if (e.key === 'Escape') {
          if (document.fullscreenElement) return; // ilk Esc tam ekrandan çıkar
          e.stopPropagation();
          onClose();
          return;
        }
        if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
          e.preventDefault();
          e.stopPropagation();
          engineRef.current?.prev();
        } else if (e.key === 'ArrowRight' || e.key === 'PageDown') {
          e.preventDefault();
          e.stopPropagation();
          engineRef.current?.next();
        } else if (e.key === '+' || e.key === '=') {
          e.stopPropagation();
          engineRef.current?.zoomIn();
        } else if (e.key === '-') {
          e.stopPropagation();
          engineRef.current?.zoomOut();
        }
      };
      window.addEventListener('keydown', onKey, true);
      return () => window.removeEventListener('keydown', onKey, true);
    }, [mode, onClose]);

    /* ---- Modal: arka plan scroll kilidi (merkezi Shared UI utility) ----
       Belge önizleme modal motoru DIŞINDAN açılabildiği için (ör. ImageViewer)
       kilidi tek merkezi utility ile alır; böylece arka plan GERÇEKTEN sabit kalır. */
    useEffect(() => {
      if (mode !== 'modal') return undefined;
      const owner = `document-preview-${previewLockId}`;
      lockScroll(owner);
      return () => unlockScroll(owner);
    }, [mode, previewLockId]);

    if (!active) return null;

    const page = viewerState.page || 1;
    const pageCount = viewerState.count || 1;
    const canNav = pageCount > 1;

    const inner = (
      <div
        className={`relative w-full h-full md:rounded-lg overflow-hidden bg-background-50 dark:bg-background-100 border border-background-300/50 dark:border-background-400/30 flex flex-col min-h-0 ${
          mode === 'embedded' ? '' : 'md:h-full'
        } ${className ?? ''}`}
      >
        {/* ── BAŞLIK ŞERİDİ ── */}
        <div className="flex items-center gap-2.5 px-2.5 md:px-3 h-12 flex-shrink-0 border-b border-background-300/50 dark:border-background-400/30 bg-background-50 dark:bg-background-200/40">
          <span className="w-7 h-7 rounded-md bg-primary-100 dark:bg-primary-500/20 flex items-center justify-center flex-shrink-0">
            <i className={`${previewKindIcon(kind)} text-primary-700 dark:text-primary-300 text-sm`} />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-medium text-foreground-900 truncate leading-tight">
              {title ?? active.fileName}
            </p>
            <p className="text-[11px] text-foreground-500 truncate leading-tight">
              {previewKindLabel(kind)} · {active.fileName}
            </p>
          </div>

          <div className="flex items-center gap-0.5 flex-shrink-0">
            {canPrint && (
              <button
                type="button"
                className={HEADER_BTN}
                onClick={handlePrint}
                disabled={printBusy}
                title="Yazdır"
                aria-label="Yazdır"
              >
                <i className={`ri-printer-line text-base ${printBusy ? 'animate-pulse' : ''}`} />
              </button>
            )}
            {onDownload && (
              <button
                type="button"
                className={HEADER_BTN}
                onClick={onDownload}
                disabled={downloadBusy}
                title="İndir"
                aria-label="İndir"
              >
                <i className={`ri-download-2-line text-base ${downloadBusy ? 'animate-pulse' : ''}`} />
              </button>
            )}
            {hasMeta && (
              <button
                type="button"
                className={`${HEADER_BTN} lg:hidden ${metaOpen ? 'bg-background-200 dark:bg-background-300/50 text-foreground-900' : ''}`}
                onClick={() => setMetaOpen((v) => !v)}
                title="Belge Bilgileri"
                aria-label="Belge Bilgileri"
                aria-pressed={metaOpen}
              >
                <i className="ri-information-line text-base" />
              </button>
            )}
            {onClose && (
              <button
                type="button"
                className={HEADER_BTN}
                onClick={onClose}
                title="Kapat"
                aria-label="Kapat"
              >
                <i className="ri-close-line text-lg" />
              </button>
            )}
          </div>
        </div>

        {/* ── GÖVDE: viewer + (varsa) Belge Bilgileri ── */}
        <div className="relative flex-1 min-h-0 flex">
          <div className="flex-1 min-h-0 min-w-0">
            <DocumentPreviewEngine
              key={`${index}-${active.cacheKey}`}
              ref={engineRef}
              source={active}
              title={title ?? active.fileName}
              initialPage={initialPage}
              selectable={selectable}
              selectedPages={selectedPages}
              defaultSelectedPages={defaultSelectedPages}
              onSelectionChange={onSelectionChange}
              onStateChange={handleState}
              className="flex-1 min-h-0"
            />
          </div>

          {hasMeta && (
            <>
              {/* Masaüstü: sağ kolon (varsayılan açık) */}
              <div className="hidden lg:flex h-full">
                <MetaPanel source={active} />
              </div>
              {/* Mobil/tablet: sağdan açılan drawer */}
              {metaOpen && (
                <div className="lg:hidden absolute inset-0 z-20 flex justify-end">
                  <button
                    type="button"
                    aria-label="Belge bilgilerini kapat"
                    className="isg-overlay absolute inset-0 cursor-default"
                    onClick={() => setMetaOpen(false)}
                  />
                  <div className="relative w-[85%] max-w-[320px] h-full">
                    <MetaPanel source={active} />
                  </div>
                </div>
              )}
            </>
          )}

          {/* Galeri: doküman gezinme */}
          {coklu && (
            <>
              <button
                type="button"
                onClick={() => gitBelge(-1)}
                aria-label="Önceki belge"
                title="Önceki belge"
                className="absolute left-2 md:left-4 top-[calc(50%-1.5rem)] -translate-y-1/2 z-30 w-9 h-9 flex items-center justify-center rounded-full bg-background-50/90 dark:bg-background-200/90 text-foreground-700 border border-background-300/60 dark:border-background-400/30 hover:bg-background-100 dark:hover:bg-background-300/60 transition-colors cursor-pointer"
              >
                <i className="ri-arrow-left-s-line text-xl" />
              </button>
              <button
                type="button"
                onClick={() => gitBelge(1)}
                aria-label="Sonraki belge"
                title="Sonraki belge"
                className="absolute right-2 md:right-4 top-[calc(50%-1.5rem)] -translate-y-1/2 z-30 w-9 h-9 flex items-center justify-center rounded-full bg-background-50/90 dark:bg-background-200/90 text-foreground-700 border border-background-300/60 dark:border-background-400/30 hover:bg-background-100 dark:hover:bg-background-300/60 transition-colors cursor-pointer"
              >
                <i className="ri-arrow-right-s-line text-xl" />
              </button>
            </>
          )}
        </div>

        {/* ── ALT AKSİYON BARI (SABİT) ── */}
        <div className="flex items-center gap-2 px-2.5 md:px-3 h-12 flex-shrink-0 border-t border-background-300/50 dark:border-background-400/30 bg-background-50 dark:bg-background-200/40">
          {onClose && (
            <button type="button" className={FOOT_BTN} onClick={onClose}>
              <i className="ri-close-line text-sm" /> Kapat
            </button>
          )}

          {coklu && (
            <span className="text-xs text-foreground-500 tabular-nums whitespace-nowrap">
              Belge {index + 1} / {list.length}
            </span>
          )}

          <span className="flex-1" />

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              className={FOOT_BTN}
              onClick={() => engineRef.current?.prev()}
              disabled={!canNav || page <= 1}
              aria-label="Önceki sayfa"
            >
              <i className="ri-arrow-left-s-line text-base" /> Önceki Sayfa
            </button>
            <span className="text-xs text-foreground-700 tabular-nums px-1 whitespace-nowrap">
              {page} / {pageCount}
            </span>
            <button
              type="button"
              className={FOOT_BTN}
              onClick={() => engineRef.current?.next()}
              disabled={!canNav || page >= pageCount}
              aria-label="Sonraki sayfa"
            >
              Sonraki Sayfa <i className="ri-arrow-right-s-line text-base" />
            </button>
          </div>
        </div>
      </div>
    );

    if (mode === 'embedded') {
      return inner;
    }

    return createPortal(
      <div
        className="isg-overlay fixed inset-0 p-0 md:p-4 flex items-center justify-center"
        style={{ zIndex: Z_LAYERS.documentPreview }}
        role="dialog"
        aria-modal="true"
        aria-label={title ?? active.fileName}
      >
        {inner}
      </div>,
      document.body,
    );
  },
);

export default SharedDocumentPreview;