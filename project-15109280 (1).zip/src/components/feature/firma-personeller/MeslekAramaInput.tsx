import { useEffect, useRef, useState } from 'react';
import { araIskurMeslekler, type IskurMeslekSecim } from '@/lib/firmaPersonelService';

interface MeslekAramaInputProps {
  value: IskurMeslekSecim | null;
  onChange: (meslek: IskurMeslekSecim | null) => void;
}

/**
 * GÖREV / MESLEK ALANI — İŞKUR meslek araması (klasik dropdown DEĞİL).
 * Kullanıcı serbestçe yazar; sistem İŞKUR mesleklerini sunucu tarafında anlık
 * filtreler ve sonuçlardan kanonik bir meslek (occupation_id + İŞKUR kodu) seçilir.
 * Serbest metin ile resmi İŞKUR mesleği birbirine karıştırılmaz.
 */
export default function MeslekAramaInput({ value, onChange }: MeslekAramaInputProps) {
  const [term, setTerm] = useState('');
  const [results, setResults] = useState<IskurMeslekSecim[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (value) return; // meslek seçiliyken arama yapılmaz
    const q = term.trim();
    if (q.length < 2) {
      setResults([]);
      return;
    }
    let cancelled = false;
    setLoading(true);
    const t = setTimeout(() => {
      araIskurMeslekler(q)
        .then((res) => {
          if (!cancelled) {
            setResults(res);
            setOpen(true);
          }
        })
        .catch(() => {
          if (!cancelled) setResults([]);
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [term, value]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  if (value) {
    return (
      <div className="flex items-center gap-3 p-3 rounded-lg border border-primary-300/60 bg-primary-50/60 dark:bg-primary-500/10">
        <span className="w-9 h-9 rounded-md bg-primary-500/15 flex items-center justify-center flex-shrink-0">
          <i className="ri-base-station-line text-primary-600 dark:text-primary-400" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-foreground-900 truncate">{value.name}</p>
          <p className="isg-text-caption text-foreground-500">
            İŞKUR Kodu: {value.occupationCode}
            {value.sektor ? ` · ${value.sektor}` : ''}
          </p>
        </div>
        <button
          type="button"
          onClick={() => {
            onChange(null);
            setTerm('');
            setResults([]);
            setOpen(false);
          }}
          className="isg-btn isg-btn-secondary isg-btn-sm whitespace-nowrap cursor-pointer"
        >
          <i className="ri-refresh-line" /> Değiştir
        </button>
      </div>
    );
  }

  return (
    <div ref={boxRef} className="relative">
      <div className="relative">
        <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400" />
        <input
          type="text"
          value={term}
          onChange={(e) => setTerm(e.target.value)}
          onFocus={() => term.trim().length >= 2 && setOpen(true)}
          placeholder="Görev veya meslek adı yazın..."
          className="isg-input w-full pl-9"
          aria-label="Görev veya meslek ara"
        />
        {loading && (
          <span className="absolute right-3 top-1/2 -translate-y-1/2 inline-block w-4 h-4 border-2 border-foreground-300 border-t-transparent rounded-full animate-spin" />
        )}
        {!loading && term && (
          <button
            type="button"
            onClick={() => {
              setTerm('');
              setResults([]);
              setOpen(false);
            }}
            className="absolute right-3 top-1/2 -translate-y-1/2 text-foreground-400 hover:text-foreground-700 cursor-pointer"
            aria-label="Temizle"
          >
            <i className="ri-close-line" />
          </button>
        )}
      </div>

      {open && term.trim().length >= 2 && (
        <div className="absolute z-50 mt-1 w-full max-h-72 overflow-y-auto rounded-lg border border-background-300/70 dark:border-background-400/40 bg-background-50 dark:bg-background-200 shadow-lg">
          {results.length === 0 ? (
            <div className="p-4 text-sm text-foreground-400 text-center">
              {loading ? 'Aranıyor...' : 'İŞKUR mesleği bulunamadı'}
            </div>
          ) : (
            results.map((r) => (
              <button
                key={r.occupationId}
                type="button"
                onClick={() => {
                  onChange(r);
                  setOpen(false);
                }}
                className="w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-primary-50 dark:hover:bg-primary-500/15 transition-colors cursor-pointer border-b border-background-200/60 dark:border-background-400/20 last:border-0"
              >
                <span className="w-8 h-8 rounded-md bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
                  <i className="ri-tools-line text-foreground-500 text-sm" />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm text-foreground-800 truncate">{r.name}</span>
                  <span className="block isg-text-caption text-foreground-500">
                    İŞKUR Kodu: {r.occupationCode}
                    {r.sektor ? ` · ${r.sektor}` : ''}
                  </span>
                </span>
                {r.kuralVar && (
                  <span className="isg-status" data-tone="info">
                    Mesleki belge gerekli
                  </span>
                )}
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}