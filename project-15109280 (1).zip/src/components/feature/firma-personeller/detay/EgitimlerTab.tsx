import { useEffect, useMemo, useState } from 'react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import StatusBadge from '@/components/ui/StatusBadge';
import Select from '@/components/ui/Select';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import DatePicker from '@/components/ui/DatePicker';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import { toast } from '@/hooks/useToast';
import {
  fetchPersonelEgittimleri,
  fetchEgittimTurleri,
  type EgittimData,
  type EgittimTuru,
} from '@/lib/personelService';
import {
  createPersonelEgitimKaydi,
  arsivlePersonelEgitim,
  gunFarki,
} from '@/lib/firmaPersonelService';
import { fetchPersonelDigerTuru, uploadEvrak } from '@/lib/evrakService';
import { useEvrakOnizleme } from '@/components/feature/evrak/useEvrakOnizleme';
import { useTabData } from '@/lib/tabDataCache';
import { formatTarih, kalanGunMetni, kalanGunRenkSinifi } from '../personelFirmaUi';

interface Props {
  personelId: string;
  firmaId: string;
  onChanged: () => void;
}

/** Belge referansı (belge_url) personel evrak id'si mi? (legacy tam URL değil). */
function isEvrakRef(v: string | null | undefined): v is string {
  return !!v && v !== '—' && !v.startsWith('http') && !v.includes('/');
}

/**
 * EĞİTİMLER — belge + geçerlilik + yenileme/arşivleme.
 *
 * • Her eğitim kaydı: tür, (serbest) ad, tarih, geçerlilik tarihi, açıklama, belge.
 * • Belge yüklenirse personelin DİJİTAL dosyasına (evraklar) da yazılır ve burada
 *   evrak referansıyla bağlanır — Evraklar sekmesinde ve sistem içi görüntüleyicide bulunur.
 * • Süresi dolan kayıtta “Yenile” görünür. Yenileme eski kaydı SİLMEZ/ÜZERİNE YAZMAZ;
 *   eski kaydı arşivler (egitim_durumu='arsivlendi') ve YENİ bir kayıt oluşturur.
 */
export default function EgitimlerTab({ personelId, firmaId, onChanged }: Props) {
  const { data, error, isInitialLoading, refresh } = useTabData<EgittimData[]>(
    ['personel-egitimleri', personelId],
    () => fetchPersonelEgittimleri(personelId),
  );
  const rows = data ?? [];
  const { data: turlerData } = useTabData<EgittimTuru[]>('egitim-turleri', () => fetchEgittimTurleri());
  const turler = turlerData ?? [];
  const { openEvrak, evrakPreviewNode } = useEvrakOnizleme();

  const aktifler = useMemo(() => rows.filter((r) => r.egitimDurumu !== 'arsivlendi'), [rows]);
  const arsiv = useMemo(() => rows.filter((r) => r.egitimDurumu === 'arsivlendi'), [rows]);

  const [digerTuruId, setDigerTuruId] = useState<string | null>(null);
  useEffect(() => {
    fetchPersonelDigerTuru().then((t) => setDigerTuruId(t?.id ?? null)).catch(() => setDigerTuruId(null));
  }, []);

  const [showForm, setShowForm] = useState(false);
  const [renewOfId, setRenewOfId] = useState<string | null>(null);
  const [tur, setTur] = useState('temel_isg');
  const [serbestAd, setSerbestAd] = useState('');
  const [tarih, setTarih] = useState('');
  const [gecerlilik, setGecerlilik] = useState('');
  const [aciklama, setAciklama] = useState('');
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [saving, setSaving] = useState(false);
  const [showArsiv, setShowArsiv] = useState(false);

  const errorMessage = error instanceof Error ? error.message : error ? 'Eğitimler yüklenemedi.' : null;
  const serbestMi = tur === 'diger';

  function resetForm() {
    setTur('temel_isg');
    setSerbestAd('');
    setTarih('');
    setGecerlilik('');
    setAciklama('');
    setFiles([]);
    setRenewOfId(null);
  }

  function openAdd() {
    resetForm();
    setShowForm(true);
  }

  function openRenew(r: EgittimData) {
    setTur(r.egitimTuru);
    setSerbestAd(r.egitimAdi ?? '');
    setTarih('');
    setGecerlilik('');
    setAciklama('');
    setFiles([]);
    setRenewOfId(r.id);
    setShowForm(true);
  }

  async function handleSave() {
    if (!tarih) {
      toast.warning('Eğitim tarihi girin');
      return;
    }
    if (gecerlilik && gecerlilik < tarih) {
      toast.warning('Geçersiz tarih', 'Geçerlilik tarihi eğitim tarihinden önce olamaz.');
      return;
    }
    if (serbestMi && !serbestAd.trim()) {
      toast.warning('Eğitim adını yazın');
      return;
    }
    setSaving(true);
    try {
      // Belge varsa önce personelin dijital dosyasına (evraklar) yaz.
      let belgeUrl: string | null = null;
      const file = files.find((f) => f.raw)?.raw;
      if (file) {
        if (!digerTuruId) {
          toast.warning('Belge türü tanımlı değil', 'Belge kaydedilemedi, eğitim belgesiz oluşturuldu.');
        } else {
          const res = await uploadEvrak({
            ownerType: 'personel',
            firmaId,
            personelId,
            documentTypeId: digerTuruId,
            title: file.name,
            documentDate: tarih,
            validUntil: gecerlilik || null,
            file,
          });
          belgeUrl = res.evrakId;
        }
      }

      // Aynı türdeki mevcut AKTİF kayıt(lar) ARŞİVLENİR (SİLİNMEZ, üzerine YAZILMAZ);
      // yeni kayıt GÜNCEL kayıt olur. 'diger' türünde aynı serbest ad baz alınır.
      const ayniTur = aktifler.filter(
        (r) => r.egitimTuru === tur && (tur !== 'diger' || (r.egitimAdi ?? '').trim() === serbestAd.trim()),
      );
      for (const r of ayniTur) {
        await arsivlePersonelEgitim(r.id);
      }
      await createPersonelEgitimKaydi({
        personelId,
        egitimTuru: tur,
        egitimAdi: serbestMi ? serbestAd : null,
        egitimTarihi: tarih,
        gecerlilikTarihi: gecerlilik || null,
        aciklama,
        belgeUrl,
      });
      toast.success(renewOfId ? 'Eğitim yenilendi' : 'Eğitim eklendi');
      resetForm();
      setShowForm(false);
      refresh();
      onChanged();
    } catch (e) {
      toast.error('Kaydedilemedi', e instanceof Error ? e.message : undefined);
    } finally {
      setSaving(false);
    }
  }

  function belgeGoruntule(r: EgittimData) {
    if (!isEvrakRef(r.belgeUrl)) {
      toast.warning('Belge bulunamadı', 'Bu eğitim kaydına bağlı görüntülenebilir dosya yok.');
      return;
    }
    openEvrak({
      evrakId: r.belgeUrl,
      title: r.egitimTuruAd,
      fileName: null,
      mimeType: null,
      fileSize: null,
      meta: { belgeAdi: r.egitimTuruAd, belgeTarihi: formatTarih(r.egitimTarihi), gecerlilik: formatTarih(r.yenilemeTarihi) },
    });
  }

  function EgitimKart({ r, archived }: { r: EgittimData; archived?: boolean }) {
    const kalan = gunFarki(r.yenilemeTarihi);
    const suresiDoldu = kalan !== null && kalan < 0 && !archived;
    const hasBelge = isEvrakRef(r.belgeUrl);
    return (
      <div className={`rounded-lg border p-3 ${archived ? 'border-background-300/40 dark:border-background-400/20 bg-background-100/60 dark:bg-background-200/30' : 'border-background-300/60 dark:border-background-400/30 bg-background-50 dark:bg-background-100/40'}`}>
        <div className="flex items-start gap-2.5">
          <span className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
            <i className="ri-graduation-cap-line text-lg" />
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="text-sm font-semibold text-foreground-900 truncate">{r.egitimTuruAd}</p>
              {archived ? (
                <Badge variant="default">Arşiv</Badge>
              ) : suresiDoldu ? (
                <StatusBadge tone="danger">Süresi Doldu</StatusBadge>
              ) : (
                <StatusBadge tone="success">Geçerli</StatusBadge>
              )}
            </div>
            <div className="mt-1.5 grid grid-cols-1 sm:grid-cols-3 gap-x-4 gap-y-1">
              <div>
                <p className="isg-text-caption text-foreground-400">Eğitim Tarihi</p>
                <p className="text-sm text-foreground-800">{formatTarih(r.egitimTarihi)}</p>
              </div>
              <div>
                <p className="isg-text-caption text-foreground-400">Geçerlilik</p>
                <p className="text-sm text-foreground-800">{formatTarih(r.yenilemeTarihi)}</p>
              </div>
              <div>
                <p className="isg-text-caption text-foreground-400">Kalan Süre</p>
                <p className={`text-sm ${kalanGunRenkSinifi(kalan)}`}>{kalanGunMetni(kalan)}</p>
              </div>
            </div>
            {r.aciklama && <p className="mt-1.5 text-xs text-foreground-500 whitespace-pre-wrap">{r.aciklama}</p>}
            <div className="mt-2 flex items-center gap-2 flex-wrap">
              <span className={`inline-flex items-center gap-1 text-xs ${hasBelge ? 'text-success-600' : 'text-foreground-400'}`}>
                <i className={hasBelge ? 'ri-attachment-2' : 'ri-attachment-line'} />
                {hasBelge ? 'Belge yüklü' : 'Belge yok'}
              </span>
              {hasBelge && (
                <Button variant="ghost" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={() => belgeGoruntule(r)}>Görüntüle</Button>
              )}
              {!archived && suresiDoldu && (
                <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={() => openRenew(r)}>Yenile</Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <Card
      title="Eğitimler"
      icon="ri-graduation-cap-line"
      subtitle="Personelin aldığı İSG ve mesleki eğitimler; belge, geçerlilik ve yenileme takibi."
      actions={<Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={openAdd}>Eğitim Ekle</Button>}
    >
      {/* Form (ekle / yenile) */}
      {showForm && (
        <div className="mb-4 rounded-lg border border-primary-200/60 dark:border-primary-400/25 bg-primary-50/40 dark:bg-primary-500/10 p-3 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold text-foreground-800">
              {renewOfId ? 'Eğitimi Yenile (eski kayıt arşivlenir)' : 'Yeni Eğitim Kaydı'}
            </p>
            <Button variant="ghost" size="sm" onClick={() => { setShowForm(false); resetForm(); }} disabled={saving}>
              <i className="ri-close-line" />
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Select
              label="Eğitim Türü"
              options={turler.filter((t) => t.aktif).map((t) => ({ value: t.kod, label: t.ad }))}
              value={tur}
              onChange={(e) => setTur(e.target.value)}
              disabled={saving}
            />
            {serbestMi && (
              <Input label="Eğitim Adı" required value={serbestAd} onChange={(e) => setSerbestAd(e.target.value)} placeholder="Örn: Forklift Kullanım Eğitimi" maxLength={120} disabled={saving} />
            )}
            <DatePicker label="Eğitim Tarihi" required value={tarih} onChange={(e) => setTarih(e.target.value)} disabled={saving} />
            <DatePicker label="Geçerlilik Tarihi" value={gecerlilik} onChange={(e) => setGecerlilik(e.target.value)} disabled={saving} />
            <div className="sm:col-span-2">
              <Textarea label="Açıklama / Not" value={aciklama} onChange={(e) => setAciklama(e.target.value.slice(0, 500))} rows={2} placeholder="İsteğe bağlı" disabled={saving} />
            </div>
            <div className="sm:col-span-2">
              <FileUpload
                multiple={false}
                files={files}
                onChange={setFiles}
                label="Eğitim Belgesi"
                heading="Belgeyi buraya sürükleyin veya seçin"
                browseLabel="Dosya Seç"
                helpText="Belge, personelin dijital dosyasına da kaydedilir (PDF, JPG, PNG · Maks. 10 MB)"
              />
            </div>
          </div>
          <div className="flex items-center justify-end gap-2">
            <Button variant="secondary" size="sm" onClick={() => { setShowForm(false); resetForm(); }} disabled={saving}>Vazgeç</Button>
            <Button variant="primary" size="sm" isLoading={saving} leftIcon={<i className="ri-save-line" />} onClick={handleSave}>
              {renewOfId ? 'Yenile ve Kaydet' : 'Kaydet'}
            </Button>
          </div>
        </div>
      )}

      {isInitialLoading ? (
        <div className="flex justify-center py-10"><Loading size="lg" text="Eğitimler yükleniyor..." /></div>
      ) : errorMessage ? (
        <ErrorState message={errorMessage} onRetry={refresh} />
      ) : (
        <>
          {aktifler.length === 0 ? (
            <p className="isg-text-caption text-foreground-400 py-4">Henüz aktif eğitim kaydı yok.</p>
          ) : (
            <div className="flex flex-col gap-2.5">
              {aktifler.map((r) => <EgitimKart key={r.id} r={r} />)}
            </div>
          )}

          {arsiv.length > 0 && (
            <div className="mt-4 border-t border-background-300/40 dark:border-background-400/25 pt-3">
              <button
                type="button"
                onClick={() => setShowArsiv((v) => !v)}
                className="flex items-center gap-1.5 text-sm font-medium text-foreground-600 hover:text-foreground-900 cursor-pointer"
              >
                <i className={showArsiv ? 'ri-arrow-down-s-line' : 'ri-arrow-right-s-line'} />
                Arşiv ({arsiv.length})
              </button>
              {showArsiv && (
                <div className="mt-2.5 flex flex-col gap-2.5">
                  {arsiv.map((r) => <EgitimKart key={r.id} r={r} archived />)}
                </div>
              )}
            </div>
          )}
        </>
      )}

      {evrakPreviewNode}
    </Card>
  );
}