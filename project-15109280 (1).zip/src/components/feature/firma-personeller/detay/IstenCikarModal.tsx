import { useState } from 'react';
import Button from '@/components/ui/Button';
import DatePicker from '@/components/ui/DatePicker';
import { toast } from '@/hooks/useToast';
import { firmaPersonelIstenCikar } from '@/lib/firmaPersonelService';
import { formatTarih } from '../personelFirmaUi';

interface Props {
  personelId: string;
  adSoyad: string;
  onClose: () => void;
  onDone: () => void;
}

function bugunIso(): string {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/**
 * Personeli İşten Çıkar onay içeriği (Shared Modal shell içinde açılır).
 * Bu işlem DELETE değildir: personel pasife alınır, işten çıkış tarihi yazılır,
 * aktif listeden çıkar; geçmiş, dijital dosya, evrak, eğitim ve sağlık kayıtları
 * KORUNUR. Backend: `firma_personel_isten_cikar` RPC (firma/OSGB scope + RLS).
 */
export default function IstenCikarModal({ personelId, adSoyad, onClose, onDone }: Props) {
  const [tarih, setTarih] = useState(bugunIso());
  const [saving, setSaving] = useState(false);

  async function handleConfirm() {
    if (!tarih) {
      toast.warning('İşten çıkarma tarihi seçin');
      return;
    }
    setSaving(true);
    try {
      await firmaPersonelIstenCikar(personelId, tarih);
      toast.success('Personel işten çıkarıldı', `${adSoyad} ${formatTarih(tarih)} itibarıyla pasif duruma alındı. Geçmiş kayıtları korunur.`);
      onDone();
      onClose();
    } catch (e) {
      toast.error('İşlem başarısız', e instanceof Error ? e.message : 'Beklenmeyen bir hata oluştu.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="p-4 md:p-5 space-y-4">
      <div className="flex items-start gap-3 p-3 rounded-xl bg-danger-50 dark:bg-danger-500/10 border border-danger-200/60 dark:border-danger-500/20">
        <span className="w-9 h-9 rounded-full bg-danger-100 dark:bg-danger-500/20 flex items-center justify-center flex-shrink-0">
          <i className="ri-user-unfollow-line text-danger-600 dark:text-danger-400" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-foreground-950">{adSoyad}</p>
          <p className="mt-0.5 text-sm text-foreground-600">
            Bu personel işten ayrılmış olarak işaretlenecek ve aktif personel listesinden çıkarılacaktır.
          </p>
        </div>
      </div>

      <DatePicker
        label="İşten Çıkarma Tarihi"
        required
        value={tarih}
        onChange={(e) => setTarih(e.target.value)}
      />

      <p className="isg-text-caption text-foreground-500 leading-relaxed">
        Personel kaydı silinmez; geçmiş bilgileri, dijital dosyası, evrakları, eğitim ve sağlık kayıtları korunur.
        Personel arşiv/ayrılmış listesine geçer.
      </p>

      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="secondary" onClick={onClose} disabled={saving}>İptal</Button>
        <Button variant="danger" isLoading={saving} disabled={!tarih} leftIcon={<i className="ri-user-unfollow-line" />} onClick={handleConfirm}>
          İşten Çıkar
        </Button>
      </div>
    </div>
  );
}