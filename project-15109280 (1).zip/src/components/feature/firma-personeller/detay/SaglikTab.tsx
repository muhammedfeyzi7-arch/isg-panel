import { useState } from 'react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import StatusBadge from '@/components/ui/StatusBadge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import DatePicker from '@/components/ui/DatePicker';
import Select from '@/components/ui/Select';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import { toast } from '@/hooks/useToast';
import { fetchPersonelSaglikMuayeneleri, type SaglikMuayeneData } from '@/lib/personelService';
import {
  addPersonelSaglik,
  fetchSaglikOzetMap,
  gunFarki,
  kayitDurum,
  saglikUygunlukOf,
  type PersonelSaglikOzet,
} from '@/lib/firmaPersonelService';
import { useTabData } from '@/lib/tabDataCache';
import {
  SAGLIK_DURUM_LABEL,
  SAGLIK_UYGUNLUK_LABEL,
  formatTarih,
  kalanGunMetni,
  saglikDurumVariant,
  saglikUygunlukVariant,
} from '../personelFirmaUi';

interface Props {
  personelId: string;
  firmaId: string;
  /**
   * Sağlık muayenesi TIBBİ DETAYINI görme ve kayıt oluşturma yetkisi. YALNIZCA işyeri
   * hekimi (ve OSGB/admin) için true'dur. Firma ve Uzman YALNIZCA "Uygun / Uygun Değil /
   * Kayıt Yok" görür — tıbbi detay, muayene türü, kurum, açıklama ve belge göremez (KVKK).
   */
  canManage: boolean;
  onChanged: () => void;
}

const KVKK_NOTE = 'Sağlık verileri KVKK kapsamında korunmaktadır. Tıbbi detaylar ve sağlık belgeleri yalnızca yetkili işyeri hekimi tarafından görüntülenir.';

/** KVKK güvenli özet görünümü — Firma ve Uzman için 3 durumlu uygunluk. */
function SaglikOzet({ personelId }: { personelId: string }) {
  const { data, error, isInitialLoading, refresh } = useTabData<Record<string, PersonelSaglikOzet>>(
    ['personel-saglik-ozet', personelId],
    () => fetchSaglikOzetMap([personelId]),
  );
  const ozet = data?.[personelId];
  const uygunluk = saglikUygunlukOf(ozet?.saglikDurumu ?? null, !!ozet?.muayeneTarihi);
  const v = saglikUygunlukVariant(uygunluk);
  const errorMessage = error instanceof Error ? error.message : error ? 'Sağlık durumu yüklenemedi.' : null;

  return (
    <Card
      title="Sağlık ve Muayeneler"
      icon="ri-heart-pulse-line"
      subtitle="Periyodik sağlık muayenesi durumu. Tıbbi detaylar yalnızca yetkili işyeri hekimi tarafından görülebilir."
    >
      <div className="mb-3 rounded-lg border border-secondary-200/60 dark:border-secondary-400/25 bg-secondary-50 dark:bg-secondary-500/10 p-3 flex gap-2">
        <i className="ri-lock-2-line text-secondary-600 dark:text-secondary-400 flex-shrink-0 mt-0.5" />
        <p className="isg-text-caption text-secondary-900 dark:text-secondary-300 leading-relaxed">{KVKK_NOTE}</p>
      </div>
      {isInitialLoading ? (
        <div className="flex justify-center py-10"><Loading size="lg" text="Sağlık durumu yükleniyor..." /></div>
      ) : errorMessage ? (
        <ErrorState message={errorMessage} onRetry={refresh} />
      ) : (
        <div className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <span className="w-10 h-10 rounded-lg bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
              <i className="ri-heart-pulse-line text-foreground-500" />
            </span>
            <div className="min-w-0">
              <p className="text-sm font-medium text-foreground-800">Sağlık Uygunluğu</p>
              <p className="isg-text-caption text-foreground-500">Güncel muayene durumuna göre</p>
            </div>
          </div>
          <StatusBadge tone={v === 'success' ? 'success' : v === 'danger' ? 'danger' : 'neutral'}>
            {SAGLIK_UYGUNLUK_LABEL[uygunluk]}
          </StatusBadge>
        </div>
      )}
    </Card>
  );
}

/** Tıbbi detay görünümü — yalnızca hekim / OSGB / admin. */
function SaglikDetay({ personelId, firmaId, onChanged }: { personelId: string; firmaId: string; onChanged: () => void }) {
  const { data, error, isInitialLoading, refresh } = useTabData<SaglikMuayeneData[]>(
    ['personel-saglik', personelId],
    () => fetchPersonelSaglikMuayeneleri(personelId),
  );
  const rows = data ?? [];
  const [showAdd, setShowAdd] = useState(false);
  const [tarih, setTarih] = useState('');
  const [durum, setDurum] = useState('uygun');
  const [saving, setSaving] = useState(false);
  const errorMessage = error instanceof Error ? error.message : error ? 'Muayeneler yüklenemedi.' : null;

  async function handleAdd() {
    if (!tarih) {
      toast.warning('Muayene tarihi girin');
      return;
    }
    setSaving(true);
    try {
      await addPersonelSaglik(personelId, firmaId, tarih, durum);
      toast.success('Muayene kaydı eklendi');
      setShowAdd(false);
      setTarih('');
      setDurum('uygun');
      refresh();
      onChanged();
    } catch (e) {
      toast.error('Eklenemedi', e instanceof Error ? e.message : undefined);
    } finally {
      setSaving(false);
    }
  }

  const columns: TableColumn<SaglikMuayeneData>[] = [
    { key: 'muayene', header: 'Muayene Tarihi', render: (r) => <span className="text-sm text-foreground-700">{formatTarih(r.muayeneTarihi)}</span> },
    { key: 'yenileme', header: 'Yenileme Tarihi', render: (r) => <span className="text-sm text-foreground-700">{formatTarih(r.yenilemeTarihi)}</span> },
    {
      key: 'kalan',
      header: 'Kalan Süre',
      render: (r) => {
        const k = gunFarki(r.yenilemeTarihi);
        return k !== null && k < 0 ? <StatusBadge tone="danger">{kalanGunMetni(k)}</StatusBadge> : <span className="text-sm text-foreground-700">{kalanGunMetni(k)}</span>;
      },
    },
    {
      key: 'uygunluk',
      header: 'Uygunluk Durumu',
      render: (r) => {
        const d = kayitDurum(r.yenilemeTarihi);
        const variant = saglikDurumVariant(d);
        return <StatusBadge tone={variant === 'success' ? 'success' : variant === 'danger' ? 'danger' : variant === 'warning' ? 'warning' : 'neutral'}>{SAGLIK_DURUM_LABEL[d]}</StatusBadge>;
      },
    },
  ];

  return (
    <Card
      title="Sağlık ve Muayeneler"
      icon="ri-heart-pulse-line"
      subtitle="Periyodik sağlık muayenesi bilgileri. Sağlık kaydını ve uygunluk durumunu yalnızca yetkili işyeri hekimi oluşturabilir."
      actions={<Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={() => setShowAdd((s) => !s)}>Muayene Kaydı</Button>}
    >
      <div className="mb-3 rounded-lg border border-secondary-200/60 dark:border-secondary-400/25 bg-secondary-50 dark:bg-secondary-500/10 p-3 flex gap-2">
        <i className="ri-lock-2-line text-secondary-600 dark:text-secondary-400 flex-shrink-0 mt-0.5" />
        <p className="isg-text-caption text-secondary-900 dark:text-secondary-300 leading-relaxed">
          {KVKK_NOTE} Yenileme tarihi, firmanın tehlike sınıfına göre merkezi mevzuat kurallarından otomatik hesaplanır.
        </p>
      </div>
      {showAdd && (
        <div className="mb-4 rounded-lg border border-primary-200/60 dark:border-primary-400/25 bg-primary-50/40 dark:bg-primary-500/10 p-3 grid grid-cols-1 sm:grid-cols-4 gap-3">
          <DatePicker label="Muayene Tarihi" value={tarih} onChange={(e) => setTarih(e.target.value)} />
          <Select
            label="Uygunluk Durumu"
            options={[
              { value: 'uygun', label: 'Uygun' },
              { value: 'uygun_degil', label: 'Uygun Değil' },
            ]}
            value={durum}
            onChange={(e) => setDurum(e.target.value)}
          />
          <div className="flex items-end gap-2 sm:col-span-2">
            <Button variant="secondary" size="sm" onClick={() => setShowAdd(false)} disabled={saving}>Vazgeç</Button>
            <Button variant="primary" size="sm" isLoading={saving} leftIcon={<i className="ri-save-line" />} onClick={handleAdd}>Kaydet</Button>
          </div>
        </div>
      )}
      {isInitialLoading ? (
        <div className="flex justify-center py-10"><Loading size="lg" text="Muayeneler yükleniyor..." /></div>
      ) : errorMessage ? (
        <ErrorState message={errorMessage} onRetry={refresh} />
      ) : rows.length === 0 ? (
        <p className="isg-text-caption text-foreground-400 py-4">Henüz muayene kaydı yok.</p>
      ) : (
        <Table data={rows} columns={columns} keyExtractor={(r) => r.id} density="compact" />
      )}
    </Card>
  );
}

// Bu görünüm yalnızca yetkili roller (hekim/osgb/admin) için render edilir.
export default function SaglikTab({ personelId, firmaId, canManage, onChanged }: Props) {
  if (!canManage) return <SaglikOzet personelId={personelId} />;
  return <SaglikDetay personelId={personelId} firmaId={firmaId} onChanged={onChanged} />;
}