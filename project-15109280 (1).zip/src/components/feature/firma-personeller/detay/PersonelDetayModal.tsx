import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Button from '@/components/ui/Button';
import StatusBadge from '@/components/ui/StatusBadge';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import ActionMenu from '@/components/ui/ActionMenu';
import { useModalActions } from '@/hooks/useModal';
import { useAuth } from '@/context/AuthContext';
import { fetchEvrakTurleri, type EvrakTuru } from '@/lib/evrakService';
import { fetchPersonelEgittimleri, fetchPersonelSaglikMuayeneleri } from '@/lib/personelService';
import { preloadTabData, useTabData } from '@/lib/tabDataCache';
import {
  codeMatches,
  enrichPersoneller,
  evrakKodlariForAcceptedTypes,
  fetchFirmaPersonelDetay,
  fetchKisiGereksinimleri,
  fetchOccupationSektor,
  fetchPersonelEvraklari,
  fetchPersonelNotlariWithUser,
  type BelgeTuruOption,
  type KisiGereksinim,
  type PersonelDetay,
  type PersonelEvrakSatir,
  type PersonelZenginlestirme,
} from '@/lib/firmaPersonelService';
import { basHarfler, calismaSuresiMetni, formatTarih } from '../personelFirmaUi';
import GenelBilgilerTab from './GenelBilgilerTab';
import MeslekiBelgelerTab, { type GereksinimSatir } from './MeslekiBelgelerTab';
import EgitimlerTab from './EgitimlerTab';
import SaglikTab from './SaglikTab';
import EvraklarTab from './EvraklarTab';
import NotlarGecmisTab from './NotlarGecmisTab';
import IstenCikarModal from './IstenCikarModal';
import PersonelDuzenleModal from './PersonelDuzenleModal';

interface Props {
  personelId: string;
  onClose: () => void;
  onChanged: () => void;
}

type TabKey = 'genel' | 'mesleki' | 'egitim' | 'saglik' | 'evrak' | 'gecmis';

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: 'genel', label: 'Genel Bilgiler', icon: 'ri-user-line' },
  { key: 'mesleki', label: 'Mesleki Belgeler', icon: 'ri-file-shield-2-line' },
  { key: 'egitim', label: 'Eğitimler', icon: 'ri-graduation-cap-line' },
  { key: 'saglik', label: 'Sağlık ve Muayeneler', icon: 'ri-heart-pulse-line' },
  { key: 'evrak', label: 'Evraklar', icon: 'ri-folder-shield-2-line' },
  { key: 'gecmis', label: 'Notlar ve Geçmiş', icon: 'ri-history-line' },
];

const BOS_ZENGIN: PersonelZenginlestirme = {
  meslekiBelge: { durum: 'gerekli_degil', eksikSayi: 0, toplamSayi: 0 },
  saglik: { muayeneTarihi: null, yenilemeTarihi: null, kalanGun: null, durum: 'yok', uygunluk: 'yok' },
  egitim: { egitimTarihi: null, yenilemeTarihi: null, kalanGun: null, durum: 'yok' },
  evrak: { var_: 0, toplam: 0, durum: 'gerekli_degil' },
};

export default function PersonelDetayModal({ personelId, onClose, onChanged }: Props) {
  const { openModal, closeModal } = useModalActions();
  const { profile } = useAuth();
  // Sağlık muayenesi kaydını YALNIZCA işyeri hekimi (ve OSGB/admin) oluşturabilir.
  const canManageHealth = ['hekim', 'admin', 'osgb_admin'].includes(profile?.role ?? '');
  // Personel notlarını yalnızca admin/osgb_admin yazabilir (RLS aynı kapsamı uygular).
  const canManageNotes = ['admin', 'osgb_admin'].includes(profile?.role ?? '');
  const cikarModalRef = useRef('');
  const editModalRef = useRef('');

  const [tab, setTab] = useState<TabKey>('genel');
  const [detay, setDetay] = useState<PersonelDetay | null>(null);
  const [zengin, setZengin] = useState<PersonelZenginlestirme>(BOS_ZENGIN);
  const [evraklar, setEvraklar] = useState<PersonelEvrakSatir[]>([]);
  const [gereksinimler, setGereksinimler] = useState<KisiGereksinim[]>([]);
  const [sektor, setSektor] = useState<string | null>(null);
  // Evrak türü kataloğu: global referans veri → merkezi SWR cache (uygulama başına tek
  // istek, modallar arası dedupe). Önceden her modal açılışında yeniden çekiliyordu.
  const { data: evrakTurleri } = useTabData<EvrakTuru[]>('evrak-turleri', () => fetchEvrakTurleri());
  const belgeTuruOptions = useMemo<BelgeTuruOption[]>(
    () => (evrakTurleri ?? [])
      .filter((t) => t.ownerType === 'personel' && !t.isHealth)
      .map((t) => ({ value: t.id, label: t.name, code: t.code })),
    [evrakTurleri],
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      // BAĞIMSIZ istekler PARALEL çalışır. Önceden bu istekler SIRAYLA bekleniyordu
      // (detay → evrak → gereksinim → zenginleştirme → sektör = 5 ardışık round-trip).
      // Modal açılış gecikmesinin ana kaynağı bu waterfall'dı; artık 2 faza iner.
      const [d, ev] = await Promise.all([
        fetchFirmaPersonelDetay(personelId),
        fetchPersonelEvraklari(personelId),
      ]);
      const kodlar = ev.map((e) => e.documentTypeCode).filter((x): x is string => !!x);
      // Gereksinim (evrak+kodlara bağlı), zenginleştirme ve sektör BİRBİRİNDEN bağımsız → paralel.
      const [reqs, zMap, sek] = await Promise.all([
        fetchKisiGereksinimleri(d.occupationId, d.tehlikeSinifi, kodlar),
        enrichPersoneller([{ id: personelId, occupation_id: d.occupationId }], d.tehlikeSinifi),
        fetchOccupationSektor(d.occupationId).catch(() => null),
      ]);
      setDetay(d);
      setEvraklar(ev);
      setGereksinimler(reqs);
      setZengin(zMap[personelId] ?? BOS_ZENGIN);
      setSektor(sek);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Personel detayı yüklenemedi.');
    } finally {
      setLoading(false);
    }
  }, [personelId]);

  useEffect(() => { void load(); }, [load]);

  // ── SEKME VERİ PREFETCH ──
  // Modal açılır açılmaz, yüksek olasılıkla açılacak sekmelerin verisini ARKA PLANDA
  // merkezi SWR cache'ine hazırla. Kullanıcı sekmeye tıkladığında veri cache'den ANINDA
  // gelir (spinner yok). Modal açılışını BLOKLAMAZ; yalnızca liste/metadata çeker.
  useEffect(() => {
    preloadTabData(['personel-egitimleri', personelId], () => fetchPersonelEgittimleri(personelId));
    preloadTabData(['personel-saglik', personelId], () => fetchPersonelSaglikMuayeneleri(personelId));
    preloadTabData(['personel-notlar', personelId], () => fetchPersonelNotlariWithUser(personelId));
  }, [personelId]);

  // ── İşten Çıkar (Personel Detay üst header işlem menüsü) ──
  // Fiziksel silme DEĞİL: personel pasife alınır, işten çıkış tarihi yazılır,
  // geçmiş/evrak/eğitim/sağlık kayıtları korunur. Backend RPC: firma_personel_isten_cikar.
  const openIstenCikar = useCallback(() => {
    if (!detay) return;
    if (cikarModalRef.current) return;
    const id = openModal({
      dedupeKey: `personel-isten-cikar:${detay.id}`,
      title: 'Personeli İşten Çıkar',
      description: 'İşten çıkarma işlemi personeli aktif listeden çıkarır; geçmiş kayıtları korunur.',
      variant: 'confirmation',
      width: 480,
      minWidth: 380,
      height: 420,
      showFooter: false,
      closable: true,
      bodyLayout: 'scroll',
      // Guard ref'i modalın HER kapanış yolunda (X / ESC / içerideki İptal) temizlenir;
      // aksi halde "İşten Çıkar" butonu bir daha modal açmaz.
      onClose: () => { cikarModalRef.current = ''; },
      content: (
        <IstenCikarModal
          personelId={detay.id}
          adSoyad={detay.adSoyad}
          onClose={() => { closeModal(cikarModalRef.current); cikarModalRef.current = ''; }}
          onDone={() => { void load(); onChanged(); }}
        />
      ),
    });
    cikarModalRef.current = id;
  }, [detay, openModal, closeModal, load, onChanged]);

  // ── Personel Düzenle (gerçek güncelleme akışı) ──
  const openEdit = useCallback(() => {
    if (!detay) return;
    if (editModalRef.current) return;
    const id = openModal({
      dedupeKey: `personel-duzenle:${detay.id}`,
      title: 'Personel Bilgilerini Düzenle',
      description: 'Temel bilgileri güncelleyin. Meslek değiştirilirse gereksinimler otomatik yeniden hesaplanır.',
      variant: 'form',
      width: 720,
      minWidth: 480,
      height: 620,
      showFooter: false,
      closable: true,
      bodyLayout: 'fill',
      // Guard ref'i modalın HER kapanış yolunda (X / ESC / içerideki İptal) temizlenir;
      // aksi halde "Düzenle" butonu bir daha modal açmaz.
      onClose: () => { editModalRef.current = ''; },
      content: (
        <PersonelDuzenleModal
          detay={detay}
          onClose={() => { closeModal(editModalRef.current); editModalRef.current = ''; }}
          onSaved={() => { void load(); onChanged(); }}
        />
      ),
    });
    editModalRef.current = id;
  }, [detay, openModal, closeModal, load, onChanged]);

  const gereksinimSatirlar: GereksinimSatir[] = gereksinimler.map((g) => {
    const kodlar = evrakKodlariForAcceptedTypes(g.acceptedTypes);
    const evrak = evraklar.find((e) => e.documentTypeCode && kodlar.some((c) => codeMatches(e.documentTypeCode as string, c))) ?? null;
    return { g, evrak };
  });

  const calismaMetni = detay ? calismaSuresiMetni(detay.iseGirisTarihi, detay.istenCikisTarihi, detay.isActive) : '';

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      {detay ? (
        <div className="flex-shrink-0 px-4 md:px-6 py-4 border-b border-background-300/60 dark:border-background-400/30">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary-500 flex items-center justify-center flex-shrink-0">
              <span className="text-inverse font-bold">{basHarfler(detay.adSoyad)}</span>
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-bold text-foreground-950">{detay.adSoyad}</h2>
                <StatusBadge tone={detay.isActive ? 'success' : 'neutral'}>
                  {detay.isActive ? 'Aktif Çalışan' : 'İşten Ayrılmış'}
                </StatusBadge>
              </div>
              <p className="isg-text-caption text-foreground-500 truncate">
                {detay.gorev}
                {detay.occupationCode !== '—' ? ` | İŞKUR: ${detay.occupationCode}` : ''}
                {sektor ? ` | ${sektor}` : ''}
              </p>
            </div>
            <div className="hidden lg:block text-right flex-shrink-0">
              <p className="isg-text-caption text-foreground-500">Firma: {detay.firmaUnvan}</p>
              <p className="isg-text-caption text-foreground-400">
                İşe giriş: {formatTarih(detay.iseGirisTarihi)}
                {calismaMetni ? ` • ${calismaMetni}` : ''}
              </p>
            </div>
            {detay.isActive && (
              <ActionMenu
                align="end"
                items={[
                  { label: 'İşten Çıkar', icon: 'ri-user-unfollow-line', tone: 'danger', onClick: openIstenCikar },
                ]}
              />
            )}
          </div>
          <p className="lg:hidden mt-2 isg-text-caption text-foreground-400">
            Firma: {detay.firmaUnvan} • İşe giriş: {formatTarih(detay.iseGirisTarihi)}
            {calismaMetni ? ` • ${calismaMetni}` : ''}
          </p>
        </div>
      ) : null}

      {/* Tabs */}
      <div className="flex-shrink-0 px-4 md:px-6 pt-3 overflow-x-auto">
        <div className="flex items-center gap-1 border-b border-background-300/60 dark:border-background-400/30 min-w-max">
          {TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-1.5 px-3 py-2 text-sm whitespace-nowrap border-b-2 transition-colors cursor-pointer ${
                tab === t.key
                  ? 'border-primary-500 text-primary-600 dark:text-primary-400 font-medium'
                  : 'border-transparent text-foreground-500 hover:text-foreground-800'
              }`}
            >
              <i className={t.icon} /> {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6">
        {loading ? (
          <div className="flex justify-center py-20"><Loading size="lg" text="Personel detayı yükleniyor..." /></div>
        ) : error || !detay ? (
          <ErrorState message={error ?? 'Personel bulunamadı.'} onRetry={load} />
        ) : (
          <>
            {tab === 'genel' && (
              <GenelBilgilerTab
                detay={detay}
                zengin={zengin}
                gereksinimler={gereksinimler}
                meslekGrup={sektor}
                canViewHealthDetail={canManageHealth}
                onGoEvrak={() => setTab('evrak')}
                onEdit={openEdit}
              />
            )}
            {tab === 'mesleki' && (
              <MeslekiBelgelerTab
                rows={gereksinimSatirlar}
                evraklar={evraklar}
                firmaId={detay.firmaId ?? ''}
                personelId={detay.id}
                belgeTuruOptions={belgeTuruOptions}
                onChanged={() => { void load(); onChanged(); }}
              />
            )}
            {tab === 'egitim' && <EgitimlerTab personelId={detay.id} firmaId={detay.firmaId ?? ''} onChanged={() => { void load(); onChanged(); }} />}
            {tab === 'saglik' && <SaglikTab personelId={detay.id} firmaId={detay.firmaId ?? ''} canManage={canManageHealth} onChanged={() => { void load(); onChanged(); }} />}
            {tab === 'evrak' && (
              <EvraklarTab
                evraklar={evraklar}
                firmaId={detay.firmaId ?? ''}
                personelId={detay.id}
                belgeTuruOptions={belgeTuruOptions}
                onChanged={() => { void load(); onChanged(); }}
              />
            )}
            {tab === 'gecmis' && (
              <NotlarGecmisTab
                personelId={detay.id}
                olusturmaTarihi={detay.createdAt}
                isActive={detay.isActive}
                istenCikisTarihi={detay.istenCikisTarihi}
                canManageNotes={canManageNotes}
                onChanged={() => { void load(); onChanged(); }}
              />
            )}
          </>
        )}
      </div>

      {/* Footer */}
      <div className="flex-shrink-0 flex items-center justify-end gap-2 px-4 md:px-6 py-3 border-t border-background-300/60 dark:border-background-400/30">
        <Button variant="secondary" onClick={onClose}>Kapat</Button>
      </div>
    </div>
  );
}