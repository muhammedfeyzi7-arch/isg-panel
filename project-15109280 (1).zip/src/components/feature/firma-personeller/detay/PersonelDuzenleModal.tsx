import { useEffect, useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import PhoneInput from '@/components/ui/PhoneInput';
import TcKimlikInput from '@/components/ui/TcKimlikInput';
import DatePicker from '@/components/ui/DatePicker';
import { toast } from '@/hooks/useToast';
import MeslekAramaInput from '../MeslekAramaInput';
import {
  updateFirmaPersonel,
  type FirmaPersonelGuncellePayload,
  type IskurMeslekSecim,
  type PersonelDetay,
} from '@/lib/firmaPersonelService';
import { fetchPersonelTcKimlik } from '@/lib/personelService';

interface Props {
  detay: PersonelDetay;
  onClose: () => void;
  onSaved: () => void;
}

/**
 * Personel Düzenle — Personel Detay üst header'ındaki "Düzenle" aksiyonunun gerçek
 * güncelleme akışıdır (Shared Modal shell içinde açılır). Yalnızca temel bilgiler
 * güncellenir; meslek değişirse occupation_id/code/name birlikte yazılır ve gereksinim
 * motoru bir sonraki yüklemede yeni mesleğe göre yeniden hesaplanır. Firma kapsamı
 * RLS + trigger ile korunur.
 */
export default function PersonelDuzenleModal({ detay, onClose, onSaved }: Props) {
  const [adSoyad, setAdSoyad] = useState(detay.adSoyad);
  const [tc, setTc] = useState('');
  // GÜVENLİK: tam T.C. kimlik no liste/detay ile TAŞINMAZ. Düzenleme açılınca yetkili
  // RPC ile alınır; tcOmit=true iken GÖNDERİLMEZ → boş alan mevcut numarayı SİLMEZ.
  const [tcOmit, setTcOmit] = useState(true);
  const [telefon, setTelefon] = useState(detay.telefon === '—' ? '' : detay.telefon);
  const [email, setEmail] = useState(detay.email === '—' ? '' : detay.email);
  const [iseGiris, setIseGiris] = useState(detay.iseGirisTarihi === '—' ? '' : detay.iseGirisTarihi);
  const [meslek, setMeslek] = useState<IskurMeslekSecim | null>(
    detay.occupationId
      ? {
          occupationId: detay.occupationId,
          occupationCode: detay.occupationCode,
          name: detay.occupationName,
          sektor: null,
          level: null,
          kuralVar: false,
          mykKapsaminda: false,
          mykList: [],
        }
      : null,
  );
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Tam numara yalnızca yetkili düzenleme anında sunucudan (audit'li RPC) alınır.
  useEffect(() => {
    let cancelled = false;
    fetchPersonelTcKimlik(detay.id)
      .then((full) => {
        if (!cancelled && full) {
          setTc(full);
          setTcOmit(false);
        }
      })
      .catch(() => {
        // Yetki yok / erişilemedi → alan boş kalır ve kaydederken GÖNDERİLMEZ.
      });
    return () => { cancelled = true; };
  }, [detay.id]);

  function validate(): boolean {
    const e: Record<string, string> = {};
    if (!adSoyad.trim()) e.adSoyad = 'Ad Soyad zorunludur.';
    if (tc.trim() && !/^\d{11}$/.test(tc.trim())) e.tc = 'T.C. kimlik no 11 haneli olmalıdır.';
    if (!iseGiris) e.iseGiris = 'İşe giriş tarihi zorunludur.';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSave() {
    if (saving) return;
    if (!validate()) return;
    setSaving(true);
    try {
      const trimmed = adSoyad.trim().replace(/\s+/g, ' ');
      const parts = trimmed.split(' ').filter(Boolean);
      const ad = parts[0] ?? '';
      const soyad = parts.slice(1).join(' ');

      await updateFirmaPersonel(detay.id, (() => {
        const patch: FirmaPersonelGuncellePayload = {
          ad,
          soyad,
          telefon: telefon || null,
          email: email || null,
          iseGirisTarihi: iseGiris || null,
          occupationId: meslek?.occupationId ?? null,
          occupationCode: meslek?.occupationCode ?? null,
          occupationName: meslek?.name ?? null,
        };
        // Tam numara YALNIZCA yüklendiğinde veya kullanıcı değiştirdiğinde gönderilir.
        if (!tcOmit) patch.tcKimlikNo = tc || null;
        return patch;
      })());
      toast.success('Personel güncellendi');
      onSaved();
      onClose();
    } catch (err) {
      toast.error('Güncellenemedi', err instanceof Error ? err.message : 'Beklenmeyen bir hata oluştu.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 md:p-5 space-y-4">
        <section className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4">
          <h3 className="text-sm font-semibold text-foreground-900 mb-3">Kişisel Bilgiler</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="Ad Soyad"
              value={adSoyad}
              onChange={(e) => setAdSoyad(e.target.value)}
              leftIcon={<i className="ri-user-line" />}
              required
              error={errors.adSoyad}
            />
            <TcKimlikInput
              label="T.C. Kimlik No"
              value={tc}
              onChange={(v) => { setTc(v); setTcOmit(false); }}
              leftIcon={<i className="ri-id-card-line" />}
              error={errors.tc}
            />
            <PhoneInput label="Telefon" value={telefon} onChange={setTelefon} leftIcon={<i className="ri-phone-line" />} />
            <Input label="E-posta" type="email" value={email} onChange={(e) => setEmail(e.target.value)} leftIcon={<i className="ri-mail-line" />} />
            <DatePicker label="İşe Giriş Tarihi" value={iseGiris} onChange={(e) => setIseGiris(e.target.value)} required error={errors.iseGiris} />
          </div>
        </section>

        <section className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4">
          <h3 className="text-sm font-semibold text-foreground-900 mb-3">Görev / Meslek</h3>
          <MeslekAramaInput value={meslek} onChange={setMeslek} />
        </section>
      </div>

      <div className="flex-shrink-0 flex items-center justify-end gap-2 px-4 md:px-5 py-3 border-t border-background-300/60 dark:border-background-400/30">
        <Button variant="secondary" onClick={onClose} disabled={saving}>İptal</Button>
        <Button variant="primary" leftIcon={<i className="ri-save-line" />} isLoading={saving} onClick={handleSave}>Kaydet</Button>
      </div>
    </div>
  );
}