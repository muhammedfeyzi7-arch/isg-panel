import { useState } from 'react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Loading from '@/components/ui/Loading';
import { toast } from '@/hooks/useToast';
import {
  addPersonelNot,
  deletePersonelNot,
  fetchPersonelNotlariWithUser,
  type PersonelNotKayit,
} from '@/lib/firmaPersonelService';
import { useTabData } from '@/lib/tabDataCache';
import { formatTarihSaat } from '../personelFirmaUi';

interface Props {
  personelId: string;
  olusturmaTarihi: string;
  isActive: boolean;
  istenCikisTarihi: string | null;
  /** Not ekleme/silme yalnızca admin/osgb_admin (RLS ile aynı kapsam). */
  canManageNotes: boolean;
  onChanged: () => void;
}

interface Olay {
  id: string;
  tarih: string;
  baslik: string;
  aciklama: string;
  yazan: string;
  ikon: string;
  tone: 'info' | 'success' | 'neutral';
  notId?: string;
}

export default function NotlarGecmisTab({ personelId, olusturmaTarihi, isActive, istenCikisTarihi, canManageNotes, onChanged }: Props) {
  // Merkezi SWR cache: sekmeden çıkıp geri dönüldüğünde veri ANINDA cache'den gelir
  // (spinner yok, tekrar istek yok — dedupe).
  const { data, isInitialLoading, refresh } = useTabData<PersonelNotKayit[]>(
    ['personel-notlar', personelId],
    () => fetchPersonelNotlariWithUser(personelId),
  );
  const notlar = data ?? [];
  const [metin, setMetin] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleAdd() {
    if (!metin.trim()) return;
    setSaving(true);
    try {
      await addPersonelNot(personelId, metin);
      toast.success('Not eklendi');
      setMetin('');
      refresh();
      onChanged();
    } catch (e) {
      toast.error('Eklenemedi', e instanceof Error ? e.message : undefined);
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      await deletePersonelNot(id);
      toast.success('Not silindi');
      refresh();
    } catch (e) {
      toast.error('Silinemedi', e instanceof Error ? e.message : undefined);
    }
  }

  const olaylar: Olay[] = [
    {
      id: 'created',
      tarih: olusturmaTarihi,
      baslik: 'Personel oluşturuldu',
      aciklama: 'Personel kaydı oluşturuldu.',
      yazan: 'Sistem',
      ikon: 'ri-user-add-line',
      tone: 'success',
    },
    ...(isActive
      ? []
      : [
          {
            id: 'isten-cikarildi',
            tarih: istenCikisTarihi ?? olusturmaTarihi,
            baslik: 'Personel işten çıkarıldı',
            aciklama: 'Personel işten ayrılmış olarak işaretlendi ve aktif personel listesinden çıkarıldı. Geçmiş kayıtları korunur.',
            yazan: 'Sistem',
            ikon: 'ri-user-unfollow-line',
            tone: 'neutral' as const,
          },
        ]),
    ...notlar.map<Olay>((n) => ({
      id: n.id,
      tarih: n.createdAt,
      baslik: 'Not eklendi',
      aciklama: n.icerik,
      yazan: n.yazanAd,
      ikon: 'ri-sticky-note-line',
      tone: 'info',
      notId: n.id,
    })),
  ].sort((a, b) => new Date(b.tarih).getTime() - new Date(a.tarih).getTime());

  const toneCls: Record<Olay['tone'], string> = {
    success: 'bg-success-100 text-success-700 dark:bg-success-500/20 dark:text-success-400',
    info: 'bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-400',
    neutral: 'bg-background-200 text-foreground-600 dark:bg-background-300/40',
  };

  return (
    <Card title="Notlar ve Geçmiş" icon="ri-history-line" subtitle="Personele ilişkin notlar ve tüm işlemler zaman çizelgesinde takip edilebilir.">
      {isInitialLoading ? (
        <div className="flex justify-center py-10"><Loading size="lg" text="Geçmiş yükleniyor..." /></div>
      ) : (
        <ol className="relative space-y-4 pl-1">
          {olaylar.map((o) => (
            <li key={o.id} className="flex gap-3">
              <span className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${toneCls[o.tone]}`}>
                <i className={`${o.ikon} text-sm`} />
              </span>
              <div className="min-w-0 flex-1 pb-4 border-b border-background-200/50 dark:border-background-400/15">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-sm font-medium text-foreground-900">{o.baslik}</p>
                  <span className="isg-text-caption text-foreground-400 flex-shrink-0">{formatTarihSaat(o.tarih)}</span>
                </div>
                <p className="mt-0.5 isg-text-caption text-foreground-600 whitespace-pre-wrap break-words">{o.aciklama}</p>
                <div className="mt-1 flex items-center gap-2">
                  <span className="isg-text-caption text-foreground-400">— {o.yazan}</span>
                  {o.notId && canManageNotes && (
                    <button type="button" onClick={() => handleDelete(o.notId as string)} className="isg-text-caption text-danger-500 hover:text-danger-600 cursor-pointer" aria-label="Notu sil">
                      <i className="ri-delete-bin-line" />
                    </button>
                  )}
                </div>
              </div>
            </li>
          ))}
        </ol>
      )}

      {canManageNotes ? (
        <div className="mt-3 flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={metin}
            onChange={(e) => setMetin(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleAdd(); }}
            placeholder="Personele ilişkin notunuzu buraya yazabilirsiniz..."
            className="isg-input flex-1"
          />
          <Button variant="primary" size="md" isLoading={saving} leftIcon={<i className="ri-save-line" />} onClick={handleAdd}>Not Ekle</Button>
        </div>
      ) : (
        <p className="mt-3 isg-text-caption text-foreground-400 flex items-center gap-1">
          <i className="ri-lock-2-line" /> Personel notlarını yalnızca yetkili kullanıcılar ekleyebilir.
        </p>
      )}
    </Card>
  );
}