import { useMemo, useState } from 'react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import StatusBadge from '@/components/ui/StatusBadge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import Select from '@/components/ui/Select';
import Input from '@/components/ui/Input';
import DatePicker from '@/components/ui/DatePicker';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import { toast } from '@/hooks/useToast';
import { uploadEvrak } from '@/lib/evrakService';
import { useEvrakOnizleme } from '@/components/feature/evrak/useEvrakOnizleme';
import { gunFarki, type BelgeTuruOption, type KisiGereksinim, type PersonelEvrakSatir } from '@/lib/firmaPersonelService';
import {
  dosyaBoyutMetni,
  dosyaIkonu,
  evrakStatusLabel,
  evrakStatusVariant,
  formatTarih,
  kalanGunMetni,
} from '../personelFirmaUi';

export interface GereksinimSatir {
  g: KisiGereksinim;
  evrak: PersonelEvrakSatir | null;
}

interface Props {
  rows: GereksinimSatir[];
  evraklar: PersonelEvrakSatir[];
  firmaId: string;
  personelId: string;
  belgeTuruOptions: BelgeTuruOption[];
  onChanged: () => void;
}

function durumBadge(g: KisiGereksinim) {
  if (g.durum === 'tamamlandi') return <StatusBadge tone="success">Tamamlandı</StatusBadge>;
  if (g.durum === 'eksik') return <StatusBadge tone="danger">Eksik</StatusBadge>;
  if (g.durum === 'opsiyonel') return <StatusBadge tone="neutral">Opsiyonel</StatusBadge>;
  return <StatusBadge tone="neutral">Gerekli Değil</StatusBadge>;
}

function turBelge(g: KisiGereksinim) {
  if (!g.required) return <Badge variant="secondary">Opsiyonel</Badge>;
  return <Badge variant="accent">Zorunlu</Badge>;
}

export default function MeslekiBelgelerTab({ rows, evraklar, firmaId, personelId, belgeTuruOptions, onChanged }: Props) {
  const { openEvrak, evrakPreviewNode } = useEvrakOnizleme();
  const [showAdd, setShowAdd] = useState(false);
  const [belgeTuruId, setBelgeTuruId] = useState('');
  const [belgeAdi, setBelgeAdi] = useState('');
  const [belgeNo, setBelgeNo] = useState('');
  const [tarih, setTarih] = useState('');
  const [gecerlilik, setGecerlilik] = useState('');
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [saving, setSaving] = useState(false);

  const ozet = useMemo(() => {
    const tamam = rows.filter((r) => r.g.durum === 'tamamlandi').length;
    const eksik = rows.filter((r) => r.g.durum === 'eksik').length;
    // Beklemede: yüklü belgesi olup henüz doğrulanmamış gereksinimler (gerçek evrak durumundan).
    const beklemede = rows.filter((r) => r.evrak && (r.evrak.status === 'pending' || r.evrak.status === 'verification_required')).length;
    return { tamam, eksik, beklemede };
  }, [rows]);

  // Belgeyi SİSTEM İÇİNDE aç (yeni sekme YOK) — merkezi preview motoru.
  function goruntule(e: PersonelEvrakSatir) {
    openEvrak({
      evrakId: e.id,
      title: e.documentTypeName || e.title,
      fileName: e.fileName,
      mimeType: e.mimeType,
      fileSize: e.fileSize,
      meta: {
        belgeAdi: e.documentTypeName || e.title,
        durum: evrakStatusLabel(e.status),
        belgeTarihi: e.documentDate ? formatTarih(e.documentDate) : undefined,
        gecerlilik: e.validUntil ? formatTarih(e.validUntil) : undefined,
        yuklemeTarihi: e.createdAt ? formatTarih(e.createdAt) : undefined,
      },
    });
  }

  async function handleUpload() {
    const file = files.find((f) => f.raw)?.raw;
    if (!belgeTuruId) {
      toast.warning('Belge türü seçin');
      return;
    }
    if (!file) {
      toast.warning('Dosya seçin');
      return;
    }
    setSaving(true);
    try {
      await uploadEvrak({
        ownerType: 'personel',
        firmaId,
        personelId,
        documentTypeId: belgeTuruId,
        title: belgeAdi.trim() || file.name,
        belgeNo: belgeNo.trim() || null,
        documentDate: tarih || null,
        validUntil: gecerlilik || null,
        file,
      });
      toast.success('Belge yüklendi');
      setShowAdd(false);
      setBelgeTuruId('');
      setBelgeAdi('');
      setBelgeNo('');
      setTarih('');
      setGecerlilik('');
      setFiles([]);
      onChanged();
    } catch (e) {
      toast.error('Yüklenemedi', e instanceof Error ? e.message : undefined);
    } finally {
      setSaving(false);
    }
  }

  const columns: TableColumn<GereksinimSatir>[] = [
    {
      key: 'tur',
      header: 'Belge Türü',
      render: (r) => (
        <div className="flex items-center gap-2 min-w-[200px]">
          <span className="w-8 h-8 rounded-md bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-file-shield-2-line text-primary-600 dark:text-primary-400 text-sm" />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground-800 truncate">{r.g.name}</p>
            <div className="mt-0.5">{turBelge(r.g)}</div>
          </div>
        </div>
      ),
    },
    {
      key: 'aciklama',
      header: 'Açıklama',
      render: (r) => (
        <span className="text-sm text-foreground-600 max-w-[260px] inline-block whitespace-normal">
          {r.g.legalBasis || (r.g.acceptedTypes.length > 0 ? `Kabul edilen belgeler: ${r.g.acceptedTypes.join(' / ')}` : '—')}
        </span>
      ),
    },
    { key: 'durum', header: 'Durum', render: (r) => durumBadge(r.g) },
    { key: 'belge_tarihi', header: 'Belge Tarihi', render: (r) => <span className="text-sm text-foreground-700">{formatTarih(r.evrak?.documentDate)}</span> },
    { key: 'yenileme', header: 'Yenileme Tarihi', render: (r) => <span className="text-sm text-foreground-700">{formatTarih(r.evrak?.validUntil)}</span> },
    {
      key: 'kalan',
      header: 'Kalan Süre',
      render: (r) => {
        const k = gunFarki(r.evrak?.validUntil);
        return k !== null && k < 0 ? (
          <StatusBadge tone="danger">{kalanGunMetni(k)}</StatusBadge>
        ) : (
          <span className="text-sm text-foreground-700">{kalanGunMetni(k)}</span>
        );
      },
    },
    {
      key: 'islemler',
      header: 'İşlemler',
      align: 'right',
      render: (r) => (
        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
          {r.evrak ? (
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={() => goruntule(r.evrak!)}>Görüntüle</Button>
          ) : (
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-upload-2-line" />} onClick={() => {
              setShowAdd(true);
              const targetCode = r.g.belgeTuruKodu;
              const found = targetCode
                ? belgeTuruOptions.find((o) => o.code.toLocaleUpperCase('tr') === targetCode.toLocaleUpperCase('tr'))
                : null;
              setBelgeTuruId(found?.value ?? '');
            }}>Yükle</Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-4">
      <Card
        title="Mesleki Belgeler"
        icon="ri-file-shield-2-line"
        subtitle="Seçilen meslek için mevzuata göre gereken mesleki yeterlilik, ustalık, diploma, sertifika ve diğer belgeler. Gerekli olmayan belgeler gösterilmez."
        actions={
          <div className="flex items-center gap-2">
            <div className="px-2.5 py-1.5 rounded-md bg-success-50 dark:bg-success-500/10 border border-success-200/60 dark:border-success-400/25 text-center min-w-[64px]">
              <p className="text-sm font-bold text-success-700 dark:text-success-400 leading-none tabular-nums">{ozet.tamam}</p>
              <p className="isg-text-caption text-success-700/80 dark:text-success-300 mt-1">Tamamlandı</p>
            </div>
            <div className="px-2.5 py-1.5 rounded-md bg-danger-50 dark:bg-danger-500/10 border border-danger-200/60 dark:border-danger-400/25 text-center min-w-[64px]">
              <p className="text-sm font-bold text-danger-700 dark:text-danger-400 leading-none tabular-nums">{ozet.eksik}</p>
              <p className="isg-text-caption text-danger-700/80 dark:text-danger-300 mt-1">Eksik</p>
            </div>
            <div className="px-2.5 py-1.5 rounded-md bg-background-100 dark:bg-background-200/50 border border-background-300/60 dark:border-background-400/30 text-center min-w-[64px]">
              <p className="text-sm font-bold text-foreground-700 leading-none tabular-nums">{ozet.beklemede}</p>
              <p className="isg-text-caption text-foreground-500 mt-1">Beklemede</p>
            </div>
          </div>
        }
      >
        {rows.length === 0 ? (
          <p className="isg-text-caption text-foreground-400 py-4">Bu meslek için mesleki belge gereksinimi bulunmuyor.</p>
        ) : (
          <Table data={rows} columns={columns} keyExtractor={(r) => r.g.group} density="compact" />
        )}
      </Card>

      {/* Yüklenen Belgeler */}
      <Card
        title={`Yüklenen Belgeler (${evraklar.length})`}
        icon="ri-folders-line"
        subtitle="Bu personelin yüklenmiş mesleki belgeleri."
        actions={<Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={() => setShowAdd((s) => !s)}>Yeni Belge Ekle</Button>}
      >
        {showAdd && (
          <div className="mb-4 rounded-lg border border-primary-200/60 dark:border-primary-400/25 bg-primary-50/40 dark:bg-primary-500/10 p-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Select label="Belge Türü" placeholder="Belge türü seçin" options={belgeTuruOptions} value={belgeTuruId} onChange={(e) => setBelgeTuruId(e.target.value)} />
            <Input label="Belge Adı" value={belgeAdi} onChange={(e) => setBelgeAdi(e.target.value)} placeholder="Belge adı (boşsa dosya adı kullanılır)" maxLength={120} />
            <Input label="Belge No (varsa)" value={belgeNo} onChange={(e) => setBelgeNo(e.target.value)} placeholder="Belge numarası" maxLength={60} />
            <DatePicker label="Düzenleme Tarihi" value={tarih} onChange={(e) => setTarih(e.target.value)} />
            <DatePicker label="Geçerlilik Tarihi (varsa)" value={gecerlilik} onChange={(e) => setGecerlilik(e.target.value)} />
            <div className="sm:col-span-2">
              <FileUpload
                multiple={false}
                files={files}
                onChange={setFiles}
                label="Belge Dosyası"
                heading="Dosyayı buraya sürükleyin veya seçin"
                browseLabel="Dosya Seç"
                helpText="PDF, JPG, PNG (Maks. 10 MB)"
              />
            </div>
            <div className="sm:col-span-2 flex items-center justify-end gap-2">
              <Button variant="secondary" size="sm" onClick={() => setShowAdd(false)} disabled={saving}>Vazgeç</Button>
              <Button variant="primary" size="sm" isLoading={saving} leftIcon={<i className="ri-upload-2-line" />} onClick={handleUpload}>Yükle</Button>
            </div>
          </div>
        )}

        {evraklar.length === 0 ? (
          <p className="isg-text-caption text-foreground-400 py-2">Henüz belge yüklenmedi.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {evraklar.map((e) => (
              <div key={e.id} className="flex items-center gap-3 p-3 rounded-lg border border-background-300/50 dark:border-background-400/25">
                <span className="w-10 h-12 rounded-md bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
                  <i className={`${dosyaIkonu(e.mimeType)} text-foreground-500`} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-foreground-800 truncate">{e.documentTypeName || e.title}</p>
                  <p className="isg-text-caption text-foreground-500 truncate">{e.fileName || e.title}</p>
                  <p className="isg-text-caption text-foreground-400">
                    {dosyaBoyutMetni(e.fileSize)}{e.documentDate ? ` · ${formatTarih(e.documentDate)}` : ''}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1.5 flex-shrink-0">
                  <StatusBadge tone={evrakStatusVariant(e.status) === 'success' ? 'success' : evrakStatusVariant(e.status) === 'danger' ? 'danger' : evrakStatusVariant(e.status) === 'warning' ? 'warning' : 'neutral'}>
                    {evrakStatusLabel(e.status)}
                  </StatusBadge>
                  <button type="button" onClick={() => goruntule(e)} className="text-foreground-500 hover:text-primary-600 cursor-pointer" aria-label="Görüntüle">
                    <i className="ri-eye-line" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {evrakPreviewNode}
    </div>
  );
}