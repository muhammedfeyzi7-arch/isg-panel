import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import StatusBadge from '@/components/ui/StatusBadge';
import {
  hazardSinifiLabel,
  type KisiGereksinim,
  type PersonelDetay,
  type PersonelZenginlestirme,
} from '@/lib/firmaPersonelService';
import {
  EGITIM_DURUM_LABEL,
  SAGLIK_DURUM_LABEL,
  SAGLIK_UYGUNLUK_LABEL,
  egitimDurumVariant,
  formatTarih,
  gereksinimVariant,
  kalanGunMetni,
  maskTc,
  saglikDurumVariant,
  saglikUygunlukVariant,
} from '../personelFirmaUi';

interface Props {
  detay: PersonelDetay;
  zengin: PersonelZenginlestirme;
  gereksinimler: KisiGereksinim[];
  meslekGrup: string | null;
  /** KVKK: sağlık TIBBİ DETAYINI görme yetkisi (yalnızca hekim/osgb/admin). */
  canViewHealthDetail: boolean;
  onGoEvrak: () => void;
  onEdit: () => void;
}

function BilgiSatir({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1.5">
      <span className="isg-text-caption text-foreground-500 flex-shrink-0">{label}</span>
      <span className="text-sm text-foreground-800 text-right min-w-0 truncate">{value}</span>
    </div>
  );
}

function YenilemeBlok({
  icon,
  title,
  tarihLabel,
  tarih,
  yenileme,
  kalan,
  durumLabel,
  durumVariant,
}: {
  icon: string;
  title: string;
  tarihLabel: string;
  tarih: string | null;
  yenileme: string | null;
  kalan: string;
  durumLabel: string;
  durumVariant: ReturnType<typeof egitimDurumVariant>;
}) {
  return (
    <div className="rounded-lg border border-background-300/50 dark:border-background-400/25 p-3">
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="flex items-center gap-2 text-sm font-medium text-foreground-800">
          <i className={`${icon} text-foreground-500`} /> {title}
        </span>
        <StatusBadge tone={durumVariant === 'success' ? 'success' : durumVariant === 'warning' ? 'warning' : durumVariant === 'danger' ? 'danger' : 'neutral'}>
          {durumLabel}
        </StatusBadge>
      </div>
      <BilgiSatir label={tarihLabel} value={formatTarih(tarih)} />
      <BilgiSatir label="Sonraki Yenileme" value={formatTarih(yenileme)} />
      <BilgiSatir label="Kalan Süre" value={kalan} />
      <p className="mt-2 pt-2 border-t border-background-300/40 dark:border-background-400/20 isg-text-caption text-foreground-400 flex items-center gap-1">
        <i className="ri-information-line" /> Firmanın tehlike sınıfına göre otomatik hesaplanır.
      </p>
    </div>
  );
}

export default function GenelBilgilerTab({ detay, zengin, gereksinimler, meslekGrup, canViewHealthDetail, onGoEvrak, onEdit }: Props) {
  const requiredReqs = gereksinimler.filter((r) => r.required);
  const tamamlanan = requiredReqs.filter((r) => r.satisfied).length;
  const evrakToplam = zengin.evrak.toplam;
  const evrakVar = zengin.evrak.var_;
  const evrakYuzde = evrakToplam > 0 ? Math.min(100, Math.round((evrakVar / evrakToplam) * 100)) : 0;
  const eksikEvrak = Math.max(0, evrakToplam - evrakVar);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      {/* Kişisel Bilgiler */}
      <Card title="Kişisel Bilgiler" icon="ri-user-line" actions={<Button variant="secondary" size="sm" leftIcon={<i className="ri-edit-line" />} onClick={onEdit}>Düzenle</Button>}>
        <div className="divide-y divide-background-200/50 dark:divide-background-400/15">
          <BilgiSatir label="Ad Soyad" value={detay.adSoyad} />
          <BilgiSatir label="T.C. Kimlik No" value={maskTc(detay.tcKimlikNo)} />
          <BilgiSatir label="Telefon" value={detay.telefon} />
          <BilgiSatir label="E-posta" value={detay.email} />
          <BilgiSatir label="İşe Giriş Tarihi" value={formatTarih(detay.iseGirisTarihi)} />
        </div>
      </Card>

      {/* Görev / Meslek Bilgisi */}
      <Card title="Görev / Meslek Bilgisi" icon="ri-briefcase-4-line">
        <div className="divide-y divide-background-200/50 dark:divide-background-400/15">
          <BilgiSatir label="Görevi" value={detay.gorev} />
          <BilgiSatir label="İŞKUR Meslek Kodu" value={detay.occupationCode} />
          <BilgiSatir label="İŞKUR Meslek Adı" value={detay.occupationName} />
          <BilgiSatir label="Meslek Grubu" value={meslekGrup ?? '—'} />
          <div className="flex items-center justify-between gap-3 py-1.5">
            <span className="isg-text-caption text-foreground-500">Firma Tehlike Sınıfı</span>
            <StatusBadge tone={detay.tehlikeSinifi === 'cok_tehlikeli' ? 'danger' : detay.tehlikeSinifi === 'tehlikeli' ? 'warning' : 'success'}>
              {hazardSinifiLabel(detay.tehlikeSinifi)}
            </StatusBadge>
          </div>
        </div>
      </Card>

      {/* Yenileme Takibi */}
      <Card title="Yenileme Takibi" icon="ri-calendar-check-line" subtitle="Tarihler merkezi motordan firmanın tehlike sınıfına göre otomatik hesaplanır.">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <YenilemeBlok
            icon="ri-book-2-line"
            title="İSG Eğitimi"
            tarihLabel="Son Eğitim Tarihi"
            tarih={zengin.egitim.egitimTarihi}
            yenileme={zengin.egitim.yenilemeTarihi}
            kalan={kalanGunMetni(zengin.egitim.kalanGun)}
            durumLabel={EGITIM_DURUM_LABEL[zengin.egitim.durum]}
            durumVariant={egitimDurumVariant(zengin.egitim.durum)}
          />
          {canViewHealthDetail ? (
            <YenilemeBlok
              icon="ri-heart-pulse-line"
              title="Sağlık Muayenesi"
              tarihLabel="Son Muayene Tarihi"
              tarih={zengin.saglik.muayeneTarihi}
              yenileme={zengin.saglik.yenilemeTarihi}
              kalan={kalanGunMetni(zengin.saglik.kalanGun)}
              durumLabel={SAGLIK_DURUM_LABEL[zengin.saglik.durum]}
              durumVariant={saglikDurumVariant(zengin.saglik.durum)}
            />
          ) : (
            <div className="rounded-lg border border-background-300/50 dark:border-background-400/25 p-3">
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-sm font-medium text-foreground-800">
                  <i className="ri-heart-pulse-line text-foreground-500" /> Sağlık Muayenesi
                </span>
                <StatusBadge tone={saglikUygunlukVariant(zengin.saglik.uygunluk) === 'success' ? 'success' : saglikUygunlukVariant(zengin.saglik.uygunluk) === 'danger' ? 'danger' : 'neutral'}>
                  {SAGLIK_UYGUNLUK_LABEL[zengin.saglik.uygunluk]}
                </StatusBadge>
              </div>
              <p className="mt-2 isg-text-caption text-foreground-400 flex items-center gap-1 leading-relaxed">
                <i className="ri-lock-2-line" /> Sağlık verileri KVKK kapsamında korunmaktadır. Tıbbi detaylar yalnızca yetkili işyeri hekimi tarafından görüntülenir.
              </p>
            </div>
          )}
        </div>
      </Card>

      {/* Mesleki Gereksinimler */}
      <Card title="Mesleki Gereksinimler" icon="ri-shield-check-line" subtitle="Seçilen meslek için gerçek mesleki gereksinimler.">
        {gereksinimler.length === 0 ? (
          <p className="isg-text-caption text-foreground-400">Bu meslek için mesleki belge zorunluluğu bulunmuyor.</p>
        ) : (
          <ul className="space-y-2">
            {gereksinimler.map((r) => (
              <li key={r.group} className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 min-w-0 text-sm text-foreground-800">
                  <i className="ri-file-shield-2-line text-foreground-400 flex-shrink-0" />
                  <span className="truncate">{r.name}</span>
                </span>
                <StatusBadge tone={gereksinimVariant(r.durum) === 'success' ? 'success' : gereksinimVariant(r.durum) === 'danger' ? 'danger' : 'neutral'}>
                  {r.durum === 'tamamlandi' ? 'Tamamlandı' : r.durum === 'eksik' ? 'Eksik' : r.durum === 'opsiyonel' ? 'Opsiyonel' : 'Gerekli Değil'}
                </StatusBadge>
              </li>
            ))}
          </ul>
        )}
        {requiredReqs.length > 0 && (
          <p className="mt-3 isg-text-caption text-foreground-500">{requiredReqs.length} gereksinimden {tamamlanan} tanesi karşılandı.</p>
        )}
      </Card>

      {/* Evrak Durumu */}
      <Card className="lg:col-span-2" title="Evrak Durumu" icon="ri-folder-shield-2-line" subtitle="Kişiye özel gerekli evrakların karşılanma durumu.">
        {zengin.evrak.durum === 'gerekli_degil' ? (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 isg-text-caption text-foreground-500">
              <i className="ri-information-line text-foreground-400" />
              Bu personel için tanımlı zorunlu bir evrak gereksinimi bulunmuyor.
            </div>
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-folder-open-line" />} onClick={onGoEvrak}>Evrakları Gör</Button>
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex-1 min-w-0">
              <div className="h-2 rounded-full bg-background-200 dark:bg-background-300/40 overflow-hidden">
                <div className={`h-full transition-all ${zengin.evrak.durum === 'eksik' ? 'bg-warning-500' : 'bg-success-500'}`} style={{ width: `${evrakYuzde}%` }} />
              </div>
            </div>
            <div className="flex items-center gap-3 flex-shrink-0">
              <span className="text-sm font-semibold text-foreground-900">{evrakVar} / {evrakToplam}</span>
              {eksikEvrak > 0 && <StatusBadge tone="danger">{eksikEvrak} Eksik</StatusBadge>}
              {eksikEvrak === 0 && evrakToplam > 0 && <StatusBadge tone="success">Tamamlandı</StatusBadge>}
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-folder-open-line" />} onClick={onGoEvrak}>Evrakları Gör</Button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
}