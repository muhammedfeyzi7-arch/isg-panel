import { useState } from 'react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import StatusBadge from '@/components/ui/StatusBadge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import { toast } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import { useAuth } from '@/context/AuthContext';
import EvrakDuzenleModal from '@/components/feature/evrak/EvrakDuzenleModal';
import { getEvrakContent, uploadEvrak, deleteEvrak } from '@/lib/evrakService';
import { downloadBytesFile, sanitizeFilename, resolveExtension } from '@/lib/downloadFile';
import { useEvrakOnizleme } from '@/components/feature/evrak/useEvrakOnizleme';
import { gunFarki, fetchPersonelArsivEvraklari, type BelgeTuruOption, type PersonelEvrakSatir } from '@/lib/firmaPersonelService';
import { useTabData } from '@/lib/tabDataCache';
import { base64ToArrayBuffer } from '@/lib/ocrService';
import {
  dosyaBoyutMetni,
  dosyaIkonu,
  evrakStatusLabel,
  evrakStatusVariant,
  formatTarih,
  kalanGunMetni,
} from '../personelFirmaUi';

interface Props {
  evraklar: PersonelEvrakSatir[];
  firmaId: string;
  personelId: string;
  belgeTuruOptions: BelgeTuruOption[];
  onChanged: () => void;
}

function toneOf(status: string): 'success' | 'warning' | 'danger' | 'neutral' {
  const v = evrakStatusVariant(status);
  if (v === 'success') return 'success';
  if (v === 'warning') return 'warning';
  if (v === 'danger') return 'danger';
  return 'neutral';
}

/**
 * EVRAKLAR — Yalnızca personelin GERÇEK dijital dosyaları yönetilir.
 * Belge ŞABLONU / Şablon Kütüphanesi KESİNLİKLE yoktur; bu modül şablon yönetmez.
 */
export default function EvraklarTab({ evraklar, firmaId, personelId, belgeTuruOptions, onChanged }: Props) {
  const { openEvrak, evrakPreviewNode } = useEvrakOnizleme();
  const { confirm } = useConfirmActions();
  const { profile } = useAuth();
  // Silme OSGB tarafıyla sınırlıdır (uzman/admin); firma kullanıcısı belge silemez.
  const canDelete = (profile?.role ?? '') !== 'firma';
  const [duzenlenen, setDuzenlenen] = useState<PersonelEvrakSatir | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [belgeTuruId, setBelgeTuruId] = useState('');
  const [tarih, setTarih] = useState('');
  const [files, setFiles] = useState<UploadFile[]>([]);
  // "Yeni sürüm / revizyon" akışı: bir belgenin yeni sürümü yüklenirken eski belge
  // SİLİNMEZ; revizyon zincirine bağlanır (previousEvrakId) ve tarihçeye taşınır.
  const [revizyonKaynak, setRevizyonKaynak] = useState<PersonelEvrakSatir | null>(null);
  const [saving, setSaving] = useState(false);
  // Arşiv: yeni belge yüklendiğinde eski belge SİLİNMEZ, arşivlenir (revizyon zinciri).
  // Eski sürümler burada görüntülenebilir.
  const [showArsiv, setShowArsiv] = useState(false);
  const { data: arsivData, refresh: refreshArsiv } = useTabData<PersonelEvrakSatir[]>(
    ['personel-evrak-arsiv', personelId],
    () => fetchPersonelArsivEvraklari(personelId),
  );
  const arsiv = arsivData ?? [];

  // Belgeyi SİSTEM İÇİNDE aç (yeni sekme YOK) — merkezi preview motoru.
  function goruntule(r: PersonelEvrakSatir) {
    openEvrak({
      evrakId: r.id,
      title: r.documentTypeName || r.title,
      fileName: r.fileName,
      mimeType: r.mimeType,
      fileSize: r.fileSize,
      meta: {
        belgeAdi: r.documentTypeName || r.title,
        durum: evrakStatusLabel(r.status),
        belgeTarihi: r.documentDate ? formatTarih(r.documentDate) : undefined,
        gecerlilik: r.validUntil ? formatTarih(r.validUntil) : undefined,
        yuklemeTarihi: r.createdAt ? formatTarih(r.createdAt) : undefined,
      },
    });
  }

  // İndir: belge içeriği sunucu tarafından (yetkili) alınır, blob olarak indirilir.
  // Yeni sekme açılmaz, imzalı URL'e CORS bağımlılığı yoktur.
  async function indir(r: PersonelEvrakSatir) {
    try {
      const c = await getEvrakContent(r.id);
      const bytes = base64ToArrayBuffer(c.fileBase64);
      const mime = c.mimeType ?? r.mimeType ?? null;
      const ext = resolveExtension(r.fileName, mime);
      const base = r.documentTypeName || r.title || 'Belge';
      const name = sanitizeFilename(`${base}${ext ? `.${ext}` : ''}`, { fallback: 'Belge' });
      downloadBytesFile(bytes, mime, name);
    } catch (e) {
      toast.error('İndirilemedi', e instanceof Error ? e.message : undefined);
    }
  }

  function sil(r: PersonelEvrakSatir) {
    confirm({
      title: 'Belgeyi sil',
      message: `"${r.documentTypeName || r.title}" belgesi kalıcı olarak silinecek. Bu işlem geri alınamaz.`,
      confirmText: 'Evet, Sil',
      variant: 'danger',
      onConfirm: () => {
        void (async () => {
          try {
            await deleteEvrak(r.id);
            toast.success('Belge silindi');
            refreshArsiv();
            onChanged();
          } catch (e) {
            toast.error('Belge silinemedi', e instanceof Error ? e.message : undefined);
          }
        })();
      },
    });
  }

  async function handleUpload() {
    const file = files.find((f) => f.raw)?.raw;
    if (!belgeTuruId) { toast.warning('Belge türü seçin'); return; }
    if (!file) { toast.warning('Dosya seçin'); return; }
    setSaving(true);
    try {
      await uploadEvrak({
        ownerType: 'personel',
        firmaId,
        personelId,
        documentTypeId: belgeTuruId,
        title: file.name,
        documentDate: tarih || null,
        previousEvrakId: revizyonKaynak?.id ?? null,
        file,
      });
      toast.success(revizyonKaynak ? 'Yeni sürüm yüklendi' : 'Evrak yüklendi');
      setShowAdd(false); setBelgeTuruId(''); setTarih(''); setFiles([]); setRevizyonKaynak(null);
      refreshArsiv();
      onChanged();
    } catch (e) {
      toast.error('Yüklenemedi', e instanceof Error ? e.message : undefined);
    } finally {
      setSaving(false);
    }
  }

  // Bir belgenin YENİ SÜRÜMÜNÜ yükleme akışını başlatır. Belge türü sabitlenir,
  // eski belge silinmez; yükleme anında revizyon olarak bağlanır.
  function yeniSurum(r: PersonelEvrakSatir) {
    if (!r.documentTypeId) { toast.warning('Bu belgenin katalog türü yok; sürüm oluşturulamaz.'); return; }
    setRevizyonKaynak(r);
    setBelgeTuruId(r.documentTypeId);
    setTarih('');
    setFiles([]);
    setShowAdd(true);
  }

  function kapatEkle() {
    setShowAdd(false);
    setBelgeTuruId('');
    setTarih('');
    setFiles([]);
    setRevizyonKaynak(null);
  }

  const columns: TableColumn<PersonelEvrakSatir>[] = [
    {
      key: 'tur',
      header: 'Evrak Türü',
      render: (r) => (
        <div className="flex items-center gap-2 min-w-[180px]">
          <span className="w-8 h-8 rounded-md bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
            <i className={`${dosyaIkonu(r.mimeType)} text-foreground-500 text-sm`} />
          </span>
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground-800 truncate">{r.documentTypeName || r.title}</p>
            <p className="isg-text-caption text-foreground-500 truncate">{r.fileName || '—'}</p>
          </div>
        </div>
      ),
    },
    { key: 'aciklama', header: 'Açıklama', render: (r) => <span className="text-sm text-foreground-600">{r.title}{r.fileSize ? ` · ${dosyaBoyutMetni(r.fileSize)}` : ''}</span> },
    { key: 'duzenleme', header: 'Düzenleme Tarihi', render: (r) => <span className="text-sm text-foreground-700">{formatTarih(r.documentDate)}</span> },
    { key: 'yenileme', header: 'Yenileme Tarihi', render: (r) => <span className="text-sm text-foreground-700">{formatTarih(r.validUntil)}</span> },
    {
      key: 'kalan',
      header: 'Kalan Süre',
      render: (r) => {
        const k = gunFarki(r.validUntil);
        return k !== null && k < 0 ? <StatusBadge tone="danger">{kalanGunMetni(k)}</StatusBadge> : <span className="text-sm text-foreground-700">{kalanGunMetni(k)}</span>;
      },
    },
    { key: 'durum', header: 'Durum', render: (r) => <StatusBadge tone={toneOf(r.status)}>{evrakStatusLabel(r.status)}</StatusBadge> },
    {
      key: 'islemler',
      header: 'İşlemler',
      align: 'right',
      render: (r) => (
        <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
          <Button variant="secondary" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={() => goruntule(r)}>Görüntüle</Button>
          <Button variant="ghost" size="sm" leftIcon={<i className="ri-edit-line" />} onClick={() => setDuzenlenen(r)}><span className="sr-only">Düzenle</span></Button>
          {r.documentTypeId && (
            <Button variant="ghost" size="sm" leftIcon={<i className="ri-upload-2-line" />} onClick={() => yeniSurum(r)}><span className="sr-only">Yeni Sürüm</span></Button>
          )}
          <Button variant="ghost" size="sm" leftIcon={<i className="ri-download-2-line" />} onClick={() => indir(r)}><span className="sr-only">İndir</span></Button>
          {canDelete && (
            <Button variant="ghost" size="sm" leftIcon={<i className="ri-delete-bin-line" />} onClick={() => sil(r)}><span className="sr-only">Sil</span></Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <Card
      title="Evraklar"
      icon="ri-folder-shield-2-line"
      subtitle="Personelin gerçek dijital evrakları. Gerekli evrakların mesleğine göre listesi; yalnızca gerçek ve geçerli evraklar gösterilir."
      actions={<Button variant="primary" size="sm" leftIcon={<i className="ri-upload-2-line" />} onClick={() => { setRevizyonKaynak(null); setBelgeTuruId(''); setTarih(''); setFiles([]); setShowAdd((s) => !s); }}>Evrak Yükle</Button>}
    >
      {showAdd && (
        <div className="mb-4 rounded-lg border border-primary-200/60 dark:border-primary-400/25 bg-primary-50/40 dark:bg-primary-500/10 p-3">
          {revizyonKaynak && (
            <div className="mb-3 flex items-start gap-2 rounded-md border border-accent-200/60 dark:border-accent-500/25 bg-accent-50 dark:bg-accent-500/10 p-2.5">
              <i className="ri-history-line text-accent-600 dark:text-accent-400 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-foreground-700">
                <span className="font-medium">{revizyonKaynak.documentTypeName || revizyonKaynak.title}</span> belgesinin yeni sürümü yüklenecek.
                Eski belge silinmez; tarihçeye taşınır ve aktif geçerlilik hesabına dahil edilmez.
              </p>
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Select label="Evrak Türü" placeholder="Evrak türü seçin" options={belgeTuruOptions} value={belgeTuruId} onChange={(e) => setBelgeTuruId(e.target.value)} disabled={!!revizyonKaynak} />
            <DatePicker label="Belge Tarihi" value={tarih} onChange={(e) => setTarih(e.target.value)} />
            <div className="sm:col-span-2">
              <FileUpload multiple={false} files={files} onChange={setFiles} label="Dosya" heading="Dosyayı buraya sürükleyin veya seçin" browseLabel="Dosya Seç" helpText="PDF, JPG, PNG (Maks. 10 MB)" />
            </div>
            <div className="sm:col-span-2 flex items-center justify-end gap-2">
              <Button variant="secondary" size="sm" onClick={kapatEkle} disabled={saving}>Vazgeç</Button>
              <Button variant="primary" size="sm" isLoading={saving} leftIcon={<i className="ri-upload-2-line" />} onClick={handleUpload}>{revizyonKaynak ? 'Yeni Sürümü Yükle' : 'Yükle'}</Button>
            </div>
          </div>
        </div>
      )}
      {duzenlenen && (
        <div className="mb-4 rounded-lg border border-primary-200/60 dark:border-primary-400/25 bg-primary-50/40 dark:bg-primary-500/10 p-3">
          <div className="flex items-center justify-between gap-2 mb-2">
            <span className="text-sm font-semibold text-foreground-800">Belgeyi Düzenle</span>
            <button type="button" onClick={() => setDuzenlenen(null)} className="cursor-pointer text-foreground-500 hover:text-foreground-800"><i className="ri-close-line" /></button>
          </div>
          <EvrakDuzenleModal
            evrakId={duzenlenen.id}
            initialTitle={duzenlenen.documentTypeName || duzenlenen.title}
            initialDocumentDate={duzenlenen.documentDate}
            initialValidUntil={duzenlenen.validUntil}
            onSaved={() => { refreshArsiv(); onChanged(); }}
            onClose={() => setDuzenlenen(null)}
          />
        </div>
      )}
      {evraklar.length === 0 ? (
        <p className="isg-text-caption text-foreground-400 py-4">Henüz evrak yüklenmedi.</p>
      ) : (
        <Table data={evraklar} columns={columns} keyExtractor={(r) => r.id} density="compact" />
      )}

      {arsiv.length > 0 && (
        <div className="mt-4 border-t border-background-300/40 dark:border-background-400/25 pt-3">
          <button
            type="button"
            onClick={() => setShowArsiv((v) => !v)}
            className="flex items-center gap-1.5 text-sm font-medium text-foreground-600 hover:text-foreground-900 cursor-pointer"
          >
            <i className={showArsiv ? 'ri-arrow-down-s-line' : 'ri-arrow-right-s-line'} />
            Arşiv ({arsiv.length})
          </button>
          {showArsiv && (
            <div className="mt-2.5 flex flex-col gap-2">
              {arsiv.map((e) => (
                <div key={e.id} className="flex items-center gap-3 p-2.5 rounded-lg border border-background-300/40 dark:border-background-400/20 bg-background-100/60 dark:bg-background-200/30">
                  <span className="w-8 h-8 rounded-md bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
                    <i className={`${dosyaIkonu(e.mimeType)} text-foreground-500 text-sm`} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground-800 truncate">{e.documentTypeName || e.title}</p>
                    <p className="isg-text-caption text-foreground-400">{formatTarih(e.createdAt)} · Arşivlendi</p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <Button variant="secondary" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={() => goruntule(e)}>Görüntüle</Button>
                    <Button variant="ghost" size="sm" leftIcon={<i className="ri-download-2-line" />} onClick={() => indir(e)}><span className="sr-only">İndir</span></Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {evrakPreviewNode}
    </Card>
  );
}