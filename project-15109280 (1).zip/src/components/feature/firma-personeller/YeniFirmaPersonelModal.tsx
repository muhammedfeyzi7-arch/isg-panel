import { useEffect, useMemo, useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import PhoneInput from '@/components/ui/PhoneInput';
import TcKimlikInput from '@/components/ui/TcKimlikInput';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import { toast } from '@/hooks/useToast';
import MeslekAramaInput from './MeslekAramaInput';
import {
  createFirmaPersonelDetay,
  fetchMeslekiGereksinimler,
  fetchValidityRuleMap,
  gunFarki,
  hazardSinifiLabel,
  yenilemeTarihiEkle,
  type IskurMeslekSecim,
  type MeslekiGereksinim,
  type PanelFirma,
  type ValidityRuleMap,
} from '@/lib/firmaPersonelService';
import { fetchEvrakTurleri, uploadEvrak } from '@/lib/evrakService';
import { dateValidationError, emailValidationError, tcValidationError } from '@/lib/personelValidation';
import { friendlyPersonelError } from '@/lib/personelService';
import { formatTarih, kalanGunMetni } from './personelFirmaUi';

interface Props {
  firma: PanelFirma;
  onClose: () => void;
  onCreated: () => void;
}

interface GereksinimGosterge {
  name: string;
  gerekli: boolean;
  alt?: string | null;
}

interface BelgeTuruSecenek {
  value: string;
  label: string;
}

/** Kabul edilen belge türü token'larını okunabilir etikete çevirir. */
const TOKEN_LABEL: Record<string, string> = {
  MYK: 'MYK Yeterlilik Belgesi',
  USTALIK: 'Ustalık Belgesi',
  DIPLOMA: 'Diploma',
  KALFALIK: 'Kalfalık Belgesi',
  MESLEKI_EGITIM: 'Mesleki Eğitim Belgesi',
  MESLEKI_SERTIFIKA: 'Mesleki Sertifika',
  OPERATORLUK_BELGESI: 'Operatörlük Belgesi',
  OPERATORLUK: 'Operatörlük Belgesi',
  EHLIYET: 'Ehliyet',
};

export default function YeniFirmaPersonelModal({ firma, onClose, onCreated }: Props) {
  const [adSoyad, setAdSoyad] = useState('');
  const [tc, setTc] = useState('');
  const [telefon, setTelefon] = useState('');
  const [email, setEmail] = useState('');
  const [iseGiris, setIseGiris] = useState('');
  const [meslek, setMeslek] = useState<IskurMeslekSecim | null>(null);
  const [sonEgitim, setSonEgitim] = useState('');
  const [sonSaglik, setSonSaglik] = useState('');
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [fileTypes, setFileTypes] = useState<Record<string, string>>({});
  const [belgeTuruOptions, setBelgeTuruOptions] = useState<BelgeTuruSecenek[]>([]);
  const [validity, setValidity] = useState<ValidityRuleMap | null>(null);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [gereksinimler, setGereksinimler] = useState<MeslekiGereksinim[]>([]);

  // Merkezi evrak türleri + yenileme kuralları (mevzuat süresi frontend'e gömülmez).
  useEffect(() => {
    fetchEvrakTurleri()
      .then((turler) =>
        setBelgeTuruOptions(
          turler
            .filter((t) => t.ownerType === 'personel' && !t.isHealth)
            .map((t) => ({ value: t.id, label: t.name })),
        ),
      )
      .catch(() => setBelgeTuruOptions([]));
    fetchValidityRuleMap()
      .then(setValidity)
      .catch(() => setValidity(null));
  }, []);

  // Seçilen mesleğe göre merkezi gereksinim motoru (tek kaynak).
  useEffect(() => {
    let cancelled = false;
    if (!meslek) {
      setGereksinimler([]);
      return;
    }
    fetchMeslekiGereksinimler(meslek.occupationId, firma.tehlikeSinifi)
      .then((r) => {
        if (!cancelled) setGereksinimler(r);
      })
      .catch(() => {
        if (!cancelled) setGereksinimler([]);
      });
    return () => {
      cancelled = true;
    };
  }, [meslek, firma.tehlikeSinifi]);

  const gostergeListesi = useMemo<GereksinimGosterge[]>(() => {
    // Yalnızca gerçek BELGE gereksinimleri (mesleki belge + genel evrak). Eğitim/sağlık
    // gereksinimleri belge değildir; ayrı tarih alanlarından yönetilir. Sabit/gereksiz
    // belge EKLENMEZ — liste tamamen merkezi motordan (requirement_rules) gelir.
    return gereksinimler
      .filter((r) => r.kategori === 'mesleki' || r.kategori === 'genel_evrak')
      .map((r) => ({
        name: r.name,
        gerekli: r.required,
        alt: r.acceptedTypes.length > 0 ? r.acceptedTypes.map((t) => TOKEN_LABEL[t] ?? t).join(' / ') : null,
      }));
  }, [gereksinimler]);

  // Yenileme özeti — merkezi kuraldan (isg_kurallari) türetilir.
  const hazKey = (firma.tehlikeSinifi ?? '') as keyof ValidityRuleMap['egitim'];
  const egitimYil = validity?.egitim[hazKey];
  const saglikYil = validity?.saglik[hazKey];
  const egitimYenileme = sonEgitim && egitimYil ? yenilemeTarihiEkle(sonEgitim, egitimYil) : null;
  const saglikYenileme = sonSaglik && saglikYil ? yenilemeTarihiEkle(sonSaglik, saglikYil) : null;
  const saglikKalan = gunFarki(saglikYenileme);

  const rawFiles = useMemo(() => files.filter((f) => f.raw), [files]);

  function validate(): boolean {
    const e: Record<string, string> = {};
    const temizAdSoyad = adSoyad.trim().replace(/\s+/g, ' ');
    // Tek kelimelik giriş → soyad boş kalır → DB `personeller_soyad_check` ihlali (400).
    // Bu yüzden kayıt gönderilmeden ÖNCE ad + soyad zorunluluğu burada doğrulanır.
    if (!temizAdSoyad) e.adSoyad = 'Ad Soyad zorunludur.';
    else if (temizAdSoyad.split(' ').filter(Boolean).length < 2) {
      e.adSoyad = 'Ad ve soyad birlikte girilmelidir (en az iki kelime).';
    }
    // Merkezi kurallar — Excel içe aktarma ile AYNI doğrulama (tek kaynak).
    const tcErr = tcValidationError(tc);
    if (tcErr) e.tc = tcErr;
    const emailErr = emailValidationError(email);
    if (emailErr) e.email = emailErr;
    const iseErr = dateValidationError(iseGiris, true, 'İşe giriş tarihi');
    if (iseErr) e.iseGiris = iseErr;
    // Yüklenen her dosya için belge türü zorunlu.
    if (rawFiles.some((f) => !fileTypes[f.id])) e.belgeTuru = 'Her dosya için belge türü seçmelisiniz.';
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  async function handleSave() {
    if (saving) return; // çift gönderim koruması — duplicate personel oluşmaz
    if (!validate()) return;
    setSaving(true);
    try {
      const trimmed = adSoyad.trim().replace(/\s+/g, ' ');
      const parts = trimmed.split(' ').filter(Boolean);
      const ad = parts[0] ?? '';
      const soyad = parts.slice(1).join(' ');

      const { personelId, warnings } = await createFirmaPersonelDetay({
        firmaId: firma.id,
        ad,
        soyad,
        tcKimlikNo: tc,
        telefon,
        email,
        iseGirisTarihi: iseGiris || null,
        // Yeni personel, mevcut iş akışına uygun şekilde aktif olarak oluşturulur.
        calismaDurumu: 'aktif',
        occupationId: meslek?.occupationId ?? null,
        occupationCode: meslek?.occupationCode ?? null,
        occupationName: meslek?.name ?? null,
        sonIsgEgitimTarihi: sonEgitim || null,
        sonSaglikMuayeneTarihi: sonSaglik || null,
      });

      // Opsiyonel evrak yükleme — her dosya kendi belge türü ile kaydedilir.
      let fail = 0;
      for (const f of rawFiles) {
        const raw = f.raw as File;
        const documentTypeId = fileTypes[f.id];
        try {
          await uploadEvrak({
            ownerType: 'personel',
            firmaId: firma.id,
            personelId,
            documentTypeId,
            title: raw.name,
            file: raw,
          });
        } catch {
          fail += 1;
        }
      }

      const uyarilar = [...warnings];
      if (fail > 0) uyarilar.push(`${fail} evrak kaydedilemedi.`);
      if (uyarilar.length > 0) {
        toast.warning(
          'Personel kaydedildi, bazı kayıtlar tamamlanamadı',
          `${uyarilar.join(' ')} Personel detay ekranından tekrar deneyebilirsiniz.`,
        );
      } else {
        toast.success('Personel kaydedildi');
      }
      onCreated();
      onClose();
    } catch (err) {
      // Domain kodları (PERSONEL_TC_DUPLICATE / PERSONEL_EMAIL_DUPLICATE / FIRMA_PASIF ...)
      // merkezi PERSONEL çeviricisi ile Türkçeleştirilir. Genel hata çevirici bu kodları
      // tanımadığı için ham kod ekrana düşüyordu; artık gerçek sebep anlaşılır gösterilir.
      toast.error('Kaydedilemedi', friendlyPersonelError(err));
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 md:p-6">
        <div className="grid grid-cols-1 lg:grid-cols-[1.55fr_1fr] gap-4">
          {/* Sol kolon */}
          <div className="space-y-4">
            {/* 1. Kişisel Bilgiler */}
            <section className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4">
              <SectionHead no={1} title="Kişisel Bilgiler" desc="Personelin kimlik ve iletişim bilgilerini girin." />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                <Input
                  label="Ad Soyad"
                  value={adSoyad}
                  onChange={(e) => setAdSoyad(e.target.value)}
                  placeholder="Mehmet Yılmaz"
                  leftIcon={<i className="ri-user-line" />}
                  required
                  error={errors.adSoyad}
                  autoComplete="off"
                />
                <TcKimlikInput label="T.C. Kimlik No" value={tc} onChange={setTc} placeholder="12345678901" leftIcon={<i className="ri-id-card-line" />} error={errors.tc} />
                <PhoneInput label="Telefon" value={telefon} onChange={setTelefon} leftIcon={<i className="ri-phone-line" />} />
                <Input label="E-posta" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ornek@ornek.com" leftIcon={<i className="ri-mail-line" />} error={errors.email} autoComplete="off" />
                <DatePicker label="İşe Giriş Tarihi" value={iseGiris} onChange={(e) => setIseGiris(e.target.value)} required error={errors.iseGiris} />
              </div>
            </section>

            {/* 2. Görev / Meslek */}
            <section className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4">
              <SectionHead no={2} title="Görev / Meslek" desc="Personelin görevini yazarak İŞKUR meslekleri arasından seçin." />
              <div className="mt-3">
                <MeslekAramaInput value={meslek} onChange={setMeslek} />
              </div>
            </section>

            {/* 3. Tarihler */}
            <section className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4">
              <SectionHead no={3} title="Tarihler" desc="Eğitim ve sağlık yenileme takibi için başlangıç tarihlerini girin." />
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                <DatePicker label="Son İSG Eğitimi Tarihi" value={sonEgitim} onChange={(e) => setSonEgitim(e.target.value)} />
                <DatePicker label="Son Sağlık Muayenesi Tarihi" value={sonSaglik} onChange={(e) => setSonSaglik(e.target.value)} />
              </div>
              {(egitimYenileme || saglikYenileme) && (
                <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {egitimYenileme && (
                    <div className="rounded-md bg-background-100 dark:bg-background-200/50 border border-background-300/50 dark:border-background-400/25 p-2.5">
                      <p className="isg-text-caption text-foreground-500">İSG Eğitimi — Sonraki Yenileme</p>
                      <p className="text-sm text-foreground-800">{formatTarih(egitimYenileme)}</p>
                      <p className="isg-text-caption text-foreground-500">Kalan: {kalanGunMetni(gunFarki(egitimYenileme))}</p>
                    </div>
                  )}
                  {saglikYenileme && (
                    <div className="rounded-md bg-background-100 dark:bg-background-200/50 border border-background-300/50 dark:border-background-400/25 p-2.5">
                      <p className="isg-text-caption text-foreground-500">Sağlık — Sonraki Yenileme</p>
                      <p className="text-sm text-foreground-800">{formatTarih(saglikYenileme)}</p>
                      <p className="isg-text-caption text-foreground-500">
                        Kalan: {kalanGunMetni(saglikKalan)} · {saglikKalan !== null && saglikKalan < 0 ? 'Süresi Geçmiş' : 'Uygun'}
                      </p>
                    </div>
                  )}
                </div>
              )}
              <p className="mt-2 isg-text-caption text-foreground-500 flex items-center gap-1">
                <i className="ri-information-line" />
                Yenileme süreleri firma tehlike sınıfına göre sistem tarafından otomatik hesaplanır.
              </p>
            </section>

            {/* 4. Evrak Yükleme (İsteğe Bağlı) */}
            <section className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4">
              <SectionHead no={4} title="Evrak Yükleme (İsteğe Bağlı)" desc="Personelin mevcut evraklarını şimdi yükleyebilir veya daha sonra ekleyebilirsiniz." />
              <div className="mt-3">
                <FileUpload
                  multiple
                  files={files}
                  onChange={setFiles}
                  heading="Dosyaları buraya sürükleyin veya seçin"
                  browseLabel="Dosya Seç"
                  helpText="PDF, JPG, PNG (Maks. 10 MB)"
                />
              </div>
              {rawFiles.length > 0 && (
                <div className="mt-3 space-y-2">
                  <p className="isg-text-caption text-foreground-500">Her dosya için belge türü seçin.</p>
                  {rawFiles.map((f) => (
                    <div key={f.id} className="flex items-center gap-2">
                      <span className="flex-1 min-w-0 text-sm text-foreground-700 truncate flex items-center gap-1.5">
                        <i className="ri-file-line text-foreground-400" /> {f.name}
                      </span>
                      <Select
                        size="sm"
                        containerClassName="w-[220px] flex-shrink-0"
                        placeholder="Belge türü"
                        options={belgeTuruOptions}
                        value={fileTypes[f.id] ?? ''}
                        onChange={(e) => setFileTypes((prev) => ({ ...prev, [f.id]: e.target.value }))}
                      />
                    </div>
                  ))}
                  {errors.belgeTuru && <p className="text-xs text-danger-600">{errors.belgeTuru}</p>}
                </div>
              )}
            </section>
          </div>

          {/* Sağ kolon */}
          <div className="space-y-4">
            <section className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4">
              <p className="isg-text-caption font-medium text-foreground-500 mb-2">Seçilen Meslek Bilgisi</p>
              {meslek ? (
                <div className="flex items-center gap-3">
                  <span className="w-10 h-10 rounded-md bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                    <i className="ri-base-station-line text-primary-600 dark:text-primary-400" />
                  </span>
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-foreground-900 truncate">{meslek.name}</p>
                    <p className="isg-text-caption text-foreground-500">
                      İŞKUR Kodu: {meslek.occupationCode}{meslek.sektor ? ` · ${meslek.sektor}` : ''}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-3 text-foreground-400">
                  <span className="w-10 h-10 rounded-md bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
                    <i className="ri-user-search-line" />
                  </span>
                  <p className="text-sm">Henüz meslek seçilmedi.</p>
                </div>
              )}
              <div className="mt-3 rounded-md bg-secondary-50 dark:bg-secondary-500/10 border border-secondary-200/60 dark:border-secondary-400/20 p-2.5 flex gap-2">
                <i className="ri-information-line text-secondary-600 dark:text-secondary-400 flex-shrink-0 mt-0.5" />
                <p className="isg-text-caption text-secondary-900 dark:text-secondary-300 leading-relaxed">
                  Bu meslek için firmanın tehlike sınıfına göre aşağıdaki mesleki belgeler, eğitimler ve sağlık gereksinimleri geçerlidir. Gerekli olmayan belgeler sistemde gösterilmez.
                </p>
              </div>

              {meslek && (
                <div className={`mt-3 rounded-md border p-2.5 ${meslek.mykKapsaminda ? 'border-accent-200/60 dark:border-accent-400/20 bg-accent-50 dark:bg-accent-500/10' : 'border-background-300/60 dark:border-background-400/25 bg-background-100 dark:bg-background-200/40'}`}>
                  <div className="flex items-center gap-2">
                    <i className={`${meslek.mykKapsaminda ? 'ri-award-line text-accent-600 dark:text-accent-400' : 'ri-information-line text-foreground-400'} flex-shrink-0`} />
                    <p className="text-sm font-medium text-foreground-800">
                      {meslek.mykKapsaminda ? 'Bu görev MYK / UMS kapsamında değerlendirilmektedir' : 'MYK kapsam eşleşmesi bulunmuyor'}
                    </p>
                  </div>
                  {meslek.mykKapsaminda && meslek.mykList.length > 0 && (
                    <ul className="mt-2 space-y-1">
                      {meslek.mykList.slice(0, 5).map((m, i) => (
                        <li key={`${m.qualificationCode ?? m.umsCode ?? i}`} className="isg-text-caption text-foreground-600 flex items-start gap-1.5">
                          <i className="ri-checkbox-circle-line text-accent-500 flex-shrink-0 mt-0.5" />
                          <span className="min-w-0">
                            {m.qualificationCode ? `UY: ${m.qualificationCode}` : (m.umsCode ? `UMS: ${m.umsCode}` : '')}
                            {m.qualificationName ? ` · ${m.qualificationName}` : ''}
                            {m.level ? ` (Seviye ${m.level})` : ''}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                  <p className="mt-2 isg-text-caption text-foreground-400 leading-relaxed">
                    Kapsam bilgisi nötr olarak sunulur; mesleğe bağlı zorunlu belgeler “Bu personel için gerekenler” listesinde gösterilir. Kullanıcıdan manuel MYK/UMS seçimi istenmez.
                  </p>
                </div>
              )}
            </section>

            <section className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4">
              <p className="text-sm font-semibold text-foreground-900 mb-3">Bu personel için gerekenler</p>
              {gostergeListesi.length === 0 ? (
                <p className="isg-text-caption text-foreground-400">
                  {meslek ? 'Bu meslek için tanımlı özel bir belge gereksinimi bulunmuyor.' : 'Meslek seçildiğinde gereksinimler listelenir.'}
                </p>
              ) : (
                <ul className="space-y-2.5">
                  {gostergeListesi.map((g) => (
                    <li key={g.name} className="flex items-start justify-between gap-2">
                      <span className="flex items-start gap-2 min-w-0 text-sm text-foreground-800">
                        <i className="ri-file-shield-2-line text-foreground-400 flex-shrink-0 mt-0.5" />
                        <span className="min-w-0">
                          <span className="block truncate">{g.name}</span>
                          {g.gerekli && g.alt && <span className="block isg-text-caption text-foreground-400">{g.alt}</span>}
                        </span>
                      </span>
                      <span className={`isg-status flex-shrink-0 ${g.gerekli ? 'isg-soft-danger' : ''}`} data-tone={g.gerekli ? 'danger' : 'neutral'}>
                        {g.gerekli ? 'Gerekli' : 'Gerekli Değil'}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <div className="rounded-lg border border-warning-200/60 dark:border-warning-400/25 bg-warning-50 dark:bg-warning-500/10 p-3 flex gap-2">
              <i className="ri-lightbulb-line text-warning-600 flex-shrink-0 mt-0.5" />
              <p className="isg-text-caption text-warning-900 dark:text-warning-300 leading-relaxed">
                Görev değiştirildiğinde bu alandaki gereksinimler otomatik olarak güncellenir. Evrak yüklemek zorunlu değildir; personeli kaydettikten sonra detay sayfasından evrak ekleyebilirsiniz.
              </p>
            </div>

            <p className="isg-text-caption text-foreground-400">Firma Tehlike Sınıfı: {hazardSinifiLabel(firma.tehlikeSinifi)}</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="flex-shrink-0 flex items-center justify-end gap-2 px-4 md:px-6 py-3 border-t border-background-300/60 dark:border-background-400/30">
        <Button variant="secondary" onClick={onClose} disabled={saving}>İptal</Button>
        <Button variant="primary" leftIcon={<i className="ri-save-line" />} isLoading={saving} onClick={handleSave}>Personeli Kaydet</Button>
      </div>
    </div>
  );
}

function SectionHead({ no, title, desc }: { no: number; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3">
      <span className="w-6 h-6 rounded-full bg-primary-500 text-inverse text-xs font-bold flex items-center justify-center flex-shrink-0">
        {no}
      </span>
      <div className="min-w-0">
        <h3 className="text-sm font-semibold text-foreground-900">{title}</h3>
        <p className="isg-text-caption text-foreground-500">{desc}</p>
      </div>
    </div>
  );
}