// ─────────────────────────────────────────────────────────────────────────────
// EXCEL'DEN PERSONEL AKTAR — Modal Parçaları (tek ekran)
// Kolon eşleştirme kartları + özet sayaçlar + düzenlenebilir önizleme tablosu.
// Ortak SharedUICore bileşenlerini kullanır (Select, DatePicker, PickerPortal,
// Badge, StatusBadge, Input). İkinci bir UI motoru oluşturmaz.
// ─────────────────────────────────────────────────────────────────────────────
import { useEffect, useMemo, useRef, useState } from 'react';
import Select from '@/components/ui/Select';
import Badge from '@/components/ui/Badge';
import StatusBadge from '@/components/ui/StatusBadge';
import PickerPortal from '@/components/ui/PickerPortal';
import DatePicker from '@/components/ui/DatePicker';
import { araIskurMeslekler, type IskurMeslekSecim } from '@/lib/firmaPersonelService';
import type { ColumnMapping, ImportFieldDef } from '@/lib/import/types';
import type { EditableImportRow, ImportSessionCounts } from '@/lib/personelImportSession';
import { matchesSearch } from '@/utils/turkishText';

const CELL_INPUT =
  'w-full bg-transparent border border-transparent rounded px-1.5 py-1 text-sm text-foreground-800 ' +
  'hover:border-background-300/60 focus:border-primary-400 focus:bg-background-50 dark:focus:bg-background-200 ' +
  'outline-none transition-colors placeholder:text-foreground-300';

const CELL_ERROR = 'border-danger-400 bg-danger-50/60 dark:bg-danger-500/10';

// ──────────────────────────── KOLON EŞLEŞTİRME KARTLARI ────────────────────────────

export function MappingCards({
  fields,
  mapping,
  onChange,
}: {
  fields: ImportFieldDef[];
  mapping: ColumnMapping[];
  onChange: (mapping: ColumnMapping[]) => void;
}) {
  const options = useMemo(
    () => [{ value: '', label: 'Eşleştirme Yok' }, ...fields.map((f) => ({ value: f.key, label: f.label }))],
    [fields],
  );
  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const m of mapping) if (m.targetField) c[m.targetField] = (c[m.targetField] ?? 0) + 1;
    return c;
  }, [mapping]);

  const change = (sourceIndex: number, targetField: string) => {
    onChange(
      mapping.map((m) =>
        m.sourceIndex === sourceIndex
          ? { ...m, targetField: targetField || null, state: targetField ? 'matched' : 'unmapped' }
          : m,
      ),
    );
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <p className="text-xs font-semibold uppercase tracking-wide text-foreground-500">Kolon Eşleştirme</p>
        <Badge variant="secondary">{mapping.filter((m) => m.targetField).length}/{mapping.length} eşleşti</Badge>
      </div>
      <div className="flex gap-2.5 overflow-x-auto pb-1 -mx-1 px-1">
        {mapping.map((m) => {
          const dup = m.targetField ? counts[m.targetField] > 1 : false;
          return (
            <div
              key={m.sourceIndex}
              className="w-[220px] flex-shrink-0 rounded-lg border border-background-300/50 dark:border-background-400/25 bg-background-100 dark:bg-background-200/50 p-2.5 space-y-1.5"
            >
              <div className="flex items-center justify-between gap-1">
                <span className="text-[11px] text-foreground-400">Kolon {m.sourceIndex + 1}</span>
                {m.targetField ? (
                  <StatusBadge tone={dup ? 'warning' : 'success'}>{dup ? 'Çift' : 'Eşleşti'}</StatusBadge>
                ) : (
                  <StatusBadge tone="neutral">Yok</StatusBadge>
                )}
              </div>
              <p className="text-sm font-medium text-foreground-800 truncate" title={m.header}>
                {m.header || '(boş başlık)'}
              </p>
              <p className="text-[11px] text-foreground-400 truncate" title={m.sample}>
                Örnek: {m.sample || '—'}
              </p>
              <Select
                size="sm"
                options={options}
                value={m.targetField ?? ''}
                onChange={(e) => change(m.sourceIndex, String(e.target.value))}
              />
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ──────────────────────────── ÖZET SAYAÇLAR ────────────────────────────

function Sayac({ label, value, tone, icon }: { label: string; value: number; tone: string; icon: string }) {
  return (
    <div className="flex items-center gap-2.5 rounded-lg border border-background-300/50 dark:border-background-400/25 bg-background-100 dark:bg-background-200/50 px-3 py-2.5">
      <span className={`w-9 h-9 rounded-md flex items-center justify-center flex-shrink-0 ${tone}`}>
        <i className={`${icon} text-base`} />
      </span>
      <div className="min-w-0">
        <p className="text-lg font-bold text-foreground-900 leading-none">{value}</p>
        <p className="text-[11px] text-foreground-500 truncate">{label}</p>
      </div>
    </div>
  );
}

export function ImportCounters({ counts }: { counts: ImportSessionCounts }) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
      <Sayac label="Toplam Satır" value={counts.toplam} icon="ri-file-list-3-line" tone="bg-background-200 text-foreground-600 dark:bg-background-300/40" />
      <Sayac label="Geçerli" value={counts.gecerli} icon="ri-checkbox-circle-line" tone="bg-success-100 text-success-700 dark:bg-success-500/20 dark:text-success-400" />
      <Sayac label="Hatalı" value={counts.hatali} icon="ri-error-warning-line" tone="bg-danger-100 text-danger-700 dark:bg-danger-500/20 dark:text-danger-400" />
      <Sayac label="Uyarılı" value={counts.uyarili} icon="ri-alert-line" tone="bg-warning-100 text-warning-700 dark:bg-warning-500/20 dark:text-warning-400" />
    </div>
  );
}

// ──────────────────────────── DÜZENLENEBİLİR HÜCRELER ────────────────────────────

function TextCell({
  value,
  error,
  placeholder,
  onCommit,
}: {
  value: string;
  error?: string;
  placeholder?: string;
  onCommit: (v: string) => void;
}) {
  const [draft, setDraft] = useState(value);
  useEffect(() => setDraft(value), [value]);
  return (
    <input
      type="text"
      value={draft}
      placeholder={placeholder}
      onChange={(e) => setDraft(e.target.value)}
      onBlur={() => { if (draft !== value) onCommit(draft); }}
      onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); (e.target as HTMLInputElement).blur(); } }}
      className={`${CELL_INPUT} ${error ? CELL_ERROR : ''}`}
      title={error || undefined}
    />
  );
}

/** Merkezi paylaşılan DatePicker ile düzenlenebilir tarih hücresi (serbest tarih paneli). */
function DateCell({ value, error, onCommit }: { value: string; error?: string; onCommit: (v: string) => void }) {
  return (
    <DatePicker
      value={value}
      error={error}
      placeholder="gg.aa.yyyy"
      onChange={(e) => onCommit(e.target.value)}
    />
  );
}

/**
 * Meslek hücresi — Excel'den gelen serbest metin + İŞKUR eşleştirmesi. Kullanıcı
 * hücreye tıklayıp İŞKUR mesleklerini arayabilir ve kanonik kaydı seçebilir.
 * Dropdown gövde overflow'unu kırmaması için PickerPortal ile portallanır.
 */
function MeslekCell({
  row,
  onSelect,
}: {
  row: EditableImportRow;
  onSelect: (meslek: IskurMeslekSecim | null, gorev: string) => void;
}) {
  const btnRef = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);
  const [term, setTerm] = useState('');
  const [results, setResults] = useState<IskurMeslekSecim[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open) return undefined;
    const q = term.trim();
    if (q.length < 2) { setResults([]); return undefined; }
    let cancelled = false;
    setLoading(true);
    const t = setTimeout(() => {
      araIskurMeslekler(q)
        .then((r) => { if (!cancelled) setResults(r); })
        .catch(() => { if (!cancelled) setResults([]); })
        .finally(() => { if (!cancelled) setLoading(false); });
    }, 300);
    return () => { cancelled = true; clearTimeout(t); };
  }, [term, open]);

  const label = row.occupationName || row.gorev || '—';
  const tone = row.occupationMatched ? 'text-success-700' : row.gorev ? 'text-warning-700' : 'text-foreground-400';
  const icon = row.occupationMatched ? 'ri-checkbox-circle-line' : row.gorev ? 'ri-question-line' : 'ri-add-line';

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        onClick={() => { setOpen((o) => !o); setTerm(row.gorev); }}
        className={`w-full flex items-center gap-1.5 rounded px-1.5 py-1 text-left text-sm border border-transparent hover:border-background-300/60 focus:border-primary-400 outline-none transition-colors ${tone}`}
        title={row.occupationMatched ? `İŞKUR: ${row.occupationCode}` : row.gorev ? 'İŞKUR mesleği bulunamadı — aramak için tıklayın' : 'Meslek seçin'}
      >
        <i className={`${icon} flex-shrink-0`} />
        <span className="truncate">{label}</span>
      </button>
      <PickerPortal anchorRef={btnRef} open={open} onClose={() => setOpen(false)} minWidth={320}>
        <div className="w-80 p-2">
          <div className="relative mb-2">
            <i className="ri-search-line absolute left-2.5 top-1/2 -translate-y-1/2 text-foreground-400 text-sm" />
            <input
              type="text"
              value={term}
              autoFocus
              onChange={(e) => setTerm(e.target.value)}
              placeholder="İŞKUR mesleği ara (ör. Forklift)"
              className="isg-input isg-input-sm w-full pl-8"
              onKeyDown={(e) => { if (e.key === 'Enter' && results[0]) { e.preventDefault(); onSelect(results[0], results[0].name); setOpen(false); } }}
            />
          </div>
          <div className="max-h-60 overflow-y-auto">
            <button
              type="button"
              onClick={() => { onSelect(null, ''); setOpen(false); }}
              className="w-full flex items-center gap-2 px-2.5 py-2 text-left text-sm text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 rounded cursor-pointer"
            >
              <i className="ri-close-line" /> Mesleği temizle
            </button>
            <button
              type="button"
              onClick={() => { onSelect(null, term.trim()); setOpen(false); }}
              className="w-full flex items-center gap-2 px-2.5 py-2 text-left text-sm text-foreground-800 hover:bg-background-200 dark:hover:bg-background-300/40 rounded cursor-pointer border-b border-background-200 dark:border-background-400/20"
            >
              <i className="ri-edit-line text-foreground-400" /> Serbest metin: &ldquo;{term.trim() || '—'}&rdquo;
            </button>
            {loading ? (
              <p className="px-2.5 py-3 text-xs text-foreground-400">Aranıyor...</p>
            ) : results.length === 0 ? (
              <p className="px-2.5 py-3 text-xs text-foreground-400">İŞKUR mesleği bulunamadı.</p>
            ) : (
              results.map((r) => (
                <button
                  key={r.occupationId}
                  type="button"
                  onClick={() => { onSelect(r, r.name); setOpen(false); }}
                  className="w-full flex items-center justify-between gap-2 px-2.5 py-2 text-left hover:bg-primary-50 dark:hover:bg-primary-500/15 rounded cursor-pointer"
                >
                  <span className="min-w-0">
                    <span className="block text-sm text-foreground-800 truncate">{r.name}</span>
                    <span className="block text-[11px] text-foreground-400">İŞKUR: {r.occupationCode}</span>
                  </span>
                  {r.kuralVar && <Badge variant="accent">Belge</Badge>}
                </button>
              ))
            )}
          </div>
        </div>
      </PickerPortal>
    </>
  );
}

// ──────────────────────────── ÖNİZLEME TABLOSU ────────────────────────────

type FilterKey = 'all' | 'hatali' | 'uyarili' | 'gecerli';

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: 'all', label: 'Tümü' },
  { key: 'hatali', label: 'Hatalı' },
  { key: 'uyarili', label: 'Uyarılı' },
  { key: 'gecerli', label: 'Geçerli' },
];

const STATUS_META: Record<EditableImportRow['status'], { label: string; tone: 'success' | 'warning' | 'danger' }> = {
  gecerli: { label: 'Geçerli', tone: 'success' },
  uyarili: { label: 'Uyarılı', tone: 'warning' },
  hatali: { label: 'Hatalı', tone: 'danger' },
};

export function ImportPreviewTable({
  rows,
  onPatch,
  onSelectMeslek,
}: {
  rows: EditableImportRow[];
  onPatch: (rowId: string, patch: Partial<EditableImportRow>) => void;
  onSelectMeslek: (rowId: string, meslek: IskurMeslekSecim | null, gorev: string) => void;
}) {
  const [filter, setFilter] = useState<FilterKey>('all');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const filtered = useMemo(() => {
    let r = rows;
    if (filter !== 'all') r = r.filter((x) => x.status === filter);
    const q = search.trim().toLocaleLowerCase('tr');
    if (q) {
      r = r.filter((x) =>
        [x.ad, x.soyad, x.tcKimlikNo, x.gorev, x.email, x.telefon, x.sicilNo]
          .some((v) => matchesSearch(v ?? '', q)),
      );
    }
    return r;
  }, [rows, filter, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, totalPages);
  const pageRows = filtered.slice((current - 1) * pageSize, current * pageSize);
  const rangeFrom = filtered.length === 0 ? 0 : (current - 1) * pageSize + 1;
  const rangeTo = Math.min(current * pageSize, filtered.length);

  const counts = useMemo(() => ({
    all: rows.length,
    hatali: rows.filter((r) => r.status === 'hatali').length,
    uyarili: rows.filter((r) => r.status === 'uyarili').length,
    gecerli: rows.filter((r) => r.status === 'gecerli').length,
  }), [rows]);

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1.5">
          {FILTERS.map((f) => {
            const active = filter === f.key;
            const n = counts[f.key];
            const tone =
              f.key === 'hatali' ? 'bg-danger-100 text-danger-700 dark:bg-danger-500/20 dark:text-danger-400'
              : f.key === 'uyarili' ? 'bg-warning-100 text-warning-700 dark:bg-warning-500/20 dark:text-warning-400'
              : f.key === 'gecerli' ? 'bg-success-100 text-success-700 dark:bg-success-500/20 dark:text-success-400'
              : 'bg-background-200 text-foreground-600 dark:bg-background-300/40';
            return (
              <button
                key={f.key}
                type="button"
                onClick={() => { setFilter(f.key); setPage(1); }}
                className={`px-2.5 py-1 rounded-full text-xs font-medium whitespace-nowrap cursor-pointer transition-colors ${active ? 'ring-2 ring-primary-400' : 'opacity-80 hover:opacity-100'} ${tone}`}
              >
                {f.label} ({n})
              </button>
            );
          })}
        </div>
        <div className="relative ml-auto w-full sm:w-64">
          <i className="ri-search-line absolute left-2.5 top-1/2 -translate-y-1/2 text-foreground-400 text-sm" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Listede ara..."
            className="isg-input isg-input-sm w-full pl-8"
          />
        </div>
      </div>

      <div className="rounded-lg border border-background-300/40 dark:border-background-400/25 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse min-w-[1080px]">
            <thead>
              <tr className="bg-background-200/70 dark:bg-background-200/40 text-[11px] uppercase tracking-wide text-foreground-500">
                <th className="text-left font-medium px-2 py-2 w-10">#</th>
                <th className="text-left font-medium px-2 py-2 min-w-[150px]">Ad Soyad *</th>
                <th className="text-left font-medium px-2 py-2 min-w-[120px]">T.C. Kimlik No</th>
                <th className="text-left font-medium px-2 py-2 min-w-[120px]">Telefon</th>
                <th className="text-left font-medium px-2 py-2 min-w-[150px]">E-posta</th>
                <th className="text-left font-medium px-2 py-2 min-w-[150px]">Görev / Meslek</th>
                <th className="text-left font-medium px-2 py-2 min-w-[120px]">İşe Giriş *</th>
                <th className="text-left font-medium px-2 py-2 min-w-[120px]">Doğum Tarihi</th>
                <th className="text-left font-medium px-2 py-2 min-w-[90px]">Sicil No</th>
                <th className="text-left font-medium px-2 py-2 min-w-[110px]">Durum</th>
                <th className="text-left font-medium px-2 py-2 min-w-[180px]">Açıklama</th>
              </tr>
            </thead>
            <tbody>
              {pageRows.length === 0 ? (
                <tr>
                  <td colSpan={11} className="px-3 py-10 text-center text-sm text-foreground-400">
                    Gösterilecek satır yok.
                  </td>
                </tr>
              ) : (
                pageRows.map((r) => {
                  const rowTone =
                    r.status === 'hatali' ? 'bg-danger-50/50 dark:bg-danger-500/10'
                    : r.status === 'uyarili' ? 'bg-warning-50/40 dark:bg-warning-500/10'
                    : '';
                  const meta = STATUS_META[r.status];
                  const aciklama = r.errors[0] ?? r.warnings[0] ?? (r.fileDuplicate ? 'Dosya içinde yinelenen kayıt — bu satır oluşturulmaz' : '');
                  return (
                    <tr key={r.rowId} className={`border-t border-background-300/25 dark:border-background-400/20 ${rowTone}`}>
                      <td className="px-2 py-1 text-xs text-foreground-400 tabular-nums">{r.sourceIndex}</td>
                      <td className="px-1 py-1">
                        <TextCell
                          value={[r.ad, r.soyad].filter(Boolean).join(' ')}
                          error={r.fieldErrors.adSoyad}
                          placeholder="Ad Soyad"
                          onCommit={(v) => {
                            const parts = v.trim().split(/\s+/).filter(Boolean);
                            onPatch(r.rowId, { ad: parts[0] ?? '', soyad: parts.slice(1).join(' ') });
                          }}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <TextCell
                          value={r.tcKimlikNo}
                          error={r.fieldErrors.tc}
                          placeholder="11 hane"
                          onCommit={(v) => onPatch(r.rowId, { tcKimlikNo: v })}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <TextCell value={r.telefon} placeholder="Telefon" onCommit={(v) => onPatch(r.rowId, { telefon: v })} />
                      </td>
                      <td className="px-1 py-1">
                        <TextCell value={r.email} error={r.fieldErrors.email} placeholder="E-posta" onCommit={(v) => onPatch(r.rowId, { email: v })} />
                      </td>
                      <td className="px-1 py-1">
                        <MeslekCell
                          row={r}
                          onSelect={(m, g) => onSelectMeslek(r.rowId, m, g)}
                        />
                      </td>
                      <td className="px-1 py-1">
                        <DateCell value={r.iseGirisTarihi} error={r.fieldErrors.iseGiris} onCommit={(v) => onPatch(r.rowId, { iseGirisTarihi: v })} />
                      </td>
                      <td className="px-1 py-1">
                        <DateCell value={r.dogumTarihi} error={r.fieldErrors.dogum} onCommit={(v) => onPatch(r.rowId, { dogumTarihi: v })} />
                      </td>
                      <td className="px-1 py-1">
                        <TextCell value={r.sicilNo} placeholder="Sicil" onCommit={(v) => onPatch(r.rowId, { sicilNo: v })} />
                      </td>
                      <td className="px-2 py-1">
                        <StatusBadge tone={meta.tone}>{meta.label}</StatusBadge>
                      </td>
                      <td className="px-2 py-1">
                        <span className={`text-[11px] ${r.errors.length > 0 ? 'text-danger-600' : 'text-warning-600'}`}>
                          {aciklama || '—'}
                        </span>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-foreground-500">
          {filtered.length === 0 ? '0 kayıt' : `${rangeFrom}–${rangeTo} / ${filtered.length} kayıt`} · Sayfa {current}/{totalPages}
        </p>
        <div className="flex items-center gap-2">
          <select
            value={pageSize}
            onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
            className="isg-input isg-input-sm w-auto"
            aria-label="Sayfa başına kayıt sayısı"
          >
            {[10, 25, 50, 100].map((s) => <option key={s} value={s}>{s} / sayfa</option>)}
          </select>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              aria-label="İlk sayfa"
              disabled={current <= 1}
              onClick={() => setPage(1)}
              className="w-7 h-7 rounded-md border border-background-300/60 dark:border-background-400/30 flex items-center justify-center text-foreground-600 hover:bg-background-200 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <i className="ri-arrow-left-double-line" />
            </button>
            <button
              type="button"
              aria-label="Önceki sayfa"
              disabled={current <= 1}
              onClick={() => setPage(current - 1)}
              className="w-7 h-7 rounded-md border border-background-300/60 dark:border-background-400/30 flex items-center justify-center text-foreground-600 hover:bg-background-200 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <i className="ri-arrow-left-s-line" />
            </button>
            <span className="px-1 text-xs font-medium text-foreground-700 tabular-nums">{current}/{totalPages}</span>
            <button
              type="button"
              aria-label="Sonraki sayfa"
              disabled={current >= totalPages}
              onClick={() => setPage(current + 1)}
              className="w-7 h-7 rounded-md border border-background-300/60 dark:border-background-400/30 flex items-center justify-center text-foreground-600 hover:bg-background-200 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <i className="ri-arrow-right-s-line" />
            </button>
            <button
              type="button"
              aria-label="Son sayfa"
              disabled={current >= totalPages}
              onClick={() => setPage(totalPages)}
              className="w-7 h-7 rounded-md border border-background-300/60 dark:border-background-400/30 flex items-center justify-center text-foreground-600 hover:bg-background-200 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
            >
              <i className="ri-arrow-right-double-line" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}