import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import StatusBadge from '@/components/ui/StatusBadge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import FilterBar from '@/components/ui/FilterBar';
import type { FilterField, FilterValue } from '@/components/ui/FilterBar';
import Pagination from '@/components/ui/Pagination';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import { ModalSkeleton, ListSkeleton } from '@/components/ui/Skeleton';
import { useModalActions } from '@/hooks/useModal';
import { useIdlePrefetch } from '@/hooks/useIdlePrefetch';
import { useToastActions } from '@/hooks/useToast';
import { useExcelBrandMeta } from '@/hooks/useExcelBrandMeta';
import { useUzmanFirma } from '@/context/UzmanFirmaContext';
import { fetchPersonelRaporRows, indirPersonelRaporXlsx } from '@/lib/personelRaporService';
import {
  fetchFirmaPersonelKpi,
  fetchFirmaPersonelListe,
  fetchPanelFirmalari,
  type FirmaPersonelKpi,
  type PanelFirma,
  type PersonelListeSatir,
} from '@/lib/firmaPersonelService';
import {
  basHarfler,
  formatTarih,
  kalanGunGosterim,
  kalanGunRenkSinifi,
  maskTc,
  SAGLIK_UYGUNLUK_LABEL,
  saglikUygunlukVariant,
} from './personelFirmaUi';

// ── PERFORMANS: Ağır alt modallar (Excel parser/xlsx, personel detay sekmeleri)
// personel listesi route chunk'ına statik girmesin. Yalnızca ilgili buton
// tıklandığında indirilir. Liste ekranı sadece özet veri + ince kabuk taşır. ──
const YeniFirmaPersonelModal = lazy(() => import('./YeniFirmaPersonelModal'));
const ExcelPersonelImportModal = lazy(() => import('./ExcelPersonelImportModal'));
const PersonelDetayModal = lazy(() => import('./detay/PersonelDetayModal'));
const TopluEvrakModal = lazy(() => import('@/components/feature/evrak/topluEvrak/TopluEvrakModal'));

/** Modal gövdesi için ortak lazy yükleme göstergesi. */
function ModalLoading({ text }: { text: string }) {
  return <ModalSkeleton variant="detail" label={text} />;
}

// Firma Personeller modülü — Firma ve Uzman panelleri aynı bileşeni kullanır.

interface Props {
  panel: 'firma' | 'uzman' | 'hekim';
}

function asStr(v: FilterValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

function KpiKart({ icon, label, value, tone }: { icon: string; label: string; value: number; tone: string }) {
  return (
    <div className="isg-card p-3 flex items-center gap-3">
      <span className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${tone}`}>
        <i className={`${icon} text-lg`} />
      </span>
      <div className="min-w-0">
        <p className="text-xl font-bold text-foreground-950 leading-tight">{value}</p>
        <p className="isg-text-caption text-foreground-500 truncate">{label}</p>
      </div>
    </div>
  );
}

export default function FirmaPersonellerModule({ panel }: Props) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const getBrandMeta = useExcelBrandMeta();
  const newModalRef = useRef('');
  const importModalRef = useRef('');
  const detailModalRef = useRef('');
  const topluEvrakRef = useRef('');

  const [firmalar, setFirmalar] = useState<PanelFirma[]>([]);
  const [firmaHata, setFirmaHata] = useState<string | null>(null);
  // Uzman ve Hekim panellerinde firma seçimi TOPBAR'daki global seçiciden gelir; firma
  // panelinde kullanıcı zaten kendi firmasına bağlıdır (ilk yetkili firma).
  const { selectedFirmaId } = useUzmanFirma();
  const firmaId = panel === 'firma' ? firmalar[0]?.id || '' : selectedFirmaId || firmalar[0]?.id || '';

  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState<Record<string, FilterValue>>({});
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  // Aktif / İşten Ayrılmış — çalışma durumu artık bir FİLTRE değil, ana SEKMEdir.
  const [tab, setTab] = useState<'aktif' | 'ayrilmis'>('aktif');
  const [raporBusy, setRaporBusy] = useState(false);

  const [rows, setRows] = useState<PersonelListeSatir[]>([]);
  const [count, setCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [kpi, setKpi] = useState<FirmaPersonelKpi | null>(null);

  const aktifFirma = useMemo(() => firmalar.find((f) => f.id === firmaId) ?? null, [firmalar, firmaId]);
  // Firma panelinde kullanıcı zaten kendi firmasına bağlı olduğu için ekleme her zaman
  // aktiftir. Uzman panelinde seçili firma varsa eklenebilir. Hekim paneli personel
  // OLUŞTURMAZ (RLS zaten reddeder); yalnızca görüntüler ve sağlık işlemi yapar.
  const ekleyebilir = aktifFirma != null && panel !== 'hekim';

  useEffect(() => {
    fetchPanelFirmalari()
      .then((fs) => setFirmalar(fs))
      .catch((e) => setFirmaHata(e instanceof Error ? e.message : 'Firmalar yüklenemedi.'));
  }, []);

  // Topbar'dan firma değişince sayfa/filtre sıfırlanır (1. sayfadan yeniden yüklenir).
  useEffect(() => { setPage(1); }, [firmaId]);
  // Sekme değişince de 1. sayfadan yeniden yüklenir.
  useEffect(() => { setPage(1); }, [tab]);

  const load = useCallback(() => {
    if (!firmaId) return;
    setLoading(true);
    setError(null);
    fetchFirmaPersonelListe({
      firmaId,
      search: search || undefined,
      durum: tab === 'aktif' ? 'aktif' : 'ayrilmis',
      meslekiBelge: (asStr(filters['mesleki']) as 'eksik' | 'tam' | 'gerekli_degil' | '') || '',
      saglikDurum: (asStr(filters['saglik']) as 'uygun' | 'uygun_degil' | 'yok' | '') || '',
      egitimDurum: (asStr(filters['egitim']) as 'gecerli' | 'yaklasiyor' | 'suresi_doldu' | 'yok' | '') || '',
      page,
      pageSize,
    })
      .then((res) => { setRows(res.rows); setCount(res.count); })
      .catch((e) => setError(e instanceof Error ? e.message : 'Personeller yüklenemedi.'))
      .finally(() => setLoading(false));
  }, [firmaId, search, filters, page, pageSize, tab]);

  useEffect(() => { load(); }, [load]);

  const loadKpi = useCallback(() => {
    if (!firmaId) { setKpi(null); return; }
    fetchFirmaPersonelKpi(firmaId).then(setKpi).catch(() => setKpi(null));
  }, [firmaId]);

  useEffect(() => { loadKpi(); }, [loadKpi]);

  const refreshAll = useCallback(() => { load(); loadKpi(); }, [load, loadKpi]);

  // “Rapor Al” → modal AÇMADAN doğrudan XLSX indirir (2 sheet: Aktif / İşten Ayrılmış).
  const raporAl = useCallback(async () => {
    if (!firmaId) return;
    setRaporBusy(true);
    try {
      const rows = await fetchPersonelRaporRows(firmaId);
      if (rows.length === 0) {
        addToast({ title: 'Rapor boş', message: 'Bu firma için personel kaydı bulunamadı.', type: 'info' });
        return;
      }
      // Excel, ekipman raporuyla BİREBİR aynı kurumsal tasarımı kullanır
      // (kurumsal header + logo + lacivert panel + tablo + footer).
      const meta = await getBrandMeta({ firmaId, firmaAdi: aktifFirma?.unvan ?? '' });
      await indirPersonelRaporXlsx(rows, meta);
      addToast({ title: 'Rapor indirildi', message: `${rows.length} personel kaydı Excel olarak indirildi.`, type: 'success' });
    } catch (e) {
      addToast({ title: 'Rapor alınamadı', message: e instanceof Error ? e.message : 'İşlem tamamlanamadı.', type: 'error' });
    } finally {
      setRaporBusy(false);
    }
  }, [firmaId, aktifFirma, getBrandMeta, addToast]);

  const openYeni = useCallback(() => {
    if (!aktifFirma) return;
    if (newModalRef.current) return;
    const viewportH = typeof window !== 'undefined' ? window.innerHeight : 900;
    const id = openModal({
      title: 'Yeni Personel Ekle',
      description: 'Firmanın çalışanını sisteme ekleyin. Evrak yükleme isteğe bağlıdır, daha sonra da eklenebilir.',
      wide: true,
      width: 1180,
      height: Math.max(620, viewportH - 48),
      minWidth: 900,
      minHeight: 620,
      showFooter: false,
      closable: true,
      resizable: true,
      bodyLayout: 'fill',
      // Guard ref'i modalın HER kapanış yolunda (X / ESC / içerideki İptal) temizlenir;
      // aksi halde buton bir daha modal açmaz (rota değişene kadar).
      onClose: () => { newModalRef.current = ''; },
      content: (
        <Suspense fallback={<ModalLoading text="Form yükleniyor..." />}>
          <YeniFirmaPersonelModal
            firma={aktifFirma}
            onClose={() => { closeModal(newModalRef.current); newModalRef.current = ''; }}
            onCreated={refreshAll}
          />
        </Suspense>
      ),
    });
    newModalRef.current = id;
  }, [aktifFirma, openModal, closeModal, refreshAll]);

  const openExcelImport = useCallback(() => {
    if (!aktifFirma) return;
    const viewportH = typeof window !== 'undefined' ? window.innerHeight : 900;
    const id = openModal({
      dedupeKey: `firma-excel-import:${aktifFirma.id}`,
      title: "Excel'den Toplu Personel Ekle ve Eşleştir",
      description: 'Kendi Excel dosyanızı yükleyin, kolonları eşleştirin ve personelleri tek seferde sisteme ekleyin. Şablon kullanmak zorunlu değildir.',
      wide: true,
      width: 1180,
      height: Math.max(680, viewportH - 40),
      minWidth: 900,
      minHeight: 620,
      showFooter: false,
      closable: true,
      resizable: true,
      bodyLayout: 'fill',
      content: (
        <Suspense fallback={<ModalLoading text="Excel modülü yükleniyor..." />}>
          <ExcelPersonelImportModal
            firmaId={aktifFirma.id}
            onClose={() => { closeModal(importModalRef.current); importModalRef.current = ''; }}
            onCompleted={refreshAll}
          />
        </Suspense>
      ),
    });
    importModalRef.current = id;
  }, [aktifFirma, openModal, closeModal, refreshAll]);

  const openTopluEvrak = useCallback(() => {
    if (!firmaId) return;
    const viewportH = typeof window !== 'undefined' ? window.innerHeight : 900;
    const id = openModal({
      dedupeKey: `toplu-evrak:${firmaId}`,
      title: 'Toplu Evrak Yükle ve Eşleştir',
      description: 'PDF dosyanızı yükleyin, sayfaları personellere ve belge türlerine eşleştirerek kaydedin.',
      variant: 'large',
      wide: true,
      width: 1360,
      height: Math.max(680, viewportH - 40),
      minWidth: 1024,
      minHeight: 620,
      showFooter: false,
      closable: true,
      resizable: true,
      maximizable: true,
      bodyLayout: 'fill',
      content: (
        <Suspense fallback={<ModalLoading text="Toplu evrak modülü yükleniyor..." />}>
          <TopluEvrakModal
            firmaId={firmaId}
            role={panel}
            onClose={() => { closeModal(topluEvrakRef.current); topluEvrakRef.current = ''; }}
            onCompleted={refreshAll}
          />
        </Suspense>
      ),
    });
    topluEvrakRef.current = id;
  }, [firmaId, panel, openModal, closeModal, refreshAll]);

  const openDetay = useCallback((row: PersonelListeSatir) => {
    const viewportH = typeof window !== 'undefined' ? window.innerHeight : 900;
    const id = openModal({
      dedupeKey: `firma-personel-detay:${row.id}`,
      title: 'Personel Detay',
      description: 'Personel bilgilerini, mesleki belgelerini, eğitim, sağlık ve evraklarını görüntüleyin.',
      variant: 'detail',
      wide: true,
      width: 1180,
      height: Math.max(600, viewportH - 48),
      minWidth: 760,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      bodyLayout: 'fill',
      content: (
        <Suspense fallback={<ModalLoading text="Personel detayı yükleniyor..." />}>
          <PersonelDetayModal personelId={row.id} onClose={() => closeModal(detailModalRef.current)} onChanged={refreshAll} />
        </Suspense>
      ),
    });
    detailModalRef.current = id;
  }, [openModal, closeModal, refreshAll]);

  // ── PERFORMANS: Ağır personel detay / yeni personel / Excel import modal
  // chunk'larını tarayıcı BOŞTAYKEN önceden indir. Kullanıcı "Detay"a bastığında
  // ya da "Personel Ekle" dediğinde lazy import modül cache'inden ANINDA çözülür;
  // "Personel detayı yükleniyor..." beklemesi ortadan kalkar. Liste ekranını
  // bloklamaz (yalnızca idle penceresinde, fire-and-forget). ──
  useIdlePrefetch([
    () => import('./detay/PersonelDetayModal'),
    () => import('./YeniFirmaPersonelModal'),
    () => import('./ExcelPersonelImportModal'),
    () => import('@/components/feature/evrak/topluEvrak/TopluEvrakModal'),
  ]);

  const filterFields: FilterField[] = useMemo(() => [
    {
      key: 'mesleki', label: 'Mesleki Belge Durumu', type: 'select',
      options: [
        { value: 'tam', label: 'Tam' },
        { value: 'eksik', label: 'Eksik' },
        { value: 'gerekli_degil', label: 'Gerekli Değil' },
      ],
    },
    {
      key: 'saglik', label: 'Sağlık Durumu', type: 'select',
      options: [
        { value: 'uygun', label: 'Uygun' },
        { value: 'uygun_degil', label: 'Uygun Değil' },
        { value: 'yok', label: 'Kayıt Yok' },
      ],
    },
    {
      key: 'egitim', label: 'Eğitim Durumu', type: 'select',
      options: [
        { value: 'gecerli', label: 'Geçerli' },
        { value: 'yaklasiyor', label: 'Yaklaşıyor' },
        { value: 'suresi_doldu', label: 'Süresi Doldu' },
        { value: 'yok', label: 'Kayıt Yok' },
      ],
    },
  ], []);

  const columns: TableColumn<PersonelListeSatir>[] = [
    {
      key: 'personel', header: 'Personel',
      render: (r) => (
        <div className="flex items-center gap-2.5 min-w-[180px]">
          <span className="w-9 h-9 rounded-lg bg-primary-500 flex items-center justify-center flex-shrink-0">
            <span className="text-[11px] font-bold text-inverse">{basHarfler(r.adSoyad)}</span>
          </span>
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground-800 truncate">{r.adSoyad}</p>
            <p className="isg-text-caption text-foreground-400 tabular-nums">{maskTc(r.tcKimlikNo)}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'gorev', header: 'Görev / Meslek',
      render: (r) => (
        <div className="min-w-[140px]">
          <p className="text-sm text-foreground-800 truncate">{r.gorev}</p>
          {r.occupationCode !== '—' && <p className="isg-text-caption text-foreground-400">İŞKUR: {r.occupationCode}</p>}
        </div>
      ),
    },
    {
      key: 'mesleki', header: 'Mesleki Belge Durumu',
      render: (r) => {
        const m = r.zengin.meslekiBelge;
        if (m.durum === 'gerekli_degil') return <StatusBadge tone="neutral">Gerekli Değil</StatusBadge>;
        if (m.durum === 'tam') return <div className="flex items-center gap-1.5"><Badge variant="accent">Gerekli</Badge><StatusBadge tone="success">Tam</StatusBadge></div>;
        return <div className="flex items-center gap-1.5"><Badge variant="accent">Gerekli</Badge><StatusBadge tone="danger">{m.eksikSayi} Eksik</StatusBadge></div>;
      },
    },
    {
      key: 'saglik', header: 'Sağlık Muayenesi',
      render: (r) => {
        const u = r.zengin.saglik.uygunluk;
        const v = saglikUygunlukVariant(u);
        return (
          <StatusBadge tone={v === 'success' ? 'success' : v === 'danger' ? 'danger' : 'neutral'}>
            {SAGLIK_UYGUNLUK_LABEL[u]}
          </StatusBadge>
        );
      },
    },
    {
      key: 'egitim', header: 'İSG Eğitimi',
      render: (r) => (
        <div className="min-w-[120px]">
          {r.zengin.egitim.egitimTarihi ? (
            <>
              <p className="text-sm text-foreground-800">{formatTarih(r.zengin.egitim.egitimTarihi)}</p>
              <p className={`isg-text-caption ${kalanGunRenkSinifi(r.zengin.egitim.kalanGun)}`}>{kalanGunGosterim(r.zengin.egitim.kalanGun)}</p>
            </>
          ) : <span className="isg-text-caption text-foreground-400">Kayıt yok</span>}
        </div>
      ),
    },
    {
      key: 'evrak', header: 'Evraklar',
      render: (r) => {
        const { var_: v, toplam: t, durum } = r.zengin.evrak;
        // Gerçek gereksinim yoksa sahte 0/0 gösterme — net "Gerekli Değil".
        if (t === 0 || durum === 'gerekli_degil') {
          return <span className="isg-text-caption text-foreground-400">Gerekli Değil</span>;
        }
        const y = Math.min(100, Math.round((v / t) * 100));
        return (
          <div className="min-w-[110px]">
            <div className="flex items-center justify-between gap-2 mb-1">
              <span className="text-sm text-foreground-800">{v} / {t}</span>
              <span className="isg-text-caption text-foreground-400">%{y}</span>
            </div>
            <div className="h-1.5 rounded-full bg-background-200 dark:bg-background-300/40 overflow-hidden">
              <div className={`h-full ${durum === 'eksik' ? 'bg-warning-500' : 'bg-success-500'}`} style={{ width: `${y}%` }} />
            </div>
          </div>
        );
      },
    },
    {
      key: 'calisma', header: 'Çalışma Durumu',
      render: (r) => <StatusBadge tone={r.isActive ? 'success' : 'neutral'}>{r.durum}</StatusBadge>,
    },
    {
      key: 'islemler', header: 'İşlemler', align: 'right',
      render: (r) => (
        <div className="flex justify-end" onClick={(e) => e.stopPropagation()}>
          <Button variant="secondary" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={() => openDetay(r)} className="whitespace-nowrap">Detay</Button>
        </div>
      ),
    },
  ];

  const totalPages = Math.max(1, Math.ceil(count / pageSize));

  return (
    <div className="isg-page flex flex-col gap-3">
      <PageHeader
        title={panel === 'firma' ? 'Firma Personeller' : 'Personeller'}
        subtitle="Firmanın çalışanları, görevleri, mesleki belgeleri, İSG eğitimleri ve sağlık durumları"
        className="flex-shrink-0"
        actions={
          <>
            {ekleyebilir && (
              <Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={openYeni} className="whitespace-nowrap">Personel Ekle</Button>
            )}
            {ekleyebilir && (
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-file-excel-2-line" />} onClick={openExcelImport} className="whitespace-nowrap">Toplu Personel Ekle</Button>
            )}
            {ekleyebilir && (
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-stack-line" />} onClick={openTopluEvrak} className="whitespace-nowrap">Toplu Evrak Yükle</Button>
            )}
            {ekleyebilir && (
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-download-2-line" />} onClick={raporAl} isLoading={raporBusy} className="whitespace-nowrap">Rapor Al</Button>
            )}
          </>
        }
      />

      {firmaHata ? (
        <ErrorState message={firmaHata} />
      ) : firmalar.length === 0 ? (
        <EmptyState icon="ri-building-line" title="Firma bulunmuyor." description="Yetkili olduğunuz aktif bir firma bulunamadı." />
      ) : (
        <>
          {/* Aktif / İşten Ayrılmış sekmeleri — toolbar'dan ayrı, net konumlanır */}
          <div className="flex items-center gap-1 p-1 rounded-lg border border-background-300/60 dark:border-background-400/30 bg-background-100 dark:bg-background-200/50 w-full sm:w-auto self-start flex-shrink-0">
            <button
              type="button"
              onClick={() => setTab('aktif')}
              className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md text-sm whitespace-nowrap transition-colors cursor-pointer ${
                tab === 'aktif'
                  ? 'bg-primary-500 text-inverse font-medium'
                  : 'text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40'
              }`}
            >
              <i className="ri-user-follow-line" /> Aktif Personeller
            </button>
            <button
              type="button"
              onClick={() => setTab('ayrilmis')}
              className={`flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md text-sm whitespace-nowrap transition-colors cursor-pointer ${
                tab === 'ayrilmis'
                  ? 'bg-primary-500 text-inverse font-medium'
                  : 'text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40'
              }`}
            >
              <i className="ri-user-unfollow-line" /> İşten Ayrılmış Personeller
            </button>
          </div>

          {/* KPI */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 flex-shrink-0">
            <KpiKart icon="ri-team-line" label="Toplam Personel" value={kpi?.toplam ?? 0} tone="bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-400" />
            <KpiKart icon="ri-user-follow-line" label="Aktif Çalışan" value={kpi?.aktif ?? 0} tone="bg-success-100 text-success-700 dark:bg-success-500/20 dark:text-success-400" />
            <KpiKart icon="ri-user-unfollow-line" label="Ayrılmış Çalışan" value={kpi?.ayrilmis ?? 0} tone="bg-background-200 text-foreground-600 dark:bg-background-300/40" />
            <KpiKart icon="ri-folder-warning-line" label="Eksik Evrak" value={kpi?.eksikEvrak ?? 0} tone="bg-danger-100 text-danger-700 dark:bg-danger-500/20 dark:text-danger-400" />
            <KpiKart icon="ri-error-warning-line" label="Yaklaşan Yenileme" value={kpi?.yaklasanYenileme ?? 0} tone="bg-warning-100 text-warning-700 dark:bg-warning-500/20 dark:text-warning-400" />
            <KpiKart icon="ri-alarm-warning-line" label="Süresi Dolan" value={kpi?.suresiDolan ?? 0} tone="bg-danger-100 text-danger-700 dark:bg-danger-500/20 dark:text-danger-400" />
          </div>

          {/* Liste */}
          <div className="isg-card flex flex-col p-3 min-h-0">
            <FilterBar
              filters={filterFields}
              values={filters}
              onChange={(k, v) => { setFilters((prev) => ({ ...prev, [k]: v })); setPage(1); }}
              onReset={() => { setFilters({}); setSearch(''); setPage(1); }}
              onSearch={setSearch}
              searchPlaceholder="Ad, soyad, T.C. kimlik no, görev..."
            />
            <div className="mt-3">
              {loading ? (
                <ListSkeleton rows={8} />
              ) : error ? (
                <ErrorState message={error} onRetry={load} />
              ) : rows.length === 0 ? (
                <EmptyState icon="ri-team-line" title="Personel bulunmuyor." description="Arama/filtre kriterlerinizi değiştirin veya yeni bir personel ekleyin." action={ekleyebilir ? { label: 'Personel Ekle', onClick: openYeni, icon: 'ri-add-line' } : undefined} />
              ) : (
                <>
                  <div className="overflow-x-auto">
                    <Table data={rows} columns={columns} keyExtractor={(r) => r.id} onRowClick={openDetay} density="compact" />
                  </div>
                  <div className="mt-3 pt-3 border-t border-background-300/25 dark:border-background-400/25">
                    <Pagination currentPage={page} totalPages={totalPages} pageSize={pageSize} totalItems={count} onPageChange={setPage} onPageSizeChange={(s) => { setPageSize(s); setPage(1); }} />
                  </div>
                </>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}