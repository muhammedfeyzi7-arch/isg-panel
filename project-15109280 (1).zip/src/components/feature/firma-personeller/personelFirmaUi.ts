import type { GereksinimDurum, KayitDurum, MeslekiBelgeDurum, SaglikUygunluk } from '@/lib/firmaPersonelService';
import { formatIstanbulDate, formatIstanbulDateTime } from '@/lib/dateFormat';
import { maskTcKimlik } from '@/lib/tcKimlik';

export type BadgeVariant =
  | 'default'
  | 'success'
  | 'warning'
  | 'danger'
  | 'info'
  | 'primary'
  | 'secondary'
  | 'accent';

/** T.C. kimlik no maskesi — merkezi `maskTcKimlik` üzerinden (tek standart). */
export function maskTc(tc: string | null | undefined): string {
  return maskTcKimlik(tc);
}

/** "YYYY-MM-DD"/ISO → "05.09.2026". Merkezi standart görünüm. */
export function formatTarih(iso: string | null | undefined): string {
  return formatIstanbulDate(iso);
}

/** ISO datetime → "05.09.2026 14:32". Merkezi standart görünüm. */
export function formatTarihSaat(iso: string | null | undefined): string {
  return formatIstanbulDateTime(iso);
}

/** Kalan gün → "343 gün" / "Süresi doldu" metni. */
export function kalanGunMetni(kalan: number | null): string {
  if (kalan === null) return '—';
  if (kalan < 0) return `${Math.abs(kalan)} gün geçti`;
  if (kalan === 0) return 'Bugün son';
  return `${kalan} gün`;
}

/**
 * Kalan gün uyarı eşikleri — merkezi görsel uyarı tokenları (mevzuat süresi DEĞİL).
 * Gün azaldıkça renk normal → uyarı → kritik → expired yönünde değişir.
 */
export const KALAN_GUN_ESIK = { kritik: 30, uyari: 90 } as const;

/** Kalan gün sayısına göre metin renk sınıfı (dinamik renklendirme). */
export function kalanGunRenkSinifi(kalan: number | null): string {
  if (kalan === null) return 'text-foreground-400';
  if (kalan < 0) return 'text-danger-700 font-medium';
  if (kalan <= KALAN_GUN_ESIK.kritik) return 'text-danger-600 font-medium';
  if (kalan <= KALAN_GUN_ESIK.uyari) return 'text-warning-600 font-medium';
  return 'text-success-600';
}

/** Kalan gün yoksa "Kayıt yok", varsa renkli kalan süre metni. */
export function kalanGunGosterim(kalan: number | null): string {
  if (kalan === null) return 'Kayıt yok';
  return kalanGunMetni(kalan);
}

export const EGITIM_DURUM_LABEL: Record<KayitDurum, string> = {
  gecerli: 'Geçerli',
  yaklasiyor: 'Yaklaşıyor',
  suresi_doldu: 'Süresi Doldu',
  yok: 'Kayıt Yok',
};

export function egitimDurumVariant(d: KayitDurum): BadgeVariant {
  if (d === 'gecerli') return 'success';
  if (d === 'yaklasiyor') return 'warning';
  if (d === 'suresi_doldu') return 'danger';
  return 'default';
}

export const SAGLIK_DURUM_LABEL: Record<KayitDurum, string> = {
  gecerli: 'Uygun',
  yaklasiyor: 'Yaklaşıyor',
  suresi_doldu: 'Süresi Doldu',
  yok: 'Kayıt Yok',
};

/**
 * KVKK — Firma ve Uzman için geçerli 3 durumlu sağlık uygunluğu. Tıbbi detay YOK.
 */
export const SAGLIK_UYGUNLUK_LABEL: Record<SaglikUygunluk, string> = {
  uygun: 'Uygun',
  uygun_degil: 'Uygun Değil',
  yok: 'Kayıt Yok',
};

export function saglikUygunlukVariant(d: SaglikUygunluk): BadgeVariant {
  if (d === 'uygun') return 'success';
  if (d === 'uygun_degil') return 'danger';
  return 'default';
}

export function saglikDurumVariant(d: KayitDurum): BadgeVariant {
  if (d === 'gecerli') return 'success';
  if (d === 'yaklasiyor') return 'warning';
  if (d === 'suresi_doldu') return 'danger';
  return 'default';
}

export const MESLEKI_BELGE_LABEL: Record<MeslekiBelgeDurum, string> = {
  tam: 'Tam',
  eksik: 'Eksik',
  gerekli_degil: 'Gerekli Değil',
};

export const GEREKSINIM_DURUM_LABEL: Record<GereksinimDurum, string> = {
  tamamlandi: 'Tamamlandı',
  eksik: 'Eksik',
  gerekli_degil: 'Gerekli Değil',
  opsiyonel: 'Opsiyonel',
};

export function gereksinimVariant(d: GereksinimDurum): BadgeVariant {
  if (d === 'tamamlandi') return 'success';
  if (d === 'eksik') return 'danger';
  if (d === 'opsiyonel') return 'secondary';
  return 'default';
}

export function evrakStatusLabel(status: string): string {
  const map: Record<string, string> = {
    valid: 'Geçerli',
    expiring: 'Süresi Yaklaşıyor',
    expired: 'Süresi Doldu',
    pending: 'Doğrulama Bekliyor',
    rejected: 'Reddedildi',
    verification_required: 'Doğrulama Gerekli',
  };
  return map[status] ?? status;
}

export function evrakStatusVariant(status: string): BadgeVariant {
  if (status === 'valid') return 'success';
  if (status === 'expiring' || status === 'verification_required' || status === 'pending') return 'warning';
  if (status === 'expired' || status === 'rejected') return 'danger';
  return 'default';
}

export function dosyaBoyutMetni(bytes: number | null): string {
  if (!bytes) return '—';
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  if (bytes >= 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${bytes} B`;
}

export function dosyaIkonu(mime: string | null): string {
  if (!mime) return 'ri-file-line';
  if (mime.includes('pdf')) return 'ri-file-pdf-2-line';
  if (mime.startsWith('image/')) return 'ri-image-line';
  if (mime.includes('word') || mime.includes('officedocument.word')) return 'ri-file-word-2-line';
  if (mime.includes('excel') || mime.includes('spreadsheet')) return 'ri-file-excel-2-line';
  return 'ri-file-line';
}

/** İşe giriş tarihinden bugüne (veya çıkış tarihine) kadar süre metni. */
export function calismaSuresiMetni(
  iseGiris: string | null | undefined,
  istenCikis: string | null | undefined,
  aktif: boolean,
): string {
  if (!iseGiris || iseGiris === '—') return '';
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iseGiris);
  if (!m) return '';
  const start = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  let end = new Date();
  if (!aktif && istenCikis) {
    const mm = /^(\d{4})-(\d{2})-(\d{2})/.exec(istenCikis);
    if (mm) end = new Date(Number(mm[1]), Number(mm[2]) - 1, Number(mm[3]));
  }
  let months = (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth());
  if (end.getDate() < start.getDate()) months -= 1;
  if (months <= 0) return aktif ? 'yeni başladı' : 'kısa süre';
  const yil = Math.floor(months / 12);
  const ay = months % 12;
  const parts: string[] = [];
  if (yil > 0) parts.push(`${yil} yıl`);
  if (ay > 0) parts.push(`${ay} ay`);
  const sure = parts.join(' ');
  return aktif ? `${sure}dır çalışıyor` : `${sure} çalıştı`;
}

export function basHarfler(adSoyad: string): string {
  const parts = adSoyad.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '—';
  return parts.slice(0, 2).map((p) => p.charAt(0)).join('').toLocaleUpperCase('tr-TR');
}