// ─────────────────────────────────────────────────────────────────────────────
// EXCEL'DEN TOPLU PERSONEL EKLE VE EŞLEŞTİR — TEK MODAL / TEK EKRAN
//
// Firma Paneli (Firma Personeller) ve Uzman Paneli (Personeller) AYNI bu ortak
// bileşeni kullanır. Excel seç → kolonlar otomatik eşleşir → kullanıcı düzenler
// → satırlar önizlenir → hatalı hücre tıklanarak düzeltilir → tek tuşla kayıt.
// Mevcut import motoru (parse/analyze/normalize) + personel-import edge function
// yeniden kullanılır; ikinci bir motor/UI oluşturulmaz.
// ─────────────────────────────────────────────────────────────────────────────
import { useCallback, useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import Button from '@/components/ui/Button';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import Checkbox from '@/components/ui/Checkbox';
import Loading from '@/components/ui/Loading';
import { useToastActions } from '@/hooks/useToast';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import { parseImportFile } from '@/lib/import/excel';
import { autoMapColumns } from '@/lib/import/engine';
import { downloadBlobFile } from '@/lib/downloadFile';
import type { ColumnMapping, ExistingRecord, ParsedFile, ParsedSheet } from '@/lib/import/types';
import { PERSONEL_FIELD_DEFS } from '@/lib/personelImport';
import {
  fetchFirmaPersonelForImport,
  matchIskurMeslekler,
  runPersonelImport,
  friendlyImportError,
} from '@/lib/personelImportService';
import type { IskurMeslekSecim } from '@/lib/firmaPersonelService';
import {
  applyIskurMatches,
  buildEditableRows,
  markFileDuplicates,
  revalidateRow,
  summarizeRows,
  toPayloadRow,
  uniqueGorevler,
  type EditableImportRow,
} from '@/lib/personelImportSession';
import { ImportCounters, ImportPreviewTable, MappingCards } from './components/ExcelImportParts';

const ACCEPT = '.xlsx,.xls,.csv';
const MAX_SIZE = 20 * 1024 * 1024;
const TEMPLATE_COLS = ['Ad Soyad', 'T.C. Kimlik No', 'Telefon', 'E-posta', 'Görev / Meslek', 'İşe Giriş Tarihi', 'Doğum Tarihi', 'Sicil No'];

interface Props {
  firmaId: string | null;
  onClose: () => void;
  onCompleted: () => void;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function downloadTemplate() {
  const ornek = [
    TEMPLATE_COLS,
    ['Ahmet Yılmaz', '12345678901', '0532 111 22 33', 'ahmet@ornek.com', 'Forklift Operatörü', '15.03.2024', '01.01.1990', 'K-001'],
  ];
  const ws = XLSX.utils.aoa_to_sheet(ornek);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'Personeller');
  // Merkezî indirme: anlamlı şablon adı (UUID yok).
  const buffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  downloadBlobFile(blob, 'Personel_Import_Sablonu.xlsx');
}

export default function ExcelPersonelImportModal({ firmaId, onClose, onCompleted }: Props) {
  const { addToast } = useToastActions();

  const [busy, setBusy] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [parsed, setParsed] = useState<ParsedFile | null>(null);
  const [sheetIndex, setSheetIndex] = useState(0);
  const [mapping, setMapping] = useState<ColumnMapping[]>([]);
  const [rows, setRows] = useState<EditableImportRow[]>([]);
  const [existing, setExisting] = useState<ExistingRecord[]>([]);
  const [updateExisting, setUpdateExisting] = useState(false);
  // Sadeleştirme: kolon eşleştirme varsayılan KAPALI; akış Excel → analiz → önizleme → aktar.
  const [showMapping, setShowMapping] = useState(false);

  const reqRef = useRef(0);
  const sheet: ParsedSheet | null = parsed?.sheets[sheetIndex] ?? null;

  const updateRowsFromSheet = useCallback(
    async (sh: ParsedSheet, map: ColumnMapping[], ex: ExistingRecord[]) => {
      const rid = ++reqRef.current;
      const base = buildEditableRows(sh, map, ex);
      setRows(base);
      const gorevler = uniqueGorevler(base);
      if (gorevler.length === 0) return;
      try {
        const matches = await matchIskurMeslekler(gorevler);
        if (rid !== reqRef.current) return;
        setRows(applyIskurMatches(base, matches, ex));
      } catch {
        /* eşleştirme başarısız olsa da satırlar kalır — kullanıcı elle seçer */
      }
    },
    [],
  );

  const handleFiles = useCallback(
    async (files: UploadFile[]) => {
      const raw = files.find((f) => f.raw)?.raw;
      if (!raw) return;
      setBusy(true);
      setError(null);
      try {
        const p = await parseImportFile(raw);
        setParsed(p);
        setSheetIndex(0);
        const first = p.sheets[0];
        const map = autoMapColumns(first, PERSONEL_FIELD_DEFS);
        setMapping(map);
        const ex = firmaId ? await fetchFirmaPersonelForImport(firmaId) : [];
        setExisting(ex);
        await updateRowsFromSheet(first, map, ex);
      } catch (e) {
        setError(friendlyErrorMessage(e, 'Dosya okunamadı.'));
      } finally {
        setBusy(false);
      }
    },
    [firmaId, updateRowsFromSheet],
  );

  const handleSheetChange = useCallback(
    (idx: number) => {
      if (!parsed) return;
      setSheetIndex(idx);
      const map = autoMapColumns(parsed.sheets[idx], PERSONEL_FIELD_DEFS);
      setMapping(map);
      updateRowsFromSheet(parsed.sheets[idx], map, existing);
    },
    [parsed, existing, updateRowsFromSheet],
  );

  const handleMappingChange = useCallback(
    (map: ColumnMapping[]) => {
      setMapping(map);
      if (sheet) updateRowsFromSheet(sheet, map, existing);
    },
    [sheet, existing, updateRowsFromSheet],
  );

  // Hücre düzeltmesi → satır yeniden doğrulanır (hata giderilirse durum anında düzelir).
  // T.C./sicil değişmiş olabileceğinden dosya-içi yinelenen durumu tüm satırlar için
  // yeniden hesaplanır (sayfa değişse bile düzenleme korunur — rows state kalıcıdır).
  const patchRow = useCallback((rowId: string, patch: Partial<EditableImportRow>) => {
    setRows((prev) => markFileDuplicates(prev.map((r) => (r.rowId === rowId ? revalidateRow({ ...r, ...patch }, existing) : r))));
  }, [existing]);

  // Meslek hücresi: İŞKUR seçimi veya serbest metin. Serbest metinde eşleştirme
  // otomatik denenir; bulunursa kanonik İŞKUR kaydı bağlanır.
  const handleSelectMeslek = useCallback(
    (rowId: string, meslek: IskurMeslekSecim | null, gorev: string) => {
      setRows((prev) => prev.map((r) => (r.rowId === rowId
        ? revalidateRow({
            ...r,
            gorev,
            occupationId: meslek?.occupationId ?? null,
            occupationCode: meslek?.occupationCode ?? null,
            occupationName: meslek?.name ?? null,
            occupationMatched: !!meslek,
          }, existing)
        : r)));
      const term = gorev.trim();
      if (meslek || term.length < 2) return;
      matchIskurMeslekler([term])
        .then((matches) => {
          const m = matches[term];
          if (!m) return;
          setRows((prev) => prev.map((r) => (r.rowId === rowId
            ? revalidateRow({ ...r, occupationId: m.occupationId, occupationCode: m.occupationCode, occupationName: m.name, occupationMatched: true }, existing)
            : r)));
        })
        .catch(() => undefined);
    },
    [existing],
  );

  const counts = useMemo(() => summarizeRows(rows), [rows]);

  const toImport = useMemo(() => {
    const creatable = rows.filter((r) => r.status !== 'hatali' && r.duplicateStrength === null && !r.fileDuplicate);
    if (!updateExisting) return creatable;
    const dups = rows.filter((r) => r.duplicateStrength === 'strong' && r.status !== 'hatali' && !r.fileDuplicate);
    return [...creatable, ...dups].sort((a, b) => a.sourceIndex - b.sourceIndex);
  }, [rows, updateExisting]);

  const handleSave = useCallback(async () => {
    if (saving) return; // çift gönderim koruması
    if (toImport.length === 0) {
      addToast({ title: 'Oluşturulacak kayıt yok', message: 'Hatalı satırlar oluşturulamaz. Lütfen hataları düzeltin.', type: 'warning' });
      return;
    }
    setSaving(true);
    setError(null);
    try {
      const payload = toImport
        .slice()
        .sort((a, b) => a.sourceIndex - b.sourceIndex)
        .map(toPayloadRow);
      const res = await runPersonelImport({
        firmaId,
        updateExisting,
        archiveExisting: false,
        rows: payload,
      });
      onCompleted();
      if (res.errors > 0) {
        addToast({
          title: 'Kısmi tamamlandı',
          message: `${res.total} kayıttan ${res.createdActive + res.createdArchive + res.updated} tanesi işlendi, ${res.errors} kayıt oluşturulamadı.`,
          type: 'warning',
        });
        onClose();
      } else {
        addToast({ title: 'Personeller oluşturuldu', message: `${res.createdActive} personel başarıyla eklendi.`, type: 'success' });
        onClose();
      }
    } catch (e) {
      const msg = friendlyImportError(e);
      setError(msg);
      addToast({ title: 'Aktarım başarısız', message: msg, type: 'error' });
    } finally {
      setSaving(false);
    }
  }, [saving, toImport, firmaId, updateExisting, addToast, onCompleted, onClose]);

  const olusturLabel = updateExisting
    ? `${toImport.length} Personeli İşle`
    : `${toImport.length} Personeli Oluştur`;

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 md:p-5 space-y-4 min-h-0">
        {/* Excel yükleme / dosya bilgisi */}
        {!parsed ? (
          <div className="space-y-2">
            <div className="flex items-center gap-3 rounded-lg border border-background-300/50 dark:border-background-400/25 bg-background-100 dark:bg-background-200/50 p-3.5">
              <div className="w-10 h-10 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
                <i className="ri-file-excel-2-line text-xl text-primary-600 dark:text-primary-400" />
              </div>
              <div className="min-w-0 flex-1">
                <h4 className="text-sm font-semibold text-foreground-900">Excel Dosyanızı Yükleyin</h4>
                <p className="text-xs text-foreground-500">
                  Kendi Excel dosyanızı kullanabilirsiniz — şablon zorunlu değildir. Kolonları sistem otomatik tanır.
                </p>
              </div>
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-download-line" />} onClick={downloadTemplate} className="whitespace-nowrap">
                Örnek Şablon
              </Button>
            </div>
            <FileUpload
              accept={ACCEPT}
              maxSize={MAX_SIZE}
              multiple={false}
              onChange={handleFiles}
              heading="Dosyayı buraya sürükleyin veya seçin"
              browseLabel="Dosya Seç"
              helpText="XLSX, XLS veya CSV · En fazla 20 MB"
            />
            {busy && <Loading text="Dosya analiz ediliyor..." />}
            {error && <p className="text-sm text-danger-600">{error}</p>}
          </div>
        ) : (
          <>
            {/* Dosya özeti */}
            <div className="flex items-center gap-3 rounded-lg border border-background-300/50 dark:border-background-400/25 bg-background-100 dark:bg-background-200/50 p-3">
              <div className="w-9 h-9 rounded-md bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
                <i className="ri-file-excel-2-line text-success-600" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-foreground-800 truncate">{parsed.fileName}</p>
                <p className="text-xs text-foreground-500">
                  {formatBytes(parsed.sizeBytes)} · {sheet?.dataRows.length ?? 0} satır · {parsed.sheets.length} sayfa
                </p>
              </div>
              {parsed.sheets.length > 1 && (
                <select
                  value={sheetIndex}
                  onChange={(e) => handleSheetChange(Number(e.target.value))}
                  className="isg-input isg-input-sm w-auto"
                >
                  {parsed.sheets.map((s, i) => (
                    <option key={s.name} value={i}>{s.name} ({s.dataRows.length})</option>
                  ))}
                </select>
              )}
              <Button variant="ghost" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={() => { setParsed(null); setRows([]); setMapping([]); setError(null); }} className="whitespace-nowrap">
                Değiştir
              </Button>
            </div>

            {busy && <Loading text="Yeniden analiz ediliyor..." />}

            <div>
              <button
                type="button"
                onClick={() => setShowMapping((v) => !v)}
                className="flex items-center gap-1.5 text-sm font-medium text-foreground-600 hover:text-foreground-900 cursor-pointer"
              >
                <i className={showMapping ? 'ri-arrow-down-s-line' : 'ri-arrow-right-s-line'} />
                Kolon Eşleştirme (gerekirse düzenleyin)
              </button>
              {showMapping && (
                <div className="mt-2.5">
                  <MappingCards fields={PERSONEL_FIELD_DEFS} mapping={mapping} onChange={handleMappingChange} />
                </div>
              )}
            </div>

            <ImportCounters counts={counts} />

            <ImportPreviewTable
              rows={rows}
              onPatch={patchRow}
              onSelectMeslek={handleSelectMeslek}
            />

            {counts.eslesenMevcut > 0 && (
              <div className="flex items-start gap-2 rounded-lg border border-warning-200/60 dark:border-warning-400/25 bg-warning-50 dark:bg-warning-500/10 p-3">
                <Checkbox checked={updateExisting} onChange={(e) => setUpdateExisting(e.target.checked)} />
                <span onClick={() => setUpdateExisting((v) => !v)} className="text-xs text-foreground-600 leading-relaxed cursor-pointer">
                  <span className="font-medium text-foreground-800">{counts.eslesenMevcut} satır mevcut personelle eşleşiyor.</span>{' '}
                  İşaretlersen bu kayıtlar güncellenir (yalnızca boş alanlar doldurulur); işaretlemezsen atlanır. Hiçbir kayıt sessizce üzerine yazılmaz.
                </span>
              </div>
            )}

            {error && (
              <p className="text-sm text-danger-600 flex items-center gap-1">
                <i className="ri-error-warning-line" /> {error}
              </p>
            )}
          </>
        )}
      </div>

      {/* Alt aksiyon alanı */}
      <div className="flex-shrink-0 flex items-center justify-between gap-2 px-4 md:px-5 py-3 border-t border-background-300/50 dark:border-background-400/25">
        <p className="text-xs text-foreground-500 hidden sm:block">
          {parsed
            ? `${counts.olusturulabilir} oluşturulabilir · ${counts.hatali} hatalı · ${counts.uyarili} uyarılı${counts.dosyaIcindeYinelenen > 0 ? ` · ${counts.dosyaIcindeYinelenen} dosya-içi yinelenen` : ''}`
            : 'Önce bir Excel dosyası yükleyin.'}
        </p>
        <div className="flex items-center gap-2 ml-auto">
          <Button variant="secondary" onClick={onClose} disabled={saving}>İptal</Button>
          <Button
            variant="primary"
            leftIcon={<i className="ri-team-line" />}
            isLoading={saving}
            disabled={!parsed || busy || toImport.length === 0}
            onClick={handleSave}
            className="whitespace-nowrap"
          >
            {olusturLabel}
          </Button>
        </div>
      </div>
    </div>
  );
}