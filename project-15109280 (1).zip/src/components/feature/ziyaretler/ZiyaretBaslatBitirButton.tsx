import { useState } from 'react';
import Button from '@/components/ui/Button';
import Textarea from '@/components/ui/Textarea';
import { useToastActions } from '@/hooks/useToast';
import {
  startVisit,
  finishVisit,
  friendlyPlanlamaError,
  type ZiyaretDurum,
  type ProgramTuru,
} from '@/lib/planlamaService';
import { getCurrentPosition, isErrorCode } from './ziyaretlerUi';

/** Başlat/bitir için gereken minimal ziyaret referansı (ZiyaretKaydi ve occurrence ikisi de uyar). */
export interface ZiyaretOpRef {
  id: string;
  durum: ZiyaretDurum;
  planTuru: ProgramTuru;
}

interface ZiyaretBaslatBitirButtonProps {
  ziyaret: ZiyaretOpRef;
  /** Başlat/bitir sonrası listeyi tazelemek için çağrılır. */
  onChanged?: () => void;
}

interface PendingGerekce {
  mode: 'start' | 'finish';
  /** Planlanan saatten geç mi (>45 dk geç) yoksa erken mi (>45 dk erken)? */
  late: boolean;
}

/**
 * Gün Programı (tam_zamanli) ziyareti için BAŞLAT/BİTİR butonu.
 * Sahadaki kullanıcının takvime girmesine gerek kalmadan doğrudan başlat/bitir yapmasını
 * sağlar. GPS + geofence backend doğrulaması mevcut startVisit/finishVisit servisleriyle
 * aynen kullanılır.
 *
 * 45 DAKİKA TOLERANSI: Planlanan giriş/çıkış ile gerçek saat arasındaki fark 45 dakikaya
 * kadar ise gerekçe İSTENMEZ (backend ERCEN_*_GEREKCE_REQUIRED döndürmez). Fark 45 dakikayı
 * AŞARSA backend ERCEN_GELIS/GEC_GIRIS (başlangıç) veya ERCEN_CIKIS/GEC_CIKIS (bitiş) kodu
 * döner ve burada inline gerekçe formu açılır. Backend kararı esastır; burada yalnızca
 * gerçek koda göre ilgili form gösterilir (yeni modal yok).
 */
export default function ZiyaretBaslatBitirButton({ ziyaret, onChanged }: ZiyaretBaslatBitirButtonProps) {
  const { addToast } = useToastActions();
  const [operating, setOperating] = useState(false);
  const [pending, setPending] = useState<PendingGerekce | null>(null);
  const [gerekce, setGerekce] = useState('');

  const canStart = ziyaret.durum === 'planlandi' && ziyaret.planTuru === 'tam_zamanli';
  const canFinish = ziyaret.durum === 'devam_ediyor' && ziyaret.planTuru === 'tam_zamanli';

  const handleStartError = (e: unknown): boolean => {
    if (isErrorCode(e, 'ERCEN_GELIS_GEREKCE_REQUIRED')) {
      setPending({ mode: 'start', late: false });
      return true;
    }
    if (isErrorCode(e, 'GEC_GIRIS_GEREKCE_REQUIRED')) {
      setPending({ mode: 'start', late: true });
      return true;
    }
    return false;
  };

  const handleFinishError = (e: unknown): boolean => {
    if (isErrorCode(e, 'ERCEN_CIKIS_GEREKCE_REQUIRED')) {
      setPending({ mode: 'finish', late: false });
      return true;
    }
    if (isErrorCode(e, 'GEC_CIKIS_GEREKCE_REQUIRED')) {
      setPending({ mode: 'finish', late: true });
      return true;
    }
    return false;
  };

  const doStart = async (gerekceStr: string) => {
    setOperating(true);
    try {
      const { latitude, longitude } = await getCurrentPosition();
      await startVisit(ziyaret.id, latitude, longitude, gerekceStr);
      addToast({ title: 'Ziyaret başlatıldı', message: 'Başlangıç saati kaydedildi.', type: 'success' });
      setPending(null);
      setGerekce('');
      onChanged?.();
    } catch (e) {
      if (!handleStartError(e)) {
        addToast({ title: 'Ziyaret başlatılamadı', message: friendlyPlanlamaError(e), type: 'error' });
      }
    } finally {
      setOperating(false);
    }
  };

  const doFinish = async (gerekceStr: string) => {
    setOperating(true);
    try {
      const { latitude, longitude } = await getCurrentPosition();
      await finishVisit(ziyaret.id, latitude, longitude, gerekceStr);
      addToast({ title: 'Ziyaret bitirildi', message: 'Gerçekleşen süre kaydedildi.', type: 'success' });
      setPending(null);
      setGerekce('');
      onChanged?.();
    } catch (e) {
      if (!handleFinishError(e)) {
        addToast({ title: 'Ziyaret bitirilemedi', message: friendlyPlanlamaError(e), type: 'error' });
      }
    } finally {
      setOperating(false);
    }
  };

  if (pending) {
    const message =
      pending.mode === 'start'
        ? pending.late
          ? 'Planlanan girişten 45 dakikadan fazla geç kaldınız, gerekçe girin.'
          : 'Planlanan girişten 45 dakikadan fazla erken geldiniz, gerekçe girin.'
        : pending.late
          ? 'Planlanan çıkıştan 45 dakikadan fazla geç çıktınız, gerekçe girin.'
          : 'Planlanan çıkıştan 45 dakikadan fazla erken çıktınız, gerekçe girin.';

    return (
      <div className="flex flex-col sm:flex-row sm:items-center gap-2 rounded-lg border border-warning-200/60 bg-warning-50/60 px-3 py-2">
        <div className="flex-1 min-w-[220px]">
          <p className="text-xs font-medium text-foreground-700 mb-1 flex items-center gap-1.5">
            <i className="ri-information-line text-warning-600" />
            {message}
          </p>
          <Textarea
            value={gerekce}
            maxLength={500}
            placeholder="Gerekçe açıklaması..."
            onChange={(e) => setGerekce(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          <Button
            variant="primary"
            size="sm"
            isLoading={operating}
            onClick={() => {
              if (!gerekce.trim()) {
                addToast({ title: 'Gerekçe gerekli', message: 'Lütfen bir gerekçe girin.', type: 'warning' });
                return;
              }
              if (pending.mode === 'start') void doStart(gerekce.trim());
              else void doFinish(gerekce.trim());
            }}
          >
            Onayla
          </Button>
          <Button
            variant="ghost"
            size="sm"
            disabled={operating}
            onClick={() => { setPending(null); setGerekce(''); }}
          >
            Vazgeç
          </Button>
        </div>
      </div>
    );
  }

  if (canStart) {
    return (
      <Button
        variant="primary"
        size="sm"
        isLoading={operating}
        leftIcon={<i className="ri-play-circle-line" />}
        onClick={() => void doStart('')}
      >
        Ziyareti Başlat
      </Button>
    );
  }

  if (canFinish) {
    return (
      <Button
        variant="danger"
        size="sm"
        isLoading={operating}
        leftIcon={<i className="ri-stop-circle-line" />}
        onClick={() => void doFinish('')}
      >
        Ziyareti Bitir
      </Button>
    );
  }

  return null;
}