import { useRef, useState } from 'react';
import Button from '@/components/ui/Button';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import Textarea from '@/components/ui/Textarea';
import { useToastActions } from '@/hooks/useToast';
import {
  resolveGeziciFirmalar,
  tamZamanliPlansizStart,
  friendlyPlanlamaError,
  type YakindakiGeziciFirma,
} from '@/lib/planlamaService';
import { getCurrentPosition } from './ziyaretlerUi';

interface PlansizCalismaModalProps {
  /** Başarılı başlatma sonrası çağrılır (modalı kapatır + listeyi tazeler). */
  onDone: () => void;
}

type Step = 'gerekce' | 'locating' | 'selecting' | 'starting' | 'error';

/**
 * Gün Programı personeli için "plan dışı çalışma" başlatma akışı (Faz 5.3).
 * - Gerekçe ZORUNLUDUR (boşsa ilerlenmez).
 * - GPS konumu alınır → backend `resolveGeziciFirmalar` ile geofence içindeki firmalar çözülür.
 * - 0 firma → hata, 1 firma → otomatik başlat, 2+ firma → kullanıcıdan firma seçimi.
 * - Karar her zaman backend'dedir; kayıt "plan dışı/gerekçeli" olarak tutulur (plan_id = null).
 * Yeni GPS/modal motoru YOK; mevcut servisler ve Shared UI kullanılır.
 */
export default function PlansizCalismaModal({ onDone }: PlansizCalismaModalProps) {
  const { addToast } = useToastActions();
  const [step, setStep] = useState<Step>('gerekce');
  const [gerekce, setGerekce] = useState('');
  const [firmalar, setFirmalar] = useState<YakindakiGeziciFirma[]>([]);
  const [seciliId, setSeciliId] = useState('');
  const [error, setError] = useState<string | null>(null);
  const posRef = useRef<{ latitude: number; longitude: number } | null>(null);

  const doStart = async (firmaId: string) => {
    setStep('starting');
    try {
      const pos = posRef.current ?? (await getCurrentPosition());
      await tamZamanliPlansizStart(firmaId, pos.latitude, pos.longitude, gerekce.trim());
      addToast({ title: 'Plan dışı çalışma başlatıldı', message: 'Gerekçeli çalışma kaydı oluşturuldu.', type: 'success' });
      onDone();
    } catch (e) {
      const msg = friendlyPlanlamaError(e);
      setError(msg);
      setStep('error');
      addToast({ title: 'Çalışma başlatılamadı', message: msg, type: 'error' });
    }
  };

  const handleDevam = async () => {
    const gerekceTrim = gerekce.trim();
    if (!gerekceTrim) {
      addToast({ title: 'Gerekçe gerekli', message: 'Plan dışı çalışma için gerekçe zorunludur.', type: 'warning' });
      return;
    }
    setStep('locating');
    try {
      const pos = await getCurrentPosition();
      posRef.current = pos;
      const near = await resolveGeziciFirmalar(pos.latitude, pos.longitude);
      if (near.length === 0) {
        setError(
          'Yakınınızda ziyaret başlatabileceğiniz firma bulunamadı. Çalışmayı başlatmak için firma konumuna belirlenen mesafe içinde olmalısınız.',
        );
        setStep('error');
      } else if (near.length === 1) {
        await doStart(near[0].firmaId);
      } else {
        setFirmalar(near);
        setStep('selecting');
      }
    } catch (e) {
      setError(friendlyPlanlamaError(e));
      setStep('error');
    }
  };

  if (step === 'gerekce') {
    return (
      <div className="flex flex-col space-y-3">
        <div className="flex items-start gap-2 rounded-lg border border-secondary-200/60 bg-secondary-50 dark:bg-secondary-500/10 px-3 py-2.5">
          <i className="ri-information-line mt-0.5 text-sm text-secondary-600" />
          <p className="text-xs text-secondary-700">
            Bugün için planlı ziyaretiniz bulunmuyor. Yine de çalışma başlatabilirsiniz; bu kayıt
            &quot;plan dışı / gerekçeli&quot; olarak işaretlenir ve gerekçe zorunludur.
          </p>
        </div>
        <Textarea
          label="Gerekçe"
          required
          placeholder="Plan dışı çalışma gerekçenizi yazın..."
          value={gerekce}
          maxLength={500}
          onChange={(e) => setGerekce(e.target.value)}
        />
        <div className="flex justify-end">
          <Button
            variant="primary"
            size="sm"
            disabled={!gerekce.trim()}
            leftIcon={<i className="ri-play-circle-line" />}
            onClick={handleDevam}
          >
            Devam Et
          </Button>
        </div>
      </div>
    );
  }

  if (step === 'locating' || step === 'starting') {
    return (
      <div className="flex justify-center py-16">
        <Loading size="lg" text={step === 'locating' ? 'Konumunuz alınıyor...' : 'Çalışma başlatılıyor...'} />
      </div>
    );
  }

  if (step === 'error') {
    return <ErrorState message={error ?? 'Ziyaret bilgileri yüklenemedi. Lütfen tekrar deneyin.'} onRetry={() => setStep('gerekce')} />;
  }

  return (
    <div className="flex flex-col space-y-3">
      <p className="text-sm text-foreground-700 flex items-center gap-1.5">
        <i className="ri-question-line text-primary-500" />
        Hangi firma için çalışma başlatıyorsunuz?
      </p>
      <div className="space-y-2">
        {firmalar.map((f) => (
          <button
            key={f.firmaId}
            type="button"
            onClick={() => setSeciliId(f.firmaId)}
            className={`w-full flex items-center justify-between gap-3 rounded-lg border px-3 py-3 text-left transition-colors cursor-pointer ${
              seciliId === f.firmaId
                ? 'border-primary-400 bg-primary-50 dark:bg-primary-500/10'
                : 'border-background-300/60 bg-background-50 hover:bg-background-100'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-lg bg-background-200 flex items-center justify-center flex-shrink-0">
                <i className="ri-building-2-line text-foreground-500 text-sm" />
              </div>
              <span className="text-sm font-medium text-foreground-800 truncate">{f.firmaUnvan}</span>
            </div>
            <span className="text-xs text-foreground-500 whitespace-nowrap flex-shrink-0">{f.distanceMeters} m</span>
          </button>
        ))}
      </div>
      <div className="flex justify-end pt-1">
        <Button
          variant="primary"
          size="sm"
          disabled={!seciliId}
          leftIcon={<i className="ri-play-circle-line" />}
          onClick={() => void doStart(seciliId)}
        >
          Çalışmayı Başlat
        </Button>
      </div>
    </div>
  );
}