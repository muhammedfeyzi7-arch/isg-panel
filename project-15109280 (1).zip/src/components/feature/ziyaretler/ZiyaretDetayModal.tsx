import { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import Card from '@/components/ui/Card';
import { useToastActions } from '@/hooks/useToast';
import { useAuth } from '@/context/AuthContext';
import { friendlyErrorMessage } from '@/lib/errorMessages';
// ── PERFORMANS: Leaflet tabanlı harita seçici ağır (leaflet JS+CSS). Bu modalı
// import eden tüm bundle'lara (ör. OSGB dashboard) statik sızmasın; yalnızca
// koordinat varsa ve harita alanı görünürken yüklenir. ──
const FirmaMapPicker = lazy(() => import('@/pages/osgb/firmalar/components/FirmaMapPicker'));
import {
  fetchZiyaret,
  fetchProgramDetay,
  createGenelIzinTalep,
  createIzinTalep,
  geziciFinishVisit,
  markVisitNotCompleted,
  ziyaretNotEkle,
  friendlyPlanlamaError,
  trTodayISO,
  yeniProgramTuruLabel,
  formatPlanDate,
  formatSureKisa,
  formatTimeHM,
  type ZiyaretKaydi,
  type ZiyaretBakiye,
  type ProgramDetay,
} from '@/lib/planlamaService';
import {
  durumToken,
  GUN_ADI,
  GUN_SIRA,
  gunIndex,
  formatTarihUzun,
} from '@/pages/osgb/ziyaret-planlama/components/detay/detayUi';
import { programTuruBadgeVariant } from '@/pages/osgb/ziyaret-planlama/components/ziyaretPlanlamaUi';
import { isPlanDisi, getCurrentPosition } from './ziyaretlerUi';
import ZiyaretBaslatBitirButton from './ZiyaretBaslatBitirButton';
import { tehlikeVariant, tehlikeSinifiLabel } from './saha/sahaZiyaretUi';

interface ZiyaretDetayModalProps {
  ziyaretId: string;
  /** Başlat/bitir/izin sonrası ana listeyi tazelemek için çağrılır. */
  onChanged?: () => void;
}

function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5 py-2 border-b border-background-300/25 last:border-0">
      <span className="text-[11px] text-foreground-500 uppercase tracking-wide">{label}</span>
      <span className="text-sm text-foreground-800 break-words">{value}</span>
    </div>
  );
}

function OzetKutu({ icon, label, value, tone = 'text-foreground-800' }: { icon: string; label: string; value: ReactNode; tone?: string }) {
  return (
    <div className="flex items-center gap-2.5 rounded-lg border border-background-300/40 dark:border-background-400/20 bg-background-50 dark:bg-background-100 px-3 py-2.5">
      <span className="w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0 bg-primary-50 text-primary-600 dark:bg-primary-500/15 dark:text-primary-300">
        <i className={icon} />
      </span>
      <div className="min-w-0">
        <p className="text-[11px] uppercase tracking-wide text-foreground-500">{label}</p>
        <p className={`text-sm font-semibold truncate ${tone}`}>{value}</p>
      </div>
    </div>
  );
}

/**
 * SAHA (uzman / işyeri hekimi) — TEK EKRANLI "Ziyaret Detayı".
 *
 * Eski çok adımlı / sekmeli detay kaldırıldı. Bu modal yalnızca SEÇİLEN ziyarete odaklanır:
 * Ziyaret Bilgileri · Firma Bilgileri · Program Bilgileri · Konum · Aksiyonlar tek ekranda kartlar
 * hâlinde gösterilir. Başlat/bitir mevcut start/finish servislerini (GPS + geofence + ownership
 * backend doğrulaması) AYNEN kullanır; gelecek tarihli ziyaret için "İzin Talep Et" mevcut
 * `personel_izin_talepleri` / talep-onay workflow'unu kullanır. Yeni tablo/enum/RPC yoktur.
 */
export default function ZiyaretDetayModal({ ziyaretId, onChanged }: ZiyaretDetayModalProps) {
  const { addToast } = useToastActions();
  const { profile } = useAuth();
  const isField = profile?.role === 'uzman' || profile?.role === 'hekim';

  const [ziyaret, setZiyaret] = useState<ZiyaretKaydi | null>(null);
  const [bakiye, setBakiye] = useState<ZiyaretBakiye | null>(null);
  const [program, setProgram] = useState<ProgramDetay | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [operating, setOperating] = useState(false);

  // İzin talebi (gelecek tarihli Sabit Çalışma Programı ziyareti)
  const [izinAcik, setİzinAcik] = useState(false);
  const [izinBaslangic, setİzinBaslangic] = useState('');
  const [izinBitis, setİzinBitis] = useState('');
  const [izinTuru, setİzinTuru] = useState('Yıllık İzin');
  const [izinGerekce, setİzinGerekce] = useState('');
  const [izinGonderildi, setİzinGonderildi] = useState(false);

  // Ziyaret notu (devam eden / gerçekleşen) — mevcut `ziyaretler.notlar` üzerinden.
  const [notEdit, setNotEdit] = useState(false);
  const [notDraft, setNotDraft] = useState('');
  // Çalışma Yapılmadı / Ziyaret Gerçekleşmedi (saha tarafı).
  const [cyAcik, setCyAcik] = useState(false);
  const [cyGerekce, setCyGerekce] = useState('');
  const [cyGonderildi, setCyGonderildi] = useState(false);
  // Gün Değişikliği Talebi (sabit çalışma programı).
  const [gdAcik, setGdAcik] = useState(false);
  const [gdTalepTarihi, setGdTalepTarihi] = useState('');
  const [gdAciklama, setGdAciklama] = useState('');
  const [gdGonderildi, setGdGonderildi] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchZiyaret(ziyaretId);
      setZiyaret(res.ziyaret);
      setBakiye(res.bakiye);
      // Program bilgisi (Sabit/Süre Bazlı) yalnızca plana bağlı ziyaretlerde yüklenir.
      if (res.ziyaret.planId) {
        fetchProgramDetay(res.ziyaret.planId)
          .then((pd) => setProgram(pd))
          .catch(() => setProgram(null));
      } else {
        setProgram(null);
      }
    } catch (e) {
      setError(friendlyErrorMessage(e, 'Ziyaret yüklenirken bir hata oluştu.'));
    } finally {
      setLoading(false);
    }
  }, [ziyaretId]);

  useEffect(() => {
    void load();
  }, [load]);

  const refresh = useCallback(async () => {
    try {
      const res = await fetchZiyaret(ziyaretId);
      setZiyaret(res.ziyaret);
      setBakiye(res.bakiye);
    } catch {
      /* yenileme hatası operasyon başarısını engellemez */
    }
    onChanged?.();
  }, [ziyaretId, onChanged]);

  const doGeziciFinish = useCallback(async () => {
    setOperating(true);
    try {
      const { latitude, longitude } = await getCurrentPosition();
      await geziciFinishVisit(ziyaretId, latitude, longitude, '');
      addToast({ title: 'Ziyaret bitirildi', message: 'Gerçekleşen süre kaydedildi.', type: 'success' });
      await refresh();
    } catch (e) {
      addToast({ title: 'Ziyaret bitirilemedi', message: friendlyPlanlamaError(e), type: 'error' });
    } finally {
      setOperating(false);
    }
  }, [ziyaretId, addToast, refresh]);

  const doIzinTalep = useCallback(async () => {
    if (!ziyaret?.planId) return;
    if (!izinBaslangic || !izinBitis) {
      addToast({ title: 'Tarih gerekli', message: 'İzin başlangıç ve bitiş tarihini seçin.', type: 'warning' });
      return;
    }
    if (izinBitis < izinBaslangic) {
      addToast({ title: 'Geçersiz tarih', message: 'Bitiş tarihi başlangıçtan önce olamaz.', type: 'warning' });
      return;
    }
    if (!izinGerekce.trim()) {
      addToast({ title: 'Gerekçe gerekli', message: 'İzin talebi için bir açıklama girin.', type: 'warning' });
      return;
    }
    setOperating(true);
    try {
      await createGenelIzinTalep({
        programId: ziyaret.planId,
        baslangicTarihi: izinBaslangic,
        bitisTarihi: izinBitis,
        aciklama: `[${izinTuru}] ${izinGerekce.trim()}`,
      });
      addToast({ title: 'İzin talebi gönderildi', message: 'Talebiniz onay için OSGB yöneticisine iletildi.', type: 'success' });
      setİzinGonderildi(true);
      setİzinAcik(false);
      setİzinGerekce('');
      onChanged?.();
    } catch (e) {
      addToast({ title: 'İzin talebi gönderilemedi', message: friendlyPlanlamaError(e), type: 'error' });
    } finally {
      setOperating(false);
    }
  }, [ziyaret, izinBaslangic, izinBitis, izinTuru, izinGerekce, addToast, onChanged]);

  const doKaydetNot = useCallback(async () => {
    const metin = notDraft.trim();
    if (!metin) {
      addToast({ title: 'Not gerekli', message: 'Ziyaret notu boş bırakılamaz.', type: 'warning' });
      return;
    }
    setOperating(true);
    try {
      await ziyaretNotEkle(ziyaretId, metin);
      addToast({ title: 'Ziyaret notu kaydedildi', message: 'Not ziyaret detayına eklendi.', type: 'success' });
      setNotEdit(false);
      await refresh();
    } catch (e) {
      addToast({ title: 'Not kaydedilemedi', message: friendlyPlanlamaError(e), type: 'error' });
    } finally {
      setOperating(false);
    }
  }, [notDraft, ziyaretId, addToast, refresh]);

  const doCalismaYapilmadi = useCallback(async () => {
    const gerekce = cyGerekce.trim();
    if (!gerekce) {
      addToast({ title: 'Gerekçe gerekli', message: 'Çalışma yapılmadı kaydı için gerekçe zorunludur.', type: 'warning' });
      return;
    }
    setOperating(true);
    try {
      await markVisitNotCompleted(ziyaretId, gerekce);
      addToast({ title: 'Çalışma yapılmadı olarak kaydedildi', message: 'Ziyaret gerçekleşmedi olarak işaretlendi.', type: 'success' });
      setCyAcik(false);
      setCyGerekce('');
      setCyGonderildi(true);
      await refresh();
    } catch (e) {
      addToast({ title: 'Kaydedilemedi', message: friendlyPlanlamaError(e), type: 'error' });
    } finally {
      setOperating(false);
    }
  }, [cyGerekce, ziyaretId, addToast, refresh]);

  const doGunDegisikligi = useCallback(async () => {
    if (!ziyaret?.planId) return;
    if (!gdTalepTarihi) {
      addToast({ title: 'Tarih gerekli', message: 'Talep edilen tarihi seçin.', type: 'warning' });
      return;
    }
    if (!gdAciklama.trim()) {
      addToast({ title: 'Açıklama gerekli', message: 'Gün değişikliği talebi için açıklama girin.', type: 'warning' });
      return;
    }
    setOperating(true);
    try {
      const mevcutSaat = ziyaret.planlananBaslangic && ziyaret.planlananBitis
        ? `${ziyaret.planlananBaslangic} - ${ziyaret.planlananBitis}`
        : '—';
      const aciklama = `Mevcut: ${formatPlanDate(ziyaret.ziyaretTarihi)} (${mevcutSaat}). Talep edilen tarih: ${formatPlanDate(gdTalepTarihi)}. ${gdAciklama.trim()}`;
      await createIzinTalep({
        programId: ziyaret.planId,
        // ZV-01 — Seçilen GERÇEK hedef tarih payload'a iletilir (önceden mevcut tarih
        // gönderiliyordu ve kullanıcının seçtiği gün kayboluyordu).
        gun: gunIndex(gdTalepTarihi),
        mevcutDurum: 'calisma',
        istenenDurum: 'calisma',
        aciklama,
        tarih: gdTalepTarihi,
        // Taşıma kaynağı: ziyaretin mevcut tarihi. Onayda kaynak gün izin, hedef gün çalışma yapılır.
        kaynakTarih: ziyaret.ziyaretTarihi,
      });
      addToast({ title: 'Gün değişikliği talebi gönderildi', message: 'Talebiniz onay için OSGB yöneticisine iletildi.', type: 'success' });
      setGdAcik(false);
      setGdTalepTarihi('');
      setGdAciklama('');
      setGdGonderildi(true);
      onChanged?.();
    } catch (e) {
      addToast({ title: 'Talep gönderilemedi', message: friendlyPlanlamaError(e), type: 'error' });
    } finally {
      setOperating(false);
    }
  }, [ziyaret, gdTalepTarihi, gdAciklama, addToast, onChanged]);

  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <Loading size="lg" text="Ziyaret yükleniyor..." />
      </div>
    );
  }
  if (error || !ziyaret) {
    return <ErrorState message={error ?? 'Ziyaret bulunamadı.'} onRetry={load} />;
  }

  const t = durumToken(ziyaret.durum);
  const bugun = ziyaret.ziyaretTarihi === trTodayISO();
  const gelecek = ziyaret.ziyaretTarihi > trTodayISO();
  const gun = gunIndex(ziyaret.ziyaretTarihi);
  const sabit = ziyaret.planTuru === 'tam_zamanli';
  const planDisi = isPlanDisi(ziyaret);

  const koordinatVar = ziyaret.firmaLatitude != null && ziyaret.firmaLongitude != null;

  const canStartBugun = isField && sabit && bugun && ziyaret.durum === 'planlandi';
  const canFinishTamZamanli = isField && sabit && ziyaret.durum === 'devam_ediyor';
  const canFinishGezici = isField && !sabit && ziyaret.durum === 'devam_ediyor';
  const canIzinTalep = isField && sabit && gelecek && ziyaret.durum === 'planlandi' && !!ziyaret.planId && !izinGonderildi;
  // Ziyaret Notu — devam eden / gerçekleşen / otomatik kapatılan ziyaretlerde düzenlenebilir.
  const canNote = isField && !planDisi && ['devam_ediyor', 'gerceklesti', 'otomatik_kapatildi'].includes(ziyaret.durum);
  // Çalışma Yapılmadı — planlı gün gelmiş (bugün/geçmiş) ve henüz gerçek kayıt yoksa.
  const canCalismaYapilmadi = isField && sabit && !planDisi && !ziyaret.actualStart
    && (ziyaret.durum === 'planlandi' || ziyaret.durum === 'gerceklesmedi')
    && !ziyaret.gerceklesmemeGerekcesi
    && ziyaret.ziyaretTarihi <= trTodayISO();
  // Gün Değişikliği Talebi — planlı sabit ziyaret için (bugün veya gelecek).
  const canGunDegisikligi = isField && sabit && !planDisi && !!ziyaret.planId
    && ziyaret.durum === 'planlandi' && ziyaret.ziyaretTarihi >= trTodayISO() && !gdGonderildi;

  // Sabit Program — çalışma günleri (Pazartesi..Pazar sırasıyla)
  const calisilanGunler = (program?.gunler ?? [])
    .filter((g) => !g.izin && g.baslangicSaat && g.bitisSaat)
    .sort((a, b) => GUN_SIRA.indexOf(a.gun) - GUN_SIRA.indexOf(b.gun));
  const calismaGunleriLabel = calisilanGunler.length
    ? `${GUN_ADI[calisilanGunler[0].gun]} - ${GUN_ADI[calisilanGunler[calisilanGunler.length - 1].gun]}`
    : '—';
  const bugununSlotu = calisilanGunler.find((g) => g.gun === gun) ?? calisilanGunler[0];
  const gunlukSaatLabel = bugununSlotu ? `${bugununSlotu.baslangicSaat} - ${bugununSlotu.bitisSaat}` : (ziyaret.planlananBaslangic && ziyaret.planlananBitis ? `${ziyaret.planlananBaslangic} - ${ziyaret.planlananBitis}` : '—');

  const kalanDakika = bakiye ? Math.max(bakiye.ayKalanDakika || 0, 0) : 0;
  const oran = bakiye && bakiye.aylikPlanDakika > 0
    ? Math.round((Math.min(bakiye.ayToplamGerceklesenDakika, bakiye.aylikPlanDakika) / bakiye.aylikPlanDakika) * 100)
    : 0;

  const geofenceSonuc = ziyaret.geofenceInside == null ? '—' : ziyaret.geofenceInside ? 'Uygun (içeride)' : 'Uygun Değil (dışarıda)';

  const planlananAralik = ziyaret.planlananBaslangic && ziyaret.planlananBitis ? `${ziyaret.planlananBaslangic} - ${ziyaret.planlananBitis}` : '—';

  return (
    <div className="flex flex-col space-y-3">
      {/* Başlık */}
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-primary-600 dark:text-primary-400">
            <i className="ri-map-pin-user-line" />
            Ziyaret Detayı
          </p>
          <p className="mt-1 text-base font-semibold text-foreground-950 truncate">{ziyaret.firmaUnvan}</p>
          {(ziyaret.firmaIl || ziyaret.firmaIlce) && (
            <p className="mt-0.5 text-xs text-foreground-500">
              {[ziyaret.firmaIl, ziyaret.firmaIlce].filter(Boolean).join(' / ')}
            </p>
          )}
        </div>
        <div className="flex flex-wrap items-center justify-end gap-1.5 flex-shrink-0">
          {planDisi && <Badge variant="warning">Plan Dışı Çalışma</Badge>}
          <Badge variant={programTuruBadgeVariant(ziyaret.planTuru)}>{yeniProgramTuruLabel(ziyaret.planTuru)}</Badge>
          <Badge variant={t.badge}>{t.label}</Badge>
        </div>
      </div>

      {/* Üst özet şeridi */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <OzetKutu icon="ri-calendar-event-line" label="Tarih / Gün" value={`${formatTarihUzun(ziyaret.ziyaretTarihi)} (${GUN_ADI[gun] ?? '—'})`} />
        <OzetKutu icon="ri-time-line" label="Planlanan Saat" value={planlananAralik} />
        <OzetKutu
          icon="ri-hourglass-line"
          label="Planlanan Süre"
          value={ziyaret.planlananSureDakika != null ? formatSureKisa(ziyaret.planlananSureDakika) : '—'}
        />
        <OzetKutu icon="ri-flag-line" label="Durum" value={bugun && ziyaret.durum === 'planlandi' ? 'Bugün' : t.label} tone="text-foreground-900" />
      </div>

      {/* Gelecek ziyaret uyarısı */}
      {gelecek && ziyaret.durum === 'planlandi' && (
        <div className="flex items-start gap-2 rounded-lg border border-warning-200/60 bg-warning-50/60 px-3 py-2.5">
          <i className="ri-information-line text-warning-600 mt-0.5" />
          <p className="text-xs text-foreground-700">
            <span className="font-medium">Bu ziyaretin günü henüz gelmedi.</span>{' '}
            Ziyaret başlatmak için planlanan tarih ve saatin gelmesi gerekir.
          </p>
        </div>
      )}

      {/* Aksiyon şeridi */}
      {(canStartBugun || canFinishTamZamanli || canFinishGezici) && (
        <div className="flex flex-wrap items-center justify-end gap-2 rounded-lg border border-background-300/40 dark:border-background-400/20 bg-background-50 dark:bg-background-100 px-3 py-2.5">
          {(canStartBugun || canFinishTamZamanli) && (
            <ZiyaretBaslatBitirButton ziyaret={ziyaret} onChanged={() => void refresh()} />
          )}
          {canFinishGezici && (
            <Button variant="danger" size="sm" isLoading={operating} leftIcon={<i className="ri-stop-circle-line" />} onClick={() => void doGeziciFinish()}>
              Ziyareti Bitir
            </Button>
          )}
        </div>
      )}

      {/* Ana içerik: iki kolon */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* Sol: Ziyaret Bilgileri */}
        <div className="space-y-3">
          <Card title="Ziyaret Bilgileri" padding="md">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
              <InfoRow label="Tarih" value={formatPlanDate(ziyaret.ziyaretTarihi)} />
              <InfoRow label="Gün" value={GUN_ADI[gun] ?? '—'} />
              <InfoRow label="Planlanan Saat" value={planlananAralik} />
              <InfoRow label="Planlanan Süre" value={ziyaret.planlananSureDakika != null ? formatSureKisa(ziyaret.planlananSureDakika) : '—'} />
              <InfoRow label="Gerçek Başlangıç" value={ziyaret.actualStart ? formatTimeHM(ziyaret.actualStart) : '—'} />
              <InfoRow label="Gerçek Bitiş" value={ziyaret.actualEnd ? formatTimeHM(ziyaret.actualEnd) : ziyaret.actualStart ? 'Devam Ediyor' : '—'} />
              <InfoRow label="Gerçekleşen Süre" value={ziyaret.actualDurationMinutes != null ? formatSureKisa(ziyaret.actualDurationMinutes) : '—'} />
              <InfoRow label="Plan Türü" value={yeniProgramTuruLabel(ziyaret.planTuru)} />
              {ziyaret.autoClosed && <InfoRow label="Kapanma" value="24:00'te Otomatik Kapatıldı" />}
            </div>
            {ziyaret.gerceklesmemeGerekcesi && (
              <div className="mt-2">
                <InfoRow label="Gerçekleşmeme Gerekçesi" value={ziyaret.gerceklesmemeGerekcesi} />
              </div>
            )}
            {(ziyaret.notlar || canNote) && (
              <div className="mt-2 rounded-lg border border-background-300/40 dark:border-background-400/20 bg-background-50 dark:bg-background-100 p-2.5">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <p className="text-[11px] uppercase tracking-wide text-foreground-500">Ziyaret Notu</p>
                  {canNote && !notEdit && (
                    <button
                      type="button"
                      onClick={() => { setNotDraft(ziyaret.notlar ?? ''); setNotEdit(true); }}
                      className="text-xs font-medium text-primary-600 hover:text-primary-700 flex items-center gap-1 cursor-pointer whitespace-nowrap"
                    >
                      <i className="ri-pencil-line" />{ziyaret.notlar ? 'Düzenle' : 'Not Ekle'}
                    </button>
                  )}
                </div>
                {notEdit ? (
                  <div className="space-y-2">
                    <Textarea
                      value={notDraft}
                      maxLength={500}
                      placeholder="Ziyaret notunuzu yazın..."
                      onChange={(e) => setNotDraft(e.target.value)}
                    />
                    <div className="flex items-center justify-end gap-2">
                      <Button variant="ghost" size="sm" disabled={operating} onClick={() => { setNotEdit(false); setNotDraft(''); }}>
                        Vazgeç
                      </Button>
                      <Button variant="primary" size="sm" isLoading={operating} onClick={() => void doKaydetNot()}>
                        Kaydet
                      </Button>
                    </div>
                  </div>
                ) : ziyaret.notlar ? (
                  <p className="text-sm text-foreground-800 whitespace-pre-wrap break-words">{ziyaret.notlar}</p>
                ) : (
                  <p className="text-sm text-foreground-400">Henüz not eklenmedi.</p>
                )}
              </div>
            )}
          </Card>

          {/* Program Bilgileri */}
          <Card title="Program Bilgileri" padding="md">
            {sabit ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
                <InfoRow label="Çalışma Günleri" value={calismaGunleriLabel} />
                <InfoRow label="Günlük Çalışma Saati" value={gunlukSaatLabel} />
                <InfoRow label="Günlük Süre" value={bugununSlotu ? formatSureKisa(dakikaAralik(bugununSlotu.baslangicSaat, bugununSlotu.bitisSaat)) : (ziyaret.planlananSureDakika != null ? formatSureKisa(ziyaret.planlananSureDakika) : '—')} />
                <InfoRow label="Program Başlangıç" value={program ? formatPlanDate(program.program.baslangicTarihi) : '—'} />
                <InfoRow label="Program Bitiş" value={program?.program.bitisTarihi ? formatPlanDate(program.program.bitisTarihi) : 'Devam ediyor'} />
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-lg bg-background-100 dark:bg-background-200/60 p-2.5 text-center">
                  <p className="text-[11px] text-foreground-500">Aylık Ayrılan Süre</p>
                  <p className="mt-0.5 text-sm font-semibold text-foreground-800">{bakiye ? formatSureKisa(bakiye.aylikPlanDakika) : '—'}</p>
                </div>
                <div className="rounded-lg bg-background-100 dark:bg-background-200/60 p-2.5 text-center">
                  <p className="text-[11px] text-foreground-500">Ay</p>
                  <p className="mt-0.5 text-sm font-semibold text-foreground-800">{bakiye?.donem ? formatPlanDate(bakiye.donem).split(' ').slice(1).join(' ') : '—'}</p>
                </div>
                <div className="rounded-lg bg-background-100 dark:bg-background-200/60 p-2.5 text-center">
                  <p className="text-[11px] text-foreground-500">Gerçekleşen Süre</p>
                  <p className="mt-0.5 text-sm font-semibold text-success-600">{bakiye ? formatSureKisa(bakiye.ayToplamGerceklesenDakika) : '—'}</p>
                </div>
                <div className="rounded-lg bg-background-100 dark:bg-background-200/60 p-2.5 text-center">
                  <p className="text-[11px] text-foreground-500">Kalan Süre</p>
                  <p className="mt-0.5 text-sm font-semibold text-warning-600">{bakiye ? formatSureKisa(kalanDakika) : '—'}</p>
                </div>
                <div className="col-span-2 rounded-lg bg-background-100 dark:bg-background-200/60 p-2.5 text-center">
                  <p className="text-[11px] text-foreground-500">Gerçekleşme Oranı</p>
                  <p className="mt-0.5 text-sm font-semibold text-foreground-800">%{oran}</p>
                </div>
              </div>
            )}
          </Card>
        </div>

        {/* Sağ: Firma Bilgileri + Konum + İzin */}
        <div className="space-y-3">
          <Card title="Firma Bilgileri" padding="md">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
              <InfoRow label="Firma" value={ziyaret.firmaUnvan} />
              <InfoRow label="Tehlike Sınıfı" value={<Badge variant={tehlikeVariant(ziyaret.firmaTehlikeSinifi)}>{tehlikeSinifiLabel(ziyaret.firmaTehlikeSinifi)}</Badge>} />
              <InfoRow label="İl / İlçe" value={[ziyaret.firmaIl, ziyaret.firmaIlce].filter(Boolean).join(' / ') || '—'} />
              {ziyaret.firmaTelefon && <InfoRow label="Telefon" value={ziyaret.firmaTelefon} />}
              {ziyaret.firmaEmail && <InfoRow label="E-posta" value={ziyaret.firmaEmail} />}
              {ziyaret.firmaYetkili && <InfoRow label="Firma Yetkilisi" value={ziyaret.firmaYetkili} />}
              {ziyaret.firmaAdres && <InfoRow label="Adres" value={ziyaret.firmaAdres} />}
            </div>
          </Card>

          <Card title="Konum" padding="md">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
              <InfoRow label="İl / İlçe" value={[ziyaret.firmaIl, ziyaret.firmaIlce].filter(Boolean).join(' / ') || '—'} />
              <InfoRow label="Açık Adres" value={ziyaret.firmaAdres || '—'} />
              <InfoRow label="Geofence" value={ziyaret.geofenceRadius ? `${ziyaret.geofenceRadius} metre` : 'Tanımlı değil'} />
              <InfoRow label="Doğrulama Sonucu" value={geofenceSonuc} />
            </div>
            {koordinatVar && (
              <div className="mt-3 rounded-lg border border-background-300/40 overflow-hidden">
                <Suspense
                  fallback={
                    <div className="w-full h-[180px] flex items-center justify-center bg-background-100 dark:bg-background-200/60">
                      <Loading size="md" text="Harita yükleniyor..." />
                    </div>
                  }
                >
                  <FirmaMapPicker
                    lat={ziyaret.firmaLatitude}
                    lng={ziyaret.firmaLongitude}
                    radius={ziyaret.geofenceRadius}
                    height={180}
                    readOnly
                    onSelect={() => {}}
                  />
                </Suspense>
              </div>
            )}
          </Card>

          {/* Saha İşlemleri — gün değişikliği + çalışma yapılmadı */}
          {(canGunDegisikligi || gdGonderildi || canCalismaYapilmadi || cyGonderildi) && (
            <Card title="Saha İşlemleri" padding="md">
              <div className="space-y-3">
                {(canGunDegisikligi || gdGonderildi) && (
                  <div className="rounded-lg border border-background-300/40 dark:border-background-400/20 bg-background-50 dark:bg-background-100 p-2.5">
                    {gdGonderildi ? (
                      <p className="text-sm font-medium text-success-600 flex items-center gap-1.5">
                        <i className="ri-checkbox-circle-line" />
                        Gün Değişikliği Talebi Gönderildi
                      </p>
                    ) : (
                      <>
                        <div className="flex items-start gap-2">
                          <i className="ri-calendar-2-line text-primary-600 mt-0.5" />
                          <div>
                            <p className="text-sm font-semibold text-foreground-900">Gün Değişikliği Talep Et</p>
                            <p className="text-xs text-foreground-600 mt-0.5">
                              Planlanan günde çalışamayacaksanız uygun bir güne taşınması için talep oluşturun.
                            </p>
                          </div>
                        </div>
                        {gdAcik && (
                          <div className="mt-2.5 space-y-2">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <p className="text-[11px] text-foreground-500 mb-1">Mevcut Tarih</p>
                                <p className="text-sm text-foreground-800">{formatPlanDate(ziyaret.ziyaretTarihi)}</p>
                              </div>
                              <div>
                                <p className="text-[11px] text-foreground-500 mb-1">Mevcut Saat</p>
                                <p className="text-sm text-foreground-800">{planlananAralik}</p>
                              </div>
                            </div>
                            <div>
                              <p className="text-[11px] text-foreground-500 mb-1">Talep Edilen Tarih</p>
                              <DatePicker
                                value={gdTalepTarihi}
                                min={trTodayISO()}
                                onChange={(e) => setGdTalepTarihi(e.target.value)}
                              />
                            </div>
                            <Textarea
                              value={gdAciklama}
                              maxLength={500}
                              placeholder="Açıklama..."
                              onChange={(e) => setGdAciklama(e.target.value)}
                            />
                          </div>
                        )}
                        <div className="mt-2.5 flex items-center justify-end gap-2">
                          {gdAcik ? (
                            <>
                              <Button variant="ghost" size="sm" disabled={operating} onClick={() => { setGdAcik(false); setGdTalepTarihi(''); setGdAciklama(''); }}>
                                Vazgeç
                              </Button>
                              <Button variant="primary" size="sm" isLoading={operating} onClick={() => void doGunDegisikligi()}>
                                Talebi Gönder
                              </Button>
                            </>
                          ) : (
                            <Button variant="outline" size="sm" leftIcon={<i className="ri-calendar-2-line" />} onClick={() => setGdAcik(true)}>
                              Gün Değişikliği Talep Et
                            </Button>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                )}
                {(canCalismaYapilmadi || cyGonderildi) && (
                  <div className="rounded-lg border border-warning-200/60 bg-warning-50/60 p-2.5">
                    {cyGonderildi ? (
                      <p className="text-sm font-medium text-warning-700 flex items-center gap-1.5">
                        <i className="ri-checkbox-circle-line" />
                        Çalışma Yapılmadı Olarak Kaydedildi
                      </p>
                    ) : (
                      <>
                        <div className="flex items-start gap-2">
                          <i className="ri-error-warning-line text-warning-600 mt-0.5" />
                          <div>
                            <p className="text-sm font-semibold text-foreground-900">Çalışma Yapılmadı</p>
                            <p className="text-xs text-foreground-600 mt-0.5">
                              Planlanan gün geldi ancak çalışma gerçekleşmediyse gerekçesiyle kaydedin.
                            </p>
                          </div>
                        </div>
                        {cyAcik && (
                          <div className="mt-2.5">
                            <Textarea
                              value={cyGerekce}
                              maxLength={500}
                              placeholder="Çalışmanın gerçekleşmeme gerekçesi..."
                              onChange={(e) => setCyGerekce(e.target.value)}
                            />
                          </div>
                        )}
                        <div className="mt-2.5 flex items-center justify-end gap-2">
                          {cyAcik ? (
                            <>
                              <Button variant="ghost" size="sm" disabled={operating} onClick={() => { setCyAcik(false); setCyGerekce(''); }}>
                                Vazgeç
                              </Button>
                              <Button variant="primary" size="sm" isLoading={operating} onClick={() => void doCalismaYapilmadi()}>
                                Kaydet
                              </Button>
                            </>
                          ) : (
                            <Button variant="outline" size="sm" leftIcon={<i className="ri-error-warning-line" />} onClick={() => setCyAcik(true)}>
                              Çalışma Yapılmadı
                            </Button>
                          )}
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
            </Card>
          )}

          {/* İzin Talep Et (gelecek Sabit Program) */}
          {(canIzinTalep || izinGonderildi) && (
            <div className="rounded-lg border border-primary-200/60 bg-primary-50/60 p-3">
              {izinGonderildi ? (
                <p className="text-sm font-medium text-primary-700 flex items-center gap-1.5">
                  <i className="ri-checkbox-circle-line" />
                  İzin Talebi Gönderildi
                </p>
              ) : (
                <>
                  <div className="flex items-start gap-2">
                    <i className="ri-send-plane-line text-primary-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-semibold text-foreground-900">İzin Talep Et</p>
                      <p className="text-xs text-foreground-600 mt-0.5">
                        Bu ziyaretin günü gelmediği için ziyaret başlatılamaz. İhtiyacınız varsa izin talebinde bulunabilirsiniz.
                      </p>
                    </div>
                  </div>
                  {izinAcik && (
                    <div className="mt-2.5 space-y-2">
                      <div>
                        <p className="text-[11px] text-foreground-500 mb-1">İzin Türü</p>
                        <Select
                          value={izinTuru}
                          onChange={(e) => setİzinTuru(e.target.value)}
                          options={[
                            { value: 'Yıllık İzin', label: 'Yıllık İzin' },
                            { value: 'Mazeret İzni', label: 'Mazeret İzni' },
                            { value: 'Rapor', label: 'Rapor' },
                            { value: 'Diğer', label: 'Diğer' },
                          ]}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-[11px] text-foreground-500 mb-1">Başlangıç Tarihi</p>
                          <DatePicker
                            value={izinBaslangic}
                            onChange={(e) => setİzinBaslangic(e.target.value)}
                          />
                        </div>
                        <div>
                          <p className="text-[11px] text-foreground-500 mb-1">Bitiş Tarihi</p>
                          <DatePicker
                            value={izinBitis}
                            min={izinBaslangic}
                            onChange={(e) => setİzinBitis(e.target.value)}
                          />
                        </div>
                      </div>
                      <Textarea
                        value={izinGerekce}
                        maxLength={500}
                        placeholder="İzin açıklaması..."
                        onChange={(e) => setİzinGerekce(e.target.value)}
                      />
                    </div>
                  )}
                  <div className="mt-2.5 flex items-center justify-end gap-2">
                    {izinAcik ? (
                      <>
                        <Button variant="ghost" size="sm" disabled={operating} onClick={() => { setİzinAcik(false); setİzinGerekce(''); }}>
                          Vazgeç
                        </Button>
                        <Button variant="primary" size="sm" isLoading={operating} onClick={() => void doIzinTalep()}>
                          Talebi Gönder
                        </Button>
                      </>
                    ) : (
                      <Button
                        variant="primary"
                        size="sm"
                        leftIcon={<i className="ri-send-plane-line" />}
                        onClick={() => { setİzinBaslangic(ziyaret.ziyaretTarihi); setİzinBitis(ziyaret.ziyaretTarihi); setİzinAcik(true); }}
                      >
                        İzin Talep Et
                      </Button>
                    )}
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/** "09:00" ve "17:00" → 480 dk. Boş/hatalı aralıkta 0. */
function dakikaAralik(bas: string | null, bit: string | null): number {
  if (!bas || !bit) return 0;
  const toMin = (s: string) => {
    const [h, m] = s.split(':').map(Number);
    return (h || 0) * 60 + (m || 0);
  };
  const d = toMin(bit) - toMin(bas);
  return d > 0 ? d : 0;
}