import { useCallback, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import { useToastActions } from '@/hooks/useToast';
import { useModalActions } from '@/hooks/useModal';
import { useRealtimeRefresh } from '@/hooks/useRealtimeRefresh';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import { matchesSearch } from '@/utils/turkishText';
import {
  fetchOccurrences,
  fetchProgramDetay,
  trTodayISO,
  formatSureKisa,
  yeniProgramTuruLabel,
  type ZiyaretOccurrence,
  type ProgramDetay,
} from '@/lib/planlamaService';
import {
  durumToken,
  GUN_ADI,
  GUN_SIRA,
  gunIndex,
  formatTarihUzun,
  haftaPazartesi,
  gunEkle,
  type BadgeVariant,
} from '@/pages/osgb/ziyaret-planlama/components/detay/detayUi';
import { programTuruBadgeVariant } from '@/pages/osgb/ziyaret-planlama/components/ziyaretPlanlamaUi';
import ZiyaretBaslatBitirButton from '../ZiyaretBaslatBitirButton';
import PlansizCalismaModal from '../PlansizCalismaModal';
import ZiyaretDetayModal from '../ZiyaretDetayModal';
import { KpiKart, HaftaSecici, AySecici, tehlikeVariant, tehlikeSinifiLabel } from './sahaZiyaretUi';

interface SabitProgramZiyaretListesiProps {
  programId: string;
  /** Üst ekranı (personel özeti) tazelemek için çağrılır. */
  onChanged?: () => void;
}

type Satir =
  | { kind: 'occ'; id: string; tarih: string; occ: ZiyaretOccurrence }
  | { kind: 'bos'; tarih: string; gun: number };

type TabKey = 'tumu' | 'bugun' | 'tamamlanan' | 'bekleyen' | 'geciken' | 'iptal';

const TABS: { key: TabKey; label: string }[] = [
  { key: 'tumu', label: 'Tümü' },
  { key: 'bugun', label: 'Bugün' },
  { key: 'tamamlanan', label: 'Tamamlanan' },
  { key: 'bekleyen', label: 'Bekleyen' },
  { key: 'geciken', label: 'Geciken' },
  { key: 'iptal', label: 'İptal Edilen' },
];

/** Bir ziyaretin GERÇEK gerçekleşen süresini (dakika) çözer. Devam eden ziyarette başlangıçtan
 *  itibaren geçen süre kullanılır. Gerçek bir ölçüm yoksa null (gelecek / başlamamış). */
function realizedMinutes(occ: ZiyaretOccurrence): number | null {
  if (occ.actualDurationMinutes != null) return Math.max(0, occ.actualDurationMinutes);
  if (occ.durum === 'devam_ediyor' && occ.actualStart) {
    const ms = Date.now() - new Date(occ.actualStart).getTime();
    if (Number.isFinite(ms)) return Math.max(0, Math.round(ms / 60000));
  }
  return null;
}

/** Gerçekleşme oranı = gerçekleşen süre / planlanan süre × 100. Durum tek başına %100 DEMEK DEĞİLDİR. */
function gerceklesmeOran(occ: ZiyaretOccurrence): number | null {
  const plan = occ.planlananSureDakika ?? 0;
  if (plan <= 0) return null;
  const gerc = realizedMinutes(occ);
  if (gerc == null) return null;
  return (gerc / plan) * 100;
}

/** Oranı TR biçiminde gösterir: %0,42 · %0,4 · %50 · %100. */
function formatOran(oran: number): string {
  const capped = Math.max(0, Math.min(100, oran));
  if (capped === 0) return '%0';
  if (capped < 1) return `%${capped.toFixed(2).replace('.', ',')}`;
  if (capped < 10) return `%${capped.toFixed(1).replace('.', ',')}`;
  return `%${Math.round(capped)}`;
}

/** Gerçekleşme hücresi — gerçek orandan hesaplanan ince progress bar + yüzde. Ölçüm yoksa "—". */
function GerceklesmeHucre({ occ }: { occ: ZiyaretOccurrence }) {
  const oran = gerceklesmeOran(occ);
  const olculdu = realizedMinutes(occ) != null;
  if (oran == null || !olculdu) return <span className="text-foreground-400">—</span>;
  const capped = Math.max(0, Math.min(100, oran));
  return (
    <div className="flex items-center gap-2 min-w-[130px]">
      <div className="h-1.5 w-16 rounded-full bg-background-300/70 dark:bg-background-300/40 overflow-hidden">
        <div className="h-full rounded-full bg-success-500" style={{ width: `${capped}%` }} />
      </div>
      <span className="text-xs font-medium text-foreground-700 tabular-nums">{formatOran(oran)}</span>
    </div>
  );
}

/**
 * SAHA — Sabit Çalışma Programı ziyaret listesi (HAFTA BAZLI).
 *
 * Bu modelde haftalık gün + saat önceden tanımlıdır; sistem planlı occurrence kayıtlarını
 * (geçmiş · bugün · gelecek) gösterir. Liste YALNIZCA seçili haftanın 7 gününü gösterir; ayın
 * tamamı tek seferde dökülmez. Hafta navigasyonu gerçek takvim hesabıyla çalışır ("Bu Hafta"
 * bugünün haftasına döner; 29 Eylül – 5 Ekim gibi ay/yıl geçişleri doğru hesaplanır).
 *
 * KESİN KURAL: günü gelmemiş ziyaret BAŞLATILAMAZ — "Başlat" yalnızca bugünkü planlı ziyarette
 * görünür; gelecek ziyaretlerde pasif "Günü gelmedi" ve detayda "İzin Talep Et" bulunur. Backend
 * de gelecek tarihli start'ı reddeder (WRONG_DATE).
 */
export default function SabitProgramZiyaretListesi({ programId, onChanged }: SabitProgramZiyaretListesiProps) {
  const { addToast } = useToastActions();
  const { openModal, closeModal } = useModalActions();

  const [haftaBaslangic, setHaftaBaslangic] = useState(() => haftaPazartesi(trTodayISO()));
  const [tab, setTab] = useState<TabKey>('tumu');
  const [arama, setArama] = useState('');
  const [occs, setOccs] = useState<ZiyaretOccurrence[]>([]);
  const [program, setProgram] = useState<ProgramDetay | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const bugun = trTodayISO();
  const haftaBitis = useMemo(() => gunEkle(haftaBaslangic, 6), [haftaBaslangic]);
  const buHaftaPazartesi = useMemo(() => haftaPazartesi(trTodayISO()), []);
  const ayKey = haftaBaslangic.slice(0, 7);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [pd, res] = await Promise.all([
        fetchProgramDetay(programId),
        fetchOccurrences({ programId, baslangic: haftaBaslangic, bitis: haftaBitis, pageSize: 200 }),
      ]);
      setProgram(pd);
      setOccs(res.data.filter((o) => o.planTuru === 'tam_zamanli'));
    } catch (e) {
      setError(friendlyErrorMessage(e, 'Ziyaret listesi yüklenemedi.'));
      setOccs([]);
      setProgram(null);
    } finally {
      setLoading(false);
    }
  }, [programId, haftaBaslangic, haftaBitis]);

  useEffect(() => {
    void load();
  }, [load]);

  // Merkezi realtime: ziyaret başlat/bitir/iptal değişiminde listeyi tazele.
  useRealtimeRefresh(['ziyaretler'], () => { void load(); });

  const oncekiHafta = useCallback(() => setHaftaBaslangic((h) => gunEkle(h, -7)), []);
  const sonrakiHafta = useCallback(() => setHaftaBaslangic((h) => gunEkle(h, 7)), []);
  const buHafta = useCallback(() => setHaftaBaslangic(haftaPazartesi(trTodayISO())), []);
  // Ay seçici (ikincil hızlı atlama): o ayın ilk gününü içeren haftaya gider.
  const ayDegistir = useCallback((ym: string) => setHaftaBaslangic(haftaPazartesi(`${ym}-01`)), []);

  const openDetay = useCallback(
    (ziyaretId: string) => {
      openModal({
        title: 'Ziyaret Detayı',
        description: 'Sabit Çalışma Programı',
        variant: 'detail',
        width: 960,
        minWidth: 660,
        minHeight: 580,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: <ZiyaretDetayModal ziyaretId={ziyaretId} onChanged={() => { void load(); onChanged?.(); }} />,
      });
    },
    [openModal, load, onChanged],
  );

  const handlePlansiz = useCallback(() => {
    let modalId: string;
    modalId = openModal({
      title: 'Plan Dışı Çalışma Başlat',
      description: 'Gerekçe girip konumunuz doğrulandıktan sonra başlatılır',
      variant: 'detail',
      width: 560,
      minWidth: 420,
      showFooter: false,
      closable: true,
      content: (
        <PlansizCalismaModal
          onDone={() => {
            closeModal(modalId);
            void load();
            onChanged?.();
            addToast({ title: 'Plan dışı çalışma başlatıldı', message: 'Gerekçeli çalışma kaydı oluşturuldu.', type: 'success' });
          }}
        />
      ),
    });
  }, [openModal, closeModal, load, onChanged, addToast]);

  // Programın izin günleri (weekday index → izinli).
  const izinGunleri = useMemo(() => {
    const set = new Set<number>();
    for (const g of program?.gunler ?? []) if (g.izin) set.add(g.gun);
    return set;
  }, [program]);

  // Satırlar: yalnızca seçili haftanın 7 günü. Gerçek occurrence varsa gerçek durum,
  // yoksa pasif işaretçi satırı (izin / hafta sonu / plan dışı).
  const satirlar = useMemo<Satir[]>(() => {
    const byDate = new Map<string, ZiyaretOccurrence[]>();
    for (const o of occs) {
      if (!byDate.has(o.ziyaretTarihi)) byDate.set(o.ziyaretTarihi, []);
      byDate.get(o.ziyaretTarihi)!.push(o);
    }
    const out: Satir[] = [];
    for (let i = 0; i < 7; i += 1) {
      const tarih = gunEkle(haftaBaslangic, i);
      const list = (byDate.get(tarih) ?? [])
        .slice()
        .sort((a, b) => (a.planlananBaslangic ?? '').localeCompare(b.planlananBaslangic ?? ''));
      if (list.length === 0) {
        out.push({ kind: 'bos', tarih, gun: gunIndex(tarih) });
      } else {
        for (const o of list) out.push({ kind: 'occ', id: o.id, tarih: o.ziyaretTarihi, occ: o });
      }
    }
    return out;
  }, [occs, haftaBaslangic]);

  const sayilar = useMemo(() => {
    const c: Record<TabKey, number> = { tumu: 0, bugun: 0, tamamlanan: 0, bekleyen: 0, geciken: 0, iptal: 0 };
    for (const s of satirlar) {
      c.tumu += 1;
      if (s.tarih === bugun) c.bugun += 1;
      if (s.kind !== 'occ') continue;
      const o = s.occ;
      if (o.durum === 'gerceklesti' || o.durum === 'otomatik_kapatildi') c.tamamlanan += 1;
      if (o.durum === 'planlandi' && o.ziyaretTarihi >= bugun) c.bekleyen += 1;
      if (o.durum === 'gerceklesmedi' || (o.durum === 'planlandi' && o.ziyaretTarihi < bugun)) c.geciken += 1;
      if (o.durum === 'iptal') c.iptal += 1;
    }
    return c;
  }, [satirlar, bugun]);

  // Haftalık KPI — gerçek sürelerden (planlanan / gerçekleşen / kalan / oran).
  const kpi = useMemo(() => {
    let plan = 0;
    let gerc = 0;
    for (const o of occs) {
      plan += o.planlananSureDakika ?? 0;
      gerc += realizedMinutes(o) ?? 0;
    }
    const oran = plan > 0 ? (Math.min(gerc, plan) / plan) * 100 : 0;
    return { plan, gerc, kalan: Math.max(plan - gerc, 0), oran };
  }, [occs]);

  const gorunen = useMemo(() => {
    return satirlar.filter((s) => {
      if (!eslesirTab(s, tab, bugun)) return false;
      if (!arama.trim()) return true;
      const etiket = `${s.tarih} ${formatTarihUzun(s.tarih)} ${s.kind === 'occ' ? s.occ.firmaUnvan : ''}`;
      return matchesSearch(etiket, arama);
    });
  }, [satirlar, tab, arama, bugun]);

  const programBilgi = program?.program ?? null;
  const calisilanGunler = (program?.gunler ?? [])
    .filter((g) => !g.izin && g.baslangicSaat && g.bitisSaat)
    .sort((a, b) => GUN_SIRA.indexOf(a.gun) - GUN_SIRA.indexOf(b.gun));
  const calismaGunleriLabel = calisilanGunler.length
    ? `${GUN_ADI[calisilanGunler[0].gun]} - ${GUN_ADI[calisilanGunler[calisilanGunler.length - 1].gun]}`
    : '—';
  const gunlukSaatLabel = calisilanGunler[0] ? `${calisilanGunler[0].baslangicSaat} - ${calisilanGunler[0].bitisSaat}` : '—';
  const bugunPlanliVar = occs.some(
    (o) => o.ziyaretTarihi === bugun && (o.durum === 'planlandi' || o.durum === 'devam_ediyor'),
  );

  return (
    <div className="space-y-3">
      {/* Alt başlık + hafta/ay navigasyonu */}
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="min-w-0">
          <h2 className="text-lg font-semibold text-foreground-950">Sabit Çalışma Programı - Ziyaret Listesi</h2>
          <p className="text-xs text-foreground-500">Seçili haftanın planlanan ziyaretleri. Günü gelmemiş ziyaretler başlatılamaz.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <AySecici ayKey={ayKey} onChange={ayDegistir} />
          <HaftaSecici
            baslangic={haftaBaslangic}
            bitis={haftaBitis}
            onPrev={oncekiHafta}
            onNext={sonrakiHafta}
            onToday={buHafta}
            buHaftaMi={haftaBaslangic === buHaftaPazartesi}
          />
        </div>
      </div>

      {/* Haftalık KPI şeridi (gerçek sürelerden) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
        <KpiKart icon="ri-hourglass-line" label="Planlanan Süre" value={formatSureKisa(kpi.plan)} tone="primary" />
        <KpiKart icon="ri-checkbox-circle-line" label="Gerçekleşen Süre" value={formatSureKisa(kpi.gerc)} tone="success" />
        <KpiKart icon="ri-timer-line" label="Kalan Süre" value={formatSureKisa(kpi.kalan)} tone="warning" />
        <KpiKart icon="ri-percent-line" label="Gerçekleşme" value={formatOran(kpi.oran)} tone="accent" />
      </div>

      {/* Firma + Program özet kartı */}
      {programBilgi && (
        <div className="isg-card p-3">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-3">
            <div className="flex items-center gap-3 min-w-[220px]">
              <span className="w-11 h-11 rounded-lg flex items-center justify-center flex-shrink-0 bg-primary-50 text-primary-600 dark:bg-primary-500/15 dark:text-primary-300">
                <i className="ri-building-4-line text-xl" />
              </span>
              <div className="min-w-0">
                <p className="font-semibold text-foreground-950 truncate">{programBilgi.firmaUnvan}</p>
                {(programBilgi.firmaIl || programBilgi.firmaIlce) && (
                  <p className="text-[11px] text-foreground-500">
                    {[programBilgi.firmaIl, programBilgi.firmaIlce].filter(Boolean).join(' / ')}
                  </p>
                )}
              </div>
            </div>
            <OzetAlan label="Tehlike Sınıfı">
              <Badge variant={tehlikeVariant(programBilgi.firmaTehlikeSinifi)}>{tehlikeSinifiLabel(programBilgi.firmaTehlikeSinifi)}</Badge>
            </OzetAlan>
            <OzetAlan label="Plan Türü">
              <Badge variant={programTuruBadgeVariant(programBilgi.programTuru)}>{yeniProgramTuruLabel(programBilgi.programTuru)}</Badge>
            </OzetAlan>
            <OzetAlan label="Çalışma Günleri">
              <span className="text-sm font-medium text-foreground-800">{calismaGunleriLabel}</span>
            </OzetAlan>
            <OzetAlan label="Planlanan Saat">
              <span className="text-sm font-medium text-foreground-800">{gunlukSaatLabel}</span>
            </OzetAlan>
            {!bugunPlanliVar && (
              <div className="ml-auto">
                <Button variant="outline" size="sm" leftIcon={<i className="ri-add-circle-line" />} onClick={handlePlansiz}>
                  Plan Dışı Çalışma Başlat
                </Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Filtre sekmeleri + arama */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 overflow-x-auto no-scrollbar isg-segmented p-1 rounded-lg">
          {TABS.map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setTab(t.key)}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium whitespace-nowrap transition-colors cursor-pointer ${
                tab === t.key
                  ? 'isg-segment-active text-primary-700 dark:text-primary-300'
                  : 'text-foreground-500 hover:text-foreground-800'
              }`}
            >
              {t.label}
              <span className={`text-[11px] rounded-full px-1.5 ${tab === t.key ? 'bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300' : 'bg-background-300/60 dark:bg-background-300/40 text-foreground-600'}`}>
                {sayilar[t.key]}
              </span>
            </button>
          ))}
        </div>
        <div className="relative flex-1 min-w-[200px] ml-auto">
          <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400 text-sm" />
          <input
            value={arama}
            onChange={(e) => setArama(e.target.value)}
            placeholder="Tarih ara..."
            className="w-full rounded-md border border-background-300/60 dark:border-background-400/25 bg-background-50 dark:bg-background-100 pl-9 pr-3 py-2 text-sm text-foreground-800 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400"
          />
        </div>
        <Button variant="outline" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={() => void load()}>
          Listeyi Yenile
        </Button>
      </div>

      {/* Liste — yalnızca seçili haftanın 7 günü */}
      <div className="isg-card overflow-hidden">
        {loading ? (
          <div className="flex justify-center py-16">
            <Loading size="lg" text="Ziyaretler yükleniyor..." />
          </div>
        ) : error ? (
          <div className="p-4">
            <ErrorState message={error} onRetry={() => void load()} />
          </div>
        ) : gorunen.length === 0 ? (
          <div className="p-4">
            <EmptyState
              icon="ri-calendar-line"
              title="Bu hafta için ziyaret bulunmuyor."
              description="Farklı bir hafta seçebilir veya filtreyi değiştirebilirsiniz."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm isg-mobile-cards">
              <thead>
                <tr className="border-b border-background-300/50 bg-background-200/60 dark:bg-background-100/30">
                  <th className="isg-table-head-cell text-left whitespace-nowrap">Tarih</th>
                  <th className="isg-table-head-cell text-left">Gün</th>
                  <th className="isg-table-head-cell text-left whitespace-nowrap">Planlanan Saat</th>
                  <th className="isg-table-head-cell text-left whitespace-nowrap">Planlanan Süre</th>
                  <th className="isg-table-head-cell text-left">Durum</th>
                  <th className="isg-table-head-cell text-left">Gerçekleşme</th>
                  <th className="isg-table-head-cell text-left whitespace-nowrap">Süre</th>
                  <th className="isg-table-head-cell text-right">İşlemler</th>
                </tr>
              </thead>
              <tbody>
                {gorunen.map((s) => {
                  const gunAdi = GUN_ADI[s.kind === 'occ' ? gunIndex(s.tarih) : s.gun] ?? '—';
                  const bugunMu = s.tarih === bugun;
                  const occ = s.kind === 'occ' ? s.occ : null;
                  const durum = occ ? occDurum(occ, bugun) : bosDurum(s.gun, s.tarih, bugun, izinGunleri);

                  return (
                    <tr
                      key={`${s.kind}-${s.tarih}-${s.kind === 'occ' ? s.id : ''}`}
                      className={`isg-table-row border-b border-background-300/30 dark:border-background-400/15 ${occ ? 'cursor-pointer' : ''}`}
                      onClick={occ ? () => openDetay(occ.id) : undefined}
                    >
                      <td className="isg-table-cell" data-card="title">
                        <div className="flex items-center gap-2 whitespace-nowrap">
                          <i className="ri-calendar-line text-foreground-400" />
                          <span className="text-foreground-800">{formatTarihUzun(s.tarih)}</span>
                        </div>
                      </td>
                      <td className="isg-table-cell text-foreground-700 whitespace-nowrap" data-label="Gün">
                        {gunAdi}
                        {bugunMu && <span className="ml-1.5 text-[10px] font-semibold uppercase text-primary-600 dark:text-primary-400">Bugün</span>}
                      </td>
                      <td className="isg-table-cell text-foreground-700 whitespace-nowrap" data-label="Planlanan Saat">
                        {occ && occ.planlananBaslangic && occ.planlananBitis ? `${occ.planlananBaslangic} - ${occ.planlananBitis}` : '—'}
                      </td>
                      <td className="isg-table-cell text-foreground-700 whitespace-nowrap" data-label="Planlanan Süre">
                        {occ?.planlananSureDakika != null ? formatSureKisa(occ.planlananSureDakika) : '—'}
                      </td>
                      <td className="isg-table-cell" data-label="Durum">
                        <Badge variant={durum.badge}>{durum.label}</Badge>
                      </td>
                      <td className="isg-table-cell" data-label="Gerçekleşme">
                        {occ ? <GerceklesmeHucre occ={occ} /> : <span className="text-foreground-400">—</span>}
                      </td>
                      <td className="isg-table-cell text-foreground-700 whitespace-nowrap" data-label="Süre">
                        {occ?.actualDurationMinutes != null ? formatSureKisa(occ.actualDurationMinutes) : '—'}
                      </td>
                      <td className="isg-table-cell" data-card="actions" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end">
                          {occ ? (
                            <Aksiyonlar occ={occ} bugunMu={bugunMu} onChanged={() => { void load(); onChanged?.(); }} onDetay={() => openDetay(occ.id)} />
                          ) : (
                            <span className="text-foreground-400">—</span>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

function OzetAlan({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="min-w-[110px]">
      <p className="text-[11px] uppercase tracking-wide text-foreground-500">{label}</p>
      <div className="mt-0.5">{children}</div>
    </div>
  );
}

/** Gerçek ziyaret durumu — bugün (başlamamış) ve gelecek gün için özel etiket. */
function occDurum(occ: ZiyaretOccurrence, bugun: string): { label: string; badge: BadgeVariant } {
  if (occ.durum === 'planlandi' && occ.ziyaretTarihi === bugun) return { label: 'Bugün', badge: 'info' };
  if (occ.durum === 'planlandi' && occ.ziyaretTarihi > bugun) return { label: 'Planlanmış', badge: 'secondary' };
  return durumToken(occ.durum);
}

/** Boş (occurrence olmayan) gün için pasif durum rozeti — gerçek program verisine göre. */
function bosDurum(gun: number, tarih: string, bugun: string, izinGunleri: Set<number>): { label: string; badge: BadgeVariant } {
  if (izinGunleri.has(gun)) return { label: 'İzin Günü', badge: 'warning' };
  if (gun === 0 || gun === 6) return { label: 'Hafta Sonu', badge: 'default' };
  if (tarih > bugun) return { label: 'Planlanmış', badge: 'secondary' };
  if (tarih === bugun) return { label: 'Bugün', badge: 'info' };
  return { label: 'Plan Dışı Çalışma Yok', badge: 'default' };
}

function eslesirTab(s: Satir, key: TabKey, bugun: string): boolean {
  if (key === 'tumu') return true;
  // ZV-08 — "Bugün" sekmesi, gerçek occurrence olmayan (boş) gün satırını da içerir;
  // böylece Tümü'de "Bugün" rozeti alan satır ile sekme tutarlı olur.
  if (key === 'bugun') return s.tarih === bugun;
  if (s.kind !== 'occ') return false;
  const o = s.occ;
  switch (key) {
    case 'bugun':
      return o.ziyaretTarihi === bugun;
    case 'tamamlanan':
      return o.durum === 'gerceklesti' || o.durum === 'otomatik_kapatildi';
    case 'bekleyen':
      return o.durum === 'planlandi' && o.ziyaretTarihi >= bugun;
    case 'geciken':
      return o.durum === 'gerceklesmedi' || (o.durum === 'planlandi' && o.ziyaretTarihi < bugun);
    case 'iptal':
      return o.durum === 'iptal';
    default:
      return true;
  }
}

/** Satır aksiyonları — bugün: başlat/bitir · gelecek: günü gelmedi (pasif) + detay · geçmiş: detay. */
function Aksiyonlar({
  occ,
  bugunMu,
  onChanged,
  onDetay,
}: {
  occ: ZiyaretOccurrence;
  bugunMu: boolean;
  onChanged: () => void;
  onDetay: () => void;
}) {
  if (occ.durum === 'devam_ediyor') {
    return <ZiyaretBaslatBitirButton ziyaret={occ} onChanged={onChanged} />;
  }
  if (occ.durum === 'planlandi' && bugunMu) {
    return <ZiyaretBaslatBitirButton ziyaret={occ} onChanged={onChanged} />;
  }
  if (occ.durum === 'planlandi' && !bugunMu) {
    return (
      <div className="flex items-center gap-2">
        <span className="text-xs text-foreground-500 flex items-center gap-1 whitespace-nowrap">
          <i className="ri-time-line" />
          Günü gelmedi
        </span>
        <Button variant="ghost" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={onDetay}>
          Detay
        </Button>
      </div>
    );
  }
  return (
    <Button variant="outline" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={onDetay}>
      Detay
    </Button>
  );
}