import type { ReactNode } from 'react';
import { tehlikeSinifiLabel } from '@/lib/firmaService';

export { tehlikeSinifiLabel };

// GLOBAL TARİH NAVİGASYONU — tek merkez (OSGB + saha ortak kullanır).
export { AySecici, HaftaSecici, haftaAralikLabel } from '@/pages/osgb/ziyaret-planlama/components/detay/tarihSecici';

/** Tehlike sınıfı → Badge varyantı (semantik scale rolleri; hex hardcode yok). */
export function tehlikeVariant(slug: string | null): 'danger' | 'warning' | 'success' {
  if (slug === 'cok_tehlikeli') return 'danger';
  if (slug === 'tehlikeli') return 'warning';
  return 'success';
}

/** Firma kısa kodu (varsa): "#F-XXXXXXXX". */
export function firmaKodu(firmaId: string | null | undefined): string {
  if (!firmaId) return '—';
  return `#F-${firmaId.replace(/-/g, '').slice(0, 8).toUpperCase()}`;
}

type Tone = 'primary' | 'success' | 'warning' | 'accent' | 'secondary';

const TONE_BOX: Record<Tone, string> = {
  primary: 'bg-primary-50 text-primary-600 dark:bg-primary-500/15 dark:text-primary-300',
  success: 'bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-300',
  warning: 'bg-warning-50 text-warning-600 dark:bg-warning-500/15 dark:text-warning-300',
  accent: 'bg-accent-50 text-accent-600 dark:bg-accent-500/15 dark:text-accent-300',
  secondary: 'bg-secondary-100 text-secondary-700 dark:bg-secondary-500/15 dark:text-secondary-300',
};

/** KPI kartı: yuvarlak ikon kutusu + etiket + değer. */
export function KpiKart({ icon, label, value, tone = 'primary' }: { icon: string; label: string; value: ReactNode; tone?: Tone }) {
  return (
    <div className="isg-card flex items-center gap-3 p-3.5">
      <span className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${TONE_BOX[tone]}`}>
        <i className={`${icon} text-lg`} />
      </span>
      <div className="min-w-0">
        <p className="text-[11px] uppercase tracking-wide text-foreground-500 truncate">{label}</p>
        <p className="mt-0.5 text-base font-semibold text-foreground-950 truncate">{value}</p>
      </div>
    </div>
  );
}

/** İnce ilerleme çubuğu (Gerçekleşme). */
export function IlerlemeCubugu({ oran }: { oran: number }) {
  const safe = Math.max(0, Math.min(100, Math.round(oran)));
  return (
    <div className="flex items-center gap-2 min-w-[120px]">
      <div className="h-1.5 flex-1 rounded-full bg-background-300/70 dark:bg-background-300/40 overflow-hidden">
        <div className="h-full rounded-full bg-success-500" style={{ width: `${safe}%` }} />
      </div>
      <span className="text-xs font-medium text-foreground-700 tabular-nums w-9 text-right">%{safe}</span>
    </div>
  );
}

/** Basit istemci-taraflı sayfalama alt satırı. */
export function ListeFooter({ page, pageSize, count, onPage }: { page: number; pageSize: number; count: number; onPage: (p: number) => void }) {
  const pageCount = Math.max(1, Math.ceil(count / pageSize));
  if (count === 0) return null;
  const from = (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, count);
  return (
    <div className="flex items-center justify-between gap-3 px-3 py-2.5 border-t border-background-300/30">
      <span className="text-xs text-foreground-500">{from}-{to} / {count} kayıt</span>
      <div className="flex items-center gap-1">
        <button
          type="button"
          aria-label="Önceki sayfa"
          disabled={page <= 1}
          onClick={() => onPage(page - 1)}
          className="w-7 h-7 flex items-center justify-center rounded text-foreground-500 hover:bg-background-200/70 dark:hover:bg-background-300/40 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
        >
          <i className="ri-arrow-left-s-line" />
        </button>
        <span className="px-2 text-xs font-medium text-foreground-800">{page}</span>
        <button
          type="button"
          aria-label="Sonraki sayfa"
          disabled={page >= pageCount}
          onClick={() => onPage(page + 1)}
          className="w-7 h-7 flex items-center justify-center rounded text-foreground-500 hover:bg-background-200/70 dark:hover:bg-background-300/40 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
        >
          <i className="ri-arrow-right-s-line" />
        </button>
      </div>
    </div>
  );
}