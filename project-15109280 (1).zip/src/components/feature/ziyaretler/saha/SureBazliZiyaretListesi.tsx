import { useCallback, useEffect, useMemo, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import DonutChart from '@/components/feature/DonutChart';
import { useToastActions } from '@/hooks/useToast';
import { useModalActions } from '@/hooks/useModal';
import { useRealtimeRefresh } from '@/hooks/useRealtimeRefresh';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import { matchesSearch } from '@/utils/turkishText';
import {
  fetchGeziciFirmalar,
  geziciStartVisit,
  friendlyPlanlamaError,
  formatSureKisa,
  type GeziciFirmaOption,
} from '@/lib/planlamaService';
import { buAyKey } from '@/pages/osgb/ziyaret-planlama/components/detay/detayUi';
import { getCurrentPosition } from '../ziyaretlerUi';
import ZiyaretDetayModal from '../ZiyaretDetayModal';
import {
  KpiKart,
  IlerlemeCubugu,
  AySecici,
  ListeFooter,
  tehlikeVariant,
  tehlikeSinifiLabel,
} from './sahaZiyaretUi';

interface SureBazliZiyaretListesiProps {
  /** Üst ekranı (personel özeti) tazelemek için çağrılır. */
  onChanged?: () => void;
}

const PAGE_SIZE = 8;

/**
 * SAHA — Süre Bazlı (gezici) plan listesi.
 *
 * Personelin ay içinde istediği uygun günde gidebileceği firmaları ve AYLIK süre bakiyesini
 * gösterir. Gelecek güne dair "planlı ziyaret" ÜRETİLMEZ; yalnızca gerçek firmalar + gerçekleşen
 * süreler listelenir. "Ziyaret Başlat" mevcut `geziciStartVisit` (GPS + geofence + aktif atama +
 * aktif plan kontrolleri) servisini kullanır. Yeni liste/motor oluşturulmaz.
 */
export default function SureBazliZiyaretListesi({ onChanged }: SureBazliZiyaretListesiProps) {
  const { addToast } = useToastActions();
  const { openModal } = useModalActions();

  const [ayKey, setAyKey] = useState(buAyKey());
  const [firmalar, setFirmalar] = useState<GeziciFirmaOption[]>([]);
  const [arama, setArama] = useState('');
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [startingId, setStartingId] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchGeziciFirmalar(ayKey);
      setFirmalar(res);
    } catch (e) {
      setError(friendlyErrorMessage(e, 'Firma listesi yüklenemedi.'));
      setFirmalar([]);
    } finally {
      setLoading(false);
    }
  }, [ayKey]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    setPage(1);
  }, [ayKey, arama]);

  // Merkezi realtime: ziyaret başlat/bitir ve atama değişimi listeyi tazeler.
  useRealtimeRefresh(['ziyaretler', 'atamalar'], () => { void load(); });

  const openDetay = useCallback(
    (ziyaretId: string) => {
      openModal({
        title: 'Ziyaret Detayı',
        description: 'Süre Bazlı Ziyaret',
        variant: 'detail',
        width: 960,
        minWidth: 660,
        minHeight: 580,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: <ZiyaretDetayModal ziyaretId={ziyaretId} onChanged={() => { void load(); onChanged?.(); }} />,
      });
    },
    [openModal, load, onChanged],
  );

  const handleStart = useCallback(
    async (f: GeziciFirmaOption) => {
      if (f.ongoingOccurrenceId) {
        openDetay(f.ongoingOccurrenceId);
        return;
      }
      setStartingId(f.firmaId);
      try {
        const pos = await getCurrentPosition();
        const res = await geziciStartVisit(f.firmaId, pos.latitude, pos.longitude);
        addToast({ title: 'Ziyaret başlatıldı', message: `${f.firmaUnvan} için ziyaret kaydı oluşturuldu.`, type: 'success' });
        await load();
        onChanged?.();
        if (res.occurrenceId) openDetay(res.occurrenceId);
      } catch (e) {
        addToast({ title: 'Ziyaret başlatılamadı', message: friendlyPlanlamaError(e), type: 'error' });
      } finally {
        setStartingId(null);
      }
    },
    [addToast, load, onChanged, openDetay],
  );

  const toplam = useMemo(() => {
    const planlanan = firmalar.reduce((a, f) => a + (f.planlananDakika || 0), 0);
    const gerceklesen = firmalar.reduce((a, f) => a + (f.ayGerceklesenDakika || 0), 0);
    const kalan = firmalar.reduce((a, f) => a + Math.max(f.ayKalanDakika || 0, 0), 0);
    const oran = planlanan > 0 ? Math.round((Math.min(gerceklesen, planlanan) / planlanan) * 100) : 0;
    return { planlanan, gerceklesen, kalan, oran };
  }, [firmalar]);

  const filtreli = useMemo(() => {
    const q = arama.trim().toLocaleLowerCase('tr');
    if (!q) return firmalar;
    return firmalar.filter((f) =>
      [f.firmaUnvan, f.firmaIl, f.firmaIlce].some((v) => matchesSearch(String(v ?? ''), q)),
    );
  }, [firmalar, arama]);

  const pageCount = Math.max(1, Math.ceil(filtreli.length / PAGE_SIZE));
  const guvenliPage = Math.min(page, pageCount);
  const pageRows = filtreli.slice((guvenliPage - 1) * PAGE_SIZE, guvenliPage * PAGE_SIZE);

  return (
    <div className="space-y-3">
      {/* Alt başlık + ay seçici */}
      <div className="flex flex-wrap items-end justify-between gap-2">
        <div className="min-w-0">
          <h2 className="text-lg font-semibold text-foreground-950">Süre Bazlı Plan - Firmalar</h2>
          <p className="text-xs text-foreground-500">Bu ay size tanımlı firmalar ve aylık çalışma süreleri</p>
        </div>
        <AySecici ayKey={ayKey} onChange={setAyKey} />
      </div>

      {/* KPI şeridi */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
        <KpiKart icon="ri-building-2-line" label="Toplam Firma" value={firmalar.length} tone="primary" />
        <KpiKart icon="ri-hourglass-line" label="Aylık Ayrılan Süre" value={formatSureKisa(toplam.planlanan)} tone="accent" />
        <KpiKart icon="ri-checkbox-circle-line" label="Gerçekleşen Süre" value={formatSureKisa(toplam.gerceklesen)} tone="success" />
        <KpiKart icon="ri-timer-line" label="Kalan Süre" value={formatSureKisa(toplam.kalan)} tone="warning" />
        <div className="isg-card flex items-center justify-center gap-3 p-3.5">
          <DonutChart
            size={68}
            strokeWidth={9}
            hideLegend
            data={[{ label: 'Gerçekleşen', value: toplam.planlanan > 0 ? Math.min(toplam.gerceklesen, toplam.planlanan) : 0, color: 'success' }]}
            total={Math.max(toplam.planlanan, 1)}
            centerText={`%${toplam.oran}`}
            centerLabel=""
          />
          <div className="min-w-0">
            <p className="text-[11px] uppercase tracking-wide text-foreground-500">Aylık</p>
            <p className="text-sm font-semibold text-foreground-900">Gerçekleşme Oranı</p>
          </div>
        </div>
      </div>

      {/* Liste */}
      <div className="isg-card overflow-hidden">
        <div className="flex flex-wrap items-center gap-2 p-3">
          <div className="relative flex-1 min-w-[220px]">
            <i className="ri-search-line absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400 text-sm" />
            <input
              value={arama}
              onChange={(e) => setArama(e.target.value)}
              placeholder="Firma adı, il, ilçe ara..."
              className="w-full rounded-md border border-background-300/60 dark:border-background-400/25 bg-background-50 dark:bg-background-100 pl-9 pr-3 py-2 text-sm text-foreground-800 placeholder:text-foreground-400 focus:outline-none focus:ring-2 focus:ring-primary-400"
            />
          </div>
          <Button variant="outline" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={() => void load()}>
            Listeyi Yenile
          </Button>
        </div>

        {loading ? (
          <div className="flex justify-center py-16">
            <Loading size="lg" text="Firmalar yükleniyor..." />
          </div>
        ) : error ? (
          <div className="p-4">
            <ErrorState message={error} onRetry={() => void load()} />
          </div>
        ) : firmalar.length === 0 ? (
          <div className="p-4">
            <EmptyState
              icon="ri-building-2-line"
              title="Size tanımlı Süre Bazlı firma bulunmuyor."
              description="Aktif atama ve Süre Bazlı plan tanımlandığında firmalar burada listelenir."
            />
          </div>
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-sm isg-mobile-cards">
                <thead>
                  <tr className="border-y border-background-300/50 bg-background-200/60 dark:bg-background-100/30">
                    <th className="isg-table-head-cell text-left">Firma</th>
                    <th className="isg-table-head-cell text-left">Tehlike Sınıfı</th>
                    <th className="isg-table-head-cell text-left">İl / İlçe</th>
                    <th className="isg-table-head-cell text-left whitespace-nowrap">Aylık Ayrılan Süre</th>
                    <th className="isg-table-head-cell text-left whitespace-nowrap">Gerçekleşen Süre</th>
                    <th className="isg-table-head-cell text-left whitespace-nowrap">Kalan Süre</th>
                    <th className="isg-table-head-cell text-left">Gerçekleşme</th>
                    <th className="isg-table-head-cell text-right">İşlemler</th>
                  </tr>
                </thead>
                <tbody>
                  {pageRows.map((f) => {
                    const oran = f.planlananDakika > 0 ? Math.round((Math.min(f.ayGerceklesenDakika, f.planlananDakika) / f.planlananDakika) * 100) : 0;
                    return (
                      <tr key={f.firmaId} className="isg-table-row border-b border-background-300/30 dark:border-background-400/15">
                        <td className="isg-table-cell" data-card="title">
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 bg-primary-50 text-primary-600 dark:bg-primary-500/15 dark:text-primary-300">
                              <i className="ri-building-2-line" />
                            </span>
                            <div className="min-w-0">
                              <p className="font-medium text-foreground-900 truncate">{f.firmaUnvan}</p>
                            </div>
                          </div>
                        </td>
                        <td className="isg-table-cell" data-label="Tehlike Sınıfı">
                          <Badge variant={tehlikeVariant(f.tehlikeSinifi)}>{tehlikeSinifiLabel(f.tehlikeSinifi)}</Badge>
                        </td>
                        <td className="isg-table-cell text-foreground-700 whitespace-nowrap" data-label="İl / İlçe">
                          {[f.firmaIl, f.firmaIlce].filter(Boolean).join(' / ') || '—'}
                        </td>
                        <td className="isg-table-cell text-foreground-800 whitespace-nowrap" data-label="Aylık Ayrılan Süre">
                          {f.hasPlan ? formatSureKisa(f.planlananDakika) : '—'}
                        </td>
                        <td className="isg-table-cell text-foreground-800 whitespace-nowrap" data-label="Gerçekleşen Süre">
                          {f.hasPlan ? formatSureKisa(f.ayGerceklesenDakika) : '—'}
                        </td>
                        <td className="isg-table-cell text-foreground-800 whitespace-nowrap" data-label="Kalan Süre">
                          {f.hasPlan ? formatSureKisa(Math.max(f.ayKalanDakika, 0)) : '—'}
                        </td>
                        <td className="isg-table-cell" data-label="Gerçekleşme">
                          <IlerlemeCubugu oran={oran} />
                        </td>
                        <td className="isg-table-cell" data-card="actions">
                          <div className="flex items-center justify-end gap-1">
                            {f.ongoingOccurrenceId ? (
                              <Button variant="danger" size="sm" leftIcon={<i className="ri-stop-circle-line" />} onClick={() => openDetay(f.ongoingOccurrenceId as string)}>
                                Ziyareti Bitir
                              </Button>
                            ) : f.hasPlan ? (
                              <Button
                                variant="primary"
                                size="sm"
                                isLoading={startingId === f.firmaId}
                                leftIcon={<i className="ri-play-circle-line" />}
                                onClick={() => void handleStart(f)}
                              >
                                Ziyaret Başlat
                              </Button>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                disabled
                                title="Bu firma için bu dönemde geçerli bir Süre Bazlı planı bulunmuyor."
                                leftIcon={<i className="ri-forbid-2-line" />}
                              >
                                Plan Yok
                              </Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <ListeFooter page={guvenliPage} pageSize={PAGE_SIZE} count={filtreli.length} onPage={setPage} />
          </>
        )}
      </div>
    </div>
  );
}