import {
  ZIYARET_DURUM_LABEL,
  formatTimeHM,
  formatSureKisa,
  formatSureDakika,
  type ZiyaretKaydi,
  type ZiyaretDurum,
} from '@/lib/planlamaService';

/** Filtre için durum seçenekleri — mevcut gerçek enum değerlerinden türetilir (yeni enum uydurulmaz). */
export const DURUM_OPTIONS = (Object.keys(ZIYARET_DURUM_LABEL) as ZiyaretDurum[]).map((k) => ({
  value: k,
  label: ZIYARET_DURUM_LABEL[k],
}));

/** Planlanan saat aralığı ("08:00 – 12:00") veya "—" (gezici / planlı slot yok). */
export function planlananAralik(z: ZiyaretKaydi): string {
  if (z.planlananBaslangic && z.planlananBitis) return `${z.planlananBaslangic} – ${z.planlananBitis}`;
  return '—';
}

/** Gerçek başlangıç–bitiş saati (ISO timestamp → HH:mm) veya "—". */
export function gerceklesenAralik(z: ZiyaretKaydi): string {
  if (!z.actualStart) return '—';
  const bas = formatTimeHM(z.actualStart);
  const bit = z.actualEnd ? formatTimeHM(z.actualEnd) : '';
  return bit ? `${bas} – ${bit}` : bas;
}

/** Gerçekleşen süre (yoksa planlanan süre) gösterimi. */
export function sureGosterim(z: ZiyaretKaydi): string {
  if (z.actualDurationMinutes != null) return formatSureKisa(z.actualDurationMinutes);
  if (z.planlananSureDakika != null) return formatSureDakika(z.planlananSureDakika);
  return '—';
}

/** Bir ziyaret kaydının plan dışı (plan_id yok + Gün Programı) olup olmadığı. Yeni enum kullanılmaz. */
export function isPlanDisi(z: ZiyaretKaydi): boolean {
  return z.planTuru === 'tam_zamanli' && z.planId === null;
}

/** Bir ziyaret kaydındaki en anlamlı gerekçe metnini döner (yoksa null). */
export function ziyaretGerekce(z: ZiyaretKaydi): string | null {
  if (isPlanDisi(z) && z.notlar) return `Plan dışı: ${z.notlar}`;
  if (z.gerceklesmemeGerekcesi) return z.gerceklesmemeGerekcesi;
  if (z.erkenCikisGerekcesi) return z.erkenCikisGerekcesi;
  if (z.erkenGirisGerekcesi) return z.erkenGirisGerekcesi;
  if (z.autoClosed) return '24:00\'te otomatik kapatıldı';
  return null;
}

/**
 * Tarayıcının yerleşik Geolocation API'si ile kullanıcının mevcut konumunu alır.
 * Yeni bir GPS sistemi kurmaz; backend start/finish servisleri zaten konumu parametre
 * olarak bekler, bu helper yalnızca o koordinatları sağlar. Hata durumunda backend'in
 * `GPS_REQUIRED` koduyla uyumlu bir mesaj döner (friendlyPlanlamaError ile eşleşir).
 */
export function getCurrentPosition(): Promise<{ latitude: number; longitude: number }> {
  return new Promise((resolve, reject) => {
    if (typeof navigator === 'undefined' || !('geolocation' in navigator)) {
      reject(new Error('GPS_REQUIRED: Cihaz konumu alınamadı. Konum izni verin ve tekrar deneyin.'));
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ latitude: pos.coords.latitude, longitude: pos.coords.longitude }),
      () => reject(new Error('GPS_REQUIRED: Cihaz konumu alınamadı. Konum izni verin ve tekrar deneyin.')),
      // BUG-003 — Start/finish geofence kontrolünde MÜMKÜN OLDUĞUNCA TAZE konum kullanılır:
      // maximumAge=0 ile tarayıcının önbelleklenmiş (30 sn'ye kadar eski) konumu döndürmesi engellenir.
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 },
    );
  });
}

/** Bir hatanın backend kodu içerip içermediğini denetler (ör. 'ERCEN_CIKIS_GEREKCE_REQUIRED'). */
export function isErrorCode(e: unknown, code: string): boolean {
  return e instanceof Error && e.message.includes(code);
}