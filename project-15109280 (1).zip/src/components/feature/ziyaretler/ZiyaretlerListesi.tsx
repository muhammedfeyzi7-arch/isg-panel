import useSWR from 'swr';
import PageHeader from '@/components/ui/PageHeader';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import { useRealtimeRefresh } from '@/hooks/useRealtimeRefresh';
import { fetchMyZiyaret, type ZiyaretPersonelRow } from '@/lib/planlamaService';
import SureBazliZiyaretListesi from './saha/SureBazliZiyaretListesi';
import SabitProgramZiyaretListesi from './saha/SabitProgramZiyaretListesi';

/**
 * SAHA (uzman / işyeri hekimi) — "Ziyaretler" ekranı.
 *
 * Tek bir merkezi dispatcher'dır: kullanıcının AKTİF planına göre iki farklı iş modelini gösterir:
 *  - Sabit Çalışma Programı (tam_zamanli) → planlı ziyaret listesi (geçmiş · bugün · gelecek)
 *  - Süre Bazlı (gezici) → firma + aylık süre listesi (gelecek gün listesi YOK)
 *
 * Eski çok sekmeli "Personel Plan Detayı" modalı saha tarafından TAMAMEN kaldırıldı; tüm detaylar
 * tek ekranlı "Ziyaret Detayı" modalı ile açılır. Modal motoru mevcut SharedUICore'dur.
 */
export default function ZiyaretlerListesi() {
  const { data: row, error, isLoading, mutate } = useSWR<ZiyaretPersonelRow | null>(
    'uzman-hekim-ziyaret',
    fetchMyZiyaret,
    { revalidateOnFocus: true, revalidateOnMount: true, refreshInterval: 30000 },
  );
  const errorMsg = error instanceof Error ? error.message : null;

  // Merkezi realtime: atama değişimi aktif planı etkileyebilir → özeti tazele.
  useRealtimeRefresh(['atamalar'], () => mutate());

  const programVar = !!row && !!row.programTuru && (row.programTuru === 'gezici' || !!row.programId);

  return (
    <div className="isg-page">
      <PageHeader
        title="Ziyaretler"
        subtitle="Size atanmış ziyaret planınız ve saha operasyonlarınız"
        className="flex-shrink-0"
      />

      {isLoading ? (
        <div className="flex justify-center py-16">
          <Loading size="lg" text="Ziyaret bilgileriniz yükleniyor..." />
        </div>
      ) : errorMsg ? (
        <ErrorState message={errorMsg} onRetry={() => mutate()} />
      ) : !row ? (
        <EmptyState
          icon="ri-user-line"
          title="Personel kaydınız bulunamadı."
          description="Ziyaret planınız ve operasyonlarınız için personel kaydınızın tanımlı olması gerekir."
        />
      ) : !programVar ? (
        <EmptyState
          icon="ri-calendar-line"
          title="Aktif ziyaret planınız bulunmuyor."
          description="OSGB yöneticiniz size bir Sabit Çalışma Programı veya Süre Bazlı plan tanımladığında ziyaretleriniz burada görünür."
        />
      ) : row.programTuru === 'gezici' ? (
        <SureBazliZiyaretListesi onChanged={() => mutate()} />
      ) : (
        <SabitProgramZiyaretListesi programId={row.programId as string} onChanged={() => mutate()} />
      )}
    </div>
  );
}