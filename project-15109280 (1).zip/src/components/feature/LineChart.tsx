interface LineChartDataPoint {
  date: string;
  aktif: number;
  yeni: number;
}

interface LineChartProps {
  data: LineChartDataPoint[];
  height?: number;
}

export default function LineChart({ data, height = 220 }: LineChartProps) {
  const maxValue = Math.max(...data.map((d) => Math.max(d.aktif, d.yeni)));
  const minValue = 0;
  const padding = { top: 20, right: 20, bottom: 30, left: 40 };

  const chartWidth = 600;
  const chartHeight = height;
  const innerWidth = chartWidth - padding.left - padding.right;
  const innerHeight = chartHeight - padding.top - padding.bottom;

  const xScale = (index: number) => padding.left + (index / (data.length - 1)) * innerWidth;
  const yScale = (value: number) => padding.top + innerHeight - ((value - minValue) / (maxValue - minValue)) * innerHeight;

  const aktifPath = data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${xScale(i)} ${yScale(d.aktif)}`).join(' ');
  const yeniPath = data.map((d, i) => `${i === 0 ? 'M' : 'L'} ${xScale(i)} ${yScale(d.yeni)}`).join(' ');

  const gridLines = [0, 25, 50, 75, 100];

  return (
    <div className="w-full overflow-x-auto">
      <svg
        viewBox={`0 0 ${chartWidth} ${chartHeight}`}
        preserveAspectRatio="xMidYMid meet"
        className="w-full"
        style={{ minHeight: height }}
      >
        {/* Grid lines */}
        {gridLines.map((val) => (
          <g key={val}>
            <line
              x1={padding.left}
              y1={yScale(val)}
              x2={chartWidth - padding.right}
              y2={yScale(val)}
              stroke="currentColor"
              strokeDasharray="4 4"
              className="text-background-300"
              strokeWidth={1}
            />
            <text
              x={padding.left - 8}
              y={yScale(val) + 4}
              textAnchor="end"
              className="text-xs fill-foreground-400"
            >
              {val}
            </text>
          </g>
        ))}

        {/* X-axis labels */}
        {data.filter((_, i) => i % 3 === 0).map((d, i) => {
          const idx = i * 3;
          return (
            <text
              key={idx}
              x={xScale(idx)}
              y={chartHeight - 8}
              textAnchor="middle"
              className="text-xs fill-foreground-400"
            >
              {d.date}
            </text>
          );
        })}

        {/* Aktif OSGB line */}
        <path
          d={aktifPath}
          fill="none"
          stroke="currentColor"
          className="text-danger-500"
          strokeWidth={2}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {data.map((d, i) => (
          <circle
            key={`aktif-${i}`}
            cx={xScale(i)}
            cy={yScale(d.aktif)}
            r={3}
            className="text-danger-500"
            fill="currentColor"
          />
        ))}

        {/* Yeni OSGB line */}
        <path
          d={yeniPath}
          fill="none"
          stroke="currentColor"
          className="text-primary-500"
          strokeWidth={2}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        {data.map((d, i) => (
          <circle
            key={`yeni-${i}`}
            cx={xScale(i)}
            cy={yScale(d.yeni)}
            r={3}
            className="text-primary-500"
            fill="currentColor"
          />
        ))}
      </svg>
    </div>
  );
}