import { useEffect, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { resetAllTransientUi } from '@/lib/transientUiReset';
import { clearClientCaches } from '@/lib/clientCacheReset';

/**
 * ── AUTH SESSION BOUNDARY (Shared UI tek kaynak) ──
 *
 * Authenticated kimliği (kullanıcı id'si) izler ve kimlik DEĞİŞTİĞİNDE
 * tüm global geçici UI overlay'lerini (modal / confirm / bottom sheet / toast)
 * merkezi olarak sıfırlar.
 *
 * Neden gerekli:
 *  - Modal/Confirm/BottomSheet/Toast sağlayıcıları router'ın ÜSTÜNDE mount
 *    olduğu için logout'ta kendiliğinden temizlenmezler; açık bir modal login
 *    ekranına sızar.
 *  - Bu gözlemci, oturum sınırını (login/logout/kullanıcı değişimi)
 *    "modal state geçersiz" sinyaline çevirir. Feature componentlerinin tek
 *    tek logout dinlemesine gerek kalmaz.
 *
 * Davranış:
 *  - Uygulama açılışında (initial identity) reset YAPILMAZ — sadece kaydedilir.
 *    Böylece boot sırasında gereksiz bir sıfırlama tetiklenmez.
 *  - SIGNED_OUT / farklı kullanıcı / aynı kullanıcının yeniden girişi → reset.
 *  - Kullanıcı hiç oturum açmadıysa (login ekranı) reset zaten no-op'tur.
 */
export default function SessionBoundary() {
  const { user, loading } = useAuth();
  const identityRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    // Auth bootstrap tamamlanmadan karar verme (INITIAL_SESSION belirsizken
    // yanlış bir "logout" sinyali üretmemek için).
    if (loading) return;

    const identity: string | null = user?.id ?? null;

    // İlk kez kimlik belirleniyor → yalnızca kaydet, reset ETME.
    if (identityRef.current === undefined) {
      identityRef.current = identity;
      return;
    }

    // Kimlik gerçekten değişti → tüm geçici overlay'leri VE istemci veri
    // cache'ini (SWR / sekme verisi) sıfırla. Böylece önceki kullanıcının
    // bellekteki verisi yeni oturuma SIZMAZ (sunucu taraflı token iptali veya
    // oturum süresi dolmasıyla oluşan SIGNED_OUT dahil).
    if (identityRef.current !== identity) {
      identityRef.current = identity;
      resetAllTransientUi();
      clearClientCaches();
    }
  }, [user, loading]);

  return null;
}