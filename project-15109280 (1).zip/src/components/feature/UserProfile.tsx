import { useState, useRef, lazy, Suspense } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useClickOutside } from '@/hooks/useDropdown';
import { useModalActions } from '@/hooks/useModal';
import { useBottomSheet } from '@/hooks/useBottomSheet';
import { useAdminProfile } from '@/context/AdminProfileContext';
import { useAuth } from '@/context/AuthContext';
import { useMediaQuery } from '@/hooks/useMediaQuery';
import { Z_LAYERS } from '@/utils/layers';
import Avatar from '@/components/ui/Avatar';
import ModalFallback from '@/components/ui/ModalFallback';

// Profil modalı yalnızca menüden açılınca yüklenir (tembel).
const ProfileModal = lazy(() => import('./ProfileModal'));
import { getPanelFromPath, PANEL_NAV_CONFIG, PANEL_ROLE_LABEL } from './panelNavigation';

export default function UserProfile() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const { profile, fullName } = useAdminProfile();
  const { signOut } = useAuth();
  const { openModal, closeModal } = useModalActions();
  const { openSheet, closeSheet } = useBottomSheet();
  const profileModalIdRef = useRef('');
  const navigate = useNavigate();
  const location = useLocation();
  const panel = getPanelFromPath(location.pathname);
  const ayarlarPath = PANEL_NAV_CONFIG[panel].find((i) => i.label === 'Ayarlar')?.path ?? '/ayarlar';

  const isMobile = useMediaQuery('(max-width: 1023px)');

  useClickOutside(ref, () => setOpen(false), open);

  const handleAyarlar = () => {
    setOpen(false);
    closeSheet();
    navigate(ayarlarPath);
  };

  const handleOpenProfile = () => {
    setOpen(false);
    closeSheet();
    const id = openModal({
      title: 'Profil Ayarları',
      description: 'Kişisel bilgilerinizi ve şifrenizi yönetin.',
      width: 520,
      minWidth: 400,
      minHeight: 400,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <Suspense fallback={<ModalFallback />}>
          <ProfileModal onClose={() => closeModal(id)} modalIdRef={profileModalIdRef} />
        </Suspense>
      ),
      footerActions: null,
    });
    profileModalIdRef.current = id;
  };

  return (
    <div className="relative" ref={ref}>
      <button
        aria-haspopup="menu"
        aria-expanded={!isMobile ? open : undefined}
        aria-label={`${fullName} profil menüsü`}
        onClick={() => {
          if (isMobile) {
            openSheet({
              title: '',
              showClose: false,
              content: (
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-3 px-1">
                    <Avatar src={profile.avatar || undefined} name={fullName} size="lg" />
                    <div className="min-w-0">
                      <p className="text-base font-semibold text-foreground-950">{fullName}</p>
                      <p className="text-sm text-foreground-500 truncate">{profile.email}</p>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <button
                      onClick={() => {
                        closeSheet();
                        handleOpenProfile();
                      }}
                      className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer"
                    >
                      <i className="ri-user-line text-xl text-foreground-400" />
                      <span className="text-sm font-medium">Profilim</span>
                      <i className="ri-arrow-right-s-line ml-auto text-foreground-400" />
                    </button>
                    <button onClick={handleAyarlar} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer">
                      <i className="ri-settings-3-line text-xl text-foreground-400" />
                      <span className="text-sm font-medium">Ayarlar</span>
                      <i className="ri-arrow-right-s-line ml-auto text-foreground-400" />
                    </button>
                  </div>
                  <div className="pt-2 border-t isg-divider">
                    <button onClick={() => { closeSheet(); signOut(); }} className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left text-danger-600 hover:bg-danger-50 transition-colors cursor-pointer">
                      <i className="ri-logout-box-r-line text-xl" />
                      <span className="text-sm font-medium">Çıkış Yap</span>
                    </button>
                  </div>
                </div>
              ),
            });
          } else {
            setOpen((p) => !p);
          }
        }}
        className="flex items-center gap-2 pl-2 pr-1 py-1 rounded-lg hover:bg-background-200 transition-colors cursor-pointer"
      >
        <Avatar src={profile.avatar || undefined} name={fullName} size="sm" />
        <div className="hidden md:block text-left">
          <p className="text-xs font-medium text-foreground-800 leading-tight">{fullName}</p>
          <p className="text-[10px] text-foreground-500 leading-tight">{PANEL_ROLE_LABEL[panel]}</p>
        </div>
        <i className="ri-arrow-down-s-line text-xs text-foreground-400 hidden md:block" />
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-2 w-56 max-w-[calc(100vw-2rem)] isg-popover overflow-hidden" style={{ zIndex: Z_LAYERS.topbarDropdown }}>
          <div className="px-4 py-3 border-b isg-divider">
            <p className="text-sm font-medium text-foreground-800">{fullName}</p>
            <p className="text-xs text-foreground-500">{profile.email}</p>
          </div>
          <div className="py-1">
            <button
              onClick={handleOpenProfile}
              className="w-full flex items-center gap-2 px-4 py-2 text-sm text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors text-left cursor-pointer"
            >
              <i className="ri-user-line text-foreground-400" />
              Profilim
            </button>
            <button onClick={handleAyarlar} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors text-left cursor-pointer">
              <i className="ri-settings-3-line text-foreground-400" />
              Ayarlar
            </button>
          </div>
          <div className="border-t isg-divider py-1">
            <button onClick={() => { setOpen(false); signOut(); }} className="w-full flex items-center gap-2 px-4 py-2 text-sm text-danger-600 hover:bg-danger-50 dark:hover:bg-danger-50/10 transition-colors text-left cursor-pointer">
              <i className="ri-logout-box-r-line" />
              Çıkış Yap
            </button>
          </div>
        </div>
      )}
    </div>
  );
}