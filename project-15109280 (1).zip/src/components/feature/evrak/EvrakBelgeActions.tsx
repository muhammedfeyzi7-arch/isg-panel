import { useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import { useToastActions } from '@/hooks/useToast';
import { assignEvrakKlasor, updateEvrak, friendlyEvrakError, type FirmaKlasor } from '@/lib/evrakService';

/** Belge önizleme → "Klasör Değiştir" formu. Belgeyi var olan bir klasöre taşır/kaldırır. */
export function KlasorDegistirForm({
  evrakId,
  currentKlasorId,
  klasorler,
  onClose,
  onSaved,
}: {
  evrakId: string;
  currentKlasorId: string | null;
  klasorler: FirmaKlasor[];
  onClose: () => void;
  onSaved?: () => void;
}) {
  const { addToast } = useToastActions();
  const [value, setValue] = useState(currentKlasorId ?? '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const options = [
    { value: '', label: 'Klasörsüz' },
    ...klasorler.map((k) => ({ value: k.id, label: k.ad })),
  ];

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    try {
      await assignEvrakKlasor(evrakId, value || null);
      addToast({ title: 'Klasör güncellendi', message: 'Belge yeni klasörüne taşındı.', type: 'success' });
      onSaved?.();
      onClose();
    } catch (e) {
      setError(friendlyEvrakError(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <Select
        label="Klasör"
        options={options}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        placeholder="Klasör seçin"
        searchable
        autoFocus
      />
      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={saving}>
          Vazgeç
        </Button>
        <Button variant="primary" size="sm" leftIcon={<i className="ri-check-line" />} onClick={handleSave} isLoading={saving}>
          Kaydet
        </Button>
      </div>
    </div>
  );
}

/** Belge önizleme → "Bilgileri Düzenle" formu. Belge adı + açıklamayı günceller. */
export function BilgileriDuzenleForm({
  evrakId,
  initialTitle,
  initialDescription,
  onClose,
  onSaved,
}: {
  evrakId: string;
  initialTitle: string;
  initialDescription: string | null;
  onClose: () => void;
  onSaved?: () => void;
}) {
  const { addToast } = useToastActions();
  const [title, setTitle] = useState(initialTitle);
  const [description, setDescription] = useState(initialDescription ?? '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async () => {
    if (!title.trim()) {
      setError('Belge adı zorunludur.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await updateEvrak(evrakId, { title: title.trim(), description: description.trim() || null });
      addToast({ title: 'Bilgiler güncellendi', message: 'Belge bilgileri kaydedildi.', type: 'success' });
      onSaved?.();
      onClose();
    } catch (e) {
      setError(friendlyEvrakError(e));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <Input label="Belge Adı" required value={title} onChange={(e) => setTitle(e.target.value)} autoFocus />
      <Textarea
        label="Açıklama"
        value={description}
        onChange={(e) => setDescription(e.target.value.slice(0, 500))}
        rows={3}
        placeholder="Belge hakkında kısa açıklama (isteğe bağlı)"
      />
      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={saving}>
          Vazgeç
        </Button>
        <Button variant="primary" size="sm" leftIcon={<i className="ri-check-line" />} onClick={handleSave} isLoading={saving}>
          Kaydet
        </Button>
      </div>
    </div>
  );
}