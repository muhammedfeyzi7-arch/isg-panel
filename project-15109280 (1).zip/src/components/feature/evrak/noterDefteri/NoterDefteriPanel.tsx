import { useCallback, useMemo, useRef, useState } from 'react';
import useSWR from 'swr';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Select from '@/components/ui/Select';
import Input from '@/components/ui/Input';
import Search from '@/components/ui/Search';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import Pagination from '@/components/ui/Pagination';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import Loading from '@/components/ui/Loading';
import ContextMenu from '@/components/ui/ContextMenu';
import IconButton from '@/components/ui/IconButton';
import SharedListCard, { ListCardBadge } from '@/components/ui/SharedListCard';
import DatePicker from '@/components/ui/DatePicker';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import {
  type NoterKayit,
  type NoterKayitDurum,
  NOTER_DURUM_LABEL,
  fetchNoterDefteri,
  fetchNoterKayitlariPage,
  fetchFirmaPersonelOptions,
  noterGorunenDurum,
  arsivleNoterKayit,
  deleteNoterKayit,
  kopyalaNoterKayit,
  friendlyNoterError,
} from '@/lib/noterDefteriService';
import { durumLabel, durumVariant, formatTrDate } from './noterDefteriUi';
import DefterBilgileriModal from './DefterBilgileriModal';
import NoterKayitModal from './NoterKayitModal';
import NoterKayitDetailModal from './NoterKayitDetailModal';

interface NoterDefteriPanelProps {
  firmaId: string;
  role: 'uzman' | 'firma';
}

const DURUM_FILTRE_OPTIONS = [
  { value: '', label: 'Tüm Durumlar' },
  ...(['taslak', 'acik', 'isverene_bildirildi', 'kapatildi'] as NoterKayitDurum[]).map((d) => ({
    value: d,
    label: NOTER_DURUM_LABEL[d],
  })),
];

/**
 * Uzman > Evraklar > Firma Dosyaları > Noter Defteri çalışma alanı.
 *
 * Onaylı defter (noter defteri) üzerindeki TESPİT ve ÖNERİ kayıtlarını yönetir.
 * Fiziksel nüsha takibi bilgi amaçlıdır; dijital kayıt tektir ve onaylı defterin
 * yerine geçmez. Mevcut Evraklar shell'i + global Modal / Table / FileUpload
 * altyapısı kullanılır; sayfaya özel motur yazılmaz.
 */
export default function NoterDefteriPanel({ firmaId, role }: NoterDefteriPanelProps) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const defterModalRef = useRef('');
  const kayitModalRef = useRef('');
  const detailModalRef = useRef('');

  const canEdit = role === 'uzman';

  const [durumFilter, setDurumFilter] = useState('');
  const [tespitEdenFilter, setTespitEdenFilter] = useState('');
  const [sayfaNoFilter, setSayfaNoFilter] = useState('');
  const [tarihBas, setTarihBas] = useState('');
  const [tarihBit, setTarihBit] = useState('');
  const [search, setSearch] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const { data: defter, mutate: mutateDefter } = useSWR(
    ['noter-defteri', firmaId],
    () => fetchNoterDefteri(firmaId),
  );

  const { data: personelOptions = [] } = useSWR(
    ['noter-personel', firmaId],
    () => fetchFirmaPersonelOptions(firmaId),
  );
  const personelMap = useMemo(() => {
    const m: Record<string, string> = {};
    for (const p of personelOptions) m[p.value] = p.label;
    return m;
  }, [personelOptions]);

  const query = useMemo(
    () => ({
      search: search || undefined,
      durum: (durumFilter as NoterKayitDurum | '') || '',
      tespitEden: tespitEdenFilter || undefined,
      sayfaNo: sayfaNoFilter || undefined,
      tarihBaslangic: tarihBas || undefined,
      tarihBitis: tarihBit || undefined,
      page,
      pageSize,
    }),
    [search, durumFilter, tespitEdenFilter, sayfaNoFilter, tarihBas, tarihBit, page, pageSize],
  );

  const queryKey = useMemo(() => JSON.stringify(query), [query]);
  const { data: pageData, error, isLoading, mutate } = useSWR(
    ['noter-kayitlari', firmaId, queryKey],
    () => fetchNoterKayitlariPage(firmaId, query),
  );
  const rows = pageData?.data ?? [];
  const count = pageData?.count ?? 0;
  const errorMsg = error instanceof Error ? error.message : null;

  const refresh = useCallback(() => {
    void mutate();
  }, [mutate]);

  const resetPage = () => setPage(1);

  // ---- Defter bilgileri modalı ----
  const openDefterModal = useCallback(() => {
    const id = openModal({
      title: defter ? 'Defter Bilgilerini Düzenle' : 'Defter Bilgilerini Ekle',
      description: 'Onaylı defterin temel bilgilerini girin.',
      width: 620,
      minWidth: 420,
      minHeight: 420,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <DefterBilgileriModal
          firmaId={firmaId}
          defter={defter ?? null}
          onClose={() => closeModal(defterModalRef.current)}
          onSaved={() => { void mutateDefter(); }}
        />
      ),
    });
    defterModalRef.current = id;
  }, [openModal, closeModal, firmaId, defter, mutateDefter]);

  // ---- Yeni / düzenle kayıt modalı ----
  const openKayitModal = useCallback(
    (kayit?: NoterKayit) => {
      const id = openModal({
        title: kayit ? `Kaydı Düzenle — Sıra No ${kayit.siraNo ?? '—'}` : 'Yeni Tespit / Öneri Kaydı',
        description: 'Onaylı deftere işlenecek tespit ve öneri kaydını oluşturun.',
        variant: 'large',
        width: 1120,
        height: 900,
        minWidth: 720,
        minHeight: 620,
        bodyLayout: 'fill',
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        maximizable: true,
        content: (
          <NoterKayitModal
            firmaId={firmaId}
            defter={defter ?? null}
            kayit={kayit ?? null}
            onClose={() => closeModal(kayitModalRef.current)}
            onSaved={refresh}
          />
        ),
      });
      kayitModalRef.current = id;
    },
    [openModal, closeModal, firmaId, defter, refresh],
  );

  // ---- Detay modalı ----
  const openDetail = useCallback(
    (kayit: NoterKayit) => {
      const durum = noterGorunenDurum(kayit);
      const id = openModal({
        title: 'Kayıt Detayı',
        description: kayit.defterNo ? `Defter No: ${kayit.defterNo} • Sıra No: ${kayit.siraNo ?? '—'}` : undefined,
        headerExtra: <Badge variant={durumVariant(durum)}>{durumLabel(durum)}</Badge>,
        variant: 'detail',
        width: 980,
        height: 800,
        minWidth: 720,
        minHeight: 620,
        bodyLayout: 'fill',
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        maximizable: true,
        content: (
          <NoterKayitDetailModal
            kayit={kayit}
            personelAd={kayit.ilgiliPersonelId ? personelMap[kayit.ilgiliPersonelId] ?? null : null}
            onClose={() => closeModal(detailModalRef.current)}
            onChanged={refresh}
            onEdit={(k) => {
              closeModal(detailModalRef.current);
              openKayitModal(k);
            }}
          />
        ),
      });
      detailModalRef.current = id;
    },
    [openModal, closeModal, personelMap, refresh, openKayitModal],
  );

  // ---- Satır işlemleri ----
  const handleKopyala = useCallback(
    (kayit: NoterKayit) => {
      kopyalaNoterKayit(kayit)
        .then(() => {
          addToast({ title: 'Kopyalandı', message: 'Kayıt taslak olarak kopyalandı.', type: 'success' });
          refresh();
        })
        .catch((e) => addToast({ title: 'Kopyalanamadı', message: friendlyNoterError(e), type: 'error' }));
    },
    [addToast, refresh],
  );

  const handleArsivle = useCallback(
    (kayit: NoterKayit) => {
      confirm({
        title: 'Kaydı arşivle',
        message: 'Kayıt listeden gizlenecek, silinmeyecek. Geçmişi korunur.',
        variant: 'warning',
        confirmText: 'Evet, Arşivle',
        cancelText: 'Vazgeç',
        onConfirm: () => {
          arsivleNoterKayit(kayit.id)
            .then(() => {
              addToast({ title: 'Arşivlendi', message: 'Kayıt arşivlendi.', type: 'success' });
              refresh();
            })
            .catch((e) => addToast({ title: 'Arşivlenemedi', message: friendlyNoterError(e), type: 'error' }));
        },
      });
    },
    [confirm, addToast, refresh],
  );

  const handleSil = useCallback(
    (kayit: NoterKayit) => {
      confirm({
        title: 'Kaydı sil',
        message: 'Bu kayıt kalıcı olarak silinecek. Bu işlem geri alınamaz.',
        variant: 'danger',
        confirmText: 'Evet, Sil',
        cancelText: 'Vazgeç',
        onConfirm: () => {
          deleteNoterKayit(kayit.id)
            .then(() => {
              addToast({ title: 'Silindi', message: 'Kayıt silindi.', type: 'success' });
              refresh();
            })
            .catch((e) => addToast({ title: 'Silinemedi', message: friendlyNoterError(e), type: 'error' }));
        },
      });
    },
    [confirm, addToast, refresh],
  );

  const columns: TableColumn<NoterKayit>[] = [
    { key: 'siraNo', header: 'Sıra No', width: '70px', render: (r) => <span className="text-sm font-medium text-foreground-700 tabular-nums">{r.siraNo ?? '—'}</span> },
    { key: 'sayfaNo', header: 'Sayfa No', width: '80px', render: (r) => <span className="text-sm text-foreground-600 tabular-nums">{r.sayfaNo ?? '—'}</span> },
    { key: 'tespitTarihi', header: 'Tespit Tarihi', render: (r) => <span className="text-sm text-foreground-600">{formatTrDate(r.tespitTarihi)}</span> },
    { key: 'tespitSaati', header: 'Tespit Saati', render: (r) => <span className="text-sm text-foreground-600">{r.tespitSaati || '—'}</span> },
    {
      key: 'konu',
      header: 'Tespit / Öneri Konusu',
      render: (r) => (
        <div className="min-w-0 max-w-[280px]">
          <p className="text-sm font-medium text-foreground-800 truncate">{r.konu ?? '—'}</p>
        </div>
      ),
    },
    { key: 'tespitEden', header: 'Tespit Eden', render: (r) => <span className="text-sm text-foreground-600 truncate">{r.tespitEden ?? '—'}</span> },
    {
      key: 'ilgiliPersonel',
      header: 'İlgili Personel',
      render: (r) => (
        <span className="text-sm text-foreground-600 truncate">
          {r.ilgiliPersonelId ? personelMap[r.ilgiliPersonelId] ?? 'Personel' : '—'}
        </span>
      ),
    },
    { key: 'termin', header: 'Termin', render: (r) => <span className="text-sm text-foreground-600">{formatTrDate(r.termin)}</span> },
    {
      key: 'durum',
      header: 'Durum',
      render: (r) => {
        const d = noterGorunenDurum(r);
        return <Badge variant={durumVariant(d)}>{durumLabel(d)}</Badge>;
      },
    },
  ];

  const rowActions = (r: NoterKayit) => (
    <>
      <IconButton icon={<i className="ri-eye-line" />} variant="ghost" size="sm" label="Görüntüle" onClick={() => openDetail(r)} />
      {canEdit && (
        <IconButton icon={<i className="ri-edit-line" />} variant="ghost" size="sm" label="Düzenle" onClick={() => openKayitModal(r)} />
      )}
      <ContextMenu
        triggerIcon="ri-more-2-fill"
        items={[
          { label: 'Görüntüle', icon: 'ri-eye-line', onClick: () => openDetail(r) },
          ...(canEdit ? [{ label: 'Düzenle', icon: 'ri-edit-line', onClick: () => openKayitModal(r) }] : []),
          { label: 'Kopyala', icon: 'ri-file-copy-line', onClick: () => handleKopyala(r) },
          ...(canEdit
            ? [
                { label: 'Arşivle', icon: 'ri-archive-line', onClick: () => handleArsivle(r) },
                { label: 'Sil', icon: 'ri-delete-bin-line', variant: 'danger' as const, onClick: () => handleSil(r) },
              ]
            : []),
        ]}
      />
    </>
  );

  const mobileCard = (r: NoterKayit) => {
    const d = noterGorunenDurum(r);
    return (
      <SharedListCard
        recordNo={`#SIRA-${r.siraNo ?? '—'} · SAYFA ${r.sayfaNo ?? '—'}`}
        icon="ri-file-warning-line"
        iconBg="bg-primary-50 dark:bg-primary-500/20"
        iconColor="text-primary-600 dark:text-primary-400"
        title={r.konu ?? 'Tespit / Öneri'}
        description={r.tespitEden ?? undefined}
        badges={[<ListCardBadge key="durum" variant={durumVariant(d)}>{durumLabel(d)}</ListCardBadge>]}
        metadata={[
          { label: 'Tarih', value: formatTrDate(r.tespitTarihi) },
          { label: 'Termin', value: formatTrDate(r.termin) },
        ]}
        onClick={() => openDetail(r)}
      />
    );
  };

  const totalPages = Math.max(1, Math.ceil(count / pageSize));

  const yil = defter?.onayTarihi ? defter.onayTarihi.slice(0, 4) : null;
  const sayfaAraligi =
    defter?.sayfaBaslangic != null || defter?.sayfaBitis != null
      ? `${defter?.sayfaBaslangic ?? '—'}–${defter?.sayfaBitis ?? '—'}`
      : '—';

  return (
    <div className="flex flex-col gap-3">
      {/* Başlık */}
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h2 className="text-lg font-semibold text-foreground-950">Noter Defteri</h2>
          <p className="text-sm text-foreground-500 mt-0.5">Onaylı defter üzerindeki tespit ve öneri kayıtlarını yönetin.</p>
        </div>
        {canEdit && (
          <Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} className="whitespace-nowrap" onClick={() => openKayitModal()} disabled={!defter}>
            Yeni Tespit / Öneri Kaydı
          </Button>
        )}
      </div>

      {/* Defter Bilgileri Kartı */}
      {!defter ? (
        <div className="rounded-lg border border-dashed border-background-300 dark:border-background-400/40 bg-background-50 dark:bg-background-100/40 px-4 py-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <span className="w-9 h-9 rounded-md bg-secondary-100 text-secondary-600 dark:bg-secondary-500/20 dark:text-secondary-300 flex items-center justify-center flex-shrink-0">
              <i className="ri-booklet-line" />
            </span>
            <p className="text-sm text-foreground-600">Bu firma için onaylı defter bilgileri henüz tanımlanmadı.</p>
          </div>
          {canEdit && (
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-add-line" />} className="whitespace-nowrap" onClick={openDefterModal}>
              Defter Bilgilerini Ekle
            </Button>
          )}
        </div>
      ) : (
        <div className="rounded-lg border border-background-300/40 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 px-4 py-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="w-9 h-9 rounded-md bg-secondary-100 text-secondary-600 dark:bg-secondary-500/20 dark:text-secondary-300 flex items-center justify-center flex-shrink-0">
                <i className="ri-booklet-fill" />
              </span>
              <div className="min-w-0">
                <p className="text-sm font-semibold text-foreground-900">
                  Defter No: {defter.defterNo ?? '—'}
                  {yil && <span className="text-foreground-400 font-normal"> · {yil}</span>}
                </p>
                <p className="text-xs text-foreground-500 truncate">
                  {defter.onaylayanKurum ?? 'Onaylayan kurum girilmedi'}
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-x-5 gap-y-1 text-xs">
              <span className="flex flex-col">
                <span className="text-foreground-400">Onay Tarihi</span>
                <span className="text-foreground-800 font-medium">{formatTrDate(defter.onayTarihi)}</span>
              </span>
              <span className="flex flex-col">
                <span className="text-foreground-400">Sayfa Aralığı</span>
                <span className="text-foreground-800 font-medium">{sayfaAraligi}</span>
              </span>
              {canEdit && (
                <Button variant="ghost" size="sm" leftIcon={<i className="ri-edit-line" />} className="whitespace-nowrap" onClick={openDefterModal}>
                  Düzenle
                </Button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Arama + Filtre */}
      <div className="rounded-lg border border-background-300/40 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-3 flex flex-col gap-2.5">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex-1 min-w-[220px]">
            <Search
              placeholder="Konu, tespit eden, sayfa no veya açıklama ara..."
              value={search}
              onSearch={(v) => { setSearch(v); resetPage(); }}
              size="sm"
              debounceMs={400}
            />
          </div>
          <Select
            size="sm"
            options={DURUM_FILTRE_OPTIONS}
            value={durumFilter}
            onChange={(e) => { setDurumFilter(e.target.value); resetPage(); }}
            containerClassName="min-w-[160px]"
          />
          <Button
            variant="ghost"
            size="sm"
            leftIcon={<i className="ri-filter-3-line" />}
            className="whitespace-nowrap"
            onClick={() => setShowFilters((v) => !v)}
          >
            {showFilters ? 'Filtreleri Gizle' : 'Filtreler'}
          </Button>
        </div>

        {showFilters && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-2 border-t border-background-300/30 dark:border-background-400/20">
            <DatePicker label="Başlangıç Tarihi" value={tarihBas} onChange={(e) => { setTarihBas(e.target.value); resetPage(); }} />
            <DatePicker label="Bitiş Tarihi" value={tarihBit} onChange={(e) => { setTarihBit(e.target.value); resetPage(); }} />
            <Input label="Tespit Eden" value={tespitEdenFilter} onChange={(e) => { setTespitEdenFilter(e.target.value); resetPage(); }} placeholder="Ad Soyad" />
            <Input label="Sayfa No" type="number" value={sayfaNoFilter} onChange={(e) => { setSayfaNoFilter(e.target.value); resetPage(); }} placeholder="Örn. 12" />
          </div>
        )}
      </div>

      {/* Kayıt Listesi */}
      <div className="rounded-lg border border-background-300/40 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-3">
        {isLoading ? (
          <div className="flex justify-center py-14">
            <Loading size="lg" text="Kayıtlar yükleniyor..." />
          </div>
        ) : errorMsg ? (
          <ErrorState message={errorMsg} onRetry={() => mutate()} />
        ) : rows.length === 0 ? (
          <EmptyState
            icon="ri-file-list-3-line"
            title="Henüz tespit veya öneri kaydı bulunmuyor."
            description={
              defter
                ? 'Onaylı defterinizdeki ilk tespit ve öneri kaydını oluşturun.'
                : 'Önce onaylı defter bilgilerini tanımlayın.'
            }
            action={
              canEdit
                ? defter
                  ? { label: 'Yeni Tespit / Öneri Kaydı', onClick: () => openKayitModal(), icon: 'ri-add-line' }
                  : { label: 'Defter Bilgilerini Ekle', onClick: openDefterModal, icon: 'ri-add-line' }
                : undefined
            }
          />
        ) : (
          <>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-foreground-500">
                Toplam <span className="font-semibold text-foreground-800">{count}</span> kayıt
              </p>
            </div>
            <div className="overflow-x-auto">
              <Table
                data={rows}
                columns={columns}
                keyExtractor={(r) => r.id}
                rowActions={rowActions}
                onRowClick={(r) => openDetail(r)}
                mobileCardRenderer={mobileCard}
              />
            </div>
            <div className="mt-3 pt-3 border-t isg-divider">
              <Pagination
                currentPage={page}
                totalPages={totalPages}
                pageSize={pageSize}
                totalItems={count}
                onPageChange={setPage}
                onPageSizeChange={(size) => { setPageSize(size); setPage(1); }}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
}