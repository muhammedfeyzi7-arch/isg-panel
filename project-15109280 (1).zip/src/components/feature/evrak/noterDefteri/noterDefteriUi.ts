import type { NoterEkTuru, NoterGorunenDurum } from '@/lib/noterDefteriService';
import { NOTER_DURUM_LABEL, NOTER_DURUM_VARIANT } from '@/lib/noterDefteriService';
import { DOSYA_TUR_IKON, ICON_REGISTRY, dosyaTuruBul } from '@/lib/icons/iconRegistry';

/** ISO (yyyy-mm-dd veya timestamp) → dd.MM.yyyy. Boş değerde '—'. */
export function formatTrDate(iso?: string | null): string {
  if (!iso) return '—';
  const d = iso.length >= 10 ? iso.slice(0, 10) : iso;
  const [y, m, day] = d.split('-');
  if (!y || !m || !day) return iso;
  return `${day}.${m}.${y}`;
}

/** ISO timestamp → dd.MM.yyyy HH:mm. */
export function formatTrDateTime(iso?: string | null): string {
  if (!iso) return '—';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return iso;
  const day = `${dt.getDate()}`.padStart(2, '0');
  const m = `${dt.getMonth() + 1}`.padStart(2, '0');
  const hh = `${dt.getHours()}`.padStart(2, '0');
  const mm = `${dt.getMinutes()}`.padStart(2, '0');
  return `${day}.${m}.${dt.getFullYear()} ${hh}:${mm}`;
}

export function durumLabel(durum: NoterGorunenDurum): string {
  return NOTER_DURUM_LABEL[durum] ?? durum;
}

export function durumVariant(durum: NoterGorunenDurum) {
  return NOTER_DURUM_VARIANT[durum] ?? 'default';
}

/** Ek türü / MIME → MERKEZÎ dosya-formatı ikon sınıfı (tek kaynak). */
export function ekIkon(ekTuru: NoterEkTuru, mime?: string | null): string {
  if (ekTuru === 'fotograf') return 'ri-image-2-line';
  if (ekTuru === 'video') return 'ri-video-line';
  const m = (mime ?? '').toLowerCase();
  if (m.startsWith('image/')) return 'ri-image-2-line';
  const tur = dosyaTuruBul(mime, null);
  return ICON_REGISTRY[DOSYA_TUR_IKON[tur]].className;
}

/** Dosya boyutunu okunur biçime çevirir. */
export function formatBoyut(bytes?: number | null): string {
  if (!bytes || bytes <= 0) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/** MIME / dosya adına göre uygun ek türünü tahmin eder. */
export function tahminEkTuru(mime: string | null | undefined, adi: string): NoterEkTuru {
  const m = (mime ?? '').toLowerCase();
  const lower = adi.toLowerCase();
  if (m.startsWith('image/') || /\.(png|jpe?g|webp|gif|bmp)$/.test(lower)) return 'fotograf';
  if (m.startsWith('video/') || /\.(mp4|mov|avi|mkv|webm)$/.test(lower)) return 'video';
  return 'belge';
}