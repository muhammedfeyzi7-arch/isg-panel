import { useCallback, useState } from 'react';
import Button from '@/components/ui/Button';
import FileUpload from '@/components/ui/FileUpload';
import type { UploadFile } from '@/components/ui/FileUpload';
import { useToastActions } from '@/hooks/useToast';
import { uploadNoterEk, friendlyNoterError } from '@/lib/noterDefteriService';
import { tahminEkTuru } from './noterDefteriUi';

const EK_ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.webp';

interface NoterEkEkleModalProps {
  kayitId: string;
  onClose: () => void;
  onAdded: () => void;
}

/**
 * Kayıtlı bir Tespit/Öneri kaydına ek dosya yükleme (detay modalından "Ek Ekle").
 * Mevcut global FileUpload motoru + mevcut noterDefteriService kullanılır;
 * yeni bir yükleme motoru oluşturulmaz. Global modal motoru içinde çalışır.
 */
export default function NoterEkEkleModal({ kayitId, onClose, onAdded }: NoterEkEkleModalProps) {
  const { addToast } = useToastActions();
  const [files, setFiles] = useState<UploadFile[]>([]);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = useCallback(async () => {
    const raws = files.filter((f) => !!f.raw);
    if (raws.length === 0) {
      setError('En az bir dosya seçin.');
      return;
    }
    setError(null);
    setSaving(true);
    try {
      for (const uf of raws) {
        await uploadNoterEk(kayitId, {
          ekTuru: tahminEkTuru(uf.mime, uf.name),
          baslik: uf.name,
          file: uf.raw as File,
        });
      }
      addToast({ title: 'Ek eklendi', message: `${raws.length} dosya kayda eklendi.`, type: 'success' });
      onAdded();
      onClose();
    } catch (e) {
      setError(friendlyNoterError(e));
      setSaving(false);
    }
  }, [files, kayitId, addToast, onAdded, onClose]);

  return (
    <div className="flex flex-col gap-3">
      <FileUpload
        accept={EK_ACCEPT}
        multiple
        maxSize={15 * 1024 * 1024}
        files={files}
        onChange={setFiles}
        heading="Dosyaları sürükleyip bırakın veya dosya seçin"
        browseLabel="dosya seçin"
      />

      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      <div className="flex items-center justify-end gap-2">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={saving} className="whitespace-nowrap">
          İptal
        </Button>
        <Button variant="primary" size="sm" leftIcon={<i className="ri-upload-2-line" />} className="whitespace-nowrap" onClick={handleSave} isLoading={saving} disabled={saving}>
          Yükle
        </Button>
      </div>
    </div>
  );
}