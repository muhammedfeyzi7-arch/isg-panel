import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import {
  type NoterKayit,
  type NoterEk,
  NUSHA_DURUM_LABEL,
  fetchNoterEkleri,
  getNoterEkUrl,
  deleteNoterEk,
  deleteNoterKayit,
  updateNoterKayit,
  noterGorunenDurum,
  friendlyNoterError,
} from '@/lib/noterDefteriService';
import { durumLabel, durumVariant, ekIkon, formatBoyut, formatTrDate, formatTrDateTime } from './noterDefteriUi';
import NoterEkEkleModal from './NoterEkEkleModal';
import { sanitizeHtml } from '@/lib/sanitizeHtml';

interface NoterKayitDetailModalProps {
  kayit: NoterKayit;
  personelAd?: string | null;
  onClose: () => void;
  onChanged: () => void;
  onEdit: (kayit: NoterKayit) => void;
}

/** Kompakt bölüm kartı (detay görünümü). */
function DCard({ icon, title, action, children, className = '' }: { icon: string; title: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`flex flex-col rounded-lg border border-background-300/50 dark:border-background-400/30 bg-background-50 dark:bg-background-200/40 overflow-hidden ${className}`}>
      <header className="flex items-center gap-2 px-3 py-2 border-b border-background-300/30 dark:border-background-400/25 bg-background-100 dark:bg-background-200/60 flex-shrink-0">
        <span className="w-6 h-6 rounded-md bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
          <i className={`${icon} text-[13px]`} />
        </span>
        <h4 className="text-xs font-semibold text-foreground-900 leading-tight flex-1 truncate">{title}</h4>
        {action && <div className="flex-shrink-0">{action}</div>}
      </header>
      <div className="p-3 space-y-3">{children}</div>
    </section>
  );
}

/** Etiket + değer kutusu. */
function DField({ label, value }: { label: string; value: ReactNode }) {
  const empty = value == null || value === '' || value === '—';
  return (
    <div className="min-w-0">
      <p className="text-[11px] text-foreground-500 mb-1">{label}</p>
      <div className="rounded-md border border-background-300/40 dark:border-background-400/25 bg-background-100/60 dark:bg-background-300/20 px-2.5 py-1.5 text-sm text-foreground-800 break-words">
        {empty ? <span className="text-foreground-500">—</span> : value}
      </div>
    </div>
  );
}

/** Zengin metin değeri (kutu içinde). */
function DRich({ label, html, empty }: { label: string; html: string | null; empty: string }) {
  const hasContent = !!html && html.replace(/<[^>]*>/g, '').trim() !== '';
  return (
    <div>
      <p className="text-[11px] text-foreground-500 mb-1">{label}</p>
      <div className="rounded-md border border-background-300/40 dark:border-background-400/25 bg-background-100/60 dark:bg-background-300/20 px-2.5 py-2 text-sm text-foreground-700 break-words">
        {hasContent ? (
          // GUV-05: kayıtlı zengin metin her gösterimde sanitize edilir (defense in depth).
          <div className="isg-rte leading-relaxed" dangerouslySetInnerHTML={{ __html: sanitizeHtml(html as string, 'rich') }} />
        ) : (
          <span className="text-foreground-500">{empty}</span>
        )}
      </div>
    </div>
  );
}

function NushaKart({ label, alt, durum }: { label: string; alt: string; durum: string }) {
  return (
    <div className="rounded-lg border border-background-300/50 dark:border-background-400/30 bg-background-50 dark:bg-background-200/40 p-2.5">
      <p className="text-xs font-semibold text-foreground-800 leading-tight">{label}</p>
      <p className="text-[11px] text-foreground-500 mt-0.5 mb-2">{alt}</p>
      <div className="space-y-1">
        {(['teslim', 'takipte'] as const).map((d) => {
          const active = durum === d;
          return (
            <div key={d} className="flex items-center gap-1.5">
              <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center flex-shrink-0 ${active ? 'border-primary-500' : 'border-background-400 dark:border-background-400/70'}`}>
                {active && <span className="w-1.5 h-1.5 rounded-full bg-primary-500" />}
              </span>
              <span className={`text-[11px] ${active ? 'text-foreground-900 font-medium' : 'text-foreground-500'}`}>
                {d === 'teslim' ? 'Teslim Edildi' : 'Takipte'}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/** Kaydedilmiş Tespit/Öneri kaydının detay görünümü (global Detail Modal içinde). */
export default function NoterKayitDetailModal({ kayit, personelAd, onClose, onChanged, onEdit }: NoterKayitDetailModalProps) {
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const { openModal, closeModal } = useModalActions();
  const ekModalRef = useRef('');

  const [ekler, setEkler] = useState<NoterEk[]>([]);
  const [eklerLoading, setEklerLoading] = useState(false);
  const [busy, setBusy] = useState(false);

  const loadEkler = useCallback(() => {
    setEklerLoading(true);
    fetchNoterEkleri(kayit.id)
      .then((list) => setEkler(list))
      .catch(() => setEkler([]))
      .finally(() => setEklerLoading(false));
  }, [kayit.id]);

  useEffect(() => {
    loadEkler();
  }, [loadEkler]);

  const acEk = useCallback(
    async (ek: NoterEk, mode: 'view' | 'download') => {
      try {
        const url = await getNoterEkUrl(ek.id, mode);
        window.open(url, '_blank', 'noopener,noreferrer');
      } catch (e) {
        addToast({ title: 'Dosya açılamadı', message: friendlyNoterError(e), type: 'error' });
      }
    },
    [addToast],
  );

  const silEk = useCallback(
    (ek: NoterEk) => {
      confirm({
        title: 'Eki sil',
        message: 'Bu dosya kalıcı olarak silinecek. Bu işlem geri alınamaz.',
        variant: 'danger',
        confirmText: 'Evet, Sil',
        cancelText: 'Vazgeç',
        onConfirm: () => {
          deleteNoterEk(ek.id)
            .then(() => {
              setEkler((prev) => prev.filter((x) => x.id !== ek.id));
              addToast({ title: 'Silindi', message: 'Ek kaldırıldı.', type: 'success' });
            })
            .catch((e) => addToast({ title: 'Silinemedi', message: friendlyNoterError(e), type: 'error' }));
        },
      });
    },
    [confirm, addToast],
  );

  const ekEkle = useCallback(() => {
    const id = openModal({
      title: 'Ek Ekle',
      description: 'Kayda fotoğraf, belge veya diğer dosyaları ekleyin.',
      width: 560,
      minWidth: 420,
      minHeight: 460,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <NoterEkEkleModal
          kayitId={kayit.id}
          onClose={() => closeModal(ekModalRef.current)}
          onAdded={() => {
            loadEkler();
            onChanged();
          }}
        />
      ),
    });
    ekModalRef.current = id;
  }, [openModal, closeModal, kayit.id, loadEkler, onChanged]);

  const sil = useCallback(() => {
    confirm({
      title: 'Kaydı sil',
      message: 'Bu kayıt kalıcı olarak silinecek. Bu işlem geri alınamaz.',
      variant: 'danger',
      confirmText: 'Evet, Sil',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setBusy(true);
        deleteNoterKayit(kayit.id)
          .then(() => {
            addToast({ title: 'Silindi', message: 'Kayıt silindi.', type: 'success' });
            onChanged();
            onClose();
          })
          .catch((e) => addToast({ title: 'Silinemedi', message: friendlyNoterError(e), type: 'error' }))
          .finally(() => setBusy(false));
      },
    });
  }, [confirm, kayit.id, addToast, onChanged, onClose]);

  const toggleFirmVisible = useCallback(() => {
    setBusy(true);
    updateNoterKayit(kayit.id, { firmVisible: !kayit.firmVisible })
      .then(() => {
        addToast({
          title: 'Güncellendi',
          message: !kayit.firmVisible ? 'Firma görünürlüğü açıldı.' : 'Kayıt firma tarafında gizlendi.',
          type: 'success',
        });
        onChanged();
      })
      .catch((e) => addToast({ title: 'Güncellenemedi', message: friendlyNoterError(e), type: 'error' }))
      .finally(() => setBusy(false));
  }, [kayit.id, kayit.firmVisible, addToast, onChanged]);

  const gDurum = noterGorunenDurum(kayit);

  return (
    <div className="flex h-full min-h-0 flex-col gap-3">
      <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane pr-0.5 space-y-3">
        {/* SATIR 1 — Defter Kayıt Bilgileri + Tespit Eden Bilgileri */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          <DCard icon="ri-booklet-line" title="Defter Kayıt Bilgileri">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
              <DField label="Defter No" value={kayit.defterNo ?? '—'} />
              <DField label="Sayfa No" value={kayit.sayfaNo ?? '—'} />
              <DField label="Sıra No" value={kayit.siraNo ?? '—'} />
              <DField label="Tespit Tarihi" value={formatTrDate(kayit.tespitTarihi)} />
              <DField label="Tespit Saati" value={kayit.tespitSaati || '—'} />
            </div>
          </DCard>

          <DCard icon="ri-user-search-line" title="Tespit Eden Bilgileri">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <DField label="Tespit Eden" value={kayit.tespitEden ?? '—'} />
              <DField label="Görevi" value={kayit.tespitEdenGorevi ?? '—'} />
              <DField label="İlgili Personel" value={kayit.ilgiliPersonelId ? personelAd ?? 'Personel' : 'Personel ile ilişkili değil'} />
            </div>
          </DCard>
        </div>

        {/* SATIR 2 — Tespit/Öneri + Gerekli Önlem/Tavsiye */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          <DCard icon="ri-file-warning-line" title="Tespit / Öneri">
            <DField label="Tespit / Öneri Konusu" value={kayit.konu ?? '—'} />
            <DRich label="Tespit ve Öneri Açıklaması" html={kayit.tespitAciklamasi} empty="—" />
          </DCard>

          <DCard icon="ri-shield-check-line" title="Gerekli Önlem / Tavsiye">
            <DRich label="Gerekli Önlem / Tavsiye" html={kayit.gerekliOnlem} empty="—" />
            <DField label="İlgili Mevzuat" value={kayit.ilgiliMevzuat ?? '—'} />
          </DCard>
        </div>

        {/* SATIR 3 — Takip Bilgileri + İşveren Görüşü */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          <DCard icon="ri-calendar-check-line" title="Takip Bilgileri">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <DField label="Önerilen Termin" value={formatTrDate(kayit.termin)} />
              <DField label="Sorumlu" value={kayit.sorumlu ?? '—'} />
              <div className="min-w-0">
                <p className="text-[11px] text-foreground-500 mb-1">Durum</p>
                <div className="rounded-md border border-background-300/40 dark:border-background-400/25 bg-background-100/60 dark:bg-background-300/20 px-2.5 py-1.5">
                  <Badge variant={durumVariant(gDurum)}>{durumLabel(gDurum)}</Badge>
                </div>
              </div>
            </div>
          </DCard>

          <DCard icon="ri-chat-quote-line" title="İşveren Görüşü / Cevabı">
            <DRich label="İşveren Görüşü / Cevabı" html={kayit.isverenGorusu} empty="Henüz işveren görüşü veya cevabı girilmedi." />
          </DCard>
        </div>

        {/* SATIR 4 — Fiziksel Nüsha Takibi + Ekler */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          <DCard icon="ri-stack-line" title="Fiziksel Nüsha Takibi">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <NushaKart label="Asıl Nüsha" alt="İşveren" durum={kayit.asilNushaDurum} />
              <NushaKart label="Uzman Nüshası" alt="İş Güvenliği Uzmanı" durum={kayit.uzmanNushaDurum} />
              <NushaKart label="Hekim Nüshası" alt="İşyeri Hekimi" durum={kayit.hekimNushaDurum} />
            </div>
            <p className="text-[10px] text-foreground-500 leading-snug flex items-start gap-1">
              <i className="ri-information-line mt-px flex-shrink-0" />
              Fiziksel nüsha takibidir; dijital kayıt fiziksel onaylı defterin yerine geçmez.
            </p>
          </DCard>

          <DCard
            icon="ri-attachment-2"
            title="Ekler"
            action={
              <Button variant="secondary" size="sm" leftIcon={<i className="ri-add-line" />} className="whitespace-nowrap" onClick={ekEkle}>
                Ek Ekle
              </Button>
            }
          >
            {eklerLoading ? (
              <p className="text-xs text-foreground-500">Ekler yükleniyor…</p>
            ) : ekler.length === 0 ? (
              <p className="text-sm text-foreground-500">Bu kayda ek dosya eklenmemiş.</p>
            ) : (
              <ul className="space-y-1.5">
                {ekler.map((ek) => (
                  <li key={ek.id} className="flex items-center gap-2.5 rounded-md border border-background-300/40 dark:border-background-400/25 bg-background-50 dark:bg-background-200/40 px-2.5 py-2">
                    <span className="w-9 h-9 rounded-md bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0 overflow-hidden">
                      <i className={`${ekIkon(ek.ekTuru, ek.mimeType)} text-foreground-600 text-lg`} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-foreground-800 truncate">{ek.baslik || ek.dosyaAdi || 'Dosya'}</p>
                      <p className="text-[11px] text-foreground-500 truncate">
                        {formatBoyut(ek.fileSize)} · {formatTrDateTime(ek.createdAt)}
                      </p>
                    </div>
                    <div className="flex items-center gap-0.5 flex-shrink-0">
                      <button type="button" onClick={() => acEk(ek, 'view')} title="Görüntüle" aria-label="Görüntüle" className="w-7 h-7 flex items-center justify-center rounded-md text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer">
                        <i className="ri-eye-line text-sm" />
                      </button>
                      <button type="button" onClick={() => acEk(ek, 'download')} title="İndir" aria-label="İndir" className="w-7 h-7 flex items-center justify-center rounded-md text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer">
                        <i className="ri-download-2-line text-sm" />
                      </button>
                      <button type="button" onClick={() => silEk(ek)} title="Sil" aria-label="Sil" className="w-7 h-7 flex items-center justify-center rounded-md text-danger-600 hover:bg-danger-50 dark:hover:bg-danger-500/15 transition-colors cursor-pointer">
                        <i className="ri-delete-bin-line text-sm" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </DCard>
        </div>
      </div>

      {/* Alt aksiyonlar — firma görünürlüğü + Sil / Düzenle */}
      <div className="flex-shrink-0 flex items-center justify-between gap-2 flex-wrap">
        <button
          type="button"
          onClick={toggleFirmVisible}
          disabled={busy}
          className="flex items-center gap-1.5 text-xs font-medium text-foreground-600 hover:text-foreground-900 cursor-pointer disabled:opacity-50"
        >
          <i className={`${kayit.firmVisible ? 'ri-eye-line text-primary-500' : 'ri-eye-off-line text-foreground-400'} text-base`} />
          {kayit.firmVisible ? 'Firma tutanaklarında gösteriliyor' : 'Firma tutanaklarında gizli'}
        </button>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          <Button variant="ghost" size="sm" leftIcon={<i className="ri-delete-bin-line" />} className="whitespace-nowrap" onClick={sil} disabled={busy}>
            Sil
          </Button>
          <Button variant="primary" size="sm" leftIcon={<i className="ri-edit-line" />} className="whitespace-nowrap" onClick={() => onEdit(kayit)} disabled={busy}>
            Düzenle
          </Button>
        </div>
      </div>
    </div>
  );
}