import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import TimePicker from '@/components/ui/TimePicker';
import FileUpload from '@/components/ui/FileUpload';
import type { UploadFile } from '@/components/ui/FileUpload';
import { useAuth } from '@/context/AuthContext';
import { useToastActions } from '@/hooks/useToast';
import { RichTextEditor } from '@/components/ui/RichTextEditor';
import {
  type NoterDefteri,
  type NoterKayit,
  type NoterKayitDurum,
  type NushaDurum,
  NOTER_SECILEBILIR_DURUMLAR,
  NOTER_DURUM_LABEL,
  createNoterKayit,
  updateNoterKayit,
  fetchNextSiraNo,
  fetchFirmaPersonelOptions,
  fetchNoterEkleri,
  uploadNoterEk,
  deleteNoterEk,
  type NoterPersonelOption,
  type NoterEk,
  friendlyNoterError,
} from '@/lib/noterDefteriService';
import { ekIkon, formatBoyut, tahminEkTuru } from './noterDefteriUi';

interface NoterKayitModalProps {
  firmaId: string;
  defter: NoterDefteri | null;
  kayit?: NoterKayit | null;
  onClose: () => void;
  onSaved: () => void;
}

const EK_ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.jpg,.jpeg,.png,.webp';

/** Kompakt bölüm kartı (modal tek ekrana sığsın diye dar başlık + sıkı padding). */
function Kart({ icon, title, children, className = '' }: { icon: string; title: string; children: ReactNode; className?: string }) {
  return (
    <section className={`flex flex-col rounded-lg border border-background-300/50 dark:border-background-400/30 bg-background-50 dark:bg-background-200/40 overflow-hidden ${className}`}>
      <header className="flex items-center gap-2 px-2.5 py-1.5 border-b border-background-300/30 dark:border-background-400/25 bg-background-100 dark:bg-background-200/60 flex-shrink-0">
        <span className="w-5 h-5 rounded bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
          <i className={`${icon} text-[12px]`} />
        </span>
        <h4 className="text-xs font-semibold text-foreground-900 leading-tight truncate">{title}</h4>
      </header>
      <div className="p-2.5 space-y-2">{children}</div>
    </section>
  );
}

/** Fiziksel nüsha durum seçici (radyo mantığı; dosya yükleme DEĞİL). */
function NushaSecici({ label, alt, value, onChange }: { label: string; alt: string; value: NushaDurum; onChange: (v: NushaDurum) => void }) {
  return (
    <div className="flex items-start gap-2">
      <span className="min-w-[78px] flex-shrink-0">
        <span className="block text-[11px] font-semibold text-foreground-800 leading-tight">{label}</span>
        <span className="block text-[10px] text-foreground-500 mt-0.5 leading-tight">{alt}</span>
      </span>
      <div className="flex items-center gap-2.5 pt-0.5 flex-wrap">
        {(['teslim', 'takipte'] as NushaDurum[]).map((d) => {
          const active = value === d;
          return (
            <button
              key={d}
              type="button"
              onClick={() => onChange(d)}
              className="inline-flex items-center gap-1 text-[11px] font-medium text-foreground-700 hover:text-foreground-900 cursor-pointer whitespace-nowrap"
            >
              <span className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center flex-shrink-0 ${active ? 'border-primary-500' : 'border-background-400 dark:border-background-400/70'}`}>
                {active && <span className="w-1.5 h-1.5 rounded-full bg-primary-500" />}
              </span>
              {d === 'teslim' ? 'Teslim Edildi' : 'Takipte'}
            </button>
          );
        })}
      </div>
    </div>
  );
}

/** Yeni / düzenlenen Tespit-Öneri kaydı formu — TEK EKRAN, kompakt grid, scroll yok. */
export default function NoterKayitModal({ firmaId, defter, kayit, onClose, onSaved }: NoterKayitModalProps) {
  const { addToast } = useToastActions();
  const { profile } = useAuth();
  const duzenleme = !!kayit;

  const [personelOptions, setPersonelOptions] = useState<NoterPersonelOption[]>([]);
  const [defterNo, setDDefterNo] = useState(kayit?.defterNo ?? defter?.defterNo ?? '');
  const [sayfaNo, setSayfaNo] = useState(kayit?.sayfaNo != null ? String(kayit.sayfaNo) : '');
  const [siraNo, setSiraNo] = useState(kayit?.siraNo != null ? String(kayit.siraNo) : '');
  const [tespitTarihi, setTespitTarihi] = useState(kayit?.tespitTarihi ?? '');
  const [tespitSaati, setTespitSaati] = useState(kayit?.tespitSaati ?? '');
  const [tespitEden, setTespitEden] = useState(kayit?.tespitEden ?? '');
  const [tespitEdenGorevi, setTespitEdenGorevi] = useState(kayit?.tespitEdenGorevi ?? 'İş Güvenliği Uzmanı');
  const [ilgiliPersonelId, setIlgiliPersonelId] = useState(kayit?.ilgiliPersonelId ?? '');
  const [konu, setKonu] = useState(kayit?.konu ?? '');
  const [tespitAciklamasi, setTespitAciklamasi] = useState(kayit?.tespitAciklamasi ?? '');
  const [gerekliOnlem, setGerekliOnlem] = useState(kayit?.gerekliOnlem ?? '');
  const [ilgiliMevzuat, setIlgiliMevzuat] = useState(kayit?.ilgiliMevzuat ?? '');
  const [termin, setTermin] = useState(kayit?.termin ?? '');
  const [sorumlu, setSorumlu] = useState(kayit?.sorumlu ?? '');
  const [durum, setDurum] = useState<NoterKayitDurum>(kayit?.durum ?? 'taslak');
  const [isverenGorusu, setIsverenGorusu] = useState(kayit?.isverenGorusu ?? '');
  const [asilNusha, setAsilNusha] = useState<NushaDurum>(kayit?.asilNushaDurum ?? 'takipte');
  const [uzmanNusha, setUzmanNusha] = useState<NushaDurum>(kayit?.uzmanNushaDurum ?? 'takipte');
  const [hekimNusha, setHekimNusha] = useState<NushaDurum>(kayit?.hekimNushaDurum ?? 'takipte');

  const [mevcutEkler, setMevcutEkler] = useState<NoterEk[]>([]);
  const [yeniDosyalar, setYeniDosyalar] = useState<UploadFile[]>([]);

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    fetchFirmaPersonelOptions(firmaId)
      .then((list) => {
        if (!cancelled) setPersonelOptions(list);
      })
      .catch(() => {
        if (!cancelled) setPersonelOptions([]);
      });
    return () => {
      cancelled = true;
    };
  }, [firmaId]);

  useEffect(() => {
    if (duzenleme) return undefined;
    let cancelled = false;
    fetchNextSiraNo(firmaId)
      .then((n) => {
        if (!cancelled) setSiraNo(String(n));
      })
      .catch(() => {
        if (!cancelled) setSiraNo('1');
      });
    return () => {
      cancelled = true;
    };
  }, [duzenleme, firmaId]);

  useEffect(() => {
    if (duzenleme) return;
    const ad = [profile?.firstName, profile?.lastName].filter(Boolean).join(' ').trim();
    if (ad) setTespitEden((prev) => prev || ad);
  }, [duzenleme, profile?.firstName, profile?.lastName]);

  useEffect(() => {
    if (!kayit) return;
    let cancelled = false;
    fetchNoterEkleri(kayit.id)
      .then((list) => {
        if (!cancelled) setMevcutEkler(list);
      })
      .catch(() => {
        if (!cancelled) setMevcutEkler([]);
      });
    return () => {
      cancelled = true;
    };
  }, [kayit]);

  const durumOptions = useMemo(
    () => NOTER_SECILEBILIR_DURUMLAR.map((d) => ({ value: d, label: NOTER_DURUM_LABEL[d] })),
    [],
  );

  const handleSave = useCallback(
    async (taslak: boolean) => {
      setError(null);
      if (!defterNo.trim()) {
        setError('Defter numarası zorunludur.');
        return;
      }
      if (!sayfaNo.trim() || Number.isNaN(Number(sayfaNo))) {
        setError('Sayfa numarası zorunludur.');
        return;
      }
      if (!taslak) {
        if (!tespitTarihi) {
          setError('Tespit tarihi zorunludur.');
          return;
        }
        if (!tespitEden.trim()) {
          setError('Tespit eden bilgisi zorunludur.');
          return;
        }
        if (!konu.trim()) {
          setError('Tespit / öneri konusu zorunludur.');
          return;
        }
        if (!tespitAciklamasi || tespitAciklamasi.replace(/<[^>]*>/g, '').trim() === '') {
          setError('Tespit ve öneri açıklaması zorunludur.');
          return;
        }
        if (!gerekliOnlem || gerekliOnlem.replace(/<[^>]*>/g, '').trim() === '') {
          setError('Gerekli önlem / tavsiye zorunludur.');
          return;
        }
      }

      const finalDurum: NoterKayitDurum = taslak ? 'taslak' : durum === 'taslak' ? 'acik' : durum;

      const payload = {
        defterId: defter?.id ?? kayit?.defterId ?? null,
        defterNo: defterNo.trim(),
        sayfaNo: Number(sayfaNo),
        siraNo: siraNo.trim() ? Number(siraNo) : null,
        tespitTarihi: tespitTarihi || null,
        tespitSaati: tespitSaati || null,
        tespitEden: tespitEden.trim() || null,
        tespitEdenGorevi: tespitEdenGorevi.trim() || null,
        ilgiliPersonelId: ilgiliPersonelId || null,
        konu: konu.trim() || null,
        tespitAciklamasi: tespitAciklamasi || null,
        gerekliOnlem: gerekliOnlem || null,
        ilgiliMevzuat: ilgiliMevzuat.trim() || null,
        termin: termin || null,
        sorumlu: sorumlu.trim() || null,
        isverenGorusu: isverenGorusu || null,
        durum: finalDurum,
        asilNushaDurum: asilNusha,
        uzmanNushaDurum: uzmanNusha,
        hekimNushaDurum: hekimNusha,
      };

      setSaving(true);
      try {
        const savedKayit = duzenleme && kayit
          ? await updateNoterKayit(kayit.id, payload)
          : await createNoterKayit(firmaId, payload);

        for (const uf of yeniDosyalar) {
          if (!uf.raw) continue;
          await uploadNoterEk(savedKayit.id, {
            ekTuru: tahminEkTuru(uf.mime, uf.name),
            baslik: uf.name,
            file: uf.raw,
          });
        }

        addToast({
          title: taslak ? 'Taslak kaydedildi' : 'Kayıt oluşturuldu',
          message: taslak
            ? 'Kayıt taslak olarak saklandı; tekrar düzenleyebilirsiniz.'
            : 'Tespit / öneri kaydı onaylı deftere işlendi.',
          type: 'success',
        });
        onSaved();
        onClose();
      } catch (e) {
        setError(friendlyNoterError(e));
        setSaving(false);
      }
    },
    [
      defter, kayit, firmaId, defterNo, sayfaNo, siraNo, tespitTarihi, tespitSaati, tespitEden,
      tespitEdenGorevi, ilgiliPersonelId, konu, tespitAciklamasi, gerekliOnlem, ilgiliMevzuat,
      termin, sorumlu, isverenGorusu, durum, asilNusha, uzmanNusha, hekimNusha, yeniDosyalar,
      duzenleme, addToast, onSaved, onClose,
    ],
  );

  const handleSilEk = useCallback(
    (ek: NoterEk) => {
      deleteNoterEk(ek.id)
        .then(() => {
          setMevcutEkler((prev) => prev.filter((x) => x.id !== ek.id));
          addToast({ title: 'Ek silindi', message: 'Dosya kaldırıldı.', type: 'success' });
        })
        .catch((e) => addToast({ title: 'Silinemedi', message: friendlyNoterError(e), type: 'error' }));
    },
    [addToast],
  );

  return (
    <div className="flex h-full min-h-0 flex-col gap-2.5">
      {/* Tek ekran kompakt form alanı */}
      <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane pr-0.5 space-y-2.5">
        {/* SATIR 1 — Defter/Sayfa + Tespit Bilgileri */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2.5">
          <Kart icon="ri-booklet-line" title="Defter / Sayfa Bilgileri">
            <div className="grid grid-cols-3 gap-2">
              <Input label="Defter No" required value={defterNo} onChange={(e) => setDDefterNo(e.target.value)} placeholder="2026/1453" />
              <Input label="Sayfa No" required type="number" min={1} value={sayfaNo} onChange={(e) => setSayfaNo(e.target.value)} placeholder="12" />
              <Input label="Sıra No" type="number" min={1} value={siraNo} onChange={(e) => setSiraNo(e.target.value)} />
            </div>
            <p className="text-[10px] text-foreground-400">Sıra no otomatik üretilir, değiştirilebilir.</p>
          </Kart>

          <Kart icon="ri-user-search-line" title="Tespit Bilgileri">
            <div className="grid grid-cols-2 gap-2">
              <DatePicker label="Tespit Tarihi" required value={tespitTarihi} onChange={(e) => setTespitTarihi(e.target.value)} />
              <TimePicker label="Tespit Saati" value={tespitSaati} onChange={(e) => setTespitSaati(e.target.value)} />
            </div>
            <div className="grid grid-cols-3 gap-2">
              <Input label="Tespit Eden" required value={tespitEden} onChange={(e) => setTespitEden(e.target.value)} placeholder="Ad Soyad" />
              <Input label="Görevi" value={tespitEdenGorevi} onChange={(e) => setTespitEdenGorevi(e.target.value)} />
              <Select
                label="İlgili Personel"
                options={[{ value: '', label: 'Seçiniz' }, ...personelOptions]}
                value={ilgiliPersonelId}
                onChange={(e) => setIlgiliPersonelId(e.target.value)}
                searchable
              />
            </div>
          </Kart>
        </div>

        {/* SATIR 2 — Tespit/Öneri + Gerekli Önlem/Tavsiye */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-2.5">
          <Kart icon="ri-file-warning-line" title="Tespit / Öneri">
            <Input label="Tespit / Öneri Konusu" required value={konu} onChange={(e) => setKonu(e.target.value)} placeholder="Örn. Makine koruyucu ekipman eksikliği" />
            <div>
              <label className="block mb-1 text-xs font-medium text-foreground-800">
                Tespit ve Öneri Açıklaması<span className="text-danger-600 ml-0.5">*</span>
              </label>
              <RichTextEditor
                value={tespitAciklamasi}
                onChange={setTespitAciklamasi}
                placeholder="Tespit edilen uygunsuzluğu, mevcut durumu ve gözleminizi açıklayın."
                minHeight={92}
                maxLength={5000}
              />
            </div>
          </Kart>

          <Kart icon="ri-shield-check-line" title="Gerekli Önlem / Tavsiye">
            <div>
              <label className="block mb-1 text-xs font-medium text-foreground-800">
                Gerekli Önlem / Tavsiye<span className="text-danger-600 ml-0.5">*</span>
              </label>
              <RichTextEditor
                value={gerekliOnlem}
                onChange={setGerekliOnlem}
                placeholder="Alınması gereken önlemi veya öneriyi açıklayın."
                minHeight={92}
                maxLength={5000}
              />
            </div>
            <Input label="İlgili Mevzuat" value={ilgiliMevzuat} onChange={(e) => setIlgiliMevzuat(e.target.value)} placeholder="Örn. 6331 sayılı Kanun Madde 4" />
          </Kart>
        </div>

        {/* SATIR 3 — Takip Bilgileri */}
        <Kart icon="ri-calendar-check-line" title="Takip Bilgileri">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
            <DatePicker label="Önerilen Termin" value={termin} onChange={(e) => setTermin(e.target.value)} />
            <Input label="Sorumlu" value={sorumlu} onChange={(e) => setSorumlu(e.target.value)} placeholder="İşveren / Departman / kişi" />
            <Select label="Durum" options={durumOptions} value={durum} onChange={(e) => setDurum(e.target.value as NoterKayitDurum)} />
          </div>
        </Kart>

        {/* SATIR 4 — İşveren Görüşü + Fiziksel Nüsha + Ekler */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-2.5">
          <Kart icon="ri-chat-quote-line" title="İşveren Görüşü / Cevabı">
            <RichTextEditor
              value={isverenGorusu}
              onChange={setIsverenGorusu}
              placeholder="İşverenin görüşü, yaptığı işlem veya cevabı..."
              minHeight={92}
              maxLength={3000}
            />
          </Kart>

          <Kart icon="ri-stack-line" title="Fiziksel Nüsha Takibi">
            <div className="space-y-2">
              <NushaSecici label="Asıl Nüsha" alt="İşveren" value={asilNusha} onChange={setAsilNusha} />
              <NushaSecici label="Uzman Nüshası" alt="İş Güvenliği Uzmanı" value={uzmanNusha} onChange={setUzmanNusha} />
              <NushaSecici label="Hekim Nüshası" alt="İşyeri Hekimi" value={hekimNusha} onChange={setHekimNusha} />
            </div>
            <p className="text-[10px] text-foreground-500 leading-snug flex items-start gap-1">
              <i className="ri-information-line mt-px flex-shrink-0" />
              Fiziksel nüsha takibidir; dijital kayıt fiziksel onaylı defterin yerine geçmez.
            </p>
          </Kart>

          <Kart icon="ri-attachment-2" title="Ekler">
            {mevcutEkler.length > 0 && (
              <ul className="space-y-1">
                {mevcutEkler.map((ek) => (
                  <li key={ek.id} className="flex items-center gap-2 rounded-md border border-background-300/40 dark:border-background-400/25 bg-background-50 dark:bg-background-200/40 px-2 py-1">
                    <i className={`${ekIkon(ek.ekTuru, ek.mimeType)} text-foreground-500 text-sm`} />
                    <span className="min-w-0 flex-1 truncate text-[11px] text-foreground-800">{ek.baslik || ek.dosyaAdi || 'Dosya'}</span>
                    <span className="text-[10px] text-foreground-400 flex-shrink-0">{formatBoyut(ek.fileSize)}</span>
                    <button
                      type="button"
                      onClick={() => handleSilEk(ek)}
                      className="w-6 h-6 flex items-center justify-center rounded text-danger-600 hover:bg-danger-50 dark:hover:bg-danger-500/15 transition-colors cursor-pointer flex-shrink-0"
                      title="Ek sil"
                      aria-label="Ek sil"
                    >
                      <i className="ri-delete-bin-line text-xs" />
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <FileUpload
              accept={EK_ACCEPT}
              multiple
              maxSize={15 * 1024 * 1024}
              files={yeniDosyalar}
              onChange={setYeniDosyalar}
              heading="Dosyaları sürükleyip bırakın veya dosya seçin"
              dropClassName="p-3"
            />
          </Kart>
        </div>
      </div>

      {/* Bilgi + hata + SABİT footer */}
      <div className="flex-shrink-0 space-y-2">
        <div className="flex items-start gap-2 rounded-md border border-primary-200/60 dark:border-primary-500/20 bg-primary-50 dark:bg-primary-500/10 px-2.5 py-1.5">
          <i className="ri-information-line text-primary-600 dark:text-primary-400 text-sm mt-0.5 flex-shrink-0" />
          <p className="text-[11px] text-foreground-700 leading-snug">
            Eklenen kanıtlar, olayın gerçekliğinin doğrulanması ve risklerin doğru analiz edilmesi için kullanılır.
          </p>
        </div>

        {error && (
          <p className="text-sm text-danger-600 flex items-center gap-1.5">
            <i className="ri-error-warning-line" />
            {error}
          </p>
        )}

        <div className="flex items-center justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={onClose} disabled={saving} className="whitespace-nowrap">
            İptal
          </Button>
          <Button variant="secondary" size="sm" leftIcon={<i className="ri-draft-line" />} className="whitespace-nowrap" onClick={() => handleSave(true)} isLoading={saving} disabled={saving}>
            Taslak Kaydet
          </Button>
          <Button variant="primary" size="sm" leftIcon={<i className="ri-save-line" />} className="whitespace-nowrap" onClick={() => handleSave(false)} isLoading={saving} disabled={saving}>
            Kaydet
          </Button>
        </div>
      </div>
    </div>
  );
}