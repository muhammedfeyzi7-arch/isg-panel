import { useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import DatePicker from '@/components/ui/DatePicker';
import FormSection from '@/components/ui/FormSection';
import { useToastActions } from '@/hooks/useToast';
import {
  type NoterDefteri,
  saveNoterDefteri,
  friendlyNoterError,
} from '@/lib/noterDefteriService';

interface DefterBilgileriModalProps {
  firmaId: string;
  defter: NoterDefteri | null;
  onClose: () => void;
  onSaved: (defter: NoterDefteri) => void;
}

/** Onaylı defter (noter defteri) temel bilgileri formu — firma başına tek kayıt. */
export default function DefterBilgileriModal({ firmaId, defter, onClose, onSaved }: DefterBilgileriModalProps) {
  const { addToast } = useToastActions();
  const [defterNo, setDefterNo] = useState(defter?.defterNo ?? '');
  const [onaylayanKurum, setOnaylayanKurum] = useState(defter?.onaylayanKurum ?? '');
  const [onayTarihi, setOnayTarihi] = useState(defter?.onayTarihi ?? '');
  const [sayfaBaslangic, setSayfaBaslangic] = useState(defter?.sayfaBaslangic != null ? String(defter.sayfaBaslangic) : '');
  const [sayfaBitis, setSayfaBitis] = useState(defter?.sayfaBitis != null ? String(defter.sayfaBitis) : '');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async () => {
    setError(null);
    if (!defterNo.trim()) {
      setError('Defter numarası zorunludur.');
      return;
    }
    const bas = sayfaBaslangic.trim() ? Number(sayfaBaslangic) : null;
    const bit = sayfaBitis.trim() ? Number(sayfaBitis) : null;
    if (bas != null && bit != null && bit < bas) {
      setError('Bitiş sayfası, başlangıç sayfasından küçük olamaz.');
      return;
    }
    setSaving(true);
    try {
      const saved = await saveNoterDefteri(firmaId, {
        defterNo: defterNo.trim(),
        onaylayanKurum: onaylayanKurum.trim() || null,
        onayTarihi: onayTarihi || null,
        sayfaBaslangic: bas,
        sayfaBitis: bit,
      });
      addToast({ title: 'Kaydedildi', message: 'Onaylı defter bilgileri kaydedildi.', type: 'success' });
      onSaved(saved);
      onClose();
    } catch (e) {
      setError(friendlyNoterError(e));
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <FormSection icon="ri-booklet-line" title="Onaylı Defter Bilgileri" subtitle="İş sağlığı ve güvenliği ile ilgili tespit ve önerilerin kaydedildiği onaylı defter.">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input
            label="Defter No"
            required
            value={defterNo}
            onChange={(e) => setDefterNo(e.target.value)}
            placeholder="Örn. 2026/1453"
          />
          <Input
            label="Onaylayan Kurum / Noter"
            value={onaylayanKurum}
            onChange={(e) => setOnaylayanKurum(e.target.value)}
            placeholder="Örn. Kadıköy 34. Noterliği"
          />
          <DatePicker
            label="Onay Tarihi"
            value={onayTarihi}
            onChange={(e) => setOnayTarihi(e.target.value)}
          />
          <div className="grid grid-cols-2 gap-2">
            <Input
              label="Başlangıç Sayfası"
              type="number"
              min={1}
              value={sayfaBaslangic}
              onChange={(e) => setSayfaBaslangic(e.target.value)}
              placeholder="1"
            />
            <Input
              label="Bitiş Sayfası"
              type="number"
              min={1}
              value={sayfaBitis}
              onChange={(e) => setSayfaBitis(e.target.value)}
              placeholder="200"
            />
          </div>
        </div>
      </FormSection>

      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={saving}>
          Vazgeç
        </Button>
        <Button
          variant="primary"
          size="sm"
          leftIcon={<i className="ri-save-line" />}
          onClick={handleSave}
          isLoading={saving}
          className="whitespace-nowrap"
        >
          Kaydet
        </Button>
      </div>
    </div>
  );
}