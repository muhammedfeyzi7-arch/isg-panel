import Badge from '@/components/ui/Badge';
import { FileIcon } from '@/components/ui/Icon';
import { dosyaTuruBul } from '@/lib/icons/iconRegistry';

export type EvrakDosyaTur = 'pdf' | 'word' | 'excel' | 'gorsel' | 'diger';

function extOf(name: string | null | undefined): string {
  if (!name) return '';
  const i = name.lastIndexOf('.');
  return i >= 0 ? name.slice(i + 1).toLowerCase() : '';
}

/**
 * Dosya MIME/uzantısına göre görsel tür ailesi. Yalnızca GÖRÜNTÜLEME amaçlıdır
 * (iş mantığı değil); tür çözümü MERKEZÎ `dosyaTuruBul` üzerinden yapılır ve
 * evrak modülünün 5'li görsel grubuna indirgenir.
 */
export function evrakDosyaTur(mime: string | null, name: string | null): EvrakDosyaTur {
  const tur = dosyaTuruBul(mime, name);
  if (tur === 'pdf') return 'pdf';
  if (tur === 'word') return 'word';
  if (tur === 'excel') return 'excel';
  if (tur === 'image') return 'gorsel';
  return 'diger';
}

/**
 * Tür etiketi canonical Shared UI `Badge` varyantına bağlanır (tek kaynak).
 * Böylece sayfaya özel elle yazılmış rozet renkleri KALMAZ; rozet teması
 * (light/dark) merkezî Badge token'ından gelir.
 */
type BadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'secondary' | 'accent';

const TUR_META: Record<EvrakDosyaTur, { variant: BadgeVariant; labelFor: (ext: string) => string }> = {
  pdf: { variant: 'danger', labelFor: () => 'PDF' },
  word: {
    variant: 'info',
    labelFor: (e) => (e === 'doc' ? 'DOC' : e === 'rtf' ? 'RTF' : e === 'odt' ? 'ODT' : 'DOCX'),
  },
  excel: {
    variant: 'success',
    labelFor: (e) => (e === 'xls' ? 'XLS' : e === 'csv' ? 'CSV' : e === 'ods' ? 'ODS' : 'XLSX'),
  },
  gorsel: { variant: 'accent', labelFor: (e) => (e ? e.toUpperCase() : 'GÖRSEL') },
  diger: { variant: 'default', labelFor: (e) => (e ? e.toUpperCase() : 'DOSYA') },
};

interface Props {
  mime: string | null;
  name: string | null;
  size?: 'sm' | 'md';
}

/**
 * Evrak adı yanındaki PROFESYONEL dosya türü ikonu.
 *
 * Artık kutu içine gömülü beyaz sembol yerine, dosya formatının KENDİSİNİ ve
 * marka rengini gösteren dolgulu ikon kullanılır (PDF=kırmızı, Word=mavi,
 * Excel=yeşil, PowerPoint=turuncu, görsel=mavi). İkon merkezî FileIcon'dan
 * gelir; tüm modüller aynı görsel dili paylaşır.
 */
export function EvrakDosyaIkonu({ mime, name, size = 'md' }: Props) {
  const box = size === 'sm' ? 'w-8 h-8' : 'w-9 h-9';
  const px = size === 'sm' ? 22 : 26;
  return (
    <div className={`${box} flex items-center justify-center flex-shrink-0`}>
      <FileIcon mime={mime} name={name} size={px} />
    </div>
  );
}

/**
 * "Dosya Türü" alanında kullanılacak sade etiket (ör. PDF / DOCX / XLSX).
 * Ham MIME türü ("application/pdf") yerine kullanıcıya anlamlı tür gösterir.
 */
export function evrakDosyaTurEtiket(mime: string | null, name: string | null): string {
  const tur = evrakDosyaTur(mime, name);
  return TUR_META[tur].labelFor(extOf(name));
}

/** "Dosya Türü" sütunundaki renkli tür etiketi (canonical Badge — tek kaynak). */
export function EvrakDosyaTipiBadge({ mime, name }: Props) {
  const meta = TUR_META[evrakDosyaTur(mime, name)];
  return <Badge variant={meta.variant}>{meta.labelFor(extOf(name))}</Badge>;
}