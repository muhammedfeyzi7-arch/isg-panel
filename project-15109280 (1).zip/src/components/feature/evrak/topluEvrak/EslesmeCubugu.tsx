import { OZEL_TYPE_VALUE, sayfaAralikEtiketi, type BelgeGrubu } from './types';

interface EslesmeCubuguProps {
  gruplar: BelgeGrubu[];
  aktifGrupId: string | null;
  personelMap: Map<string, string>;
  turMap: Map<string, string>;
  seciliSayi: number;
  saving: boolean;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
  onSecilenleriEkle: () => void;
  onSecimKaldir: () => void;
}

/**
 * EŞLEŞTİRME ŞERİDİ — oluşturulan belge grupları tek satırda (yatay kaydırmalı).
 *
 * Her çip = sayfa aralığı + personel + belge türü durumu. Çip tıklandığında grup
 * "aktif" olur; alttaki işlem alanı o grubu düzenler. Böylece referans düzeni
 * (sol grid | sağ büyük preview) korunurken ÇOKLU grup desteği birebir çalışır.
 */
export default function EslesmeCubugu({
  gruplar,
  aktifGrupId,
  personelMap,
  turMap,
  seciliSayi,
  saving,
  onSelect,
  onDelete,
  onSecilenleriEkle,
  onSecimKaldir,
}: EslesmeCubuguProps) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 border-b border-background-300/50 dark:border-background-400/30 flex-shrink-0">
      <span className="flex items-center gap-1.5 flex-shrink-0">
        <i className="ri-links-line text-foreground-500" />
        <span className="text-sm font-semibold text-foreground-800">Eşleştirmeler</span>
        <span className="isg-text-caption text-foreground-500">({gruplar.length})</span>
      </span>

      {/* Çipler */}
      <div className="flex-1 min-w-0 flex items-center gap-1.5 overflow-x-auto isg-scroll-pane py-0.5">
        {gruplar.length === 0 ? (
          <span className="isg-text-caption text-foreground-400 whitespace-nowrap">
            Soldan sayfa seçip “Seçilenleri Ekle” ile eşleştirme oluşturun.
          </span>
        ) : (
          gruplar.map((g) => {
            const active = aktifGrupId === g.id;
            const personelAd = g.personelId ? personelMap.get(g.personelId) : null;
            const turAd = g.typeValue === OZEL_TYPE_VALUE
              ? (g.ozelBelgeTuru.trim() || 'Özel Belge')
              : turMap.get(g.typeValue) ?? null;
            const tam = !!personelAd && !!turAd;
            return (
              <div
                key={g.id}
                onClick={() => onSelect(g.id)}
                title={tam ? `${personelAd} · ${turAd}` : 'Eksik: personel/belge türü seçin'}
                className={`group flex items-center gap-1.5 pl-2 pr-1 py-1 rounded-full border text-xs whitespace-nowrap cursor-pointer transition-colors ${
                  active
                    ? 'border-primary-400 bg-primary-50 dark:bg-primary-500/15 text-primary-700 dark:text-primary-300'
                    : 'border-background-300/60 dark:border-background-400/30 bg-background-100 dark:bg-background-200/50 text-foreground-700 hover:border-primary-300'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${tam ? 'bg-success-500' : 'bg-warning-500'}`} />
                <span className="font-semibold tabular-nums">{sayfaAralikEtiketi(g.pages)}</span>
                <span className="text-foreground-400">·</span>
                <span className="max-w-[140px] truncate">{personelAd ?? 'Personel?'}</span>
                <span className="text-foreground-400">·</span>
                <span className="max-w-[120px] truncate">{turAd ?? 'Tür?'}</span>
                {g.saved && <i className="ri-checkbox-circle-fill text-success-500" />}
                <button
                  type="button"
                  title="Grubu sil"
                  aria-label="Grubu sil"
                  disabled={saving}
                  onClick={(e) => { e.stopPropagation(); onDelete(g.id); }}
                  className="w-5 h-5 flex items-center justify-center rounded-full text-foreground-400 hover:text-danger-600 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer disabled:opacity-40"
                >
                  <i className="ri-close-line text-sm" />
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* Aksiyonlar */}
      <div className="flex items-center gap-1.5 flex-shrink-0">
        <button
          type="button"
          onClick={onSecilenleriEkle}
          disabled={saving || seciliSayi === 0}
          className="isg-btn isg-btn-sm isg-btn-primary whitespace-nowrap cursor-pointer disabled:opacity-50"
        >
          <i className="ri-add-line" /> Seçilenleri Ekle
          {seciliSayi > 0 ? ` (${seciliSayi})` : ''}
        </button>
        <button
          type="button"
          onClick={onSecimKaldir}
          disabled={saving || seciliSayi === 0}
          className="isg-btn isg-btn-sm isg-btn-ghost whitespace-nowrap cursor-pointer disabled:opacity-50"
        >
          <i className="ri-eraser-line" /> Seçim Kaldır
        </button>
      </div>
    </div>
  );
}