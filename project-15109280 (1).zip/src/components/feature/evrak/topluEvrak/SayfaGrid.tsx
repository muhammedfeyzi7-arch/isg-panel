import { useEffect, useMemo, useState, type MouseEvent as ReactMouseEvent } from 'react';
import type { PDFDocumentProxy } from 'pdfjs-dist';
import { renderThumbnail, RENDER_PRIORITY } from '@/components/feature/preview/pdf/pdfEngine';

const THUMB_W = 150;
const PAGE_SIZE = 12;

interface ThumbProps {
  doc: PDFDocumentProxy | null;
  cacheKey: string;
  page: number;
  selected: boolean;
  used: boolean;
  active: boolean;
  onToggle: (page: number, shift: boolean) => void;
  onPreview: (page: number) => void;
}

function Thumb({ doc, cacheKey, page, selected, used, active, onToggle, onPreview }: ThumbProps) {
  const [url, setUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  const [retry, setRetry] = useState(0);

  useEffect(() => {
    if (!doc) return undefined;
    const ctrl = new AbortController();
    let settled = false;
    setFailed(false);
    renderThumbnail(doc, cacheKey, page, 0, THUMB_W, ctrl.signal, RENDER_PRIORITY.VISIBLE_THUMB)
      .then((u) => {
        if (!settled) {
          settled = true;
          setUrl(u);
        }
      })
      .catch(() => {
        if (!settled) {
          settled = true;
          setFailed(true);
        }
      });
    return () => {
      settled = true;
      ctrl.abort();
    };
  }, [doc, cacheKey, page, retry]);

  const handleClick = (e: ReactMouseEvent<HTMLButtonElement>) => {
    onPreview(page);
    if (!used) onToggle(page, e.shiftKey);
  };

  return (
    <div className="flex flex-col items-center gap-1">
      <button
        type="button"
        onClick={handleClick}
        aria-label={`Sayfa ${page}`}
        aria-pressed={selected}
        className={`relative block w-full rounded-md overflow-hidden border-2 transition-colors cursor-pointer ${
          selected
            ? 'border-primary-500'
            : active
              ? 'border-primary-400'
              : 'border-background-300/60 dark:border-background-400/30 hover:border-primary-300'
        } ${used ? 'opacity-45' : ''}`}
        style={{ height: 150 }}
      >
        {url ? (
          <img src={url} alt={`Sayfa ${page}`} className="w-full h-full object-contain bg-white" draggable={false} />
        ) : (
          <span className="absolute inset-0 flex items-center justify-center bg-background-200/70 dark:bg-background-300/40">
            {failed ? (
              <span
                role="button"
                tabIndex={0}
                title="Tekrar dene"
                onClick={(e) => {
                  e.stopPropagation();
                  setUrl(null);
                  setFailed(false);
                  setRetry((k) => k + 1);
                }}
                className="w-6 h-6 flex items-center justify-center rounded-full text-foreground-500 hover:text-primary-600 cursor-pointer"
              >
                <i className="ri-refresh-line text-sm" />
              </span>
            ) : (
              <span className="w-4 h-4 border-2 border-primary-400/70 border-t-transparent rounded-full animate-spin" />
            )}
          </span>
        )}

        {selected && (
          <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-primary-500 text-inverse flex items-center justify-center">
            <i className="ri-check-line text-[10px]" />
          </span>
        )}
        {used && (
          <span className="absolute top-1 left-1 w-4 h-4 rounded-full bg-secondary-500 text-inverse flex items-center justify-center" title="Bir belgeye atandı">
            <i className="ri-lock-line text-[10px]" />
          </span>
        )}
      </button>
      <span className={`text-xs tabular-nums ${active ? 'text-primary-600 font-semibold' : 'text-foreground-500'}`}>
        {page}
      </span>
    </div>
  );
}

interface SayfaGridProps {
  doc: PDFDocumentProxy | null;
  cacheKey: string;
  pageCount: number;
  selectedPages: number[];
  usedPages: Set<number>;
  activePage: number;
  onToggle: (page: number, shift: boolean) => void;
  onPreview: (page: number) => void;
  onSelectAll: () => void;
  onClearSelection: () => void;
}

/**
 * SOL KOLON — "PDF Sayfaları".
 *
 * Gerçek PDF thumbnail gridi (pencereleme/pagination ile). Sayfa seçimi gerçek
 * state'e bağlıdır; bir belgeye atanmış (used) sayfalar kilitli görünür ve tekrar
 * seçilemez. Filtre: Tümü / Seçilen.
 */
export default function SayfaGrid({
  doc,
  cacheKey,
  pageCount,
  selectedPages,
  usedPages,
  activePage,
  onToggle,
  onPreview,
  onSelectAll,
  onClearSelection,
}: SayfaGridProps) {
  const [onlySelected, setOnlySelected] = useState(false);
  const [page, setPage] = useState(1);

  const selectedSet = useMemo(() => new Set(selectedPages), [selectedPages]);

  const allPages = useMemo(() => {
    const arr: number[] = [];
    for (let i = 1; i <= pageCount; i += 1) arr.push(i);
    return arr;
  }, [pageCount]);

  const basePages = onlySelected ? [...selectedPages].sort((a, b) => a - b) : allPages;
  const totalPages = Math.max(1, Math.ceil(basePages.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const slice = basePages.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  useEffect(() => {
    setPage(1);
  }, [onlySelected, pageCount]);

  const pageNumbers = useMemo(() => {
    const nums: number[] = [];
    const start = Math.max(1, currentPage - 2);
    const end = Math.min(totalPages, start + 4);
    for (let i = start; i <= end; i += 1) nums.push(i);
    return nums;
  }, [currentPage, totalPages]);

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Başlık */}
      <div className="flex items-center justify-between gap-2 px-3 py-2 border-b border-background-300/40 dark:border-background-400/25 flex-shrink-0">
        <div className="flex items-center gap-2">
          <i className="ri-image-2-line text-foreground-500" />
          <span className="text-sm font-semibold text-foreground-800">PDF Sayfaları</span>
          <span className="isg-text-caption text-foreground-500">{pageCount} sayfa</span>
        </div>
        <div className="flex items-center gap-1 p-0.5 rounded-full border border-background-300/60 dark:border-background-400/30 bg-background-100 dark:bg-background-200/60">
          <button
            type="button"
            onClick={() => setOnlySelected(false)}
            className={`px-2.5 py-0.5 rounded-full text-xs transition-colors cursor-pointer ${
              !onlySelected ? 'bg-primary-500 text-inverse' : 'text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40'
            }`}
          >
            Tümü
          </button>
          <button
            type="button"
            onClick={() => setOnlySelected(true)}
            className={`px-2.5 py-0.5 rounded-full text-xs transition-colors cursor-pointer ${
              onlySelected ? 'bg-primary-500 text-inverse' : 'text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40'
            }`}
          >
            Seçilen
          </button>
        </div>
      </div>

      {/* Seçim araç satırı */}
      <div className="flex items-center gap-2 px-3 py-1.5 border-b border-background-300/40 dark:border-background-400/25 flex-shrink-0">
        <span className="isg-text-caption text-foreground-500">
          Seçilen: <span className="font-semibold text-foreground-800">{selectedPages.length}</span> sayfa
        </span>
        <span className="flex-1" />
        <button
          type="button"
          onClick={onSelectAll}
          className="isg-btn isg-btn-sm isg-btn-ghost whitespace-nowrap cursor-pointer"
        >
          <i className="ri-checkbox-multiple-line" /> Tümünü Seç
        </button>
        <button
          type="button"
          onClick={onClearSelection}
          disabled={selectedPages.length === 0}
          className="isg-btn isg-btn-sm isg-btn-ghost whitespace-nowrap cursor-pointer disabled:opacity-50"
        >
          <i className="ri-close-line" /> Temizle
        </button>
      </div>

      {/* Grid */}
      <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane p-3">
        {slice.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center gap-1 text-foreground-400">
            <i className="ri-image-line text-2xl" />
            <p className="text-sm">Seçili sayfa yok.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
            {slice.map((p) => (
              <Thumb
                key={p}
                doc={doc}
                cacheKey={cacheKey}
                page={p}
                selected={selectedSet.has(p)}
                used={usedPages.has(p)}
                active={p === activePage}
                onToggle={onToggle}
                onPreview={onPreview}
              />
            ))}
          </div>
        )}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-1 px-3 py-2 border-t border-background-300/40 dark:border-background-400/25 flex-shrink-0">
          <button
            type="button"
            onClick={() => setPage((n) => Math.max(1, n - 1))}
            disabled={currentPage <= 1}
            className="w-7 h-7 flex items-center justify-center rounded-md text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 disabled:opacity-40 cursor-pointer"
          >
            <i className="ri-arrow-left-s-line" />
          </button>
          {pageNumbers.map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setPage(n)}
              className={`min-w-7 h-7 px-1.5 flex items-center justify-center rounded-md text-xs tabular-nums cursor-pointer ${
                n === currentPage ? 'bg-primary-500 text-inverse' : 'text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40'
              }`}
            >
              {n}
            </button>
          ))}
          {totalPages > pageNumbers[pageNumbers.length - 1] && (
            <>
              <span className="text-foreground-400 text-xs px-0.5">…</span>
              <button
                type="button"
                onClick={() => setPage(totalPages)}
                className="min-w-7 h-7 px-1.5 flex items-center justify-center rounded-md text-xs tabular-nums text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer"
              >
                {totalPages}
              </button>
            </>
          )}
          <button
            type="button"
            onClick={() => setPage((n) => Math.min(totalPages, n + 1))}
            disabled={currentPage >= totalPages}
            className="w-7 h-7 flex items-center justify-center rounded-md text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 disabled:opacity-40 cursor-pointer"
          >
            <i className="ri-arrow-right-s-line" />
          </button>
        </div>
      )}
    </div>
  );
}