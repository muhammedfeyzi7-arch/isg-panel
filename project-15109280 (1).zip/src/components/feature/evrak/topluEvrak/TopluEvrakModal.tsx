import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { mutate } from 'swr';
import Button from '@/components/ui/Button';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import { DocumentPreviewEngine, usePdfDocument, type PreviewViewerHandle } from '@/components/feature/preview';
import { fetchEvrakTurleri, friendlyEvrakError, type EvrakTuru } from '@/lib/evrakService';
import { fetchFirmaPersonellerPage, type PersonelData } from '@/lib/personelService';
import {
  cleanupTopluEvrakSource,
  commitTopluEvrakGroup,
  prepareTopluEvrakSource,
  selectableBelgeTurleri,
  uploadTopluEvrakSource,
} from '@/lib/topluEvrakService';
import SayfaGrid from './SayfaGrid';
import EslesmeCubugu from './EslesmeCubugu';
import KaydetBar from './KaydetBar';
import { grupHatasi, newGroupId, OZEL_TYPE_VALUE, type BelgeGrubu } from './types';

interface TopluEvrakModalProps {
  firmaId: string;
  role: 'firma' | 'uzman';
  onClose?: () => void;
  onCompleted?: () => void;
}

const SOURCE_MAX_SIZE = 60 * 1024 * 1024;
const SOURCE_ACCEPT = '.pdf,application/pdf';

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * Toplu Evrak — TEK MODAL, TEK EKRAN (referans düzen).
 *
 * SOL: PDF sayfa gridi (seçim / Tümünü Seç / Temizle / sayfalama).
 * SAĞ: eşleştirme şeridi + BÜYÜK PDF önizleme (merkezi motor toolbar'ı ile).
 * ALT: seçili sayfalar + personel + belge türü + “Belgeyi Kaydet”.
 *
 * PDF, SUNUCUDA (edge function) storage'dan indirilip gerçek sayfalara ayrılır; her
 * grup personel dijital dosyasına kaydedilir. Çoklu grup desteği korunur.
 */
export default function TopluEvrakModal({ firmaId, role, onClose, onCompleted }: TopluEvrakModalProps) {
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const engineRef = useRef<PreviewViewerHandle | null>(null);

  const [file, setFile] = useState<File | null>(null);
  const [sourceBytes, setSourceBytes] = useState<ArrayBuffer | null>(null);
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([]);
  const [loadingFile, setLoadingFile] = useState(false);

  const [selectedPages, setSelectedPages] = useState<number[]>([]);
  const [groups, setGroups] = useState<BelgeGrubu[]>([]);
  const [activeGroupId, setActiveGroupId] = useState<string | null>(null);
  const [activePage, setActivePage] = useState(1);
  const [saving, setSaving] = useState(false);
  const [progressText, setProgressText] = useState<string | null>(null);

  const [personeller, setPersoneller] = useState<PersonelData[]>([]);
  const [personelError, setPersonelError] = useState<string | null>(null);
  const [belgeTurleri, setBelgeTurleri] = useState<EvrakTuru[]>([]);
  const [turError, setTurError] = useState<string | null>(null);

  // ── Referans veriler ──
  useEffect(() => {
    let cancelled = false;
    Promise.all([
      fetchFirmaPersonellerPage({ firmaId, durum: 'aktif', sortBy: 'ad', sortDir: 'asc', pageSize: 500 }),
      fetchEvrakTurleri(),
    ])
      .then(([pr, turler]) => {
        if (cancelled) return;
        setPersoneller(pr.data);
        setPersonelError(null);
        setBelgeTurleri(selectableBelgeTurleri(turler, false));
        setTurError(null);
      })
      .catch((e) => {
        if (cancelled) return;
        setPersonelError(friendlyEvrakError(e));
        setTurError('Belge türleri yüklenemedi.');
      });
    return () => {
      cancelled = true;
    };
  }, [firmaId]);

  const personelOptions = useMemo(
    () => personeller.map((p) => ({ value: p.id, label: p.adSoyad })),
    [personeller],
  );
  const personelMap = useMemo(() => new Map(personeller.map((p) => [p.id, p.adSoyad])), [personeller]);
  const turMap = useMemo(() => new Map(belgeTurleri.map((t) => [t.id, t.name])), [belgeTurleri]);
  const digerTuruId = useMemo(() => belgeTurleri.find((t) => t.code === 'diger')?.id ?? null, [belgeTurleri]);

  // ── PDF kaynağı ──
  const source = useMemo(() => {
    if (!file) return null;
    return {
      cacheKey: `toplu-evrak:${file.name}:${file.size}:${file.lastModified}`,
      fileName: file.name,
      mimeType: file.type || 'application/pdf',
      fileSize: file.size,
      getBytes: async () => sourceBytes ?? new ArrayBuffer(0),
    };
  }, [file, sourceBytes]);

  // Sol grid + önizleme için gerçek PDF dokümanı (thumbnail ve sayfa sayısı).
  const pdf = usePdfDocument(
    source?.cacheKey ?? 'none',
    source?.getBytes ?? (async () => new ArrayBuffer(0)),
    !!source,
  );
  const pageCount = pdf.pageCount;

  const allPages = useMemo(() => {
    const arr: number[] = [];
    for (let i = 1; i <= pageCount; i += 1) arr.push(i);
    return arr;
  }, [pageCount]);

  const usedPages = useMemo(() => {
    const s = new Set<number>();
    groups.forEach((g) => g.pages.forEach((p) => s.add(p)));
    return s;
  }, [groups]);

  // ── Dosya yükleme (yeni PDF = yeni oturum) ──
  const loadFile = useCallback(
    async (raw: File) => {
      const isPdf = raw.type === 'application/pdf' || raw.name.toLowerCase().endsWith('.pdf');
      if (!isPdf) {
        addToast({ title: 'Geçersiz dosya', message: 'Lütfen bir PDF dosyası seçin.', type: 'error' });
        return;
      }
      if (raw.size > SOURCE_MAX_SIZE) {
        addToast({ title: 'Dosya çok büyük', message: `Kaynak PDF en fazla ${formatBytes(SOURCE_MAX_SIZE)} olmalı.`, type: 'error' });
        return;
      }
      setLoadingFile(true);
      try {
        const bytes = await raw.arrayBuffer();
        setFile(raw);
        setSourceBytes(bytes);
        setSelectedPages([]);
        setGroups([]);
        setActiveGroupId(null);
        setActivePage(1);
      } catch {
        addToast({ title: 'Dosya okunamadı', message: 'PDF içeriği okunamadı.', type: 'error' });
      } finally {
        setLoadingFile(false);
      }
    },
    [addToast],
  );

  const handleUploadChange = useCallback(
    (files: UploadFile[]) => {
      setUploadFiles(files);
      const raw = files[0]?.raw;
      if (raw) void loadFile(raw);
    },
    [loadFile],
  );

  const handleReplace = useCallback(() => {
    setFile(null);
    setSourceBytes(null);
    setUploadFiles([]);
    setSelectedPages([]);
    setGroups([]);
    setActiveGroupId(null);
    setActivePage(1);
  }, []);

  // ── Sayfa seçimi ──
  const togglePage = useCallback(
    (page: number, shift: boolean) => {
      if (usedPages.has(page)) return;
      setSelectedPages((prev) => {
        if (shift && prev.length > 0) {
          const lo = Math.min(prev[prev.length - 1], page);
          const hi = Math.max(prev[prev.length - 1], page);
          const range: number[] = [];
          for (let i = lo; i <= hi; i += 1) if (!usedPages.has(i)) range.push(i);
          return Array.from(new Set([...prev, ...range])).sort((a, b) => a - b);
        }
        return prev.includes(page) ? prev.filter((p) => p !== page) : [...prev, page].sort((a, b) => a - b);
      });
    },
    [usedPages],
  );

  const previewPage = useCallback((page: number) => {
    setActivePage(page);
    engineRef.current?.goTo(page);
  }, []);

  const selectAllPages = useCallback(() => {
    setSelectedPages(allPages.filter((p) => !usedPages.has(p)));
  }, [allPages, usedPages]);

  // ── Gruplar ──
  const updateGroup = useCallback((id: string, patch: Partial<BelgeGrubu>) => {
    setGroups((prev) => prev.map((g) => (g.id === id ? { ...g, ...patch } : g)));
  }, []);

  const createGroupFromSelection = useCallback(() => {
    if (selectedPages.length === 0) {
      addToast({ title: 'Sayfa seçilmedi', message: 'Yeni belge için önce sayfa seçin.', type: 'warning' });
      return;
    }
    const id = newGroupId();
    setGroups((prev) => [
      ...prev,
      {
        id,
        pages: [...selectedPages].sort((a, b) => a - b),
        personelId: null,
        typeValue: '',
        ozelBelgeTuru: '',
        saved: false,
        savedEvrakId: null,
        saveError: null,
      },
    ]);
    setSelectedPages([]);
    setActiveGroupId(id);
  }, [selectedPages, addToast]);

  const deleteGroup = useCallback((id: string) => {
    setGroups((prev) => prev.filter((g) => g.id !== id));
    setActiveGroupId((prev) => (prev === id ? null : prev));
  }, []);

  const activeGroup = useMemo(() => groups.find((g) => g.id === activeGroupId) ?? null, [groups, activeGroupId]);
  const unsavedGroups = useMemo(() => groups.filter((g) => !g.saved), [groups]);
  const kaydetSayisi = unsavedGroups.length;
  const toplamSayfa = unsavedGroups.reduce((sum, g) => sum + g.pages.length, 0);

  // ── Kaydetme ──
  const runSave = useCallback(async () => {
    if (saving) return;
    const toSave = groups.filter((g) => !g.saved);
    if (toSave.length === 0 || !file) return;

    const invalid = toSave.filter((g) => grupHatasi(g, digerTuruId) !== null);
    if (invalid.length > 0) {
      invalid.forEach((g) => updateGroup(g.id, { saveError: grupHatasi(g, digerTuruId) }));
      addToast({ title: 'Eksik bilgi var', message: `${invalid.length} grupta eksik alan var. Personel ve belge türünü tamamlayın.`, type: 'warning' });
      return;
    }

    setSaving(true);
    setProgressText('Belgeler hazırlanıyor…');
    const batchId = typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : `batch-${Date.now()}`;
    let sourcePath: string | null = null;

    try {
      const prep = await prepareTopluEvrakSource(firmaId);
      sourcePath = prep.path;
      await uploadTopluEvrakSource(prep.path, prep.token, file);

      let ok = 0;
      let fail = 0;
      for (let i = 0; i < toSave.length; i += 1) {
        const g = toSave[i];
        setProgressText(`${i} / ${toSave.length} belge oluşturuldu`);
        const typeId = g.typeValue === OZEL_TYPE_VALUE ? digerTuruId : g.typeValue;
        try {
          const res = await commitTopluEvrakGroup({
            firmaId,
            sourcePath: prep.path,
            batchId,
            group: {
              pages: g.pages,
              personelId: g.personelId as string,
              documentTypeId: typeId as string,
              ozelBelgeTuru: g.typeValue === OZEL_TYPE_VALUE ? g.ozelBelgeTuru.trim() : undefined,
            },
          });
          updateGroup(g.id, { saved: true, savedEvrakId: res.evrakId, saveError: null });
          ok += 1;
        } catch (e) {
          updateGroup(g.id, { saveError: e instanceof Error ? e.message : 'Belge oluşturulamadı.' });
          fail += 1;
        }
      }
      setProgressText(`${toSave.length} / ${toSave.length} belge oluşturuldu`);

      mutate(
        (key) =>
          Array.isArray(key) &&
          (key[0] === 'firma-evrak-listesi' ||
            key[0] === 'firma-evrak-sayilari' ||
            key[0] === 'personel-dosya-evraklar' ||
            key[0] === 'personel-dosya-klasorler'),
      );
      onCompleted?.();

      if (fail === 0) {
        addToast({ title: 'Kaydetme tamamlandı', message: `${ok} belge personel dosyalarına eklendi.`, type: 'success' });
        // Başarılı gruptları listeden temizle — ekran temiz kalsın.
        setGroups((prev) => prev.filter((g) => !g.saved));
        setActiveGroupId(null);
      } else if (ok === 0) {
        addToast({ title: 'Kaydetme başarısız', message: `${fail} belge oluşturulamadı. Detaylar grup kartlarında.`, type: 'error' });
      } else {
        addToast({ title: 'Kısmi başarı', message: `${ok} belge eklendi, ${fail} belge oluşturulamadı.`, type: 'warning' });
        setGroups((prev) => prev.filter((g) => !g.saved));
      }
    } catch (e) {
      addToast({ title: 'İşlem başarısız', message: friendlyEvrakError(e), type: 'error' });
    } finally {
      setSaving(false);
      setProgressText(null);
      if (sourcePath) void cleanupTopluEvrakSource(firmaId, sourcePath);
    }
  }, [saving, groups, file, digerTuruId, firmaId, updateGroup, addToast, onCompleted]);

  const handleKaydetClick = useCallback(() => {
    if (unsavedGroups.length === 0) {
      addToast({ title: 'Kaydedilecek belge yok', message: 'Önce bir eşleştirme oluşturun.', type: 'info' });
      return;
    }
    const invalid = unsavedGroups.filter((g) => grupHatasi(g, digerTuruId) !== null);
    if (invalid.length > 0) {
      invalid.forEach((g) => updateGroup(g.id, { saveError: grupHatasi(g, digerTuruId) }));
      const first = invalid[0];
      setActiveGroupId(first.id);
      addToast({ title: 'Eksik bilgi var', message: `${invalid.length} grupta eksik alan var. Personel ve belge türünü tamamlayın.`, type: 'warning' });
      return;
    }
    const personelSayisi = new Set(unsavedGroups.map((g) => g.personelId)).size;
    confirm({
      title: 'Belgeleri Kaydet',
      message: `${unsavedGroups.length} belge ${personelSayisi} personele eklenecek. Devam etmek istiyor musunuz?`,
      confirmText: 'Evet, Kaydet',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        void runSave();
      },
    });
  }, [unsavedGroups, digerTuruId, updateGroup, addToast, confirm, runSave]);

  // ── Yükleme görünümü ──
  if (!file) {
    return (
      <div className="flex flex-col h-full min-h-0 items-center justify-center p-6 overflow-y-auto">
        <div className="w-full max-w-xl">
          <div className="mb-4 text-center">
            <div className="w-14 h-14 mx-auto rounded-xl bg-primary-50 dark:bg-primary-500/10 flex items-center justify-center">
              <i className="ri-file-pdf-2-line text-primary-600 dark:text-primary-400 text-2xl" />
            </div>
            <h3 className="mt-3 text-base font-semibold text-foreground-900">Toplu Evrak Yükle ve Eşleştir</h3>
            <p className="mt-1 text-sm text-foreground-500">
              PDF dosyanızı yükleyin, sayfaları personellere ve belge türlerine eşleştirerek kaydedin.
            </p>
          </div>
          <FileUpload
            accept={SOURCE_ACCEPT}
            maxSize={SOURCE_MAX_SIZE}
            files={uploadFiles}
            onChange={handleUploadChange}
            multiple={false}
            helpText={`Yalnızca PDF · Maksimum ${formatBytes(SOURCE_MAX_SIZE)}`}
          />
          {loadingFile && (
            <p className="mt-3 text-sm text-foreground-500 flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-primary-400/70 border-t-transparent rounded-full animate-spin" />
              PDF açılıyor…
            </p>
          )}
          {(personelError || turError) && (
            <p className="mt-3 text-xs text-danger-600">{personelError || turError}</p>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Dosya kartı */}
      <div className="flex items-center gap-3 px-3 py-2.5 border-b border-background-300/50 dark:border-background-400/30 flex-shrink-0">
        <span className="w-10 h-10 rounded-lg bg-danger-50 dark:bg-danger-500/15 text-danger-600 flex items-center justify-center flex-shrink-0">
          <i className="ri-file-pdf-2-fill text-xl" />
        </span>
        <div className="min-w-0 flex-1">
          <p className="text-sm font-semibold text-foreground-800 truncate">{file.name}</p>
          <p className="isg-text-caption text-foreground-500">{formatBytes(file.size)}</p>
        </div>
        <span className="w-6 h-6 rounded-full bg-success-500 text-inverse flex items-center justify-center flex-shrink-0">
          <i className="ri-check-line text-sm" />
        </span>
        <Button variant="ghost" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={handleReplace} disabled={saving}>
          Değiştir
        </Button>
        {onClose && (
          <Button variant="ghost" size="sm" leftIcon={<i className="ri-close-line" />} onClick={onClose} disabled={saving}>
            Kapat
          </Button>
        )}
      </div>

      {/* Gövde: 2 kolon */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
        <div className="w-full lg:w-[360px] xl:w-[400px] flex-shrink-0 min-h-0 border-b lg:border-b-0 lg:border-r border-background-300/50 dark:border-background-400/30">
          <SayfaGrid
            doc={pdf.doc}
            cacheKey={source?.cacheKey ?? 'none'}
            pageCount={pageCount}
            selectedPages={selectedPages}
            usedPages={usedPages}
            activePage={activePage}
            onToggle={togglePage}
            onPreview={previewPage}
            onSelectAll={selectAllPages}
            onClearSelection={() => setSelectedPages([])}
          />
        </div>

        <div className="flex-1 min-w-0 min-h-0 flex flex-col">
          <EslesmeCubugu
            gruplar={groups}
            aktifGrupId={activeGroupId}
            personelMap={personelMap}
            turMap={turMap}
            seciliSayi={selectedPages.length}
            saving={saving}
            onSelect={setActiveGroupId}
            onDelete={deleteGroup}
            onSecilenleriEkle={createGroupFromSelection}
            onSecimKaldir={() => setSelectedPages([])}
          />
          <div className="flex-1 min-h-0">
            {source ? (
              <DocumentPreviewEngine
                ref={engineRef}
                source={source}
                title={file.name}
                initialPage={activePage}
                defaultFit="page"
                onStateChange={(s) => setActivePage(s.page)}
              />
            ) : null}
          </div>
        </div>
      </div>

      {/* Alt işlem alanı */}
      <KaydetBar
        aktifGrup={activeGroup}
        personelOptions={personelOptions}
        belgeTurleri={belgeTurleri}
        seciliSayilar={selectedPages}
        kaydetSayisi={kaydetSayisi}
        toplamSayfa={toplamSayfa}
        saving={saving}
        progressText={progressText}
        onUpdateGrup={updateGroup}
        onKaydet={handleKaydetClick}
      />
    </div>
  );
}