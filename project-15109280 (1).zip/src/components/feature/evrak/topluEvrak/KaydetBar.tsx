import Select from '@/components/ui/Select';
import type { SelectOption } from '@/components/ui/Select';
import Input from '@/components/ui/Input';
import type { EvrakTuru } from '@/lib/evrakService';
import { OZEL_TYPE_VALUE, type BelgeGrubu } from './types';

interface KaydetBarProps {
  aktifGrup: BelgeGrubu | null;
  personelOptions: SelectOption[];
  belgeTurleri: EvrakTuru[];
  /** Aktif grup yokken gösterilecek canlı sayfa seçimi. */
  seciliSayilar: number[];
  kaydetSayisi: number;
  toplamSayfa: number;
  saving: boolean;
  progressText: string | null;
  onUpdateGrup: (id: string, patch: Partial<BelgeGrubu>) => void;
  onKaydet: () => void;
}

function BilgiKutu({
  icon,
  label,
  children,
}: {
  icon: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-2.5 rounded-lg border border-background-300/60 dark:border-background-400/30 bg-background-50 dark:bg-background-200/40 px-3 py-2 min-w-0 flex-1">
      <span className="w-8 h-8 rounded-md bg-secondary-100 dark:bg-secondary-500/15 text-secondary-700 dark:text-secondary-400 flex items-center justify-center flex-shrink-0">
        <i className={`${icon} text-sm`} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[11px] text-foreground-400 leading-tight">{label}</p>
        {children}
      </div>
    </div>
  );
}

/**
 * ALT İŞLEM ALANI (referans düzeni) — seçili sayfalar, personel ve belge türü tek
 * kompakt alanda toplanır; "Belgeyi Kaydet" tüm (kaydedilmemiş) grupları Supabase'e yazar.
 * Aktif grup yoksa personel/belge türü alanları kilitlidir ve kullanıcı önce
 * "Seçilenleri Ekle" ile bir grup oluşturur.
 */
export default function KaydetBar({
  aktifGrup,
  personelOptions,
  belgeTurleri,
  seciliSayilar,
  kaydetSayisi,
  toplamSayfa,
  saving,
  progressText,
  onUpdateGrup,
  onKaydet,
}: KaydetBarProps) {
  const tipOptions: SelectOption[] = [
    ...belgeTurleri.map((t) => ({ value: t.id, label: t.name, group: t.kategori ?? 'Diğer' })),
    { value: OZEL_TYPE_VALUE, label: 'Diğer / Özel Belge Türü', group: 'Diğer' },
  ];

  const sayfaListesi = aktifGrup && aktifGrup.pages.length > 0 ? aktifGrup.pages : seciliSayilar;
  const sayfaMetni = sayfaListesi.length > 0
    ? `${[...sayfaListesi].sort((a, b) => a - b).join(', ')} (${sayfaListesi.length} sayfa)`
    : 'Seçim yok';
  const isCustom = aktifGrup?.typeValue === OZEL_TYPE_VALUE;

  return (
    <div className="flex-shrink-0 border-t border-background-300/50 dark:border-background-400/30 bg-background-50 dark:bg-background-100 p-3">
      <div className="flex flex-col lg:flex-row lg:items-stretch gap-2.5">
        {/* Seçili Sayfalar */}
        <BilgiKutu icon="ri-file-list-3-line" label="Seçili Sayfalar">
          <p className="text-sm text-foreground-800 truncate tabular-nums" title={sayfaMetni}>{sayfaMetni}</p>
        </BilgiKutu>

        {/* Seçili Personel */}
        <div className="flex-1 min-w-0">
          <BilgiKutu icon="ri-user-line" label="Seçili Personel">
            {aktifGrup ? (
              <Select
                options={personelOptions}
                value={aktifGrup.personelId ?? ''}
                onChange={(e) => onUpdateGrup(aktifGrup.id, { personelId: e.target.value || null, saveError: null })}
                placeholder="Personel seçin"
                searchable
                size="sm"
                disabled={saving}
              />
            ) : (
              <p className="text-sm text-foreground-400">—</p>
            )}
          </BilgiKutu>
        </div>

        {/* Seçili Belge Türü */}
        <div className="flex-1 min-w-0">
          <BilgiKutu icon="ri-price-tag-3-line" label="Seçili Belge Türü">
            {aktifGrup ? (
              <Select
                options={tipOptions}
                value={aktifGrup.typeValue}
                onChange={(e) => onUpdateGrup(aktifGrup.id, { typeValue: e.target.value, saveError: null })}
                placeholder="Belge türü seçin"
                searchable
                size="sm"
                disabled={saving}
              />
            ) : (
              <p className="text-sm text-foreground-400">—</p>
            )}
          </BilgiKutu>
        </div>

        {/* Kaydet */}
        <div className="flex flex-col justify-center gap-1 lg:w-[280px] flex-shrink-0">
          <button
            type="button"
            onClick={onKaydet}
            disabled={saving || kaydetSayisi === 0}
            className="w-full isg-btn isg-btn-primary justify-center whitespace-nowrap cursor-pointer disabled:opacity-50"
          >
            {saving ? (
              <>
                <span className="w-4 h-4 border-2 border-inverse/70 border-t-transparent rounded-full animate-spin" />
                {progressText ?? 'Hazırlanıyor…'}
              </>
            ) : (
              <>
                <i className="ri-save-3-line" /> {kaydetSayisi} Belgeyi Kaydet
              </>
            )}
          </button>
          <p className="isg-text-caption text-foreground-400 text-center truncate">
            {toplamSayfa} sayfa • {kaydetSayisi} belge
          </p>
        </div>
      </div>

      {/* Özel belge türü adı */}
      {aktifGrup && isCustom && (
        <div className="mt-2.5">
          <Input
            label="Özel Belge Türü Adı"
            required
            value={aktifGrup.ozelBelgeTuru}
            onChange={(e) => onUpdateGrup(aktifGrup.id, { ozelBelgeTuru: e.target.value, saveError: null })}
            placeholder="Örn. Kurs Katılım Sertifikası"
            disabled={saving}
          />
        </div>
      )}

      {/* Aktif grubun hata mesajı */}
      {aktifGrup?.saveError && (
        <p className="mt-2 flex items-start gap-1 text-xs text-danger-600">
          <i className="ri-error-warning-line mt-px shrink-0" /> {aktifGrup.saveError}
        </p>
      )}
    </div>
  );
}