/**
 * Toplu Evrak — belge grubu modeli.
 *
 * Bir grup = seçili PDF sayfaları + personel + belge türü (veya özel belge türü).
 * Kaydetme durumu (saved / savedEvrakId / saveError) kısmi başarı ve idempotency
 * için grupta tutulur.
 */
export const OZEL_TYPE_VALUE = '__ozel__';

export interface BelgeGrubu {
  id: string;
  /** 1 tabanlı, artan sıralı kaynak sayfa numaraları. */
  pages: number[];
  personelId: string | null;
  /** '' | evrak türü id'si | OZEL_TYPE_VALUE. */
  typeValue: string;
  /** "Diğer / Özel Belge Türü" seçildiğinde kullanıcının yazdığı tür adı. */
  ozelBelgeTuru: string;
  saved: boolean;
  savedEvrakId: string | null;
  saveError: string | null;
}

let groupSeq = 0;

/** Yeni grup kimliği (crypto.randomUUID yoksa deterministik fallback). */
export function newGroupId(): string {
  groupSeq += 1;
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `grp-${Date.now()}-${groupSeq}`;
}

/** Sayfa listesinden okunur aralık etiketi üretir: "1 – 3. sayfalar" / "5. sayfa". */
export function sayfaAralikEtiketi(pages: number[]): string {
  if (pages.length === 0) return 'Sayfa yok';
  const sorted = [...pages].sort((a, b) => a - b);
  if (sorted.length === 1) return `${sorted[0]}. sayfa`;
  return `${sorted[0]} – ${sorted[sorted.length - 1]}. sayfalar`;
}

/** Grup eksiksiz mi? Eksikse kullanıcıya gösterilecek mesajı döndürür. */
export function grupHatasi(g: BelgeGrubu, digerTuruId: string | null): string | null {
  if (g.pages.length === 0) return 'Bu gruba sayfa eklenmedi.';
  if (!g.personelId) return 'Personel seçilmedi.';
  if (!g.typeValue) return 'Belge türü seçilmedi.';
  if (g.typeValue === OZEL_TYPE_VALUE) {
    if (!digerTuruId) return 'Sistemde "Diğer" belge türü bulunamadı.';
    if (!g.ozelBelgeTuru.trim()) return 'Özel belge türü adı girilmedi.';
  }
  return null;
}