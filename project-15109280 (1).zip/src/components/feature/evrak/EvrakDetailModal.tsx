import { useState, useEffect, useRef } from 'react';
import type { ReactNode } from 'react';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import { useModalActions } from '@/hooks/useModal';
import { useAuth } from '@/context/AuthContext';
import {
  type EvrakData,
  getEvrakUrl,
  archiveEvrak,
  restoreEvrak,
  deleteEvrak,
  fetchRevisionHistory,
  friendlyEvrakError,
} from '@/lib/evrakService';
import { fetchProfilIsimleri } from '@/lib/profilIsimService';
import {
  evrakStatusBadgeVariant,
  formatEvrakDate,
  formatEvrakDateTime,
  formatEvrakSize,
  formatKalanSure,
  evrakFileIcon,
} from './evrakUi';
import { EvrakDosyaIkonu } from './EvrakDosyaTipi';
import EvrakBelgeViewer from './EvrakBelgeViewer';
import type { EvrakBelgeViewerHandle } from './EvrakBelgeViewer';
import type { PreviewViewerState } from '@/components/feature/preview';
import EvrakUploadModal from './EvrakUploadModal';
import OcrEditorModal from './ocr/OcrEditorModal';
import { isPdf, isSupportedForOcr } from '@/lib/ocrService';

interface EvrakDetailModalProps {
  evrak: EvrakData;
  requirementTitle: string | null;
  documentTypeName: string | null;
  firmaName?: string | null;
  /** Belgeyi yükleyen kullanıcının id'si (isim detay sekmesinde çözülür). */
  uploadedBy?: string | null;
  onClose: () => void;
  onChanged?: () => void;
}

type Sekme = 'genel' | 'versiyonlar' | 'ilgili';

const SEKMELER: Array<{ key: Sekme; label: string }> = [
  { key: 'genel', label: 'Genel Bilgiler' },
  { key: 'versiyonlar', label: 'Versiyonlar' },
  { key: 'ilgili', label: 'İlgili Kayıtlar' },
];

const NAV_BTN =
  'w-7 h-7 flex items-center justify-center rounded-md text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-default';

function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 py-2 border-b border-background-200/70 dark:border-background-400/20 last:border-0">
      <span className="text-xs text-foreground-500 flex-shrink-0">{label}</span>
      <span className="text-sm text-foreground-800 text-right min-w-0 break-words">{value}</span>
    </div>
  );
}

function VersionRow({
  version,
  active,
  evrak,
  onView,
  onDownload,
  downloadingId,
}: {
  version: string;
  active: boolean;
  evrak: EvrakData;
  onView: (e: EvrakData) => void;
  onDownload: (e: EvrakData) => void;
  downloadingId: string | null;
}) {
  return (
    <div className="flex items-center justify-between gap-3 px-3 py-2 rounded-md bg-background-100 dark:bg-background-200/60">
      <div className="min-w-0 flex items-center gap-2">
        <i className={`${evrakFileIcon(evrak.mimeType, evrak.originalFileName)} text-foreground-500 text-sm flex-shrink-0`} />
        <div className="min-w-0">
          <p className="text-sm text-foreground-800 truncate">
            Versiyon {version}{' '}
            <span className={active ? 'text-success-600' : 'text-foreground-400'}>
              · {active ? 'Aktif' : 'Arşiv'}
            </span>
          </p>
          <p className="text-xs text-foreground-500 truncate">
            Belge {formatEvrakDate(evrak.documentDate)} · Bitiş{' '}
            {evrak.validUntil ? formatEvrakDate(evrak.validUntil) : 'Süresiz'} · Yükleme{' '}
            {formatEvrakDate(evrak.createdAt)}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-0.5 flex-shrink-0">
        <button
          type="button"
          title="Sürümü görüntüle"
          aria-label="Sürümü görüntüle"
          className={NAV_BTN}
          onClick={() => onView(evrak)}
        >
          <i className="ri-eye-line text-sm" />
        </button>
        <button
          type="button"
          title="Sürümü indir"
          aria-label="Sürümü indir"
          className={NAV_BTN}
          onClick={() => onDownload(evrak)}
        >
          <i className={`ri-download-2-line text-sm ${downloadingId === evrak.id ? 'animate-pulse' : ''}`} />
        </button>
      </div>
    </div>
  );
}

/**
 * Evrak Detay Modalı — belge görüntüleyici + bilgi sekmeleri (Evraklar sekmesi detay görünümü).
 *
 * Sol: belge önizlemesi (PDF için sol sayfa küçük resimleri + zoom, görsel için önizleme,
 * Word için satır içi görünüm). Sağ: "Genel Bilgiler / Versiyonlar / İlgili Kayıtlar"
 * sekmeleri. Üstte sayfa gezinme, altta Dosyayı İndir / Düzenle / Yeni Versiyon / Kapat.
 *
 * Veri/mutation akışı MEVCUT merkezi servisler üzerinden yürür (getEvrakUrl, archiveEvrak,
 * supersede/upload, fetchRevisionHistory). Orijinal belge her zaman korunur; "Yeni Versiyon"
 * eski sürümü arşivleyip zinciri (previous_document_id + revision_no) korur.
 */
export default function EvrakDetailModal({
  evrak,
  requirementTitle,
  documentTypeName,
  firmaName,
  uploadedBy,
  onClose,
  onChanged,
}: EvrakDetailModalProps) {
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const { openModal, closeModal } = useModalActions();
  const { profile } = useAuth();

  const viewerRef = useRef<EvrakBelgeViewerHandle>(null);
  const [sekme, setSekme] = useState<Sekme>('genel');
  const [viewerState, setViewerState] = useState<PreviewViewerState>({ page: 1, count: 1, zoom: 1, rotation: 0 });
  const [downloading, setDownloading] = useState(false);
  const [downloadingId, setDownloadingId] = useState<string | null>(null);
  const [archiving, setArchiving] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [history, setHistory] = useState<EvrakData[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [uploaderName, setUploaderName] = useState<string | null>(null);

  // Belgeyi yükleyen kullanıcının adını (kapsam kontrollü) çöz.
  useEffect(() => {
    if (!uploadedBy) {
      setUploaderName(null);
      return;
    }
    let cancelled = false;
    fetchProfilIsimleri([uploadedBy])
      .then((m) => {
        if (!cancelled) setUploaderName(m[uploadedBy]?.name ?? null);
      })
      .catch(() => {
        if (!cancelled) setUploaderName(null);
      });
    return () => {
      cancelled = true;
    };
  }, [uploadedBy]);

  const pdf = isPdf(evrak.mimeType);
  const currentVersion = evrak.revisionNo ?? 1;

  // Revizyon zinciri: bu belgenin eski sürümleri (previous_document_id geriye doğru).
  useEffect(() => {
    if (!evrak.previousDocumentId) {
      setHistory([]);
      return;
    }
    let cancelled = false;
    setHistoryLoading(true);
    fetchRevisionHistory(evrak.id)
      .then((list) => {
        if (!cancelled) setHistory(list);
      })
      .catch(() => {
        if (!cancelled) setHistory([]);
      })
      .finally(() => {
        if (!cancelled) setHistoryLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [evrak.id, evrak.previousDocumentId]);

  const uploadRole = profile?.role === 'firma' ? 'firma' : profile?.role === 'hekim' ? 'hekim' : 'uzman';
  // Yeni sürüm/arşiv: yalnızca firma seviyesi evraklar için, hekim dışı roller, arşivlenmemiş.
  // requirementId zorunluluğu KALDIRILDI — manuel yüklenmiş (yükümlülüğe bağlanmamış) firma
  // evraklarında da "Yeni Versiyon" akışı çalışır (backend previous_document_id zincirini korur).
  const canNewVersion =
    evrak.ownerType === 'firma' &&
    evrak.status !== 'archived' &&
    profile?.role !== 'hekim';
  const canEdit = canNewVersion && isSupportedForOcr(evrak.mimeType);
  // Fiziksel silme yalnızca OSGB tarafı için: uzman (asıl atama) / admin / osgb_admin.
  const canDelete = !!profile?.role && ['admin', 'osgb_admin', 'uzman'].includes(profile.role as string);

  const openSignedUrl = async (target: EvrakData) => {
    try {
      const url = await getEvrakUrl(target.id);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
      addToast({ title: 'Dosya açılamadı', message: friendlyEvrakError(e), type: 'error' });
    }
  };

  const handleDownload = async () => {
    setDownloading(true);
    await openSignedUrl(evrak);
    setDownloading(false);
  };

  const handleDownloadVersion = async (target: EvrakData) => {
    setDownloadingId(target.id);
    await openSignedUrl(target);
    setDownloadingId(null);
  };

  // Eski sürümü görüntüle: yeni bir sekmeye sürümün kendisini açar (mevcut zincir korunur).
  const handleViewVersion = async (target: EvrakData) => {
    await openSignedUrl(target);
  };

  const handleArchive = () => {
    confirm({
      title: 'Evrakı Arşivle',
      message: `"${evrak.title}" arşivlenecek. Dosya silinmez; geçmiş korunur ve gereksinim hesabında artık sayılmaz.`,
      variant: 'danger',
      confirmText: 'Evet, Arşivle',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setArchiving(true);
        archiveEvrak(evrak.id)
          .then(() => {
            addToast({ title: 'Arşivlendi', message: 'Evrak arşivlendi.', type: 'success' });
            onChanged?.();
            onClose();
          })
          .catch((e) => addToast({ title: 'Arşivleme başarısız', message: friendlyEvrakError(e), type: 'error' }))
          .finally(() => setArchiving(false));
      },
    });
  };

  const handleRestore = () => {
    confirm({
      title: 'Arşivden Çıkar',
      message: `"${evrak.title}" yeniden aktif duruma döndürülecek ve geçerliliği yeniden hesaplanacak.`,
      variant: 'info',
      confirmText: 'Evet, Çıkar',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setRestoring(true);
        restoreEvrak(evrak.id)
          .then(() => {
            addToast({ title: 'Arşivden çıkarıldı', message: 'Evrak yeniden aktif duruma döndü.', type: 'success' });
            onChanged?.();
            onClose();
          })
          .catch((e) => addToast({ title: 'İşlem başarısız', message: friendlyEvrakError(e), type: 'error' }))
          .finally(() => setRestoring(false));
      },
    });
  };

  const handleDelete = () => {
    confirm({
      title: 'Evrakı Sil',
      message: `"${evrak.title}" kalıcı olarak silinecek. Dosya da kaldırılır; bu işlem geri alınamaz.`,
      variant: 'danger',
      confirmText: 'Evet, Kalıcı Sil',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setDeleting(true);
        deleteEvrak(evrak.id)
          .then(() => {
            addToast({ title: 'Silindi', message: 'Evrak kalıcı olarak silindi.', type: 'success' });
            onChanged?.();
            onClose();
          })
          .catch((e) => addToast({ title: 'Silinemedi', message: friendlyEvrakError(e), type: 'error' }))
          .finally(() => setDeleting(false));
      },
    });
  };

  const handleNewVersion = () => {
    const id = openModal({
      title: 'Yeni Sürüm Yükle',
      description: `"${evrak.title}" belgesinin yeni sürümünü yükleyin. Eski sürüm (V${currentVersion}) arşivde kalacak.`,
      width: 560,
      minWidth: 420,
      minHeight: 480,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EvrakUploadModal
          role={uploadRole}
          previousEvrak={evrak}
          previousEvrakId={evrak.id}
          onClose={() => closeModal(id)}
          onUploaded={() => {
            addToast({
              title: 'Yeni sürüm aktif',
              message: `V${currentVersion + 1} aktifleştirildi, eski sürüm arşivlendi.`,
              type: 'success',
            });
            onChanged?.();
            onClose();
          }}
        />
      ),
    });
  };

  const handleEdit = () => {
    const id = openModal({
      title: 'Belgeyi Düzenle',
      description: 'Belge içeriği çıkarılır, düzenlenir ve yeni sürüm olarak kaydedilir. Orijinal belge korunur.',
      variant: 'large',
      width: 1200,
      height: 820,
      minWidth: 720,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <OcrEditorModal
          evrak={evrak}
          onClose={() => closeModal(id)}
          onSaved={() => {
            onChanged?.();
            onClose();
          }}
        />
      ),
    });
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Üst şerit: dosya türü + durum + sürüm | sayfa gezinme */}
      <div className="flex items-center justify-between gap-3 pb-2 border-b border-background-300/40 dark:border-background-400/25 flex-shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <EvrakDosyaIkonu mime={evrak.mimeType} name={evrak.originalFileName} size="sm" />
          <div className="flex items-center gap-1.5 min-w-0">
            <Badge variant={evrakStatusBadgeVariant(evrak.status)}>{evrak.statusLabel}</Badge>
            <span className="text-xs px-2 py-0.5 rounded-md bg-background-200 dark:bg-background-300/40 text-foreground-600 font-medium whitespace-nowrap">
              v{currentVersion}
            </span>
          </div>
        </div>
        {pdf && (
          <div className="flex items-center gap-1 flex-shrink-0">
            <button
              type="button"
              className={NAV_BTN}
              onClick={() => viewerRef.current?.prev()}
              disabled={viewerState.page <= 1}
              title="Önceki sayfa"
              aria-label="Önceki sayfa"
            >
              <i className="ri-arrow-left-s-line text-base" />
            </button>
            <span className="text-xs tabular-nums text-foreground-600 w-12 text-center">
              {viewerState.page} / {viewerState.count}
            </span>
            <button
              type="button"
              className={NAV_BTN}
              onClick={() => viewerRef.current?.next()}
              disabled={viewerState.page >= viewerState.count}
              title="Sonraki sayfa"
              aria-label="Sonraki sayfa"
            >
              <i className="ri-arrow-right-s-line text-base" />
            </button>
          </div>
        )}
      </div>

      {/* Gövde: görüntüleyici + bilgi sekmeleri */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row gap-3 pt-3">
        <div className="flex-1 min-w-0 h-[56vh] lg:h-auto lg:min-h-0 rounded-lg border border-background-300/40 dark:border-background-400/25 overflow-hidden bg-background-50 dark:bg-background-200/30">
          <EvrakBelgeViewer ref={viewerRef} evrak={evrak} onState={setViewerState} />
        </div>

        <div className="w-full lg:w-[340px] flex-shrink-0 flex flex-col max-h-[44vh] lg:max-h-none lg:min-h-0 rounded-lg border border-background-300/40 dark:border-background-400/25 overflow-hidden">
          <div className="flex border-b border-background-300/40 dark:border-background-400/25 flex-shrink-0">
            {SEKMELER.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setSekme(t.key)}
                className={`flex-1 px-2 py-2.5 text-xs font-medium whitespace-nowrap transition-colors cursor-pointer border-b-2 ${
                  sekme === t.key
                    ? 'text-primary-600 border-primary-500'
                    : 'text-foreground-500 border-transparent hover:text-foreground-800'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto p-3 min-h-0">
            {sekme === 'genel' && (
              <div className="flex flex-col">
                <InfoRow label="Evrak Adı" value={evrak.title} />
                <InfoRow label="Evrak Türü" value={documentTypeName ?? '—'} />
                <InfoRow label="Firma" value={firmaName ?? '—'} />
                <InfoRow label="İlgili Yükümlülük" value={requirementTitle ?? '—'} />
                <InfoRow label="Belge Tarihi" value={formatEvrakDate(evrak.documentDate)} />
                <InfoRow label="Geçerlilik Başlangıcı" value={formatEvrakDate(evrak.validFrom)} />
                <InfoRow
                  label="Geçerlilik Bitişi"
                  value={evrak.validUntil ? formatEvrakDate(evrak.validUntil) : 'Süresiz'}
                />
                <InfoRow label="Kalan Süre" value={formatKalanSure(evrak.validUntil)} />
                <InfoRow label="Durum" value={<Badge variant={evrakStatusBadgeVariant(evrak.status)}>{evrak.statusLabel}</Badge>} />
                <InfoRow label="Dosya Boyutu" value={formatEvrakSize(evrak.fileSize)} />
                <InfoRow label="Dosya Adı" value={evrak.originalFileName ?? '—'} />
                <InfoRow label="Yüklenme Tarihi" value={formatEvrakDateTime(evrak.createdAt)} />
                <InfoRow label="Son Güncelleme" value={formatEvrakDateTime(evrak.updatedAt)} />
                <InfoRow label="Yükleyen" value={uploaderName ?? '—'} />

                {evrak.description && (
                  <div className="mt-3">
                    <p className="text-xs text-foreground-500 mb-1">Açıklama</p>
                    <p className="text-sm text-foreground-700 whitespace-pre-wrap">{evrak.description}</p>
                  </div>
                )}
              </div>
            )}

            {sekme === 'versiyonlar' && (
              <div className="flex flex-col gap-1.5">
                {historyLoading && <p className="text-xs text-foreground-500">Versiyon geçmişi yükleniyor…</p>}
                <VersionRow
                  version={String(currentVersion)}
                  active
                  evrak={evrak}
                  onView={handleViewVersion}
                  onDownload={handleDownloadVersion}
                  downloadingId={downloadingId}
                />
                {history.map((h) => (
                  <VersionRow
                    key={h.id}
                    version={h.revisionNo != null ? String(h.revisionNo) : '—'}
                    active={false}
                    evrak={h}
                    onView={handleViewVersion}
                    onDownload={handleDownloadVersion}
                    downloadingId={downloadingId}
                  />
                ))}
                {!historyLoading && history.length === 0 && (
                  <p className="text-xs text-foreground-500 px-1 py-2">
                    Bu belgenin eski bir sürümü yok. İlk sürüm (V{currentVersion}) geçerli.
                  </p>
                )}
              </div>
            )}

            {sekme === 'ilgili' && (
              <div className="flex flex-col">
                <InfoRow label="Firma" value={firmaName ?? '—'} />
                <InfoRow label="İlgili Yükümlülük" value={requirementTitle ?? '—'} />
                <InfoRow label="Evrak Türü" value={documentTypeName ?? '—'} />
                <InfoRow label="Sahiplik" value={evrak.ownerTypeLabel} />
                <InfoRow label="Firma Görünürlüğü" value={evrak.firmVisible ? 'Firmaya açık' : 'Yalnızca OSGB'} />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Alt aksiyonlar */}
      <div className="flex items-center justify-between gap-2 pt-3 mt-3 border-t border-background-300/40 dark:border-background-400/25 flex-shrink-0 flex-wrap">
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            leftIcon={<i className="ri-download-2-line" />}
            onClick={handleDownload}
            disabled={!evrak.originalFileName}
            isLoading={downloading}
          >
            Dosyayı İndir
          </Button>
          {evrak.status === 'archived' ? (
            <Button
              variant="ghost"
              size="sm"
              leftIcon={<i className="ri-inbox-unarchive-line" />}
              onClick={handleRestore}
              isLoading={restoring}
            >
              Arşivden Çıkar
            </Button>
          ) : (
            <Button
              variant="ghost"
              size="sm"
              leftIcon={<i className="ri-archive-line" />}
              onClick={handleArchive}
              isLoading={archiving}
            >
              Arşivle
            </Button>
          )}
          {canDelete && (
            <Button
              variant="ghost"
              size="sm"
              leftIcon={<i className="ri-delete-bin-line" />}
              onClick={handleDelete}
              isLoading={deleting}
            >
              Sil
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2 flex-wrap justify-end">
          {canEdit && (
            <Button variant="secondary" size="sm" leftIcon={<i className="ri-edit-line" />} onClick={handleEdit}>
              Düzenle
            </Button>
          )}
          {canNewVersion && (
            <Button
              variant="secondary"
              size="sm"
              leftIcon={<i className="ri-upload-cloud-2-line" />}
              onClick={handleNewVersion}
            >
              Yeni Versiyon
            </Button>
          )}
          <Button variant="primary" size="sm" onClick={onClose}>
            Kapat
          </Button>
        </div>
      </div>
    </div>
  );
}