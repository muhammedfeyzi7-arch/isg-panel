import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import EmptyState from '@/components/ui/EmptyState';
import ContextMenu from '@/components/ui/ContextMenu';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import {
  DocumentPreviewEngine,
  detectPreviewKind,
  type PreviewDocumentSource,
} from '@/components/feature/preview';
import { base64ToArrayBuffer } from '@/lib/ocrService';
import {
  type EvrakData,
  type FirmaKlasor,
  getEvrakContent,
  getEvrakUrl,
  fetchRevisionHistory,
  deleteEvrak,
  friendlyEvrakError,
} from '@/lib/evrakService';
import { EvrakDosyaIkonu, evrakDosyaTurEtiket } from './EvrakDosyaTipi';
import { downloadBytesFile, sanitizeFilename, resolveExtension } from '@/lib/downloadFile';
import { evrakDurumGorunum, formatEvrakDate, formatEvrakDateTime, formatEvrakSize, formatKalanSure } from './evrakUi';
import EvrakEkleModal from './EvrakEkleModal';
import { KlasorDegistirForm, BilgileriDuzenleForm } from './EvrakBelgeActions';

interface EvrakBelgeModalProps {
  evrak: EvrakData;
  firmaId: string;
  role: 'uzman' | 'firma' | 'hekim';
  klasorler: FirmaKlasor[];
  /** Görüntüleme amaçlı çözümlenmiş adlar (iş mantığı değil). */
  turName?: string | null;
  kategoriName?: string | null;
  altKategoriName?: string | null;
  klasorName?: string | null;
  uploaderName?: string | null;
  onChanged?: () => void;
  /**
   * Tutanak türü (is_tutanak) belgeler için SALT-OKUNUR lifecycle. Bu modda imza/
   * revizyon yükleme ve silme aksiyonları GİZLENİR; belge yalnızca görüntülenir/
   * indirilir. Tutanakların özel durum/imza/revizyon akışı mevcut Tutanaklar
   * modülünde kalır (tek doğruluk kaynağı).
   */
  lifecycleLocked?: boolean;
}

type Sekme = 'bilgi' | 'islemler' | 'gecmis';

const SEKMELER: { key: Sekme; label: string; icon: string }[] = [
  { key: 'bilgi', label: 'Belge Bilgileri', icon: 'ri-file-info-line' },
  { key: 'islemler', label: 'İşlemler', icon: 'ri-tools-line' },
  { key: 'gecmis', label: 'Geçmiş', icon: 'ri-history-line' },
];

/** Tarayıcının doğrudan yazdırabildiği türleri (PDF/görsel) gizli iframe ile yazdırır. */
function printBytes(bytes: ArrayBuffer, mime: string | null): void {
  const blob = new Blob([bytes], { type: mime || 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const iframe = document.createElement('iframe');
  iframe.setAttribute('aria-hidden', 'true');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.src = url;
  iframe.onload = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      /* yoksay */
    }
  };
  document.body.appendChild(iframe);
  window.setTimeout(() => {
    if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
    URL.revokeObjectURL(url);
  }, 60000);
}

function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1.5 border-b border-background-200/60 dark:border-background-400/15 last:border-0">
      <span className="text-xs text-foreground-500 flex-shrink-0">{label}</span>
      <span className="text-sm text-foreground-800 text-right min-w-0 break-words">{value}</span>
    </div>
  );
}

function InfoCard({ title, icon, children }: { title: string; icon: string; children: ReactNode }) {
  return (
    <div className="rounded-lg border border-background-300/40 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-3">
      <div className="flex items-center gap-1.5 mb-1.5">
        <i className={`${icon} text-primary-500 text-sm`} />
        <p className="text-[0.6875rem] font-semibold text-foreground-600 uppercase tracking-wide">{title}</p>
      </div>
      <div className="flex flex-col">{children}</div>
    </div>
  );
}

function ActionTile({
  icon,
  label,
  onClick,
  tone = 'default',
  disabled,
}: {
  icon: string;
  label: string;
  onClick: () => void;
  tone?: 'default' | 'primary' | 'danger';
  disabled?: boolean;
}) {
  const toneCls =
    tone === 'primary'
      ? 'border-primary-200/70 text-primary-700 hover:bg-primary-50 dark:border-primary-500/25 dark:text-primary-300 dark:hover:bg-primary-500/10'
      : tone === 'danger'
      ? 'border-danger-200/70 text-danger-600 hover:bg-danger-50 dark:border-danger-500/25 dark:text-danger-400 dark:hover:bg-danger-500/10'
      : 'border-background-300/60 text-foreground-700 hover:bg-background-100 dark:border-background-400/30 dark:hover:bg-background-200/50';
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium whitespace-nowrap transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-default ${toneCls}`}
    >
      <i className={`${icon} text-base`} />
      <span className="truncate">{label}</span>
    </button>
  );
}

/**
 * ORTAK BELGE ÖNİZLEME MODALI (referans birebir).
 *
 * Merkezi önizleme motorunu (DocumentPreviewEngine) kullanır: gerçek PDF/görsel/Word/
 * Excel önizlemesi + sayfa thumbnailleri + zoom/döndür/tam ekran/indir. Belge HTML ile
 * SAHTE olarak yeniden çizilmez — gerçek dosya render edilir. Sağ panel üç sekmelidir:
 * Belge Bilgileri · İşlemler · Geçmiş (revizyon). Eski revizyonlar korunur ve incelenebilir.
 */
export default function EvrakBelgeModal({
  evrak,
  firmaId,
  role,
  klasorler,
  turName,
  kategoriName,
  altKategoriName,
  klasorName,
  uploaderName,
  onChanged,
  lifecycleLocked = false,
}: EvrakBelgeModalProps) {
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const { openModal, closeModal } = useModalActions();

  const [sekme, setSekme] = useState<Sekme>('bilgi');
  const [history, setHistory] = useState<EvrakData[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [busy, setBusy] = useState(false);

  const durum = evrakDurumGorunum(evrak.status, evrak.validUntil);
  const isFirmaDoc = evrak.ownerType === 'firma';
  // "Yeni sürüm / revizyon" OSGB tarafına (uzman/hekim/admin) aittir; firma rolü
  // backend'de supersede yetkisine sahip DEĞİLDİR → buton gösterilmez.
  const canRevision = isFirmaDoc && evrak.status !== 'archived' && role !== 'firma' && !lifecycleLocked;
  const canDelete = role !== 'firma' && !lifecycleLocked;
  const currentRev = evrak.revisionNo ?? 1;
  const modalIdsRef = useRef<string[]>([]);

  useEffect(() => {
    let cancelled = false;
    setHistoryLoading(true);
    fetchRevisionHistory(evrak.id)
      .then((list) => {
        if (!cancelled) setHistory(list);
      })
      .catch(() => {
        if (!cancelled) setHistory([]);
      })
      .finally(() => {
        if (!cancelled) setHistoryLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [evrak.id]);

  const source: PreviewDocumentSource = useMemo(
    () => ({
      cacheKey: `${evrak.id}:${evrak.revisionNo ?? 1}`,
      fileName: evrak.originalFileName ?? evrak.title ?? 'belge',
      mimeType: evrak.mimeType,
      fileSize: evrak.fileSize,
      getBytes: async () => base64ToArrayBuffer((await getEvrakContent(evrak.id)).fileBase64),
    }),
    [evrak.id, evrak.revisionNo, evrak.originalFileName, evrak.title, evrak.mimeType, evrak.fileSize],
  );

  const kind = detectPreviewKind(evrak.mimeType, evrak.originalFileName ?? evrak.title ?? '');
  const canPrint = kind === 'pdf' || kind === 'image';

  const handleDownload = useCallback(async () => {
    setBusy(true);
    try {
      // Yeni sekme AÇILMAZ; içerik (yetkili) alınır ve ANLAMLI adla indirilir.
      const c = await getEvrakContent(evrak.id);
      const bytes = base64ToArrayBuffer(c.fileBase64);
      const mime = c.mimeType ?? evrak.mimeType;
      const ext = resolveExtension(evrak.originalFileName, mime);
      const name = sanitizeFilename(`${evrak.title || 'Belge'}${ext ? `.${ext}` : ''}`, { fallback: 'Belge' });
      downloadBytesFile(bytes, mime, name);
    } catch (e) {
      addToast({ title: 'Dosya indirilemedi', message: friendlyEvrakError(e), type: 'error' });
    } finally {
      setBusy(false);
    }
  }, [evrak.id, evrak.mimeType, evrak.originalFileName, evrak.title, addToast]);

  const handlePrint = useCallback(async () => {
    try {
      const c = await getEvrakContent(evrak.id);
      printBytes(base64ToArrayBuffer(c.fileBase64), c.mimeType ?? evrak.mimeType);
    } catch (e) {
      addToast({ title: 'Yazdırma başarısız', message: friendlyEvrakError(e), type: 'error' });
    }
  }, [evrak.id, evrak.mimeType, addToast]);

  const handleShare = useCallback(async () => {
    try {
      const url = await getEvrakUrl(evrak.id);
      await navigator.clipboard.writeText(url);
      addToast({ title: 'Bağlantı kopyalandı', message: 'Belge bağlantısı panoya kopyalandı.', type: 'success' });
    } catch (e) {
      addToast({ title: 'Paylaşılamadı', message: friendlyEvrakError(e), type: 'error' });
    }
  }, [evrak.id, addToast]);

  const handleNewRevision = useCallback(() => {
    const id = openModal({
      title: 'Revizyon Yükle',
      description: `"${evrak.title}" belgesinin yeni revizyonunu yükleyin. Eski revizyon (R${currentRev}) geçmişte korunur.`,
      variant: 'large',
      width: 720,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EvrakEkleModal
          firmaId={firmaId}
          role={role}
          initialEvrak={evrak}
          revisionOf={evrak}
          onClose={() => closeModal(id)}
          onUploaded={() => {
            addToast({
              title: 'Yeni revizyon aktif',
              message: `R${currentRev + 1} aktifleştirildi; R${currentRev} geçmişte korundu.`,
              type: 'success',
            });
            onChanged?.();
          }}
        />
      ),
    });
    modalIdsRef.current.push(id);
  }, [openModal, closeModal, firmaId, role, evrak, currentRev, addToast, onChanged]);

  const handleChangeKlasor = useCallback(() => {
    const id = openModal({
      title: 'Klasör Değiştir',
      description: evrak.title,
      width: 460,
      minWidth: 360,
      minHeight: 240,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <KlasorDegistirForm
          evrakId={evrak.id}
          currentKlasorId={evrak.klasorId}
          klasorler={klasorler}
          onClose={() => closeModal(id)}
          onSaved={onChanged}
        />
      ),
    });
    modalIdsRef.current.push(id);
  }, [openModal, closeModal, evrak, klasorler, onChanged]);

  const handleEditInfo = useCallback(() => {
    const id = openModal({
      title: 'Bilgileri Düzenle',
      description: evrak.title,
      width: 520,
      minWidth: 400,
      minHeight: 320,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <BilgileriDuzenleForm
          evrakId={evrak.id}
          initialTitle={evrak.title}
          initialDescription={evrak.description}
          onClose={() => closeModal(id)}
          onSaved={onChanged}
        />
      ),
    });
    modalIdsRef.current.push(id);
  }, [openModal, closeModal, evrak, onChanged]);

  const handleDelete = useCallback(() => {
    confirm({
      title: 'Belgeyi Sil',
      message: `"${evrak.title}" kalıcı olarak silinecek. Dosya da kaldırılır; bu işlem geri alınamaz.`,
      variant: 'danger',
      confirmText: 'Evet, Kalıcı Sil',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        deleteEvrak(evrak.id)
          .then(() => {
            addToast({ title: 'Silindi', message: 'Belge kalıcı olarak silindi.', type: 'success' });
            onChanged?.();
          })
          .catch((e) => addToast({ title: 'Silinemedi', message: friendlyEvrakError(e), type: 'error' }));
      },
    });
  }, [confirm, addToast, evrak.id, evrak.title, onChanged]);

  const revizyonlar = useMemo(() => [evrak, ...history], [evrak, history]);

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* BELGE BAŞLIK ALANI — ikon + ad + dosya adı + badge'ler + indir */}
      <div className="flex items-center gap-3 pb-2.5 border-b border-background-300/40 dark:border-background-400/25 flex-shrink-0">
        <EvrakDosyaIkonu mime={evrak.mimeType} name={evrak.originalFileName} size="md" />
        <div className="min-w-0 flex-1">
          <h3 className="text-base font-semibold text-foreground-950 leading-tight truncate">{evrak.title}</h3>
          <p className="text-xs text-foreground-500 mt-0.5 truncate">{evrak.originalFileName ?? '—'}</p>
        </div>
        <div className="flex items-center gap-1.5 flex-shrink-0">
          <Badge variant={durum.variant}>{durum.label}</Badge>
          <Badge variant="secondary">Revizyon {currentRev}</Badge>
          <Button
            variant="primary"
            size="sm"
            className="whitespace-nowrap"
            leftIcon={<i className="ri-download-2-line" />}
            onClick={handleDownload}
            isLoading={busy}
            disabled={!evrak.originalFileName}
          >
            İndir
          </Button>
          <ContextMenu
            triggerIcon="ri-more-2-fill"
            items={[
              { label: 'Yazdır', icon: 'ri-printer-line', onClick: handlePrint },
              { label: 'Paylaş', icon: 'ri-share-line', onClick: handleShare },
              ...(canRevision ? [{ label: 'Revizyon Yükle', icon: 'ri-upload-cloud-2-line', onClick: handleNewRevision }] : []),
              ...(canDelete ? [{ label: 'Sil', icon: 'ri-delete-bin-line', variant: 'danger' as const, onClick: handleDelete }] : []),
            ]}
          />
        </div>
      </div>

      {lifecycleLocked && (
        <div className="mt-2.5 flex items-start gap-2 rounded-lg border border-secondary-200/70 bg-secondary-50 dark:bg-secondary-500/10 dark:border-secondary-500/25 px-3 py-2 flex-shrink-0">
          <span className="w-5 h-5 flex items-center justify-center flex-shrink-0 text-secondary-600 dark:text-secondary-300">
            <i className="ri-lock-2-line text-sm" />
          </span>
          <p className="text-xs text-foreground-600 leading-relaxed">
            Bu belge <strong className="font-semibold text-foreground-800">Tutanaklar / Saha Denetimleri</strong> modülü tarafından yönetilir. İmza, revizyon ve durum işlemleri ilgili modülden yapılır; burada yalnızca görüntüleme, indirme ve paylaşma yapılabilir.
          </p>
        </div>
      )}

      {/* GÖVDE — önizleme + sağ sekmeli bilgi paneli */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row gap-3 pt-3">
        <div className="flex-1 min-w-0 min-h-[360px] rounded-lg border border-background-300/40 dark:border-background-400/25 overflow-hidden bg-background-50 dark:bg-background-200/30 flex flex-col">
          {evrak.originalFileName ? (
            <DocumentPreviewEngine
              key={evrak.id}
              source={source}
              title={evrak.title}
              onDownload={handleDownload}
              downloadBusy={busy}
              className="flex-1 min-h-0"
            />
          ) : (
            <EmptyState
              icon="ri-file-unknow-line"
              title="Önizlenecek belge yok"
              description="Bu evrak için yüklenmiş bir dosya bulunmuyor."
            />
          )}
        </div>

        <div className="w-full lg:w-[380px] flex-shrink-0 flex flex-col min-h-[360px] rounded-lg border border-background-300/40 dark:border-background-400/25 overflow-hidden">
          {/* Sekme çubuğu */}
          <div className="flex border-b border-background-300/40 dark:border-background-400/25 flex-shrink-0">
            {SEKMELER.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setSekme(t.key)}
                className={`flex-1 inline-flex items-center justify-center gap-1.5 px-2 py-2.5 text-xs font-medium whitespace-nowrap transition-colors cursor-pointer border-b-2 ${
                  sekme === t.key
                    ? 'text-primary-600 border-primary-500'
                    : 'text-foreground-500 border-transparent hover:text-foreground-800'
                }`}
              >
                <i className={`${t.icon} text-sm`} />
                {t.label}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto p-3 min-h-0 flex flex-col gap-3">
            {sekme === 'bilgi' && (
              <>
                <InfoCard title="Temel Bilgiler" icon="ri-file-info-line">
                  <InfoRow label="Belge Adı" value={evrak.title} />
                  <InfoRow label="Kategori" value={kategoriName ?? '—'} />
                  {altKategoriName && <InfoRow label="Alt Kategori" value={altKategoriName} />}
                  <InfoRow label="Klasör" value={klasorName ?? '—'} />
                  <InfoRow label="Belge Türü" value={turName ?? '—'} />
                  <InfoRow label="Dosya Türü" value={evrakDosyaTurEtiket(evrak.mimeType, evrak.originalFileName)} />
                  <InfoRow label="Dosya Boyutu" value={formatEvrakSize(evrak.fileSize)} />
                  <InfoRow label="Yükleme Tarihi" value={formatEvrakDateTime(evrak.createdAt)} />
                  <InfoRow label="Yükleyen" value={uploaderName ?? 'Kullanıcı'} />
                  <InfoRow label="Revizyon No" value={String(currentRev)} />
                  <InfoRow label="Durum" value={<Badge variant={durum.variant}>{durum.label}</Badge>} />
                  <InfoRow label="Geçerlilik Bitişi" value={evrak.validUntil ? formatEvrakDate(evrak.validUntil) : 'Süresiz'} />
                  <InfoRow label="Kalan Süre" value={formatKalanSure(evrak.validUntil)} />
                </InfoCard>

                <InfoCard title="Açıklama" icon="ri-text">
                  <p className="text-sm text-foreground-700 whitespace-pre-wrap py-0.5">{evrak.description || '—'}</p>
                </InfoCard>

                <div>
                  <div className="flex items-center gap-1.5 mb-1.5">
                    <i className="ri-more-line text-primary-500 text-sm" />
                    <p className="text-[0.6875rem] font-semibold text-foreground-600 uppercase tracking-wide">Diğer İşlemler</p>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {canRevision && <ActionTile icon="ri-upload-cloud-2-line" label="Revizyon Yükle" tone="primary" onClick={handleNewRevision} />}
                    <ActionTile icon="ri-folder-transfer-line" label="Klasör Değiştir" onClick={handleChangeKlasor} />
                    <ActionTile icon="ri-edit-line" label="Bilgileri Düzenle" onClick={handleEditInfo} />
                    <ActionTile icon="ri-share-line" label="Paylaş" onClick={handleShare} />
                    {canDelete && <ActionTile icon="ri-delete-bin-line" label="Sil" tone="danger" onClick={handleDelete} />}
                  </div>
                </div>
              </>
            )}

            {sekme === 'islemler' && (
              <div className="flex flex-col gap-2">
                <Button variant="secondary" size="sm" className="w-full justify-start whitespace-nowrap" leftIcon={<i className="ri-download-2-line" />} onClick={handleDownload} disabled={!evrak.originalFileName} isLoading={busy}>
                  İndir
                </Button>
                {canPrint && (
                  <Button variant="secondary" size="sm" className="w-full justify-start whitespace-nowrap" leftIcon={<i className="ri-printer-line" />} onClick={handlePrint} disabled={!evrak.originalFileName}>
                    Yazdır
                  </Button>
                )}
                <Button variant="secondary" size="sm" className="w-full justify-start whitespace-nowrap" leftIcon={<i className="ri-share-line" />} onClick={handleShare}>
                  Paylaş
                </Button>
                {canRevision && (
                  <Button variant="primary" size="sm" className="w-full justify-start whitespace-nowrap" leftIcon={<i className="ri-upload-cloud-2-line" />} onClick={handleNewRevision}>
                    Revizyon Yükle
                  </Button>
                )}
                <Button variant="secondary" size="sm" className="w-full justify-start whitespace-nowrap" leftIcon={<i className="ri-folder-transfer-line" />} onClick={handleChangeKlasor}>
                  Klasör Değiştir
                </Button>
                <Button variant="secondary" size="sm" className="w-full justify-start whitespace-nowrap" leftIcon={<i className="ri-edit-line" />} onClick={handleEditInfo}>
                  Bilgileri Düzenle
                </Button>
                {canDelete && (
                  <Button variant="ghost" size="sm" className="w-full justify-start whitespace-nowrap text-danger-600" leftIcon={<i className="ri-delete-bin-line" />} onClick={handleDelete}>
                    Sil
                  </Button>
                )}
              </div>
            )}

            {sekme === 'gecmis' && (
              <div className="flex flex-col gap-2">
                {historyLoading && <p className="text-xs text-foreground-500">Geçmiş yükleniyor…</p>}
                <ol className="flex flex-col gap-2">
                  {revizyonlar.map((rev, idx) => {
                    const aktif = idx === 0;
                    return (
                      <li key={rev.id} className="flex items-start gap-2.5 rounded-lg border border-background-300/40 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 px-3 py-2">
                        <span className="mt-0.5 w-7 h-7 rounded-full bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 text-[0.625rem] font-semibold flex items-center justify-center flex-shrink-0">
                          R{rev.revisionNo ?? 1}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-semibold text-foreground-800">
                            {aktif ? 'Belge aktif' : 'Önceki revizyon'}
                          </p>
                          <p className="text-[0.6875rem] text-foreground-500">
                            {uploaderName ?? 'Kullanıcı'} · {formatEvrakDateTime(rev.createdAt)}
                          </p>
                          {rev.validUntil && (
                            <p className="text-[0.6875rem] text-foreground-500">
                              Bitiş {formatEvrakDate(rev.validUntil)}
                            </p>
                          )}
                        </div>
                        {!aktif && (
                          <Badge variant="default">Arşiv</Badge>
                        )}
                      </li>
                    );
                  })}
                </ol>
                {!historyLoading && history.length === 0 && (
                  <p className="text-xs text-foreground-500 px-1">
                    Bu belgenin eski bir revizyonu yok. İlk revizyon (R{currentRev}) geçerli.
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}