import { useCallback, useEffect, useMemo, useState } from 'react';
import type { ChangeEvent } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import { useToastActions } from '@/hooks/useToast';
import {
  type EvrakOwnerType,
  type EvrakTuru,
  type EvrakData,
  type FirmaKlasor,
  type FirmaGereksinimi,
  fetchEvrakTurleri,
  fetchFirmaKlasorleri,
  fetchFirmaGereksinimleri,
  fetchActiveEvrakByType,
  previewEvrakValidity,
  uploadEvrak,
  assignEvrakKlasor,
  friendlyEvrakError,
  type EvrakValidityPreview,
} from '@/lib/evrakService';
import { firmaKategoriEtiket } from './kategoriUi';
import { DOCUMENT_CATEGORIES } from './documents/documentCategories';
import { formatEvrakDate, formatGecerlilikSuresi } from './evrakUi';

interface EvrakEkleModalProps {
  firmaId: string;
  role: 'uzman' | 'firma' | 'hekim';
  onClose: () => void;
  onUploaded?: () => void;
  /** "Güncelle" akışı: mevcut (süresi dolmuş) evrakın tür/klasör/açıklama bilgileri önceden dolar. */
  initialEvrak?: EvrakData | null;
  /** "Revizyon Yükle" akışı: bu belgenin yeni revizyonu doğrudan oluşturulur (mevcut değiştirme sorusu yok). */
  revisionOf?: EvrakData | null;
  /**
   * Bulunulan kategori bağlamı (Evraklar ekranındaki seçim). Kullanıcı hangi
   * kategoriden "Belge Ekle" dediyse o kategori öntanımlı gelir; manuel belge
   * bu kategori altında listelenir.
   */
  initialKategori?: string;
  /** Kategori alanı kilitli mi? (Evraklar ekranından gelindiğinde true). */
  lockKategori?: boolean;
  /** Alt kategori bağlamı (child kategori id): o alt kategoriden yüklenirken kaydedilir. */
  initialAltKategori?: string;
  /** Kilitli alt kategori için gösterilecek görünen ad. */
  altKategoriLabel?: string;
}

const MAX_SIZE = 15 * 1024 * 1024;
const ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.odt,.ods,image/jpeg,image/png,image/webp';

type ConflictChoice = 'replace' | 'draft';

/**
 * BELGE EKLE / EVRAK YÜKLE MODALI.
 *
 * Kategori ile belge türü AYRIDIR:
 *  · Kategori  → Evraklar ekranındaki sabit İSG kategorisi (Acil Durum, Risk Yönetimi, …).
 *  · Belge Adı → Kullanıcının yazdığı serbest belge adı (katalogda olmak ZORUNDA DEĞİL).
 *  · Tanımlı Belge Türü → OPSİYONEL; seçilirse firma İSG gereksinimi (evrak_türleri.code ↔
 *    isg_kurallari.rule_code) üzerinden otomatik bağlanır ve merkezi mevzuat motoru geçerlilik
 *    hesaplar. Seçilmezse belge yine kaydedilir; requirement_id boş kalır.
 *
 * Mevcut `evraklar` + Storage + `evrak` edge function altyapısı kullanılır; yeni tablo/sistem YOK.
 */
export default function EvrakEkleModal({
  firmaId,
  role,
  onClose,
  onUploaded,
  initialEvrak,
  revisionOf,
  initialKategori,
  lockKategori,
  initialAltKategori,
  altKategoriLabel,
}: EvrakEkleModalProps) {
  const { addToast } = useToastActions();
  const base = revisionOf ?? initialEvrak ?? null;
  // Alt kategori bağlamı: mevcut belgenin alt kategorisi korunur; yoksa bulunulan
  // child kategoriden gelir. Parent yüklemede null kalır.
  const altKategoriValue = base?.altKategori ?? initialAltKategori ?? null;

  const [turlar, setTurlar] = useState<EvrakTuru[]>([]);
  const [klasorler, setKlasorler] = useState<FirmaKlasor[]>([]);
  const [gereksinimler, setGereksinimler] = useState<FirmaGereksinimi[]>([]);
  const [loading, setLoading] = useState(true);

  const [kategori, setKategori] = useState(base?.kategori ?? initialKategori ?? '');
  const [documentTypeId, setDocumentTypeId] = useState(base?.documentTypeId ?? '');
  const [klasorValue, setKlasorValue] = useState(base?.klasorId ?? '');
  // Revizyon akışında belge tarihi BOŞ başlar: yeni revizyon KENDİ belge tarihinden
  // değerlendirilir; eski belgenin tarihi/kalan süresi yeni belgeye aktarılmaz.
  const [documentDate, setDocumentDate] = useState(revisionOf ? '' : (initialEvrak?.documentDate ?? ''));
  const [title, setTitle] = useState(base?.title ?? '');
  const [validUntilOverride, setValidUntilOverride] = useState<string | null>(null);
  const [description, setDescription] = useState(base?.description ?? '');
  const [file, setFile] = useState<File | null>(null);

  const [preview, setPreview] = useState<EvrakValidityPreview | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [showRuleDetail, setShowRuleDetail] = useState(false);

  const [conflict, setConflict] = useState<EvrakData | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [t, k, g] = await Promise.all([
          fetchEvrakTurleri(),
          fetchFirmaKlasorleri(firmaId, 'firma'),
          fetchFirmaGereksinimleri(firmaId),
        ]);
        if (cancelled) return;
        setTurlar(t.filter((x) => x.ownerType === 'firma'));
        setKlasorler(k);
        setGereksinimler(g);
      } catch {
        // Seçenekler yüklenemese de form açık kalır; boş picker güvenli sonuçtur.
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [firmaId]);

  // Kategori seçenekleri: mevcut kategori ağacının TEK kaynağı (fallback hariç).
  // Değer olarak kategorinin kanonik DB adı (dbKategoriler[0]) yazılır; liste filtresi
  // aynı adlar üzerinden eşleşir.
  const kategoriOptions = useMemo(
    () =>
      DOCUMENT_CATEGORIES.filter((c) => !c.fallback).map((c) => ({
        value: c.dbKategoriler[0] ?? c.name,
        label: c.name,
      })),
    [],
  );

  const turOptions = useMemo(
    () => turlar.map((t) => ({ value: t.id, label: t.name, group: t.kategori ? firmaKategoriEtiket(t.kategori) : 'Diğer' })),
    [turlar],
  );

  // Klasör seçenekleri: YALNIZCA kullanıcının kendi oluşturduğu klasörler (opsiyonel).
  // Sabit "sistem klasörleri" artık Kategori alanıyla temsil edilir.
  const klasorOptions = useMemo(
    () => klasorler.map((k) => ({ value: k.id, label: k.ad, group: 'Kullanıcı Klasörleri' })),
    [klasorler],
  );

  const selectedTur = useMemo(() => turlar.find((t) => t.id === documentTypeId) ?? null, [turlar, documentTypeId]);
  const isUserFolder = !!klasorValue;

  // Seçilen türün kodu ile eşleşen firma gereksinimi (İSG gerekliliği) — varsa bağlanır.
  const matchedRequirement = useMemo(
    () => (selectedTur ? gereksinimler.find((g) => g.requirementCode === selectedTur.code) ?? null : null),
    [selectedTur, gereksinimler],
  );

  // Tür seçilince Belge Adı boşsa otomatik doldur (kullanıcı yazdıysa dokunma).
  useEffect(() => {
    if (selectedTur?.name && !title.trim()) setTitle(selectedTur.name);
  }, [selectedTur, title]);

  // Geçerlilik önizlemesi (belge tarihi + tür değişince).
  useEffect(() => {
    if (!documentTypeId || !documentDate) {
      setPreview(null);
      return undefined;
    }
    let cancelled = false;
    setPreviewLoading(true);
    previewEvrakValidity(firmaId, documentTypeId, documentDate)
      .then((p) => {
        if (!cancelled) setPreview(p);
      })
      .catch(() => {
        if (!cancelled) setPreview(null);
      })
      .finally(() => {
        if (!cancelled) setPreviewLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [firmaId, documentTypeId, documentDate]);

  const effectiveValidUntil = validUntilOverride ?? preview?.validUntil ?? '';

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    setFile(e.target.files?.[0] ?? null);
    setError(null);
    setConflict(null);
  };

  const doUpload = useCallback(
    async (opts: { previousEvrakId?: string | null; draft?: boolean }) => {
      if (!file) return;
      setSubmitting(true);
      setError(null);
      try {
        // Revizyonda yükümlülük, ESKİ belgenin yükümlülüğüyle birebir aynı olmalı
        // (backend REQUIREMENT_MISMATCH verir). Manuel belgede (tür seçilmediyse)
        // yükümlülük OTOMATİK bağlanmaz → requirement_id boş kalır.
        const effectiveRequirementId = revisionOf
          ? revisionOf.requirementId
          : matchedRequirement?.id ?? null;
        const res = await uploadEvrak({
          ownerType: 'firma' as EvrakOwnerType,
          firmaId,
          requirementId: effectiveRequirementId,
          documentTypeId: documentTypeId || null,
          // Tür seçilmediyse manuel belge: kategoriyi kalıcı sakla. Tür seçildiyse
          // kategori türden türetilir → kategori alanı gönderilmez.
          kategori: documentTypeId ? null : (kategori || null),
          altKategori: altKategoriValue,
          title: title.trim() || selectedTur?.name || 'Belge',
          description: description.trim() || null,
          documentDate: documentDate || null,
          validUntil: validUntilOverride,
          previousEvrakId: revisionOf ? revisionOf.id : (opts.previousEvrakId ?? null),
          draft: opts.draft ?? false,
          file,
        });
        if (klasorValue) {
          try {
            await assignEvrakKlasor(res.evrakId, klasorValue);
          } catch {
            // klasöre atanamazsa evrak yine yüklenmiş kalır.
          }
        }
        addToast({
          title: opts.draft ? 'Taslak kaydedildi' : 'Belge eklendi',
          message: opts.draft
            ? 'Belge taslak olarak kaydedildi; mevcut aktif belge değişmedi.'
            : 'Belge kaydedildi; seçili kategori altında listelenir.',
          type: 'success',
        });
        onUploaded?.();
        onClose();
      } catch (e) {
        setError(friendlyEvrakError(e));
        setSubmitting(false);
      }
    },
    [file, firmaId, matchedRequirement, documentTypeId, kategori, altKategoriValue, revisionOf, title, selectedTur, description, documentDate, validUntilOverride, klasorValue, addToast, onUploaded, onClose],
  );

  const handleSave = useCallback(async () => {
    setError(null);
    if (!title.trim()) {
      setError('Belge adı zorunludur.');
      return;
    }
    if (!documentTypeId && !kategori) {
      setError('Kategori veya tanımlı belge türü seçmelisiniz.');
      return;
    }
    if (!file) {
      setError('Bir dosya seçmelisiniz.');
      return;
    }
    if (file.size > MAX_SIZE) {
      setError('Dosya boyutu 15 MB sınırını aşıyor.');
      return;
    }
    // Revizyon akışı: doğrudan yeni revizyon olarak yükle (mevcut değiştirme sorusu yok).
    if (revisionOf) {
      await doUpload({ previousEvrakId: revisionOf.id });
      return;
    }
    setSubmitting(true);
    try {
      // "Aynı türde aktif belge var mı?" sorusu YALNIZCA katalog türü seçildiğinde anlamlıdır.
      const existing = documentTypeId ? await fetchActiveEvrakByType(firmaId, documentTypeId) : null;
      if (existing) {
        setSubmitting(false);
        setConflict(existing);
        return;
      }
      await doUpload({});
    } catch (e) {
      setError(friendlyEvrakError(e));
      setSubmitting(false);
    }
  }, [documentTypeId, kategori, title, revisionOf, file, firmaId, doUpload]);

  const chooseConflict = useCallback(
    (choice: ConflictChoice) => {
      if (!conflict) return;
      if (choice === 'replace') doUpload({ previousEvrakId: conflict.id });
      else doUpload({ draft: true });
    },
    [conflict, doUpload],
  );

  const validityNote = previewLoading
    ? 'Geçerlilik süresi hesaplanıyor…'
    : preview && preview.validUntil
    ? `Bu tarihe ait geçerlilik süresi: ${formatGecerlilikSuresi(preview.duration, preview.unit)}${
        preview.hazardLabel ? ` (${preview.hazardLabel})` : ''
      }`
    : preview && !preview.hasRule
    ? 'Bu evrak türü için otomatik geçerlilik kuralı bulunamadı; geçerlilik tarihini manuel belirleyebilirsiniz.'
    : 'Belge tarihi seçildiğinde geçerlilik süresi otomatik hesaplanır.';

  return (
    <div className="flex flex-col gap-3">
      <Input
        label="Belge Adı"
        required
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Örn: Yangın Tüpü Periyodik Kontrol Raporu"
      />

      {/* Kategori + Tanımlı Belge Türü */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Select
          label="Kategori"
          required
          options={kategoriOptions}
          value={kategori}
          disabled={lockKategori}
          onChange={(e) => {
            setKategori(e.target.value);
            setError(null);
          }}
          placeholder="Kategori seçin"
          loading={loading}
          searchable
        />
        <Select
          label="Tanımlı Belge Türü (opsiyonel)"
          options={turOptions}
          value={documentTypeId}
          onChange={(e) => {
            const v = e.target.value;
            setDocumentTypeId(v);
            const t = turlar.find((x) => x.id === v);
            if (t?.kategori) setKategori(t.kategori);
            setConflict(null);
            setError(null);
          }}
          placeholder="Katalogda varsa seçin"
          loading={loading}
          searchable
        />
      </div>

      {altKategoriLabel && (
        <div className="flex items-center gap-1.5 rounded-md border border-primary-200/60 dark:border-primary-500/25 bg-primary-50 dark:bg-primary-500/10 px-3 py-2">
          <i className="ri-node-tree text-primary-600 dark:text-primary-400 text-sm" />
          <span className="text-xs text-foreground-600">Alt kategori:</span>
          <span className="text-xs font-semibold text-foreground-800">{altKategoriLabel}</span>
          <i className="ri-lock-2-line text-foreground-400 text-xs ml-auto" />
        </div>
      )}

      {/* Klasör (opsiyonel) */}
      <Select
        label="Klasör (opsiyonel)"
        options={klasorOptions}
        value={klasorValue}
        onChange={(e) => setKlasorValue(e.target.value)}
        placeholder="Kendi klasörünüze ekleyin (isteğe bağlı)"
        loading={loading}
        searchable
      />

      <p className="text-xs text-foreground-500 flex items-start gap-1.5 -mt-1">
        <i className="ri-information-line mt-0.5 flex-shrink-0" />
        Belge adı serbesttir; katalogda karşılığı olmasa da belge seçili kategori altında kaydedilir.
        Tanımlı belge türü seçerseniz İSG gereklilikleri ve otomatik geçerlilik devreye girer.
      </p>

      {/* Bilgi bandı */}
      <div className="flex items-start gap-2.5 rounded-lg border border-primary-200/60 dark:border-primary-500/25 bg-primary-50 dark:bg-primary-500/10 px-3 py-2.5">
        <i className="ri-information-line text-primary-600 dark:text-primary-400 text-base mt-0.5 flex-shrink-0" />
        <div>
          <p className="text-sm font-medium text-foreground-800">Kategori ile belge türü ayrı kavramlardır.</p>
          <p className="text-xs text-foreground-600 mt-0.5">
            Kategori yalnızca belgenin hangi başlık altında listeleneceğini belirler. Katalog belge türü seçilirse
            geçerlilik firma tehlike sınıfına göre otomatik hesaplanır; seçilmezse geçerlilik tarihini manuel belirlersiniz.
          </p>
        </div>
      </div>

      {/* Belge Tarihi + Geçerlilik Tarihi */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <DatePicker
          label="Belge Tarihi"
          required
          value={documentDate}
          onChange={(e) => {
            setDocumentDate(e.target.value);
            setValidUntilOverride(null);
          }}
        />
        <div>
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-sm font-medium text-foreground-800">Geçerlilik Tarihi</span>
            {validUntilOverride && (
              <button
                type="button"
                onClick={() => setValidUntilOverride(null)}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[0.6875rem] font-medium bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300 hover:bg-primary-200 dark:hover:bg-primary-500/30 transition-colors cursor-pointer"
              >
                <i className="ri-magic-line" />
                Otomatik
              </button>
            )}
          </div>
          <DatePicker
            value={effectiveValidUntil}
            onChange={(e) => setValidUntilOverride(e.target.value)}
          />
        </div>
      </div>

      {/* Geçerlilik notu */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
        <span className={`inline-flex items-center gap-1.5 ${preview?.hasRule || validUntilOverride ? 'text-foreground-600' : 'text-warning-700'}`}>
          <i className="ri-time-line" />
          {validityNote}
        </span>
        {(preview?.hasRule || matchedRequirement) && (
          <button
            type="button"
            onClick={() => setShowRuleDetail((v) => !v)}
            className="text-primary-600 dark:text-primary-400 font-medium hover:underline cursor-pointer"
          >
            Mevzuat Detayı
          </button>
        )}
      </div>
      {showRuleDetail && (
        <div className="rounded-lg bg-background-100 dark:bg-background-200/50 px-3 py-2 text-xs text-foreground-600 flex flex-col gap-1">
          <span>Belge Türü: {selectedTur?.name ?? '—'}</span>
          <span>Bağlanan Yükümlülük: {matchedRequirement?.title ?? matchedRequirement?.requirementCode ?? 'Otomatik eşleşme yok'}</span>
          <span>Firma Tehlike Sınıfı: {preview?.hazardLabel ?? '—'}</span>
          <span>Hesaplanan Geçerlilik Bitişi: {preview?.validUntil ? formatEvrakDate(preview.validUntil) : 'Süresiz / manuel'}</span>
        </div>
      )}

      {/* Açıklama */}
      <div>
        <Textarea
          label="Açıklama"
          value={description}
          onChange={(e) => setDescription(e.target.value.slice(0, 500))}
          placeholder="Belge hakkında kısa açıklama (isteğe bağlı)"
          rows={3}
        />
        <p className="mt-1 text-right text-[0.6875rem] text-foreground-400 tabular-nums">{description.length}/500</p>
      </div>

      {/* Dosya */}
      <div>
        <label className="isg-form-label">
          Dosya<span className="text-danger-600 ml-0.5">*</span>
        </label>
        <div className="relative rounded-lg border-2 border-dashed border-background-300 dark:border-background-400/40 bg-background-100 dark:bg-background-200/40 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors">
          <input
            type="file"
            accept={ACCEPT}
            onChange={handleFileChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            aria-label="Dosya seç"
          />
          <div className="pointer-events-none flex items-center justify-between gap-3 px-3 py-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <i className="ri-upload-cloud-2-line text-xl text-foreground-400" />
              <div className="min-w-0">
                <p className="text-sm text-foreground-700 truncate">Dosya seçin veya buraya sürükleyip bırakın</p>
                <p className="text-[0.6875rem] text-foreground-400">PDF, DOC, DOCX, XLS, XLSX, görsel (Maks. 15 MB)</p>
              </div>
            </div>
            <span className="inline-flex items-center px-3 py-1.5 rounded-md border border-background-300 dark:border-background-400/50 bg-background-50 text-sm font-medium text-foreground-700 whitespace-nowrap">
              Dosya Seç
            </span>
          </div>
        </div>
        {file && (
          <div className="mt-2 flex items-center gap-2.5 rounded-md border border-background-300/50 dark:border-background-400/30 bg-background-50 dark:bg-background-100/50 px-3 py-2">
            <i className="ri-file-line text-foreground-500" />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium text-foreground-800 truncate">{file.name}</p>
              <p className="text-[0.6875rem] text-foreground-500">{Math.round(file.size / 1024)} KB</p>
            </div>
            <button
              type="button"
              onClick={() => setFile(null)}
              className="w-7 h-7 flex items-center justify-center rounded-md text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer"
              aria-label="Dosyayı kaldır"
            >
              <i className="ri-close-line" />
            </button>
          </div>
        )}
      </div>

      {/* Aynı türde mevcut aktif belge → değiştir / taslak sorusu */}
      {conflict && (
        <div className="rounded-lg border border-warning-300/60 dark:border-warning-500/30 bg-warning-50 dark:bg-warning-500/10 px-3 py-3">
          <div className="flex items-start gap-2">
            <i className="ri-alert-line text-warning-600 text-base mt-0.5 flex-shrink-0" />
            <div className="min-w-0">
              <p className="text-sm font-medium text-foreground-800">Bu türde zaten aktif bir evrak var.</p>
              <p className="text-xs text-foreground-600 mt-0.5">
                &quot;{conflict.title}&quot{conflict.validUntil ? ` (Bitiş: ${formatEvrakDate(conflict.validUntil)})` : ''} mevcut. Mevcut değiştirilsin mi?
              </p>
              <div className="flex flex-wrap items-center gap-2 mt-2.5">
                <Button
                  variant="primary"
                  size="sm"
                  leftIcon={<i className="ri-refresh-line" />}
                  className="whitespace-nowrap"
                  onClick={() => chooseConflict('replace')}
                  isLoading={submitting}
                >
                  Mevcut Değiştirilsin
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  leftIcon={<i className="ri-draft-line" />}
                  className="whitespace-nowrap"
                  onClick={() => chooseConflict('draft')}
                  isLoading={submitting}
                >
                  Taslak Olarak Kaydet
                </Button>
                <Button variant="ghost" size="sm" className="whitespace-nowrap" onClick={() => setConflict(null)} disabled={submitting}>
                  Vazgeç
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      {/* Footer */}
      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={submitting}>
          Vazgeç
        </Button>
        <Button
          variant="primary"
          size="sm"
          leftIcon={<i className="ri-save-line" />}
          onClick={handleSave}
          isLoading={submitting}
          disabled={!!conflict}
        >
          Kaydet
        </Button>
      </div>
    </div>
  );
}