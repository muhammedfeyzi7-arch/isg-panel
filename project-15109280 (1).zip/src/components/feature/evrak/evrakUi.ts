import type { EvrakStatus } from '@/lib/evrakService';
import { DOSYA_TUR_IKON, ICON_REGISTRY, dosyaTuruBul } from '@/lib/icons/iconRegistry';

export type EvrakBadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'secondary';

/** Evrak durumunu Badge variant'ına eşler (yalnızca görüntüleme, iş mantığı değil). */
export function evrakStatusBadgeVariant(s: EvrakStatus): EvrakBadgeVariant {
  switch (s) {
    case 'valid':
      return 'success';
    case 'expiring':
      return 'warning';
    case 'expired':
      return 'danger';
    case 'rejected':
      return 'danger';
    case 'archived':
      return 'default';
    case 'pending':
      return 'secondary';
    case 'verification_required':
      return 'warning';
    default:
      return 'default';
  }
}

/**
 * "Tüm Durumlar" filtresinde gösterilen SADE durum seçenekleri.
 * Onay/doğrulama akışına ait etiketler ("Doğrulama Bekliyor", "Reddedildi" vb.)
 * bilinçli olarak listeden çıkarılmıştır.
 */
export const EVRAK_DURUM_FILTRE_OPTIONS = [
  { value: 'valid', label: 'Geçerli' },
  { value: 'expiring', label: 'Süresi Yaklaşıyor' },
  { value: 'expired', label: 'Süresi Doldu' },
  { value: 'pending', label: 'Taslak' },
];

export interface EvrakDurumGorunum {
  label: string;
  variant: EvrakBadgeVariant;
}

/**
 * Ekranda gösterilecek SADELEŞTİRİLMİŞ evrak durumu.
 * Yalnızca kullanıcı için anlamlı 4 durum kullanılır: Süresiz / Geçerli /
 * Süresi Yaklaşıyor / Süresi Doldu. Onay/doğrulama akışı etiketleri GÖSTERİLMEZ.
 */
export function evrakDurumGorunum(status: EvrakStatus, validUntil: string | null): EvrakDurumGorunum {
  // Taslak: aktif yapılmamış (yükümlülüğü karşılamayan) belge. Geçerlilik tarihi
  // hesaplanmış olsa bile listede "Taslak" olarak görünür.
  if (status === 'pending') return { label: 'Taslak', variant: 'secondary' };
  if (!validUntil) return { label: 'Süresiz', variant: 'default' };
  switch (status) {
    case 'expired':
      return { label: 'Süresi Doldu', variant: 'danger' };
    case 'expiring':
      return { label: 'Süresi Yaklaşıyor', variant: 'warning' };
    default:
      return { label: 'Geçerli', variant: 'success' };
  }
}

/** Belgenin süresi dolmuş mu? (durum ya da geçerlilik tarihi geçmişse). */
export function evrakSuresiDoldu(status: EvrakStatus, validUntil: string | null): boolean {
  if (status === 'expired') return true;
  if (!validUntil) return false;
  return new Date(`${validUntil}T23:59:59`).getTime() < Date.now();
}

/** Geçerlilik süresini okunur metne çevirir: "1 yıl" / "6 ay" / "30 gün". */
export function formatGecerlilikSuresi(duration: number | null, unit: string | null): string {
  if (duration == null) return '—';
  const u = unit === 'month' ? 'ay' : unit === 'day' ? 'gün' : 'yıl';
  return `${duration} ${u}`;
}

const TR_MONTHS = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

/** ISO → "5 Eyl 2026" (yalnızca tarih). */
export function formatEvrakDate(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return `${d.getDate()} ${TR_MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

/** ISO → "5 Eyl 2026 14:32" (tarih + saat). */
export function formatEvrakDateTime(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${d.getDate()} ${TR_MONTHS[d.getMonth()]} ${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/**
 * Dosya türüne göre MERKEZÎ ikon sınıfı (uzantı + MIME).
 * Tür çözümü `@/lib/icons/iconRegistry` üzerinden yapılır; böylece evrak,
 * mesajlaşma, tutanak ve personel modülleri AYNI dosya-türü ikon ailesini
 * kullanır (satır ikonu → formatı temsil eden dolgulu ikon).
 */
export function evrakFileIcon(mime: string | null, name: string | null): string {
  const tur = dosyaTuruBul(mime, name);
  return ICON_REGISTRY[DOSYA_TUR_IKON[tur]].className;
}

/** Bayt → okunabilir boyut. */
export function formatEvrakSize(bytes: number | null): string {
  if (bytes == null) return '—';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

/**
 * FAZ9 Evraklar Düzeltme 3 — Gömülü (inline) önizleme yapılabilen MIME'lar.
 * PDF / görsel / düz metin tarayıcıda doğrudan render edilir; Office formatları
 * (Word/Excel/ODT/ODS) tarayıcı tarafından render EDİLEMEZ → güvenli indirme önerilir.
 */
export function evrakInlinePreviewable(mime: string | null): boolean {
  if (!mime) return false;
  if (mime === 'application/pdf') return true;
  if (mime.startsWith('image/')) return true;
  if (mime === 'text/plain') return true;
  return false;
}

/** Office belge formatı mı? (gömülü önizleme yapılamaz). */
export function evrakIsOfficeDocument(mime: string | null): boolean {
  if (!mime) return false;
  return (
    mime === 'application/msword' ||
    mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    mime === 'application/vnd.ms-excel' ||
    mime === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
    mime === 'application/vnd.oasis.opendocument.text' ||
    mime === 'application/vnd.oasis.opendocument.spreadsheet'
  );
}

/**
 * Kalan/geçen süre — merkezi geçerlilik değeri (valid_until) üzerinden salt tarih
 * aritmetiği. Mevzuat süresi HESAPLANMAZ; yalnızca merkezi valid_until bugüne göre okunur.
 * "37 gün kaldı" / "Bugün sona eriyor" / "12 gün geçti" / "Süresiz".
 */
export function formatKalanSure(validUntil: string | null): string {
  if (!validUntil) return 'Süresiz';
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const until = new Date(`${validUntil}T00:00:00`);
  if (Number.isNaN(until.getTime())) return '—';
  const diffDays = Math.round((until.getTime() - today.getTime()) / 86400000);
  if (diffDays === 0) return 'Bugün sona eriyor';
  if (diffDays > 0) return `${diffDays} gün kaldı`;
  return `${Math.abs(diffDays)} gün geçti`;
}