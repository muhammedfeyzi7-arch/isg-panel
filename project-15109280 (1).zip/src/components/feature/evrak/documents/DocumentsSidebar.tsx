import { useState } from 'react';
import DocumentCategoryTree from './DocumentCategoryTree';
import type { DocumentSelection } from './documentsTypes';

interface DocumentsSidebarProps {
  counts: Record<string, number>;
  totalCount: number;
  selection: DocumentSelection;
  openIds: Set<string>;
  onSelectAll: () => void;
  onSelectCategory: (categoryId: string) => void;
  onToggleCategory: (categoryId: string) => void;
  onSelectAlt: (categoryId: string, subId: string) => void;
}

/**
 * Belgeler — sol "Kategoriler" paneli.
 *
 * Üstte "Tüm Evraklar" sabit satırı, altında kategori ağacı bulunur. "Sık
 * Kullanılanlar" ve "Son Eklenenler" YOKTUR. Kategori arama kutusu yalnızca
 * kategori ağacını filtreler. Adetler gerçek firma evrak özetinden gelir.
 */
export default function DocumentsSidebar({
  counts,
  totalCount,
  selection,
  openIds,
  onSelectAll,
  onSelectCategory,
  onToggleCategory,
  onSelectAlt,
}: DocumentsSidebarProps) {
  const [query, setQuery] = useState('');
  const allActive = selection.type === 'all';

  return (
    <div className="rounded-lg border border-background-300/40 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-2">
      <div className="px-1.5 pb-1.5">
        <span className="text-[0.6875rem] font-semibold uppercase tracking-wide text-foreground-500">Kategoriler</span>
      </div>

      {/* Kategori ara */}
      <div className="relative flex items-center mb-1.5">
        <i className="ri-search-line absolute left-2.5 text-foreground-400 text-sm pointer-events-none" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Kategori ara..."
          aria-label="Kategori ara"
          className="isg-input isg-input-sm w-full pl-8 pr-7"
        />
        {query && (
          <button
            type="button"
            onClick={() => setQuery('')}
            aria-label="Aramayı temizle"
            className="absolute right-2 text-foreground-400 hover:text-foreground-600 cursor-pointer"
          >
            <i className="ri-close-circle-line text-sm" />
          </button>
        )}
      </div>

      {/* Tüm Evraklar (pinned) */}
      <button
        type="button"
        onClick={onSelectAll}
        className={`w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-left cursor-pointer transition-colors ${
          allActive ? 'bg-primary-50 dark:bg-primary-500/15' : 'hover:bg-background-200 dark:hover:bg-background-300/30'
        }`}
      >
        <span className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0 bg-primary-100 text-primary-600 dark:bg-primary-500/20 dark:text-primary-300">
          <i className="ri-archive-2-line text-xs" />
        </span>
        <span className={`flex-1 truncate text-sm ${allActive ? 'font-semibold text-foreground-900' : 'font-medium text-foreground-700'}`}>
          Tüm Evraklar
        </span>
        <span className={`text-xs tabular-nums flex-shrink-0 ${allActive ? 'text-foreground-700 font-semibold' : 'text-foreground-400'}`}>
          {totalCount}
        </span>
      </button>

      <div className="my-1.5 border-t border-background-300/40 dark:border-background-400/25" />

      <DocumentCategoryTree
        counts={counts}
        query={query}
        openIds={openIds}
        selection={selection}
        onSelectCategory={onSelectCategory}
        onToggleCategory={onToggleCategory}
        onSelectAlt={onSelectAlt}
      />
    </div>
  );
}