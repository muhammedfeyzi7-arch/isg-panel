import IconButton from '@/components/ui/IconButton';
import ContextMenu from '@/components/ui/ContextMenu';
import Icon from '@/components/ui/Icon';
import type { EvrakData } from '@/lib/evrakService';

interface DocumentActionsProps {
  row: EvrakData;
  /** Süresi dolan belge için "Güncelle" aksiyonu gösterilsin mi. */
  expired: boolean;
  /** Silme aksiyonu gösterilsin mi (uzman). */
  canDelete: boolean;
  /** "Güncelle" (yeni sürüm) aksiyonu gösterilsin mi (uzman; firma yetkisiz). */
  canUpdate: boolean;
  onView: () => void;
  onDownload: () => void;
  onUpdate: () => void;
  onDelete: () => void;
}

/**
 * Belgeler — satır işlemleri (Görüntüle / İndir / Diğer).
 *
 * Mevcut işlevler korunur: görüntüleme, indirme; süresi dolan belge için
 * "Güncelle" ve yetkili kullanıcı için "Sil" işlemleri "Diğer" menüsünde yer
 * alır. İkonlar merkezî Icon bileşeninden tüketilir.
 */
export default function DocumentActions({
  row,
  expired,
  canDelete,
  canUpdate,
  onView,
  onDownload,
  onUpdate,
  onDelete,
}: DocumentActionsProps) {
  const hasFile = !!row.originalFileName;

  return (
    <>
      <IconButton
        icon={<Icon name="view" size="sm" />}
        variant="ghost"
        size="sm"
        label="Belgeyi görüntüle"
        disabled={!hasFile}
        onClick={onView}
      />
      <IconButton
        icon={<Icon name="download" size="sm" />}
        variant="ghost"
        size="sm"
        label="Dosyayı indir"
        disabled={!hasFile}
        onClick={onDownload}
      />
      <ContextMenu
        triggerIcon="ri-more-2-fill"
        items={[
          { label: 'Görüntüle', icon: 'ri-eye-line', onClick: onView },
          { label: 'İndir', icon: 'ri-download-2-line', onClick: onDownload },
          ...(expired && canUpdate ? [{ label: 'Güncelle', icon: 'ri-refresh-line', onClick: onUpdate }] : []),
          ...(canDelete
            ? [{ label: 'Sil', icon: 'ri-delete-bin-line', variant: 'danger' as const, onClick: onDelete }]
            : []),
        ]}
      />
    </>
  );
}