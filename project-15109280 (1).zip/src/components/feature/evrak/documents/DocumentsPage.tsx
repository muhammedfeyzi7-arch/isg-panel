import { lazy, Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import useSWR from 'swr';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import { ModalSkeleton, ListSkeleton } from '@/components/ui/Skeleton';
import ErrorState from '@/components/ui/ErrorState';
import EmptyState from '@/components/ui/EmptyState';
import Pagination from '@/components/ui/Pagination';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import {
  deleteEvrak,
  fetchEvrakCountByTypeIds,
  fetchEvraklarPage,
  fetchEvrakTurleri,
  fetchFirmaEvrakSayilari,
  fetchFirmaKlasorleri,
  fetchFirmaTutanakTurleri,
  friendlyEvrakError,
  getEvrakUrl,
  type EvrakData,
  type EvrakStatus,
  type EvrakTuru,
  type FirmaKlasor,
} from '@/lib/evrakService';
import { fetchProfilIsimleri, type ProfilIsim } from '@/lib/profilIsimService';
import { EVRAK_DURUM_FILTRE_OPTIONS } from '../evrakUi';
import DocumentsSidebar from './DocumentsSidebar';
import DocumentsToolbar from './DocumentsToolbar';
import DocumentTable, { renderDocumentCard } from './DocumentTable';
import { SihirbazHeaderIcon, SihirbazYardimButton } from '@/components/feature/risk/RiskSihirbazHeader';

// ── PERFORMANS: Ağır feature'lar (PDF işleme, PDF önizleme motoru, risk sihirbazı,
// jspdf/exceljs bağımlılıkları) Evraklar route chunk'ına STATİK sızmasın. Yalnızca
// ilgili aksiyon tetiklendiğinde indirilir (interaction-based code splitting). ──
const EvrakEkleModal = lazy(() => import('../EvrakEkleModal'));
const EvrakBelgeModal = lazy(() => import('../EvrakBelgeModal'));
const TopluEvrakModal = lazy(() => import('../topluEvrak/TopluEvrakModal'));
const RiskSihirbazModal = lazy(() => import('@/components/feature/risk/RiskSihirbazModal'));
const AcilDurumEkipYonetimiModal = lazy(() => import('@/components/feature/risk/AcilDurumEkipYonetimiModal'));
const AcilDurumTatbikatModal = lazy(() => import('@/components/feature/risk/AcilDurumTatbikatModal'));
const AcilDurumTahliyeModal = lazy(() => import('@/components/feature/tahliye/AcilDurumTahliyeModal'));
const IsgKurulPanel = lazy(() => import('@/components/feature/isgKurul/IsgKurulPanel'));
const IsgOrganizasyonuModal = lazy(() => import('@/components/feature/risk/IsgOrganizasyonuModal'));
const NoterDefteriPanel = lazy(() => import('@/components/feature/evrak/noterDefteri/NoterDefteriPanel'));

/** Modal gövdesi için ortak lazy yükleme göstergesi. */
function ModalLoading({ text }: { text: string }) {
  return <ModalSkeleton variant="form" label={text} />;
}
import {
  DOCUMENT_ACTION_META,
  DOCUMENT_CATEGORIES,
  DOCUMENT_CATEGORY_MAP,
  DOCUMENT_COLUMNS,
  categoryDisplayNameForType,
  categoryTurIds,
  kategoriKeyToCategory,
  resolveSubcategoryLabel,
  subAction,
  subOnlyTypeIds,
  type DocTypeLike,
  type DocumentActionKey,
} from './documentCategories';
import type { DocumentSelection, DocumentSortKey, DocumentViewMode } from './documentsTypes';

interface DocumentsPageProps {
  firmaId: string;
  role: 'uzman' | 'firma';
}

function sortParams(sort: DocumentSortKey): { sortBy: 'created_at' | 'title' | 'document_date'; sortDir: 'asc' | 'desc' } {
  switch (sort) {
    case 'old':
      return { sortBy: 'created_at', sortDir: 'asc' };
    case 'title':
      return { sortBy: 'title', sortDir: 'asc' };
    case 'expiry':
      return { sortBy: 'document_date', sortDir: 'asc' };
    case 'new':
    default:
      return { sortBy: 'created_at', sortDir: 'desc' };
  }
}

/**
 * EVRAKLAR — Uzman ve Firma panellerinin ORTAK yeni ekranı.
 *
 * Sol kategori ağacı (kapalı başlar, tıklayınca açılır, alt kategoriler
 * seçilebilir) + sağda evrak tablosu. Tüm kategoriler saf evrak FİLTRESİDİR.
 * Kategori verisi tek kaynaktan (`DOCUMENT_CATEGORIES`) gelir; iki panel için
 * AYRI ekran kodlanmaz — bu bileşen her ikisinde de kullanılır.
 */
export default function DocumentsPage({ firmaId, role }: DocumentsPageProps) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const sihirbazIdRef = useRef('');
  const topluEvrakRef = useRef('');
  const modulIdRef = useRef('');

  const [selection, setSelection] = useState<DocumentSelection>({ type: 'all' });
  const [openIds, setOpenIds] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [turFilter, setTurFilter] = useState('');
  const [sort, setSort] = useState<DocumentSortKey>('new');
  const [viewMode, setViewMode] = useState<DocumentViewMode>('liste');
  const [visibleColumns, setVisibleColumns] = useState<string[]>(
    DOCUMENT_COLUMNS.filter((c) => !c.always).map((c) => c.key),
  );
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [bulkBusy, setBulkBusy] = useState(false);
  const [refreshToken, setRefreshToken] = useState(0);

  const refreshAll = useCallback(() => setRefreshToken((t) => t + 1), []);

  // ---- Veri kaynakları ----
  // Genel firma kataloğu (is_tutanak=false) + firma sahipli TUTANAK türleri
  // (is_tutanak=true). İki alan AYRI getirilir ama bu ekranda TEK listede birleşir;
  // Saha Denetimleri/Tutanaklar kategorileri tutanak türleriyle eşleşir.
  const { data: tumTurler = [] } = useSWR<EvrakTuru[]>('evrak-turleri', fetchEvrakTurleri);
  const { data: tutanakTurleri = [] } = useSWR<EvrakTuru[]>('evrak-tutanak-turleri', fetchFirmaTutanakTurleri);
  const firmaTurleri = useMemo(() => tumTurler.filter((t) => t.ownerType === 'firma'), [tumTurler]);

  const allFirmaTurleri = useMemo(() => {
    const m = new Map<string, EvrakTuru>();
    for (const t of firmaTurleri) m.set(t.id, t);
    for (const t of tutanakTurleri) if (t.ownerType === 'firma') m.set(t.id, t);
    return Array.from(m.values());
  }, [firmaTurleri, tutanakTurleri]);

  const turMap = useMemo(() => {
    const m: Record<string, { name: string; kategori: string | null; tutanakGrubu: string | null }> = {};
    for (const t of allFirmaTurleri) {
      m[t.id] = { name: t.name, kategori: t.kategori, tutanakGrubu: t.tutanakGrubu ?? null };
    }
    return m;
  }, [allFirmaTurleri]);

  const { data: klasorler = [] } = useSWR<FirmaKlasor[]>(
    ['firma-evrak-klasorleri', firmaId, refreshToken],
    () => fetchFirmaKlasorleri(firmaId, 'firma'),
  );
  const klasorMap = useMemo(() => {
    const m: Record<string, string> = {};
    for (const k of klasorler) m[k.id] = k.ad;
    return m;
  }, [klasorler]);

  const { data: sayilar } = useSWR(['firma-evrak-sayilari', firmaId, refreshToken], () =>
    fetchFirmaEvrakSayilari(firmaId),
  );

  // ---- Seçime göre belge türü kapsamı (tür veri modeli) ----
  const docTypes: DocTypeLike[] = useMemo(
    () =>
      allFirmaTurleri.map((t) => ({
        id: t.id,
        code: t.code,
        name: t.name,
        kategori: t.kategori,
        isTutanak: t.isTutanak,
        tutanakGrubu: t.tutanakGrubu,
      })),
    [allFirmaTurleri],
  );

  // Saha Denetimleri (SAHA) ve Tutanaklar (SAHA dışı) tür id'leri — kategori eşleme
  // motorunun AYNI çıktısı kullanılır (tek veri kümesi: sayaç = liste).
  const sahaTypeIds = useMemo(() => {
    const cat = DOCUMENT_CATEGORY_MAP['saha'];
    return cat ? categoryTurIds(cat, docTypes) : [];
  }, [docTypes]);
  const tutanakTypeIds = useMemo(() => {
    const cat = DOCUMENT_CATEGORY_MAP['tutanaklar'];
    return cat ? categoryTurIds(cat, docTypes) : [];
  }, [docTypes]);
  // Ortak ekranda tutanak türü (is_tutanak) satırlar SALT-OKUNUR lifecycle'a tabidir:
  // imza/revizyon/silme işlemleri mevcut Tutanaklar modülünde kalır.
  const tutanakIdSet = useMemo(
    () => new Set(tutanakTurleri.filter((t) => t.ownerType === 'firma').map((t) => t.id)),
    [tutanakTurleri],
  );
  const isTutanakRow = useCallback(
    (row: EvrakData) => !!row.documentTypeId && tutanakIdSet.has(row.documentTypeId),
    [tutanakIdSet],
  );

  // ---- Kategori adetleri ----
  // Non-tutanak kategoriler RPC özetinden; Saha/Tutanak kategorileri tutanak türleri
  // için AYNI liste kapsamıyla sayılır (sayaç = liste, salt SELECT).
  const { data: sahaCount = 0 } = useSWR(
    sahaTypeIds.length > 0 ? ['evrak-sayi-saha', firmaId, refreshToken, sahaTypeIds.join(',')] : null,
    () => fetchEvrakCountByTypeIds(firmaId, sahaTypeIds),
  );
  const { data: tutanakCount = 0 } = useSWR(
    tutanakTypeIds.length > 0 ? ['evrak-sayi-tutanak', firmaId, refreshToken, tutanakTypeIds.join(',')] : null,
    () => fetchEvrakCountByTypeIds(firmaId, tutanakTypeIds),
  );

  // RPC'nin döndürdüğü TÜM kategori anahtarları — sayaç ve liste kapsamı aynı bu
  // kaynaktan türetilir.
  const allKategoriKeys = useMemo(() => Object.keys(sayilar?.kategori ?? {}), [sayilar]);

  // SAYAÇ: RPC'nin her kategori anahtarı `kategoriKeyToCategory` ile TEK display
  // kategorisine eşlenir. Tutanak türleri RPC'de yoktur; Saha/Tutanaklar sayaçları
  // AYNI tür kapsamıyla (categoryTurIds) hesaplanır. Böylece "sayaçtaki belge listede
  // yok" tutarsızlığı yapısal olarak imkânsızdır (sayaç ve liste tek çözümleyici).
  const counts = useMemo<Record<string, number>>(() => {
    const result: Record<string, number> = {};
    for (const cat of DOCUMENT_CATEGORIES) result[cat.id] = 0;
    result.saha = sahaCount;
    result.tutanaklar = tutanakCount;
    const kat = sayilar?.kategori ?? {};
    for (const [key, n] of Object.entries(kat)) {
      const cat = kategoriKeyToCategory(key);
      result[cat.id] = (result[cat.id] ?? 0) + (Number(n) || 0);
    }
    return result;
  }, [sayilar, sahaCount, tutanakCount]);

  // "Tüm Evraklar" sayacı = tüm kategorilerin toplamı (Saha/Tutanak dahil).
  const totalCount = useMemo(() => Object.values(counts).reduce((a, b) => a + b, 0), [counts]);

  // Kategori kapsamı: katalog tür id'leri + MANUEL belgelerin kategori adları + alt
  // kategori anahtarı. 'all' → kapsam filtresi yok (tüm firma evrakları).
  const scope = useMemo<{
    documentTypeIds?: string[];
    kategoriList?: string[];
    altKategori?: string;
    kategoriNull?: boolean;
  }>(() => {
    if (selection.type === 'all') return {};
    const cat = DOCUMENT_CATEGORY_MAP[selection.categoryId];
    if (!cat) return { documentTypeIds: ['__none__'] };
    if (selection.type === 'alt') {
      // Alt kategori: kardeş kategorilerin belgeleri KESİNLİKLE SIZMAZ. Kapsam =
      // o alt kategoriye atanmış katalog türleri VEYA doğrudan o alt kategoriye
      // yüklenmiş manuel belgeler (alt_kategori = child id).
      const ids = subOnlyTypeIds(cat, selection.subId, docTypes);
      return { documentTypeIds: ids, altKategori: selection.subId };
    }
    // Kategori başlığı: SAYAÇLA AYNI kaynaktan. Katalog türleri (resolveTypeCategory
    // ile o kategoriye düşen) + manuel belgelerin kategori adları (RPC anahtarları).
    const typeIds = categoryTurIds(cat, docTypes);
    const keysForCat = allKategoriKeys.filter((k) => kategoriKeyToCategory(k).id === cat.id);
    const kategoriList = Array.from(new Set([...cat.dbKategoriler, ...keysForCat]));
    if (typeIds.length === 0 && kategoriList.length === 0 && !cat.fallback) {
      return { documentTypeIds: ['__none__'] };
    }
    return { documentTypeIds: typeIds, kategoriList, kategoriNull: cat.fallback };
  }, [selection, docTypes, allKategoriKeys]);

  // ---- Liste sorgusu ----
  const query = useMemo(() => {
    const { sortBy, sortDir } = sortParams(sort);
    return {
      search: search || undefined,
      ownerType: 'firma' as const,
      status: (statusFilter as EvrakStatus | '') || '',
      firmaId,
      documentTypeIds: scope.documentTypeIds,
      kategoriList: scope.kategoriList,
      altKategori: scope.altKategori,
      kategoriNull: scope.kategoriNull,
      // Seçili "Evrak Türü" filtresi kategori kapsamının ÜZERİNE uygulanır (daraltır).
      documentTypeId: turFilter || undefined,
      // Tutanakların geçmiş (superseded) revizyonları current belge gibi gösterilmesin.
      excludeSuperseded: true,
      sortBy,
      sortDir,
      page,
      pageSize,
    };
  }, [search, statusFilter, firmaId, scope, turFilter, sort, page, pageSize]);

  const queryKey = useMemo(() => JSON.stringify(query), [query]);
  const { data: pageData, error, isLoading, mutate } = useSWR(
    ['firma-evrak-listesi', firmaId, queryKey, refreshToken],
    () => fetchEvraklarPage(query),
  );
  const rows = pageData?.data ?? [];
  const count = pageData?.count ?? 0;
  const errorMsg = error instanceof Error ? error.message : null;

  const uploaderIds = useMemo(
    () => Array.from(new Set(rows.map((r) => r.uploadedBy).filter((x): x is string => !!x))).sort(),
    [rows],
  );
  const { data: uploaderMap = {} } = useSWR<Record<string, ProfilIsim>>(
    uploaderIds.length ? `profil-isimleri:${uploaderIds.join(',')}` : null,
    () => fetchProfilIsimleri(uploaderIds),
  );

  useEffect(() => {
    setSelectedKeys([]);
  }, [queryKey]);

  // Kategori seçilince seçim yapılır + ilgili kategori açılır.
  const handleSelectCategory = useCallback((categoryId: string) => {
    setSelection({ type: 'kategori', categoryId });
    setTurFilter('');
    setPage(1);
    setOpenIds((prev) => {
      if (prev.has(categoryId)) return prev;
      const next = new Set(prev);
      next.add(categoryId);
      return next;
    });
  }, []);

  const handleToggleCategory = useCallback((categoryId: string) => {
    setOpenIds((prev) => {
      const next = new Set(prev);
      if (next.has(categoryId)) next.delete(categoryId);
      else next.add(categoryId);
      return next;
    });
  }, []);

  const handleSelectAlt = useCallback((categoryId: string, subId: string) => {
    setSelection({ type: 'alt', categoryId, subId });
    setTurFilter('');
    setPage(1);
  }, []);

  const handleSelectAll = useCallback(() => {
    setSelection({ type: 'all' });
    setTurFilter('');
    setPage(1);
  }, []);

  const handleToggleColumn = useCallback((key: string) => {
    setVisibleColumns((prev) => (prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]));
  }, []);

  // ---- Breadcrumb ----
  const breadcrumb = useMemo<string[]>(() => {
    if (selection.type === 'all') return ['Evraklar', 'Tüm Evraklar'];
    const cat = DOCUMENT_CATEGORY_MAP[selection.categoryId];
    if (!cat) return ['Evraklar'];
    if (selection.type === 'alt') {
      const sub = cat.children.find((c) => c.id === selection.subId);
      return sub ? ['Evraklar', cat.name, sub.name] : ['Evraklar', cat.name];
    }
    return ['Evraklar', cat.name];
  }, [selection]);

  const turOptions = useMemo(
    () => allFirmaTurleri.map((t) => ({ value: t.id, label: t.name, group: t.kategori ?? 'Diğer' })),
    [allFirmaTurleri],
  );

  // ---- Satır işlemleri ----
  const handleDownload = useCallback(
    async (row: EvrakData) => {
      if (!row.originalFileName) return;
      try {
        const url = await getEvrakUrl(row.id);
        window.open(url, '_blank', 'noopener,noreferrer');
      } catch (e) {
        addToast({ title: 'Dosya açılamadı', message: friendlyEvrakError(e), type: 'error' });
      }
    },
    [addToast],
  );

  const openBelge = useCallback(
    (row: EvrakData) => {
      const tur = row.documentTypeId ? turMap[row.documentTypeId] : undefined;
      const kategoriName = categoryDisplayNameForType({
        kategori: tur?.kategori ?? row.kategori ?? null,
        tutanakGrubu: tur?.tutanakGrubu ?? null,
      });
      const altKategoriName = resolveSubcategoryLabel(row.altKategori);
      openModal({
        title: 'Belge Önizleme',
        description: 'Seçilen evrağı görüntüleyin, detaylarını inceleyin ve işlem yapın.',
        variant: 'large',
        width: 1180,
        height: 820,
        minWidth: 720,
        minHeight: 560,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        maximizable: true,
        content: (
          <Suspense fallback={<ModalLoading text="Belge hazırlanıyor..." />}>
            <EvrakBelgeModal
              evrak={row}
              firmaId={firmaId}
              role={role}
              klasorler={klasorler}
              turName={row.documentTypeId ? turMap[row.documentTypeId]?.name : null}
              kategoriName={kategoriName}
              altKategoriName={altKategoriName}
              klasorName={row.klasorId ? klasorMap[row.klasorId] ?? null : null}
              uploaderName={row.uploadedBy ? uploaderMap[row.uploadedBy]?.name : null}
              lifecycleLocked={isTutanakRow(row)}
              onChanged={refreshAll}
            />
          </Suspense>
        ),
      });
    },
    [openModal, firmaId, role, klasorler, turMap, klasorMap, uploaderMap, refreshAll, isTutanakRow],
  );

  const openUpdate = useCallback(
    (row: EvrakData) => {
      const id = openModal({
        title: 'Evrak Güncelle',
        description: 'Süresi dolan belgenin yenisini yükleyin. Eski belge arşivlenir.',
        variant: 'large',
        width: 720,
        minHeight: 560,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: (
          <Suspense fallback={<ModalLoading text="Form yükleniyor..." />}>
            <EvrakEkleModal
              firmaId={firmaId}
              role={role}
              initialEvrak={row}
              onClose={() => closeModal(id)}
              onUploaded={refreshAll}
            />
          </Suspense>
        ),
      });
    },
    [openModal, closeModal, firmaId, role, refreshAll],
  );

  const handleDelete = useCallback(
    (row: EvrakData) => {
      confirm({
        title: 'Evrakı Sil',
        message: `"${row.title}" kalıcı olarak silinecek. Dosya da kaldırılır ve bu işlem geri alınamaz.`,
        variant: 'danger',
        confirmText: 'Evet, Kalıcı Sil',
        cancelText: 'Vazgeç',
        onConfirm: () => {
          deleteEvrak(row.id)
            .then(() => {
              addToast({ title: 'Silindi', message: 'Evrak kalıcı olarak silindi.', type: 'success' });
              refreshAll();
            })
            .catch((e) => addToast({ title: 'Silinemedi', message: friendlyEvrakError(e), type: 'error' }));
        },
      });
    },
    [confirm, addToast, refreshAll],
  );

  const handleBulkDelete = useCallback(() => {
    if (selectedKeys.length === 0) return;
    // Tutanak türleri (is_tutanak) ortak ekrandan SİLİNMEZ — tek doğruluk kaynağı
    // Tutanaklar/Saha modülüdür. Yalnızca normal evraklar silinebilir.
    const rowById = new Map(rows.map((r) => [r.id, r]));
    const deletableKeys = selectedKeys.filter((id) => {
      const r = rowById.get(id);
      return r ? !isTutanakRow(r) : true;
    });
    if (deletableKeys.length === 0) {
      addToast({
        title: 'İşlem yapılamadı',
        message: 'Seçilen belgeler tutanak türünde; yalnızca Tutanaklar modülünden yönetilir.',
        type: 'warning',
      });
      return;
    }
    confirm({
      title: 'Seçilenleri Sil',
      message: `${deletableKeys.length} evrak kalıcı olarak silinecek. Bu işlem geri alınamaz.`,
      variant: 'danger',
      confirmText: 'Evet, Kalıcı Sil',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setBulkBusy(true);
        Promise.allSettled(deletableKeys.map((id) => deleteEvrak(id)))
          .then((results) => {
            const ok = results.filter((r) => r.status === 'fulfilled').length;
            addToast({
              title: 'Toplu işlem',
              message: `${ok} / ${deletableKeys.length} evrak silindi.`,
              type: ok === deletableKeys.length ? 'success' : 'warning',
            });
            setSelectedKeys([]);
            refreshAll();
          })
          .finally(() => setBulkBusy(false));
      },
    });
  }, [selectedKeys, rows, isTutanakRow, confirm, addToast, refreshAll]);

  const openUpload = useCallback(() => {
    // Bulunulan kategori bağlamı manuel belgeye öntanımlı kategori olarak taşınır.
    // Kategori seçiliyse upload modalında kategori KİLİTLİ gelir → kullanıcı tekrar
    // seçmek zorunda kalmaz ve belge doğru kategoriye kaydedilir. Alt kategori
    // seçiliyse alt_kategori de kilitlenir (yüklenen belge o alt kategoride görünür).
    const aktifCat = selection.type !== 'all' ? DOCUMENT_CATEGORY_MAP[selection.categoryId] : undefined;
    const aktifKategori = aktifCat ? aktifCat.dbKategoriler[0] ?? aktifCat.name : undefined;
    const aktifAlt = selection.type === 'alt' ? selection.subId : undefined;
    const altLabel =
      aktifAlt && aktifCat ? aktifCat.children.find((c) => c.id === aktifAlt)?.name ?? null : null;
    const id = openModal({
      title: 'Evrak Yükle',
      description: 'Firmaya ait yeni bir belgeyi sisteme yükleyin.',
      variant: 'large',
      width: 720,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <Suspense fallback={<ModalLoading text="Form yükleniyor..." />}>
          <EvrakEkleModal
            firmaId={firmaId}
            role={role}
            initialKategori={aktifKategori}
            lockKategori={!!aktifKategori}
            initialAltKategori={aktifAlt}
            altKategoriLabel={altLabel ?? undefined}
            onClose={() => closeModal(id)}
            onUploaded={refreshAll}
          />
        </Suspense>
      ),
    });
  }, [openModal, closeModal, firmaId, role, refreshAll, selection]);

  const openTopluEvrak = useCallback(() => {
    const viewportH = typeof window !== 'undefined' ? window.innerHeight : 900;
    const id = openModal({
      dedupeKey: `toplu-evrak:${firmaId}`,
      title: 'Toplu Evrak Yükle ve Eşleştir',
      description: 'PDF dosyanızı yükleyin, sayfaları personellere ve belge türlerine eşleştirerek kaydedin.',
      variant: 'large',
      wide: true,
      width: 1360,
      height: Math.max(680, viewportH - 40),
      minWidth: 1024,
      minHeight: 620,
      showFooter: false,
      closable: true,
      resizable: true,
      maximizable: true,
      bodyLayout: 'fill',
      content: (
        <Suspense fallback={<ModalLoading text="Toplu evrak modülü yükleniyor..." />}>
          <TopluEvrakModal
            firmaId={firmaId}
            role={role}
            onClose={() => {
              closeModal(topluEvrakRef.current);
              topluEvrakRef.current = '';
            }}
            onCompleted={refreshAll}
          />
        </Suspense>
      ),
    });
    topluEvrakRef.current = id;
  }, [openModal, closeModal, firmaId, role, refreshAll]);

  const openSihirbaz = useCallback(() => {
    const id = openModal({
      title: 'İSGDenetim Sihirbazı',
      description: 'İhtiyacınız olan dokümanı kolayca oluşturun. Aşağıdaki modüllerden birini seçerek başlayın.',
      headerIcon: <SihirbazHeaderIcon />,
      headerExtra: <SihirbazYardimButton />,
      variant: 'large',
      size: 'wide',
      wide: true,
      width: 1360,
      height: 760,
      minWidth: 900,
      minHeight: 560,
      showFooter: false,
      bodyLayout: 'fill',
      closable: true,
      resizable: true,
      minimizable: true,
      maximizable: true,
      content: (
        <Suspense fallback={<ModalLoading text="Sihirbaz yükleniyor..." />}>
          <RiskSihirbazModal modalIdRef={sihirbazIdRef} onClose={() => closeModal(sihirbazIdRef.current)} />
        </Suspense>
      ),
    });
    sihirbazIdRef.current = id;
  }, [openModal, closeModal]);

  // Seçili kategoriye bağlı modül aksiyonu. ALT kategoride child aksiyonu; ANA
  // kategori başlığında kategori aksiyonu (ör. İSG Kurulu / Noter Defteri) esas alınır.
  const activeAction: DocumentActionKey | undefined = useMemo(() => {
    if (selection.type === 'alt') return subAction(selection.categoryId, selection.subId);
    if (selection.type === 'kategori') return DOCUMENT_CATEGORY_MAP[selection.categoryId]?.action;
    return undefined;
  }, [selection]);

  const openAction = useCallback(
    (action: DocumentActionKey) => {
      const common = {
        variant: 'large' as const,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        maximizable: true,
      };
      if (action === 'ekip') {
        const id = openModal({
          ...common,
          title: 'Acil Durum Ekipleri',
          width: 1120,
          minWidth: 780,
          minHeight: 620,
          content: (
            <Suspense fallback={<ModalLoading text="Ekipler yükleniyor..." />}>
              <AcilDurumEkipYonetimiModal
                firmaId={firmaId}
                role={role}
                onClose={() => closeModal(modulIdRef.current)}
                onChanged={refreshAll}
              />
            </Suspense>
          ),
        });
        modulIdRef.current = id;
      } else if (action === 'tatbikat') {
        const id = openModal({
          ...common,
          title: 'Acil Durum Tatbikatları',
          width: 1200,
          minWidth: 900,
          minHeight: 620,
          content: (
            <Suspense fallback={<ModalLoading text="Tatbikatlar yükleniyor..." />}>
              <AcilDurumTatbikatModal
                firmaId={firmaId}
                role={role}
                onClose={() => closeModal(modulIdRef.current)}
                onChanged={refreshAll}
              />
            </Suspense>
          ),
        });
        modulIdRef.current = id;
      } else if (action === 'kurul') {
        const id = openModal({
          ...common,
          title: 'İSG Kurulu',
          width: 1200,
          minWidth: 900,
          minHeight: 620,
          wide: true,
          bodyLayout: 'fill',
          content: (
            <Suspense fallback={<ModalLoading text="İSG Kurulu yükleniyor..." />}>
              <IsgKurulPanel
                firmaId={firmaId}
                role={role}
                onClose={() => closeModal(modulIdRef.current)}
                onChanged={refreshAll}
              />
            </Suspense>
          ),
        });
        modulIdRef.current = id;
      } else if (action === 'noter') {
        const id = openModal({
          ...common,
          title: 'Noter Defteri',
          description: 'Onaylı defter üzerindeki tespit ve öneri kayıtlarını ve fiziksel nüsha durumlarını yönetin.',
          width: 1240,
          minWidth: 900,
          minHeight: 640,
          wide: true,
          bodyLayout: 'fill',
          content: (
            <Suspense fallback={<ModalLoading text="Noter defteri yükleniyor..." />}>
              <NoterDefteriPanel firmaId={firmaId} role={role} />
            </Suspense>
          ),
        });
        modulIdRef.current = id;
      } else if (action === 'organizasyon') {
        const id = openModal({
          ...common,
          title: 'İSG Organizasyonu',
          description: 'Firmanın İSG organizasyon yapısını, ekiplerini ve gereksinim durumunu görüntüleyin.',
          width: 1200,
          minWidth: 900,
          minHeight: 620,
          wide: true,
          bodyLayout: 'fill',
          content: (
            <Suspense fallback={<ModalLoading text="İSG organizasyonu yükleniyor..." />}>
              <IsgOrganizasyonuModal firmaId={firmaId} role={role} onClose={() => closeModal(modulIdRef.current)} />
            </Suspense>
          ),
        });
        modulIdRef.current = id;
      } else {
        const viewportH = typeof window !== 'undefined' ? window.innerHeight : 900;
        const id = openModal({
          ...common,
          title: 'Acil Durum Tahliye Planları / Kroki',
          width: 1440,
          height: Math.max(700, viewportH - 40),
          minWidth: 1080,
          minHeight: 640,
          wide: true,
          bodyLayout: 'fill',
          content: (
            <Suspense fallback={<ModalLoading text="Tahliye planı modülü yükleniyor..." />}>
              <AcilDurumTahliyeModal
                firmaId={firmaId}
                role={role}
                onClose={() => closeModal(modulIdRef.current)}
                onChanged={refreshAll}
              />
            </Suspense>
          ),
        });
        modulIdRef.current = id;
      }
    },
    [openModal, closeModal, firmaId, role, refreshAll],
  );

  const totalPages = Math.max(1, Math.ceil(count / pageSize));
  const showEmpty = !isLoading && !errorMsg && rows.length === 0;

  return (
    <div className="isg-page">
      <PageHeader
        title={role === 'uzman' ? 'Uzman Evrakları' : 'Firma İSG Evrakları'}
        subtitle={
          role === 'uzman'
            ? 'Hizmet verdiğiniz firmalar için oluşturduğunuz İSG çalışma dokümanlarını yönetin.'
            : 'Firmanıza ait İSG dokümanlarını görüntüleyin ve yönetin.'
        }
        className="flex-shrink-0"
        actions={
          <>
            {role === 'uzman' && (
              <Button
                variant="secondary"
                size="sm"
                className="whitespace-nowrap"
                leftIcon={<i className="ri-magic-line" />}
                onClick={openSihirbaz}
              >
                Sihirbaz
              </Button>
            )}
            <Button
              variant="secondary"
              size="sm"
              className="whitespace-nowrap"
              leftIcon={<i className="ri-stack-line" />}
              onClick={openTopluEvrak}
            >
              Toplu Evrak
            </Button>
            <Button
              variant="primary"
              size="sm"
              className="whitespace-nowrap"
              leftIcon={<i className="ri-upload-2-line" />}
              onClick={openUpload}
            >
              Evrak Yükle
            </Button>
          </>
        }
      />

      <div className="flex flex-col lg:flex-row gap-3">
        <aside className="lg:w-64 lg:flex-shrink-0">
          <div className="lg:sticky lg:top-3">
            <DocumentsSidebar
              counts={counts}
              totalCount={totalCount}
              selection={selection}
              openIds={openIds}
              onSelectAll={handleSelectAll}
              onSelectCategory={handleSelectCategory}
              onToggleCategory={handleToggleCategory}
              onSelectAlt={handleSelectAlt}
            />
          </div>
        </aside>

        <div className="flex-1 min-w-0 flex flex-col">
          <div className="isg-card flex flex-col p-3">
            {(activeAction || selection.type !== 'all') && (
              <div className="flex items-center justify-end gap-2 mb-2.5">
                {selection.type !== 'all' && (
                  <Button
                    variant="secondary"
                    size="sm"
                    className="whitespace-nowrap"
                    leftIcon={<i className="ri-upload-2-line" />}
                    onClick={openUpload}
                  >
                    Bu Kategoriye Evrak Yükle
                  </Button>
                )}
                {activeAction && (
                  <Button
                    variant="primary"
                    size="sm"
                    className="whitespace-nowrap"
                    leftIcon={<i className={DOCUMENT_ACTION_META[activeAction].icon} />}
                    onClick={() => openAction(activeAction)}
                  >
                    {DOCUMENT_ACTION_META[activeAction].label}
                  </Button>
                )}
              </div>
            )}
            <DocumentsToolbar
              breadcrumb={breadcrumb}
              count={count}
              search={search}
              onSearch={(v) => {
                setSearch(v);
                setPage(1);
              }}
              statusFilter={statusFilter}
              statusOptions={EVRAK_DURUM_FILTRE_OPTIONS}
              onStatusChange={(v) => {
                setStatusFilter(v);
                setPage(1);
              }}
              turFilter={turFilter}
              turOptions={turOptions}
              onTurChange={(v) => {
                setTurFilter(v);
                setPage(1);
              }}
              sort={sort}
              onSortChange={(v) => {
                setSort(v);
                setPage(1);
              }}
              visibleColumns={visibleColumns}
              onToggleColumn={handleToggleColumn}
              viewMode={viewMode}
              onViewModeChange={setViewMode}
            />

            {/* Seçim çubuğu */}
            {selectedKeys.length > 0 && (
              <div className="mt-2.5 flex items-center justify-between gap-2 px-3 py-2 rounded-lg bg-primary-50 dark:bg-primary-500/10 border border-primary-200/60 dark:border-primary-500/25">
                <span className="text-sm font-medium text-foreground-800">
                  <span className="font-semibold">{selectedKeys.length}</span> evrak seçildi
                </span>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setSelectedKeys([])}>
                    Seçimi Temizle
                  </Button>
                  {role === 'uzman' && (
                    <Button
                      variant="danger"
                      size="sm"
                      leftIcon={<i className="ri-delete-bin-line" />}
                      isLoading={bulkBusy}
                      onClick={handleBulkDelete}
                    >
                      Sil
                    </Button>
                  )}
                </div>
              </div>
            )}

            {/* İçerik */}
            <div className="mt-2.5 flex-1 min-h-0">
              {isLoading ? (
                <ListSkeleton rows={8} />
              ) : errorMsg ? (
                <ErrorState message={errorMsg} onRetry={() => mutate()} />
              ) : showEmpty ? (
                <EmptyState
                  icon="ri-file-text-line"
                  title="Bu kategoride evrak yok"
                  description={
                    selection.type === 'all'
                      ? 'Bu firmaya ait işyeri İSG evrakı bulunmuyor.'
                      : `"${breadcrumb[breadcrumb.length - 1]}" kapsamında evrak bulunmuyor.`
                  }
                />
              ) : viewMode === 'kart' ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-2.5">
                  {rows.map((row) => (
                    <div key={row.id}>{renderDocumentCard(row, turMap, uploaderMap)}</div>
                  ))}
                </div>
              ) : (
                <DocumentTable
                  rows={rows}
                  visibleColumns={visibleColumns}
                  turMap={turMap}
                  uploaderMap={uploaderMap}
                  selectedKeys={selectedKeys}
                  onSelectionChange={setSelectedKeys}
                  canDelete={role === 'uzman'}
                  canUpdate={role === 'uzman'}
                  isLockedRow={isTutanakRow}
                  onView={openBelge}
                  onDownload={handleDownload}
                  onUpdate={openUpdate}
                  onDelete={handleDelete}
                />
              )}
            </div>

            {!isLoading && !errorMsg && rows.length > 0 && (
              <div className="mt-3 pt-3 border-t isg-divider">
                <Pagination
                  currentPage={page}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={count}
                  onPageChange={setPage}
                  onPageSizeChange={(size) => {
                    setPageSize(size);
                    setPage(1);
                  }}
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}