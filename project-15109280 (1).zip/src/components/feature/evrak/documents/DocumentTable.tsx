import { useCallback, useMemo } from 'react';
import Badge from '@/components/ui/Badge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import SharedListCard, { ListCardBadge } from '@/components/ui/SharedListCard';
import type { EvrakData } from '@/lib/evrakService';
import { EvrakDosyaIkonu, EvrakDosyaTipiBadge } from '../EvrakDosyaTipi';
import {
  evrakDurumGorunum,
  evrakFileIcon,
  evrakSuresiDoldu,
  formatEvrakDate,
  formatEvrakDateTime,
  formatKalanSure,
} from '../evrakUi';
import { categoryDisplayNameForType, categoryForType } from './documentCategories';
import DocumentActions from './DocumentActions';

export interface TurBilgi {
  name: string;
  kategori: string | null;
  tutanakGrubu?: string | null;
}

interface DocumentTableProps {
  rows: EvrakData[];
  /** Görünür kolon anahtarları (bkz. DOCUMENT_COLUMNS). */
  visibleColumns: string[];
  turMap: Record<string, TurBilgi>;
  uploaderMap: Record<string, { name: string }>;
  selectedKeys: string[];
  onSelectionChange: (keys: string[]) => void;
  canDelete: boolean;
  /** Süresi dolan belge için "Güncelle" (yeni sürüm) aksiyonu gösterilsin mi (uzman). */
  canUpdate: boolean;
  onView: (row: EvrakData) => void;
  onDownload: (row: EvrakData) => void;
  onUpdate: (row: EvrakData) => void;
  onDelete: (row: EvrakData) => void;
  /**
   * Kilitli satırlar (ör. tutanak türleri) salt-okunur lifecycle'a tabidir: bu
   * satırlarda imza/revizyon (Güncelle) ve silme aksiyonları GÖSTERİLMEZ. Tek
   * doğruluk kaynağı ilgili modüldür (Tutanaklar / Saha Denetimleri).
   */
  isLockedRow?: (row: EvrakData) => boolean;
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

/** Kart (grid) görünümü — liste görünümüyle aynı görsel dili kullanır. */
export function renderDocumentCard(
  row: EvrakData,
  turMap: Record<string, TurBilgi>,
  uploaderMap: Record<string, { name: string }>,
) {
  const durum = evrakDurumGorunum(row.status, row.validUntil);
  const tur = row.documentTypeId ? turMap[row.documentTypeId] : undefined;
  const kategoriName = categoryDisplayNameForType({
    kategori: tur?.kategori ?? row.kategori ?? null,
    tutanakGrubu: tur?.tutanakGrubu ?? null,
  });
  return (
    <SharedListCard
      recordNo={`#EVRAK-${row.id.slice(0, 8)}`}
      icon={evrakFileIcon(row.mimeType, row.originalFileName)}
      iconBg="bg-primary-50 dark:bg-primary-500/20"
      iconColor="text-primary-600 dark:text-primary-400"
      title={row.title}
      description={row.originalFileName ?? undefined}
      badges={[
        <ListCardBadge key="durum" variant={durum.variant}>
          {durum.label}
        </ListCardBadge>,
        <ListCardBadge key="kategori" variant="default">
          {kategoriName}
        </ListCardBadge>,
      ]}
      metadata={[
        { label: 'Geçerlilik', value: row.validUntil ? formatEvrakDate(row.validUntil) : 'Süresiz' },
        { label: 'Yükleyen', value: row.uploadedBy ? uploaderMap[row.uploadedBy]?.name ?? 'Kullanıcı' : '—' },
      ]}
    />
  );
}

/**
 * Belgeler — ana evrak tablosu.
 *
 * Kolonlar: Evrak Adı · Kategori · Dosya Türü · Eklenme Tarihi · Geçerlilik
 * Tarihi · Kalan Süre · Durum · Yükleyen · İşlemler. Görünür kolonlar üst araç
 * çubuğundan yönetilir. Dosya türü yalnızca satırda rozet olarak gösterilir;
 * sekme yoktur. Satır işlemleri (Görüntüle/İndir/Diğer) korunur.
 */
export default function DocumentTable({
  rows,
  visibleColumns,
  turMap,
  uploaderMap,
  selectedKeys,
  onSelectionChange,
  canDelete,
  canUpdate,
  onView,
  onDownload,
  onUpdate,
  onDelete,
  isLockedRow,
}: DocumentTableProps) {
  const has = (key: string) => visibleColumns.includes(key);

  const kategoriOf = (row: EvrakData) => (row.documentTypeId ? turMap[row.documentTypeId] : undefined);

  const allColumns: Record<string, TableColumn<EvrakData>> = {
    evrak: {
      key: 'evrak',
      header: 'Evrak Adı',
      render: (row) => (
        <div className="flex items-center gap-2.5">
          <EvrakDosyaIkonu mime={row.mimeType} name={row.originalFileName} />
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground-800 truncate">{row.title}</p>
            <p className="text-xs text-foreground-500 truncate">
              {row.documentTypeId ? turMap[row.documentTypeId]?.name ?? null : null}
              {row.documentTypeId ? ' · ' : ''}
              {row.originalFileName ?? ''}
            </p>
          </div>
        </div>
      ),
    },
    kategori: {
      key: 'kategori',
      header: 'Kategori',
      render: (row) => {
        const tur = kategoriOf(row);
        const cat = categoryForType({
          kategori: tur?.kategori ?? row.kategori ?? null,
          tutanakGrubu: tur?.tutanakGrubu ?? null,
        });
        return <Badge variant={cat?.badge ?? 'default'}>{cat?.name ?? 'Diğer İSG Dokümanları'}</Badge>;
      },
    },
    dosyaTuru: {
      key: 'dosyaTuru',
      header: 'Dosya Türü',
      render: (row) => <EvrakDosyaTipiBadge mime={row.mimeType} name={row.originalFileName} />,
    },
    eklenme: {
      key: 'eklenme',
      header: 'Eklenme Tarihi',
      render: (row) => <span className="text-sm text-foreground-600">{formatEvrakDate(row.createdAt)}</span>,
    },
    gecerlilik: {
      key: 'gecerlilik',
      header: 'Geçerlilik Tarihi',
      render: (row) => (
        <span className="text-sm text-foreground-600">
          {row.validUntil ? formatEvrakDate(row.validUntil) : 'Süresiz'}
        </span>
      ),
    },
    kalan: {
      key: 'kalan',
      header: 'Kalan Süre',
      render: (row) => {
        const d = evrakDurumGorunum(row.status, row.validUntil);
        const cls =
          d.variant === 'danger' ? 'text-danger-600' : d.variant === 'warning' ? 'text-warning-600' : 'text-foreground-600';
        return <span className={`text-sm ${cls}`}>{formatKalanSure(row.validUntil)}</span>;
      },
    },
    durum: {
      key: 'durum',
      header: 'Durum',
      render: (row) => {
        const d = evrakDurumGorunum(row.status, row.validUntil);
        return <Badge variant={d.variant}>{d.label}</Badge>;
      },
    },
    yukleyen: {
      key: 'yukleyen',
      header: 'Yükleyen',
      render: (row) => {
        const u = row.uploadedBy ? uploaderMap[row.uploadedBy] : undefined;
        const name = u?.name ?? (row.uploadedBy ? 'Kullanıcı' : '—');
        return (
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-7 h-7 rounded-full bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 text-[10px] font-semibold flex items-center justify-center flex-shrink-0">
              {row.uploadedBy ? initials(name) : '—'}
            </span>
            <div className="min-w-0">
              <p className="text-xs font-medium text-foreground-700 truncate">{name}</p>
              <p className="text-[0.6875rem] text-foreground-500 truncate">{formatEvrakDateTime(row.createdAt)}</p>
            </div>
          </div>
        );
      },
    },
  };

  const columns = useMemo(
    () => Object.keys(allColumns)
      .filter((key) => has(key) && allColumns[key])
      .map((key) => allColumns[key]),
    // `allColumns`/`has` yalnızca aşağıdaki bağımlılıklardan türetilir; kolon referansı
    // sabitlenerek Table satır memoizasyonu aktive edilir.
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [visibleColumns, turMap, uploaderMap],
  );

  const rowActions = useCallback(
    (row: EvrakData) => {
      const locked = isLockedRow?.(row) ?? false;
      return (
        <DocumentActions
          row={row}
          expired={evrakSuresiDoldu(row.status, row.validUntil)}
          canDelete={canDelete && !locked}
          canUpdate={canUpdate && !locked}
          onView={() => onView(row)}
          onDownload={() => onDownload(row)}
          onUpdate={() => onUpdate(row)}
          onDelete={() => onDelete(row)}
        />
      );
    },
    [isLockedRow, canDelete, canUpdate, onView, onDownload, onUpdate, onDelete],
  );

  const handleRowClick = useCallback(
    (row: EvrakData) => {
      if (row.originalFileName) onView(row);
    },
    [onView],
  );

  const mobileCard = (row: EvrakData) => renderDocumentCard(row, turMap, uploaderMap);

  return (
    <div className="overflow-x-auto">
      <Table
        data={rows}
        columns={columns}
        keyExtractor={(r) => r.id}
        selectable
        selectedKeys={selectedKeys}
        onSelectionChange={onSelectionChange}
        rowActions={rowActions}
        onRowClick={handleRowClick}
        mobileCardRenderer={mobileCard}
      />
    </div>
  );
}