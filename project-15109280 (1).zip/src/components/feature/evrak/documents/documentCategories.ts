import type { DocumentColumnDef } from './documentsTypes';

/**
 * BELGE KATEGORİLERİ — TEK KAYNAK (source of truth).
 *
 * Sol kategori ağacının TAMAMI bu tek veri yapısından üretilir. Kategori/alt
 * kategori bilgisi JSX içine dağıtılmaz; hem Uzman hem Firma paneli aynı bu
 * yapıyı kullanır. Bu ekran YALNIZCA firma sahipli (owner_type='firma') İSG iş
 * dokümanlarını gösterir; personel belgeleri ve uzmanın kendi mesleki belgeleri
 * bu ağaca DAHİL EDİLMEZ.
 *
 * EŞLEME MANTIĞI (iş mantığı değil, yalnızca GÖRÜNTÜLEME/FİLTRE):
 *  - `dbKategoriler`: kategoriye karşılık gelen `evrak_turleri.kategori` değerleri.
 *  - `children[].codes`: alt kategoriye karşılık gelen evrak türü KODLARI.
 *  - `children[].keywords`: kod eşleşmesi yoksa evrak türü ADI/KODU içinde
 *    aranan anahtar kelimeler (Türkçe karakterden bağımsız normalize edilir).
 *  - `fallback: true` (yalnızca "Diğer İSG Dokümanları"): hiçbir kategoriye
 *    eşleşmeyen belgeleri toplar.
 *
 * HEDEF AĞAÇ (Uzman Evrakları + Firma İSG Evrakları — aynı 8 kategori):
 *   1. Risk Yönetimi
 *   2. Acil Durum
 *   3. Yıllık Planlar
 *   4. Saha Denetimleri
 *   5. Tutanaklar
 *   6. Ölçüm & Teknik
 *   7. İSG Kurulu & Organizasyon
 *   8. Diğer İSG Dokümanları
 *
 * NOT: Saha Denetim / Tutanak / Ölçüm kayıtları mevcut mimaride `is_tutanak=true`
 * veya harici modül çıktısı olarak yaşar; bu ekranda yeni belge TÜRÜ UYDURULMAZ.
 * Katalogda karşılığı olmayan kategoriler güvenle BOŞ gösterilir (filtre=0).
 */

export interface DocumentSubcategory {
  id: string;
  name: string;
  /** Eşleşecek evrak türü kodları (varsa kod bazlı eşleşme önceliklidir). */
  codes?: string[];
  /** Evrak türü adında/kodunda aranacak anahtar kelimeler. */
  keywords?: string[];
  /**
   * Alt kategoriye bağlı ÖZEL AKSİYON (varsa). Bu alan yalnızca mevcut modül
   * modallarını (Ekipler / Tatbikat / Tahliye) açar; ikinci bir belge sistemi
   * OLUŞTURMAZ. Aksiyon butonları DocumentsPage içinde sağ üstte gösterilir.
   */
  action?: DocumentActionKey;
}

/**
 * Evraklar ekranından açılabilen modül aksiyonları. Her biri MEVCUT bir modüle
 * bağlanır (acil durum ekipleri / tatbikat / tahliye planı) — yeni paralel bir
 * belge/dosya sistemi kurulmaz; üretilen ve yüklenen belgeler yine merkezi
 * `evraklar` altyapısında listelenir.
 */
export type DocumentActionKey = 'ekip' | 'tatbikat' | 'tahliye' | 'kurul' | 'noter' | 'organizasyon';

/**
 * Modül aksiyonlarının görünen adı ve ikonu — TEK kaynak. DocumentsPage aksiyon
 * butonunu bu meta üzerinden çizer; dağınık if/else yerine bu tablo kullanılır.
 */
export const DOCUMENT_ACTION_META: Record<DocumentActionKey, { label: string; icon: string }> = {
  ekip: { label: 'Acil Durum Ekiplerini Yönet', icon: 'ri-team-line' },
  tatbikat: { label: 'Tatbikatları Aç', icon: 'ri-alarm-warning-line' },
  tahliye: { label: 'Tahliye Planı Sihirbazı', icon: 'ri-route-line' },
  kurul: { label: 'İSG Kurulu Toplantıları', icon: 'ri-team-line' },
  noter: { label: 'Noter Defteri Kayıtları', icon: 'ri-book-2-line' },
  organizasyon: { label: 'İSG Organizasyonu', icon: 'ri-organization-chart' },
};

export interface DocumentCategory {
  id: string;
  name: string;
  /** Remix ikon sınıfı. */
  icon: string;
  /** İkon kutusu (soft zemin + doygun ikon) sınıfları — light + dark. */
  tile: string;
  /** Kategori rozetinin Badge varyantı. */
  badge: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'secondary' | 'accent';
  /**
   * Kategori BAŞLIĞI seçildiğinde gösterilecek MODÜL aksiyonu (varsa). Kullanıcı
   * ana kategoriyi seçtiğinde de ilgili modülü (ör. İSG Kurulu / Noter Defteri)
   * açabilmesi için tanımlanır. Alt kategorilerin aksiyonu `children[].action`.
   */
  action?: DocumentActionKey;
  /** Karşılık gelen `evrak_turleri.kategori` değerleri. */
  dbKategoriler: string[];
  /**
   * Karşılık gelen `evrak_turleri.tutanak_grubu` değerleri. `is_tutanak=true`
   * katalog türlerini (kategori='Tutanak') kategoriye bağlamanın TEK veri-driven
   * yoludur — dağınık if/else yerine bu liste kullanılır. Saha Denetimleri (SAHA)
   * ve Tutanaklar kategorileri bu alanı kullanır.
   */
  tutanakGroups?: string[];
  /** Eşleşmeyen belgeleri toplayan kategori (yalnızca "Diğer"). */
  fallback?: boolean;
  children: DocumentSubcategory[];
}

/** Türkçe karakter + ayraç farklarını normalize eder. */
export function normalizeTr(s: string): string {
  return s
    .toLocaleLowerCase('tr')
    .replace(/ı/g, 'i')
    .replace(/ş/g, 's')
    .replace(/ğ/g, 'g')
    .replace(/ü/g, 'u')
    .replace(/ö/g, 'o')
    .replace(/ç/g, 'c')
    .replace(/[^a-z0-9]/g, '');
}

/**
 * Ana kategoriler. Sıralama hedef görünümle birebir aynıdır. "Tüm Evraklar" bu
 * listede DEĞİLDİR; ağacın en üstünde sabit (pinned) satır olarak render edilir.
 */
export const DOCUMENT_CATEGORIES: DocumentCategory[] = [
  {
    id: 'risk',
    name: 'Risk Yönetimi',
    badge: 'warning',
    icon: 'ri-fire-line',
    tile: 'bg-orange-100 text-orange-600 dark:bg-orange-500/15 dark:text-orange-400',
    dbKategoriler: ['Risk Yönetimi'],
    children: [
      { id: 'risk-rd', name: 'Risk Değerlendirmeleri', codes: ['RISK_DEGERLENDIRME'], keywords: ['risk degerlendirme'] },
      { id: 'risk-ek', name: 'Risk Değerlendirmesi Ekleri', keywords: ['risk ek', 'rd ek'] },
      { id: 'risk-tehlike', name: 'Tehlike Tespitleri', keywords: ['tehlike'] },
      { id: 'risk-dof', name: 'Düzeltici / Önleyici Faaliyetler', keywords: ['duzeltici', 'onleyici', 'dof'] },
    ],
  },
  {
    id: 'acil',
    name: 'Acil Durum',
    badge: 'danger',
    icon: 'ri-alarm-warning-line',
    tile: 'bg-rose-100 text-rose-600 dark:bg-rose-500/15 dark:text-rose-400',
    dbKategoriler: ['Acil Durum'],
    children: [
      { id: 'acil-plan', name: 'Acil Durum Planları', codes: ['ACIL_DURUM_PLANI'], keywords: ['acil durum plan'] },
      { id: 'acil-ekip', name: 'Acil Durum Ekipleri', codes: ['ACIL_DURUM_EKIPLERI'], keywords: ['acil durum ekip'], action: 'ekip' },
      { id: 'acil-gorevlendirme', name: 'Ekip Görevlendirme Yazıları', keywords: ['gorevlendirme yazi', 'atama yazi', 'gorevlendirme belgesi'] },
      { id: 'acil-tatbikat', name: 'Tatbikatlar', codes: ['ACIL_DURUM_TATBIKATI'], keywords: ['tatbikat'], action: 'tatbikat' },
      { id: 'acil-kroki', name: 'Tahliye Planları / Krokiler', codes: ['ACIL_DURUM_TAHLIYE_PLANI'], keywords: ['tahliye', 'kroki'], action: 'tahliye' },
    ],
  },
  {
    id: 'planlar',
    name: 'Yıllık Planlar',
    badge: 'secondary',
    icon: 'ri-calendar-schedule-line',
    tile: 'bg-teal-100 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400',
    // 'Eğitim' kategori değeri bilinçli olarak buraya bağlanır: katalogdaki tek
    // firma-sahipli 'Eğitim' türü "Yıllık Eğitim Planı"dır (bir plandır).
    dbKategoriler: ['Planlama', 'Eğitim'],
    children: [
      { id: 'plan-calisma', name: 'Yıllık Çalışma Planı', codes: ['YILLIK_CALISMA_PLANI'], keywords: ['calisma plan'] },
      { id: 'plan-egitim', name: 'Yıllık Eğitim Planı', codes: ['YILLIK_EGITIM_PLANI'], keywords: ['egitim plan'] },
      { id: 'plan-diger', name: 'Diğer Planlar', keywords: ['plan'] },
    ],
  },
  {
    id: 'saha',
    name: 'Saha Denetimleri',
    badge: 'default',
    icon: 'ri-clipboard-line',
    tile: 'bg-secondary-100 text-secondary-600 dark:bg-secondary-500/20 dark:text-secondary-300',
    dbKategoriler: [],
    // Saha Denetim çıktıları `is_tutanak=true` + `tutanak_grubu='SAHA'` türleridir
    // (SAHA_DENETIM_TUTANAGI / SAHA_TESPIT_TUTANAGI) ve `evraklar.source_type='saha_denetim'`
    // ile bağlanır. Operasyonel `uygunsuzluklar` kayıtları fiziksel belge DEĞİLDİR ve bu
    // ağaca hiçbir şekilde girmez — yalnızca gerçek `evraklar` kaydı görünür.
    tutanakGroups: ['SAHA'],
    children: [
      { id: 'saha-denetim', name: 'Saha Denetim Tutanakları', codes: ['SAHA_DENETIM_TUTANAGI'], keywords: ['saha denetim'] },
      { id: 'saha-tespit', name: 'Saha Tespit Tutanakları', codes: ['SAHA_TESPIT_TUTANAGI'], keywords: ['saha tespit'] },
    ],
  },
  {
    id: 'tutanaklar',
    name: 'Tutanaklar',
    badge: 'default',
    icon: 'ri-file-list-3-line',
    tile: 'bg-secondary-100 text-secondary-600 dark:bg-secondary-500/20 dark:text-secondary-300',
    dbKategoriler: [],
    // SAHA dışındaki tüm tutanak grupları burada toplanır. Tutanakların ÖZEL
    // lifecycle'ı (belge_durumu / imza / revizyon) bu ortak ekranda YENİDEN
    // yönetilmez; yalnızca görüntüleme/indirme için listelenir (tek doğruluk
    // kaynağı mevcut Tutanaklar modülüdür).
    tutanakGroups: ['OLAY', 'ISG_KURULU', 'ACIL_DURUM', 'CALISMA_ORTAMI'],
    children: [
      { id: 'tutanak-olay', name: 'Olay / Kaza Tutanakları', codes: ['IS_KAZASI_INCELEME', 'RAMAK_KALA_OLAY', 'TEHLIKELI_OLAY_INCELEME'], keywords: ['kaza', 'ramak kala', 'tehlikeli olay'] },
      { id: 'tutanak-kurul', name: 'Kurul Tutanakları', codes: ['KURUL_TOPLANTI', 'KURUL_KARAR_TAKIP', 'TOPLANTI_YAPILAMADI'], keywords: ['kurul toplanti'] },
      { id: 'tutanak-acil', name: 'Acil Durum Tutanakları', codes: ['ACIL_DURUM_OLAY_TESPIT', 'TATBIKAT_DEGERLENDIRME'], keywords: ['acil durum olay', 'tatbikat degerlendirme'] },
      { id: 'tutanak-calma', name: 'Çalışma Ortamı Gözetim', codes: ['CALISMA_ORTAMI_GOZETIM'], keywords: ['calisma ortami'] },
    ],
  },
  {
    id: 'olcum',
    name: 'Ölçüm & Teknik',
    badge: 'success',
    icon: 'ri-flask-line',
    tile: 'bg-teal-100 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400',
    // Manuel belgeler bu kategoriyi `evraklar.kategori='Ölçüm & Teknik'` olarak yazar;
    // katalog türleri de aynı `evrak_turleri.kategori` değerini taşır. TEK anahtar.
    dbKategoriler: ['Ölçüm & Teknik'],
    children: [
      { id: 'olcum-gaz', name: 'Gaz / Ortam Ölçümleri', keywords: ['gaz olcum', 'ortam olcum'] },
      { id: 'olcum-gurultu', name: 'Gürültü Ölçümleri', keywords: ['gurultu'] },
      { id: 'olcum-rapor', name: 'Teknik Raporlar', keywords: ['teknik rapor', 'hidrostatik', 'analiz'] },
    ],
  },
  {
    id: 'kurul',
    name: 'İSG Kurulu & Organizasyon',
    badge: 'accent',
    icon: 'ri-team-line',
    tile: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400',
    dbKategoriler: ['İSG Kurulu', 'İSG Organizasyonu'],
    action: 'kurul',
    children: [
      { id: 'kurul-isg', name: 'İSG Kurulu Toplantıları & Belgeleri', codes: ['ISG_KURULU'], keywords: ['kurul'], action: 'kurul' },
      { id: 'kurul-org', name: 'İSG Organizasyonu', codes: ['ISG_ORGANIZASYONU'], keywords: ['organizasyon'], action: 'organizasyon' },
    ],
  },
  {
    id: 'noter',
    name: 'Noter Defteri',
    badge: 'secondary',
    icon: 'ri-book-2-line',
    tile: 'bg-slate-200 text-slate-700 dark:bg-slate-500/20 dark:text-slate-300',
    // Onaylı defter (noter defteri) kayıtları ayrı bir modülde (noter_defterleri),
    // evraklar tablosunda DEĞİL. Bu kategori bir GİRİŞ NOKTASIDIR: seçilince üstte
    // "Noter Defteri Kayıtları" butonu çıkar ve modülü açar. Belge filtresi boş kalır.
    dbKategoriler: ['Noter Defteri'],
    action: 'noter',
    children: [
      { id: 'noter-kayit', name: 'Tespit ve Öneri Kayıtları', codes: ['NOTER_DEFTERI'], keywords: ['noter', 'onaylı defter', 'tespit', 'öneri'], action: 'noter' },
    ],
  },
  {
    id: 'diger',
    name: 'Diğer İSG Dokümanları',
    badge: 'default',
    icon: 'ri-folder-3-line',
    tile: 'bg-background-200 text-foreground-500 dark:bg-background-300/40 dark:text-foreground-400',
    dbKategoriler: ['Faaliyet Koşulu'],
    fallback: true,
    children: [],
  },
];

export const DOCUMENT_CATEGORY_MAP: Record<string, DocumentCategory> = DOCUMENT_CATEGORIES.reduce(
  (acc, c) => {
    acc[c.id] = c;
    return acc;
  },
  {} as Record<string, DocumentCategory>,
);

/** Bir `evrak_turleri.kategori` değerine karşılık gelen ana kategori (varsa). */
export function dbKategoriToCategory(dbKategori: string | null | undefined): DocumentCategory | undefined {
  if (!dbKategori) return undefined;
  const n = normalizeTr(dbKategori);
  return DOCUMENT_CATEGORIES.find((c) => c.dbKategoriler.some((k) => normalizeTr(k) === n));
}

/** Belge satırındaki "Kategori" rozeti için görünen ad (eşleşme yoksa "Diğer"). */
export function dbKategoriDisplayName(dbKategori: string | null | undefined): string {
  return dbKategoriToCategory(dbKategori)?.name ?? 'Diğer İSG Dokümanları';
}

/** Belge satırındaki "Kategori" rozetinin varyantı. */
export function dbKategoriBadge(dbKategori: string | null | undefined): DocumentCategory['badge'] {
  return dbKategoriToCategory(dbKategori)?.badge ?? 'default';
}

/**
 * Bir belge türünün (kategori + tutanak grubu) ait olduğu kategori. Tutanak türleri
 * `kategori='Tutanak'` taşıdığı için önce dbKategori denenir; eşleşme yoksa
 * `tutanak_grubu` üzerinden Saha Denetimleri / Tutanaklar kategorisi bulunur.
 */
export function categoryForType(t: {
  kategori?: string | null;
  tutanakGrubu?: string | null;
}): DocumentCategory | undefined {
  const byKat = dbKategoriToCategory(t.kategori);
  if (byKat) return byKat;
  if (t.tutanakGrubu) {
    return DOCUMENT_CATEGORIES.find((c) => c.tutanakGroups?.includes(t.tutanakGrubu as string));
  }
  return undefined;
}

/** Belge satırındaki "Kategori" rozeti için görünen ad (tutanak grubu dahil). */
export function categoryDisplayNameForType(t: {
  kategori?: string | null;
  tutanakGrubu?: string | null;
}): string {
  return categoryForType(t)?.name ?? 'Diğer İSG Dokümanları';
}

/** Evrak türünün, kategori eşlemesi için ihtiyaç duyulan alanları. */
export interface DocTypeLike {
  id: string;
  code: string;
  name: string;
  kategori: string | null;
  /** `is_tutanak=true` ise tür bir tutanak türüdür (kategori='Tutanak'). */
  isTutanak?: boolean;
  /** Tutanak alt grubu (SAHA / OLAY / ISG_KURULU / ACIL_DURUM / CALISMA_ORTAMI). */
  tutanakGrubu?: string | null;
}

/**
 * Bir ALT kategoriye bağlı özel aksiyon anahtarını (varsa) döndürür. Evraklar
 * ekranındaki seçim bu anahtar üzerinden ilgili modül modalını açar.
 */
export function subAction(categoryId: string, subId: string): DocumentActionKey | undefined {
  const cat = DOCUMENT_CATEGORY_MAP[categoryId];
  return cat?.children.find((c) => c.id === subId)?.action;
}

/**
 * Alt kategori anahtarından (child id) görünen adı çözer. Kategori ağacı TEK
 * kaynağından (`DOCUMENT_CATEGORIES`) okur; sayaç/liste/detay aynı sonucu gösterir.
 */
export function resolveSubcategoryLabel(subId: string | null | undefined): string | null {
  if (!subId) return null;
  for (const c of DOCUMENT_CATEGORIES) {
    const s = c.children.find((x) => x.id === subId);
    if (s) return s.name;
  }
  return null;
}

/** Bir evrak türü, verilen ALT kategoriyle eşleşiyor mu? */
export function subMatchesTur(sub: DocumentSubcategory, tur: DocTypeLike): boolean {
  if (sub.codes && sub.codes.length > 0) return sub.codes.includes(tur.code);
  if (sub.keywords && sub.keywords.length > 0) {
    const hay = normalizeTr(`${tur.name} ${tur.code}`);
    return sub.keywords.some((k) => hay.includes(normalizeTr(k)));
  }
  return false;
}

/** Fallback ("Diğer İSG Dokümanları") kategorisi — catch-all. */
const FALLBACK_CATEGORY: DocumentCategory = DOCUMENT_CATEGORIES.find((c) => c.fallback) as DocumentCategory;

/**
 * MERKEZİ KATEGORİ ÇÖZÜMLEYİCİ — bir DB kategori ANAHTARINI (evrak_turleri.kategori
 * veya manuel belge evraklar.kategori) tek bir display kategorisine eşler.
 *
 * Bu fonksiyon SAYAÇ, LİSTE, ROZET, BREADCRUMB ve FİLTRE tarafından ORTAK kullanılır.
 * Aynı belge her yerde aynı kategoriye ait görünür; sayaç ile liste ayrışamaz.
 */
export function kategoriKeyToCategory(key: string | null | undefined): DocumentCategory {
  if (!key) return FALLBACK_CATEGORY;
  const n = normalizeTr(key);
  for (const c of DOCUMENT_CATEGORIES) {
    if (c.fallback) continue;
    if (c.dbKategoriler.some((k) => normalizeTr(k) === n)) return c;
  }
  return FALLBACK_CATEGORY;
}

/**
 * Bir evrak TÜRÜNÜ ait olduğu kategori. Tutanak türlerinde önce `tutanak_grubu`
 * (SAHA → Saha Denetimleri, diğerleri → Tutanaklar) esas alınır; kalanlarda
 * katalog kategori anahtarı çözümlenir.
 */
export function resolveTypeCategory(t: DocTypeLike): DocumentCategory {
  if (t.tutanakGrubu) {
    const byGroup = DOCUMENT_CATEGORIES.find((c) => c.tutanakGroups?.includes(t.tutanakGrubu as string));
    if (byGroup) return byGroup;
  }
  return kategoriKeyToCategory(t.kategori);
}

/** Bir EVRAK SATIRININ kategorisi (tür varsa türden, yoksa manuel kategori anahtarından). */
export function resolveEvrakCategory(e: {
  kategori?: string | null;
  turKategori?: string | null;
  tutanakGrubu?: string | null;
}): DocumentCategory {
  if (e.tutanakGrubu) {
    const byGroup = DOCUMENT_CATEGORIES.find((c) => c.tutanakGroups?.includes(e.tutanakGrubu as string));
    if (byGroup) return byGroup;
  }
  return kategoriKeyToCategory(e.turKategori ?? e.kategori ?? null);
}

/**
 * Bir ana kategoriye atanan evrak tür id'leri — SAYAÇ ile BİREBİR aynı kapsam.
 * `resolveTypeCategory` üzerinden çalışır; gevşek alt-kategori kelime eşleşmesi
 * parent kapsamına KARIŞMAZ (kategori sızıntısı olmaz).
 */
export function categoryTurIds(cat: DocumentCategory, turler: DocTypeLike[]): string[] {
  return turler.filter((t) => resolveTypeCategory(t).id === cat.id).map((t) => t.id);
}

/** Hiçbir gerçek kategoriye eşleşmeyen (fallback/"Diğer") evrak tür id'leri. */
export function fallbackTurIds(turler: DocTypeLike[]): string[] {
  return categoryTurIds(FALLBACK_CATEGORY, turler);
}

/**
 * Bir evrak türünün, ait olduğu kategori içindeki TEK alt kategorisi (exclusive).
 * Önce KOD eşleşmesi (kesin), sonra anahtar kelime (bildirim sırasına göre).
 * Böylece bir tür iki kardeş alt kategoride birden görünmez.
 */
export function subForType(cat: DocumentCategory, t: DocTypeLike): string | undefined {
  for (const sub of cat.children) {
    if (sub.codes && sub.codes.length > 0 && sub.codes.includes(t.code)) return sub.id;
  }
  const hay = normalizeTr(`${t.name} ${t.code}`);
  for (const sub of cat.children) {
    if (!sub.codes?.length && sub.keywords?.length && sub.keywords.some((k) => hay.includes(normalizeTr(k)))) {
      return sub.id;
    }
  }
  return undefined;
}

/** Bir ALT kategoriye ÖZEL atanan (kardeşlere sızmayan) evrak tür id'leri. */
export function subOnlyTypeIds(cat: DocumentCategory, subId: string, turler: DocTypeLike[]): string[] {
  return turler
    .filter((t) => resolveTypeCategory(t).id === cat.id)
    .filter((t) => subForType(cat, t) === subId)
    .map((t) => t.id);
}

/**
 * Tabloda gösterilebilecek kolonlar (sıralama referanstaki gibidir).
 * "İŞLEMLER" kolonu her zaman gösterilir; bu listede yer almaz.
 */
export const DOCUMENT_COLUMNS: DocumentColumnDef[] = [
  { key: 'evrak', label: 'Evrak Adı', always: true },
  { key: 'kategori', label: 'Kategori' },
  { key: 'dosyaTuru', label: 'Dosya Türü' },
  { key: 'eklenme', label: 'Eklenme Tarihi' },
  { key: 'gecerlilik', label: 'Geçerlilik Tarihi' },
  { key: 'kalan', label: 'Kalan Süre' },
  { key: 'durum', label: 'Durum' },
  { key: 'yukleyen', label: 'Yükleyen' },
];