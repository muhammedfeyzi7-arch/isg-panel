import type { ReactNode } from 'react';
import {
  DOCUMENT_CATEGORIES,
  normalizeTr,
  type DocumentCategory,
} from './documentCategories';
import type { DocumentSelection } from './documentsTypes';

interface DocumentCategoryTreeProps {
  /** Kategori id → belge adedi. */
  counts: Record<string, number>;
  /** Kategori arama metni (küçük harf normalize edilerek eşleştirilir). */
  query: string;
  /** Açık (genişletilmiş) kategori id'leri. */
  openIds: Set<string>;
  selection: DocumentSelection;
  onSelectCategory: (categoryId: string) => void;
  onToggleCategory: (categoryId: string) => void;
  onSelectAlt: (categoryId: string, subId: string) => void;
}

interface TreeRowProps {
  icon: string;
  tile: string;
  label: string;
  count?: number;
  active: boolean;
  onClick: () => void;
  leading?: ReactNode;
  indent?: boolean;
  muted?: boolean;
}

function TreeRow({ icon, tile, label, count, active, onClick, leading, indent, muted }: TreeRowProps) {
  return (
    <div
      className={`group flex items-center rounded-md ${
        active ? 'bg-primary-50 dark:bg-primary-500/15' : 'hover:bg-background-200 dark:hover:bg-background-300/30'
      }`}
    >
      {leading}
      <button
        type="button"
        onClick={onClick}
        className={`flex flex-1 min-w-0 items-center gap-2 py-1.5 text-left cursor-pointer ${
          indent ? 'pl-1 pr-2' : 'px-2'
        }`}
      >
        <span
          className={`${indent ? 'w-5 h-5' : 'w-6 h-6'} rounded-md flex items-center justify-center flex-shrink-0 ${tile}`}
        >
          <i className={`${icon} text-xs`} />
        </span>
        {/* Hiyerarşi: ANA kategori 14px/500 · ALT kategori 13px/400.
            Alt kategori ASLA üst kategoriden büyük olmaz (ölçekli rem). */}
        <span
          className={`flex-1 truncate ${indent ? 'text-[0.8125rem]' : 'text-sm'} ${
            active
              ? 'font-semibold text-foreground-900'
              : muted
              ? 'font-normal text-foreground-500'
              : 'font-medium text-foreground-700'
          }`}
        >
          {label}
        </span>
        {count !== undefined && (
          <span
            className={`text-xs tabular-nums flex-shrink-0 font-medium ${
              active ? 'text-foreground-700 font-semibold' : 'text-foreground-400'
            }`}
          >
            {count}
          </span>
        )}
      </button>
    </div>
  );
}

/**
 * Belgeler — katmanlı KATEGORİ AĞACI.
 *
 * Her ana kategori katlanabilir bir üst düğümdür; açıldığında alt kategoriler
 * görünür. Ağaç, TEK kategori veri yapısından (`DOCUMENT_CATEGORIES`) üretilir;
 * hem Uzman hem Firma paneli aynı bileşeni kullanır. İlk açılışta tüm
 * kategoriler KAPALIDIR — açma durumu dışarıdan (page) yönetilir.
 */
export default function DocumentCategoryTree({
  counts,
  query,
  openIds,
  selection,
  onSelectCategory,
  onToggleCategory,
  onSelectAlt,
}: DocumentCategoryTreeProps) {
  const q = normalizeTr(query.trim());

  const visibleCategories = DOCUMENT_CATEGORIES.filter((cat) => {
    if (!q) return true;
    if (normalizeTr(cat.name).includes(q)) return true;
    return cat.children.some((sub) => normalizeTr(sub.name).includes(q));
  });

  const parentSelected = (cat: DocumentCategory) =>
    selection.type === 'kategori' && selection.categoryId === cat.id;

  return (
    <nav aria-label="Belge kategorileri" className="flex flex-col gap-0.5">
      {visibleCategories.map((cat) => {
        const count = counts[cat.id] ?? 0;
        // Arama sırasında eşleşen kategoriler otomatik açılır.
        const parentNameMatches = !q || normalizeTr(cat.name).includes(q);
        const expanded = openIds.has(cat.id) || (q !== '' && parentNameMatches && cat.children.length > 0);
        const children = q && !parentNameMatches
          ? cat.children.filter((sub) => normalizeTr(sub.name).includes(q))
          : cat.children;

        return (
          <div key={cat.id} className="flex flex-col">
            <TreeRow
              icon={cat.icon}
              tile={cat.tile}
              label={cat.name}
              count={count}
              active={parentSelected(cat)}
              onClick={() => onSelectCategory(cat.id)}
              leading={
                <button
                  type="button"
                  onClick={() => onToggleCategory(cat.id)}
                  aria-label={expanded ? 'Daralt' : 'Genişlet'}
                  aria-expanded={expanded}
                  className={`w-5 h-5 flex items-center justify-center rounded text-foreground-400 hover:text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer ${
                    cat.children.length > 0 ? '' : 'invisible'
                  }`}
                >
                  <i className={`${expanded ? 'ri-arrow-down-s-line' : 'ri-arrow-right-s-line'} text-sm`} />
                </button>
              }
            />
            {expanded &&
              children.map((sub) => (
                <TreeRow
                  key={sub.id}
                  icon="ri-file-text-line"
                  tile="bg-background-200 text-foreground-500 dark:bg-background-300/60 dark:text-foreground-400"
                  label={sub.name}
                  active={
                    selection.type === 'alt' &&
                    selection.categoryId === cat.id &&
                    selection.subId === sub.id
                  }
                  muted
                  indent
                  onClick={() => onSelectAlt(cat.id, sub.id)}
                />
              ))}
          </div>
        );
      })}

      {visibleCategories.length === 0 && (
        <p className="px-2 py-3 text-xs text-foreground-400">Kategori bulunamadı.</p>
      )}
    </nav>
  );
}