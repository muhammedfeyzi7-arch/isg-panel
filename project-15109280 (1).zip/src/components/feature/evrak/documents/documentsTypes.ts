/**
 * EVRAKLAR modülü — ortak tip tanımları.
 *
 * Bu tipler hem Uzman hem Firma panelinde kullanılan TEK Evraklar sisteminin
 * seçim, sıralama ve görünüm durumlarını tanımlar. Modüle özel ikinci bir tip
 * üretilmez; tüm alt bileşenler buradan tüketir.
 */

/** Sol kategori ağacındaki seçim kapsamı. */
export type DocumentSelection =
  | { type: 'all' }
  | { type: 'kategori'; categoryId: string }
  | { type: 'alt'; categoryId: string; subId: string };

/** Tablo sıralama seçenekleri (tek dropdown). */
export type DocumentSortKey = 'new' | 'old' | 'title' | 'expiry';

/** Liste / kart görünümü. */
export type DocumentViewMode = 'liste' | 'kart';

/** Tablo kolonu tanımı (görünürlük yönetimi için). */
export interface DocumentColumnDef {
  key: string;
  label: string;
  /** Zorunlu kolonlar gizlenemez (ör. Evrak Adı). */
  always?: boolean;
}