import { useRef, useState } from 'react';
import Search from '@/components/ui/Search';
import Select from '@/components/ui/Select';
import DropdownPanel from '@/components/ui/DropdownPanel';
import { DOCUMENT_COLUMNS } from './documentCategories';
import type { DocumentSortKey, DocumentViewMode } from './documentsTypes';

interface DocumentsToolbarProps {
  /** Breadcrumb etiketleri: ['Evraklar', 'Risk Yönetimi', ...]. */
  breadcrumb: string[];
  count: number;
  search: string;
  onSearch: (value: string) => void;
  statusFilter: string;
  statusOptions: { value: string; label: string }[];
  onStatusChange: (value: string) => void;
  turFilter: string;
  turOptions: { value: string; label: string; group?: string }[];
  onTurChange: (value: string) => void;
  sort: DocumentSortKey;
  onSortChange: (value: DocumentSortKey) => void;
  visibleColumns: string[];
  onToggleColumn: (key: string) => void;
  viewMode: DocumentViewMode;
  onViewModeChange: (mode: DocumentViewMode) => void;
}

const SORT_OPTIONS: { value: DocumentSortKey; label: string; icon: string }[] = [
  { value: 'new', label: 'Tarih (Yeni → Eski)', icon: 'ri-sort-desc' },
  { value: 'old', label: 'Tarih (Eski → Yeni)', icon: 'ri-sort-asc' },
  { value: 'title', label: 'Evrak Adı (A → Z)', icon: 'ri-sort-alphabet-asc' },
  { value: 'expiry', label: 'Geçerlilik Tarihi', icon: 'ri-calendar-line' },
];

/**
 * Belgeler — üst araç alanı.
 *
 * Evrak arama, filtre, sıralama, sütun seçimi ve görünüm (liste/kart) kontrolü
 * TEK yerde toplanır. Dosya türü (Word/PDF/Excel) için SEKME YOKTUR; dosya türü
 * yalnızca tablo satırında gösterilir.
 */
export default function DocumentsToolbar({
  breadcrumb,
  count,
  search,
  onSearch,
  statusFilter,
  statusOptions,
  onStatusChange,
  turFilter,
  turOptions,
  onTurChange,
  sort,
  onSortChange,
  visibleColumns,
  onToggleColumn,
  viewMode,
  onViewModeChange,
}: DocumentsToolbarProps) {
  const [filtreAcik, setFiltreAcik] = useState(false);
  const [sortOpen, setSortOpen] = useState(false);
  const [columnsOpen, setColumnsOpen] = useState(false);
  const sortAnchor = useRef<HTMLButtonElement>(null);
  const columnsAnchor = useRef<HTMLButtonElement>(null);

  const activeFilterCount = (statusFilter ? 1 : 0) + (turFilter ? 1 : 0);
  const currentSort = SORT_OPTIONS.find((s) => s.value === sort) ?? SORT_OPTIONS[0];

  return (
    <div className="flex flex-col gap-2">
      <div className="flex flex-col gap-2 lg:flex-row lg:items-center lg:justify-between">
        {/* Breadcrumb + toplam */}
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 isg-text-small text-foreground-500 min-w-0 flex-wrap">
            <i className="ri-folder-3-line text-foreground-400 flex-shrink-0" />
            {breadcrumb.map((part, idx) => (
              <span key={`${part}-${idx}`} className="flex items-center gap-1.5 min-w-0">
                {idx > 0 && <i className="ri-arrow-right-s-line text-foreground-300 flex-shrink-0" />}
                <span className={idx === breadcrumb.length - 1 ? 'font-semibold text-foreground-800 truncate' : 'truncate'}>
                  {part}
                </span>
              </span>
            ))}
          </div>
          <p className="isg-text-caption text-foreground-500">
            Toplam <span className="font-semibold text-foreground-800">{count}</span> evrak listeleniyor.
          </p>
        </div>

        {/* Kontroller */}
        <div className="isg-toolbar lg:justify-end">
          <Search
            placeholder="Evrak ara... (ad, açıklama, etiket)"
            value={search}
            onSearch={onSearch}
            size="sm"
            debounceMs={400}
            className="w-full sm:w-60"
          />

          <button
            type="button"
            onClick={() => setFiltreAcik((o) => !o)}
            aria-expanded={filtreAcik}
            className={`isg-btn isg-btn-sm whitespace-nowrap cursor-pointer ${filtreAcik ? 'isg-btn-outline' : 'isg-btn-secondary'}`}
          >
            <i className="ri-filter-3-line" />
            Filtrele
            {activeFilterCount > 0 && (
              <span className="ml-0.5 inline-flex items-center justify-center min-w-4 h-4 px-1 rounded-full bg-primary-500 text-inverse text-[10px] font-semibold">
                {activeFilterCount}
              </span>
            )}
          </button>

          {/* Sıralama */}
          <button
            ref={sortAnchor}
            type="button"
            onClick={() => setSortOpen((o) => !o)}
            aria-haspopup="menu"
            aria-expanded={sortOpen}
            className="isg-btn isg-btn-sm isg-btn-secondary whitespace-nowrap cursor-pointer"
          >
            <i className="ri-sort-desc" />
            <span className="hidden sm:inline">{currentSort.label}</span>
            <i className="ri-arrow-down-s-line text-foreground-400" />
          </button>
          <DropdownPanel
            open={sortOpen}
            anchorRef={sortAnchor}
            onClose={() => setSortOpen(false)}
            role="menu"
            align="end"
            minWidth={210}
            className="isg-popover py-1"
          >
            {SORT_OPTIONS.map((opt) => (
              <button
                key={opt.value}
                type="button"
                role="menuitem"
                onClick={() => {
                  onSortChange(opt.value);
                  setSortOpen(false);
                }}
                className={`w-full text-left px-3 py-2 text-sm flex items-center gap-2 cursor-pointer whitespace-nowrap ${
                  sort === opt.value
                    ? 'text-primary-700 dark:text-primary-400 bg-primary-50/70 dark:bg-primary-500/15'
                    : 'text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/30'
                }`}
              >
                <i className={opt.icon} />
                <span className="flex-1">{opt.label}</span>
                {sort === opt.value && <i className="ri-check-line text-primary-500" />}
              </button>
            ))}
          </DropdownPanel>

          {/* Sütunlar */}
          <button
            ref={columnsAnchor}
            type="button"
            onClick={() => setColumnsOpen((o) => !o)}
            aria-haspopup="menu"
            aria-expanded={columnsOpen}
            className="isg-btn isg-btn-sm isg-btn-secondary whitespace-nowrap cursor-pointer"
          >
            <i className="ri-layout-column-line" />
            <span className="hidden sm:inline">Sütunlar</span>
          </button>
          <DropdownPanel
            open={columnsOpen}
            anchorRef={columnsAnchor}
            onClose={() => setColumnsOpen(false)}
            role="menu"
            align="end"
            minWidth={200}
            className="isg-popover py-1"
          >
            <div className="px-3 pt-2 pb-1 text-[0.6875rem] font-semibold uppercase tracking-wide text-foreground-400">
              Görünür Sütunlar
            </div>
            {DOCUMENT_COLUMNS.map((col) => {
              const checked = col.always || visibleColumns.includes(col.key);
              return (
                <button
                  key={col.key}
                  type="button"
                  role="menuitemcheckbox"
                  aria-checked={checked}
                  disabled={col.always}
                  onClick={() => !col.always && onToggleColumn(col.key)}
                  className={`w-full text-left px-3 py-1.5 text-sm flex items-center gap-2.5 ${
                    col.always ? 'opacity-60 cursor-default' : 'cursor-pointer hover:bg-background-200 dark:hover:bg-background-300/30'
                  }`}
                >
                  <span
                    className={`w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 ${
                      checked ? 'bg-primary-500 border-primary-500' : 'border-background-400'
                    }`}
                  >
                    {checked && <i className="ri-check-line text-inverse text-[10px]" />}
                  </span>
                  <span className="truncate text-foreground-700">{col.label}</span>
                </button>
              );
            })}
          </DropdownPanel>

          {/* Görünüm */}
          <div className="flex items-center gap-1 p-1 rounded-lg border border-background-300/60 dark:border-background-400/30 bg-background-100 dark:bg-background-200/60">
            <button
              type="button"
              onClick={() => onViewModeChange('liste')}
              aria-label="Liste görünümü"
              title="Liste görünümü"
              className={`isg-iconbtn isg-iconbtn-sm cursor-pointer transition-colors ${
                viewMode === 'liste'
                  ? 'bg-primary-500 text-inverse'
                  : 'text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40'
              }`}
            >
              <i className="ri-list-check-2" />
            </button>
            <button
              type="button"
              onClick={() => onViewModeChange('kart')}
              aria-label="Kart görünümü"
              title="Kart görünümü"
              className={`isg-iconbtn isg-iconbtn-sm cursor-pointer transition-colors ${
                viewMode === 'kart'
                  ? 'bg-primary-500 text-inverse'
                  : 'text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40'
              }`}
            >
              <i className="ri-layout-grid-line" />
            </button>
          </div>
        </div>
      </div>

      {/* Filtre paneli */}
      {filtreAcik && (
        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-background-300/50 dark:border-background-400/25 bg-background-100 dark:bg-background-200/40 p-2.5">
          <div className="w-full sm:w-56">
            <Select
              size="sm"
              placeholder="Tüm Türler"
              searchable
              options={[{ value: '', label: 'Tüm Türler' }, ...turOptions]}
              value={turFilter}
              onChange={(e) => onTurChange(e.target.value)}
            />
          </div>
          <div className="w-full sm:w-56">
            <Select
              size="sm"
              placeholder="Tüm Durumlar"
              options={[{ value: '', label: 'Tüm Durumlar' }, ...statusOptions]}
              value={statusFilter}
              onChange={(e) => onStatusChange(e.target.value)}
            />
          </div>
          {activeFilterCount > 0 && (
            <button
              type="button"
              onClick={() => {
                onTurChange('');
                onStatusChange('');
              }}
              className="isg-btn isg-btn-sm isg-btn-ghost whitespace-nowrap cursor-pointer"
            >
              <i className="ri-refresh-line" />
              Filtreleri Sıfırla
            </button>
          )}
        </div>
      )}
    </div>
  );
}