import DocumentsPage from './documents/DocumentsPage';

interface EvrakYonetimProps {
  firmaId: string;
  role: 'uzman' | 'firma';
}

/**
 * EVRAKLAR — Uzman ve Firma panellerinin ORTAK giriş noktası.
 *
 * Tüm ekran yeni `DocumentsPage` modülünden gelir (kategori ağacı + evrak
 * tablosu). İki panel için AYRI ekran kodlanmaz; bu ince sarmalayıcı yalnızca
 * firma kapsamını ve rolü iletir. Eski (sökülen) Evraklar UI'ı buradan artık
 * referans edilmez.
 */
export default function EvrakYonetim({ firmaId, role }: EvrakYonetimProps) {
  return <DocumentsPage firmaId={firmaId} role={role} />;
}