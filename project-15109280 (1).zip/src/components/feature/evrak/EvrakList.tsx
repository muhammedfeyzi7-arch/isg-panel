import { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import FilterBar from '@/components/ui/FilterBar';
import type { FilterField, FilterValue } from '@/components/ui/FilterBar';
import Pagination from '@/components/ui/Pagination';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import Loading from '@/components/ui/Loading';
import ContextMenu from '@/components/ui/ContextMenu';
import SharedListCard, { ListCardBadge } from '@/components/ui/SharedListCard';
import EvrakDetailModal from './EvrakDetailModal';
import EvrakUploadModal from './EvrakUploadModal';
import { useModalActions } from '@/hooks/useModal';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import {
  type EvrakData,
  type EvrakStatus,
  type EvrakOwnerType,
  fetchEvraklarPage,
  fetchEvrakTurleri,
  fetchFirmaGereksinimleri,
  fetchPersonelOptions,
} from '@/lib/evrakService';
import { evrakStatusBadgeVariant, formatEvrakDate, evrakFileIcon } from './evrakUi';
import { EvrakDosyaIkonu } from './EvrakDosyaTipi';

interface EvrakListProps {
  role: 'firma' | 'uzman' | 'hekim';
  title: string;
  subtitle: string;
  emptyIcon: string;
  emptyTitle: string;
  emptyDescription: string;
  /**
   * Yalnızca SAĞLIK nitelikli evrakları (is_health) listeler ve yükler. Sağlık
   * Evrakları ekranında kullanılır: firma seviyesi İSG dokümanları (risk değerlendirmesi,
   * acil durum planı vb.) bu listeye düşmez — yalnızca kişisel sağlık belgeleri görünür.
   */
  healthOnly?: boolean;
  /**
   * Özel yükleme akışı: verilirse "Yükle" butonu varsayılan evrak modalı yerine bu
   * callback'i çağırır (kendisine liste yenileme fonksiyonu verilir). Sağlık Evrakları
   * ekranında birleşik "muayene kaydı + belge" modalını açmak için kullanılır.
   */
  onRequestUpload?: (reload: () => void) => void;
}

function asStr(v: FilterValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

const OWNER_TYPE_OPTIONS = [
  { value: 'firma', label: 'Firma Evrakı' },
  { value: 'personel', label: 'Kişisel Evrak' },
];

const STATUS_OPTIONS = [
  { value: 'pending', label: 'Doğrulama Bekliyor' },
  { value: 'valid', label: 'Geçerli' },
  { value: 'expiring', label: 'Süresi Yaklaşıyor' },
  { value: 'expired', label: 'Süresi Doldu' },
  { value: 'rejected', label: 'Reddedildi' },
  { value: 'archived', label: 'Arşivlendi' },
  { value: 'verification_required', label: 'Doğrulama Gerekli' },
];

function MobileEvrakCard({
  row,
  turName,
  reqTitle,
  onDetail,
}: {
  row: EvrakData;
  turName?: string;
  reqTitle?: string;
  onDetail: (row: EvrakData) => void;
}) {
  return (
    <SharedListCard
      recordNo={`#EVRAK-${row.id.slice(0, 8)}`}
      icon={evrakFileIcon(row.mimeType, row.originalFileName)}
      iconBg="bg-primary-50 dark:bg-primary-500/20"
      iconColor="text-primary-600 dark:text-primary-400"
      title={row.title}
      description={row.originalFileName ?? undefined}
      badges={[
        <ListCardBadge key="durum" variant={evrakStatusBadgeVariant(row.status)}>
          {row.statusLabel}
        </ListCardBadge>,
      ]}
      metadata={[
        { label: 'Tür', value: turName ?? '—' },
        { label: 'Bitiş', value: row.validUntil ? formatEvrakDate(row.validUntil) : 'Süresiz' },
      ]}
      extraBadges={reqTitle ? [<ListCardBadge key="req" variant="info">{reqTitle}</ListCardBadge>] : []}
      onClick={() => onDetail(row)}
    />
  );
}

export default function EvrakList({
  role,
  title,
  subtitle,
  emptyIcon,
  emptyTitle,
  emptyDescription,
  healthOnly = false,
  onRequestUpload,
}: EvrakListProps) {
  const { openModal, closeModal } = useModalActions();

  const uploadModalIdRef = useRef('');
  const detailModalIdRef = useRef('');

  const [rows, setRows] = useState<EvrakData[]>([]);
  const [count, setCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const [turMap, setTurMap] = useState<Record<string, string>>({});
  const [requirementMap, setRequirementMap] = useState<Record<string, string>>({});
  // Sağlık nitelikli evrak türü id'leri (is_health). healthOnly modda liste bu id'lere
  // kilitlenir; türler yüklenene kadar (null) liste isteği atılmaz (yanlış/anlık tüm-list görünümü olmaz).
  const [healthTypeIds, setHealthTypeIds] = useState<string[] | null>(null);
  // healthOnly modda personel id → "Ad Soyad" (belgenin hangi personelin olduğu görünsün).
  const [personelMap, setPersonelMap] = useState<Record<string, string>>({});

  // Referans haritaları (tür adı + yükümlülük başlığı) — tek seferde, N+1 yok.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [turlar, gereksinimler] = await Promise.all([fetchEvrakTurleri(), fetchFirmaGereksinimleri()]);
        if (cancelled) return;
        const tm: Record<string, string> = {};
        const healthIds: string[] = [];
        for (const t of turlar) {
          tm[t.id] = t.name;
          if (t.isHealth) healthIds.push(t.id);
        }
        setTurMap(tm);
        setHealthTypeIds(healthIds);
        const rm: Record<string, string> = {};
        for (const g of gereksinimler) rm[g.id] = g.title ?? g.requirementCode;
        setRequirementMap(rm);
      } catch {
        // Haritalar boş kalırsa '—' gösterilir.
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // healthOnly modda personel adlarını bir kez yükle (belgenin kime ait olduğu görünsün).
  useEffect(() => {
    if (!healthOnly) return;
    let cancelled = false;
    fetchPersonelOptions()
      .then((opts) => {
        if (cancelled) return;
        const m: Record<string, string> = {};
        for (const o of opts) m[o.value] = o.label;
        setPersonelMap(m);
      })
      .catch(() => {
        // Personel adları yüklenemezse '—' gösterilir.
      });
    return () => {
      cancelled = true;
    };
  }, [healthOnly]);

  const buildQuery = useCallback(
    () => ({
      search: searchQuery || undefined,
      ownerType: (asStr(filterValues['owner']) as EvrakOwnerType | '') || '',
      status: (asStr(filterValues['status']) as EvrakStatus | '') || '',
      documentTypeIds: healthOnly ? (healthTypeIds ?? []) : undefined,
      page,
      pageSize,
    }),
    [searchQuery, filterValues, page, pageSize, healthOnly, healthTypeIds],
  );

  const load = useCallback(() => {
    setLoading(true);
    setError(null);
    // healthOnly: türler yüklenmeden istek atılmaz; tür listesi boşsa tüm-listeye düşmemek
    // için boş kümeyle sorgu YAPILMAZ, boş sonuç gösterilir.
    if (healthOnly && (!healthTypeIds || healthTypeIds.length === 0)) {
      setRows([]);
      setCount(0);
      setLoading(false);
      return;
    }
    fetchEvraklarPage(buildQuery())
      .then((res) => {
        setRows(res.data);
        setCount(res.count);
      })
      .catch((e) => {
        setError(friendlyErrorMessage(e, 'Evraklar yüklenemedi. Lütfen tekrar deneyin.'));
        setRows([]);
        setCount(0);
      })
      .finally(() => setLoading(false));
  }, [buildQuery]);

  useEffect(() => {
    // healthOnly modda sağlık türleri gelene kadar bekle (yanlış kapsamla yükleme yapma).
    if (healthOnly && healthTypeIds === null) return;
    load();
  }, [load, healthOnly, healthTypeIds]);

  const handleOpenUpload = useCallback(() => {
    if (onRequestUpload) {
      onRequestUpload(load);
      return;
    }
    const id = openModal({
      title: 'Evrak Yükle',
      description: 'Dosya bilgilerini doldurup yükleyin.',
      width: 560,
      minWidth: 420,
      minHeight: 480,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EvrakUploadModal role={role} healthOnly={healthOnly} onClose={() => closeModal(uploadModalIdRef.current)} onUploaded={load} />
      ),
    });
    uploadModalIdRef.current = id;
  }, [openModal, closeModal, load, role, healthOnly, onRequestUpload]);

  const handleOpenDetail = useCallback(
    (row: EvrakData) => {
      const id = openModal({
        title: row.title,
        description: row.originalFileName ?? 'Evrak detayı',
        variant: 'detail',
        width: 1280,
        height: 840,
        minWidth: 720,
        minHeight: 560,
        maximizable: true,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: (
          <EvrakDetailModal
            evrak={row}
            requirementTitle={row.requirementId ? requirementMap[row.requirementId] ?? null : null}
            documentTypeName={row.documentTypeId ? turMap[row.documentTypeId] ?? null : null}
            uploadedBy={row.uploadedBy}
            onClose={() => closeModal(detailModalIdRef.current)}
            onChanged={load}
          />
        ),
      });
      detailModalIdRef.current = id;
    },
    [openModal, closeModal, load, requirementMap, turMap],
  );

  const filters = useMemo<FilterField[]>(() => {
    const f: FilterField[] = [];
    if (role === 'uzman') {
      f.push({ key: 'owner', label: 'Sahiplik', type: 'select', options: OWNER_TYPE_OPTIONS });
    }
    f.push({ key: 'status', label: 'Durum', type: 'select', options: STATUS_OPTIONS });
    return f;
  }, [role]);

  // PERFORMANS: Kolonlar yalnızca harita verilerine (tür/yükümlülük/personel) ve
  // sağlık moduna bağlı; referansı sabitlenerek Table satır memoizasyonu aktive edilir.
  const columns = useMemo<TableColumn<EvrakData>[]>(() => [
    {
      key: 'evrak',
      header: 'Evrak',
      render: (row) => (
        <div className="flex items-center gap-2.5">
          <EvrakDosyaIkonu mime={row.mimeType} name={row.originalFileName} />
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground-800 truncate">{row.title}</p>
            <p className="text-xs text-foreground-500 truncate">{row.originalFileName ?? '—'}</p>
          </div>
        </div>
      ),
    },
    ...(healthOnly
      ? [
          {
            key: 'personel',
            header: 'Personel',
            render: (row: EvrakData) => (
              <span className="text-sm text-foreground-700">
                {row.personelId ? personelMap[row.personelId] ?? '—' : '—'}
              </span>
            ),
          } as TableColumn<EvrakData>,
        ]
      : []),
    {
      key: 'tur',
      header: 'Tür',
      render: (row) => (
        <span className="text-sm text-foreground-600">{row.documentTypeId ? turMap[row.documentTypeId] ?? '—' : '—'}</span>
      ),
    },
    ...(healthOnly
      ? []
      : [
          {
            key: 'gereksinim',
            header: 'İlgili Yükümlülük',
            render: (row: EvrakData) => (
              <span className="text-sm text-foreground-600">{row.requirementId ? requirementMap[row.requirementId] ?? '—' : '—'}</span>
            ),
          } as TableColumn<EvrakData>,
        ]),
    {
      key: 'tarih',
      header: 'Belge Tarihi',
      render: (row) => <span className="text-sm text-foreground-600">{formatEvrakDate(row.documentDate)}</span>,
    },
    {
      key: 'gecerlilik',
      header: 'Geçerlilik Bitişi',
      render: (row) => (
        <span className="text-sm text-foreground-600">{row.validUntil ? formatEvrakDate(row.validUntil) : 'Süresiz'}</span>
      ),
    },
    {
      key: 'durum',
      header: 'Durum',
      render: (row) => <Badge variant={evrakStatusBadgeVariant(row.status)}>{row.statusLabel}</Badge>,
    },
    ...(healthOnly
      ? []
      : [
          {
            key: 'sahip',
            header: 'Sahiplik',
            render: (row: EvrakData) => <Badge variant="secondary">{row.ownerTypeLabel}</Badge>,
          } as TableColumn<EvrakData>,
        ]),
  ], [healthOnly, turMap, requirementMap, personelMap]);

  // PERFORMANS: Satır aksiyonları referansı sabitlenir.
  const renderEvrakRowActions = useCallback(
    (row: EvrakData) => (
      <ContextMenu
        triggerIcon="ri-more-2-fill"
        items={[{ label: 'Detay', icon: 'ri-eye-line', onClick: () => handleOpenDetail(row) }]}
      />
    ),
    [handleOpenDetail],
  );

  const totalPages = Math.max(1, Math.ceil(count / pageSize));

  return (
    <div className="isg-page">
      <PageHeader
        title={title}
        subtitle={subtitle}
        className="flex-shrink-0"
        actions={
          <Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={handleOpenUpload}>
            {healthOnly ? 'Sağlık Kaydı Yükle' : 'Evrak Yükle'}
          </Button>
        }
      />

      <div className="isg-card flex flex-col p-3">
        <FilterBar
          filters={filters}
          values={filterValues}
          onChange={(key, value) => {
            setFilterValues((prev) => ({ ...prev, [key]: value }));
            setPage(1);
          }}
          onReset={() => {
            setFilterValues({});
            setSearchQuery('');
            setPage(1);
          }}
          onSearch={setSearchQuery}
          searchPlaceholder="Ara... evrak adı, dosya adı"
          searchDebounceMs={400}
        />

        <div className="mt-3 flex-1 min-h-0">
          {loading ? (
            <div className="flex justify-center py-16">
              <Loading size="lg" text="Evraklar yükleniyor..." />
            </div>
          ) : error ? (
            <ErrorState message={error} onRetry={load} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon={emptyIcon}
              title={emptyTitle}
              description={emptyDescription}
              action={{ label: healthOnly ? 'Sağlık Kaydı Yükle' : 'Evrak Yükle', onClick: handleOpenUpload, icon: 'ri-add-line' }}
            />
          ) : (
            <>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-foreground-500">
                  Toplam <span className="font-semibold text-foreground-800">{count}</span> evrak
                </p>
              </div>
              <div className="overflow-x-auto">
                <Table
                  data={rows}
                  columns={columns}
                  keyExtractor={(r) => r.id}
                  onRowClick={handleOpenDetail}
                  rowActions={renderEvrakRowActions}
                  mobileCardRenderer={(row) => (
                    <MobileEvrakCard
                      row={row}
                      turName={row.documentTypeId ? turMap[row.documentTypeId] : undefined}
                      reqTitle={row.requirementId ? requirementMap[row.requirementId] : undefined}
                      onDetail={handleOpenDetail}
                    />
                  )}
                />
              </div>
              <div className="mt-3 pt-3 border-t isg-divider">
                <Pagination
                  currentPage={page}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={count}
                  onPageChange={setPage}
                  onPageSizeChange={(size) => {
                    setPageSize(size);
                    setPage(1);
                  }}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}