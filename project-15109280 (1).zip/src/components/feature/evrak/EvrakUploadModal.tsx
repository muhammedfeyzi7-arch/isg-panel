import { useState, useEffect, useCallback, useMemo } from 'react';
import type { ChangeEvent } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import { useToastActions } from '@/hooks/useToast';
import {
  type EvrakOwnerType,
  type EvrakOption,
  type EvrakTuru,
  type EvrakData,
  fetchEvrakTurleri,
  fetchFirmaOptions,
  fetchPersonelOptions,
  fetchFirmaGereksinimleri,
  uploadEvrak,
  assignEvrakKlasor,
  friendlyEvrakError,
  scopeShownToGenericPersonel,
} from '@/lib/evrakService';
import { ACIL_DURUM_EKIPLERI_TUR_KODU } from '@/lib/acilDurumService';

interface EvrakUploadModalProps {
  role: 'firma' | 'uzman' | 'hekim';
  onClose: () => void;
  onUploaded?: (evrakId?: string) => void;
  /** Dönemsel yükümlülük akışı: firma önceden seçili, kullanıcı değiştiremez. */
  initialFirmaId?: string;
  /** Dönemsel yükümlülük akışı: evrak türü önceden sabit (örn. ISG_KURULU). */
  initialDocumentTypeId?: string;
  /** Yeni sürüm akışı: yükümlülük önceden sabit. */
  initialRequirementId?: string;
  /** Yeni sürüm akışı: yerine geçecek eski belge (revision zinciri). */
  previousEvrakId?: string;
  /** Yeni sürüm akışı: mevcut belge (seçimler gizlenir, bilgiler otomatik bağlanır). */
  previousEvrak?: EvrakData;
  /**
   * Bağlam filtresi: bulunduğum bölüm/kategoriye uygun evrak türleri gösterilir.
   * Örn. İSG Kurulu kaydında yalnızca İSG Kurulu türü; Risk bölümünde yalnızca
   * Risk Yönetimi kategorisi. Verilmezse tüm türler listelenir.
   */
  allowedCategory?: string;
  /** Yalnızca bu kod(lar)daki evrak türlerini göster. */
  allowedCodes?: string[];
  /**
   * Sahip türü kilidi. Verilirse Firma/Kişisel Evrak sekmeleri GİZLENİR ve
   * sahip türü sabitlenir (örn. İSG Kurulu kaydı = yalnızca firma evrakı).
   */
  lockOwnerType?: EvrakOwnerType;
  /** Yükleme sonrası evrakın atanacağı firma özel klasörü. */
  initialKlasorId?: string;
  /**
   * Yalnızca SAĞLIK nitelikli evrak türlerini (is_health) göster. Sağlık Evrakları
   * ekranından yüklerken kullanılır; firma seviyesi İSG dokümanları listelenmez.
   */
  healthOnly?: boolean;
}

const MAX_SIZE = 15 * 1024 * 1024;

export default function EvrakUploadModal({
  role,
  onClose,
  onUploaded,
  initialFirmaId,
  initialDocumentTypeId,
  initialRequirementId,
  previousEvrakId,
  previousEvrak,
  allowedCategory,
  allowedCodes,
  lockOwnerType,
  initialKlasorId,
  healthOnly,
}: EvrakUploadModalProps) {
  const { addToast } = useToastActions();

  const isNewVersion = !!previousEvrak;

  const [ownerType, setOwnerType] = useState<EvrakOwnerType>(
    previousEvrak ? previousEvrak.ownerType : lockOwnerType ?? (role === 'hekim' ? 'personel' : 'firma'),
  );
  const [firmaId, setFirmaId] = useState(previousEvrak?.firmaId ?? initialFirmaId ?? '');
  const [personelId, setPersonelId] = useState(previousEvrak?.personelId ?? '');
  const [requirementId, setRequirementId] = useState(previousEvrak?.requirementId ?? initialRequirementId ?? '');
  const [documentTypeId, setDocumentTypeId] = useState(previousEvrak?.documentTypeId ?? initialDocumentTypeId ?? '');
  const [title, setTitle] = useState(previousEvrak?.title ?? '');
  const [description, setDescription] = useState(previousEvrak?.description ?? '');
  const [documentDate, setDocumentDate] = useState(previousEvrak?.documentDate ?? '');
  const [file, setFile] = useState<File | null>(null);

  const [firmaOptions, setFirmaOptions] = useState<EvrakOption[]>([]);
  const [personelOptions, setPersonelOptions] = useState<EvrakOption[]>([]);
  const [turlar, setTurlar] = useState<EvrakTuru[]>([]);
  const [requirementOptions, setRequirementOptions] = useState<{ value: string; label: string; code: string }[]>([]);

  // Evrak türleri merkezi katalogdan gelir; yalnızca seçili owner_type'ın türleri
  // gösterilir (firma evrakı → firma türleri, kişisel evrak → personel türleri).
  // Frontend'de belge türü listesi hardcode EDİLMEZ.
  const turOptions = useMemo(
    () =>
      turlar
        .filter((t) => t.ownerType === ownerType)
        .filter((t) => scopeShownToGenericPersonel(t.personelRoleScope))
        .filter((t) => (healthOnly ? t.isHealth : role === 'hekim' || !t.isHealth))
        .filter((t) => t.code !== ACIL_DURUM_EKIPLERI_TUR_KODU || (allowedCodes?.includes(ACIL_DURUM_EKIPLERI_TUR_KODU) ?? false))
        .filter((t) => !allowedCategory || t.kategori === allowedCategory)
        .filter((t) => !allowedCodes || allowedCodes.includes(t.code))
        .map((t) => ({ value: t.id, label: t.name })),
    [turlar, ownerType, role, allowedCategory, allowedCodes, healthOnly],
  );

  const [loadingOptions, setLoadingOptions] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Başlangıç seçenekleri (tür + role göre firma/personel/gereksinim).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoadingOptions(true);
      try {
        const turlarListesi = await fetchEvrakTurleri();
        if (cancelled) return;
        setTurlar(turlarListesi);
        // Tek bir tür koda kilitliyse (ekip / tatbikat / tahliye) otomatik seç -
        // yüklenen belge türsüz kalıp ilgili modül listesinden düşmesin.
        if (!initialDocumentTypeId && !previousEvrak && allowedCodes?.length === 1) {
          const es = turlarListesi.find((t) => t.code === allowedCodes[0]);
          if (es) setDocumentTypeId(es.id);
        }

        if (role === 'uzman') {
          const [firmalar, personeller] = await Promise.all([fetchFirmaOptions(), fetchPersonelOptions()]);
          if (cancelled) return;
          setFirmaOptions(firmalar);
          setPersonelOptions(personeller);
        } else if (role === 'hekim') {
          const personeller = await fetchPersonelOptions();
          if (cancelled) return;
          setPersonelOptions(personeller);
        } else {
          const gereksinimler = await fetchFirmaGereksinimleri();
          if (cancelled) return;
          setRequirementOptions(gereksinimler.map((g) => ({ value: g.id, label: g.title ?? g.requirementCode, code: g.requirementCode })));
        }
      } catch {
        // Seçenekler yüklenemezse form yine açılır; boş picker güvenli boş sonuçtur.
      } finally {
        if (!cancelled) setLoadingOptions(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [role]);

  // Uzman: firma seçilince o firmanın gereksinimlerini yükle.
  const loadRequirementsForFirma = useCallback(async (fid: string) => {
    if (!fid) {
      setRequirementOptions([]);
      return;
    }
    try {
      const gereksinimler = await fetchFirmaGereksinimleri(fid);
      setRequirementOptions(gereksinimler.map((g) => ({ value: g.id, label: g.title ?? g.requirementCode, code: g.requirementCode })));
    } catch {
      setRequirementOptions([]);
    }
  }, []);

  useEffect(() => {
    // Yeni sürüm akışında (previousEvrak) ve önceden kilitli (initialRequirementId)
    // yükümlülük SIFIRLANMAZ — mevcut belgenin değeri korunur.
    if (isNewVersion) return;
    if (initialRequirementId) return;
    if (role === 'uzman' && ownerType === 'firma' && firmaId) {
      setRequirementId('');
      loadRequirementsForFirma(firmaId);
    } else if (role === 'uzman' && ownerType !== 'firma') {
      setRequirementId('');
      setRequirementOptions([]);
    }
  }, [role, ownerType, firmaId, loadRequirementsForFirma, initialRequirementId, isNewVersion]);

  // Sahip türü değişince önceki belge türü seçimi geçersiz olur; sıfırla.
  // Dönemsel yükümlülük akışında tür önceden sabit (initialDocumentTypeId) — sıfırlanmaz.
  // Yeni sürüm akışında (previousEvrak) da sıfırlanmaz.
  useEffect(() => {
    if (!initialDocumentTypeId && !isNewVersion) setDocumentTypeId('');
  }, [ownerType, initialDocumentTypeId, isNewVersion]);

  // Evrak türü seçilince, firmanın o türle eşleşen İSG yükümlülüğüne OTOMATİK bağlanır
  // (belge türü kodu ↔ gereksinim kodu). Eşleşme yoksa bağ boş kalır; kullanıcı elle seçebilir.
  useEffect(() => {
    if (ownerType !== 'firma' || isNewVersion) return;
    if (!documentTypeId) return;
    const tur = turlar.find((t) => t.id === documentTypeId);
    if (!tur) return;
    const match = requirementOptions.find((o) => o.code === tur.code);
    setRequirementId(match ? match.value : '');
  }, [documentTypeId, ownerType, isNewVersion, turlar, requirementOptions]);

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    setFile(e.target.files?.[0] ?? null);
    setError(null);
  };

  const handleSubmit = async () => {
    setError(null);
    if (!title.trim()) {
      setError('Evrak başlığı zorunludur.');
      return;
    }
    if (!file) {
      setError('Bir dosya seçmelisiniz.');
      return;
    }
    if (file.size > MAX_SIZE) {
      setError('Dosya boyutu 15 MB sınırını aşıyor.');
      return;
    }
    if (ownerType === 'firma' && role !== 'firma' && !firmaId) {
      setError('Firma seçimi zorunludur.');
      return;
    }
    if (ownerType === 'personel' && !personelId) {
      setError('Personel seçimi zorunludur.');
      return;
    }
    if (ownerType === 'personel' && !documentTypeId) {
      setError('Belge türü seçmelisiniz.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await uploadEvrak({
        ownerType,
        firmaId: ownerType === 'firma' && role !== 'firma' ? firmaId : null,
        personelId: ownerType === 'personel' ? personelId : null,
        requirementId: ownerType === 'firma' && requirementId ? requirementId : null,
        documentTypeId: documentTypeId || null,
        title: title.trim(),
        description: description.trim() || null,
        documentDate: documentDate || null,
        previousEvrakId: previousEvrakId ?? null,
        file,
      });
      addToast({ title: 'Evrak yüklendi', message: 'Evrak başarıyla yüklendi.', type: 'success' });
      if (initialKlasorId) {
        try {
          await assignEvrakKlasor(res.evrakId, initialKlasorId);
        } catch {
          // klasöre atanamazsa evrak yine yüklenmiş olarak kalır
        }
      }
      onUploaded?.(res.evrakId);
      onClose();
    } catch (e) {
      setError(friendlyEvrakError(e));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      {role === 'uzman' && !isNewVersion && !lockOwnerType && (
        <div className="flex items-center gap-1 bg-background-100 dark:bg-background-200/60 rounded-full p-1 w-fit">
          <button
            type="button"
            onClick={() => setOwnerType('firma')}
            className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              ownerType === 'firma' ? 'bg-primary-500 text-inverse' : 'text-foreground-600 hover:text-foreground-800'
            }`}
          >
            Firma Evrakı
          </button>
          <button
            type="button"
            onClick={() => setOwnerType('personel')}
            className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
              ownerType === 'personel' ? 'bg-primary-500 text-inverse' : 'text-foreground-600 hover:text-foreground-800'
            }`}
          >
            Kişisel Evrak
          </button>
        </div>
      )}

      {ownerType === 'firma' && role !== 'firma' && !initialFirmaId && !isNewVersion && (
        <Select
          label="Firma"
          required
          options={firmaOptions}
          value={firmaId}
          onChange={(e) => setFirmaId(e.target.value)}
          placeholder="Firma seçin"
          loading={loadingOptions}
          searchable
        />
      )}

      {ownerType === 'personel' && !isNewVersion && (
        <Select
          label="Personel"
          required
          options={personelOptions}
          value={personelId}
          onChange={(e) => setPersonelId(e.target.value)}
          placeholder="Personel seçin"
          loading={loadingOptions}
          searchable
        />
      )}

      {isNewVersion ? (
        <div className="flex items-start justify-between gap-4 py-2 border-b border-background-200/70 dark:border-background-400/20">
          <span className="text-xs text-foreground-500 flex-shrink-0">Belge</span>
          <span className="text-sm text-foreground-800 text-right">{title}</span>
        </div>
      ) : (
        <Input
          label="Evrak Başlığı"
          required
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Örn: Risk Değerlendirmesi 2026"
        />
      )}

      {!initialDocumentTypeId && !isNewVersion && (
        <Select
          label="Evrak Türü"
          required={ownerType === 'personel'}
          options={turOptions}
          value={documentTypeId}
          onChange={(e) => setDocumentTypeId(e.target.value)}
          placeholder="Evrak türü seçin"
          loading={loadingOptions}
          searchable
        />
      )}

      {ownerType === 'firma' && requirementOptions.length > 0 && !initialFirmaId && !isNewVersion && (
        <Select
          label="İlgili Yükümlülük"
          options={requirementOptions}
          value={requirementId}
          onChange={(e) => setRequirementId(e.target.value)}
          placeholder="Bağlanacak yükümlülüğü seçin"
          searchable
        />
      )}

      <div className="grid grid-cols-1 gap-3">
        <DatePicker label="Belge Tarihi" value={documentDate} onChange={(e) => setDocumentDate(e.target.value)} />
      </div>
      <p className="text-xs text-foreground-500 flex items-start gap-1.5 -mt-1">
        <i className="ri-information-line mt-0.5 flex-shrink-0" />
        Geçerlilik başlangıcı ve bitişi, belge türü ile firma tehlike sınıfına göre merkezi mevzuat motoru tarafından otomatik hesaplanır.
      </p>

      <Textarea
        label="Açıklama"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        maxLength={500}
        placeholder="Evrak hakkında kısa açıklama (isteğe bağlı)"
      />

      <div>
        <label className="isg-form-label">
          Dosya
          <span className="text-danger-600 ml-0.5">*</span>
        </label>
        <input
          type="file"
          accept=".pdf,.doc,.docx,.xls,.xlsx,.odt,.ods,.txt,image/jpeg,image/png,image/webp"
          onChange={handleFileChange}
          className="isg-input w-full text-sm py-2"
        />
        {file && (
          <p className="mt-1 text-xs text-foreground-500 flex items-center gap-1">
            <i className="ri-file-line" /> {file.name} ({Math.round(file.size / 1024)} KB)
          </p>
        )}
      </div>

      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={submitting}>
          Vazgeç
        </Button>
        <Button variant="primary" size="sm" leftIcon={<i className="ri-upload-2-line" />} onClick={handleSubmit} isLoading={submitting}>
          Yükle
        </Button>
      </div>
    </div>
  );
}