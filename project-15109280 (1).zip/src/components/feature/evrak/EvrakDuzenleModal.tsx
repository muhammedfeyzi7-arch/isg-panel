import { useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import DatePicker from '@/components/ui/DatePicker';
import { updateEvrak } from '@/lib/evrakService';
import { toast } from '@/hooks/useToast';

interface Props {
  evrakId: string;
  initialTitle: string;
  initialDocumentDate?: string | null;
  initialValidUntil?: string | null;
  initialDescription?: string | null;
  onSaved: () => void;
  onClose: () => void;
}

/**
 * Personel / firma belgesi DÜZENLEME modalı (ortak).
 * Yalnızca meta bilgiler (belge adı, belge tarihi, geçerlilik tarihi, açıklama) güncellenir;
 * dosyanın kendisi değiştirilmez. Merkezi `updateEvrak` (evrak Edge Function) kullanılır,
 * yetki/kapsam kontrolleri sunucuda yapılır.
 */
export default function EvrakDuzenleModal({
  evrakId,
  initialTitle,
  initialDocumentDate,
  initialValidUntil,
  initialDescription,
  onSaved,
  onClose,
}: Props) {
  const [title, setTitle] = useState(initialTitle ?? '');
  const [documentDate, setDocumentDate] = useState(initialDocumentDate ?? '');
  const [validUntil, setValidUntil] = useState(initialValidUntil ?? '');
  const [description, setDescription] = useState(initialDescription ?? '');
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (saving) return;
    if (!title.trim()) {
      toast.warning('Belge adı zorunludur');
      return;
    }
    setSaving(true);
    try {
      await updateEvrak(evrakId, {
        title: title.trim(),
        documentDate: documentDate || null,
        validUntil: validUntil || null,
        description: description.trim() || null,
      });
      toast.success('Belge güncellendi');
      onSaved();
      onClose();
    } catch (e) {
      toast.error('Belge güncellenemedi', e instanceof Error ? e.message : undefined);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <Input
        label="Belge Adı"
        required
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Örn. İSG Uzmanlık Belgesi"
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <DatePicker
          label="Belge Tarihi"
          value={documentDate}
          onChange={(e) => setDocumentDate(e.target.value)}
        />
        <DatePicker
          label="Geçerlilik Tarihi"
          value={validUntil}
          onChange={(e) => setValidUntil(e.target.value)}
          helpText="Boş bırakılırsa geçerlilik hesaplanmaz."
        />
      </div>
      <Textarea
        label="Açıklama"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        maxLength={500}
        placeholder="Belgeye dair kısa not (opsiyonel)"
      />
      <div className="flex items-center justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={saving}>Vazgeç</Button>
        <Button
          variant="primary"
          size="sm"
          leftIcon={<i className="ri-save-line" />}
          onClick={handleSave}
          isLoading={saving}
        >
          Kaydet
        </Button>
      </div>
    </div>
  );
}