export interface KategoriGorunum {
  /** Remix ikon sınıfı. */
  icon: string;
  /** İkon kutusunun renk sınıfları (yumuşak zemin + doygun ikon). */
  tile: string;
}

export interface FirmaSistemKlasoru {
  /** Ekranda GÖSTERİLEN sabit klasör adı (referans birebir). */
  ad: string;
  /** Bu klasöre karşılık gelen VERİTABANI kategori adları (filtre + adet eşlemesi). */
  dbKategoriler: string[];
}

/**
 * Firma Dosyaları sol panelindeki SABİT sistem klasörleri.
 *
 * Sıralama referanstaki gibidir. Bu liste yalnızca GÖRÜNTÜLEME iskeletidir; klasör
 * adetleri veritabanından (`firma_evrak_sayilari`) gelir. Klasör adı ile veritabanı
 * kategori adı farklı olabilir (ör. veritabanındaki "Risk Yönetimi" ekranda "Risk
 * Değerlendirme"; "Planlama" ekranda "Çalışma Planları").
 *
 * KURAL: Yalnızca VERİTABANINDA GERÇEKTEN VAR OLAN kategoriler burada tanımlanır.
 * Personel kategorileri ve Tutanaklar bu modülde GÖSTERİLMEZ (kendi modüllerinde yönetilir).
 */
export const FIRMA_SISTEM_KLASORLERI: FirmaSistemKlasoru[] = [
  { ad: 'Risk Değerlendirme', dbKategoriler: ['Risk Yönetimi', 'Risk Değerlendirme'] },
  { ad: 'Acil Durum', dbKategoriler: ['Acil Durum'] },
  { ad: 'Eğitim', dbKategoriler: ['Eğitim'] },
  { ad: 'Çalışma Planları', dbKategoriler: ['Planlama', 'Yıllık Çalışma Planı'] },
  { ad: 'İSG Kurulu', dbKategoriler: ['İSG Kurulu'] },
  { ad: 'İSG Organizasyonu', dbKategoriler: ['İSG Organizasyonu'] },
  { ad: 'Noter Defteri', dbKategoriler: ['Noter Defteri'] },
];

const VARSAYILAN: KategoriGorunum = {
  icon: 'ri-folder-3-line',
  tile: 'bg-background-200 text-foreground-500 dark:bg-background-300/40 dark:text-foreground-400',
};

/**
 * Kategori / klasör adı → premium ikon + soft accent eşlemesi.
 *
 * İkonlar AYNI aileye ait refined outline karakterlidir (Remix "-line"); her kategori
 * görsel olarak ayrışır ama aynı tasarım sistemine bağlı kalır. Ad normalize edilerek
 * (harf/boşluk/ayraç/Türkçe karakter farkından bağımsız) eşleştirilir.
 */
const TANIMLI: Record<string, KategoriGorunum> = {
  // ---- Firma sistem klasörleri ----
  riskdegerlendirme: {
    icon: 'ri-fire-line',
    tile: 'bg-orange-100 text-orange-600 dark:bg-orange-500/15 dark:text-orange-400',
  },
  riskyonetimi: {
    icon: 'ri-fire-line',
    tile: 'bg-orange-100 text-orange-600 dark:bg-orange-500/15 dark:text-orange-400',
  },
  acildurum: {
    icon: 'ri-alarm-warning-line',
    tile: 'bg-rose-100 text-rose-600 dark:bg-rose-500/15 dark:text-rose-400',
  },
  egitim: {
    icon: 'ri-graduation-cap-line',
    tile: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400',
  },
  yillikegitimplani: {
    icon: 'ri-graduation-cap-line',
    tile: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400',
  },
  calismaplanlari: {
    icon: 'ri-calendar-schedule-line',
    tile: 'bg-teal-100 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400',
  },
  yillikcalismaplani: {
    icon: 'ri-calendar-schedule-line',
    tile: 'bg-teal-100 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400',
  },
  planlama: {
    icon: 'ri-calendar-schedule-line',
    tile: 'bg-teal-100 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400',
  },
  isgkurulu: {
    icon: 'ri-team-line',
    tile: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400',
  },
  isgorganizasyonu: {
    icon: 'ri-organization-chart',
    tile: 'bg-lime-100 text-lime-700 dark:bg-lime-500/15 dark:text-lime-400',
  },
  noterdefteri: {
    icon: 'ri-book-2-line',
    tile: 'bg-slate-200 text-slate-700 dark:bg-slate-500/20 dark:text-slate-300',
  },

  // ---- Personel kategori kartları (Personel modülünde kullanılır) ----
  saglik: {
    icon: 'ri-heart-pulse-line',
    tile: 'bg-rose-100 text-rose-600 dark:bg-rose-500/15 dark:text-rose-400',
  },
  kimlikozluk: {
    icon: 'ri-id-card-line',
    tile: 'bg-teal-100 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400',
  },
  sozlesme: {
    icon: 'ri-file-paper-2-line',
    tile: 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400',
  },
  isgecmisi: {
    icon: 'ri-briefcase-line',
    tile: 'bg-orange-100 text-orange-600 dark:bg-orange-500/15 dark:text-orange-400',
  },
  meslekibelgeler: {
    icon: 'ri-award-line',
    tile: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400',
  },
  meslekiyetkinlik: {
    icon: 'ri-verified-badge-line',
    tile: 'bg-lime-100 text-lime-700 dark:bg-lime-500/15 dark:text-lime-400',
  },
  operasyonelbelgeler: {
    icon: 'ri-settings-3-line',
    tile: 'bg-slate-100 text-slate-600 dark:bg-slate-500/20 dark:text-slate-300',
  },
  osgbcalismabelgeleri: {
    icon: 'ri-briefcase-4-line',
    tile: 'bg-stone-100 text-stone-700 dark:bg-stone-500/20 dark:text-stone-300',
  },
  personel: {
    icon: 'ri-user-3-line',
    tile: 'bg-teal-100 text-teal-600 dark:bg-teal-500/15 dark:text-teal-400',
  },
  sgk: {
    icon: 'ri-shield-user-line',
    tile: 'bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400',
  },
  diger: {
    icon: 'ri-folder-line',
    tile: 'bg-background-200 text-foreground-500 dark:bg-background-300/40 dark:text-foreground-400',
  },
};

/** Türkçe + ayraç farklarını normalize eder (ör. "Kimlik & Özlük" ≈ "kimlikozluk"). */
function normalize(s: string): string {
  return s
    .toLocaleLowerCase('tr')
    .replace(/ı/g, 'i')
    .replace(/ş/g, 's')
    .replace(/ğ/g, 'g')
    .replace(/ü/g, 'u')
    .replace(/ö/g, 'o')
    .replace(/ç/g, 'c')
    .replace(/[^a-z0-9]/g, '');
}

/**
 * Klasör panelinde GÖSTERİLMEYEN evrak kategorileri.
 * İsim normalize edilerek (harf/boşluk/ayraç farkından bağımsız) eşleştirilir.
 */
const GIZLI_KATEGORILER: string[] = ['Faaliyet Koşulu'];

/** Kategori, gizli listede mi? (görüntüleme filtresi — iş mantığı değil). */
export function kategoriGizliMi(kategori: string): boolean {
  return GIZLI_KATEGORILER.some((g) => normalize(g) === normalize(kategori));
}

export function kategoriGorunum(kategori: string): KategoriGorunum {
  return TANIMLI[normalize(kategori)] ?? VARSAYILAN;
}

/**
 * Veritabanı kategori adını ekranda gösterilecek SABİT firma klasör adına çevirir
 * (ör. "Risk Yönetimi" → "Risk Değerlendirme", "Planlama" → "Çalışma Planları").
 * Eşleşme yoksa ad aynen döner. Yalnızca GÖRÜNTÜLEME içindir; veritabanı değişmez.
 */
export function firmaKategoriEtiket(dbKategori: string): string {
  const n = normalize(dbKategori);
  const found = FIRMA_SISTEM_KLASORLERI.find((d) => d.dbKategoriler.some((k) => normalize(k) === n));
  return found ? found.ad : dbKategori;
}