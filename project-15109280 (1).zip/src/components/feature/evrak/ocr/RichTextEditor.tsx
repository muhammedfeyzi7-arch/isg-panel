import { useEffect, useRef, useState } from 'react';
import type { MutableRefObject } from 'react';
import { LexicalComposer } from '@lexical/react/LexicalComposer';
import { RichTextPlugin } from '@lexical/react/LexicalRichTextPlugin';
import { ContentEditable } from '@lexical/react/LexicalContentEditable';
import { HistoryPlugin } from '@lexical/react/LexicalHistoryPlugin';
import { ListPlugin } from '@lexical/react/LexicalListPlugin';
import { TablePlugin } from '@lexical/react/LexicalTablePlugin';
import { useLexicalComposerContext } from '@lexical/react/LexicalComposerContext';
import { HeadingNode, QuoteNode, $createHeadingNode, $createQuoteNode } from '@lexical/rich-text';
import {
  ListNode,
  ListItemNode,
  $createListNode,
  $createListItemNode,
} from '@lexical/list';
import {
  TableNode,
  TableRowNode,
  TableCellNode,
  TableCellHeaderStates,
  $createTableNodeWithDimensions,
  $createTableRowNode,
  $createTableCellNode,
  $isTableNode,
  $isTableRowNode,
  $isTableCellNode,
  INSERT_TABLE_COMMAND,
} from '@lexical/table';
import { $patchStyleText, $getSelectionStyleValueForProperty, $setBlocksType } from '@lexical/selection';
import {
  $getRoot,
  $getSelection,
  $isRangeSelection,
  $createParagraphNode,
  $createTextNode,
  $createLineBreakNode,
  $isTextNode,
  $isLineBreakNode,
  IS_BOLD,
  IS_ITALIC,
  IS_UNDERLINE,
  type LexicalEditor,
  type LexicalNode,
} from 'lexical';

// Word benzeri belge teması — başlık/paragraf/liste/tablo aralıkları okunabilir düzende.
const theme = {
  heading: {
    h1: 'text-2xl font-bold mb-3 mt-5',
    h2: 'text-xl font-semibold mb-2 mt-4',
    h3: 'text-lg font-medium mb-2 mt-3',
  },
  paragraph: 'text-[15px] leading-7 mb-3',
  list: {
    ul: 'list-disc pl-7 mb-3',
    ol: 'list-decimal pl-7 mb-3',
    listitem: 'mb-1',
  },
  table: 'border-collapse w-full mb-4',
  tableRow: '',
  tableCell: 'border px-2 py-1.5 align-top text-sm border-[#cbd5e1]',
  tableCellHeader: 'bg-[#f1f5f9] font-semibold',
  text: {
    bold: 'font-bold',
    italic: 'italic',
    underline: 'underline',
    strikethrough: 'line-through',
  },
};

interface InlineFormat {
  bold: boolean;
  italic: boolean;
  underline: boolean;
  style: string;
}

function textFormat(state: InlineFormat): number {
  let f = 0;
  if (state.bold) f |= IS_BOLD;
  if (state.italic) f |= IS_ITALIC;
  if (state.underline) f |= IS_UNDERLINE;
  return f;
}

/** Element'in inline stilinden font-size / font-family çıkarır (metin düğümü stiline yazılır). */
function extractTextStyle(el: HTMLElement, base: string): string {
  const size = el.style.fontSize;
  const family = el.style.fontFamily;
  const parts: string[] = [];
  if (size) parts.push(`font-size: ${size}`);
  if (family) parts.push(`font-family: ${family}`);
  if (parts.length === 0) return base;
  const prefix = base ? (base.endsWith(';') ? `${base} ` : `${base}; `) : '';
  return `${prefix}${parts.join('; ')}`;
}

/** Satır içi düğümleri paragrafa sarar; blok düğümleri (paragraf/liste) olduğu gibi bırakır. */
function wrapInlineInParagraph(nodes: LexicalNode[]): LexicalNode[] {
  const result: LexicalNode[] = [];
  let inline: LexicalNode[] = [];
  const flush = () => {
    if (inline.length > 0) {
      const p = $createParagraphNode();
      p.append(...inline);
      result.push(p);
      inline = [];
    }
  };
  for (const n of nodes) {
    if ($isTextNode(n) || $isLineBreakNode(n)) inline.push(n);
    else {
      flush();
      result.push(n);
    }
  }
  flush();
  if (result.length === 0) result.push($createParagraphNode());
  return result;
}

/** HTML tablo elementini Lexical TableNode'a dönüştürür (hücre içeriği korunur, karışmaz). */
function buildTable(tableEl: HTMLElement, editor: LexicalEditor, fmt: InlineFormat): TableNode {
  const rows = Array.from(tableEl.querySelectorAll('tr'));
  const colCount = rows.reduce((m, r) => Math.max(m, r.querySelectorAll('th, td').length), 1);
  const rowCount = Math.max(1, rows.length);
  const table = $createTableNodeWithDimensions(rowCount, colCount, false);
  const tableRows = table.getChildren();

  rows.forEach((tr, ri) => {
    const row = tableRows[ri];
    if (!row) return;
    const cells = Array.from(tr.querySelectorAll('th, td'));
    const rowCells = row.getChildren();
    cells.forEach((cell, ci) => {
      const cellNode = rowCells[ci];
      if (!cellNode) return;
      const isHeader = cell.tagName.toLowerCase() === 'th';
      const cellFmt: InlineFormat = isHeader
        ? { ...fmt, bold: true, style: extractTextStyle(cell as HTMLElement, fmt.style) }
        : { ...fmt, style: extractTextStyle(cell as HTMLElement, fmt.style) };
      const cellNodes: LexicalNode[] = [];
      for (const c of Array.from(cell.childNodes)) cellNodes.push(...$domToNodes(editor, c, cellFmt));
      cellNode.clear();
      cellNode.append(...wrapInlineInParagraph(cellNodes));
    });
  });

  return table;
}

/** DOM alt ağacını Lexical düğümlerine çevirir (paragraf/başlık/liste/tablo/bold/italic/stil). */
function $domToNodes(editor: LexicalEditor, node: Node, fmt: InlineFormat): LexicalNode[] {
  if (node.nodeType === Node.TEXT_NODE) {
    const text = node.textContent ?? '';
    if (text === '') return [];
    const tn = $createTextNode(text);
    const f = textFormat(fmt);
    if (f) tn.setFormat(f);
    if (fmt.style) tn.setStyle(fmt.style);
    return [tn];
  }
  if (node.nodeType !== Node.ELEMENT_NODE) return [];

  const el = node as HTMLElement;
  const tag = el.tagName.toLowerCase();

  if (tag === 'br') return [$createLineBreakNode()];

  let nextFmt: InlineFormat = { ...fmt, style: extractTextStyle(el, fmt.style) };
  if (tag === 'strong' || tag === 'b') nextFmt = { ...nextFmt, bold: true };
  else if (tag === 'em' || tag === 'i') nextFmt = { ...nextFmt, italic: true };
  else if (tag === 'u') nextFmt = { ...nextFmt, underline: true };

  if (tag === 'table') return [buildTable(el, editor, nextFmt)];

  const children: LexicalNode[] = [];
  for (const child of Array.from(el.childNodes)) children.push(...$domToNodes(editor, child, nextFmt));

  if (tag === 'p') {
    const p = $createParagraphNode();
    p.append(...children);
    return [p];
  }
  if (['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].includes(tag)) {
    const h = $createHeadingNode(tag as 'h1');
    h.append(...children);
    return [h];
  }
  if (tag === 'ul' || tag === 'ol') {
    const list = $createListNode(tag === 'ol' ? 'number' : 'bullet');
    for (const li of Array.from(el.children)) {
      if (li.tagName.toLowerCase() !== 'li') continue;
      const liNodes: LexicalNode[] = [];
      for (const c of Array.from(li.childNodes)) liNodes.push(...$domToNodes(editor, c, nextFmt));
      const item = $createListItemNode();
      item.append(...wrapInlineInParagraph(liNodes));
      list.append(item);
    }
    return [list];
  }
  if (tag === 'blockquote') {
    const q = $createQuoteNode();
    q.append(...children);
    return [q];
  }

  // Bilinmeyen satır içi/sarmalayıcı elementler (a, span, section, body, …) → çocukları döndür.
  return children;
}

/** İlk HTML içeriğini editöre yükler (başlık/paragraf/liste/tablo yapısı + inline stil korunur). */
function LoadContentPlugin({ html }: { html: string }) {
  const [editor] = useLexicalComposerContext();
  const loadedRef = useRef(false);
  useEffect(() => {
    if (loadedRef.current) return;
    loadedRef.current = true;
    editor.update(() => {
      const dom = new DOMParser().parseFromString(html || '<p></p>', 'text/html');
      const root = $getRoot();
      root.clear();
      const nodes: LexicalNode[] = [];
      for (const child of Array.from(dom.body.childNodes)) {
        nodes.push(...$domToNodes(editor, child, { bold: false, italic: false, underline: false, style: '' }));
      }
      if (nodes.length > 0) root.append(...nodes);
      else root.append($createParagraphNode());
    });
  }, [editor, html]);
  return null;
}

/** Editör örneğini dışarıya taşır (kaydetme + ribbon komutları için). */
function EditorRefCapture({
  editorRef,
  onReady,
}: {
  editorRef?: MutableRefObject<LexicalEditor | null>;
  onReady?: (editor: LexicalEditor) => void;
}) {
  const [editor] = useLexicalComposerContext();
  useEffect(() => {
    if (editorRef) editorRef.current = editor;
    onReady?.(editor);
  }, [editor, editorRef, onReady]);
  return null;
}

// ══════════════════════════════════════════════════════════════════
// RIBBON KOMUTLARI — shell (tab/ribbon) tarafından çağrılan GERÇEK işlemler.
// ══════════════════════════════════════════════════════════════════

export type EditorAlign = 'left' | 'center' | 'right' | 'justify';

export interface EditorFormatState {
  bold: boolean;
  italic: boolean;
  underline: boolean;
  strikethrough: boolean;
  align: EditorAlign;
  fontSize: string;
  fontFamily: string;
  inTable: boolean;
}

const EMPTY_FORMAT: EditorFormatState = {
  bold: false,
  italic: false,
  underline: false,
  strikethrough: false,
  align: 'left',
  fontSize: '',
  fontFamily: '',
  inTable: false,
};

/** Seçimdeki aktif biçim/hizalama/font durumunu canlı okur (ribbon aktif state için). */
export function useEditorFormatState(editor: LexicalEditor | null): EditorFormatState {
  const [state, setState] = useState<EditorFormatState>(EMPTY_FORMAT);

  useEffect(() => {
    if (!editor) {
      setState(EMPTY_FORMAT);
      return;
    }
    const read = () => {
      editor.getEditorState().read(() => {
        const sel = $getSelection();
        if (!$isRangeSelection(sel)) {
          setState(EMPTY_FORMAT);
          return;
        }
        const alignRaw = $getSelectionStyleValueForProperty(sel, 'text-align', 'left');
        const fontSize = $getSelectionStyleValueForProperty(sel, 'font-size', '');
        const fontFamily = $getSelectionStyleValueForProperty(sel, 'font-family', '');
        let inTable = false;
        let n: LexicalNode | null = sel.anchor.getNode();
        while (n) {
          if ($isTableNode(n)) {
            inTable = true;
            break;
          }
          n = n.getParent();
        }
        setState({
          bold: sel.hasFormat('bold'),
          italic: sel.hasFormat('italic'),
          underline: sel.hasFormat('underline'),
          strikethrough: sel.hasFormat('strikethrough'),
          align: (['left', 'center', 'right', 'justify'].includes(alignRaw) ? alignRaw : 'left') as EditorAlign,
          fontSize,
          fontFamily,
          inTable,
        });
      });
    };
    read();
    return editor.registerUpdateListener(() => read());
  }, [editor]);

  return state;
}

export function applyFontSize(editor: LexicalEditor, size: string): void {
  editor.update(() => {
    const sel = $getSelection();
    if ($isRangeSelection(sel)) $patchStyleText(sel, { 'font-size': size });
  });
}

export function applyFontFamily(editor: LexicalEditor, family: string): void {
  editor.update(() => {
    const sel = $getSelection();
    if ($isRangeSelection(sel)) $patchStyleText(sel, { 'font-family': family });
  });
}

export type BlockType = 'paragraph' | 'h1' | 'h2' | 'h3';

/** Seçili bloğu paragraf / başlık seviyesine dönüştürür (gerçek blok tipi değişimi). */
export function setBlockType(editor: LexicalEditor, type: BlockType): void {
  editor.update(() => {
    const sel = $getSelection();
    if (!$isRangeSelection(sel)) return;
    if (type === 'paragraph') $setBlocksType(sel, () => $createParagraphNode());
    else $setBlocksType(sel, () => $createHeadingNode(type));
  });
}

function nearestTable(): TableNode | null {
  const sel = $getSelection();
  if (!sel) return null;
  const start = sel.getNodes()[0] ?? null;
  let n: LexicalNode | null = start;
  while (n) {
    if ($isTableNode(n)) return n as TableNode;
    n = n.getParent();
  }
  return null;
}

export function insertTable(editor: LexicalEditor, rows = 3, columns = 3): void {
  editor.dispatchCommand(INSERT_TABLE_COMMAND, { rows: String(rows), columns: String(columns), includeHeaders: true });
}

export function tableAddRow(editor: LexicalEditor): void {
  editor.update(() => {
    const table = nearestTable();
    if (!table) return;
    const firstRow = table.getFirstChild<TableRowNode>();
    const cols = firstRow ? firstRow.getChildrenSize() : 1;
    const row = $createTableRowNode();
    for (let i = 0; i < cols; i++) {
      const cell = $createTableCellNode(TableCellHeaderStates.NO_STATUS);
      cell.append($createParagraphNode());
      row.append(cell);
    }
    table.append(row);
  });
}

export function tableAddColumn(editor: LexicalEditor): void {
  editor.update(() => {
    const table = nearestTable();
    if (!table) return;
    table.getChildren<TableRowNode>().forEach((row) => {
      const cell = $createTableCellNode(TableCellHeaderStates.NO_STATUS);
      cell.append($createParagraphNode());
      row.append(cell);
    });
  });
}

export function tableDeleteRow(editor: LexicalEditor): void {
  editor.update(() => {
    const sel = $getSelection();
    if (!sel) return;
    let n: LexicalNode | null = sel.getNodes()[0] ?? null;
    let row: TableRowNode | null = null;
    while (n) {
      if ($isTableRowNode(n)) {
        row = n as TableRowNode;
        break;
      }
      n = n.getParent();
    }
    if (!row) return;
    const table = row.getParent();
    row.remove();
    if (table && $isTableNode(table) && table.getChildrenSize() === 0) table.remove();
  });
}

export function tableDeleteColumn(editor: LexicalEditor): void {
  editor.update(() => {
    const sel = $getSelection();
    if (!sel) return;
    let n: LexicalNode | null = sel.getNodes()[0] ?? null;
    let cell: TableCellNode | null = null;
    while (n) {
      if ($isTableCellNode(n)) {
        cell = n as TableCellNode;
        break;
      }
      n = n.getParent();
    }
    if (!cell) return;
    const row = cell.getParent<TableRowNode>();
    if (!row) return;
    const idx = cell.getIndexWithinParent();
    const table = row.getParent<TableNode>();
    if (!table) return;
    const rows = table.getChildren<TableRowNode>();
    rows.forEach((r) => {
      const c = r.getChildAtIndex(idx);
      if (c) c.remove();
    });
    const anyCells = rows.some((r) => r.getChildrenSize() > 0);
    if (!anyCells) table.remove();
  });
}

export function tableDelete(editor: LexicalEditor): void {
  editor.update(() => {
    const table = nearestTable();
    if (table) table.remove();
  });
}

export interface EditorPageSettings {
  margin: 'narrow' | 'normal' | 'wide';
  orientation: 'portrait' | 'landscape';
}

interface RichTextEditorProps {
  initialHtml: string;
  editorRef?: MutableRefObject<LexicalEditor | null>;
  readOnly?: boolean;
  onReady?: (editor: LexicalEditor) => void;
  pageSettings?: EditorPageSettings;
}

/**
 * FAZ9 PDF Editör — Düzenlenebilir belge gövdiesi (Lexical rich text).
 * Word benzeri beyaz A4 sayfa üzerinde; başlık/paragraf/liste/bold/italic +
 * font/boyut/hizalama + TABLO desteği. Ribbon (üstte sabit) shell tarafından
 * yönetilir. `readOnly` ile DOCX önizlemesinde salt-okunur da kullanılır.
 */
export default function RichTextEditor({
  initialHtml,
  editorRef,
  readOnly = false,
  onReady,
  pageSettings,
}: RichTextEditorProps) {
  const initialConfig = {
    namespace: 'evrak-ocr-editor',
    editable: !readOnly,
    nodes: [HeadingNode, QuoteNode, ListNode, ListItemNode, TableNode, TableRowNode, TableCellNode],
    onError: () => {},
    theme,
  };

  const orientation = pageSettings?.orientation ?? 'portrait';
  const margin = pageSettings?.margin ?? 'normal';
  const pageWidth = orientation === 'landscape' ? 1120 : 820;
  const pagePad = margin === 'narrow' ? 28 : margin === 'wide' ? 96 : 56;

  return (
    <LexicalComposer initialConfig={initialConfig}>
      <div className={`flex flex-col ${readOnly ? '' : 'h-full min-h-0'}`}>
        <div className="flex-1 overflow-y-auto overflow-x-auto min-h-0 bg-background-100 dark:bg-background-200/60">
          <div
            className="mx-auto my-4 md:my-6 isg-paper shadow-sm border border-background-200/70"
            style={{ maxWidth: pageWidth, width: '100%' }}
          >
            <div style={{ padding: `${pagePad}px ${pagePad}px` }}>
              <RichTextPlugin
                contentEditable={
                  <ContentEditable
                    className={`text-[15px] leading-7 text-[#111827] outline-none ${
                      readOnly ? 'min-h-[320px]' : 'min-h-[62vh]'
                    }`}
                    style={{ fontFamily: 'Arial, Helvetica, sans-serif' }}
                  />
                }
                placeholder={
                  <div className="text-sm text-[#9ca3af] pointer-events-none select-none">
                    Belge içeriği burada düzenlenir…
                  </div>
                }
                ErrorBoundary={() => <div className="text-sm text-danger-600">Editör yüklenemedi.</div>}
              />
            </div>
          </div>
        </div>
        <HistoryPlugin />
        <ListPlugin />
        <TablePlugin />
        <LoadContentPlugin html={initialHtml} />
        <EditorRefCapture editorRef={editorRef} onReady={onReady} />
      </div>
    </LexicalComposer>
  );
}