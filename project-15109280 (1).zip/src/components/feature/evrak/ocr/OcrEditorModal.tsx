import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { MutableRefObject, ReactNode } from 'react';
import type { LexicalEditor } from 'lexical';
import {
  UNDO_COMMAND,
  REDO_COMMAND,
  FORMAT_TEXT_COMMAND,
  FORMAT_ELEMENT_COMMAND,
} from 'lexical';
import { INSERT_ORDERED_LIST_COMMAND, INSERT_UNORDERED_LIST_COMMAND } from '@lexical/list';
import { $generateHtmlFromNodes } from '@lexical/html';
import type { PDFDocumentProxy } from 'pdfjs-dist';
import Button from '@/components/ui/Button';
import Select from '@/components/ui/Select';
import { useToastActions } from '@/hooks/useToast';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import type { EvrakData } from '@/lib/evrakService';
import { getEvrakContent, getEvrakUrl, uploadEvrak, friendlyEvrakError } from '@/lib/evrakService';
import {
  extractContent,
  generatePdfFromHtml,
  isSupportedForOcr,
  isPdf,
  base64ToArrayBuffer,
  htmlHasContent,
  loadPdfDocument,
  pdfDocToHtml,
} from '@/lib/ocrService';
import RichTextEditor, {
  useEditorFormatState,
  applyFontSize,
  applyFontFamily,
  setBlockType,
  insertTable,
  tableAddRow,
  tableDeleteRow,
  tableAddColumn,
  tableDeleteColumn,
  tableDelete,
  type BlockType,
  type EditorPageSettings,
} from './RichTextEditor';
import {
  DocumentPreviewEngine,
  type PreviewDocumentSource,
  type PreviewViewerHandle,
  type PreviewViewerState,
} from '@/components/feature/preview';

interface OcrEditorModalProps {
  evrak: EvrakData;
  onClose: () => void;
  onSaved: () => void;
}

type Phase = 'extracting' | 'ready' | 'error' | 'saving';
type TabKey = 'view' | 'edit' | 'annotate' | 'sign' | 'page' | 'convert';

const TABS: { key: TabKey; label: string }[] = [
  { key: 'view', label: 'Görüntüle' },
  { key: 'edit', label: 'Düzenle' },
  { key: 'annotate', label: 'Açıklama' },
  { key: 'sign', label: 'Doldur ve İmzala' },
  { key: 'page', label: 'Sayfa' },
  { key: 'convert', label: 'Dönüştür' },
];

const FONT_FAMILIES = [
  { value: 'Arial, Helvetica, sans-serif', label: 'Arial' },
  { value: '"Times New Roman", Times, serif', label: 'Times New Roman' },
  { value: 'Georgia, serif', label: 'Georgia' },
  { value: 'Verdana, sans-serif', label: 'Verdana' },
  { value: 'Tahoma, sans-serif', label: 'Tahoma' },
  { value: '"Courier New", monospace', label: 'Courier New' },
];

const FONT_SIZES = ['10px', '11px', '12px', '13px', '14px', '15px', '16px', '18px', '20px', '24px', '28px', '32px', '36px'];

const MARJIN_OPTIONS: { key: EditorPageSettings['margin']; label: string }[] = [
  { key: 'narrow', label: 'Dar' },
  { key: 'normal', label: 'Normal' },
  { key: 'wide', label: 'Geniş' },
];

const YON_OPTIONS: { key: EditorPageSettings['orientation']; label: string }[] = [
  { key: 'portrait', label: 'Dikey' },
  { key: 'landscape', label: 'Yatay' },
];

/** Ribbon butonu — shell'in tek çalışan araç standardı. */
function RibbonBtn({
  onClick,
  title,
  active,
  disabled,
  children,
}: {
  onClick?: () => void;
  title?: string;
  active?: boolean;
  disabled?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      disabled={disabled}
      className={`h-8 min-w-8 px-2 rounded-md text-sm flex items-center justify-center gap-1 whitespace-nowrap cursor-pointer transition-colors disabled:opacity-40 disabled:cursor-not-allowed ${
        active
          ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-700'
          : 'text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40'
      }`}
    >
      {children}
    </button>
  );
}

function Separator() {
  return <span className="w-px h-5 bg-background-300/60 dark:bg-background-400/40 mx-1 flex-shrink-0" />;
}

/** Desteklenmeyen sekme panelleri için dürüst (sahte olmayan) bilgi paneli. */
function InfoPanel({ icon, title, text }: { icon: string; title: string; text: string }) {
  return (
    <div className="h-full flex flex-col items-center justify-center gap-3 py-16 px-6 text-center">
      <div className="w-12 h-12 rounded-full bg-background-200 dark:bg-background-300/50 flex items-center justify-center">
        <i className={`${icon} text-foreground-500 text-2xl`} />
      </div>
      <p className="text-sm font-semibold text-foreground-800">{title}</p>
      <p className="text-xs text-foreground-500 max-w-md">{text}</p>
    </div>
  );
}

export default function OcrEditorModal({ evrak, onClose, onSaved }: OcrEditorModalProps) {
  const { addToast } = useToastActions();

  const [phase, setPhase] = useState<Phase>('extracting');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [initialHtml, setInitialHtml] = useState('');
  const [editor, setEditor] = useState<LexicalEditor | null>(null);
  const editorRef = useRef<LexicalEditor | null>(null) as MutableRefObject<LexicalEditor | null>;
  const [pdfDoc, setPdfDoc] = useState<PDFDocumentProxy | null>(null);
  const [tab, setTab] = useState<TabKey>('view');
  const [viewer, setViewer] = useState<PreviewViewerState>({ page: 1, count: 1, zoom: 1, rotation: 0 });
  const [pageInput, setPageInput] = useState('1');
  const [pageSettings, setPageSettings] = useState<EditorPageSettings>({ margin: 'normal', orientation: 'portrait' });
  const viewerRef = useRef<PreviewViewerHandle>(null);

  const isPdfDoc = isPdf(evrak.mimeType);
  const fmt = useEditorFormatState(editor);

  useEffect(() => {
    setPageInput(String(viewer.page));
  }, [viewer.page]);

  const handleViewerState = useCallback((s: PreviewViewerState) => setViewer(s), []);

  // Merkezi Preview Engine sözleşmesi: evrakı yetkilendirilmiş kaynağa çevir.
  const previewSource = useMemo<PreviewDocumentSource>(
    () => ({
      cacheKey: `editor:${evrak.id}:${evrak.revisionNo ?? 1}`,
      fileName: evrak.originalFileName ?? evrak.title ?? 'belge',
      mimeType: evrak.mimeType,
      getBytes: async () => base64ToArrayBuffer((await getEvrakContent(evrak.id)).fileBase64),
    }),
    [evrak.id, evrak.revisionNo, evrak.originalFileName, evrak.title, evrak.mimeType],
  );

  const runExtraction = useCallback(async () => {
    setPhase('extracting');
    setErrorMessage(null);
    try {
      if (!isSupportedForOcr(evrak.mimeType)) {
        throw new Error('Bu dosya türü düzenlenemez. Yalnızca PDF ve Word belgeleri desteklenir.');
      }
      // Gerçek dosya her seferinde storage'dan taze okunur (boş/cache içerik kullanılmaz).
      const { fileBase64 } = await getEvrakContent(evrak.id);
      const bytes = base64ToArrayBuffer(fileBase64);

      if (isPdf(evrak.mimeType)) {
        // pdf.js buffer'ı sahiplenir; dokümanı bir kez yükleyip viewer + metin çıkarımında paylaşırız.
        const doc = await loadPdfDocument(bytes);
        setPdfDoc(doc);
        const html = await pdfDocToHtml(doc);
        if (!htmlHasContent(html)) {
          throw new Error(
            'Belgede çıkarılabilir metin bulunamadı. Bu belge taranmış görüntü içeriyor olabilir; orijinal dosya korundu.',
          );
        }
        setInitialHtml(html);
      } else {
        const html = await extractContent(bytes, evrak.mimeType);
        if (!htmlHasContent(html)) {
          throw new Error('Belgede çıkarılabilir içerik bulunamadı. Orijinal dosya korundu.');
        }
        setInitialHtml(html);
      }
      setPhase('ready');
    } catch (e) {
      setErrorMessage(friendlyErrorMessage(e, 'Belge işlenemedi.'));
      setPhase('error');
    }
  }, [evrak.id, evrak.mimeType]);

  useEffect(() => {
    runExtraction();
  }, [runExtraction]);

  const handleDownloadOriginal = async () => {
    try {
      const url = await getEvrakUrl(evrak.id);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
      addToast({ title: 'Dosya açılamadı', message: friendlyEvrakError(e), type: 'error' });
    }
  };

  const handleSave = async () => {
    const ed = editorRef.current;
    if (!ed) {
      addToast({ title: 'Editör hazır değil', message: 'İçerik hazırlanıyor, birkaç saniye sonra tekrar deneyin.', type: 'warning' });
      return;
    }
    setPhase('saving');
    try {
      let html = '';
      ed.getEditorState().read(() => {
        html = $generateHtmlFromNodes(ed);
      });
      if (!htmlHasContent(html)) {
        throw new Error('Belge içeriği boş; kaydetmeden önce içerik ekleyin.');
      }

      const pdfBlob = await generatePdfFromHtml(html, pageSettings);
      const nextRev = (evrak.revisionNo ?? 1) + 1;
      const baseName = (evrak.originalFileName ?? evrak.title).replace(/\.[^.]+$/, '') || 'belge';
      const file = new File([pdfBlob], `${baseName}_rev${nextRev}.pdf`, { type: 'application/pdf' });

      await uploadEvrak({
        ownerType: evrak.ownerType,
        firmaId: evrak.firmaId,
        personelId: evrak.personelId,
        requirementId: evrak.requirementId,
        documentTypeId: evrak.documentTypeId,
        title: evrak.title,
        description: evrak.description,
        documentDate: evrak.documentDate,
        previousEvrakId: evrak.id,
        file,
      });

      addToast({
        title: 'Yeni sürüm oluşturuldu',
        message: `Revizyon ${nextRev} aktifleştirildi; eski sürüm (V${evrak.revisionNo ?? 1}) arşivlendi.`,
        type: 'success',
      });
      onSaved();
      onClose();
    } catch (e) {
      addToast({ title: 'Kaydetme başarısız', message: friendlyEvrakError(e), type: 'error' });
      setPhase('ready');
    }
  };

  // ---------------- Ribbon komutları (gereçkten çalışan) ----------------
  const cmd = useMemo(
    () => ({
      undo: () => editor?.dispatchCommand(UNDO_COMMAND, undefined),
      redo: () => editor?.dispatchCommand(REDO_COMMAND, undefined),
      text: (f: 'bold' | 'italic' | 'underline' | 'strikethrough') => editor?.dispatchCommand(FORMAT_TEXT_COMMAND, f),
      align: (a: 'left' | 'center' | 'right' | 'justify') => editor?.dispatchCommand(FORMAT_ELEMENT_COMMAND, a),
      list: (t: 'bullet' | 'number') =>
        editor?.dispatchCommand(t === 'bullet' ? INSERT_UNORDERED_LIST_COMMAND : INSERT_ORDERED_LIST_COMMAND, undefined),
    }),
    [editor],
  );

  const onBlockChange = (value: string) => {
    if (editor) setBlockType(editor, value as BlockType);
  };

  // ---------------- Ribbon (sekmeye göre) ----------------
  const viewRibbon = (
    <>
      <RibbonBtn title="Önceki sayfa" onClick={() => viewerRef.current?.prev()}>
        <i className="ri-arrow-left-s-line" />
      </RibbonBtn>
      <input
        type="text"
        inputMode="numeric"
        value={pageInput}
        onChange={(e) => setPageInput(e.target.value.replace(/[^0-9]/g, ''))}
        onKeyDown={(e) => {
          if (e.key === 'Enter') viewerRef.current?.goTo(Number(pageInput) || 1);
        }}
        onBlur={() => viewerRef.current?.goTo(Number(pageInput) || 1)}
        className="w-11 h-8 text-center text-sm rounded-md border border-background-300/70 dark:border-background-400/40 bg-background-100 dark:bg-background-200 text-foreground-800"
        aria-label="Sayfa numarası"
      />
      <span className="text-sm text-foreground-500 px-0.5 whitespace-nowrap">/ {viewer.count}</span>
      <RibbonBtn title="Sonraki sayfa" onClick={() => viewerRef.current?.next()}>
        <i className="ri-arrow-right-s-line" />
      </RibbonBtn>
      <Separator />
      <RibbonBtn title="Uzaklaştır" onClick={() => viewerRef.current?.zoomOut()}>
        <i className="ri-subtract-line" />
      </RibbonBtn>
      <span className="text-sm text-foreground-700 w-12 text-center tabular-nums">{Math.round(viewer.zoom * 100)}%</span>
      <RibbonBtn title="Yakınlaştır" onClick={() => viewerRef.current?.zoomIn()}>
        <i className="ri-add-line" />
      </RibbonBtn>
      <Separator />
      <RibbonBtn title="Sayfaya sığdır" onClick={() => viewerRef.current?.fitPage()}>
        <i className="ri-fullscreen-line" />
      </RibbonBtn>
      <RibbonBtn title="Genişliğe sığdır" onClick={() => viewerRef.current?.fitWidth()}>
        <i className="ri-aspect-ratio-line" />
      </RibbonBtn>
      <Separator />
      <RibbonBtn title="Orijinali indir" onClick={handleDownloadOriginal}>
        <i className="ri-download-2-line" />
      </RibbonBtn>
    </>
  );

  const editRibbon = (
    <>
      <RibbonBtn title="Geri al" onClick={cmd.undo} disabled={!editor}>
        <i className="ri-arrow-go-back-line" />
      </RibbonBtn>
      <RibbonBtn title="İleri al" onClick={cmd.redo} disabled={!editor}>
        <i className="ri-arrow-go-forward-line" />
      </RibbonBtn>
      <Separator />
      <Select
        size="sm"
        containerClassName="w-28"
        value=""
        placeholder="Stil"
        onChange={(e) => onBlockChange(e.target.value)}
        options={[
          { value: 'paragraph', label: 'Paragraf' },
          { value: 'h1', label: 'Başlık 1' },
          { value: 'h2', label: 'Başlık 2' },
          { value: 'h3', label: 'Başlık 3' },
        ]}
      />
      <Select
        size="sm"
        containerClassName="w-36"
        value={FONT_FAMILIES.some((f) => f.value === fmt.fontFamily) ? fmt.fontFamily : ''}
        placeholder="Yazı tipi"
        onChange={(e) => editor && applyFontFamily(editor, e.target.value)}
        options={FONT_FAMILIES.map((f) => ({ value: f.value, label: f.label }))}
      />
      <Select
        size="sm"
        containerClassName="w-20"
        value={FONT_SIZES.includes(fmt.fontSize) ? fmt.fontSize : ''}
        placeholder="Boyut"
        onChange={(e) => editor && applyFontSize(editor, e.target.value)}
        options={FONT_SIZES.map((s) => ({ value: s, label: s.replace('px', '') }))}
      />
      <Separator />
      <RibbonBtn title="Kalın" active={fmt.bold} onClick={() => cmd.text('bold')} disabled={!editor}>
        <i className="ri-bold" />
      </RibbonBtn>
      <RibbonBtn title="İtalik" active={fmt.italic} onClick={() => cmd.text('italic')} disabled={!editor}>
        <i className="ri-italic" />
      </RibbonBtn>
      <RibbonBtn title="Altı çizili" active={fmt.underline} onClick={() => cmd.text('underline')} disabled={!editor}>
        <i className="ri-underline" />
      </RibbonBtn>
      <RibbonBtn title="Üstü çizili" active={fmt.strikethrough} onClick={() => cmd.text('strikethrough')} disabled={!editor}>
        <i className="ri-strikethrough" />
      </RibbonBtn>
      <Separator />
      <RibbonBtn title="Sola hizala" active={fmt.align === 'left'} onClick={() => cmd.align('left')} disabled={!editor}>
        <i className="ri-align-left" />
      </RibbonBtn>
      <RibbonBtn title="Ortala" active={fmt.align === 'center'} onClick={() => cmd.align('center')} disabled={!editor}>
        <i className="ri-align-center" />
      </RibbonBtn>
      <RibbonBtn title="Sağa hizala" active={fmt.align === 'right'} onClick={() => cmd.align('right')} disabled={!editor}>
        <i className="ri-align-right" />
      </RibbonBtn>
      <RibbonBtn title="İki yana yasla" active={fmt.align === 'justify'} onClick={() => cmd.align('justify')} disabled={!editor}>
        <i className="ri-align-justify" />
      </RibbonBtn>
      <Separator />
      <RibbonBtn title="Madde işaretli liste" onClick={() => cmd.list('bullet')} disabled={!editor}>
        <i className="ri-list-unordered" />
      </RibbonBtn>
      <RibbonBtn title="Numaralı liste" onClick={() => cmd.list('number')} disabled={!editor}>
        <i className="ri-list-ordered" />
      </RibbonBtn>
      <Separator />
      <RibbonBtn title="Tablo ekle" onClick={() => editor && insertTable(editor, 3, 3)} disabled={!editor}>
        <i className="ri-table-line" />
        <span className="text-xs">Tablo Ekle</span>
      </RibbonBtn>
      <RibbonBtn title="Satır ekle" onClick={() => editor && tableAddRow(editor)} disabled={!editor}>
        <i className="ri-insert-row-bottom" />
      </RibbonBtn>
      <RibbonBtn title="Satır sil" onClick={() => editor && tableDeleteRow(editor)} disabled={!editor}>
        <i className="ri-delete-row" />
      </RibbonBtn>
      <RibbonBtn title="Sütun ekle" onClick={() => editor && tableAddColumn(editor)} disabled={!editor}>
        <i className="ri-insert-column-right" />
      </RibbonBtn>
      <RibbonBtn title="Sütun sil" onClick={() => editor && tableDeleteColumn(editor)} disabled={!editor}>
        <i className="ri-delete-column" />
      </RibbonBtn>
      <RibbonBtn title="Tabloyu sil" onClick={() => editor && tableDelete(editor)} disabled={!editor}>
        <i className="ri-table-2" />
      </RibbonBtn>
    </>
  );

  const pageRibbon = (
    <>
      <span className="text-xs text-foreground-500 px-1 whitespace-nowrap">Kenar boşluğu</span>
      {MARJIN_OPTIONS.map((m) => (
        <RibbonBtn
          key={m.key}
          active={pageSettings.margin === m.key}
          onClick={() => setPageSettings((s) => ({ ...s, margin: m.key }))}
        >
          <span className="text-xs">{m.label}</span>
        </RibbonBtn>
      ))}
      <Separator />
      <span className="text-xs text-foreground-500 px-1 whitespace-nowrap">Yön</span>
      {YON_OPTIONS.map((o) => (
        <RibbonBtn
          key={o.key}
          active={pageSettings.orientation === o.key}
          onClick={() => setPageSettings((s) => ({ ...s, orientation: o.key }))}
        >
          <span className="text-xs">{o.label}</span>
        </RibbonBtn>
      ))}
      {isPdfDoc && (
        <>
          <Separator />
          <RibbonBtn title="Sayfaya sığdır" onClick={() => viewerRef.current?.fitPage()}>
            <i className="ri-fullscreen-line" />
          </RibbonBtn>
          <RibbonBtn title="Genişliğe sığdır" onClick={() => viewerRef.current?.fitWidth()}>
            <i className="ri-aspect-ratio-line" />
          </RibbonBtn>
        </>
      )}
    </>
  );

  const convertRibbon = (
    <>
      <RibbonBtn title="Orijinali indir" onClick={handleDownloadOriginal}>
        <i className="ri-download-2-line" />
        <span className="text-xs">Orijinali İndir</span>
      </RibbonBtn>
      <Separator />
      <RibbonBtn title="Düzenlenen içeriği yeni sürüm olarak kaydet" onClick={handleSave} disabled={phase === 'saving'}>
        <i className="ri-save-3-line" />
        <span className="text-xs">Yeni Sürüm PDF</span>
      </RibbonBtn>
    </>
  );

  const docViewRibbon = (
    <>
      <RibbonBtn title="Orijinali indir" onClick={handleDownloadOriginal}>
        <i className="ri-download-2-line" />
        <span className="text-xs">Orijinali İndir</span>
      </RibbonBtn>
      <Separator />
      <span className="text-xs text-foreground-500 px-1 whitespace-nowrap">
        Bu Word belgesi, gerçek içeriği çıkarılarak gösterilir; düzenlemek için Düzenle sekmesini açın.
      </span>
    </>
  );

  const ribbon =
    tab === 'view'
      ? isPdfDoc
        ? viewRibbon
        : docViewRibbon
      : tab === 'edit'
        ? editRibbon
        : tab === 'page'
          ? pageRibbon
          : tab === 'convert'
            ? convertRibbon
            : null;

  // ---------------- Body ----------------
  const body = (() => {
    if (phase === 'extracting') {
      return (
        <div className="h-full flex flex-col items-center justify-center gap-3 py-16">
          <div className="w-10 h-10 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" aria-hidden="true" />
          <p className="text-sm text-foreground-600">Belge içeriği hazırlanıyor…</p>
          <p className="text-xs text-foreground-400">Gerçek dosya okunuyor; orijinal belge değiştirilmez.</p>
        </div>
      );
    }
    if (phase === 'error') {
      return (
        <div className="h-full flex flex-col items-center justify-center gap-3 py-16 text-center px-4">
          <div className="w-12 h-12 rounded-full bg-background-200 dark:bg-background-300/50 flex items-center justify-center">
            <i className="ri-error-warning-line text-foreground-500 text-2xl" />
          </div>
          <div>
            <p className="text-sm font-semibold text-foreground-800">Belge işlenemedi</p>
            <p className="text-xs text-foreground-500 mt-1 max-w-md">{errorMessage}</p>
            <p className="text-xs text-foreground-400 mt-1">Orijinal belge korundu, aktif sürüm değişmedi.</p>
          </div>
          <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={runExtraction}>
            Tekrar Dene
          </Button>
        </div>
      );
    }
    return (
      <>
        <div className={tab === 'view' ? 'h-full min-h-0 overflow-hidden' : 'hidden'}>
          <DocumentPreviewEngine
            ref={viewerRef}
            source={previewSource}
            title={evrak.title}
            showToolbar={false}
            onStateChange={handleViewerState}
            className="h-full"
          />
        </div>

        <div className={tab === 'edit' ? 'h-full min-h-0' : 'hidden'}>
          <RichTextEditor
            initialHtml={initialHtml}
            editorRef={editorRef}
            onReady={setEditor}
            pageSettings={pageSettings}
          />
        </div>

        {tab === 'annotate' && (
          <InfoPanel
            icon="ri-markup-line"
            title="Açıklama (annotasyon) bu düzenleyicide desteklenmiyor"
            text="Çizim, vurgulama ve serbest metin ekleme gibi işaretleme araçları bu tarayıcı tabanlı düzenleyicide sunulmuyor. Belge metnini Düzenle sekmesinden değiştirip yeni sürüm olarak kaydedebilirsiniz."
          />
        )}
        {tab === 'sign' && (
          <InfoPanel
            icon="ri-quill-pen-line"
            title="Doldur ve imzala bu düzenleyicide desteklenmiyor"
            text="Dijital imza ve form doldurma alanları bu tarayıcı tabanlı düzenleyicide sunulmuyor. Belge içeriğini Düzenle sekmesinden güncelleyip yeni sürüm olarak kaydedebilirsiniz."
          />
        )}
        {tab === 'page' && (
          <div className="h-full flex flex-col items-center justify-center gap-2 py-16 px-6 text-center">
            <i className="ri-layout-line text-foreground-500 text-2xl" />
            <p className="text-sm font-semibold text-foreground-800">Sayfa düzeni</p>
            <p className="text-xs text-foreground-500 max-w-md">
              Kenar boşluğu ve yön seçimi üstteki şeritten uygulanır. Seçim, düzenlenen belgenin ekran görünümünü ve
              Kaydet (Yeni Sürüm) ile üretilen PDF çıktısını etkiler.
            </p>
          </div>
        )}
        {tab === 'convert' && (
          <div className="h-full flex flex-col items-center justify-center gap-2 py-16 px-6 text-center">
            <i className="ri-file-transfer-line text-foreground-500 text-2xl" />
            <p className="text-sm font-semibold text-foreground-800">Dönüştür</p>
            <p className="text-xs text-foreground-500 max-w-md">
              Düzenlenen içerik, Kaydet (Yeni Sürüm) ile gerçek, çok sayfalı, tablo ve Türkçe karakter destekli bir PDF
              dosyasına dönüştürülür. Orijinal belge hiçbir zaman değiştirilmez veya silinmez.
            </p>
          </div>
        )}
      </>
    );
  })();

  return (
    <div className="-mx-4 -my-3 h-[calc(100%+1.5rem)] flex flex-col min-h-0 bg-background-50 dark:bg-background-100">
      {/* Sekme şeridi */}
      <div className="flex items-center gap-0.5 px-2 border-b border-background-300/50 dark:border-background-400/30 overflow-x-auto no-scrollbar flex-shrink-0">
        {TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            onClick={() => setTab(t.key)}
            className={`px-3 py-2 text-sm font-medium border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
              tab === t.key
                ? 'border-primary-500 text-primary-600 dark:text-primary-700'
                : 'border-transparent text-foreground-600 hover:text-foreground-900'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Ribbon */}
      {ribbon && (
        <div className="flex items-center gap-0.5 px-3 py-1.5 border-b border-background-300/50 dark:border-background-400/30 overflow-x-auto no-scrollbar flex-shrink-0 bg-background-100 dark:bg-background-200/40">
          {ribbon}
        </div>
      )}

      {/* Gövde */}
      <div className="flex-1 min-h-0 relative">{body}</div>

      {/* Alt bar */}
      <div className="flex items-center justify-between gap-2 px-3 py-2 border-t border-background-300/50 dark:border-background-400/30 flex-shrink-0 bg-background-100 dark:bg-background-200/40">
        <Button
          variant="ghost"
          size="sm"
          leftIcon={<i className="ri-download-2-line" />}
          onClick={handleDownloadOriginal}
        >
          Orijinali İndir
        </Button>
        <span className="text-xs text-foreground-500 tabular-nums">
          {isPdfDoc && pdfDoc ? `${viewer.page} / ${viewer.count}` : ''}
        </span>
        <div className="flex items-center gap-2">
          <Button variant="secondary" size="sm" onClick={onClose} disabled={phase === 'saving'}>
            Vazgeç
          </Button>
          <Button
            variant="primary"
            size="sm"
            leftIcon={<i className="ri-save-3-line" />}
            onClick={handleSave}
            isLoading={phase === 'saving'}
            disabled={phase !== 'ready' && phase !== 'saving'}
          >
            Kaydet (Yeni Sürüm)
          </Button>
        </div>
      </div>
    </div>
  );
}