import { forwardRef, useCallback, useImperativeHandle, useMemo, useRef, useState } from 'react';
import type { PreviewDocumentSource, PreviewViewerHandle, PreviewViewerState } from '@/components/feature/preview';
import DocumentPreviewEngine from '@/components/feature/preview/DocumentPreviewEngine';
import { base64ToArrayBuffer } from '@/lib/ocrService';
import { friendlyEvrakError, getEvrakContent, type EvrakData } from '@/lib/evrakService';
import { downloadBytesFile, sanitizeFilename, resolveExtension } from '@/lib/downloadFile';
import { useToastActions } from '@/hooks/useToast';

export interface EvrakBelgeViewerHandle {
  next: () => void;
  prev: () => void;
  goTo: (n: number) => void;
  zoomIn: () => void;
  zoomOut: () => void;
  fitPage: () => void;
}

interface EvrakBelgeViewerProps {
  evrak: EvrakData;
  onState?: (s: PreviewViewerState) => void;
}

/**
 * Evrak belge görüntüleyici (detay modalı gövdesi).
 *
 * Artık KENDİ viewer'ını yazmaz: MERKEZİ PREVIEW ENGINE'e ince bir ADAPTER'dır.
 * Evrak'ı `PreviewDocumentSource` sözleşmesine çevirir; PDF (worker + virtualization),
 * görsel, Word ve Excel önizlemesi motorun tek çekirdeğinden gelir.
 *
 * Belge içeriği SUNUCU TARAFI (scope/RLS/IDOR doğrulamalı) alınır; orijinal dosya
 * her zaman korunur, burada hiçbir üretim/OCR işlemi yapılmaz.
 */
const EvrakBelgeViewer = forwardRef<EvrakBelgeViewerHandle, EvrakBelgeViewerProps>(
  function EvrakBelgeViewer({ evrak, onState }, ref) {
    const { addToast } = useToastActions();
    const engineRef = useRef<PreviewViewerHandle>(null);
    const [busyAction, setBusyAction] = useState(false);

    const source: PreviewDocumentSource = useMemo(
      () => ({
        cacheKey: `${evrak.id}:${evrak.revisionNo ?? 1}`,
        fileName: evrak.originalFileName ?? evrak.title ?? 'belge',
        mimeType: evrak.mimeType,
        fileSize: evrak.fileSize,
        getBytes: async () => {
          const c = await getEvrakContent(evrak.id);
          return base64ToArrayBuffer(c.fileBase64);
        },
      }),
      [evrak.id, evrak.revisionNo, evrak.originalFileName, evrak.title, evrak.mimeType, evrak.fileSize],
    );

    const downloadFile = useCallback(async () => {
      setBusyAction(true);
      try {
        const c = await getEvrakContent(evrak.id);
        const bytes = base64ToArrayBuffer(c.fileBase64);
        const mime = c.mimeType ?? evrak.mimeType ?? null;
        const ext = resolveExtension(evrak.originalFileName, mime);
        const name = sanitizeFilename(`${evrak.title || 'Belge'}${ext ? `.${ext}` : ''}`, { fallback: 'Belge' });
        downloadBytesFile(bytes, mime, name);
      } catch (e) {
        addToast({ title: 'Dosya indirilemedi', message: friendlyEvrakError(e), type: 'error' });
      } finally {
        setBusyAction(false);
      }
    }, [evrak.id, evrak.originalFileName, evrak.title, evrak.mimeType, addToast]);

    useImperativeHandle(
      ref,
      () => ({
        next: () => engineRef.current?.next(),
        prev: () => engineRef.current?.prev(),
        goTo: (n: number) => engineRef.current?.goTo(n),
        zoomIn: () => engineRef.current?.zoomIn(),
        zoomOut: () => engineRef.current?.zoomOut(),
        fitPage: () => engineRef.current?.fitPage(),
      }),
      [],
    );

    return (
      <div className="flex flex-col h-full min-h-0">
        <DocumentPreviewEngine
          ref={engineRef}
          source={source}
          title={evrak.title}
          showToolbar={false}
          onStateChange={onState}
          onDownload={downloadFile}
          downloadBusy={busyAction}
          className="flex-1 min-h-0"
        />
      </div>
    );
  },
);

export default EvrakBelgeViewer;