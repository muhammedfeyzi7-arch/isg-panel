import { useCallback, useMemo, useState } from 'react';
import { DocumentPreviewModal, type PreviewDocumentSource, type PreviewDocumentMeta } from '@/components/feature/preview';
import { base64ToArrayBuffer } from '@/lib/ocrService';
import { getEvrakContent } from '@/lib/evrakService';
import { downloadBytesFile, sanitizeFilename, resolveExtension } from '@/lib/downloadFile';

/** Önizleme açılacak belgenin minimal tanımı (satır verisinden de kurulabilir). */
export interface EvrakOnizlemeTarget {
  evrakId: string;
  title: string;
  fileName: string | null;
  mimeType: string | null;
  fileSize: number | null;
  meta?: PreviewDocumentMeta;
}

/** `PersonelEvrakSatir` benzeri satırdan önizleme hedefi üretir. */
export function evrakSatirToTarget(
  r: { id: string; title: string; fileName: string | null; mimeType: string | null; fileSize: number | null;
       documentTypeName?: string | null; documentDate?: string | null; validUntil?: string | null;
       status?: string | null; createdAt?: string | null },
  meta?: PreviewDocumentMeta,
): EvrakOnizlemeTarget {
  return {
    evrakId: r.id,
    title: r.documentTypeName || r.title,
    fileName: r.fileName ?? null,
    mimeType: r.mimeType ?? null,
    fileSize: r.fileSize ?? null,
    meta,
  };
}

function buildSource(t: EvrakOnizlemeTarget): PreviewDocumentSource {
  return {
    cacheKey: `evrak:${t.evrakId}`,
    fileName: t.fileName || t.title || 'belge',
    mimeType: t.mimeType,
    fileSize: t.fileSize,
    getBytes: async () => base64ToArrayBuffer((await getEvrakContent(t.evrakId)).fileBase64),
    meta: t.meta,
  };
}

/**
 * SİSTEM İÇİ BELGE ÖNİZLEME — ortak hook.
 *
 * Evrak “Görüntüle” aksiyonları YENİ SEKME AÇMAZ. Bunun yerine SharedUICore'un
 * merkezi belge önizleme modalını (DocumentPreviewModal → SharedDocumentPreview)
 * sistem içinde açar: büyük PDF alanı, zoom, sayfa gezinme, tam ekran, indir, kapat.
 * Belge içeriği sunucu tarafı (scope/RLS/IDOR doğrulamalı `evrak` edge function)
 * üzerinden çekilir — new tab / harici viewer kullanılmaz.
 */
export function useEvrakOnizleme() {
  const [target, setTarget] = useState<EvrakOnizlemeTarget | null>(null);
  const [busy, setBusy] = useState(false);

  const openEvrak = useCallback((t: EvrakOnizlemeTarget) => setTarget(t), []);
  const close = useCallback(() => setTarget(null), []);

  const handleDownload = useCallback(async () => {
    if (!target) return;
    setBusy(true);
    try {
      const c = await getEvrakContent(target.evrakId);
      const bytes = base64ToArrayBuffer(c.fileBase64);
      const mime = c.mimeType ?? target.mimeType ?? null;
      const ext = resolveExtension(target.fileName, mime);
      const name = sanitizeFilename(`${target.title || 'Belge'}${ext ? `.${ext}` : ''}`, { fallback: 'Belge' });
      downloadBytesFile(bytes, mime, name);
    } finally {
      setBusy(false);
    }
  }, [target]);

  const source = useMemo(() => (target ? buildSource(target) : null), [target]);

  /** Bileşen gövdesinde render edilecek önizleme düğümü (kapalıysa null). */
  const evrakPreviewNode = target && source ? (
    <DocumentPreviewModal
      source={source}
      title={target.title}
      onClose={close}
      onDownload={handleDownload}
      downloadBusy={busy}
    />
  ) : null;

  return { openEvrak, evrakPreviewNode, closeEvrak: close };
}