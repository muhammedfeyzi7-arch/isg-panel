import { useLayoutEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { recordPerfSample } from '@/lib/perf/perfStore';

/**
 * ROTA GEÇİŞ ÖLÇÜMÜ — SPA içi sayfa geçişlerinin (commit → paint) süresini ölçer.
 *
 * Neden bu aralık: React Router (declarative) gezinme BAŞLANGIÇ anını dışa açmaz;
 * bu yüzden dürüst ve ölçülebilir olan aralık, yeni rotanın COMMIT'i ile bir sonraki
 * karenin boyanması (çift requestAnimationFrame) arasıdır. Bu, rota geçişinin asıl
 * render/paint maliyetini yakalar. Ağ beklemesi (lazy chunk + veri) ayrı ölçülür
 * (fetch timing + Web Vitals).
 *
 * İlk yükleme BURADA ölçülmez: o, Web Vitals (FCP/LCP/TTFB) tarafından kapsanır —
 * aynı maliyeti iki kez ölçüp çift saymayız.
 *
 * Maliyet: rotada bir kez çift rAF + tek kayıt → ihmal edilebilir; açılışı yavaşlatmaz.
 */
export default function RouteTimingProbe() {
  const location = useLocation();
  const isFirstRoute = useRef(true);

  useLayoutEffect(() => {
    if (isFirstRoute.current) {
      isFirstRoute.current = false;
      return;
    }
    const path = location.pathname;
    const t0 = performance.now();
    let raf1 = 0;
    let raf2 = 0;
    raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => {
        recordPerfSample({
          kind: 'route',
          name: 'route-paint',
          value: Math.round((performance.now() - t0) * 100) / 100,
          detail: path,
          ts: Date.now(),
        });
      });
    });
    return () => {
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
    };
  }, [location.key, location.pathname]);

  return null;
}