import { useState } from 'react';
import { useTheme } from '@/context/ThemeContext';

const LOGO_DARK = 'https://static.readdy.ai/image/9a23c36b022e5dee23ad356dbe985840/f12035640d991a27cdd7f34ddcb0302b.png';
const LOGO_LIGHT = 'https://static.readdy.ai/image/9a23c36b022e5dee23ad356dbe985840/2c26bb041c16a589e47c46b5aa377d73.png';

interface BrandLogoProps {
  className?: string;
  style?: React.CSSProperties;
  alt?: string;
  variant?: 'full' | 'mark';
  /**
   * Koyu zemin üzerinde açık-metin logosunu ZORLAR.
   * Sidebar rail artık TEMA-AWARE olduğu için Sidebar bunu KULLANMAZ;
   * logo normalde tema ile seçilir (light → açık zemin/koyu metin logosu).
   */
  forceDark?: boolean;
}

/**
 * ORTAK Marka Logosu (TEK KAYNAK). Light/Dark için ayrı asset barındırır,
 * tema değişince "tak" diye değişir (animasyon yok).
 *
 * Kırık görsel fallback: logo yüklenemezse kırık-resim ikonu yerine
 * metin tabanlı bir yer tutucu gösterilir — marka boşluğu kırık kalmaz.
 * Logo LCP (above-the-fold) olduğu için lazy yüklenmez.
 */
export default function BrandLogo({ className = '', style, alt = 'Logo', variant = 'full', forceDark }: BrandLogoProps) {
  const { resolvedTheme } = useTheme();
  const [broken, setBroken] = useState(false);
  /* Logo TEMA-AWARE'dir: koyu temada (koyu sidebar/topbar) açık-metin varyantı,
     açık temada (açık rail) koyu-metin varyantı gösterilir. forceDark yalnızca
     koyu zemin üzerinde açık-metin logosunu zorlamak için kullanılabilir. */
  const useDark = forceDark || resolvedTheme === 'dark';

  if (broken) {
    return (
      <div
        className={`flex items-center justify-center font-semibold text-primary-600 ${className}`}
        style={style}
        aria-label={alt}
      >
        <span className="truncate">{alt}</span>
      </div>
    );
  }

  if (variant === 'mark') {
    return (
      <div className={`relative overflow-hidden aspect-square ${className}`} style={style}>
        <img
          src={LOGO_DARK}
          alt={alt}
          onError={() => setBroken(true)}
          className={useDark ? 'absolute inset-0 w-full h-full object-cover object-left' : 'hidden'}
          draggable={false}
        />
        <img
          src={LOGO_LIGHT}
          alt={alt}
          onError={() => setBroken(true)}
          className={!useDark ? 'absolute inset-0 w-full h-full object-cover object-left' : 'hidden'}
          draggable={false}
        />
      </div>
    );
  }

  return (
    <div className={`relative inline-block ${className}`} style={style}>
      <img
        src={LOGO_DARK}
        alt={alt}
        onError={() => setBroken(true)}
        className={useDark ? 'block h-full w-auto' : 'hidden'}
        draggable={false}
      />
      <img
        src={LOGO_LIGHT}
        alt={alt}
        onError={() => setBroken(true)}
        className={!useDark ? 'block h-full w-auto' : 'hidden'}
        draggable={false}
      />
    </div>
  );
}