import { useEffect, useState } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { fetchOsgbAccess } from '@/lib/osgbService';
import { fetchMaintenanceActive } from '@/lib/settingsService';
import { fetchAuthPersonelStatus } from '@/lib/personelService';
import { withTimeout, BOOTSTRAP_TIMEOUT_MS } from '@/lib/asyncTimeout';
import { createTransientRetry } from '@/lib/autoRetry';
import { consumeSessionEndNotice } from '@/lib/sessionPolicy';
import { supabase } from '@/lib/supabase';
import Shell from './Shell';
import SessionPolicyGuard from './SessionPolicyGuard';
import Button from '@/components/ui/Button';

const ADMIN_PATHS = ['/', '/osgb', '/destek', '/duyurular', '/meslek-evrak-yonetimi', '/logs', '/ayarlar', '/nace-import', '/ui-referans'];

const PANEL_ROOT: Record<string, string> = {
  admin: '/',
  osgb_admin: '/osgb-panel/genel-bakis',
  firma: '/firma/genel-bakis',
  uzman: '/uzman/genel-bakis',
  hekim: '/hekim/genel-bakis',
};

function roleMatchesPath(role: string, pathname: string): boolean {
  // OAuth callback: tüm rollerin ortak dönüş noktası. Role bazlı yönlendirmeye
  // takılırsa code/state query param'ları kaybolur ve bağlantı tamamlanamaz.
  if (pathname.startsWith('/email/oauth/callback')) return true;
  switch (role) {
    // admin: kendi paneli + OSGB Yönetim Paneli sayfalarına erişebilir (yönetim amaçlı).
    case 'admin': return ADMIN_PATHS.includes(pathname) || pathname.startsWith('/osgb-panel');
    case 'osgb_admin': return pathname.startsWith('/osgb-panel');
    case 'firma': return pathname.startsWith('/firma');
    case 'uzman': return pathname.startsWith('/uzman');
    case 'hekim': return pathname.startsWith('/hekim');
    default: return false;
  }
}

function osgbBlockedInfo(status: string): { title: string; description: string; icon: string } {
  switch (status) {
    case 'INACTIVE':
      return { title: 'OSGB pasif durumda', description: 'OSGB\u2019niz yönetici tarafından pasifleştirildi. Erişim açıldığında tekrar giriş yapabilirsiniz. Verileriniz korunur.', icon: 'ri-pause-circle-line' };
    case 'EXPIRED':
      return { title: 'Erişim süresi sona erdi', description: 'OSGB\u2019nizin erişim süresi doldu. Yöneticiniz süreyi uzattığında erişiminiz otomatik olarak geri gelir.', icon: 'ri-time-line' };
    case 'NOT_STARTED':
      return { title: 'Erişim henüz başlamadı', description: 'OSGB\u2019nizin erişim süresi henüz başlamadı. Lütfen başlangıç tarihinden sonra tekrar deneyin.', icon: 'ri-calendar-line' };
    case 'ARCHIVED':
      return { title: 'OSGB arşivlenmiş', description: 'OSGB\u2019niz arşivlendi. Verileriniz silinmez ancak erişim şu anda kapalı.', icon: 'ri-archive-line' };
    case 'FIRMA_HIZMET_SONA_ERDI':
      return { title: 'Firma hizmeti sona erdi', description: 'Firmanızın OSGB hizmeti sona erdirildiği için panele erişiminiz şu anda kapalı. Geçmiş kayıtlarınız korunur; hizmet yeniden başlatıldığında erişiminiz tekrar açılır.', icon: 'ri-stop-circle-line' };
    // Geçici (ağ / cold-start) hatalar artık kalıcı bir engel gibi gösterilmez.
    case 'NO_ACCESS':
      return { title: 'Erişim durumu doğrulanamadı', description: 'OSGB erişim durumunuz şu anda doğrulanamadı. Bu genellikle geçici bir bağlantı sorunudur. Lütfen yeniden deneyin; sorun sürerse yöneticinizle iletişime geçin.', icon: 'ri-wifi-off-line' };
    case 'UNAUTHENTICATED':
      return { title: 'Oturumunuz sona erdi', description: 'Güvenliğiniz için bu oturum kapatıldı. Devam etmek için lütfen yeniden giriş yapın.', icon: 'ri-lock-line' };
    case 'NO_OSGB':
      return { title: 'OSGB ataması bulunamadı', description: 'Hesabınıza bağlı bir OSGB tanımlı değil. Lütfen yöneticinizle iletişime geçin.', icon: 'ri-building-line' };
    case 'NO_PROFILE':
      return { title: 'Profil bulunamadı', description: 'Hesabınıza ait profil kaydı bulunamadı. Lütfen yöneticinizle iletişime geçin.', icon: 'ri-user-unfollow-line' };
    default:
      return { title: 'Erişim engellendi', description: 'OSGB erişimi şu anda kullanılamıyor. Lütfen yöneticinizle iletişime geçin.', icon: 'ri-forbid-line' };
  }
}

/**
 * Geçici bağlantı/erişim doğrulama hatası ekranı. Bu bir "erişim reddi" DEĞİLDİR;
 * yalnızca durumun şu an okunamadığını bildirir ve otomatik toparlanır. Kullanıcı
 * panelden ATILMAZ; bağlantı sağlanınca veya tekrar denenince panel kesintisiz açılır.
 */
function ReconnectCard({
  title,
  description,
  onRetry,
  onSignOut,
}: {
  title: string;
  description: string;
  onRetry: () => void;
  onSignOut: () => void;
}) {
  return (
    <div className="min-h-mobile-full flex items-center justify-center bg-background-50 px-4 py-10">
      <div className="w-full max-w-md">
        <div className="isg-card p-6 sm:p-8 text-center">
          <i className="ri-wifi-off-line text-4xl text-foreground-400" />
          <h1 className="text-lg font-semibold text-foreground-950 mt-4">{title}</h1>
          <p className="text-sm text-foreground-500 mt-2">{description}</p>
          <div className="mt-6 flex flex-col gap-2">
            <Button variant="primary" fullWidth leftIcon={<i className="ri-refresh-line" />} onClick={onRetry}>
              Yeniden Dene
            </Button>
            <Button variant="ghost" fullWidth leftIcon={<i className="ri-logout-box-r-line" />} onClick={onSignOut}>
              Çıkış Yap
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Oturum gerektiren rotalar için layout. Oturum yoksa /login'e yönlendirir;
 * role'e göre route erişimini sınırlar ve osgb_admin için OSGB merkezi erişim
 * kontrolünü (aktif / tarih aralığı / arşiv) her route değişiminde uygular.
 */
export default function ProtectedLayout() {
  const { session, profile, loading, signOut } = useAuth();
  const location = useLocation();

  const [accessStatus, setAccessStatus] = useState<string | null>(null);
  // accessStatus AUTHORITATIVE'dir (sunucudan geldi). accessTransient ise yalnızca
  // "durum şu an okunamadı" bilgisidir; doğrulanmış bir durumu ASLA ezmez.
  const [accessTransient, setAccessTransient] = useState(false);
  const [retryKey, setRetryKey] = useState(0);
  const [maintenanceActive, setMaintenanceActive] = useState<boolean | null>(null);
  const [maintenanceTransient, setMaintenanceTransient] = useState(false);
  const [maintenanceRetryKey, setMaintenanceRetryKey] = useState(0);

  // Uzman/Hekim için personel çalışma durumu kontrolü (işten çıkarma → anında panel kilidi).
  const [personelStatus, setPersonelStatus] = useState<'active' | 'terminated' | 'not_found' | null>(null);
  // personelStatus AUTHORITATIVE'dir (sunucu is_active döndü). personelTransient yalnızca
  // "durum şu an okunamadı" bilgisidir; doğrulanmış durumu ASLA ezmez.
  const [personelTransient, setPersonelTransient] = useState(false);
  const [personelRetryKey, setPersonelRetryKey] = useState(0);

  // Rol/kullanıcı PRİMİTİFLERİ: efektler yalnızca bu değerlere bağlanır. Böylece
  // kullanıcı adı/avatarı gibi ilgisiz profil güncellemeleri (profile nesnesi
  // referansı değişse bile) sunucu kontrollerini BOŞUNA yeniden tetiklemez.
  const profileRole = profile?.role ?? null;
  const userId = session?.user?.id ?? null;

  // Açılış kritik yolu: bakım ve OSGB erişim kontrolü, YETKİYİ sunucuda token'dan
  // türetir; client profilinin (rol) gelmesini BEKLEMEK zorunda değildir. Bu iki
  // bağımsız kontrol, oturum hazır olur olmaz profil çözümüyle PARALEL başlatılır.

  useEffect(() => {
    if (!profileRole || (profileRole !== 'uzman' && profileRole !== 'hekim')) {
      setPersonelStatus(null);
      setPersonelTransient(false);
      return;
    }
    let cancelled = false;
    // Geçici hata anında 30sn periyodik kontrolü beklemeden saniyeler içinde toparlan.
    const retry = createTransientRetry();
    const check = () => {
      withTimeout(fetchAuthPersonelStatus(), BOOTSTRAP_TIMEOUT_MS)
        .then((st) => {
          if (cancelled) return;
          // AUTHORITATIVE: sunucu kesin durumu döndürdü.
          retry.reset();
          setPersonelStatus(st);
          setPersonelTransient(false);
        })
        .catch(() => {
          // GEÇİCİ hata (ağ / cold-start / token-refresh yarışı). KRİTİK: 'terminated'
          // doğrulanmış kullanıcı, sonraki 30sn kontrolü geçici hata verince 'not_found'a
          // düşüp paneli YENİDEN AÇAMAZ (fail-safe). Doğrulanmış durum korunur; yalnızca
          // hiç doğrulanmış durum yoksa "bağlantı kuruluyor" gösterilir.
          if (cancelled) return;
          setPersonelTransient(true);
          // Hızlı toparlanma: hak bittiyse mevcut periyodik/online mekanizmalar devralır.
          retry.schedule(check);
        });
    };
    check();
    // İşten çıkarma başka sekmede/yöneticide yapıldığında kullanıcıyı anında düşürmek için
    // periyodik olarak yeniden doğrula (30sn). Rol değişiminde de yeniden çalışır.
    const id = window.setInterval(() => {
      // Yalnızca sekme görünürken doğrula (arka planda gereksiz istek yok).
      if (document.visibilityState === 'visible') check();
    }, 30000);
    return () => {
      cancelled = true;
      retry.cancel();
      window.clearInterval(id);
    };
  }, [profileRole, personelRetryKey]);

  useEffect(() => {
    if (!userId) {
      setMaintenanceActive(null);
      setMaintenanceTransient(false);
      return;
    }
    // Admin için bakım kontrolü gerekmez (render'da da gating yoktur).
    if (profileRole === 'admin') {
      setMaintenanceActive(null);
      setMaintenanceTransient(false);
      return;
    }
    let cancelled = false;
    // Geçici hata anında 60sn periyodik kontrolü beklemeden saniyeler içinde toparlan.
    const retry = createTransientRetry();

    const run = async () => {
      try {
        const active = await withTimeout(fetchMaintenanceActive(), BOOTSTRAP_TIMEOUT_MS);
        if (cancelled) return;
        // AUTHORITATIVE: sunucu kesin cevap verdi.
        retry.reset();
        setMaintenanceActive(active);
        setMaintenanceTransient(false);
      } catch {
        // Geçici (ağ / edge cold-start) hata: doğrulanmış bir değer varsa KORU,
        // kullanıcıyı çalışırken panelden düşürme. Yalnızca hiç değer yoksa
        // "bağlantı kuruluyor" durumuna geçilir (erişim reddi DEĞİL).
        if (cancelled) return;
        setMaintenanceTransient(true);
        // Hızlı toparlanma: hak bittiyse mevcut periyodik/online mekanizmalar devralır.
        retry.schedule(run);
      }
    };

    // Oturum hazır olur olmaz ilk çekimi başlat (profil/rol beklemeden). Böylece
    // bakım kontrolü, oturum+profil yüklemesiyle PARALEL yürür ve panel, auth
    // spinner'ı biter bitmez ek bakım spinner'ı beklemeden açılır.
    // KRİTİK (kanıtlanan hata): İstek, deps (userId/profileRole/retryKey) her
    // değiştiğinde YENİDEN başlatılır. Önceki çalıştırmanın temizliği `cancelled`
    // yapar ve yalnızca O isteğin sonucu yok sayılır. Eski koddaki "başladı mı"
    // ref kilidi yüzünden, profil/rol netleşince iptal edilen bekleyen istek
    // YENİDEN başlatılmıyordu → maintenanceActive null kalıp ekranda spinner
    // takılıyordu (sanki sonsuz yükleme). Artık her değişimde taze istek başlar.
    void run();

    // Bakım durumu route değişiminde yeniden tam sayfa spinner göstermemek için
    // arka planda periyodik olarak tazelenir (60sn). Sekme arka planda iken ağ
    // isteği askıya alınıp geçici hata üretebileceği için kontrol yalnızca sekme
    // görünürken çalışır.
    const id = window.setInterval(() => {
      if (document.visibilityState === 'visible') void run();
    }, 60000);
    // Ağ geri geldiğinde anında yeniden doğrula (transient durumdan hızlı çıkış).
    const onOnline = () => { void run(); };
    window.addEventListener('online', onOnline);
    return () => {
      cancelled = true;
      retry.cancel();
      window.clearInterval(id);
      window.removeEventListener('online', onOnline);
    };
  }, [userId, profileRole, maintenanceRetryKey]);

  useEffect(() => {
    if (!userId) {
      setAccessStatus(null);
      setAccessTransient(false);
      return;
    }
    // Admin için OSGB erişim kontrolü gerekmez (render'da da gating yoktur).
    if (profileRole === 'admin') {
      setAccessStatus(null);
      setAccessTransient(false);
      return;
    }
    let cancelled = false;
    // Geçici hata anında 60sn periyodik kontrolü beklemeden saniyeler içinde toparlan.
    const retry = createTransientRetry();

    const run = async () => {
      try {
        const res = await fetchOsgbAccess();
        if (cancelled) return;
        // AUTHORITATIVE: sunucu bir erişim durumu döndürdü (OK / INACTIVE / EXPIRED ...).
        retry.reset();
        setAccessStatus(res.status);
        setAccessTransient(false);
      } catch {
        // Geçici hata (ağ / edge cold-start / token-refresh yarışı).
        // KRİTİK: Bu "erişim reddedildi" DEĞİLDİR. Doğrulanmış bir accessStatus
        // varsa onu KORU; kullanıcı çalışırken panelden DÜŞÜRÜLMEZ. Yalnızca hiç
        // doğrulanmış durum yoksa (ilk yükleme) "bağlantı kuruluyor" gösterilir.
        if (cancelled) return;
        setAccessTransient(true);
        // Hızlı toparlanma: hak bittiyse mevcut periyodik/online/token mekanizmaları devralır.
        retry.schedule(run);
      }
    };

    // Oturum hazır olur olmaz ilk erişim kontrolünü başlat (profil/rol beklemeden).
    // osgb-status, yetkiyi SUNUCUDA token'dan türetir; client rolüne bağlı değildir.
    // Böylece erişim kontrolü profil çözümüyle PARALEL yürür.
    // KRİTİK (kanıtlanan hata): Yukarıdaki bakım kontrolüyle aynı nedenle, iptal
    // edilen bir osgb-status isteği ref kilidi yüzünden yeniden başlatılmıyor ve
    // accessStatus null kalıp spinner takılıyordu. Artık her deps değişiminde
    // taze istek başlar.
    void run();

    // Periyodik tazeleme (60sn). Yalnızca sekme görünürken çalışır; geçici hata
    // durumunda AUTHORITATIVE durumu ezmez, ağ gelince kendiliğinden toparlanır.
    const id = window.setInterval(() => {
      if (document.visibilityState === 'visible') void run();
    }, 60000);
    // Ağ geri geldiğinde anında yeniden doğrula.
    const onOnline = () => { void run(); };
    window.addEventListener('online', onOnline);
    // Token yenilendiğinde (refresh yarışından sonra) erişimi hızla yeniden doğrula.
    // Callback SENKRON dönmeli: yalnızca run() tetiklenir, beklenmez.
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'TOKEN_REFRESHED' || event === 'SIGNED_IN') void run();
    });
    return () => {
      cancelled = true;
      retry.cancel();
      window.clearInterval(id);
      window.removeEventListener('online', onOnline);
      sub.subscription.unsubscribe();
    };
  }, [userId, profileRole, retryKey]);

  if (loading) {
    return (
      <div className="min-h-mobile-full flex items-center justify-center bg-background-50">
        <span className="inline-block w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" aria-hidden="true" />
      </div>
    );
  }

  if (!session) {
    // Oturum kendiliğinden düştüyse nedeni (güvenlik / süre aşımı) giriş ekranına taşınır.
    // Böylece kullanıcı boş bir giriş ekranıyla değil, ne olduğunu anlatan bir mesajla karşılaşır.
    const notice = consumeSessionEndNotice();
    return <Navigate to={notice ? `/login?reason=${notice}` : '/login'} replace />;
  }

  if (!profile) {
    return <Navigate to="/login" replace />;
  }

  // Rol bazlı panel erişimi: her rol yalnızca kendi panel köküne girebilir.
  // (admin → admin, osgb_admin → OSGB paneli, firma/uzman/hekim → kendi paneli)
  if (profile.role && !roleMatchesPath(profile.role, location.pathname)) {
    return <Navigate to={PANEL_ROOT[profile.role] || '/login'} replace />;
  }

  // Uzman/hekim: personel çalışma durumu backend'den belirlenene kadar panel render edilmez
  // (fail-closed — işten çıkarılan kullanıcı paneli bir an bile görmemelidir).
  if ((profile.role === 'uzman' || profile.role === 'hekim') && personelStatus === null) {
    // Hiç doğrulanmış durum yok + geçici hata: "erişim reddi" DEĞİL, otomatik toparlanan
    // bağlantı ekranı. Böylece geçici ağ hatası kullanıcıyı ne düşürür ne de sonsuz spinner'da bırakır.
    if (personelTransient) {
      return (
        <ReconnectCard
          title="Bağlantı kuruluyor"
          description="Çalışma durumunuz geçici olarak doğrulanamadı. Kısa süreli bir bağlantı sorunu olabilir; bağlantı sağlanınca panel otomatik açılacak."
          onRetry={() => setPersonelRetryKey((k) => k + 1)}
          onSignOut={() => signOut()}
        />
      );
    }
    return (
      <div className="min-h-mobile-full flex items-center justify-center bg-background-50">
        <span className="inline-block w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" aria-hidden="true" />
      </div>
    );
  }

  // İşten çıkarılmış uzman/hekim: panel erişimi backend verisiyle kapatılır.
  // Yalnızca frontend'de buton gizlemek DEĞİL; personel çalışma durumu doğrulanır.
  if ((profile.role === 'uzman' || profile.role === 'hekim') && personelStatus === 'terminated') {
    return (
      <div className="min-h-mobile-full flex items-center justify-center bg-background-50 px-4 py-10">
        <div className="w-full max-w-md">
          <div className="isg-card p-6 sm:p-8 text-center">
            <i className="ri-user-unfollow-line text-4xl text-foreground-400" />
            <h1 className="text-lg font-semibold text-foreground-950 mt-4">Erişim Engellendi</h1>
            <p className="text-sm text-foreground-500 mt-2">
              Çalışma durumunuz sona erdiği için panele erişiminiz bulunmamaktadır. Geçmiş kayıtlarınız sistemde korunur; çalışma durumunuz yeniden aktifleştirildiğinde erişiminiz geri gelir.
            </p>
            <div className="mt-6">
              <Button variant="primary" fullWidth leftIcon={<i className="ri-logout-box-r-line" />} onClick={() => signOut()}>
                Çıkış Yap
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Merkezi bakım modu: admin hariç tüm paneller sunucu kararına göre kapatılır.
  if (profile.role !== 'admin') {
    if (maintenanceActive === null) {
      // Hiç doğrulanmış değer yoksa: geçici hatada "erişim reddi" DEĞİL, otomatik
      // toparlanan bir bağlantı ekranı gösterilir.
      if (maintenanceTransient) {
        return (
          <ReconnectCard
            title="Bağlantı kuruluyor"
            description="Sistem durumu geçici olarak doğrulanamadı. Kısa süreli bir bağlantı sorunu olabilir; bağlantı sağlanınca panel otomatik açılacak."
            onRetry={() => setMaintenanceRetryKey((k) => k + 1)}
            onSignOut={() => signOut()}
          />
        );
      }
      return (
        <div className="min-h-mobile-full flex items-center justify-center bg-background-50">
          <span className="inline-block w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" aria-hidden="true" />
        </div>
      );
    }
    if (maintenanceActive) {
      return (
        <div className="min-h-mobile-full flex items-center justify-center bg-background-50 px-4 py-10">
          <div className="w-full max-w-md">
            <div className="isg-card p-6 sm:p-8 text-center">
              <i className="ri-tools-line text-4xl text-foreground-400" />
              <h1 className="text-lg font-semibold text-foreground-950 mt-4">Sistem Bakımda</h1>
              <p className="text-sm text-foreground-500 mt-2">Sistem bakım nedeniyle geçici olarak kullanılamıyor. Lütfen daha sonra tekrar deneyin.</p>
              <div className="mt-6">
                <Button variant="primary" fullWidth leftIcon={<i className="ri-logout-box-r-line" />} onClick={() => signOut()}>
                  Çıkış Yap
                </Button>
              </div>
            </div>
          </div>
        </div>
      );
    }
  }

  // Admin hariç tüm panel rolleri → merkezi OSGB erişim kontrolü.
  if (profile.role !== 'admin') {
    if (accessStatus === null) {
      // Doğrulanmış bir durum yok ama geçici bir hata oluştu: "erişim reddi" DEĞİL,
      // otomatik toparlanan bir bağlantı ekranı gösterilir.
      if (accessTransient) {
        return (
          <ReconnectCard
            title="Bağlantı kuruluyor"
            description="Erişim durumunuz geçici olarak doğrulanamadı. Bu genellikle kısa süreli bir bağlantı sorunudur; bağlantı sağlanınca panel otomatik açılacak."
            onRetry={() => setRetryKey((k) => k + 1)}
            onSignOut={() => signOut()}
          />
        );
      }
      return (
        <div className="min-h-mobile-full flex items-center justify-center bg-background-50">
          <span className="inline-block w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full animate-spin" aria-hidden="true" />
        </div>
      );
    }
    if (accessStatus !== 'OK') {
      const info = osgbBlockedInfo(accessStatus);
      return (
        <div className="min-h-mobile-full flex items-center justify-center bg-background-50 px-4 py-10">
          <div className="w-full max-w-md">
            <div className="isg-card p-6 sm:p-8 text-center">
              <i className={`${info.icon} text-4xl text-foreground-400`} />
              <h1 className="text-lg font-semibold text-foreground-950 mt-4">{info.title}</h1>
              <p className="text-sm text-foreground-500 mt-2">{info.description}</p>
              <div className="mt-6 flex flex-col gap-2">
                <Button variant="primary" fullWidth leftIcon={<i className="ri-logout-box-r-line" />} onClick={() => signOut()}>
                  Çıkış Yap
                </Button>
                <Button variant="ghost" fullWidth onClick={() => setRetryKey((k) => k + 1)}>
                  Yeniden Dene
                </Button>
              </div>
            </div>
          </div>
        </div>
      );
    }
  }

  return (
    <Shell>
      <SessionPolicyGuard />
      <Outlet />
    </Shell>
  );
}