/**
 * İSGDenetim — PANEL NAVIGATION CONFIG (TEK KAYNAK)
 *
 * 5 panelin (Admin, OSGB, Firma, Uzman, Hekim) sidebar/bottom-nav menüleri
 * TEK config kaynağından tüketilir. Panel menüsü "config-driven"dır —
 * Sidebar ve BottomNav ayrı ayrı menü listesi YAZMAZ.
 *
 * Panel ayrımı URL köküne göre yapılır (auth yok, ileride Supabase Auth+RLS
 * ile bağlanacak temiz mimari):
 *   /osgb-panel/* → OSGB Yönetim Paneli
 *   /firma/*      → Firma Paneli
 *   /uzman/*      → Uzman Paneli
 *   /hekim/*      → Hekim Paneli
 *   (diğer tümü)  → Admin Paneli
 */

export type PanelKey = 'admin' | 'osgb' | 'firma' | 'uzman' | 'hekim';

export interface PanelNavItem {
  label: string;
  icon: string;
  path: string;
  badge?: number;
  badgeColor?: string;
}

export const PANEL_NAV_CONFIG: Record<PanelKey, PanelNavItem[]> = {
  admin: [
    { label: 'Genel Bakış', icon: 'ri-home-4-line', path: '/' },
    { label: 'OSGB Yönetimi', icon: 'ri-building-4-line', path: '/osgb' },
    { label: 'Destek Talepleri', icon: 'ri-customer-service-line', path: '/destek' },
    { label: 'Duyurular', icon: 'ri-megaphone-line', path: '/duyurular' },
    { label: 'Meslek & Evrak Yönetimi', icon: 'ri-briefcase-4-line', path: '/meslek-evrak-yonetimi' },
    { label: 'Sistem Logları', icon: 'ri-file-list-3-line', path: '/logs' },
    { label: 'Ayarlar', icon: 'ri-settings-3-line', path: '/ayarlar' },
  ],
  osgb: [
    { label: 'Genel Bakış', icon: 'ri-home-4-line', path: '/osgb-panel/genel-bakis' },
    { label: 'Teklifler', icon: 'ri-file-list-3-line', path: '/osgb-panel/teklifler' },
    { label: 'Firmalar', icon: 'ri-building-2-line', path: '/osgb-panel/firmalar' },
    { label: 'Personeller', icon: 'ri-team-line', path: '/osgb-panel/personeller' },
    { label: 'Atamalar', icon: 'ri-user-add-line', path: '/osgb-panel/atamalar' },
    { label: 'Ziyaret Planlama', icon: 'ri-calendar-check-line', path: '/osgb-panel/ziyaret-planlama' },
    { label: 'İBYS Bildirim Merkezi', icon: 'ri-send-plane-line', path: '/osgb-panel/ibys-bildirim' },
    { label: 'Envanter', icon: 'ri-box-3-line', path: '/osgb-panel/envanter' },
    { label: 'Mesajlaşma', icon: 'ri-chat-3-line', path: '/osgb-panel/mesajlasma' },
    { label: 'Ayarlar', icon: 'ri-settings-3-line', path: '/osgb-panel/ayarlar' },
  ],
  firma: [
    { label: 'Genel Bakış', icon: 'ri-home-4-line', path: '/firma/genel-bakis' },
    { label: 'Personeller', icon: 'ri-team-line', path: '/firma/personeller' },
    { label: 'Evraklar', icon: 'ri-file-text-line', path: '/firma/evraklar' },
    { label: 'Saha Denetimleri', icon: 'ri-search-eye-line', path: '/firma/saha-denetimleri' },
    { label: 'Ekipmanlar', icon: 'ri-tools-line', path: '/firma/ekipmanlar' },
    { label: 'Tutanaklar', icon: 'ri-file-list-3-line', path: '/firma/tutanaklar' },
    { label: 'Mesajlaşma', icon: 'ri-chat-3-line', path: '/firma/mesajlasma' },
    { label: 'Ayarlar', icon: 'ri-settings-3-line', path: '/firma/ayarlar' },
  ],
  uzman: [
    { label: 'Genel Bakış', icon: 'ri-home-4-line', path: '/uzman/genel-bakis' },
    { label: 'Firmalarım', icon: 'ri-building-2-line', path: '/uzman/firmalarim' },
    { label: 'Ziyaretler', icon: 'ri-map-pin-line', path: '/uzman/ziyaretler' },
    { label: 'Personeller', icon: 'ri-team-line', path: '/uzman/personeller' },
    { label: 'Evraklar', icon: 'ri-file-text-line', path: '/uzman/evraklar' },
    { label: 'Tutanaklar', icon: 'ri-file-list-3-line', path: '/uzman/tutanaklar' },
    { label: 'Ekipmanlar', icon: 'ri-tools-line', path: '/uzman/ekipmanlar' },
    { label: 'Saha Denetimleri', icon: 'ri-search-eye-line', path: '/uzman/saha-denetimleri' },
    { label: 'Zimmet', icon: 'ri-archive-2-line', path: '/uzman/zimmet' },
    { label: 'Mesajlaşma', icon: 'ri-chat-3-line', path: '/uzman/mesajlasma' },
    { label: 'Ayarlar', icon: 'ri-settings-3-line', path: '/uzman/ayarlar' },
  ],
  hekim: [
    { label: 'Genel Bakış', icon: 'ri-home-4-line', path: '/hekim/genel-bakis' },
    { label: 'Firmalarım', icon: 'ri-building-2-line', path: '/hekim/firmalarim' },
    { label: 'Ziyaretler', icon: 'ri-map-pin-line', path: '/hekim/ziyaretler' },
    { label: 'Personeller', icon: 'ri-team-line', path: '/hekim/personeller' },
    { label: 'Muayeneler', icon: 'ri-stethoscope-line', path: '/hekim/muayeneler' },
    { label: 'Tetkik ve Tahliller', icon: 'ri-test-tube-line', path: '/hekim/tetkik-tahliller' },
    { label: 'Sağlık Evrakları', icon: 'ri-health-book-line', path: '/hekim/saglik-evraklari' },
    { label: 'Muayene Planlama', icon: 'ri-calendar-check-line', path: '/hekim/muayene-planlama' },
    { label: 'Tutanaklar', icon: 'ri-file-list-3-line', path: '/hekim/tutanaklar' },
    { label: 'Zimmet', icon: 'ri-archive-2-line', path: '/hekim/zimmet' },
    { label: 'Mesajlaşma', icon: 'ri-chat-3-line', path: '/hekim/mesajlasma' },
    { label: 'Ayarlar', icon: 'ri-settings-3-line', path: '/hekim/ayarlar' },
  ],
};

export const PANEL_ROLE_LABEL: Record<PanelKey, string> = {
  admin: 'Sistem Yöneticisi',
  osgb: 'OSGB Yöneticisi',
  firma: 'Firma Yöneticisi',
  uzman: 'Uzman',
  hekim: 'Hekim',
};

/** URL köküne göre aktif paneli belirler (auth yok — route bazlı ayrım). */
export function getPanelFromPath(pathname: string): PanelKey {
  if (pathname.startsWith('/osgb-panel')) return 'osgb';
  if (pathname.startsWith('/firma')) return 'firma';
  if (pathname.startsWith('/uzman')) return 'uzman';
  if (pathname.startsWith('/hekim')) return 'hekim';
  return 'admin';
}