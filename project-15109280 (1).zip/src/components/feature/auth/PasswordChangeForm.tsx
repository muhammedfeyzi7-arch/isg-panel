import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import Alert from '@/components/ui/Alert';
import { useAuth } from '@/context/AuthContext';
import { useToastActions } from '@/hooks/useToast';
import { logPasswordChanged } from '@/lib/settingsService';
import { friendlyAuthError, friendlyPasswordErrorCode, rawAuthDetail } from '@/lib/authErrorMessages';
import { validatePasswordPolicy, PASSWORD_POLICY_HINT } from '@/lib/passwordPolicy';
import { isReauthRequired, requestReauthNonce } from '@/lib/passwordReauth';
import { EdgeDogrulamaYokError, SifreApiError, sifreKoduGonder, sifreKoduIleDegistir } from '@/lib/sifreDogrulama';

interface PasswordChangeFormProps {
  /** Başarılı değişimden sonra çağrılır (modal kapatma vb.). */
  onSuccess?: () => void;
  /** Gönder butonunun metni. */
  submitLabel?: string;
}

type FormErrors = { mevcut?: string; yeni?: string; tekrar?: string; kod?: string };

/** Alanlardan okunan gerçek değerler (tarayıcı autofill'i için DOM'dan da okunur). */
interface FormValues {
  mevcut: string;
  yeni: string;
  tekrar: string;
  kod: string;
}

interface FormNotice {
  tone: 'warning' | 'danger' | 'info';
  text: string;
  /** Tanınmayan (teknik) hatalarda sunucudan gelen ham mesaj. */
  detail?: string;
  /** Başlık verilmezse tona göre varsayılan başlık kullanılır. */
  title?: string;
}

type KodKaynagi = 'sunucu' | 'gotrue' | null;

/**
 * Şifre değiştirme formu — TEK KAYNAK.
 *
 * AKIŞ (her seferinde iki adımlı, oturum yaşından bağımsız):
 *
 *   1. ADIM — "Doğrulama Kodu Gönder"
 *        · Mevcut şifre sunucuda doğrulanır (bilgi amaçlı; engelleyici değil)
 *        · 6 haneli tek kullanımlık kod üretilir, sadece SHA-256 özeti saklanır
 *        · KOD, PROJENİN KURUMSAL E-POSTA TASARIMIYLA kullanıcıya gönderilir
 *        · Şifre HENÜZ DEĞİŞMEZ
 *
 *   2. ADIM — Kodu gir → "Doğrula ve Güncelle"
 *        · Kod doğrulanır (10 dk geçerli, tek kullanımlık, 5 deneme)
 *        · Mevcut şifre + son 3 şifre kontrolü SUNUCUDA yapılır
 *        · Şifre sunucuda güncellenir
 *        · Diğer cihazlardaki oturumlar iptal edilir
 *        · Güvenlik bilgilendirme e-postası gönderilir
 *
 * Geri dönüş (fallback): Edge Function henüz yayınlanmamışsa eski GoTrue
 * `reauthenticate` akışı denenir; o da yoksa kullanıcı kilitlenmez.
 */
export default function PasswordChangeForm({ onSuccess, submitLabel = 'Doğrulama Kodu Gönder' }: PasswordChangeFormProps) {
  const { profile, changePasswordWithNonce, signOutEverywhere } = useAuth();
  const { addToast } = useToastActions();
  const navigate = useNavigate();

  const [mevcut, setMevcut] = useState('');
  const [yeni, setYeni] = useState('');
  const [tekrar, setTekrar] = useState('');
  const [kod, setKod] = useState('');
  const [kodAdimi, setKodAdimi] = useState(false);
  const [kodKaynagi, setKodKaynagi] = useState<KodKaynagi>(null);
  const [kodGonderiliyor, setKodGonderiliyor] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [notice, setNotice] = useState<FormNotice | null>(null);
  const [loading, setLoading] = useState(false);

  const sifrelerEslesiyor = tekrar.length > 0 && yeni.length > 0 && tekrar === yeni;

  const bitir = (bildirimGonderildi: boolean) => {
    // Denetim kaydı ASLA ana akışı bloklamaz.
    void logPasswordChanged().catch(() => {});
    setMevcut('');
    setYeni('');
    setTekrar('');
    setKod('');
    setKodAdimi(false);
    setKodKaynagi(null);
    setErrors({});
    setNotice(null);
    addToast({
      title: 'Şifreniz güncellendi',
      message: bildirimGonderildi
        ? 'Güvenliğiniz için diğer cihazlardaki oturumlarınız kapatıldı. Bilgilendirme e-postası gönderildi.'
        : 'Güvenliğiniz için diğer cihazlardaki oturumlarınız kapatıldı.',
      type: 'success',
    });
    onSuccess?.();
  };

  /** 1. adım: kod gönder. Başarılıysa kod alanı açılır. */
  const kodGonder = async (currentPassword: string, sessiz = false): Promise<boolean> => {
    setKodGonderiliyor(true);
    try {
      const sonuc = await sifreKoduGonder(currentPassword);
      setKodAdimi(true);
      setKodKaynagi('sunucu');
      setKod('');
      setErrors({});
      if (sonuc.currentPasswordVerified) {
        setNotice(null);
      } else {
        // Sunucu mevcut şifreyi doğrulayamadı ama kod gönderildi. Bu bir ENGEL değil:
        // kullanıcı kodu girerek işlemi tamamlayabilir. Sadece bilgilendirilir.
        setNotice({
          tone: 'warning',
          title: 'Mevcut şifre doğrulanamadı',
          text: 'Girdiğiniz mevcut şifre sunucu tarafında doğrulanamadı (geçici bir yoğunluk olabilir). Aşağıya e-posta adresinize gelen kodu girerek işlemi tamamlayabilirsiniz.',
        });
      }
      if (!sessiz) {
        addToast({
          title: 'Doğrulama kodu gönderildi',
          message: `${profile?.email ?? 'E-posta adresinize'} gelen 6 haneli kodu girerek işlemi tamamlayın.`,
          type: 'info',
        });
      }
      return true;
    } catch (err) {
      if (err instanceof EdgeDogrulamaYokError) {
        // Edge Function yayında değil → eski GoTrue akışına geri düş.
        try {
          await requestReauthNonce();
          setKodAdimi(true);
          setKodKaynagi('gotrue');
          setKod('');
          setErrors({});
          setNotice(null);
          if (!sessiz) {
            addToast({
              title: 'Doğrulama kodu gönderildi',
              message: `${profile?.email ?? 'E-posta adresinize'} gelen kodu girerek işlemi tamamlayın.`,
              type: 'info',
            });
          }
          return true;
        } catch (e2) {
          const message = friendlyAuthError(e2, 'Doğrulama kodu gönderilemedi. Lütfen tekrar deneyin.');
          const detail = rawAuthDetail(e2);
          setNotice({ tone: 'danger', title: 'Doğrulama kodu gönderilemedi', text: message, detail: detail !== message ? detail : undefined });
          addToast({ title: 'Kod gönderilemedi', message, type: 'error' });
          return false;
        }
      }

      const message =
        err instanceof SifreApiError
          ? friendlyPasswordErrorCode(err.code, err.message)
          : friendlyAuthError(err, 'Doğrulama kodu gönderilemedi. Lütfen tekrar deneyin.');
      const detail = rawAuthDetail(err);
      setNotice({
        tone: 'danger',
        title: 'Doğrulama kodu gönderilemedi',
        text: message,
        detail: detail && detail !== message ? detail : undefined,
      });
      addToast({ title: 'Kod gönderilemedi', message, type: 'error' });
      return false;
    } finally {
      setKodGonderiliyor(false);
    }
  };

  /** Değerleri doğrular. Yalnızca GERÇEK hata mesajları nesneye eklenir. */
  const dogrula = (values: FormValues): boolean => {
    const e: FormErrors = {};

    if (!values.mevcut) e.mevcut = 'Mevcut şifre zorunludur.';

    if (!values.yeni) {
      e.yeni = 'Yeni şifre zorunludur.';
    } else {
      const politikaMesaji = validatePasswordPolicy(values.yeni, { email: profile?.email ?? null });
      if (politikaMesaji) {
        e.yeni = politikaMesaji;
      } else if (values.mevcut && values.yeni === values.mevcut) {
        e.yeni = 'Yeni şifreniz mevcut şifrenizle aynı olamaz. Lütfen farklı bir şifre belirleyin.';
      }
    }

    if (!values.tekrar) {
      e.tekrar = 'Yeni şifreyi tekrar girin.';
    } else if (values.tekrar !== values.yeni) {
      e.tekrar = 'Şifreler birbiriyle eşleşmiyor.';
    }

    if (kodAdimi) {
      const girilen = values.kod.trim();
      if (!girilen) e.kod = 'E-postanıza gelen doğrulama kodunu girin.';
      else if (girilen.replace(/\D/g, '').length < 4) e.kod = 'Doğrulama kodu eksik görünüyor. Kodu eksiksiz girin.';
    }

    setErrors(e);

    const ilkHata = e.mevcut || e.yeni || e.tekrar || e.kod;
    if (ilkHata) {
      setNotice({ tone: 'warning', text: ilkHata });
      return false;
    }

    setNotice(null);
    return true;
  };

  const handleSubmit = async (event?: FormEvent<HTMLFormElement>) => {
    event?.preventDefault();
    if (loading || kodGonderiliyor) return;

    // Tarayıcı otomatik doldurması React state'i güncellemeyebilir; değerler
    // FORM elemanından okunur (state ile birleştirilir).
    const formData = event ? new FormData(event.currentTarget) : null;
    const oku = (name: string, fallback: string): string => {
      if (!formData) return fallback;
      const raw = formData.get(name);
      return typeof raw === 'string' ? raw : fallback;
    };

    const values: FormValues = {
      mevcut: oku('currentPassword', mevcut),
      yeni: oku('newPassword', yeni),
      tekrar: oku('confirmPassword', tekrar),
      kod: oku('verificationCode', kod),
    };

    setMevcut(values.mevcut);
    setYeni(values.yeni);
    setTekrar(values.tekrar);
    setKod(values.kod);

    if (!dogrula(values)) return;

    // ── 1. ADIM: kod isteniyor ──
    if (!kodAdimi) {
      await kodGonder(values.mevcut);
      return;
    }

    // ── 2. ADIM: kod ile şifre değişimi ──
    setLoading(true);
    try {
      if (kodKaynagi === 'gotrue') {
        // Eski akış (Edge Function yayında değilken).
        await changePasswordWithNonce(values.yeni, values.kod);
        bitir(false);
        return;
      }

      const sonuc = await sifreKoduIleDegistir(values.kod, values.yeni, values.mevcut);
      bitir(sonuc.notificationSent);
      return;
    } catch (err) {
      if (err instanceof EdgeDogrulamaYokError) {
        // Yayın sırasında uç nokta kaybolduysa kullanıcıyı kilitleme.
        setNotice({
          tone: 'danger',
          title: 'Doğrulama servisine ulaşılamadı',
          text: 'Şifre değiştirme servisi şu anda yanıt vermiyor. Lütfen birkaç dakika sonra tekrar deneyin.',
        });
        return;
      }

      if (err instanceof SifreApiError) {
        const message = friendlyPasswordErrorCode(err.code, err.message);
        const detail = rawAuthDetail(err);

        // Kod hatalarında kod alanını temizle, kullanıcı yeniden girsin.
        if (err.code === 'CODE_INVALID' || err.code === 'CODE_EXPIRED' || err.code === 'CODE_ATTEMPTS' || err.code === 'CODE_NOT_FOUND') {
          setKod('');
          setErrors((p) => ({ ...p, kod: message }));
          if (err.code === 'CODE_ATTEMPTS' || err.code === 'CODE_EXPIRED' || err.code === 'CODE_NOT_FOUND') {
            setKodAdimi(false);
            setKodKaynagi(null);
          }
        }
        if (err.code === 'CURRENT_PASSWORD_INVALID') {
          setErrors((p) => ({ ...p, mevcut: message }));
        }
        if (err.code === 'PASSWORD_REUSED' || err.code === 'PASSWORD_SAME' || err.code === 'PASSWORD_TOO_SHORT') {
          setErrors((p) => ({ ...p, yeni: message }));
        }

        setNotice({
          tone: 'danger',
          title: 'Şifre değiştirilemedi',
          text: message,
          detail: detail && detail !== message ? detail : undefined,
        });
        addToast({ title: 'Şifre değiştirilemedi', message, type: 'error' });
        return;
      }

      if (isReauthRequired(err)) {
        const ok = await kodGonder(values.mevcut, true);
        if (!ok) {
          const message = friendlyAuthError(err, 'Şifre güncellenemedi. Lütfen tekrar deneyin.');
          setNotice({ tone: 'danger', text: message });
        }
        return;
      }

      const message = friendlyAuthError(err, 'Şifre güncellenemedi. Lütfen bilgilerinizi kontrol edip tekrar deneyin.');
      const detail = rawAuthDetail(err);
      setNotice({ tone: 'danger', title: 'Şifre değiştirilemedi', text: message, detail: detail && detail !== message ? detail : undefined });
      addToast({ title: 'Şifre değiştirilemedi', message, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form className="space-y-3 max-w-md" onSubmit={handleSubmit} noValidate data-readdy-password-form>
      {notice && (
        <Alert
          variant={notice.tone === 'danger' ? 'danger' : notice.tone === 'info' ? 'info' : 'warning'}
          title={notice.title ?? (notice.tone === 'danger' ? 'Şifre değiştirilemedi' : 'Eksik / hatalı bilgi')}
        >
          <span className="block">{notice.text}</span>
          {notice.detail && (
            <span className="mt-1 block text-[11px] leading-snug text-foreground-600 break-words">
              Teknik ayrıntı: {notice.detail}
            </span>
          )}
        </Alert>
      )}

      <Input
        label="Mevcut Şifre"
        type="password"
        name="currentPassword"
        autoComplete="current-password"
        required
        value={mevcut}
        onChange={(e) => { setMevcut(e.target.value); setErrors((p) => ({ ...p, mevcut: '' })); }}
        error={errors.mevcut}
        leftIcon={<i className="ri-key-2-line" />}
        disabled={loading || kodGonderiliyor}
      />
      <Input
        label="Yeni Şifre"
        type="password"
        name="newPassword"
        autoComplete="new-password"
        required
        value={yeni}
        onChange={(e) => { setYeni(e.target.value); setErrors((p) => ({ ...p, yeni: '', tekrar: '' })); }}
        error={errors.yeni}
        helpText={PASSWORD_POLICY_HINT}
        leftIcon={<i className="ri-lock-line" />}
        disabled={loading || kodGonderiliyor}
      />
      <Input
        label="Yeni Şifre (Tekrar)"
        type="password"
        name="confirmPassword"
        autoComplete="new-password"
        required
        value={tekrar}
        onChange={(e) => { setTekrar(e.target.value); setErrors((p) => ({ ...p, tekrar: '' })); }}
        error={errors.tekrar}
        isSuccess={sifrelerEslesiyor && !errors.tekrar}
        helpText={sifrelerEslesiyor ? 'Şifreler eşleşiyor.' : undefined}
        leftIcon={<i className="ri-lock-line" />}
        disabled={loading || kodGonderiliyor}
      />

      {kodAdimi && (
        <div className="rounded-lg border border-accent-300 bg-accent-100/70 p-3 space-y-2">
          <p className="flex items-start gap-1.5 text-xs font-medium text-accent-900">
            <span className="w-4 h-4 flex items-center justify-center shrink-0">
              <i className="ri-mail-check-line" />
            </span>
            E-posta doğrulama adımı
          </p>
          <p className="text-xs text-foreground-700">
            {profile?.email ?? 'E-posta adresinize'} 6 haneli bir doğrulama kodu gönderdik. Kod 10 dakika geçerlidir;
            kodu girerek şifre değişimini tamamlayın.
          </p>
          <Input
            label="Doğrulama Kodu"
            name="verificationCode"
            required
            value={kod}
            onChange={(e) => { setKod(e.target.value); setErrors((p) => ({ ...p, kod: '' })); }}
            error={errors.kod}
            inputMode="numeric"
            autoComplete="one-time-code"
            autoFocus
            maxLength={6}
            leftIcon={<i className="ri-shield-keyhole-line" />}
            disabled={loading || kodGonderiliyor}
          />
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => void kodGonder(mevcut, true)}
            isLoading={kodGonderiliyor}
            disabled={loading}
            leftIcon={<i className="ri-mail-send-line" />}
          >
            Kodu tekrar gönder
          </Button>
        </div>
      )}

      <div className="flex items-center justify-between gap-2 flex-wrap">
        <button
          type="button"
          onClick={() => {
            void signOutEverywhere().finally(() => navigate('/login?reason=all-devices', { replace: true }));
          }}
          disabled={loading}
          className="inline-flex items-center gap-1.5 text-xs text-foreground-600 hover:text-foreground-900 cursor-pointer disabled:opacity-60 whitespace-nowrap"
        >
          <span className="w-4 h-4 flex items-center justify-center">
            <i className="ri-logout-box-r-line" />
          </span>
          Tüm cihazlardan çıkış yap
        </button>
        <Button
          type="submit"
          variant="primary"
          size="sm"
          isLoading={loading || kodGonderiliyor}
          leftIcon={<i className={kodAdimi ? 'ri-shield-check-line' : 'ri-mail-send-line'} />}
        >
          {kodAdimi ? 'Doğrula ve Güncelle' : submitLabel}
        </Button>
      </div>
    </form>
  );
}