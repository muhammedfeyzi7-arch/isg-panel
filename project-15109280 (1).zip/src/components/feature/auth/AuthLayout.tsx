import type { ReactNode } from 'react';
import '@/components/feature/auth/auth.css';

interface AuthLayoutProps {
  children: ReactNode;
  /** true ise logo kartın ÜSTÜNDE (dışında) gösterilir — Yeni Şifre ekranı. */
  logoOutside?: boolean;
  /** logoOutside=true iken gösterilecek logo düğümü. */
  logo?: ReactNode;
}

/**
 * ORTAK AUTH İSKELETİ (tek kaynak).
 * Giriş / Şifremi Unuttum / Yeni Şifre ekranlarının TAMAMI bu iskeleti
 * kullanır → background, overlay, dekoratif ışıma ve ortalama davranışı
 * üç ekranda da birebir aynıdır. Global SharedUICore'a dokunmaz.
 */
export default function AuthLayout({ children, logoOutside, logo }: AuthLayoutProps) {
  return (
    <div className="isg-auth-root">
      <img
        className="isg-auth-bg"
        src="https://readdy.ai/api/search-image?query=Abstract%20dark%20navy%20charcoal%20premium%20SaaS%20background%20with%20a%20subtle%20red%20industrial%20safety%20helmet%20silhouette%20on%20the%20left%20edge%20and%20a%20faint%20geometric%20shield%20wireframe%2C%20deep%20shadows%2C%20low%20contrast%20moody%20atmosphere%2C%20elegant%20cinematic%20lighting%2C%20minimal%2C%20no%20text&width=1920&height=1080&seq=isg-auth-hero-01&orientation=landscape"
        alt=""
        aria-hidden="true"
        draggable={false}
      />
      <div className="isg-auth-overlay" aria-hidden="true" />
      <div className="isg-auth-glow isg-auth-glow--red" aria-hidden="true" />
      <div className="isg-auth-glow isg-auth-glow--blue" aria-hidden="true" />
      <main className="isg-auth-main">
        {logoOutside && <div className="isg-auth-outlogo">{logo}</div>}
        {children}
      </main>
    </div>
  );
}