import { useState, type InputHTMLAttributes } from 'react';
import AuthInput from './AuthInput';

interface PasswordInputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, 'type'> {
  label?: string;
  error?: string;
}

/** Şifre alanı — göz ikonu ile görünürlük değiştirici. */
export default function PasswordInput({ label, error, ...props }: PasswordInputProps) {
  const [visible, setVisible] = useState(false);

  return (
    <AuthInput
      {...props}
      label={label}
      error={error}
      type={visible ? 'text' : 'password'}
      icon={<i className="ri-lock-line" />}
      rightSlot={
        <button
          type="button"
          className="isg-auth-toggle"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? 'Şifreyi gizle' : 'Şifreyi göster'}
        >
          <i className={visible ? 'ri-eye-off-line' : 'ri-eye-line'} />
        </button>
      }
    />
  );
}