import { forwardRef, useId, type InputHTMLAttributes, type ReactNode } from 'react';

interface AuthInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  icon?: ReactNode;
  error?: string;
  rightSlot?: ReactNode;
}

/** Ortak auth input'u — koyu zemin, sol ikon, focus kırmızı halka. */
const AuthInput = forwardRef<HTMLInputElement, AuthInputProps>(function AuthInput(
  { label, icon, error, rightSlot, id, className = '', ...props },
  ref,
) {
  const generatedId = useId();
  const fieldId = id ?? generatedId;

  return (
    <div className="isg-auth-field">
      {label && (
        <label htmlFor={fieldId} className="isg-auth-field__label">
          {label}
        </label>
      )}
      <div className="isg-auth-input-wrap">
        {icon && <span className="isg-auth-input__icon" aria-hidden="true">{icon}</span>}
        <input
          ref={ref}
          id={fieldId}
          aria-invalid={error ? true : undefined}
          className={`isg-auth-input ${icon ? '' : 'isg-auth-input--no-left'} ${rightSlot ? 'isg-auth-input--has-right' : ''} ${error ? 'isg-auth-input--error' : ''} ${className}`}
          {...props}
        />
        {rightSlot && <span className="isg-auth-input__right">{rightSlot}</span>}
      </div>
      {error && (
        <p className="isg-auth-field__error">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}
    </div>
  );
});

export default AuthInput;