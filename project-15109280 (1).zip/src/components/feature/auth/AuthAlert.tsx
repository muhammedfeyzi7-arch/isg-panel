import type { ReactNode } from 'react';

type AuthAlertVariant = 'error' | 'success' | 'info';

interface AuthAlertProps {
  variant?: AuthAlertVariant;
  children: ReactNode;
  /** Varsayılan ikonu geçersiz kılmak için Remix Icon class'ı. */
  icon?: string;
}

const ICONS: Record<AuthAlertVariant, string> = {
  error: 'ri-error-warning-line',
  success: 'ri-checkbox-circle-line',
  info: 'ri-information-line',
};

/** Ortak auth uyarı bloğu — koyu tema ile uyumlu, form düzenini bozmaz. */
export default function AuthAlert({ variant = 'error', children, icon }: AuthAlertProps) {
  return (
    <div className={`isg-auth-alert isg-auth-alert--${variant}`} role="alert">
      <i className={icon || ICONS[variant]} aria-hidden="true" />
      <span>{children}</span>
    </div>
  );
}