import type { ReactNode } from 'react';

interface AuthCardProps {
  children: ReactNode;
  /** Verilirse kartın üst bölümünde ortalanmış logo gösterilir. */
  logo?: ReactNode;
  /** true iken karta hafif "shake" (titreme) geri bildirimi uygulanır. */
  shake?: boolean;
  /** Shake animasyonu bittiğinde tetiklenir (yeniden oynatma için state sıfırlanır). */
  onShakeEnd?: () => void;
}

/** Ortak glass-dark kart. Tüm auth ekranları aynı kartı kullanır. */
export default function AuthCard({ children, logo, shake, onShakeEnd }: AuthCardProps) {
  return (
    <section
      className={`isg-auth-card${shake ? ' isg-auth-card--shake' : ''}`}
      onAnimationEnd={onShakeEnd}
    >
      {logo && <div className="isg-auth-card__logo">{logo}</div>}
      {children}
    </section>
  );
}