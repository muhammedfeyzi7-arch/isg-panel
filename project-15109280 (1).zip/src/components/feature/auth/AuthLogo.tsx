import BrandLogo from '@/components/feature/BrandLogo';

interface AuthLogoProps {
  /** Tailwind yükseklik sınıfı (örn. "h-14"). Oran korunur, gerilmez. */
  height?: string;
}

/**
 * Auth ekranları için marka logosu. Auth zemini HER ZAMAN koyu olduğu için
 * açık-metin (dark) logo varyantı zorlanır. Logo yeniden ÇİZİLMEZ; mevcut
 * proje asset'i tek kaynaktan (BrandLogo) kullanılır.
 */
export default function AuthLogo({ height = 'h-14' }: AuthLogoProps) {
  return (
    <div className="isg-auth-logo">
      <BrandLogo forceDark className={height} alt="PRO İSGDenetim" />
    </div>
  );
}