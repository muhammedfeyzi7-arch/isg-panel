import type { ButtonHTMLAttributes, ReactNode } from 'react';

interface AuthButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
}

/** Ortak auth ana butonu — kırmızı gradient, loading'de spinner, disabled'da soluk. */
export default function AuthButton({
  isLoading,
  leftIcon,
  rightIcon,
  children,
  className = '',
  disabled,
  ...props
}: AuthButtonProps) {
  return (
    <button
      className={`isg-auth-btn ${className}`}
      disabled={disabled || isLoading}
      aria-busy={isLoading || undefined}
      {...props}
    >
      <span className={`isg-auth-btn__content ${isLoading ? 'invisible' : ''}`}>
        {leftIcon}
        {children}
        {rightIcon}
      </span>
      {isLoading && <span className="isg-auth-btn__spinner" aria-hidden="true" />}
    </button>
  );
}