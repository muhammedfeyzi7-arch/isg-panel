import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';

interface AuthLinkProps {
  to: string;
  children: ReactNode;
  /** Opsiyonel Remix Icon class'ı (örn. "ri-arrow-left-line"). */
  icon?: string;
  className?: string;
}

/** Ortak auth link'i — mavi accent, ikonlu ters yön linkleri için. */
export default function AuthLink({ to, children, icon, className = '' }: AuthLinkProps) {
  return (
    <Link to={to} className={`isg-auth-link ${className}`}>
      {icon && <i className={icon} />}
      {children}
    </Link>
  );
}