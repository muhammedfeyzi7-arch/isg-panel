import { useMemo } from 'react';

export type PasswordStrengthLevel = 'weak' | 'medium' | 'strong';

export interface PasswordStrengthResult {
  /** 0-6 arası ham puan. */
  score: number;
  /** Şifre boşsa null. */
  level: PasswordStrengthLevel | null;
  /** Kullanıcıya gösterilecek Türkçe etiket ("Zayıf" / "Orta" / "Güçlü"). */
  label: string;
}

/**
 * Şifreyi kriterlere göre puanlar ve zayıf/orta/güçlü seviyesine çevirir.
 * TEK KAYNAK: hem gösterge hem doğrulama bu kriterleri baz alır.
 * Politika (PENTEST F6): min 12 karakter + küçük + büyük + rakam + sembol.
 */
export function evaluatePasswordStrength(password: string): PasswordStrengthResult {
  if (!password) return { score: 0, level: null, label: '' };

  const checks = [
    password.length >= 12,
    /[a-z]/.test(password),
    /[A-Z]/.test(password),
    /\d/.test(password),
    /[^A-Za-z0-9]/.test(password),
    password.length >= 16,
  ];
  let score = checks.filter(Boolean).length;
  // 12 karakterden kısa şifre hiçbir zaman "güçlü" sayılmaz.
  if (password.length < 12) score = Math.min(score, 3);

  let level: PasswordStrengthLevel;
  let label: string;
  if (score <= 2) {
    level = 'weak';
    label = 'Zayıf';
  } else if (score <= 4) {
    level = 'medium';
    label = 'Orta';
  } else {
    level = 'strong';
    label = 'Güçlü';
  }

  return { score, level, label };
}

interface PasswordStrengthProps {
  password: string;
  /** Etiket satırı gizlenebilir (sadece çubuklar gösterilir). */
  showLabel?: boolean;
}

/**
 * Canlı şifre güç göstergesi — 3 segmentli çubuk + seviye etiketi.
 * Şifre boşken hiçbir şey render etmez (form düzeni bozulmaz).
 */
export default function PasswordStrength({ password, showLabel = true }: PasswordStrengthProps) {
  const { level, label } = useMemo(() => evaluatePasswordStrength(password), [password]);

  if (!password || !level) return null;

  return (
    <div className="isg-auth-strength" data-level={level}>
      <div className="isg-auth-strength__bars" aria-hidden="true">
        <span className="isg-auth-strength__seg" />
        <span className="isg-auth-strength__seg" />
        <span className="isg-auth-strength__seg" />
      </div>
      {showLabel && (
        <p className="isg-auth-strength__label">
          Şifre gücü: <strong>{label}</strong>
        </p>
      )}
      <span className="sr-only" role="status">{`Şifre gücü: ${label}`}</span>
    </div>
  );
}