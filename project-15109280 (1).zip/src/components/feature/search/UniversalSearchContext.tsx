import { createContext, useCallback, useContext, useEffect, useMemo, useState, lazy, Suspense, type ReactNode } from 'react';
import { useLocation } from 'react-router-dom';
import { useModalActions } from '@/hooks/useModal';
import { useAuth } from '@/context/AuthContext';
import { getPanelFromPath } from '@/components/feature/panelNavigation';
import { normalizeFirmaDetayRole } from '@/lib/firmaDetayPermissions';
import { getEvrakContent } from '@/lib/evrakService';
import { base64ToArrayBuffer } from '@/lib/ocrService';
import type { PreviewDocumentSource } from '@/components/feature/preview';
import type { UniversalSearchResult } from '@/lib/universalSearchService';
import { ModalSkeleton } from '@/components/ui/Skeleton';

// Ağır detay modalları yalnızca ilgili sonuç seçilince indirilir.
const PersonelDetayModal = lazy(() => import('@/components/feature/firma-personeller/detay/PersonelDetayModal'));
const FirmaDetayModal = lazy(() => import('@/components/feature/firma-detay/FirmaDetayModal'));
const UygunsuzlukDetailModal = lazy(() => import('@/pages/uzman/saha-denetimleri/components/UygunsuzlukDetailModal'));
const FirmaUygunsuzlukDetailModal = lazy(() => import('@/pages/firma/saha-denetimleri/components/FirmaUygunsuzlukDetailModal'));
const TutanakBelgeModal = lazy(() => import('@/components/feature/tutanak/TutanakBelgeModal'));
const EkipmanDetailModal = lazy(() => import('@/components/feature/ekipman/EkipmanDetailModal'));
const DocumentPreviewModal = lazy(() => import('@/components/feature/preview/DocumentPreviewModal'));

/** Modal gövdesi için ortak iskelet (SharedUICore ile uyumlu). */
function ModalLoading({ text }: { text: string }) {
  return <ModalSkeleton variant="detail" label={text} />;
}

/** Tutanak detayını id ile yükleyip MEVCUT TutanakBelgeModal'ı render eder. */
function TutanakDetayIcerik({ id, onClose }: { id: string; onClose: () => void }) {
  const [state, setState] = useState<{ loading: boolean; error: string | null; data: Awaited<ReturnType<typeof import('@/lib/tutanakService').fetchTutanakById>> | null }>({
    loading: true,
    error: null,
    data: null,
  });

  useEffect(() => {
    let cancelled = false;
    import('@/lib/tutanakService')
      .then((m) => m.fetchTutanakById(id))
      .then((data) => { if (!cancelled) setState({ loading: false, error: data ? null : 'Tutanak bulunamadı.', data }); })
      .catch(() => { if (!cancelled) setState({ loading: false, error: 'Tutanak yüklenemedi.', data: null }); });
    return () => { cancelled = true; };
  }, [id]);

  if (state.loading) return <ModalLoading text="Tutanak yükleniyor..." />;
  if (state.error || !state.data) {
    return (
      <div className="flex flex-col items-center justify-center w-full h-full min-h-[200px] gap-2 text-center">
        <i className="ri-error-warning-line text-3xl text-warning-500" />
        <p className="text-sm text-foreground-600">{state.error ?? 'Tutanak bulunamadı.'}</p>
      </div>
    );
  }
  return (
    <Suspense fallback={<ModalLoading text="Tutanak detayı yükleniyor..." />}>
      <TutanakBelgeModal tutanak={state.data} canManage={false} onClose={onClose} onChanged={() => {}} />
    </Suspense>
  );
}

/** Ekipman detayını id ile yükleyip MEVCUT EkipmanDetailModal'ı render eder. */
function EkipmanDetayIcerik({ id, onClose }: { id: string; onClose: () => void }) {
  const [row, setRow] = useState<Awaited<ReturnType<typeof import('@/lib/ekipmanService').fetchEkipmanDetail>> | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    import('@/lib/ekipmanService')
      .then((m) => m.fetchEkipmanDetail(id))
      .then((data) => { if (!cancelled) setRow(data); })
      .catch(() => { if (!cancelled) setError('Ekipman yüklenemedi.'); });
    return () => { cancelled = true; };
  }, [id]);

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center w-full h-full min-h-[200px] gap-2 text-center">
        <i className="ri-error-warning-line text-3xl text-warning-500" />
        <p className="text-sm text-foreground-600">{error}</p>
      </div>
    );
  }
  if (!row) return <ModalLoading text="Ekipman yükleniyor..." />;
  return (
    <Suspense fallback={<ModalLoading text="Ekipman detayı yükleniyor..." />}>
      <EkipmanDetailModal row={row} onClose={onClose} onChanged={() => {}} />
    </Suspense>
  );
}

interface UniversalSearchContextValue {
  openRecord: (result: UniversalSearchResult) => void;
}

const UniversalSearchContext = createContext<UniversalSearchContextValue | undefined>(undefined);

/**
 * Universal Search kayıt açıcı (SharedUI tek kaynak).
 *
 * Bir arama sonucu seçildiğinde ilgili MEVCUT detay/önizleme ekranını DOĞRUDAN
 * açar. Kullanıcıyı liste sayfasına göndermez; önce sekmeye, sonra listeye, sonra
 * tekrar aramaya zorlamaz. Modal kapanınca kullanıcı BULUNDUĞU sayfada kalır.
 * Yeni paralel modal sistemi kurulmaz; mevcut detay bileşenleri yeniden kullanılır.
 */
export function UniversalSearchProvider({ children }: { children: ReactNode }) {
  const { openModal, closeModal } = useModalActions();
  const { profile } = useAuth();
  const location = useLocation();
  const [preview, setPreview] = useState<UniversalSearchResult | null>(null);

  const openContentModal = useCallback(
    (cfg: {
      dedupeKey: string;
      title: string;
      width?: number;
      height?: number;
      minWidth?: number;
      minHeight?: number;
      bodyLayout?: 'scroll' | 'fill';
      render: (close: () => void) => ReactNode;
    }) => {
      const holder: { id: string } = { id: '' };
      const close = () => closeModal(holder.id);
      const viewportH = typeof window !== 'undefined' ? window.innerHeight : 900;
      const viewportW = typeof window !== 'undefined' ? window.innerWidth : 1440;
      const id = openModal({
        dedupeKey: cfg.dedupeKey,
        title: cfg.title,
        variant: 'detail',
        wide: true,
        width: cfg.width ?? Math.min(Math.max(viewportW - 48, 900), 1200),
        height: cfg.height ?? Math.max(560, viewportH - 48),
        minWidth: cfg.minWidth ?? 720,
        minHeight: cfg.minHeight ?? 520,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        bodyLayout: cfg.bodyLayout ?? 'fill',
        content: cfg.render(close),
      });
      holder.id = id;
    },
    [openModal, closeModal],
  );

  const openRecord = useCallback(
    (result: UniversalSearchResult) => {
      const panel = getPanelFromPath(location.pathname);
      switch (result.type) {
        case 'personel': {
          openContentModal({
            dedupeKey: `search-personel:${result.id}`,
            title: 'Personel Detay',
            render: (close) => (
              <Suspense fallback={<ModalLoading text="Personel detayı yükleniyor..." />}>
                <PersonelDetayModal personelId={result.id} onClose={close} onChanged={() => {}} />
              </Suspense>
            ),
          });
          break;
        }
        case 'firma': {
          const role = normalizeFirmaDetayRole(profile?.role);
          openContentModal({
            dedupeKey: `search-firma:${result.id}`,
            title: 'Firma Detayı',
            render: (close) => (
              <Suspense fallback={<ModalLoading text="Firma detayı yükleniyor..." />}>
                <FirmaDetayModal firmaId={result.id} role={role} onClose={close} onChanged={() => {}} />
              </Suspense>
            ),
          });
          break;
        }
        case 'uygunsuzluk': {
          if (panel === 'firma') {
            openContentModal({
              dedupeKey: `search-uygunsuzluk-firma:${result.id}`,
              title: 'Uygunsuzluk Detayı',
              bodyLayout: 'scroll',
              render: (close) => (
                <Suspense fallback={<ModalLoading text="Uygunsuzluk yükleniyor..." />}>
                  <FirmaUygunsuzlukDetailModal uygunsuzlukId={result.id} onClose={close} onChanged={() => {}} />
                </Suspense>
              ),
            });
          } else {
            openContentModal({
              dedupeKey: `search-uygunsuzluk:${result.id}`,
              title: 'Uygunsuzluk Detayı',
              bodyLayout: 'scroll',
              render: (close) => (
                <Suspense fallback={<ModalLoading text="Uygunsuzluk yükleniyor..." />}>
                  <UygunsuzlukDetailModal uygunsuzlukId={result.id} onClose={close} onChanged={() => {}} />
                </Suspense>
              ),
            });
          }
          break;
        }
        case 'tutanak': {
          openContentModal({
            dedupeKey: `search-tutanak:${result.id}`,
            title: 'Tutanak Detayı',
            render: (close) => <TutanakDetayIcerik id={result.id} onClose={close} />,
          });
          break;
        }
        case 'ekipman': {
          openContentModal({
            dedupeKey: `search-ekipman:${result.id}`,
            title: 'Ekipman Detayı',
            bodyLayout: 'scroll',
            render: (close) => <EkipmanDetayIcerik id={result.id} onClose={close} />,
          });
          break;
        }
        case 'evrak': {
          // Evrak önizleme kendi tam-ekran modalını render eder; mevcut önizleme
          // motoru yeniden kullanılır (yeni paralel sistem kurulmaz).
          setPreview(result);
          break;
        }
        default:
          break;
      }
    },
    [openContentModal, profile, location.pathname],
  );

  const value = useMemo<UniversalSearchContextValue>(() => ({ openRecord }), [openRecord]);

  const source: PreviewDocumentSource | null = preview
    ? {
        cacheKey: `evrak:${preview.id}`,
        fileName: preview.fileName || preview.title || 'belge',
        mimeType: preview.mimeType ?? null,
        fileSize: null,
        getBytes: async () => base64ToArrayBuffer((await getEvrakContent(preview.id)).fileBase64),
      }
    : null;

  return (
    <UniversalSearchContext.Provider value={value}>
      {children}
      {preview && source && (
        <Suspense fallback={null}>
          <DocumentPreviewModal
            source={source}
            title={preview.title}
            onClose={() => setPreview(null)}
          />
        </Suspense>
      )}
    </UniversalSearchContext.Provider>
  );
}

export function useUniversalSearch() {
  const ctx = useContext(UniversalSearchContext);
  if (!ctx) throw new Error('useUniversalSearch must be used within UniversalSearchProvider');
  return ctx;
}