import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { useClickOutside } from '@/hooks/useDropdown';
import { Z_LAYERS } from '@/utils/layers';
import { getPanelFromPath, type PanelKey } from '@/components/feature/panelNavigation';
import {
  searchUniversal,
  groupResults,
  TYPE_GROUP_LABEL,
  type UniversalRecordType,
  type UniversalSearchResult,
} from '@/lib/universalSearchService';
import { useUniversalSearch } from './UniversalSearchContext';

// Panel → aranacak GERÇEK kayıt tipleri (rol/yetki kapsamı; veri sınırı ayrıca RLS'te).
const PANEL_SEARCH_TYPES: Record<PanelKey, UniversalRecordType[]> = {
  admin: ['firma', 'personel', 'evrak', 'tutanak', 'uygunsuzluk', 'ekipman'],
  osgb: ['firma', 'personel', 'evrak', 'tutanak', 'uygunsuzluk', 'ekipman'],
  firma: ['personel', 'evrak', 'tutanak', 'uygunsuzluk', 'ekipman'],
  uzman: ['firma', 'personel', 'evrak', 'tutanak', 'uygunsuzluk', 'ekipman'],
  hekim: ['firma', 'personel', 'evrak', 'tutanak', 'uygunsuzluk', 'ekipman'],
};

const DEBOUNCE_MS = 250;
const MAX_RESULTS = 12;
const RECENT_LIMIT = 6;

function isMac(): boolean {
  if (typeof navigator === 'undefined') return false;
  return /Mac|iPhone|iPad|iPod/.test(navigator.platform || navigator.userAgent || '');
}

function recentKey(userId: string | undefined): string {
  return `isg_universal_search_recent_${userId ?? 'anon'}`;
}

function readRecent(userId: string | undefined): string[] {
  try {
    const raw = localStorage.getItem(recentKey(userId));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x): x is string => typeof x === 'string').slice(0, RECENT_LIMIT) : [];
  } catch {
    return [];
  }
}

function writeRecent(userId: string | undefined, list: string[]): void {
  try {
    localStorage.setItem(recentKey(userId), JSON.stringify(list.slice(0, RECENT_LIMIT)));
  } catch {
    // localStorage kapalıysa sessizce geç.
  }
}

/**
 * İSGDenetim — ORTAK Universal Record Search (komut paleti).
 *
 * Topbar'daki arama alanını GERÇEK kayıt aramasına çevirir: personel, firma,
 * evrak, tutanak, uygunsuzluk ve ekipman kayıtlarını arar. Seçilen sonuç
 * DOĞRUDAN ilgili mevcut detay/önizleme ekranını açar (liste sayfasına
 * yönlendirmez). 5 panelin tamamı AYNI UI'yi paylaşır; yalnızca veri kapsamı
 * panele göre değişir.
 *
 * Klavye: ⌘K / Ctrl+K aç-kapat → yaz → ↑/↓ gezin → Enter aç → Esc kapat.
 */
export default function UniversalSearch() {
  const location = useLocation();
  const { profile } = useAuth();
  const { openRecord } = useUniversalSearch();
  const panel = getPanelFromPath(location.pathname);
  const searchTypes = PANEL_SEARCH_TYPES[panel] ?? PANEL_SEARCH_TYPES.admin;

  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<UniversalSearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [recent, setRecent] = useState<string[]>(() => readRecent(profile?.id));

  const rootRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const openRef = useRef(false);
  openRef.current = open;
  // Race guard: yalnızca EN SON isteğin sonucu state'e yazılır.
  const reqIdRef = useRef(0);

  useClickOutside(rootRef, () => setOpen(false), open);

  const groups = useMemo(() => groupResults(results), [results]);
  const flat = useMemo(() => groups.flatMap((g) => g.items), [groups]);

  // ⌘K / Ctrl+K aç-kapat + Escape kapat. TEK listener; unmount'ta temizlenir.
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen((prev) => !prev);
      } else if (e.key === 'Escape' && openRef.current) {
        setOpen(false);
      }
    };
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, []);

  // Açılınca input'a odaklan; kapanınca sorgu/sonuçları temizle.
  useEffect(() => {
    if (open) {
      const t = window.setTimeout(() => inputRef.current?.focus(), 30);
      return () => window.clearTimeout(t);
    }
    setQuery('');
    setResults([]);
    setError(null);
    setLoading(false);
    return undefined;
  }, [open]);

  // Debounce'lu arama + race guard.
  useEffect(() => {
    if (!open) return undefined;
    const term = query.trim();
    if (term.length === 0) {
      setResults([]);
      setError(null);
      setLoading(false);
      return undefined;
    }
    setLoading(true);
    const myId = ++reqIdRef.current;
    const t = window.setTimeout(() => {
      searchUniversal(term, searchTypes, { maxResults: MAX_RESULTS })
        .then((res) => {
          if (myId !== reqIdRef.current) return; // eski istek → yok say
          setResults(res);
          setError(null);
        })
        .catch((e) => {
          if (myId !== reqIdRef.current) return;
          console.error('[universalSearch] arama hatası:', e);
          setResults([]);
          setError('Arama sırasında bir sorun oluştu.');
        })
        .finally(() => {
          if (myId === reqIdRef.current) setLoading(false);
        });
    }, DEBOUNCE_MS);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, open, panel]);

  // Sonuçlar değişince seçimi başa al.
  useEffect(() => {
    setActiveIndex(0);
  }, [query, open, results.length]);

  const close = useCallback(() => setOpen(false), []);

  const selectResult = useCallback(
    (r: UniversalSearchResult) => {
      const term = query.trim();
      if (term) {
        const next = [term, ...recent.filter((x) => x !== term)].slice(0, RECENT_LIMIT);
        setRecent(next);
        writeRecent(profile?.id, next);
      }
      close();
      openRecord(r);
    },
    [query, recent, profile?.id, close, openRecord],
  );

  const handleInputKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveIndex((i) => Math.min(i + 1, Math.max(flat.length - 1, 0)));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const target = flat[activeIndex];
      if (target) selectResult(target);
    }
  };

  const shortcutLabel = isMac() ? '⌘ K' : 'Ctrl K';
  const placeholder = 'Personel, evrak, tutanak veya kayıt ara…';
  const trimmed = query.trim();
  const showEmptyState = trimmed.length === 0;
  const showNoResult = !showEmptyState && !loading && !error && flat.length === 0;

  // Aktif sonucun grup içindeki düz indeksini bulmak için sayaç.
  let runningIndex = -1;

  return (
    <div className="relative" ref={rootRef}>
      <button
        type="button"
        onClick={() => setOpen((p) => !p)}
        aria-label="Kayıt ara"
        aria-expanded={open}
        aria-haspopup="dialog"
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-background-200 dark:bg-background-300/40 hover:bg-background-300/50 dark:hover:bg-background-400/25 border border-background-300/70 dark:border-background-500/15 text-sm text-foreground-500 hover:text-foreground-700 transition-colors w-auto lg:w-[25rem] cursor-pointer"
      >
        <i className="ri-search-line text-sm flex-shrink-0" />
        <span className="text-sm truncate flex-1 text-left hidden lg:inline">{placeholder}</span>
        <span className="ml-auto text-xs text-foreground-400 border border-background-300/30 dark:border-background-400/20 rounded px-1.5 py-0.5 hidden lg:inline flex-shrink-0">
          {shortcutLabel}
        </span>
      </button>

      {open && (
        <div
          className="absolute top-full left-0 mt-1 isg-popover p-2 w-full min-w-[20rem] sm:min-w-[26rem] max-w-[calc(100vw-2rem)]"
          style={{ zIndex: Z_LAYERS.topbarDropdown }}
          role="dialog"
          aria-label="Kayıt arama"
        >
          {/* Arama kutusu */}
          <div className="flex items-center gap-2 px-3 py-2 bg-background-200 dark:bg-background-300/40 rounded-lg border border-transparent dark:border-background-400/20">
            {loading ? (
              <span className="inline-block w-4 h-4 border-2 border-primary-500 border-t-transparent rounded-full animate-spin flex-shrink-0" aria-hidden="true" />
            ) : (
              <i className="ri-search-line text-foreground-400 flex-shrink-0" />
            )}
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={handleInputKeyDown}
              className="flex-1 bg-transparent text-sm text-foreground-950 placeholder:text-foreground-400 outline-none"
              placeholder={placeholder}
              aria-label="Kayıt ara"
              autoComplete="off"
              spellCheck={false}
              role="combobox"
              aria-expanded={flat.length > 0}
              aria-controls="universal-search-results"
            />
            {query ? (
              <button
                type="button"
                onClick={() => { setQuery(''); inputRef.current?.focus(); }}
                aria-label="Aramayı temizle"
                className="w-5 h-5 flex items-center justify-center rounded text-foreground-400 hover:text-foreground-700 cursor-pointer"
              >
                <i className="ri-close-line text-sm" />
              </button>
            ) : (
              <kbd className="text-[10px] text-foreground-400 border border-background-300/40 dark:border-background-400/25 rounded px-1.5 py-0.5 flex-shrink-0">{shortcutLabel}</kbd>
            )}
          </div>

          {/* İçerik */}
          <div id="universal-search-results" role="listbox" aria-label="Arama sonuçları" className="mt-2 max-h-[60vh] overflow-y-auto">
            {showEmptyState ? (
              <div className="px-1 py-2">
                <p className="px-2 py-3 text-center text-sm text-foreground-500">Bir kayıt arayın</p>
                {recent.length > 0 && (
                  <div className="mt-1">
                    <p className="px-2 mb-1 text-[11px] font-semibold tracking-wide text-foreground-400">SON ARAMALAR</p>
                    <div className="flex flex-wrap gap-1.5 px-2">
                      {recent.map((term) => (
                        <button
                          key={term}
                          type="button"
                          onClick={() => { setQuery(term); inputRef.current?.focus(); }}
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-background-200 dark:bg-background-300/40 text-xs text-foreground-700 hover:bg-background-300/60 dark:hover:bg-background-400/30 transition-colors cursor-pointer max-w-full"
                        >
                          <i className="ri-history-line text-foreground-400" />
                          <span className="truncate max-w-[12rem]">{term}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
                <div className="mt-3 flex items-center justify-center gap-4 px-2 py-2 text-[11px] text-foreground-400 border-t border-background-300/20 dark:border-background-400/15">
                  <span className="flex items-center gap-1"><kbd className="border border-background-300/40 rounded px-1">↑</kbd><kbd className="border border-background-300/40 rounded px-1">↓</kbd> Gezin</span>
                  <span className="flex items-center gap-1"><kbd className="border border-background-300/40 rounded px-1">↵</kbd> Aç</span>
                  <span className="flex items-center gap-1"><kbd className="border border-background-300/40 rounded px-1">Esc</kbd> Kapat</span>
                </div>
              </div>
            ) : error ? (
              <div className="px-2 py-6 text-center">
                <i className="ri-error-warning-line text-2xl text-warning-500" />
                <p className="mt-2 text-sm text-foreground-600">{error}</p>
              </div>
            ) : showNoResult ? (
              <div className="px-2 py-6 text-center">
                <i className="ri-search-eye-line text-2xl text-foreground-300" />
                <p className="mt-2 text-sm text-foreground-600">“{trimmed}” için eşleşen kayıt bulunamadı.</p>
                <p className="mt-1 text-xs text-foreground-400">Personel, evrak, tutanak veya kayıt adıyla aramayı deneyin.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {groups.map((group) => (
                  <div key={group.type}>
                    <p className="px-2 mb-1 text-[11px] font-semibold tracking-wide text-foreground-400">{TYPE_GROUP_LABEL[group.type]}</p>
                    {group.items.map((item) => {
                      runningIndex += 1;
                      const idx = runningIndex;
                      const active = idx === activeIndex;
                      return (
                        <button
                          key={`${item.type}-${item.id}`}
                          type="button"
                          role="option"
                          aria-selected={active}
                          onMouseEnter={() => setActiveIndex(idx)}
                          onClick={() => selectResult(item)}
                          className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-md transition-colors text-left cursor-pointer ${
                            active
                              ? 'bg-background-200 dark:bg-background-300/30'
                              : 'hover:bg-background-200 dark:hover:bg-background-300/25'
                          }`}
                        >
                          <span className="w-8 h-8 rounded-md bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
                            <i className={`${item.icon} text-foreground-500`} />
                          </span>
                          <span className="flex-1 min-w-0">
                            <span className="block text-sm text-foreground-900 truncate">{item.title}</span>
                            {item.subtitle && <span className="block text-xs text-foreground-500 truncate">{item.subtitle}</span>}
                          </span>
                          <span className="flex-shrink-0 text-[10px] text-foreground-400 bg-background-200/70 dark:bg-background-300/30 rounded px-1.5 py-0.5 whitespace-nowrap">
                            {item.context}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}