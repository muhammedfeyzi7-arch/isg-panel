// ─────────────────────────────────────────────────────────────────────────────
// ZİYARET RAPORU — Excel önizleme (ortak görsel dil)
//
// Personel raporu ExcelPreview ile AYNI görsel dil (kurumsal başlık, özet kutuları,
// tablo, alt bilgi + çalışma sayfası sekmeleri). Üç sayfa: Gün Programı / Süre
// Bazlı / Detaylı Liste. Önizleme, üretilen .xlsx dosyasının yapısını yansıtır.
// ─────────────────────────────────────────────────────────────────────────────
import { useMemo, useState, type CSSProperties } from 'react';
import { fmtDateTime } from '@/lib/personelReport/PersonnelReportEngine';
import { REPORT_SITE, REPORT_SLOGAN } from '@/lib/personelReport/branding';
import {
  buildDayColumns,
  buildGunProgramiMatrix,
  computeVisitDerived,
  DAY_STATUS_CODE,
  fmtDurHM,
  fmtPct,
  type DayStatus,
} from '@/lib/personelReport/visitReportModel';
import type { VisitReportDataset } from '@/lib/personelReport/visitReport';
import type { VisitReportMeta } from '@/lib/personelReport/visitMeta';
import type { ReportConfig } from '@/lib/personelReport/types';

const INK = '#0f172a';
const BODY = '#334155';
const MUTED = '#64748b';
const ACCENT = '#0d9488';
const HEAD_BG = '#1e293b';
const BORDER = '#d8dee7';
const ROW_ALT = '#f8fafc';
const WEEKEND_BG = '#fdf2f8';

const DAY_STYLE: Record<DayStatus, { bg: string | null; color: string; bold: boolean }> = {
  done: { bg: '#dcfce7', color: '#15803d', bold: true },
  missed: { bg: '#fee2e2', color: '#b91c1c', bold: true },
  izin: { bg: '#fef3c7', color: '#b45309', bold: true },
  planned: { bg: '#e9eef5', color: '#475569', bold: false },
  none: { bg: null, color: '#cbd5e1', bold: false },
};

type SheetKey = 'gun' | 'sure' | 'detay';

interface Props {
  data: VisitReportDataset;
  config: ReportConfig;
  meta: VisitReportMeta;
}

export default function VisitExcelPreview({ data, config, meta }: Props) {
  const [sheet, setSheet] = useState<SheetKey>('gun');
  const derived = useMemo(() => computeVisitDerived(data), [data]);
  const dayColumns = useMemo(() => buildDayColumns(data.period.start, data.period.end), [data]);
  const personelRows = useMemo(() => buildGunProgramiMatrix(data.dayProgram, data.izinByPersonel), [data]);

  const corp = meta.corporate;
  const contactLine = [corp.adres, [corp.il, corp.ilce].filter(Boolean).join(' / '), corp.telefon, corp.email]
    .filter((x) => !!x && String(x).trim() !== '')
    .join('  ·  ');

  const sheetLabel = sheet === 'gun' ? 'Gün Programı' : sheet === 'sure' ? 'Süre Bazlı' : 'Detaylı Liste';

  // Özet kutuları SEÇİLEN sekmeye göre değişir (indirilen Excel ile birebir tutarlı).
  const stats = useMemo(() => {
    if (sheet === 'sure') {
      return [
        { label: 'Toplam Tanımlı Aylık Süre', value: `${fmtDurHM(derived.sureBazliPlanlananDakika)} saat`, fill: '#f1f5f9', color: INK },
        { label: 'Toplam Gerçekleşen Süre', value: `${fmtDurHM(derived.sureBazliGerceklesenDakika)} saat`, fill: '#dcfce7', color: '#15803d' },
        { label: 'Toplam Kalan Süre', value: `${fmtDurHM(derived.sureBazliKalanDakika)} saat`, fill: '#fef3c7', color: '#b45309' },
        { label: 'Gerçekleşme Oranı', value: derived.sureBazliOran, fill: '#f0fdfa', color: '#0f766e' },
      ];
    }
    if (sheet === 'detay') {
      const total = data.visitDetails.length;
      const done = data.visitDetails.filter((r) => r.durum === 'gerceklesti' || r.durum === 'otomatik_kapatildi').length;
      const missed = data.visitDetails.filter((r) => r.durum === 'gerceklesmedi').length;
      const oran = total > 0 ? `${Math.round((done / total) * 100)}%` : '—';
      return [
        { label: 'Toplam Kayıt', value: String(total), fill: '#f1f5f9', color: INK },
        { label: 'Gerçekleşen Ziyaret', value: String(done), fill: '#dcfce7', color: '#15803d' },
        { label: 'Gerçekleşmedi', value: String(missed), fill: '#fee2e2', color: '#b91c1c' },
        { label: 'Gerçekleşme Oranı', value: oran, fill: '#f0fdfa', color: '#0f766e' },
      ];
    }
    return [
      { label: 'Toplam Personel', value: String(derived.gunProgramiPersonelSayisi), fill: '#f1f5f9', color: INK },
      { label: 'Planlanan Ziyaret', value: String(derived.gunProgramiPlanlanan), fill: '#e9eef5', color: '#475569' },
      { label: 'Gerçekleşen Ziyaret', value: String(derived.gunProgramiGerceklesen), fill: '#dcfce7', color: '#15803d' },
      { label: 'Gerçekleşme Oranı', value: derived.gunProgramiOran, fill: '#f0fdfa', color: '#0f766e' },
    ];
  }, [sheet, derived, data]);

  const th = (center?: boolean) => ({
    color: '#ffffff',
    background: HEAD_BG,
    fontSize: 8.5,
    fontWeight: 700 as const,
    textAlign: (center ? 'center' : 'left') as 'center' | 'left',
    padding: '5px 6px',
    border: '1px solid #334155',
    whiteSpace: 'nowrap' as const,
  });
  const td = (center?: boolean): CSSProperties => ({
    fontSize: 8.5,
    color: BODY,
    padding: '4px 6px',
    border: `1px solid ${BORDER}`,
    textAlign: center ? 'center' : 'left',
    verticalAlign: 'top',
    wordBreak: 'break-word',
  });

  return (
    <div className="flex flex-col rounded-lg border border-background-300/40 bg-background-100/60 dark:bg-background-200/40 p-3">
      <div className="flex items-center justify-between gap-2 flex-wrap mb-2">
        <div className="min-w-0">
          <h4 className="text-sm font-semibold text-foreground-900">Excel Önizleme</h4>
          <p className="text-xs text-foreground-500 mt-0.5 hidden sm:block">
            Oluşturulacak .xlsx dosyasının içeriği (kurumsal başlık + özet + 3 çalışma sayfası).
          </p>
        </div>
      </div>

      <div className="overflow-auto rounded-md border border-background-300/50 bg-white dark:bg-background-100">
        <div style={{ minWidth: 900, fontFamily: "'Calibri', 'Segoe UI', Arial, sans-serif", color: BODY }}>
          {config.showHeader && (
            <div className="flex items-start justify-between gap-4 px-4 pt-3 pb-2" style={{ borderBottom: `1px solid ${BORDER}` }}>
              <div className="flex items-center gap-3 min-w-0">
                {config.showLogo && meta.logoDataUrl && (
                  <img src={meta.logoDataUrl} alt="Kurumsal logo" style={{ height: 40, width: 'auto', maxWidth: 120, objectFit: 'contain' }} />
                )}
                <div className="min-w-0">
                  <div style={{ fontSize: 14, fontWeight: 700, color: INK, lineHeight: 1.3 }}>{corp.unvan || 'OSGB'}</div>
                  {contactLine && <div style={{ fontSize: 9, color: MUTED, marginTop: 2, lineHeight: 1.4 }}>{contactLine}</div>}
                  {corp.vergiNo && <div style={{ fontSize: 9, color: MUTED, lineHeight: 1.4 }}>Vergi No: {corp.vergiNo}</div>}
                </div>
              </div>
              <div style={{ fontSize: 9, color: MUTED, textAlign: 'right', whiteSpace: 'nowrap', lineHeight: 1.7 }}>
                {config.showDateTime && <div>Rapor Tarihi&nbsp;: {fmtDateTime(meta.generatedAt)}</div>}
                <div>Raporu Oluşturan&nbsp;: {meta.olusturan}</div>
                <div>Dönem&nbsp;: {meta.periodLabel}</div>
                <div>Sayfa&nbsp;: {sheetLabel}</div>
              </div>
            </div>
          )}

          <div className="flex items-end justify-between gap-4 px-4 pt-3">
            <div>
              <div style={{ fontSize: 20, fontWeight: 700, color: INK, lineHeight: 1.2 }}>Ziyaret Raporu</div>
              <div style={{ fontSize: 11, fontWeight: 600, color: ACCENT, marginTop: 2 }}>{sheetLabel}</div>
            </div>
            <div style={{ fontSize: 11, color: MUTED }}>Dönem: {meta.periodLabel}</div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 px-4 pt-3">
            {stats.map((s) => (
              <div key={s.label} className="rounded-md px-3 py-2" style={{ background: s.fill, border: `1px solid ${BORDER}` }}>
                <div style={{ fontSize: 9, fontWeight: 700, color: MUTED }}>{s.label}</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: s.color, marginTop: 2 }}>{s.value}</div>
              </div>
            ))}
          </div>

          <div className="px-4 pt-3 pb-2">
            {sheet === 'gun' && (
              <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                <colgroup>
                  {config.showRowNumber && <col style={{ width: '3%' }} />}
                  <col style={{ width: '16%' }} />
                  <col style={{ width: '11%' }} />
                  {dayColumns.map((d) => <col key={d.date} />)}
                  <col style={{ width: '6%' }} />
                  <col style={{ width: '6%' }} />
                  <col style={{ width: '5%' }} />
                </colgroup>
                <thead>
                  <tr>
                    {config.showRowNumber && <th style={th(true)}>#</th>}
                    <th style={th()}>Ad Soyad</th>
                    <th style={th()}>Unvan / Görev</th>
                    {dayColumns.map((d) => (
                      <th key={d.date} style={{ ...th(true), padding: '3px 1px', fontSize: 7 }}>
                        {String(d.day).padStart(2, '0')}
                        <div style={{ fontSize: 6.5, color: '#a7f3d0' }}>{d.weekday}</div>
                      </th>
                    ))}
                    <th style={th(true)}>Plan.</th>
                    <th style={th(true)}>Gerç.</th>
                    <th style={th(true)}>Oran</th>
                  </tr>
                </thead>
                <tbody>
                  {personelRows.map((p, idx) => (
                    <tr key={p.personelId} style={{ background: idx % 2 === 1 ? ROW_ALT : '#fff' }}>
                      {config.showRowNumber && <td style={{ ...td(true), color: MUTED }}>{idx + 1}</td>}
                      <td style={{ ...td(), fontWeight: 600, color: INK }}>{p.adSoyad}</td>
                      <td style={{ ...td(), color: MUTED }}>{p.unvan}</td>
                      {dayColumns.map((d) => {
                        const st: DayStatus = p.cells.get(d.date) ?? 'none';
                        const s = DAY_STYLE[st];
                        const isWeekend = d.weekday === 'Cmt' || d.weekday === 'Paz';
                        return (
                          <td key={d.date} style={{ ...td(true), background: s.bg ?? (isWeekend ? WEEKEND_BG : undefined), color: s.color, fontWeight: s.bold ? 700 : 400, padding: '3px 1px', fontSize: 8 }}>
                            {DAY_STATUS_CODE[st]}
                          </td>
                        );
                      })}
                      <td style={{ ...td(true) }}>{p.planlanan}</td>
                      <td style={{ ...td(true), color: '#15803d', fontWeight: 700 }}>{p.gerceklesen}</td>
                      <td style={{ ...td(true) }}>{p.oran}</td>
                    </tr>
                  ))}
                  {personelRows.length === 0 && (
                    <tr><td colSpan={100} style={{ ...td(true), color: MUTED, padding: '14px 6px' }}>Bu kapsamda Gün Programı kaydı bulunmuyor.</td></tr>
                  )}
                </tbody>
              </table>
            )}

            {sheet === 'sure' && (
              <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                <colgroup>
                  {config.showRowNumber && <col style={{ width: '3%' }} />}
                  <col style={{ width: '17%' }} /><col style={{ width: '14%' }} /><col style={{ width: '9%' }} />
                  <col style={{ width: '8%' }} /><col style={{ width: '8%' }} />
                  <col style={{ width: '9%' }} /><col style={{ width: '9%' }} /><col style={{ width: '8%' }} />
                  <col style={{ width: '9%' }} /><col style={{ width: '8%' }} /><col style={{ width: '8%' }} />
                </colgroup>
                <thead>
                  <tr>
                    {config.showRowNumber && <th style={th(true)}>#</th>}
                    {['Firma Adı', 'Sorumlu Uzman / Hekim', 'Unvan', 'Sözleşme Başlangıç', 'Sözleşme Bitiş', 'Aylık Tanımlı Süre', 'Gerçekleşen Süre', 'Kalan Süre', 'Gerçekleşme Oranı', 'Son Ziyaret Tarihi', 'Durum'].map((h) => (
                      <th key={h} style={th(true)}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.durationBased.map((r, idx) => {
                    const st = !r.monthlyRequiredDuration ? { label: 'Plan Yok', color: MUTED, bg: '#f1f5f9' }
                      : r.remainingDuration > 0 ? { label: 'Eksik', color: '#b45309', bg: '#fef3c7' }
                      : r.remainingDuration < 0 ? { label: 'Fazla', color: '#0f766e', bg: '#f0fdfa' }
                      : { label: 'Tamamlandı', color: '#15803d', bg: '#dcfce7' };
                    return (
                      <tr key={`${r.personelId}-${r.firmaId}-${idx}`} style={{ background: idx % 2 === 1 ? ROW_ALT : '#fff' }}>
                        {config.showRowNumber && <td style={{ ...td(true), color: MUTED }}>{idx + 1}</td>}
                        <td style={{ ...td(), fontWeight: 600, color: INK }}>{r.firmaUnvan}</td>
                        <td style={td()}>{r.personelAdSoyad}</td>
                        <td style={{ ...td(), color: MUTED }}>{r.personelTuruLabel}</td>
                        <td style={td(true)}>{r.sozlesmeBaslangic ? r.sozlesmeBaslangic.split('-').reverse().join('.') : '—'}</td>
                        <td style={td(true)}>{r.sozlesmeBitis ? r.sozlesmeBitis.split('-').reverse().join('.') : 'Açık'}</td>
                        <td style={{ ...td(true), fontWeight: 600 }}>{fmtDurHM(r.monthlyRequiredDuration)}</td>
                        <td style={td(true)}>{fmtDurHM(r.actualDuration)}</td>
                        <td style={{ ...td(true), color: r.remainingDuration < 0 ? '#0f766e' : BODY }}>{fmtDurHM(r.remainingDuration)}</td>
                        <td style={td(true)}>{fmtPct(r.actualDuration, r.monthlyRequiredDuration)}</td>
                        <td style={td(true)}>{r.sonZiyaretTarihi ? r.sonZiyaretTarihi.split('-').reverse().join('.') : '—'}</td>
                        <td style={{ ...td(true), fontWeight: 700, color: st.color, background: st.bg }}>{st.label}</td>
                      </tr>
                    );
                  })}
                  {data.durationBased.length === 0 && (
                    <tr><td colSpan={100} style={{ ...td(true), color: MUTED, padding: '14px 6px' }}>Bu kapsamda Süre Bazlı plan bulunmuyor.</td></tr>
                  )}
                </tbody>
              </table>
            )}

            {sheet === 'detay' && (
              <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                <colgroup>
                  {config.showRowNumber && <col style={{ width: '2.5%' }} />}
                  <col style={{ width: '6%' }} /><col style={{ width: '13%' }} /><col style={{ width: '10%' }} /><col style={{ width: '7%' }} />
                  <col style={{ width: '7%' }} /><col style={{ width: '6.5%' }} /><col style={{ width: '7%' }} /><col style={{ width: '7%' }} />
                  <col style={{ width: '6%' }} /><col style={{ width: '4.5%' }} /><col style={{ width: '6.5%' }} /><col style={{ width: '6.5%' }} /><col style={{ width: '10%' }} />
                </colgroup>
                <thead>
                  <tr>
                    {config.showRowNumber && <th style={th(true)}>#</th>}
                    {['Tarih', 'Firma Adı', 'Sorumlu Uzman / Hekim', 'Unvan', 'Sözleşme Başlangıç', 'Sözleşme Bitiş', 'Planlanan Süre', 'Gerçekleşen Süre', 'Kalan Süre', 'Oran', 'Son Ziyaret Tarihi', 'Durum', 'Açıklama'].map((h) => (
                      <th key={h} style={{ ...th(true), fontSize: 8 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.visitDetails.map((r, idx) => {
                    const planned = r.planlananSureDakika ?? 0;
                    const actual = r.actualDurationMinutes ?? 0;
                    const st = (r.durum === 'gerceklesti' || r.durum === 'otomatik_kapatildi')
                      ? (planned > 0 && actual < planned ? { label: 'Kısmi', color: '#b45309', bg: '#fef3c7' } : { label: 'Gerçekleşti', color: '#15803d', bg: '#dcfce7' })
                      : r.durum === 'gerceklesmedi' ? { label: 'Gerçekleşmedi', color: '#b91c1c', bg: '#fee2e2' }
                      : { label: 'Planlandı', color: '#475569', bg: '#e9eef5' };
                    return (
                      <tr key={r.id} style={{ background: idx % 2 === 1 ? ROW_ALT : '#fff' }}>
                        {config.showRowNumber && <td style={{ ...td(true), color: MUTED }}>{idx + 1}</td>}
                        <td style={td(true)}>{r.ziyaretTarihi.split('-').reverse().join('.')}</td>
                        <td style={{ ...td(), fontWeight: 600, color: INK }}>{r.firmaUnvan}</td>
                        <td style={td()}>{r.personelAdSoyad}</td>
                        <td style={{ ...td(), color: MUTED }}>{r.personelTuruLabel}</td>
                        <td style={td(true)}>{r.sozlesmeBaslangic ? r.sozlesmeBaslangic.split('-').reverse().join('.') : '—'}</td>
                        <td style={td(true)}>{r.sozlesmeBitis ? r.sozlesmeBitis.split('-').reverse().join('.') : 'Açık'}</td>
                        <td style={td(true)}>{r.planlananSureDakika != null ? fmtDurHM(r.planlananSureDakika) : '—'}</td>
                        <td style={td(true)}>{r.actualDurationMinutes != null ? fmtDurHM(r.actualDurationMinutes) : '—'}</td>
                        <td style={td(true)}>{fmtDurHM(planned - actual)}</td>
                        <td style={td(true)}>{fmtPct(actual, planned)}</td>
                        <td style={td(true)}>{actual > 0 ? r.ziyaretTarihi.split('-').reverse().join('.') : '—'}</td>
                        <td style={{ ...td(true), fontWeight: 700, color: st.color, background: st.bg }}>{st.label}</td>
                        <td style={{ ...td(), color: MUTED }}>{r.notlar || '—'}</td>
                      </tr>
                    );
                  })}
                  {data.visitDetails.length === 0 && (
                    <tr><td colSpan={100} style={{ ...td(true), color: MUTED, padding: '14px 6px' }}>Bu kapsamda ziyaret hareketi bulunmuyor.</td></tr>
                  )}
                </tbody>
              </table>
            )}
          </div>

          <div className="flex items-center justify-between gap-3 px-4 py-2" style={{ borderTop: `1px solid ${BORDER}` }}>
            <span style={{ fontSize: 9, color: MUTED }}>{corp.unvan || 'OSGB'} | {REPORT_SLOGAN}</span>
            <span style={{ fontSize: 9, color: ACCENT }}>{REPORT_SITE}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-1 mt-2 px-1">
        {([['gun', 'Gün Programı'], ['sure', 'Süre Bazlı'], ['detay', 'Detaylı Liste']] as Array<[SheetKey, string]>).map(([k, label]) => (
          <button
            key={k}
            type="button"
            onClick={() => setSheet(k)}
            className={`px-3 py-1 rounded-t-md text-xs font-medium border-b-2 cursor-pointer whitespace-nowrap ${
              sheet === k ? 'border-accent-500 text-foreground-900 bg-background-50' : 'border-transparent text-foreground-500 hover:text-foreground-700'
            }`}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}