import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import EvrakUploadModal from '@/components/feature/evrak/EvrakUploadModal';
import TahliyeKrokiCanvas from './TahliyeKrokiCanvas';
import {
  bosKroki, fetchFirmaKunye, fetchTahliyeKatlar, fetchTahliyePlanlari, fetchTahliyeBelgeleri,
  fetchTahliyeTurId, kaydetTahliyeKat, kaydetTahliyePlan, silTahliyeKat, silTahliyePlan,
  friendlyTahliyeError, TAHLIYE_DURUM_LABEL, SEMBOLLER,
  type FirmaKunye, type TahliyeKat, type TahliyePlan,
} from '@/lib/tahliyePlaniService';
import { generateTahliyeWord, indirTahliyeWord, krokiOzet } from '@/lib/tahliyePlaniRapor';
import { getEvrakUrl, evrakStatusLabel, friendlyEvrakError, type EvrakData } from '@/lib/evrakService';
import { uploadUretilenBelge, EVRAK_SOURCE_TYPE } from '@/lib/evrakSource';

interface Props {
  firmaId: string;
  role: 'uzman' | 'firma';
  onClose: () => void;
  onChanged?: () => void;
}

function tarihGoster(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

type SagTab = 'belgeler' | 'sablonlar' | 'onizleme';

/**
 * ACİL DURUM TAHLİYE PLANLARI / KROKİ (referans görsel).
 *
 * Sol: planlar/katlar + plan bilgileri. Orta: kroki çalışma alanı (görsel + sembol +
 * rota araçları). Sağ: belgeler + şablonlar + önizleme. Alt: Taslak Kaydet / Kaydet
 * ve Belge Oluştur. Kat/kroki verisi `tahliye_katlari` tablosunda; üretilen/yüklenen
 * belgeler merkezi `evraklar` altyapısında saklanır. Paralel belge sistemi YOKTUR.
 */
export default function AcilDurumTahliyeModal({ firmaId, role, onClose, onChanged }: Props) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const belgeRef = useRef('');

  const yonetimVar = role === 'uzman';

  const [kunye, setKunye] = useState<FirmaKunye | null>(null);
  const [planlar, setPlanlar] = useState<TahliyePlan[]>([]);
  const [aktifPlanId, setAktifPlanId] = useState('');
  const [katlar, setKatlar] = useState<TahliyeKat[]>([]);
  const [aktifKatId, setAktifKatId] = useState('');
  const [belgeler, setBelgeler] = useState<EvrakData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [tab, setTab] = useState<SagTab>('belgeler');

  const aktifPlan = useMemo(() => planlar.find((p) => p.id === aktifPlanId) ?? null, [planlar, aktifPlanId]);
  const aktifKat = useMemo(() => katlar.find((k) => k.id === aktifKatId) ?? null, [katlar, aktifKatId]);
  const ozet = useMemo(() => krokiOzet(katlar), [katlar]);

  const yukle = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [k, ps, bl] = await Promise.all([
        fetchFirmaKunye(firmaId),
        fetchTahliyePlanlari(firmaId),
        fetchTahliyeBelgeleri(firmaId).catch(() => [] as EvrakData[]),
      ]);
      setKunye(k);
      setPlanlar(ps);
      setBelgeler(bl);
      setAktifPlanId((prev) => prev || ps[0]?.id || '');
    } catch (e) {
      setError(friendlyTahliyeError(e));
    } finally {
      setLoading(false);
    }
  }, [firmaId]);

  useEffect(() => { void yukle(); }, [yukle]);

  // Aktif plan değişince katları yükle.
  useEffect(() => {
    if (!aktifPlanId) { setKatlar([]); setAktifKatId(''); return; }
    let alive = true;
    fetchTahliyeKatlar(aktifPlanId)
      .then((ks) => { if (alive) { setKatlar(ks); setAktifKatId((prev) => (ks.some((k) => k.id === prev) ? prev : ks[0]?.id || '')); } })
      .catch((e) => { if (alive) addToast({ title: 'Katlar yüklenemedi', message: friendlyTahliyeError(e), type: 'error' }); });
    return () => { alive = false; };
  }, [aktifPlanId, addToast]);

  const refreshDocs = useCallback(async () => {
    try { setBelgeler(await fetchTahliyeBelgeleri(firmaId)); } catch { /* yoksay */ }
  }, [firmaId]);

  // ── Plan / kat oluşturma ──
  const yeniPlan = useCallback(async () => {
    if (!yonetimVar) return;
    setBusy('plan');
    try {
      const id = await kaydetTahliyePlan({
        firmaId,
        ad: `${kunye?.ad || 'Firma'} — Acil Durum Tahliye Planı`,
        tesis: kunye?.tesis || '',
        aciklama: '',
        sorumlu: '',
        toplanmaAlani: '',
        durum: 'taslak',
        osgbId: kunye?.osgbId ?? null,
      });
      const ps = await fetchTahliyePlanlari(firmaId);
      setPlanlar(ps);
      setAktifPlanId(id);
      addToast({ title: 'Plan oluşturuldu', message: 'Şimdi kat ekleyebilirsiniz.', type: 'success' });
    } catch (e) {
      addToast({ title: 'Oluşturulamadı', message: friendlyTahliyeError(e), type: 'error' });
    } finally { setBusy(null); }
  }, [firmaId, kunye, yonetimVar, addToast]);

  const katEkle = useCallback(async () => {
    if (!yonetimVar || !aktifPlan) return;
    setBusy('kat');
    try {
      const ad = katlar.length === 0 ? 'Zemin Kat' : `${katlar.length}. Kat`;
      await kaydetTahliyeKat({
        planId: aktifPlan.id, firmaId, ad, sira: katlar.length,
        aciklama: '', alan: '', kisiSayisi: '', sorumlu: '', durum: 'taslak', kroki: bosKroki(),
      });
      const ks = await fetchTahliyeKatlar(aktifPlan.id);
      setKatlar(ks);
      setAktifKatId(ks[ks.length - 1]?.id || '');
    } catch (e) {
      addToast({ title: 'Kat eklenemedi', message: friendlyTahliyeError(e), type: 'error' });
    } finally { setBusy(null); }
  }, [yonetimVar, aktifPlan, katlar.length, firmaId, addToast]);

  const katSil = useCallback((kat: TahliyeKat) => {
    if (!yonetimVar) return;
    confirm({
      title: 'Katı Sil', message: `"${kat.ad}" kat planı ve krokisi kalıcı olarak silinecek.`,
      variant: 'danger', confirmText: 'Evet, Sil', cancelText: 'Vazgeç',
      onConfirm: async () => {
        try {
          await silTahliyeKat(kat.id);
          const ks = await fetchTahliyeKatlar(aktifPlanId);
          setKatlar(ks);
          setAktifKatId(ks[0]?.id || '');
          addToast({ title: 'Silindi', message: 'Kat silindi.', type: 'success' });
        } catch (e) { addToast({ title: 'Silinemedi', message: friendlyTahliyeError(e), type: 'error' }); }
      },
    });
  }, [yonetimVar, confirm, aktifPlanId, addToast]);

  const planSil = useCallback(() => {
    if (!yonetimVar || !aktifPlan) return;
    confirm({
      title: 'Planı Sil', message: `"${aktifPlan.ad}" planı, tüm katları ve krokileriyle birlikte silinecek.`,
      variant: 'danger', confirmText: 'Evet, Sil', cancelText: 'Vazgeç',
      onConfirm: async () => {
        try {
          await silTahliyePlan(aktifPlan.id);
          const ps = await fetchTahliyePlanlari(firmaId);
          setPlanlar(ps);
          setAktifPlanId(ps[0]?.id || '');
          addToast({ title: 'Silindi', message: 'Plan silindi.', type: 'success' });
        } catch (e) { addToast({ title: 'Silinemedi', message: friendlyTahliyeError(e), type: 'error' }); }
      },
    });
  }, [yonetimVar, aktifPlan, confirm, firmaId, addToast]);

  // ── Yerel düzenlemeler ──
  const planGuncelle = useCallback((patch: Partial<TahliyePlan>) => {
    setPlanlar((prev) => prev.map((p) => (p.id === aktifPlanId ? { ...p, ...patch } : p)));
  }, [aktifPlanId]);

  const katGuncelle = useCallback((patch: Partial<TahliyeKat>) => {
    setKatlar((prev) => prev.map((k) => (k.id === aktifKatId ? { ...k, ...patch } : k)));
  }, [aktifKatId]);

  const canvasChange = useCallback((veri: TahliyeKat['kroki']) => {
    setKatlar((prev) => prev.map((k) => (k.id === aktifKatId ? { ...k, kroki: veri } : k)));
  }, [aktifKatId]);

  // ── Kaydetme ──
  const tumunuKaydet = useCallback(async (): Promise<boolean> => {
    if (!aktifPlan) return false;
    await kaydetTahliyePlan({
      firmaId, id: aktifPlan.id, ad: aktifPlan.ad, tesis: aktifPlan.tesis, aciklama: aktifPlan.aciklama,
      sorumlu: aktifPlan.sorumlu, toplanmaAlani: aktifPlan.toplanmaAlani, durum: aktifPlan.durum, osgbId: kunye?.osgbId ?? null,
    });
    for (const kat of katlar) {
      await kaydetTahliyeKat({
        planId: aktifPlan.id, firmaId, id: kat.id, ad: kat.ad, sira: kat.sira, aciklama: kat.aciklama,
        alan: kat.alan, kisiSayisi: kat.kisiSayisi, sorumlu: kat.sorumlu, durum: kat.durum, kroki: kat.kroki,
      });
    }
    return true;
  }, [aktifPlan, firmaId, katlar, kunye]);

  const taslakKaydet = useCallback(async () => {
    if (!aktifPlan) { addToast({ title: 'Plan yok', message: 'Önce bir plan oluşturun.', type: 'warning' }); return; }
    setBusy('taslak');
    try {
      await tumunuKaydet();
      const ps = await fetchTahliyePlanlari(firmaId);
      setPlanlar(ps);
      addToast({ title: 'Kaydedildi', message: 'Tahliye planı taslak olarak kaydedildi.', type: 'success' });
      onChanged?.();
    } catch (e) {
      addToast({ title: 'Kaydedilemedi', message: friendlyTahliyeError(e), type: 'error' });
    } finally { setBusy(null); }
  }, [aktifPlan, tumunuKaydet, firmaId, addToast, onChanged]);

  const belgeOlustur = useCallback(async () => {
    if (!aktifPlan || !kunye) { addToast({ title: 'Plan yok', message: 'Önce bir plan oluşturun.', type: 'warning' }); return; }
    setBusy('belge');
    try {
      await tumunuKaydet();
      const ps = await fetchTahliyePlanlari(firmaId);
      setPlanlar(ps);
      const plan = ps.find((p) => p.id === aktifPlan.id) ?? aktifPlan;
      const { blob, fileName } = await generateTahliyeWord({
        plan, katlar,
        firmaKunye: { ad: kunye.ad, tesis: kunye.tesis, adres: kunye.adres, tehlikeSinifi: kunye.tehlikeSinifi },
        sorumlu: plan.sorumlu,
      });
      // Merkezi Evrak Merkezi'ne yaz (paralel sistem yok).
      const turId = await fetchTahliyeTurId();
      if (turId) {
        try {
          await uploadUretilenBelge({
            firmaId,
            documentTypeId: turId,
            title: `${plan.ad}${katlar.length ? ` (${katlar.length} kat)` : ''}`,
            description: 'Acil durum tahliye planı / kroki belgesi (üretilen belge).',
            sourceType: EVRAK_SOURCE_TYPE.ACIL_TAHLIYE_PLANI,
            sourceId: plan.id,
            blob,
            fileName,
            revizeEt: true,
          });
        } catch (upErr) {
          addToast({ title: 'Belge oluşturuldu, kayıt eklenemedi', message: friendlyEvrakError(upErr), type: 'warning' });
          indirTahliyeWord({ blob, fileName });
          await refreshDocs();
          return;
        }
      }
      indirTahliyeWord({ blob, fileName });
      await refreshDocs();
      onChanged?.();
      addToast({ title: 'Belge oluşturuldu', message: `${fileName} indirildi ve Evraklar\'a eklendi.`, type: 'success' });
    } catch (e) {
      addToast({ title: 'Belge oluşturulamadı', message: friendlyTahliyeError(e), type: 'error' });
    } finally { setBusy(null); }
  }, [aktifPlan, kunye, tumunuKaydet, firmaId, katlar, refreshDocs, onChanged, addToast]);

  const sablondanOlustur = useCallback(async () => {
    if (!aktifPlan || !kunye) { addToast({ title: 'Plan yok', message: 'Önce bir plan oluşturun.', type: 'warning' }); return; }
    setBusy('sablon');
    try {
      const { blob, fileName } = await generateTahliyeWord({
        plan: aktifPlan, katlar,
        firmaKunye: { ad: kunye.ad, tesis: kunye.tesis, adres: kunye.adres, tehlikeSinifi: kunye.tehlikeSinifi },
        sorumlu: aktifPlan.sorumlu,
      });
      indirTahliyeWord({ blob, fileName });
      addToast({ title: 'Şablon oluşturuldu', message: `${fileName} indirildi.`, type: 'success' });
    } catch (e) {
      addToast({ title: 'Oluşturulamadı', message: friendlyTahliyeError(e), type: 'error' });
    } finally { setBusy(null); }
  }, [aktifPlan, kunye, katlar, addToast]);

  const belgeYukle = useCallback((previous?: EvrakData) => {
    const id = openModal({
      title: previous ? 'Yeni Sürüm Yükle' : 'Kendi Belgeni Yükle',
      description: previous ? previous.title : 'Hazırladığınız tahliye planı belgesini Evraklar\'a ekleyin.',
      width: 720, minHeight: 560, showFooter: false, closable: true, resizable: true, minimizable: true,
      content: (
        <EvrakUploadModal
          role={role}
          initialFirmaId={firmaId}
          lockOwnerType="firma"
          allowedCategory="Acil Durum"
          previousEvrak={previous}
          onClose={() => closeModal(id)}
          onUploaded={() => void refreshDocs()}
        />
      ),
    });
  }, [openModal, closeModal, role, firmaId, refreshDocs]);

  const belgeAc = useCallback(async (b: EvrakData) => {
    try {
      const url = await getEvrakUrl(b.id);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) { addToast({ title: 'Dosya açılamadı', message: friendlyEvrakError(e), type: 'error' }); }
  }, [addToast]);

  if (loading) return <div className="flex justify-center py-16"><Loading size="lg" text="Tahliye planları yükleniyor..." /></div>;
  if (error) return <ErrorState message={error} onRetry={() => void yukle()} />;

  return (
    <div className="flex flex-col gap-3">
      {/* Üst bilgi */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2">
        <UstKart ikon="ri-building-4-line" etiket="Firma" deger={kunye?.ad || '—'} />
        <UstKart ikon="ri-map-pin-2-line" etiket="Tesis / İş yeri" deger={kunye?.tesis || '—'} />
        <UstKart ikon="ri-error-warning-line" etiket="Tehlike Sınıfı" deger={kunye?.tehlikeSinifi || '—'} />
        <UstKart ikon="ri-calendar-line" etiket="Son Güncelleme" deger={tarihGoster(aktifPlan?.updatedAt)} />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-sm font-semibold text-foreground-950">Acil Durum Tahliye Planları / Kroki</span>
          {aktifPlan && <Badge variant={aktifPlan.durum === 'aktif' ? 'success' : 'default'}>{TAHLIYE_DURUM_LABEL[aktifPlan.durum]}</Badge>}
        </div>
        {yonetimVar && (
          <div className="flex items-center gap-2">
            <Button variant="primary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-add-line" />} isLoading={busy === 'plan'} onClick={() => void yeniPlan()}>Yeni Tahliye Planı</Button>
            <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-file-copy-2-line" />} disabled={!aktifPlan} isLoading={busy === 'sablon'} onClick={() => void sablondanOlustur()}>Şablondan Oluştur</Button>
            <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-upload-2-line" />} onClick={() => belgeYukle()}>Kendi Belgesini Yükle</Button>
          </div>
        )}
      </div>

      {!aktifPlan ? (
        <EmptyState icon="ri-route-line" title="Tahliye planı yok" description={yonetimVar ? '"Yeni Tahliye Planı" ile başlayın, ardından kat ekleyin.' : 'Henüz tahliye planı oluşturulmamış.'} />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,260px)_minmax(0,1fr)_minmax(0,300px)] gap-3">
          {/* SOL — Katlar + Plan Bilgileri */}
          <div className="space-y-3">
            <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
              <div className="flex items-center justify-between gap-2 mb-2">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500">Kat Planları</span>
                {yonetimVar && (
                  <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-add-line" />} isLoading={busy === 'kat'} onClick={() => void katEkle()}>Kat Ekle</Button>
                )}
              </div>
              <div className="space-y-1.5 max-h-[220px] overflow-y-auto pr-0.5">
                {katlar.length === 0 ? (
                  <p className="text-xs text-foreground-400 text-center py-3">Kat yok.</p>
                ) : katlar.map((k) => (
                  <div key={k.id} className={`flex items-center gap-2 p-2 rounded-lg border ${aktifKatId === k.id ? 'border-primary-300 bg-primary-50 dark:border-primary-500/40 dark:bg-primary-500/10' : 'border-background-200/70 dark:border-background-400/25'}`}>
                    <button type="button" onClick={() => setAktifKatId(k.id)} className="flex items-center gap-2 min-w-0 flex-1 text-left cursor-pointer">
                      <span className="w-9 h-9 rounded-md bg-background-100 dark:bg-background-200/50 border border-background-200/70 dark:border-background-400/25 flex items-center justify-center flex-shrink-0 overflow-hidden">
                        {k.kroki.gorsel ? <img src={k.kroki.gorsel} alt="" className="w-full h-full object-cover" /> : <i className="ri-image-line text-foreground-400" />}
                      </span>
                      <span className="min-w-0">
                        <span className="block text-xs font-medium text-foreground-900 truncate">{k.ad}</span>
                        <span className="block text-[10px] text-foreground-500">{TAHLIYE_DURUM_LABEL[k.durum]} · {tarihGoster(k.updatedAt)}</span>
                      </span>
                    </button>
                    {yonetimVar && (
                      <button type="button" onClick={() => katSil(k)} className="w-6 h-6 rounded flex items-center justify-center text-danger-500 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer" title="Katı sil" aria-label="Katı sil"><i className="ri-delete-bin-line text-xs" /></button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Plan Bilgileri */}
            <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2.5">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500">Plan Bilgileri</span>
              <fieldset disabled={!yonetimVar} className="space-y-2.5 disabled:opacity-80">
                <Input label="Plan Adı" value={aktifPlan.ad} onChange={(e) => planGuncelle({ ad: e.target.value })} />
                <Select label="Tesis / İş yeri" value={aktifPlan.tesis} onChange={(e) => planGuncelle({ tesis: e.target.value })} options={[{ value: aktifPlan.tesis || '', label: aktifPlan.tesis || (kunye?.tesis || 'Tesis') }]} />
                <Input label="Toplanma Alanı" value={aktifPlan.toplanmaAlani} onChange={(e) => planGuncelle({ toplanmaAlani: e.target.value })} placeholder="Örn: Otopark yanı" />
                <Input label="Sorumlu" value={aktifPlan.sorumlu} onChange={(e) => planGuncelle({ sorumlu: e.target.value })} />
                <Select label="Durum" value={aktifPlan.durum} onChange={(e) => planGuncelle({ durum: e.target.value as TahliyePlan['durum'] })} options={[{ value: 'taslak', label: 'Taslak' }, { value: 'aktif', label: 'Aktif' }]} />
              </fieldset>

              {aktifKat && (
                <>
                  <div className="pt-1 mt-1 border-t border-background-200/60 dark:border-background-400/20">
                    <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500">Seçili Kat</span>
                  </div>
                  <fieldset disabled={!yonetimVar} className="space-y-2.5 disabled:opacity-80">
                    <Input label="Kat Adı" value={aktifKat.ad} onChange={(e) => katGuncelle({ ad: e.target.value })} />
                    <Textarea label="Açıklama" value={aktifKat.aciklama} onChange={(e) => katGuncelle({ aciklama: e.target.value })} maxLength={500} />
                    <div className="grid grid-cols-2 gap-2">
                      <Input label="Kat Alanı (m²)" value={aktifKat.alan} onChange={(e) => katGuncelle({ alan: e.target.value })} />
                      <Input label="Kişi Sayısı" value={aktifKat.kisiSayisi} onChange={(e) => katGuncelle({ kisiSayisi: e.target.value })} />
                    </div>
                    <Input label="Kat Sorumlusu" value={aktifKat.sorumlu} onChange={(e) => katGuncelle({ sorumlu: e.target.value })} />
                    <Select label="Kat Durumu" value={aktifKat.durum} onChange={(e) => katGuncelle({ durum: e.target.value as TahliyeKat['durum'] })} options={[{ value: 'taslak', label: 'Taslak' }, { value: 'aktif', label: 'Aktif' }]} />
                  </fieldset>
                </>
              )}

              <Note kat={aktifKat} katlar={katlar} />
            </div>

            {yonetimVar && (
              <Button variant="ghost" size="sm" className="whitespace-nowrap text-danger-600 w-full" leftIcon={<i className="ri-delete-bin-line" />} onClick={planSil}>Planı Sil</Button>
            )}
          </div>

          {/* ORTA — Kroki */}
          <div className="min-w-0 flex flex-col gap-2 min-h-[520px]">
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-foreground-900 truncate">{aktifKat ? `${aktifKat.ad} — Tahliye Planı` : 'Kroki'}</span>
              {aktifKat && <Badge variant={aktifKat.durum === 'aktif' ? 'success' : 'default'}>{TAHLIYE_DURUM_LABEL[aktifKat.durum]}</Badge>}
            </div>
            {aktifKat ? (
              <TahliyeKrokiCanvas key={aktifKat.id} veri={aktifKat.kroki} onChange={canvasChange} readOnly={!yonetimVar} />
            ) : (
              <div className="flex-1 flex items-center justify-center rounded-lg border border-dashed border-background-300/70 dark:border-background-400/30">
                <p className="text-sm text-foreground-500">Sol panelden bir kat seçin veya yeni kat ekleyin.</p>
              </div>
            )}
          </div>

          {/* SAĞ — Belgeler / Şablonlar / Önizleme */}
          <div className="space-y-3">
            <div className="flex items-center gap-1 bg-background-100 dark:bg-background-200/60 rounded-full p-1">
              {([['belgeler', 'Belgeler'], ['sablonlar', 'Şablonlar'], ['onizleme', 'Önizleme']] as [SagTab, string][]).map(([k, ad]) => (
                <button key={k} type="button" onClick={() => setTab(k)} className={`flex-1 px-2.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap cursor-pointer ${tab === k ? 'bg-primary-500 text-inverse' : 'text-foreground-600 hover:text-foreground-800'}`}>{ad}</button>
              ))}
            </div>

            {tab === 'belgeler' && (
              <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500">Mevcut Belgeler</span>
                  <button type="button" onClick={() => belgeYukle()} className="inline-flex items-center gap-1 text-xs font-semibold text-primary-600 hover:text-primary-700 cursor-pointer whitespace-nowrap"><i className="ri-upload-2-line" /> Belge Yükle</button>
                </div>
                {belgeler.length === 0 ? (
                  <p className="text-xs text-foreground-400 text-center py-4">Henüz belge yok.</p>
                ) : (
                  <ul className="space-y-1.5 max-h-[300px] overflow-y-auto pr-0.5">
                    {belgeler.map((b) => (
                      <li key={b.id} className="flex items-center gap-2 p-2 rounded-md border border-background-200/70 dark:border-background-400/25">
                        <i className="ri-file-text-line text-foreground-400 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium text-foreground-800 truncate">{b.title}</p>
                          <p className="text-[10px] text-foreground-500">{evrakStatusLabel(b.status)} · {tarihGoster(b.documentDate ?? b.createdAt)}</p>
                        </div>
                        <button type="button" onClick={() => void belgeAc(b)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer" title="Görüntüle / İndir" aria-label="Görüntüle"><i className="ri-eye-line text-xs" /></button>
                        {yonetimVar && (
                          <button type="button" onClick={() => belgeYukle(b)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer" title="Yeni sürüm" aria-label="Yeni sürüm"><i className="ri-refresh-line text-xs" /></button>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            )}

            {tab === 'sablonlar' && (
              <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500">Belge Şablonları</span>
                {[
                  { ikon: 'ri-route-line', ad: 'Acil Durum Tahliye Planı', alt: 'Tüm katlar + sembol lejantı' },
                  { ikon: 'ri-file-list-3-line', ad: 'Kat Tahliye Planı', alt: 'Seçili kat belgesi' },
                  { ikon: 'ri-stack-line', ad: 'Tüm Katlar Tahliye Planı', alt: 'Çok katlı belge' },
                  { ikon: 'ri-file-text-line', ad: 'Açıklama Sayfası', alt: 'Sembol ve rota açıklamaları' },
                ].map((t) => (
                  <div key={t.ad} className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-md bg-background-200/70 dark:bg-background-300/40 text-foreground-500 flex items-center justify-center flex-shrink-0"><i className={t.ikon} /></span>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground-800 truncate">{t.ad}</p>
                      <p className="text-[10px] text-foreground-500 truncate">{t.alt}</p>
                    </div>
                    <button type="button" disabled={!aktifPlan || busy === 'sablon'} onClick={() => void sablondanOlustur()} className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary-600 hover:text-primary-700 cursor-pointer whitespace-nowrap disabled:opacity-40"><i className="ri-download-2-line" /> Oluştur</button>
                  </div>
                ))}
              </div>
            )}

            {tab === 'onizleme' && (
              <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2">
                <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500">Belge Önizleme</span>
                <div className="rounded-md border border-background-200/70 dark:border-background-400/25 overflow-hidden">
                  <div className="bg-red-50 dark:bg-danger-500/10 px-2.5 py-2 border-b border-background-200/70 dark:border-background-400/25">
                    <p className="text-[11px] font-bold text-foreground-900 text-center">ACİL DURUM TAHLİYE PLANI</p>
                    <p className="text-[9px] text-foreground-500 text-center">{kunye?.ad || '—'} · {tarihGoster(new Date().toISOString())}</p>
                  </div>
                  <dl className="text-[10px] divide-y divide-background-200/60 dark:divide-background-400/20">
                    {[
                      ['Plan', aktifPlan.ad],
                      ['Kat Sayısı', String(ozet.katSayisi)],
                      ['Krokili Kat', String(ozet.krokiVar)],
                      ['Sembol', String(ozet.sembolSayisi)],
                      ['Tahliye Rotası', String(ozet.rotaSayisi)],
                      ['Acil Çıkış', String(ozet.acilCikis)],
                      ['Toplanma Alanı', aktifPlan.toplanmaAlani || '—'],
                    ].map(([k, v]) => (
                      <div key={k} className="flex gap-2 px-2 py-1">
                        <dt className="text-foreground-500 w-24 flex-shrink-0">{k}</dt>
                        <dd className="text-foreground-800 truncate">{v}</dd>
                      </div>
                    ))}
                  </dl>
                </div>
                {yonetimVar && aktifPlan && (
                  <Button variant="secondary" size="sm" className="whitespace-nowrap w-full" leftIcon={<i className="ri-file-word-2-line" />} isLoading={busy === 'belge'} onClick={() => void belgeOlustur()}>Belge Oluştur ve Evraklar'a Ekle</Button>
                )}
              </div>
            )}

            {/* Kullanılan semboller — canvas ile birebir aynı veri kaynağından (aktifKat.kroki.ogeler) */}
            <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500">Sembol Listesi</span>
              {!aktifKat ? (
                <p className="text-xs text-foreground-400 py-1">Bir kat seçin.</p>
              ) : (
                <ul className="divide-y divide-background-200/60 dark:divide-background-400/20">
                  {SEMBOLLER.map((s) => {
                    const adet = aktifKat.kroki.ogeler.filter((o) => o.tip === 'sembol' && o.sembolKey === s.key).length;
                    return (
                      <li key={s.key} className="flex items-center gap-2 py-1">
                        <span className="w-6 h-6 rounded flex items-center justify-center flex-shrink-0" style={{ backgroundColor: `${s.renk}1a` }}>
                          <i className={s.ikon} style={{ color: s.renk }} />
                        </span>
                        <span className="flex-1 text-xs text-foreground-700 truncate">{s.ad}</span>
                        <span className={`text-xs tabular-nums ${adet > 0 ? 'font-semibold text-foreground-900' : 'text-foreground-400'}`}>{adet}</span>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Alt bar */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t isg-divider">
        <div>
          {yonetimVar && aktifPlan && (
            <Button variant="ghost" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-save-line" />} isLoading={busy === 'taslak'} onClick={() => void taslakKaydet()}>Taslak Olarak Kaydet</Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" className="whitespace-nowrap" onClick={onClose}>İptal</Button>
          {yonetimVar && aktifPlan && (
            <Button variant="primary" className="whitespace-nowrap" leftIcon={<i className="ri-file-word-2-line" />} isLoading={busy === 'belge'} onClick={() => void belgeOlustur()}>Kaydet ve Belge Oluştur</Button>
          )}
        </div>
      </div>
    </div>
  );
}

function UstKart({ ikon, etiket, deger }: { ikon: string; etiket: string; deger: string }) {
  return (
    <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-2.5 flex items-center gap-2.5">
      <span className="w-9 h-9 rounded-md bg-primary-100 dark:bg-primary-500/15 text-primary-600 dark:text-primary-300 flex items-center justify-center flex-shrink-0">
        <i className={`${ikon} text-lg`} />
      </span>
      <div className="min-w-0">
        <p className="text-[11px] text-foreground-500 truncate">{etiket}</p>
        <p className="text-sm font-semibold text-foreground-950 truncate">{deger}</p>
      </div>
    </div>
  );
}

/** Kroki doğrulama uyarıları (mevzuat değil, sistem/veri bütünlüğü kontrolleri). */
function Note({ kat, katlar }: { kat: TahliyeKat | null; katlar: TahliyeKat[] }) {
  const uyarilar: string[] = [];
  if (katlar.length === 0) uyarilar.push('Henüz kat eklenmemiş.');
  if (kat && !kat.kroki.zemin) uyarilar.push('Bu kat için kroki yüklenmemiş.');
  if (kat) {
    const og = kat.kroki.ogeler;
    if (!og.some((o) => o.tip === 'sembol' && o.sembolKey === 'acil-cikis')) uyarilar.push('Acil çıkış sembolü bulunmuyor.');
    if (!og.some((o) => o.tip === 'sembol' && o.sembolKey === 'yangin-sondurucu')) uyarilar.push('Yangın söndürücü sembolü bulunmuyor.');
    if (!og.some((o) => o.tip === 'sembol' && o.sembolKey === 'toplanma-alani')) uyarilar.push('Toplanma alanı işaretlenmemiş.');
    if (!og.some((o) => o.tip === 'rota' || o.tip === 'ok')) uyarilar.push('Tahliye rotası çizilmemiş.');
  }
  if (uyarilar.length === 0) {
    return (
      <p className="text-[11px] text-success-600 flex items-start gap-1.5">
        <i className="ri-checkbox-circle-line mt-0.5 flex-shrink-0" /> Kontroller tamam: kroki, acil çıkış, söndürücü, toplanma alanı ve rota mevcut.
      </p>
    );
  }
  return (
    <div className="rounded-md border border-warning-300/60 dark:border-warning-500/30 bg-warning-500/10 p-2 space-y-1">
      <p className="text-[11px] font-semibold text-warning-700 dark:text-warning-300 flex items-center gap-1"><i className="ri-alert-line" /> Kontrol Uyarıları</p>
      {uyarilar.map((u) => <p key={u} className="text-[11px] text-foreground-700">• {u}</p>)}
    </div>
  );
}