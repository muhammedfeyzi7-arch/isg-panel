import { useCallback, useEffect, useRef, useState } from 'react';
import { loadPdfjsRuntime } from '@/lib/pdfjsRuntime';
import {
  SEMBOLLER, sembolTanim, yeniOgeId,
  type KrokiVeri, type KrokiOge, type KrokiNokta,
} from '@/lib/tahliyePlaniService';

// ─────────────────────────────────────────────────────────────────────────────
// TAHLİYE KROKİSİ ÇİZİM TUVALİ
//
// Yüklenen kat planı (PNG/JPG/PDF) arka plana alınır; üzerine acil durum sembolleri
// yerleştirilir, tahliye rotası çizilir, metin/kutu/daire/çizgi/ok eklenir. Öğeler
// JSON olarak saklanır (tekrar düzenlenebilir) ve düz görsel (PNG dataURL) belgeye
// gömülmek üzere dışarı verilir. Harici çizim kütüphanesi kullanılmaz.
// ─────────────────────────────────────────────────────────────────────────────

const EN = 1400;
const BOY = 900;
const OLCEK_M = 0.02; // 1 px ≈ 2 cm (yaklaşık ölçüm)

type Arac =
  | 'sec' | 'tasima' | 'alan' | 'metin' | 'kutu' | 'daire' | 'cizgi' | 'ok' | 'rota' | 'olcum' | 'sil'
  | 'sembol';

interface AracTanim { key: Arac; label: string; icon: string }

const ARACLAR: AracTanim[] = [
  { key: 'sec', label: 'Seç', icon: 'ri-cursor-line' },
  { key: 'tasima', label: 'Taşı', icon: 'ri-drag-move-2-line' },
  { key: 'alan', label: 'Alan', icon: 'ri-checkbox-blank-line' },
  { key: 'metin', label: 'Metin', icon: 'ri-text' },
  { key: 'kutu', label: 'Kutu', icon: 'ri-square-line' },
  { key: 'daire', label: 'Daire', icon: 'ri-circle-line' },
  { key: 'cizgi', label: 'Çizgi', icon: 'ri-subtract-line' },
  { key: 'ok', label: 'Ok', icon: 'ri-arrow-right-line' },
  { key: 'rota', label: 'Tahliye Rotası', icon: 'ri-route-line' },
  { key: 'olcum', label: 'Ölçüm', icon: 'ri-ruler-2-line' },
  { key: 'sil', label: 'Sil', icon: 'ri-eraser-line' },
];

// ── Yardımcılar ──────────────────────────────────────────────────────────────
function bounds(o: KrokiOge): { x: number; y: number; w: number; h: number } {
  if (o.tip === 'sembol') return { x: o.x - 16, y: o.y - 16, w: 32, h: 32 };
  if (o.tip === 'metin') return { x: o.x - 2, y: o.y - 12, w: Math.max(40, (o.metin || '').length * 9), h: 24 };
  if (o.tip === 'daire') return { x: o.x - (o.r ?? 0), y: o.y - (o.r ?? 0), w: (o.r ?? 0) * 2, h: (o.r ?? 0) * 2 };
  if (o.tip === 'alan' || o.tip === 'kutu') return { x: Math.min(o.x, o.x + (o.w ?? 0)), y: Math.min(o.y, o.y + (o.h ?? 0)), w: Math.abs(o.w ?? 0), h: Math.abs(o.h ?? 0) };
  const pts = o.pts ?? [];
  if (pts.length === 0) return { x: o.x, y: o.y, w: 0, h: 0 };
  const xs = pts.map((p) => p.x); const ys = pts.map((p) => p.y);
  return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
}

async function readKrokiFile(file: File): Promise<string> {
  if (file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')) {
    const buf = await file.arrayBuffer();
    const pdfjs = await loadPdfjsRuntime();
    const doc = await pdfjs.getDocument({ data: buf }).promise;
    const page = await doc.getPage(1);
    const viewport = page.getViewport({ scale: 2 });
    const c = document.createElement('canvas');
    c.width = viewport.width; c.height = viewport.height;
    const ctx = c.getContext('2d');
    if (!ctx) throw new Error('PDF oluşturulamadı');
    await page.render({ canvasContext: ctx, viewport }).promise;
    return c.toDataURL('image/png');
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Dosya okunamadı'));
    reader.readAsDataURL(file);
  });
}

// ── Çizim ────────────────────────────────────────────────────────────────────
function roundedRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number): void {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

/**
 * Her acil durum sembolü için ayrı, ayırt edilebilir vektör piktogram.
 * Beyaz kare zemin + renkli çerçeve üzerine sembole ÖZEL şekil çizilir; böylece
 * semboller birbirine karışmaz ve gerçek anlamlarını net gösterir.
 */
function drawSembolPiktogram(ctx: CanvasRenderingContext2D, key: string, x: number, y: number, renk: string): void {
  ctx.save();
  ctx.translate(x, y);
  const R = 14;
  ctx.fillStyle = '#FFFFFF';
  ctx.strokeStyle = renk;
  ctx.lineWidth = 2.5;
  roundedRectPath(ctx, -R, -R, R * 2, R * 2, 5);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = renk;
  ctx.strokeStyle = renk;
  ctx.lineWidth = 2;
  ctx.lineJoin = 'round';
  ctx.lineCap = 'round';

  switch (key) {
    case 'acil-cikis': {
      ctx.beginPath(); ctx.arc(-1.5, -6, 2.4, 0, Math.PI * 2); ctx.fill();
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(-1.5, -3.6); ctx.lineTo(-2.5, 2);
      ctx.moveTo(-2.5, 2); ctx.lineTo(-5.5, 6.5);
      ctx.moveTo(-2.5, 2); ctx.lineTo(0.8, 5.5);
      ctx.moveTo(-1.8, -1.5); ctx.lineTo(-6.5, 0.8);
      ctx.moveTo(-1.8, -1.5); ctx.lineTo(2.8, -3.2);
      ctx.stroke();
      break;
    }
    case 'tahliye-yonu': {
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-6.5, 6.5); ctx.lineTo(3.5, -3.5);
      ctx.moveTo(-1.5, -5); ctx.lineTo(5, -5); ctx.lineTo(5, 1.5);
      ctx.stroke();
      break;
    }
    case 'yangin-sondurucu': {
      roundedRectPath(ctx, -4.5, -3, 9, 11, 2.5); ctx.fill();
      ctx.fillRect(-2, -6.6, 4, 3.6);
      ctx.lineWidth = 1.8;
      ctx.beginPath(); ctx.moveTo(2.2, -5); ctx.lineTo(6, -6.2); ctx.lineTo(6, -1.2); ctx.stroke();
      break;
    }
    case 'yangin-dolabi': {
      ctx.lineWidth = 2.2;
      ctx.strokeRect(-7, -8, 14, 16);
      ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(0, 8); ctx.stroke();
      ctx.beginPath(); ctx.arc(-1.6, 0, 1.3, 0, Math.PI * 2); ctx.arc(1.6, 0, 1.3, 0, Math.PI * 2); ctx.fill();
      break;
    }
    case 'yangin-alarmi': {
      ctx.beginPath();
      ctx.moveTo(-6, 4); ctx.quadraticCurveTo(-6, -7, 0, -7); ctx.quadraticCurveTo(6, -7, 6, 4);
      ctx.closePath(); ctx.fill();
      ctx.fillRect(-2, -8.6, 4, 2);
      ctx.beginPath(); ctx.arc(0, 6, 2, 0, Math.PI * 2); ctx.fill();
      break;
    }
    case 'yangin-ihbar': {
      ctx.lineWidth = 2.2;
      ctx.beginPath(); ctx.arc(0, 0, 7.6, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.arc(0, -3, 2.2, 0, Math.PI * 2); ctx.fill();
      ctx.fillRect(-1, 1.5, 2, 4);
      break;
    }
    case 'ilk-yardim': {
      ctx.fillRect(-7, -2.5, 14, 5);
      ctx.fillRect(-2.5, -7, 5, 14);
      break;
    }
    case 'toplanma-alani': {
      ctx.beginPath(); ctx.arc(-4, -4, 2, 0, Math.PI * 2); ctx.arc(3, -4.2, 1.7, 0, Math.PI * 2); ctx.fill();
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-4, -1.5); ctx.lineTo(-4, 5);
      ctx.moveTo(-7, 1); ctx.lineTo(-1, 1);
      ctx.moveTo(3, -1.8); ctx.lineTo(3, 4);
      ctx.moveTo(0.6, 0.6); ctx.lineTo(5.4, 0.6);
      ctx.stroke();
      break;
    }
    case 'acil-telefon': {
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(-5, -5); ctx.lineTo(5, 5); ctx.stroke();
      ctx.beginPath(); ctx.arc(-6, -6, 2.4, 0, Math.PI * 2); ctx.arc(6, 6, 2.4, 0, Math.PI * 2); ctx.fill();
      break;
    }
    case 'elektrik-panosu': {
      ctx.beginPath();
      ctx.moveTo(2.5, -8); ctx.lineTo(-5, 1); ctx.lineTo(-1, 1); ctx.lineTo(-2.5, 8); ctx.lineTo(5, -1); ctx.lineTo(1, -1);
      ctx.closePath(); ctx.fill();
      break;
    }
    case 'gaz-kesme': {
      ctx.beginPath();
      ctx.moveTo(0, 8);
      ctx.quadraticCurveTo(-6.5, 4, -3, -3);
      ctx.quadraticCurveTo(-2, -8, 1.5, -8);
      ctx.quadraticCurveTo(0, -3, 3.2, -1);
      ctx.quadraticCurveTo(6.5, 3, 0, 8);
      ctx.closePath(); ctx.fill();
      break;
    }
    case 'su-vanasi': {
      ctx.beginPath();
      ctx.moveTo(0, -8);
      ctx.quadraticCurveTo(6, 0, 4, 4);
      ctx.quadraticCurveTo(2, 8, 0, 8);
      ctx.quadraticCurveTo(-2, 8, -4, 4);
      ctx.quadraticCurveTo(-6, 0, 0, -8);
      ctx.closePath(); ctx.fill();
      break;
    }
    case 'merdiven': {
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(-7, 6); ctx.lineTo(-3, 6); ctx.lineTo(-3, 2); ctx.lineTo(1, 2);
      ctx.lineTo(1, -2); ctx.lineTo(5, -2); ctx.lineTo(5, -6); ctx.lineTo(8, -6);
      ctx.stroke();
      break;
    }
    case 'asansor': {
      ctx.lineWidth = 2;
      ctx.strokeRect(-7, -8, 14, 16);
      ctx.beginPath();
      ctx.moveTo(-2, 3); ctx.lineTo(-2, -3);
      ctx.moveTo(-4, -1); ctx.lineTo(-2, -4); ctx.lineTo(0, -1);
      ctx.moveTo(2, -3); ctx.lineTo(2, 3);
      ctx.moveTo(0, 1); ctx.lineTo(2, 4); ctx.lineTo(4, 1);
      ctx.stroke();
      break;
    }
    case 'tehlikeli-alan': {
      ctx.lineWidth = 2.2;
      ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(8, 6); ctx.lineTo(-8, 6); ctx.closePath(); ctx.stroke();
      ctx.fillRect(-1, -3.5, 2, 5);
      ctx.beginPath(); ctx.arc(0, 4, 1.2, 0, Math.PI * 2); ctx.fill();
      break;
    }
    case 'giris': {
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, 0, 7, 0.7, Math.PI * 2 - 0.7); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-3, 0); ctx.lineTo(6, 0); ctx.moveTo(3, -3); ctx.lineTo(6, 0); ctx.lineTo(3, 3); ctx.stroke();
      break;
    }
    case 'cikis': {
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(0, 0, 7, -Math.PI / 2 + 0.7, Math.PI / 2 - 0.7, true); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(-6, 0); ctx.lineTo(3, 0); ctx.moveTo(0, -3); ctx.lineTo(-3, 0); ctx.lineTo(0, 3); ctx.stroke();
      break;
    }
    default: {
      ctx.beginPath(); ctx.arc(0, 0, 5.5, 0, Math.PI * 2); ctx.fill();
    }
  }
  ctx.restore();
}

function drawOge(ctx: CanvasRenderingContext2D, o: KrokiOge, secili: boolean): void {
  ctx.save();
  if (o.tip === 'sembol') {
    const t = sembolTanim(o.sembolKey || '');
    drawSembolPiktogram(ctx, o.sembolKey || '', o.x, o.y, t.renk);
    ctx.fillStyle = '#374151';
    ctx.font = '11px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    ctx.fillText(t.ad, o.x, o.y + 16);
  } else if (o.tip === 'metin') {
    ctx.fillStyle = '#0F2747';
    ctx.font = 'bold 16px sans-serif';
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(o.metin || '', o.x, o.y);
  } else if (o.tip === 'alan' || o.tip === 'kutu') {
    const x = Math.min(o.x, o.x + (o.w ?? 0));
    const y = Math.min(o.y, o.y + (o.h ?? 0));
    const w = Math.abs(o.w ?? 0); const h = Math.abs(o.h ?? 0);
    ctx.fillStyle = o.tip === 'alan' ? 'rgba(22,163,74,0.10)' : 'rgba(15,39,71,0.06)';
    ctx.strokeStyle = o.tip === 'alan' ? '#16A34A' : '#0F2747';
    ctx.lineWidth = 2;
    ctx.setLineDash(o.tip === 'alan' ? [6, 4] : []);
    ctx.fillRect(x, y, w, h); ctx.strokeRect(x, y, w, h);
  } else if (o.tip === 'daire') {
    ctx.strokeStyle = '#0F2747';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(o.x, o.y, Math.abs(o.w ?? o.r ?? 0), Math.abs(o.h ?? o.r ?? 0), 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (o.tip === 'cizgi' || o.tip === 'ok' || o.tip === 'rota' || o.tip === 'olcum') {
    const pts = o.pts ?? [];
    if (pts.length < 2) { ctx.restore(); return; }
    const renk = o.tip === 'rota' ? '#15803D' : o.tip === 'olcum' ? '#B45309' : o.tip === 'ok' ? '#B91C1C' : '#1F2937';
    ctx.strokeStyle = renk;
    ctx.lineWidth = o.tip === 'rota' ? 4 : 2.5;
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    if (o.tip === 'rota' || o.tip === 'olcum') ctx.setLineDash(o.tip === 'rota' ? [12, 6] : [5, 4]);
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length; i += 1) ctx.lineTo(pts[i].x, pts[i].y);
    ctx.stroke();
    if (o.tip === 'ok' || o.tip === 'rota') {
      const a = pts[pts.length - 2]; const b = pts[pts.length - 1];
      const ang = Math.atan2(b.y - a.y, b.x - a.x);
      ctx.setLineDash([]);
      ctx.fillStyle = renk;
      const hl = 16;
      ctx.beginPath();
      ctx.moveTo(b.x, b.y);
      ctx.lineTo(b.x - hl * Math.cos(ang - Math.PI / 7), b.y - hl * Math.sin(ang - Math.PI / 7));
      ctx.lineTo(b.x - hl * Math.cos(ang + Math.PI / 7), b.y - hl * Math.sin(ang + Math.PI / 7));
      ctx.closePath(); ctx.fill();
    }
    if (o.tip === 'olcum' && pts.length >= 2) {
      const p0 = pts[0]; const p1 = pts[pts.length - 1];
      const dist = Math.hypot(p1.x - p0.x, p1.y - p0.y);
      ctx.setLineDash([]);
      ctx.fillStyle = '#B45309';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center'; ctx.textBaseline = 'bottom';
      ctx.fillText(`≈ ${(dist * OLCEK_M).toFixed(2)} m`, (p0.x + p1.x) / 2, Math.min(p0.y, p1.y) - 4);
    }
  }
  if (secili) {
    const b = bounds(o);
    ctx.setLineDash([5, 4]);
    ctx.strokeStyle = '#2563EB';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(b.x - 6, b.y - 6, b.w + 12, b.h + 12);
  }
  ctx.restore();
}

function render(ctx: CanvasRenderingContext2D, ogeler: KrokiOge[], zemin: string, img: HTMLImageElement | null, gecici: KrokiOge | null, seciliId: string | null): void {
  ctx.clearRect(0, 0, EN, BOY);
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, EN, BOY);
  if (img && img.complete && img.naturalWidth > 0) {
    const r = Math.min(EN / img.naturalWidth, BOY / img.naturalHeight);
    const w = img.naturalWidth * r; const h = img.naturalHeight * r;
    ctx.drawImage(img, (EN - w) / 2, (BOY - h) / 2, w, h);
  } else if (!zemin) {
    // Izgara (kroki yüklenmeden önce çalışma zemini)
    ctx.strokeStyle = '#EDF2F8'; ctx.lineWidth = 1;
    for (let x = 0; x <= EN; x += 40) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, BOY); ctx.stroke(); }
    for (let y = 0; y <= BOY; y += 40) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(EN, y); ctx.stroke(); }
  }
  ogeler.forEach((o) => drawOge(ctx, o, o.id === seciliId));
  if (gecici) drawOge(ctx, gecici, false);
}

interface Props {
  veri: KrokiVeri;
  onChange: (v: KrokiVeri) => void;
  readOnly?: boolean;
}

export default function TahliyeKrokiCanvas({ veri, onChange, readOnly }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement | null>(null);
  const [ogeler, setOgeler] = useState<KrokiOge[]>(veri.ogeler ?? []);
  const [zemin, setZemin] = useState<string>(veri.zemin ?? '');
  const ogelerRef = useRef<KrokiOge[]>(ogeler);
  ogelerRef.current = ogeler;

  const [arac, setArac] = useState<Arac>('sec');
  const [aktifSembol, setAktifSembol] = useState<string>(SEMBOLLER[0].key);
  const [metin, setMetin] = useState('');
  const [seciliId, setSeciliId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [hata, setHata] = useState<string | null>(null);

  const gecmis = useRef<KrokiOge[][]>([]);
  const ileri = useRef<KrokiOge[][]>([]);
  const baslangic = useRef<KrokiNokta | null>(null);
  const gecici = useRef<KrokiOge | null>(null);
  const tasi = useRef<{ id: string; dx: number; dy: number } | null>(null);
  const pan = useRef<{ x: number; y: number; sl: number; st: number } | null>(null);
  const ciziyor = useRef(false);

  // Arka plan görselini yükle
  useEffect(() => {
    if (!zemin) { imgRef.current = null; ciz(); return; }
    const img = new Image();
    img.onload = () => { imgRef.current = img; ciz(); };
    img.src = zemin;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [zemin]);

  const ciz = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    render(ctx, ogelerRef.current, zemin, imgRef.current, gecici.current, seciliId);
  }, [zemin, seciliId]);

  useEffect(() => { ciz(); }, [ogeler, ciz]);

  // Değişiklikleri dışarıya: düz PNG + JSON
  const yayinla = useCallback((next: KrokiOge[], z: string) => {
    const off = document.createElement('canvas');
    off.width = EN; off.height = BOY;
    const octx = off.getContext('2d');
    let gorsel = '';
    if (octx) {
      render(octx, next, z, imgRef.current, null, null);
      gorsel = off.toDataURL('image/png');
    }
    onChange({ zemin: z, gorsel, ogeler: next, not: veri.not });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [onChange, veri.not]);

  const commit = useCallback((next: KrokiOge[]) => {
    gecmis.current.push(ogelerRef.current);
    if (gecmis.current.length > 100) gecmis.current.shift();
    ileri.current = [];
    setOgeler(next);
    yayinla(next, zemin);
  }, [setOgeler, yayinla, zemin]);

  const geriAl = useCallback(() => {
    if (gecmis.current.length === 0) return;
    ileri.current.push(ogelerRef.current);
    const p = gecmis.current.pop();
    if (p) { setOgeler(p); setSeciliId(null); yayinla(p, zemin); }
  }, [setOgeler, yayinla, zemin]);

  const ileriAl = useCallback(() => {
    if (ileri.current.length === 0) return;
    gecmis.current.push(ogelerRef.current);
    const n = ileri.current.pop();
    if (n) { setOgeler(n); setSeciliId(null); yayinla(n, zemin); }
  }, [setOgeler, yayinla, zemin]);

  const nokta = (e: React.PointerEvent<HTMLCanvasElement>): KrokiNokta => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return { x: (e.clientX - rect.left) * (EN / rect.width), y: (e.clientY - rect.top) * (BOY / rect.height) };
  };

  const silHedefi = (p: KrokiNokta): number => {
    for (let i = ogelerRef.current.length - 1; i >= 0; i -= 1) {
      const b = bounds(ogelerRef.current[i]);
      if (p.x >= b.x - 8 && p.x <= b.x + b.w + 8 && p.y >= b.y - 8 && p.y <= b.y + b.h + 8) return i;
    }
    return -1;
  };

  const basla = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (readOnly) return;
    const p = nokta(e);
    if (arac === 'sec') {
      const idx = silHedefi(p);
      if (idx >= 0) {
        const o = ogelerRef.current[idx];
        setSeciliId(o.id);
        const b = bounds(o);
        gecmis.current.push(ogelerRef.current);
        ileri.current = [];
        tasi.current = { id: o.id, dx: p.x - b.x, dy: p.y - b.y };
      } else setSeciliId(null);
    } else if (arac === 'sil') {
      const idx = silHedefi(p);
      if (idx >= 0) commit(ogelerRef.current.filter((_, i) => i !== idx));
    } else if (arac === 'sembol') {
      const yeni: KrokiOge = { id: yeniOgeId(), tip: 'sembol', sembolKey: aktifSembol, x: p.x, y: p.y };
      commit([...ogelerRef.current, yeni]);
      setSeciliId(yeni.id);
      setArac('sec');
    } else if (arac === 'metin') {
      const t = metin.trim();
      if (t) {
        const yeni: KrokiOge = { id: yeniOgeId(), tip: 'metin', x: p.x, y: p.y, metin: t };
        commit([...ogelerRef.current, yeni]);
        setSeciliId(yeni.id);
        setMetin('');
        setArac('sec');
      }
    } else if (arac === 'alan' || arac === 'kutu' || arac === 'daire' || arac === 'cizgi' || arac === 'ok' || arac === 'rota' || arac === 'olcum') {
      baslangic.current = p;
      gecici.current = { id: 'tmp', tip: arac === 'kutu' ? 'kutu' : arac, x: p.x, y: p.y, w: 0, h: 0, pts: [p, p] };
      ciziyor.current = true;
      ciz();
    }
  };

  const hareket = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (readOnly) return;
    if (pan.current) {
      const el = wrapRef.current;
      if (el) {
        el.scrollLeft = pan.current.sl - (e.clientX - pan.current.x);
        el.scrollTop = pan.current.st - (e.clientY - pan.current.y);
      }
      return;
    }
    const p = nokta(e);
    if (tasi.current) {
      const { id, dx, dy } = tasi.current;
      const yeni = ogelerRef.current.map((o) => {
        if (o.id !== id) return o;
        const b = bounds(o);
        const nx = p.x - dx; const ny = p.y - dy;
        const ox = nx - b.x; const oy = ny - b.y;
        if (o.tip === 'sembol' || o.tip === 'metin') return { ...o, x: o.x + ox, y: o.y + oy };
        if (o.tip === 'daire') return { ...o, x: o.x + ox, y: o.y + oy };
        if (o.pts) return { ...o, pts: o.pts.map((q) => ({ x: q.x + ox, y: q.y + oy })) };
        return { ...o, x: o.x + ox, y: o.y + oy };
      });
      setOgeler(yeni);
      return;
    }
    if (!ciziyor.current || !baslangic.current) return;
    const b = baslangic.current;
    if (arac === 'alan' || arac === 'kutu' || arac === 'daire') {
      gecici.current = { id: 'tmp', tip: arac, x: b.x, y: b.y, w: p.x - b.x, h: p.y - b.y };
    } else {
      const pts = [...(gecici.current?.pts ?? [b]), p];
      gecici.current = { id: 'tmp', tip: arac, x: b.x, y: b.y, pts };
    }
    ciz();
  };

  const bitir = () => {
    if (readOnly) return;
    pan.current = null;
    if (tasi.current) {
      tasi.current = null;
      yayinla(ogelerRef.current, zemin);
      return;
    }
    if (!ciziyor.current) return;
    const g = gecici.current;
    ciziyor.current = false;
    gecici.current = null;
    baslangic.current = null;
    if (!g) { ciz(); return; }
    if (g.tip === 'alan' || g.tip === 'kutu' || g.tip === 'daire') {
      if (Math.abs(g.w ?? 0) > 8 && Math.abs(g.h ?? 0) > 8) {
        const o: KrokiOge = g.tip === 'daire'
          ? { id: yeniOgeId(), tip: 'daire', x: g.x + (g.w ?? 0) / 2, y: g.y + (g.h ?? 0) / 2, w: (g.w ?? 0) / 2, h: (g.h ?? 0) / 2 }
          : { id: yeniOgeId(), tip: g.tip, x: g.x, y: g.y, w: g.w, h: g.h };
        commit([...ogelerRef.current, o]);
      } else ciz();
    } else {
      const pts = g.pts ?? [];
      if (pts.length > 1 && Math.hypot(pts[pts.length - 1].x - pts[0].x, pts[pts.length - 1].y - pts[0].y) > 8) {
        commit([...ogelerRef.current, { id: yeniOgeId(), tip: g.tip, x: g.x, y: g.y, pts }]);
      } else ciz();
    }
  };

  const krokiYukle = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setHata(null);
    try {
      const dataUrl = await readKrokiFile(file);
      setZemin(dataUrl);
      yayinla(ogelerRef.current, dataUrl);
    } catch {
      setHata('Bu dosya okunamadı. PNG, JPG veya PDF deneyin.');
    }
  };

  const kaldir = () => {
    if (readOnly) return;
    setZemin('');
    yayinla(ogelerRef.current, '');
  };

  const tamEkran = () => {
    const el = wrapRef.current?.parentElement;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen();
    else el.requestFullscreen?.();
  };

  const aktifSembolTanim = sembolTanim(aktifSembol);

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-2">
      {/* Araç çubuğu */}
      <div className="flex flex-wrap items-center gap-1">
        {ARACLAR.map((a) => (
          <button
            key={a.key}
            type="button"
            disabled={readOnly}
            onClick={() => setArac(a.key)}
            title={a.label}
            className={`inline-flex items-center gap-1 rounded-md border px-2 py-1.5 text-[11px] font-medium whitespace-nowrap cursor-pointer disabled:opacity-50 ${
              arac === a.key
                ? 'border-primary-500 bg-primary-500 text-inverse'
                : 'border-background-300/60 bg-background-100 text-foreground-700 hover:border-primary-300 dark:border-background-400/30 dark:bg-background-200/40'
            }`}
          >
            <i className={a.icon} /> <span className="hidden sm:inline">{a.label}</span>
          </button>
        ))}
        <span className="mx-0.5 h-5 w-px bg-background-300/60 dark:bg-background-400/30" />
        <button type="button" disabled={readOnly} onClick={geriAl} title="Geri Al" className="w-7 h-7 rounded-md flex items-center justify-center border border-background-300/60 dark:border-background-400/30 text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer disabled:opacity-50"><i className="ri-arrow-go-back-line" /></button>
        <button type="button" disabled={readOnly} onClick={ileriAl} title="Yinele" className="w-7 h-7 rounded-md flex items-center justify-center border border-background-300/60 dark:border-background-400/30 text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer disabled:opacity-50"><i className="ri-arrow-go-forward-line" /></button>
        <button type="button" onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))} title="Uzaklaştır" className="w-7 h-7 rounded-md flex items-center justify-center border border-background-300/60 dark:border-background-400/30 text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer"><i className="ri-zoom-out-line" /></button>
        <span className="text-[11px] text-foreground-500 tabular-nums w-10 text-center">{Math.round(zoom * 100)}%</span>
        <button type="button" onClick={() => setZoom((z) => Math.min(2, +(z + 0.1).toFixed(2)))} title="Yakınlaştır" className="w-7 h-7 rounded-md flex items-center justify-center border border-background-300/60 dark:border-background-400/30 text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer"><i className="ri-zoom-in-line" /></button>
        <button type="button" onClick={tamEkran} title="Tam Ekran" className="w-7 h-7 rounded-md flex items-center justify-center border border-background-300/60 dark:border-background-400/30 text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer"><i className="ri-fullscreen-line" /></button>
      </div>

      {/* Metin / sembol bağlamı */}
      {arac === 'metin' && (
        <input
          value={metin}
          onChange={(e) => setMetin(e.target.value)}
          placeholder="Yerleştirilecek metin"
          className="h-8 w-full max-w-xs rounded-md border border-background-300/70 bg-background-50 px-2.5 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
        />
      )}
      {arac === 'sembol' && (
        <p className="text-[11px] text-foreground-500">Seçili sembol: <strong className="text-foreground-800">{aktifSembolTanim.ad}</strong> — kroki üzerine tıklayarak yerleştirin.</p>
      )}

      {/* Kroki yükle */}
      {!readOnly && (
        <div className="flex items-center gap-2">
          <label className="isg-btn isg-btn-sm isg-btn-secondary cursor-pointer whitespace-nowrap">
            <i className="ri-upload-2-line" /> Kroki Yükle
            <input type="file" accept=".pdf,image/png,image/jpeg,image/webp" className="hidden" onChange={krokiYukle} />
          </label>
          {zemin && (
            <button type="button" onClick={kaldir} className="text-[11px] text-danger-600 hover:text-danger-700 cursor-pointer whitespace-nowrap">
              <i className="ri-delete-bin-line" /> Zemin görselini kaldır
            </button>
          )}
          {hata && <span className="text-[11px] text-danger-600">{hata}</span>}
        </div>
      )}

      <div ref={wrapRef} className="min-h-0 flex-1 max-h-[58vh] overflow-auto rounded-lg border border-background-300/60 bg-white p-2 dark:border-background-400/30">
        <canvas
          ref={canvasRef}
          width={EN}
          height={BOY}
          onPointerDown={basla}
          onPointerMove={hareket}
          onPointerUp={bitir}
          onPointerLeave={bitir}
          onPointerDownCapture={(e) => { if (arac === 'tasima') { const el = wrapRef.current; if (el) pan.current = { x: e.clientX, y: e.clientY, sl: el.scrollLeft, st: el.scrollTop }; } }}
          style={{ width: EN * zoom, height: BOY * zoom, touchAction: 'none', cursor: readOnly ? 'default' : arac === 'sec' ? 'move' : arac === 'tasima' ? 'grab' : 'crosshair' }}
          className="rounded-md border border-background-200"
        />
      </div>

      {/* Sembol paleti */}
      {!readOnly && (
        <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-2">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-semibold uppercase tracking-wide text-foreground-500">Semboller</span>
            <button
              type="button"
              onClick={() => setArac('sembol')}
              className={`text-[11px] font-semibold cursor-pointer whitespace-nowrap ${arac === 'sembol' ? 'text-primary-700' : 'text-primary-600 hover:text-primary-700'}`}
            >
              <i className="ri-add-line" /> Sembol Ekle
            </button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {SEMBOLLER.map((s) => {
              const adet = ogeler.filter((o) => o.tip === 'sembol' && o.sembolKey === s.key).length;
              return (
                <button
                  key={s.key}
                  type="button"
                  onClick={() => { setAktifSembol(s.key); setArac('sembol'); }}
                  title={s.ad}
                  className={`inline-flex items-center gap-1 rounded-md border px-2 py-1 text-[11px] whitespace-nowrap cursor-pointer ${
                    arac === 'sembol' && aktifSembol === s.key
                      ? 'border-primary-400 bg-primary-50 dark:bg-primary-500/15 text-foreground-900'
                      : 'border-background-200/70 dark:border-background-400/25 hover:bg-background-100 dark:hover:bg-background-200/50 text-foreground-700'
                  }`}
                >
                  <i className={s.ikon} style={{ color: s.renk }} /> {s.ad}
                  {adet > 0 && (
                    <span className="ml-0.5 inline-flex min-w-[16px] h-4 items-center justify-center rounded-full bg-foreground-900 text-background-50 text-[9px] px-1 tabular-nums">{adet}</span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}