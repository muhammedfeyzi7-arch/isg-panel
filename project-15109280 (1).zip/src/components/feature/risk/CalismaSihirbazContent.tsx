import { useCallback, useEffect, useState } from 'react';
import Alert from '@/components/ui/Alert';
import { useToastActions } from '@/hooks/useToast';
import { aiCalismaOnerileri } from '@/lib/riskAiService';
import { pdfIndir } from '@/lib/calismaRapor';
import CalismaAdim1Temel from '@/components/feature/risk/calisma/adimlar/CalismaAdim1Temel';
import CalismaAdim2Faaliyetler from '@/components/feature/risk/calisma/adimlar/CalismaAdim2Faaliyetler';
import CalismaAdim3Aylik from '@/components/feature/risk/calisma/adimlar/CalismaAdim3Aylik';
import CalismaAdim4Rapor from '@/components/feature/risk/calisma/adimlar/CalismaAdim4Rapor';
import { calismaWorkspaceKaydet, calismaWorkspaceTemizle, calismaWorkspaceYukle } from '@/components/feature/risk/calismaWorkspaceStore';
import { RwButton, RwStepper } from '@/components/feature/risk/sihirbaz/wizardUi';
import {
  KAPSAM_MADDELERI, aylariUygula, bosCalismaWorkspace, bosFaaliyet, ornekFaaliyetler,
  periyotAylari, sablondanFaaliyet, yeniId,
  type CalismaAiOneri, type CalismaFaaliyet, type CalismaSablon,
  type CalismaTemelBilgiler, type CalismaWorkspace,
} from '@/components/feature/risk/calismaTypes';

// ─────────────────────────────────────────────────────────────────────────────
// YILLIK ÇALIŞMA PLANI SİHİRBAZI — KABUK
//
// 4 adım tek merkezi modal içinde yönetilir (Temel Bilgiler ve Kapsam →
// Faaliyetler → Aylık Planlama → Rapor ve Önizleme). Tüm adımlar aynı workspace'i
// paylaşır. Workspace yerel (IndexedDB) saklanır — KALICI KAYIT YOKTUR, sisteme
// veri gitmez; yalnızca PDF/Word/Excel indirilir.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  onClose: () => void;
}

const CALISMA_ADIM_BASLIKLARI = ['Temel Bilgiler', 'Faaliyetler', 'Aylık Planlama', 'Rapor'];

export default function CalismaSihirbazContent({ onClose }: Props) {
  const { addToast } = useToastActions();
  const [ws, setWs] = useState<CalismaWorkspace>(() => bosCalismaWorkspace());
  const [adim, setAdim] = useState(0);
  const [hazir, setHazir] = useState(false);
  const [sifirlaOnay, setSifirlaOnay] = useState(false);
  const [aiYukleniyor, setAiYukleniyor] = useState(false);
  const [indiriliyor, setIndiriliyor] = useState(false);

  useEffect(() => {
    let iptal = false;
    void calismaWorkspaceYukle().then((kayit) => {
      if (iptal) return;
      if (kayit && Array.isArray(kayit.faaliyetler)) {
        const temel = { ...bosCalismaWorkspace().temel, ...(kayit.temel || {}) };
        setWs({
          ...bosCalismaWorkspace(),
          ...kayit,
          temel: {
            ...temel,
            ekip: Array.isArray(temel.ekip) ? temel.ekip : [],
            dokumanlar: Array.isArray(temel.dokumanlar) ? temel.dokumanlar : [],
            imzacilar: Array.isArray(temel.imzacilar) ? temel.imzacilar : [],
          },
          kapsam: Array.isArray(kayit.kapsam) ? kayit.kapsam : [...KAPSAM_MADDELERI],
          faaliyetler: kayit.faaliyetler.map((f) => ({
            ...f,
            aylar: Array.isArray(f.aylar) && f.aylar.length === 12 ? f.aylar : aylariUygula(periyotAylari(f.periyot || 'Aylık')),
          })),
          aiOnerileri: Array.isArray(kayit.aiOnerileri) ? kayit.aiOnerileri : [],
        });
        setAdim(Math.max(0, Math.min(3, kayit.aktifAdim ?? 0)));
      } else {
        // İlk kullanım: örnek faaliyetlerle başla.
        setWs({ ...bosCalismaWorkspace(), faaliyetler: ornekFaaliyetler() });
      }
      setHazir(true);
    });
    return () => { iptal = true; };
  }, []);

  useEffect(() => {
    if (!hazir) return;
    const t = setTimeout(() => { void calismaWorkspaceKaydet({ ...ws, aktifAdim: adim }); }, 500);
    return () => clearTimeout(t);
  }, [ws, adim, hazir]);

  // ── Temel ──
  const temelGuncelle = useCallback((patch: Partial<CalismaTemelBilgiler>) => {
    setWs((p) => ({ ...p, temel: { ...p.temel, ...patch } }));
  }, []);

  const kapsamGuncelle = useCallback((kapsam: string[]) => {
    setWs((p) => ({ ...p, kapsam }));
  }, []);

  // ── Faaliyet işlemleri ──
  const faaliyetEkle = useCallback(() => {
    setWs((p) => ({ ...p, faaliyetler: [...p.faaliyetler, bosFaaliyet()] }));
  }, []);

  const faaliyetGuncelle = useCallback((id: string, patch: Partial<CalismaFaaliyet>) => {
    setWs((p) => ({ ...p, faaliyetler: p.faaliyetler.map((f) => (f.id === id ? { ...f, ...patch } : f)) }));
  }, []);

  const faaliyetSil = useCallback((id: string) => {
    setWs((p) => ({ ...p, faaliyetler: p.faaliyetler.filter((f) => f.id !== id) }));
  }, []);

  const sablondanEkle = useCallback((s: CalismaSablon) => {
    const yeni = sablondanFaaliyet(s);
    setWs((p) => ({ ...p, faaliyetler: [...p.faaliyetler, yeni] }));
    addToast({ title: 'Şablondan eklendi', message: s.faaliyet, type: 'success' });
  }, [addToast]);

  // ── AI ──
  const aiYenile = useCallback(async () => {
    if (aiYukleniyor) return;
    setAiYukleniyor(true);
    try {
      const cevap = await aiCalismaOnerileri({
        firma: ws.temel.firma,
        tesis: ws.temel.tesis,
        nace: ws.temel.nace,
        tehlikeSinifi: ws.temel.tehlikeSinifi,
        planYili: ws.temel.planYili,
        kapsam: ws.kapsam,
        mevcutFaaliyetler: ws.faaliyetler.map((f) => f.faaliyet).filter(Boolean),
        oncekiOneriler: ws.aiOnerileri.map((o) => o.faaliyet),
      });
      if (cevap.ok && cevap.oneriler) {
        const yeni: CalismaAiOneri[] = cevap.oneriler.map((o) => ({ id: yeniId('ca'), ...o }));
        setWs((p) => ({ ...p, aiOnerileri: [...yeni, ...p.aiOnerileri] }));
        addToast({ title: 'AI önerileri hazır', message: `${yeni.length} yeni faaliyet önerildi.`, type: 'success' });
      } else {
        addToast({ title: 'AI önerisi alınamadı', message: cevap.message || 'Lütfen tekrar deneyin.', type: 'warning' });
      }
    } catch {
      addToast({ title: 'AI bağlantı hatası', message: 'Lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setAiYukleniyor(false);
    }
  }, [aiYukleniyor, ws, addToast]);

  const oneriEkle = useCallback((o: CalismaAiOneri) => {
    const faaliyet: CalismaFaaliyet = {
      id: yeniId('cf'),
      kategori: o.kategori,
      faaliyet: o.faaliyet,
      aciklama: o.aciklama,
      sorumlu: '',
      periyot: o.periyot,
      oncelik: o.oncelik,
      aylar: aylariUygula(periyotAylari(o.periyot)),
    };
    setWs((p) => ({
      ...p,
      faaliyetler: [...p.faaliyetler, faaliyet],
      aiOnerileri: p.aiOnerileri.filter((x) => x.id !== o.id),
    }));
    addToast({ title: 'Faaliyete eklendi', message: o.faaliyet, type: 'success' });
  }, [addToast]);

  // ── Planlama ──
  const tumunuTemizle = useCallback(() => {
    setWs((p) => ({ ...p, faaliyetler: p.faaliyetler.map((f) => ({ ...f, aylar: aylariUygula([]) })) }));
  }, []);

  const onerilenUygula = useCallback(() => {
    setWs((p) => ({ ...p, faaliyetler: p.faaliyetler.map((f) => ({ ...f, aylar: aylariUygula(periyotAylari(f.periyot)) })) }));
    addToast({ title: 'Önerilen plan uygulandı', message: 'Faaliyetler periyotlarına göre yerleştirildi.', type: 'success' });
  }, [addToast]);

  // ── Adım doğrulama ──
  const adimGecerli = useCallback((idx: number): string | null => {
    if (idx === 0) {
      if (!ws.temel.calismaAdi.trim()) return 'Plan Adı zorunludur.';
      if (!ws.temel.tesis.trim()) return 'Tesis / İş Yeri zorunludur.';
    }
    if (idx === 1) {
      if (ws.faaliyetler.length === 0) return 'Devam etmek için en az bir faaliyet ekleyin.';
      if (ws.faaliyetler.some((f) => !f.faaliyet.trim())) return 'Tüm faaliyetlerin adı doldurulmalıdır.';
    }
    return null;
  }, [ws.temel, ws.faaliyetler]);

  const sonraki = useCallback(() => {
    const hata = adimGecerli(adim);
    if (hata) { addToast({ title: 'Eksik bilgi', message: hata, type: 'warning' }); return; }
    setAdim((a) => Math.min(3, a + 1));
  }, [adim, adimGecerli, addToast]);

  const sifirla = useCallback(async () => {
    await calismaWorkspaceTemizle();
    setWs(bosCalismaWorkspace());
    setAdim(0);
    setSifirlaOnay(false);
    addToast({ title: 'Çalışma sıfırlandı', message: 'Yeni bir yıllık çalışma planına başlayabilirsiniz.', type: 'success' });
  }, [addToast]);

  const hizliPdf = useCallback(async () => {
    if (ws.faaliyetler.length === 0) {
      addToast({ title: 'Faaliyet listesi boş', message: 'Rapor için en az bir faaliyet gerekir.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndiriliyor(true);
    try {
      await pdfIndir({ temel: ws.temel, kapsam: ws.kapsam, faaliyetler: ws.faaliyetler });
      addToast({ title: 'Plan hazır', message: 'PDF indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Plan oluşturulamadı', message: 'Beklenmeyen bir hata oluştu.', type: 'error' });
    } finally {
      setIndiriliyor(false);
    }
  }, [ws, addToast, indiriliyor]);

  if (!hazir) {
    return (
      <div className="flex min-h-0 flex-1 items-center justify-center">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex-shrink-0 border-b border-background-300/25 dark:border-background-400/35">
        <RwStepper steps={CALISMA_ADIM_BASLIKLARI} current={adim} onStepClick={(idx) => { if (idx < adim) setAdim(idx); }} />
      </div>

      <div className="flex min-h-0 flex-1 overflow-hidden px-5 py-4">
        {adim === 0 && (
          <CalismaAdim1Temel temel={ws.temel} kapsam={ws.kapsam} onChange={temelGuncelle} onKapsamChange={kapsamGuncelle} />
        )}
        {adim === 1 && (
          <CalismaAdim2Faaliyetler
            faaliyetler={ws.faaliyetler}
            aiOnerileri={ws.aiOnerileri}
            aiYukleniyor={aiYukleniyor}
            onEkle={faaliyetEkle}
            onGuncelle={faaliyetGuncelle}
            onSil={faaliyetSil}
            onAiYenile={() => void aiYenile()}
            onOneriEkle={oneriEkle}
            onSablondanEkle={sablondanEkle}
          />
        )}
        {adim === 2 && (
          <CalismaAdim3Aylik
            faaliyetler={ws.faaliyetler}
            onGuncelle={faaliyetGuncelle}
            onTumunuTemizle={tumunuTemizle}
            onOnerilenUygula={onerilenUygula}
            onFaaliyetDuzenle={() => setAdim(1)}
          />
        )}
        {adim === 3 && (
          <CalismaAdim4Rapor
            temel={ws.temel}
            kapsam={ws.kapsam}
            faaliyetler={ws.faaliyetler}
            onTemelChange={temelGuncelle}
          />
        )}
      </div>

      <div className="flex flex-shrink-0 items-center justify-between gap-2 border-t isg-divider px-5 py-3">
        <div className="flex items-center gap-2">
          <RwButton variant="ghost" icon="ri-close-line" onClick={onClose}>İptal</RwButton>
          {sifirlaOnay ? (
            <Alert
              variant="danger"
              action={(
                <div className="flex items-center gap-2">
                  <RwButton variant="primary" size="sm" icon="ri-refresh-line" onClick={() => void sifirla()}>Evet, Sıfırla</RwButton>
                  <RwButton variant="ghost" size="sm" onClick={() => setSifirlaOnay(false)}>Vazgeç</RwButton>
                </div>
              )}
            >
              Tüm plan silinsin mi?
            </Alert>
          ) : (
            <RwButton variant="ghost" icon="ri-refresh-line" onClick={() => setSifirlaOnay(true)}>Sıfırla</RwButton>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden text-xs text-foreground-400 sm:inline">
            <i className="ri-information-line mr-1" /> Bu çalışma geçici olarak tutulur; kalıcı kayıt oluşturmaz.
          </span>
          {adim > 0 && (
            <RwButton variant="secondary" icon="ri-arrow-left-line" onClick={() => setAdim((a) => Math.max(0, a - 1))}>Önceki Adım</RwButton>
          )}
          {adim < 3
            ? <RwButton variant="primary" iconAfter="ri-arrow-right-line" onClick={sonraki}>Sonraki Adım</RwButton>
            : <RwButton variant="primary" icon="ri-file-download-line" onClick={() => void hizliPdf()}>{indiriliyor ? 'Oluşturuluyor...' : 'Planı Oluştur ve İndir'}</RwButton>}
        </div>
      </div>
    </div>
  );
}