// ─────────────────────────────────────────────────────────────────────────────
// RİSK SİHİRBazi — GEÇİCİ ÇALIŞMA ALANI DEPOSU
//
// Kullanıcı sihirbazı yarıda bırakıp tekrar açtığında kaldığı yerden devam
// edebilsin diye workspace YEREL olarak (IndexedDB) saklanır. Bu bir KALICI
// KAYIT / ARŞİV / yayınlanmış belge DEĞİLDİR; yalnızca oturumlar arası devam
// kolaylığıdır ve İSG gereksinimlerinde "tamamlanmış kayıt" sayılmaz.
//
// Yapısal veri olduğu için localStorage DEĞİL, IndexedDB kullanılır.
// ─────────────────────────────────────────────────────────────────────────────
import { bosWorkspace, type RiskWorkspace } from './riskSihirbazTypes';

const DB_NAME = 'isgdenetim-risk-sihirbaz';
const DB_VERSION = 1;
const STORE = 'workspace';
const KAYIT_ID = 'aktif';

function hasIdb(): boolean {
  return typeof indexedDB !== 'undefined';
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

/** Kayıtlı geçici çalışma alanını yükler; yoksa null döner. */
export async function workspaceYukle(): Promise<RiskWorkspace | null> {
  if (!hasIdb()) return null;
  try {
    const db = await openDb();
    return await new Promise<RiskWorkspace | null>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const req = tx.objectStore(STORE).get(KAYIT_ID);
      req.onsuccess = () => {
        const val = req.result as RiskWorkspace | undefined;
        resolve(val ?? null);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

/** Geçici çalışma alanını kaydeder (upsert). Hata durumunda sessizce yutulur. */
export async function workspaceKaydet(ws: RiskWorkspace): Promise<void> {
  if (!hasIdb()) return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put({ ...ws, guncellendi: new Date().toISOString() }, KAYIT_ID);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // Yerel kayıt başarısız olsa bile sihirbaz çalışmaya devam eder.
  }
}

/** Geçici çalışma alanını temizler (yeni çalışma başlatıldığında). */
export async function workspaceTemizle(): Promise<void> {
  if (!hasIdb()) return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(KAYIT_ID);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // yut
  }
}

export function bosWorkspaceAl(): RiskWorkspace {
  return bosWorkspace();
}