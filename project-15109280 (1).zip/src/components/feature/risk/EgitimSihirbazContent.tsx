import { useCallback, useEffect, useState } from 'react';
import Alert from '@/components/ui/Alert';
import { useToastActions } from '@/hooks/useToast';
import { aiEgitimOnerileri } from '@/lib/riskAiService';
import { pdfIndir } from '@/lib/egitimRapor';
import EgitimAdim1Temel from '@/components/feature/risk/egitim/adimlar/EgitimAdim1Temel';
import EgitimAdim2Egitimler from '@/components/feature/risk/egitim/adimlar/EgitimAdim2Egitimler';
import EgitimAdim3Aylik from '@/components/feature/risk/egitim/adimlar/EgitimAdim3Aylik';
import EgitimAdim4Rapor from '@/components/feature/risk/egitim/adimlar/EgitimAdim4Rapor';
import { egitimWorkspaceKaydet, egitimWorkspaceTemizle, egitimWorkspaceYukle } from '@/components/feature/risk/egitimWorkspaceStore';
import { RwButton, RwStepper } from '@/components/feature/risk/sihirbaz/wizardUi';
import {
  KAPSAM_MADDELERI, aylariUygula, bosEgitimWorkspace, bosEgitim, ornekEgitimler,
  periyotAylari, sablondanEgitim, yeniId,
  type EgitimAiOneri, type EgitimKaydi, type EgitimSablon,
  type EgitimTemelBilgiler, type EgitimWorkspace,
} from '@/components/feature/risk/egitimTypes';

// ─────────────────────────────────────────────────────────────────────────────
// YILLIK EĞİTİM PLANI SİHİRBAZI — KABUK
//
// 4 adım tek merkezi modal içinde yönetilir (Temel Bilgiler ve Kapsam → Eğitimler
// → Aylık Planlama → Rapor ve Önizleme). Tüm adımlar aynı workspace'i paylaşır.
// Workspace yerel (IndexedDB) saklanır — KALICI KAYIT YOKTUR; yalnızca Word/PDF/
// Excel/CSV/TXT indirilir.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  onClose: () => void;
}

const EGITIM_ADIM_BASLIKLARI = ['Temel Bilgiler', 'Eğitimler', 'Aylık Planlama', 'Rapor'];

export default function EgitimSihirbazContent({ onClose }: Props) {
  const { addToast } = useToastActions();
  const [ws, setWs] = useState<EgitimWorkspace>(() => bosEgitimWorkspace());
  const [adim, setAdim] = useState(0);
  const [hazir, setHazir] = useState(false);
  const [sifirlaOnay, setSifirlaOnay] = useState(false);
  const [aiYukleniyor, setAiYukleniyor] = useState(false);
  const [indiriliyor, setIndiriliyor] = useState(false);

  useEffect(() => {
    let iptal = false;
    void egitimWorkspaceYukle().then((kayit) => {
      if (iptal) return;
      if (kayit && Array.isArray(kayit.egitimler)) {
        const temel = { ...bosEgitimWorkspace().temel, ...(kayit.temel || {}) };
        setWs({
          ...bosEgitimWorkspace(),
          ...kayit,
          temel: {
            ...temel,
            ekip: Array.isArray(temel.ekip) ? temel.ekip : [],
            dokumanlar: Array.isArray(temel.dokumanlar) ? temel.dokumanlar : [],
            imzacilar: Array.isArray(temel.imzacilar) ? temel.imzacilar : [],
          },
          kapsam: Array.isArray(kayit.kapsam) ? kayit.kapsam : [...KAPSAM_MADDELERI],
          egitimler: kayit.egitimler.map((e) => ({
            ...e,
            aylar: Array.isArray(e.aylar) && e.aylar.length === 12 ? e.aylar : aylariUygula(periyotAylari(e.periyot || 'Yıllık')),
          })),
          aiOnerileri: Array.isArray(kayit.aiOnerileri) ? kayit.aiOnerileri : [],
        });
        setAdim(Math.max(0, Math.min(3, kayit.aktifAdim ?? 0)));
      } else {
        setWs({ ...bosEgitimWorkspace(), egitimler: ornekEgitimler() });
      }
      setHazir(true);
    });
    return () => { iptal = true; };
  }, []);

  useEffect(() => {
    if (!hazir) return;
    const t = setTimeout(() => { void egitimWorkspaceKaydet({ ...ws, aktifAdim: adim }); }, 500);
    return () => clearTimeout(t);
  }, [ws, adim, hazir]);

  // ── Temel ──
  const temelGuncelle = useCallback((patch: Partial<EgitimTemelBilgiler>) => {
    setWs((p) => ({ ...p, temel: { ...p.temel, ...patch } }));
  }, []);

  const kapsamGuncelle = useCallback((kapsam: string[]) => {
    setWs((p) => ({ ...p, kapsam }));
  }, []);

  // ── Eğitim işlemleri ──
  const egitimEkle = useCallback(() => {
    setWs((p) => ({ ...p, egitimler: [...p.egitimler, bosEgitim()] }));
  }, []);

  const egitimGuncelle = useCallback((id: string, patch: Partial<EgitimKaydi>) => {
    setWs((p) => ({ ...p, egitimler: p.egitimler.map((e) => (e.id === id ? { ...e, ...patch } : e)) }));
  }, []);

  const egitimSil = useCallback((id: string) => {
    setWs((p) => ({ ...p, egitimler: p.egitimler.filter((e) => e.id !== id) }));
  }, []);

  const sablondanEkle = useCallback((s: EgitimSablon) => {
    const yeni = sablondanEgitim(s);
    setWs((p) => ({ ...p, egitimler: [...p.egitimler, yeni] }));
    addToast({ title: 'Şablondan eklendi', message: s.egitim, type: 'success' });
  }, [addToast]);

  // ── AI ──
  const aiYenile = useCallback(async () => {
    if (aiYukleniyor) return;
    setAiYukleniyor(true);
    try {
      const cevap = await aiEgitimOnerileri({
        firma: ws.temel.firma,
        tesis: ws.temel.tesis,
        nace: ws.temel.nace,
        tehlikeSinifi: ws.temel.tehlikeSinifi,
        planYili: ws.temel.planYili,
        kapsam: ws.kapsam,
        mevcutEgitimler: ws.egitimler.map((e) => e.egitim).filter(Boolean),
        oncekiOneriler: ws.aiOnerileri.map((o) => o.egitim),
      });
      if (cevap.ok && cevap.oneriler) {
        const yeni: EgitimAiOneri[] = cevap.oneriler.map((o) => ({ id: yeniId('ea'), ...o }));
        setWs((p) => ({ ...p, aiOnerileri: [...yeni, ...p.aiOnerileri] }));
        addToast({ title: 'AI önerileri hazır', message: `${yeni.length} yeni eğitim önerildi.`, type: 'success' });
      } else {
        addToast({ title: 'AI önerisi alınamadı', message: cevap.message || 'Lütfen tekrar deneyin.', type: 'warning' });
      }
    } catch {
      addToast({ title: 'AI bağlantı hatası', message: 'Lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setAiYukleniyor(false);
    }
  }, [aiYukleniyor, ws, addToast]);

  const oneriEkle = useCallback((o: EgitimAiOneri) => {
    const egitim: EgitimKaydi = {
      id: yeniId('eg'),
      kategori: o.kategori,
      egitim: o.egitim,
      aciklama: o.aciklama,
      tur: o.tur,
      hedefGrup: o.hedefGrup || 'Tüm Çalışanlar',
      egitici: '',
      sure: o.sure,
      periyot: o.periyot,
      oncelik: o.oncelik,
      aylar: aylariUygula(periyotAylari(o.periyot)),
    };
    setWs((p) => ({
      ...p,
      egitimler: [...p.egitimler, egitim],
      aiOnerileri: p.aiOnerileri.filter((x) => x.id !== o.id),
    }));
    addToast({ title: 'Eğitime eklendi', message: o.egitim, type: 'success' });
  }, [addToast]);

  // ── Planlama ──
  const tumunuTemizle = useCallback(() => {
    setWs((p) => ({ ...p, egitimler: p.egitimler.map((e) => ({ ...e, aylar: aylariUygula([]) })) }));
  }, []);

  const onerilenUygula = useCallback(() => {
    setWs((p) => ({ ...p, egitimler: p.egitimler.map((e) => ({ ...e, aylar: aylariUygula(periyotAylari(e.periyot)) })) }));
    addToast({ title: 'Önerilen plan uygulandı', message: 'Eğitimler periyotlarına göre yerleştirildi.', type: 'success' });
  }, [addToast]);

  // ── Adım doğrulama ──
  const adimGecerli = useCallback((idx: number): string | null => {
    if (idx === 0) {
      if (!ws.temel.calismaAdi.trim()) return 'Plan Adı zorunludur.';
      if (!ws.temel.tesis.trim()) return 'Tesis / İş Yeri zorunludur.';
    }
    if (idx === 1) {
      if (ws.egitimler.length === 0) return 'Devam etmek için en az bir eğitim ekleyin.';
      if (ws.egitimler.some((e) => !e.egitim.trim())) return 'Tüm eğitimlerin konusu doldurulmalıdır.';
    }
    return null;
  }, [ws.temel, ws.egitimler]);

  const sonraki = useCallback(() => {
    const hata = adimGecerli(adim);
    if (hata) { addToast({ title: 'Eksik bilgi', message: hata, type: 'warning' }); return; }
    setAdim((a) => Math.min(3, a + 1));
  }, [adim, adimGecerli, addToast]);

  const sifirla = useCallback(async () => {
    await egitimWorkspaceTemizle();
    setWs(bosEgitimWorkspace());
    setAdim(0);
    setSifirlaOnay(false);
    addToast({ title: 'Çalışma sıfırlandı', message: 'Yeni bir yıllık eğitim planına başlayabilirsiniz.', type: 'success' });
  }, [addToast]);

  const hizliPdf = useCallback(async () => {
    if (ws.egitimler.length === 0) {
      addToast({ title: 'Eğitim listesi boş', message: 'Rapor için en az bir eğitim gerekir.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndiriliyor(true);
    try {
      await pdfIndir({ temel: ws.temel, kapsam: ws.kapsam, egitimler: ws.egitimler });
      addToast({ title: 'Plan hazır', message: 'PDF indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Plan oluşturulamadı', message: 'Beklenmeyen bir hata oluştu.', type: 'error' });
    } finally {
      setIndiriliyor(false);
    }
  }, [ws, addToast, indiriliyor]);

  if (!hazir) {
    return (
      <div className="flex min-h-0 flex-1 items-center justify-center">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex-shrink-0 border-b border-background-300/25 dark:border-background-400/35">
        <RwStepper steps={EGITIM_ADIM_BASLIKLARI} current={adim} onStepClick={(idx) => { if (idx < adim) setAdim(idx); }} />
      </div>

      <div className="flex min-h-0 flex-1 overflow-hidden px-5 py-4">
        {adim === 0 && (
          <EgitimAdim1Temel temel={ws.temel} kapsam={ws.kapsam} onChange={temelGuncelle} onKapsamChange={kapsamGuncelle} />
        )}
        {adim === 1 && (
          <EgitimAdim2Egitimler
            egitimler={ws.egitimler}
            aiOnerileri={ws.aiOnerileri}
            aiYukleniyor={aiYukleniyor}
            onEkle={egitimEkle}
            onGuncelle={egitimGuncelle}
            onSil={egitimSil}
            onAiYenile={() => void aiYenile()}
            onOneriEkle={oneriEkle}
            onSablondanEkle={sablondanEkle}
          />
        )}
        {adim === 2 && (
          <EgitimAdim3Aylik
            egitimler={ws.egitimler}
            onGuncelle={egitimGuncelle}
            onTumunuTemizle={tumunuTemizle}
            onOnerilenUygula={onerilenUygula}
            onEgitimDuzenle={() => setAdim(1)}
          />
        )}
        {adim === 3 && (
          <EgitimAdim4Rapor
            temel={ws.temel}
            kapsam={ws.kapsam}
            egitimler={ws.egitimler}
            onTemelChange={temelGuncelle}
          />
        )}
      </div>

      <div className="flex flex-shrink-0 items-center justify-between gap-2 border-t isg-divider px-5 py-3">
        <div className="flex items-center gap-2">
          <RwButton variant="ghost" icon="ri-close-line" onClick={onClose}>İptal</RwButton>
          {sifirlaOnay ? (
            <Alert
              variant="danger"
              action={(
                <div className="flex items-center gap-2">
                  <RwButton variant="primary" size="sm" icon="ri-refresh-line" onClick={() => void sifirla()}>Evet, Sıfırla</RwButton>
                  <RwButton variant="ghost" size="sm" onClick={() => setSifirlaOnay(false)}>Vazgeç</RwButton>
                </div>
              )}
            >
              Tüm plan silinsin mi?
            </Alert>
          ) : (
            <RwButton variant="ghost" icon="ri-refresh-line" onClick={() => setSifirlaOnay(true)}>Sıfırla</RwButton>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden text-xs text-foreground-400 sm:inline">
            <i className="ri-information-line mr-1" /> Bu çalışma geçici olarak tutulur; kalıcı kayıt oluşturmaz.
          </span>
          {adim > 0 && (
            <RwButton variant="secondary" icon="ri-arrow-left-line" onClick={() => setAdim((a) => Math.max(0, a - 1))}>Önceki Adım</RwButton>
          )}
          {adim < 3
            ? <RwButton variant="primary" iconAfter="ri-arrow-right-line" onClick={sonraki}>Sonraki Adım</RwButton>
            : <RwButton variant="primary" icon="ri-file-download-line" onClick={() => void hizliPdf()}>{indiriliyor ? 'Oluşturuluyor...' : 'Planı Oluştur ve İndir'}</RwButton>}
        </div>
      </div>
    </div>
  );
}