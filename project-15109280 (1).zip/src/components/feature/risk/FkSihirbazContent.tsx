import { useCallback, useEffect, useMemo, useState } from 'react';
import Alert from '@/components/ui/Alert';
import { useToastActions } from '@/hooks/useToast';
import { aiTehlikeOnerileri } from '@/lib/riskAiService';
import { pdfIndir } from '@/lib/fineKinneyRapor';
import FkAdim1Temel from '@/components/feature/risk/fk/adimlar/FkAdim1Temel';
import FkAdim2Tehlikeler from '@/components/feature/risk/fk/adimlar/FkAdim2Tehlikeler';
import FkAdim3Kontroller from '@/components/feature/risk/fk/adimlar/FkAdim3Kontroller';
import FkAdim4Degerlendirme from '@/components/feature/risk/fk/adimlar/FkAdim4Degerlendirme';
import FkAdim5Rapor from '@/components/feature/risk/fk/adimlar/FkAdim5Rapor';
import type { FkManuelVerisi } from '@/components/feature/risk/fk/FkManuelRiskModal';
import { fkWorkspaceKaydet, fkWorkspaceTemizle, fkWorkspaceYukle } from '@/components/feature/risk/fkWorkspaceStore';
import { RwButton, RwStepper } from '@/components/feature/risk/sihirbaz/wizardUi';
import {
  FK_ADIM_BASLIKLARI, fkBosRisk, bosFkWorkspace,
  benzerMi, fkOlasiYakin, fkFrekansYakin, fkSiddetYakin, yeniId,
  type FkAiOneri, type FkRiskItem, type FkWorkspace, type TemelBilgiler,
} from '@/components/feature/risk/fkTypes';

// ─────────────────────────────────────────────────────────────────────────────
// FINE-KINNEY SİHİRBAZI — KABUK
//
// 5 adım tek merkezi modal içinde yönetilir. Tüm adımlar aynı workspace'i
// paylaşır; adım 2'de oluşan risk 3 ve 4'e yansır, 5'in çıktısı rapora gider.
// Workspace yerel (IndexedDB) saklanır — KALICI KAYIT YOKTUR, sisteme veri gitmez.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  onClose: () => void;
}

export default function FkSihirbazContent({ onClose }: Props) {
  const { addToast } = useToastActions();
  const [ws, setWs] = useState<FkWorkspace>(() => bosFkWorkspace());
  const [adim, setAdim] = useState(0);
  const [hazir, setHazir] = useState(false);
  const [aiYukleniyor, setAiYukleniyor] = useState(false);
  const [sifirlaOnay, setSifirlaOnay] = useState(false);
  const [indiriliyor, setIndiriliyor] = useState(false);

  useEffect(() => {
    let iptal = false;
    void fkWorkspaceYukle().then((kayit) => {
      if (iptal) return;
      if (kayit && Array.isArray(kayit.riskler)) {
        const temel = { ...bosFkWorkspace().temel, ...(kayit.temel || {}) };
        setWs({
          ...bosFkWorkspace(),
          ...kayit,
          temel: {
            ...temel,
            ekip: Array.isArray(temel.ekip) ? temel.ekip : [],
            dokumanlar: Array.isArray(temel.dokumanlar) ? temel.dokumanlar : [],
            imzacilar: Array.isArray(temel.imzacilar) ? temel.imzacilar : [],
          },
          riskler: kayit.riskler,
          aiOnerileri: Array.isArray(kayit.aiOnerileri) ? kayit.aiOnerileri : [],
        });
        setAdim(Math.max(0, Math.min(4, kayit.aktifAdim ?? 0)));
      }
      setHazir(true);
    });
    return () => { iptal = true; };
  }, []);

  useEffect(() => {
    if (!hazir) return;
    const t = setTimeout(() => { void fkWorkspaceKaydet({ ...ws, aktifAdim: adim }); }, 500);
    return () => clearTimeout(t);
  }, [ws, adim, hazir]);

  const temelGuncelle = useCallback((patch: Partial<TemelBilgiler>) => {
    setWs((p) => ({ ...p, temel: { ...p.temel, ...patch } }));
  }, []);

  const manuelEkle = useCallback((veri: FkManuelVerisi) => {
    setWs((p) => ({ ...p, riskler: [...p.riskler, { ...fkBosRisk(veri.bolum, 'manuel'), ...veri }] }));
    addToast({ title: 'Risk eklendi', message: 'Manuel risk listeye eklendi.', type: 'success' });
  }, [addToast]);

  const aiEkle = useCallback((o: FkAiOneri) => {
    const yeni: FkRiskItem = {
      ...fkBosRisk(o.bolum, 'ai'),
      kategori: o.kategori, tehlike: o.tehlike, risk: o.risk, olasiSonuc: o.olasiSonuc,
      mevcutKontroller: o.mevcutKontroller, onerilenKontroller: o.onerilenKontroller,
      olasilik: o.olasilik, frekans: o.frekans, siddet: o.siddet,
    };
    setWs((p) => {
      if (p.riskler.some((r) => benzerMi(`${r.tehlike} ${r.risk}`, `${o.tehlike} ${o.risk}`))) return p;
      return { ...p, riskler: [...p.riskler, yeni] };
    });
  }, []);

  const topluEkle = useCallback((liste: FkRiskItem[]) => {
    setWs((p) => {
      const yeniler = liste
        .filter((r) => r.tehlike && r.risk)
        .filter((r) => !p.riskler.some((x) => benzerMi(`${x.tehlike} ${x.risk}`, `${r.tehlike} ${r.risk}`)))
        .map((r) => ({ ...r, id: r.id || yeniId('fk') }));
      return { ...p, riskler: [...p.riskler, ...yeniler] };
    });
  }, []);

  const guncelle = useCallback((id: string, patch: Partial<FkRiskItem>) => {
    setWs((p) => ({ ...p, riskler: p.riskler.map((r) => (r.id === id ? { ...r, ...patch } : r)) }));
  }, []);

  const sil = useCallback((id: string) => {
    setWs((p) => ({ ...p, riskler: p.riskler.filter((r) => r.id !== id) }));
  }, []);

  const aiYenile = useCallback(async (kategori: string, alan: string) => {
    setAiYukleniyor(true);
    const cevap = await aiTehlikeOnerileri({
      firma: ws.temel.firma,
      tesis: ws.temel.tesis,
      kapsam: ws.temel.kapsam,
      nace: ws.temel.nace,
      tehlikeSinifi: ws.temel.tehlikeSinifi,
      kategori,
      alan,
      yontem: 'fine-kinney',
      mevcutRiskler: ws.riskler.map((r) => `${r.tehlike} — ${r.risk}`),
      oncekiOneriler: ws.aiOnerileri.map((o) => `${o.tehlike} — ${o.risk}`),
    });
    setAiYukleniyor(false);
    if (!cevap.ok || !cevap.oneriler) {
      addToast({ title: 'AI önerileri alınamadı', message: cevap.message || 'Lütfen tekrar deneyin.', type: 'error' });
      return;
    }
    setWs((p) => {
      const mevcut = [...p.aiOnerileri.map((o) => `${o.tehlike} ${o.risk}`), ...p.riskler.map((r) => `${r.tehlike} ${r.risk}`)];
      const benzersiz: FkAiOneri[] = [];
      cevap.oneriler!.forEach((o) => {
        const anahtar = `${o.tehlike} ${o.risk}`;
        const tekrar = mevcut.some((m) => benzerMi(m, anahtar)) || benzersiz.some((b) => benzerMi(`${b.tehlike} ${b.risk}`, anahtar));
        if (!tekrar) {
          benzersiz.push({
            id: yeniId('fkai'),
            kategori: o.kategori, bolum: o.bolum, tehlike: o.tehlike, risk: o.risk,
            olasiSonuc: o.olasiSonuc, mevcutKontroller: o.mevcutKontroller, onerilenKontroller: o.onerilenKontroller,
            olasilik: fkOlasiYakin(o.olasilik), frekans: fkFrekansYakin(o.frekans ?? 6), siddet: fkSiddetYakin(o.siddet),
          });
        }
      });
      return { ...p, aiOnerileri: [...p.aiOnerileri, ...benzersiz] };
    });
    addToast({ title: 'AI önerileri hazır', message: 'Yeni öneriler listenin altına eklendi.', type: 'success' });
  }, [ws.temel, ws.riskler, ws.aiOnerileri, addToast]);

  const adimGecerli = useCallback((idx: number): string | null => {
    if (idx === 0) {
      if (!ws.temel.calismaAdi.trim()) return 'Çalışma Adı zorunludur.';
      if (!ws.temel.tesis.trim()) return 'Tesis / İş yeri zorunludur.';
      if (!ws.temel.kapsam.trim()) return 'Çalışmanın Kapsamı zorunludur.';
    }
    if (idx === 1 && ws.riskler.length === 0) return 'Devam etmek için en az bir risk ekleyin.';
    return null;
  }, [ws.temel, ws.riskler]);

  const sonraki = useCallback(() => {
    const hata = adimGecerli(adim);
    if (hata) { addToast({ title: 'Eksik bilgi', message: hata, type: 'warning' }); return; }
    setAdim((a) => Math.min(4, a + 1));
  }, [adim, adimGecerli, addToast]);

  const sifirla = useCallback(async () => {
    await fkWorkspaceTemizle();
    setWs(bosFkWorkspace());
    setAdim(0);
    setSifirlaOnay(false);
    addToast({ title: 'Çalışma sıfırlandı', message: 'Yeni bir değerlendirmeye başlayabilirsiniz.', type: 'success' });
  }, [addToast]);

  const raporIndir = useCallback(async () => {
    if (ws.riskler.length === 0) {
      addToast({ title: 'Risk listesi boş', message: 'Rapor için en az bir risk gerekir.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndiriliyor(true);
    try {
      await pdfIndir({ temel: ws.temel, riskler: ws.riskler });
      addToast({ title: 'Rapor hazır', message: 'PDF indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Rapor oluşturulamadı', message: 'Beklenmeyen bir hata oluştu.', type: 'error' });
    } finally {
      setIndiriliyor(false);
    }
  }, [ws.temel, ws.riskler, addToast, indiriliyor]);

  const stepperAdimlari = useMemo(() => FK_ADIM_BASLIKLARI, []);

  if (!hazir) {
    return (
      <div className="flex min-h-0 flex-1 items-center justify-center">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex-shrink-0 border-b border-background-300/25 dark:border-background-400/35">
        <RwStepper steps={stepperAdimlari} current={adim} onStepClick={(idx) => { if (idx < adim) setAdim(idx); }} />
      </div>

      <div className="flex min-h-0 flex-1 flex-col overflow-hidden px-5 py-4">
        {adim === 0 && <FkAdim1Temel temel={ws.temel} onChange={temelGuncelle} />}
        {adim === 1 && (
          <FkAdim2Tehlikeler
            riskler={ws.riskler} aiOnerileri={ws.aiOnerileri} aiYukleniyor={aiYukleniyor}
            onAiYenile={aiYenile} onAiEkle={aiEkle} onManuelEkle={manuelEkle}
            onTopluEkle={topluEkle} onGuncelle={guncelle} onSil={sil}
          />
        )}
        {adim === 2 && <FkAdim3Kontroller riskler={ws.riskler} onGuncelle={guncelle} />}
        {adim === 3 && <FkAdim4Degerlendirme riskler={ws.riskler} onGuncelle={guncelle} />}
        {adim === 4 && <FkAdim5Rapor temel={ws.temel} riskler={ws.riskler} onTemelChange={temelGuncelle} />}
      </div>

      <div className="flex flex-shrink-0 items-center justify-between gap-2 border-t isg-divider px-5 py-3">
        <div className="flex items-center gap-2">
          <RwButton variant="ghost" icon="ri-close-line" onClick={onClose}>İptal</RwButton>
          {sifirlaOnay ? (
            <Alert
              variant="danger"
              action={(
                <div className="flex items-center gap-2">
                  <RwButton variant="primary" size="sm" icon="ri-refresh-line" onClick={() => void sifirla()}>Evet, Sıfırla</RwButton>
                  <RwButton variant="ghost" size="sm" onClick={() => setSifirlaOnay(false)}>Vazgeç</RwButton>
                </div>
              )}
            >
              Tüm çalışma silinsin mi?
            </Alert>
          ) : (
            <RwButton variant="ghost" icon="ri-refresh-line" onClick={() => setSifirlaOnay(true)}>Sıfırla</RwButton>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden text-xs text-foreground-400 sm:inline">
            <i className="ri-information-line mr-1" /> Bu çalışma yalnızca geçici tutulur; kalıcı kayıt oluşturulmaz.
          </span>
          {adim > 0 && (
            <RwButton variant="secondary" icon="ri-arrow-left-line" onClick={() => setAdim((a) => Math.max(0, a - 1))}>Önceki Adım</RwButton>
          )}
          {adim < 4
            ? <RwButton variant="primary" iconAfter="ri-arrow-right-line" onClick={sonraki}>Sonraki Adım</RwButton>
            : <RwButton variant="primary" icon="ri-file-download-line" onClick={() => void raporIndir()}>{indiriliyor ? 'Oluşturuluyor...' : 'Raporu Oluştur ve İndir'}</RwButton>}
        </div>
      </div>
    </div>
  );
}