import { useRef, useState } from 'react';
import {
  CALISMA_METODU, KAPSAM_MADDELERI, type CalismaTemelBilgiler,
} from '@/components/feature/risk/calismaTypes';
import { GECERLILIK_SECENEKLERI, TEHLIKE_SINIFLARI, tehlikeGecerlilikPatch } from '@/components/feature/risk/riskSihirbazTypes';
import { RwButton, RwChip, RwInput, RwSelect, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';
import RiskNaceSecici from '@/components/feature/risk/RiskNaceSecici';

// ─────────────────────────────────────────────────────────────────────────────
// YILLIK ÇALIŞMA PLANI · ADIM 1 — TEMEL BİLGİLER VE KAPSAM
// Sol: iki kolonlu form → Plan Kapsamı (işaretlenebilir) → Plan Ekibi → Referans
// Dokümanlar → Rapor künyesi. Sağ: "Yıllık Çalışma Planı Hakkında" + Mevzuat
// Dayanakları + Yardımcı Mod.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: CalismaTemelBilgiler;
  kapsam: string[];
  onChange: (patch: Partial<CalismaTemelBilgiler>) => void;
  onKapsamChange: (kapsam: string[]) => void;
}

const PLAN_HEDEFLERI = [
  'Çalışma ortamı gözetimi ve saha denetimlerinin planlanması',
  'Çalışanların sağlık gözetimi ve periyodik muayeneleri',
  'Risk değerlendirmesinin güncel tutulması',
  'İSG eğitimleri ve çalışan bilgilendirmesi',
  'Acil durum planları ve tatbikatlar',
  'İş ekipmanı ve periyodik kontrollerin takibi',
  'İş kazası ve meslek hastalığı kayıtları',
];

export default function CalismaAdim1Temel({ temel, kapsam, onChange, onKapsamChange }: Props) {
  const [ekipGirdi, setEkipGirdi] = useState('');
  const [ozelKapsam, setOzelKapsam] = useState('');
  const dosyaRef = useRef<HTMLInputElement>(null);

  const yillar = Array.from({ length: 5 }, (_, i) => String(new Date().getFullYear() - 1 + i));

  const ekipEkle = () => {
    const ad = ekipGirdi.trim();
    if (!ad) return;
    if (!temel.ekip.includes(ad)) onChange({ ekip: [...temel.ekip, ad] });
    setEkipGirdi('');
  };

  const dosyaSec = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const adlar = Array.from(files).map((f) => f.name);
    onChange({ dokumanlar: Array.from(new Set([...temel.dokumanlar, ...adlar])) });
  };

  const kapsamToggle = (k: string) => {
    onKapsamChange(kapsam.includes(k) ? kapsam.filter((x) => x !== k) : [...kapsam, k]);
  };
  const tumunuSec = () => onKapsamChange(kapsam.length === KAPSAM_MADDELERI.length ? [] : [...KAPSAM_MADDELERI]);
  const ozelEkle = () => {
    const v = ozelKapsam.trim();
    if (v && !kapsam.includes(v)) onKapsamChange([...kapsam, v]);
    setOzelKapsam('');
  };

  return (
    <div className="isg-scroll-pane min-h-0 flex-1 overflow-y-auto overflow-x-hidden pr-1">
      <div className="pb-3">
        <h2 className="text-sm font-bold text-foreground-950">1. Temel Bilgiler ve Kapsam</h2>
        <p className="mt-1 text-xs text-foreground-500">
          Yıllık çalışma planına ait temel bilgileri tanımlayın ve planın kapsamını belirleyin.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
        {/* SOL */}
        <div>
          <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-2">
            <RwInput
              label="Plan Adı" required
              value={temel.calismaAdi}
              onChange={(e) => onChange({ calismaAdi: e.target.value })}
              placeholder="Örn. 2026 Yılı İSG Çalışma Planı"
            />
            <RwSelect
              label="Plan Yılı" required
              options={yillar.map((y) => ({ value: y, label: y }))}
              value={temel.planYili} onChange={(v) => onChange({ planYili: v })}
              placeholder={String(new Date().getFullYear())}
            />

            <RwInput label="Firma" value={temel.firma} onChange={(e) => onChange({ firma: e.target.value })} placeholder="Firma ünvanı" />
            <RwInput
              label="Tesis / İş Yeri" required
              value={temel.tesis} onChange={(e) => onChange({ tesis: e.target.value })}
              placeholder="Örn. Merkez Üretim Tesisi"
            />

            <RwInput
              label="Düzenleme Tarihi" required type="date"
              value={temel.tarih}
              onChange={(e) => onChange({ tarih: e.target.value })}
            />
            <RwSelect
              label="Geçerlilik Süresi"
              options={GECERLILIK_SECENEKLERI.map((v) => ({ value: v, label: v }))}
              value={temel.gecerlilik} onChange={(v) => onChange({ gecerlilik: v })}
            />

            <div className="md:col-span-2">
              <RwTextarea
                label="Planın Amacı / Açıklama" maxLength={1000}
                value={temel.amac} onChange={(e) => onChange({ amac: e.target.value })}
                placeholder="Yıllık çalışma planının amacı ve genel çerçevesine ilişkin açıklama girin..."
              />
            </div>
          </div>

          {/* Plan Kapsamı */}
          <div className="mt-5">
            <div className="flex items-center justify-between">
              <span className="block text-xs font-medium text-foreground-800">Plan Kapsamı</span>
              <button type="button" onClick={tumunuSec} className="cursor-pointer text-xs font-medium text-primary-600 hover:underline dark:text-primary-300">
                {kapsam.length === KAPSAM_MADDELERI.length ? 'Tümünü Temizle' : 'Tümünü Seç'}
              </button>
            </div>
            <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {KAPSAM_MADDELERI.map((k) => {
                const secili = kapsam.includes(k);
                return (
                  <button
                    key={k}
                    type="button"
                    onClick={() => kapsamToggle(k)}
                    className={`flex cursor-pointer items-start gap-2 rounded-md border p-2.5 text-left transition-colors ${
                      secili
                        ? 'border-primary-500/60 bg-primary-500/10'
                        : 'border-background-300/60 bg-background-100 hover:border-primary-300 dark:border-background-400/30 dark:bg-background-200/40'
                    }`}
                  >
                    <span className={`mt-0.5 flex h-4 w-4 flex-shrink-0 items-center justify-center rounded border ${secili ? 'border-primary-500 bg-primary-500 text-inverse' : 'border-foreground-300 dark:border-background-400'}`}>
                      {secili && <i className="ri-check-line text-[10px]" />}
                    </span>
                    <span className="text-xs leading-snug text-foreground-700">{k}</span>
                  </button>
                );
              })}
            </div>
            {kapsam.filter((k) => !KAPSAM_MADDELERI.includes(k)).length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {kapsam.filter((k) => !KAPSAM_MADDELERI.includes(k)).map((k) => (
                  <RwChip key={k} onRemove={() => onKapsamChange(kapsam.filter((x) => x !== k))}>{k}</RwChip>
                ))}
              </div>
            )}
            <div className="mt-2 flex items-center gap-1.5">
              <input
                value={ozelKapsam}
                onChange={(e) => setOzelKapsam(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); ozelEkle(); } }}
                placeholder="Özel kapsam maddesi ekleyin"
                className="h-8 w-full max-w-xs rounded-md border border-background-300/70 bg-background-50 px-2.5 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
              />
              <RwButton size="sm" variant="outline" icon="ri-add-line" onClick={ozelEkle}>Ekle</RwButton>
            </div>
          </div>

          {/* Plan Ekibi */}
          <div className="mt-5">
            <span className="mb-1.5 block text-xs font-medium text-foreground-800">Plan Ekibi</span>
            <div className="flex flex-wrap items-center gap-2 rounded-md border border-background-300/60 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
              {temel.ekip.map((ad) => (
                <RwChip key={ad} onRemove={() => onChange({ ekip: temel.ekip.filter((x) => x !== ad) })}>{ad}</RwChip>
              ))}
              <div className="flex items-center gap-1.5">
                <input
                  value={ekipGirdi}
                  onChange={(e) => setEkipGirdi(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); ekipEkle(); } }}
                  placeholder="İsim / unvan yazın"
                  className="h-8 w-44 rounded-md border border-background-300/70 bg-background-50 px-2.5 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
                />
                <RwButton size="sm" variant="outline" icon="ri-add-line" onClick={ekipEkle}>Ekle</RwButton>
              </div>
            </div>
          </div>

          {/* Referans Dokümanlar */}
          <div className="mt-5">
            <span className="block text-xs font-medium text-foreground-800">Referans Dokümanlar (Opsiyonel)</span>
            <div
              onClick={() => dosyaRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); dosyaSec(e.dataTransfer.files); }}
              className="mt-2 flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-md border border-dashed border-background-300/70 bg-background-100/60 px-4 py-6 text-center transition-colors hover:border-primary-400 dark:border-background-400/40 dark:bg-background-200/30"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                <i className="ri-upload-cloud-2-line text-xl" />
              </span>
              <p className="text-xs text-foreground-600">Dosya seçin veya sürükleyip bırakın</p>
              <p className="text-xs text-foreground-400">PDF, DOC, DOCX, XLS, XLSX, JPG, PNG (Maks. 10 MB)</p>
            </div>
            {temel.dokumanlar.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {temel.dokumanlar.map((d) => (
                  <RwChip key={d} onRemove={() => onChange({ dokumanlar: temel.dokumanlar.filter((x) => x !== d) })}>
                    <i className="ri-file-line text-foreground-400" /> {d}
                  </RwChip>
                ))}
              </div>
            )}
            <input ref={dosyaRef} type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" className="hidden" onChange={(e) => { dosyaSec(e.target.files); e.target.value = ''; }} />
          </div>

          {/* Künye */}
          <div className="mt-5 pb-7">
            <span className="mb-1.5 block text-xs font-medium text-foreground-800">Rapor Künye Bilgileri (Opsiyonel)</span>
            <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-3">
              <RwInput label="Rapor No" value={temel.raporNo} onChange={(e) => onChange({ raporNo: e.target.value })} placeholder="Örn. YÇP-2026-001" />
              <RwSelect label="Tehlike Sınıfı" options={TEHLIKE_SINIFLARI.map((v) => ({ value: v, label: v }))} value={temel.tehlikeSinifi} onChange={(v) => onChange(tehlikeGecerlilikPatch(v))} placeholder="Seçiniz" />
              <RwInput label="Çalışan Sayısı" value={temel.calisanSayisi} onChange={(e) => onChange({ calisanSayisi: e.target.value })} placeholder="Örn. 120" />
              <RwInput label="İşveren" value={temel.isveren} onChange={(e) => onChange({ isveren: e.target.value })} placeholder="İşveren adı / ünvanı" />
              <RiskNaceSecici
                naceId={temel.naceId}
                onChange={(s) => onChange({ naceId: s.naceId, nace: s.nace, ...(s.tehlikeSinifi ? tehlikeGecerlilikPatch(s.tehlikeSinifi) : {}) })}
              />
              <RwInput label="Hazırlayan" value={temel.hazirlayan} onChange={(e) => onChange({ hazirlayan: e.target.value })} placeholder="İş güvenliği uzmanı" />
              <RwInput label="Onaylayan" value={temel.onaylayan} onChange={(e) => onChange({ onaylayan: e.target.value })} placeholder="İşveren / vekili" />
              <RwInput label="Adres / Lokasyon" value={temel.adres} onChange={(e) => onChange({ adres: e.target.value })} placeholder="Açık adres" />
            </div>
          </div>
        </div>

        {/* SAĞ */}
        <aside className="space-y-3">
          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-information-fill text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Yıllık Çalışma Planı Hakkında</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              İş sağlığı ve güvenliği hizmetlerine ilişkin yıllık çalışma planı; işyerinde bir sonraki yıl
              gerçekleştirilecek İSG faaliyetlerinin (gözetim, eğitim, sağlık gözetimi, acil durum, periyodik
              kontroller vb.) zaman planını gösteren belgedir.
            </p>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              İSG Hizmetleri Yönetmeliği Madde 15 uyarınca plan, işyeri hekimi ve iş güvenliği uzmanı tarafından
              hazırlanır ve işverene sunulur.
            </p>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Planın Hedefleri</h3>
            <ul className="space-y-1.5">
              {PLAN_HEDEFLERI.map((h) => (
                <li key={h} className="flex items-start gap-2">
                  <i className="ri-check-line mt-0.5 text-xs text-primary-500" />
                  <span className="text-xs leading-snug text-foreground-600">{h}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-lg border border-warning-500/30 bg-warning-500/5 p-3">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-warning-500 text-inverse"><i className="ri-lightbulb-line text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Yardımcı Mod</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              Bu çalışma geçici olarak tutulur; kalıcı kayıt OLUŞTURULMAZ. Yalnızca PDF / Word / Excel indirilir.
            </p>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-foreground-950"><i className="ri-hashtag text-primary-500" /> Yöntem</p>
            <p className="mt-1 text-xs leading-relaxed text-foreground-600">{CALISMA_METODU}</p>
          </div>
        </aside>
      </div>
    </div>
  );
}