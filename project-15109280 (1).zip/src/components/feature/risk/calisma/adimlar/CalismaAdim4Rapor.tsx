import { useEffect, useMemo, useState } from 'react';
import Icon from '@/components/ui/Icon';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import {
  AY_ADLARI, AY_KISA, kategoriIkon, oncelikBilgi, yeniId,
  type CalismaFaaliyet, type CalismaTemelBilgiler, type Imzaci,
} from '@/components/feature/risk/calismaTypes';
import { MEVZUAT_DAYANAKLARI } from '@/lib/calismaRapor/model';
import { pdfBlob, pdfIndir, wordIndir, excelIndir, csvIndir, txtIndir } from '@/lib/calismaRapor';
import { RwButton, RwCard, RwIconButton, RwInput, RwSectionTitle } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// YILLIK ÇALIŞMA PLANI · ADIM 4 — RAPOR VE ÖNİZLEME
// Özet kartları + kategori dağılımı + aylık yoğunluk + mevzuat + önizleme/indirme.
// "Raporu Önizle" gerçek PDF'i (indirilenle birebir) uygulama içinde gösterir.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: CalismaTemelBilgiler;
  kapsam: string[];
  faaliyetler: CalismaFaaliyet[];
  onTemelChange: (patch: Partial<CalismaTemelBilgiler>) => void;
}

const KAT_RENK = [
  'oklch(var(--primary-500))', 'oklch(var(--secondary-500))', 'oklch(var(--accent-500))',
  'oklch(var(--primary-700))', 'oklch(var(--secondary-700))', 'oklch(var(--accent-700))',
  'oklch(var(--primary-300))', 'oklch(var(--secondary-300))', 'oklch(var(--accent-300))',
];

function PdfOnizleme({ blob }: { blob: Blob }) {
  const [url, setUrl] = useState('');
  useEffect(() => {
    const u = URL.createObjectURL(blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  if (!url) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-background-200">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }
  return (
    <div className="h-full w-full bg-background-200">
      <iframe src={url} title="Yıllık Çalışma Planı Önizleme" className="h-full w-full border-0" />
    </div>
  );
}

function tarihGoster(iso: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

export default function CalismaAdim4Rapor({ temel, kapsam, faaliyetler, onTemelChange }: Props) {
  const { addToast } = useToastActions();
  const { openModal } = useModalActions();
  const [indiriliyor, setIndiriliyor] = useState<'word' | 'pdf' | 'excel' | 'csv' | 'txt' | null>(null);
  const [indirAcik, setIndirAcik] = useState(false);
  const [onizleYukleniyor, setOnizleYukleniyor] = useState(false);

  // İmzacı yönetimi (rapor sonundaki imza bölümü)
  const imzacilar = temel.imzacilar ?? [];
  const [yeniAd, setYeniAd] = useState('');
  const [yeniGorev, setYeniGorev] = useState('');
  const [yeniBelge, setYeniBelge] = useState('');
  const [duzenlenen, setDuzenlenen] = useState<string | null>(null);

  const kategoriDagilim = useMemo(() => {
    const m = new Map<string, number>();
    faaliyetler.forEach((f) => m.set(f.kategori, (m.get(f.kategori) ?? 0) + 1));
    return Array.from(m.entries()).map(([kategori, adet]) => ({ kategori, adet })).sort((a, b) => b.adet - a.adet);
  }, [faaliyetler]);

  const aylikSayim = useMemo(() => {
    const d = Array.from({ length: 12 }, () => 0);
    faaliyetler.forEach((f) => (f.aylar || []).forEach((v, i) => { if (v && i < 12) d[i] += 1; }));
    return d;
  }, [faaliyetler]);

  const planliHucre = aylikSayim.reduce((t, v) => t + v, 0);
  const yuksek = faaliyetler.filter((f) => f.oncelik === 'Yüksek').length;
  const maxAy = Math.max(1, ...aylikSayim);

  const donutToplam = Math.max(1, faaliyetler.length);
  let aci = 0;
  const donutGradient = faaliyetler.length === 0
    ? 'oklch(var(--background-300)) 0% 100%'
    : kategoriDagilim.map((k, i) => {
      const bas = (aci / donutToplam) * 100;
      aci += k.adet;
      const bit = (aci / donutToplam) * 100;
      return `${KAT_RENK[i % KAT_RENK.length]} ${bas}% ${bit}%`;
    }).join(', ');

  const indir = async (tip: 'pdf' | 'word' | 'excel' | 'csv' | 'txt') => {
    if (faaliyetler.length === 0) {
      addToast({ title: 'Faaliyet listesi boş', message: 'Rapor oluşturmak için en az bir faaliyet ekleyin.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndirAcik(false);
    setIndiriliyor(tip);
    try {
      const veri = { temel, kapsam, faaliyetler };
      if (tip === 'pdf') await pdfIndir(veri);
      else if (tip === 'excel') await excelIndir(veri);
      else if (tip === 'csv') csvIndir(veri);
      else if (tip === 'txt') txtIndir(veri);
      else await wordIndir(veri);
      addToast({ title: 'Rapor hazır', message: 'Dosya indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Rapor oluşturulamadı', message: 'Beklenmeyen bir hata oluştu, lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setIndiriliyor(null);
    }
  };

  const ozetKopyala = async () => {
    setIndirAcik(false);
    try {
      const metin = [
        'YILLIK ÇALIŞMA PLANI',
        `Firma: ${temel.firma || '—'}`,
        `Plan Yılı: ${temel.planYili || '—'}`,
        `Rapor No: ${temel.raporNo || '—'}`,
        `Düzenleme Tarihi: ${tarihGoster(temel.tarih)}`,
        `Toplam Faaliyet: ${faaliyetler.length}`,
        `Planlı Ay Girdisi: ${planliHucre}`,
      ].join('\n');
      await navigator.clipboard.writeText(metin);
      addToast({ title: 'Kopyalandı', message: 'Plan özeti panoya kopyalandı.', type: 'success' });
    } catch {
      addToast({ title: 'Kopyalanamadı', message: 'Panoya erişilemedi.', type: 'error' });
    }
  };

  const imzaciKaydet = () => {
    if (!yeniAd.trim()) {
      addToast({ title: 'Eksik bilgi', message: 'İmzacı için ad soyad girin.', type: 'warning' });
      return;
    }
    const gorev = yeniGorev.trim() || 'Yetkili';
    if (duzenlenen) {
      onTemelChange({ imzacilar: imzacilar.map((x) => (x.id === duzenlenen ? { ...x, adSoyad: yeniAd.trim(), gorev, belge: yeniBelge.trim() } : x)) });
    } else {
      onTemelChange({ imzacilar: [...imzacilar, { id: yeniId('im'), adSoyad: yeniAd.trim(), gorev, belge: yeniBelge.trim() }] });
    }
    setYeniAd(''); setYeniGorev(''); setYeniBelge(''); setDuzenlenen(null);
  };

  const imzaciDuzenle = (im: Imzaci) => { setDuzenlenen(im.id); setYeniAd(im.adSoyad); setYeniGorev(im.gorev); setYeniBelge(im.belge); };

  const imzaciSil = (id: string) => {
    onTemelChange({ imzacilar: imzacilar.filter((x) => x.id !== id) });
    if (duzenlenen === id) { setDuzenlenen(null); setYeniAd(''); setYeniGorev(''); setYeniBelge(''); }
  };

  const onizle = async () => {
    if (faaliyetler.length === 0) {
      addToast({ title: 'Faaliyet listesi boş', message: 'Önizleme için en az bir faaliyet ekleyin.', type: 'warning' });
      return;
    }
    if (onizleYukleniyor) return;
    setOnizleYukleniyor(true);
    try {
      const blob = await pdfBlob({ temel, kapsam, faaliyetler });
      openModal({
        title: 'Yıllık Çalışma Planı Önizleme',
        description: temel.firma || 'Rapor önizlemesi',
        variant: 'large',
        width: 1120,
        height: 820,
        minWidth: 720,
        minHeight: 520,
        showFooter: false,
        bodyLayout: 'fill',
        closable: true,
        resizable: true,
        minimizable: true,
        maximizable: true,
        content: <PdfOnizleme blob={blob} />,
      });
    } catch {
      addToast({ title: 'Önizleme oluşturulamadı', message: 'Beklenmeyen bir hata oluştu, lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setOnizleYukleniyor(false);
    }
  };

  const kartlar = [
    { key: 'faaliyet', label: 'Toplam Faaliyet', adet: faaliyetler.length, icon: 'ri-list-check-2', renk: 'bg-primary-500' },
    { key: 'kategori', label: 'Kategori', adet: kategoriDagilim.length, icon: 'ri-apps-2-line', renk: 'bg-secondary-500' },
    { key: 'planli', label: 'Planlı Ay Girdisi', adet: planliHucre, icon: 'ri-calendar-check-line', renk: 'bg-accent-500' },
    { key: 'yuksek', label: 'Yüksek Öncelik', adet: yuksek, icon: 'ri-error-warning-line', renk: 'bg-danger-500' },
    { key: 'kapsam', label: 'Kapsam Maddesi', adet: kapsam.length, icon: 'ri-price-tag-3-line', renk: 'bg-success-500' },
  ];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="4. Rapor ve Önizleme"
        desc="Planın özetini gözden geçirin, yıllık matrisi kontrol edin ve raporu önizleyin/indirin."
        right={(
          <div className="flex flex-shrink-0 items-center gap-2">
            <RwButton variant="outline" size="sm" icon={onizleYukleniyor ? undefined : 'ri-eye-line'} disabled={onizleYukleniyor} onClick={() => void onizle()}>
              {onizleYukleniyor ? 'Hazırlanıyor...' : 'Planı Önizle'}
            </RwButton>
          </div>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_360px]">
        {/* SOL */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto pr-1">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
            {kartlar.map((k) => (
              <div key={k.key} className="flex items-center gap-2.5 rounded-lg border border-background-300/50 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
                <span className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-md text-inverse ${k.renk}`}><i className={`${k.icon} text-lg`} /></span>
                <span className="min-w-0">
                  <span className="block text-lg font-bold text-foreground-950">{k.adet}</span>
                  <span className="block truncate text-[11px] font-medium text-foreground-500">{k.label}</span>
                </span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <RwCard title="Kategori Dağılımı" icon="ri-pie-chart-2-line" className="p-3">
              {faaliyetler.length === 0 ? (
                <p className="py-8 text-center text-xs text-foreground-400">Faaliyet eklenince dağılım görünecek.</p>
              ) : (
                <div className="flex items-center gap-4">
                  <div className="relative h-28 w-28 flex-shrink-0">
                    <div className="h-full w-full rounded-full" style={{ background: `conic-gradient(${donutGradient})` }} />
                    <div className="absolute inset-[18%] flex flex-col items-center justify-center rounded-full bg-background-100 dark:bg-background-200">
                      <span className="text-lg font-bold text-foreground-950">{faaliyetler.length}</span>
                      <span className="text-[10px] text-foreground-500">Faaliyet</span>
                    </div>
                  </div>
                  <ul className="min-w-0 flex-1 space-y-1">
                    {kategoriDagilim.slice(0, 8).map((k, i) => (
                      <li key={k.kategori} className="flex items-center gap-2 text-xs">
                        <span className="h-2.5 w-2.5 flex-shrink-0 rounded-full" style={{ backgroundColor: KAT_RENK[i % KAT_RENK.length] }} />
                        <span className="flex-1 truncate text-foreground-600">{k.kategori}</span>
                        <span className="font-medium text-foreground-800">{k.adet}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </RwCard>

            <RwCard title="Aylık Faaliyet Yoğunluğu" icon="ri-bar-chart-2-line" className="p-3">
              <div className="flex h-32 items-end justify-between gap-1.5">
                {aylikSayim.map((v, i) => (
                  <div key={AY_KISA[i]} className="flex flex-1 flex-col items-center gap-1">
                    <span className="text-[10px] font-semibold text-foreground-600">{v > 0 ? v : ''}</span>
                    <div className="flex w-full flex-1 items-end">
                      <div className="w-full rounded-t bg-primary-500/80" style={{ height: `${Math.max(4, (v / maxAy) * 100)}%` }} title={`${AY_ADLARI[i]}: ${v} faaliyet`} />
                    </div>
                    <span className="text-[9px] text-foreground-400">{AY_KISA[i]}</span>
                  </div>
                ))}
              </div>
            </RwCard>
          </div>

          {/* Yıllık matris önizleme */}
          <RwCard className="p-0">
            <div className="border-b border-background-300/40 p-3 dark:border-background-400/25">
              <h3 className="text-xs font-semibold text-foreground-950">Yıllık Çalışma Matrisi</h3>
              <p className="mt-0.5 text-[11px] text-foreground-500">Faaliyetlerin aylara göre dağılımı (rapora aynen yansır).</p>
            </div>
            {faaliyetler.length === 0 ? (
              <p className="px-3 py-8 text-center text-xs text-foreground-400">Faaliyet eklenince matris görünecek.</p>
            ) : (
              <div className="isg-scroll-pane max-h-[340px] overflow-auto">
                <table className="w-full border-collapse" style={{ minWidth: 820 }}>
                  <thead className="sticky top-0 bg-background-200 dark:bg-background-300/70">
                    <tr className="text-left text-[10px] font-semibold uppercase tracking-wide text-foreground-500">
                      <th className="px-2 py-1.5 whitespace-nowrap">#</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Faaliyet</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Sorumlu</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Periyot</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Öncelik</th>
                      {AY_KISA.map((a) => <th key={a} className="px-1 py-1.5 text-center whitespace-nowrap">{a}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {faaliyetler.map((f, i) => {
                      const om = oncelikBilgi(f.oncelik);
                      return (
                        <tr key={f.id} className="border-t border-background-300/20 align-middle dark:border-background-400/10">
                          <td className="px-2 py-2 text-xs text-foreground-500">{i + 1}</td>
                          <td className="px-2 py-2">
                            <div className="flex items-center gap-2">
                              <i className={`${kategoriIkon(f.kategori)} text-xs text-primary-500`} />
                              <span className="text-xs font-medium text-foreground-800">{f.faaliyet || '—'}</span>
                            </div>
                          </td>
                          <td className="px-2 py-2 text-xs text-foreground-600">{f.sorumlu || '—'}</td>
                          <td className="px-2 py-2 text-xs text-foreground-600">{f.periyot}</td>
                          <td className="px-2 py-2">
                            <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${om.soft}`}>
                              <span className={`h-1.5 w-1.5 rounded-full ${om.dot}`} /> {f.oncelik}
                            </span>
                          </td>
                          {f.aylar.map((v, idx) => (
                            <td key={AY_KISA[idx]} className="px-1 py-2 text-center">
                              {v ? <span className="inline-flex h-5 w-5 items-center justify-center rounded bg-primary-500/15 text-[10px] font-bold text-primary-700 dark:text-primary-300">X</span> : <span className="text-[10px] text-foreground-300">·</span>}
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </RwCard>

          {/* Mevzuat */}
          <RwCard title="Mevzuat Dayanakları" icon="ri-scales-3-line" className="p-3">
            <ul className="space-y-2">
              {MEVZUAT_DAYANAKLARI.map((m) => (
                <li key={m.baslik} className="flex items-start gap-2">
                  <i className="ri-checkbox-circle-line mt-0.5 flex-shrink-0 text-sm text-success-500" />
                  <span className="min-w-0">
                    <span className="block text-xs font-semibold text-foreground-900">{m.baslik}</span>
                    <span className="block text-[11px] leading-snug text-foreground-500">{m.aciklama}</span>
                  </span>
                </li>
              ))}
            </ul>
          </RwCard>

          <div className="pb-7" />
        </div>

        {/* SAĞ */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <RwCard title="Rapor İşlemleri" icon="ri-download-2-line" className="p-3">
            <p className="mb-2.5 text-xs text-foreground-500">Planı aşağıdaki formatlarda oluşturabilirsiniz.</p>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('word')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-primary-500 text-inverse transition-colors hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'word' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="word" size="md" />}
                <span className="text-xs leading-tight">Word İndir</span>
              </button>
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('pdf')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-danger-500 text-inverse transition-colors hover:bg-danger-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'pdf' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="pdf" size="md" />}
                <span className="text-xs leading-tight">PDF İndir</span>
              </button>
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('excel')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-success-500 text-inverse transition-colors hover:bg-success-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'excel' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="excel" size="md" />}
                <span className="text-xs leading-tight">Excel İndir</span>
              </button>
              <div className="relative">
                <button type="button" onClick={() => setIndirAcik((o) => !o)} className="flex h-16 w-full cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md border border-background-300/70 text-foreground-700 transition-colors hover:bg-background-100 dark:border-background-400/40 dark:hover:bg-background-300/40">
                  <i className="ri-more-2-line text-lg" />
                  <span className="text-xs leading-tight">Diğer</span>
                </button>
                {indirAcik && (
                  <div className="absolute right-0 top-full z-30 mt-1 w-56 rounded-md border border-background-300/70 bg-background-50 p-1 shadow-xl dark:border-background-400/50 dark:bg-background-200">
                    <button type="button" onClick={() => void indir('csv')} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <i className="ri-file-chart-2-line text-success-600" /> CSV (ham veri) indir
                    </button>
                    <button type="button" onClick={() => void indir('txt')} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <Icon name="text" size="sm" /> Metin (TXT) raporu indir
                    </button>
                    <button type="button" onClick={() => void ozetKopyala()} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <i className="ri-clipboard-line text-secondary-600" /> Özeti panoya kopyala
                    </button>
                  </div>
                )}
              </div>
            </div>
          </RwCard>

          <RwCard title="Rapor Bilgileri" icon="ri-file-list-3-line" className="p-3">
            <div className="space-y-2.5">
              <RwInput label="Rapor Numarası" value={temel.raporNo} onChange={(e) => onTemelChange({ raporNo: e.target.value })} placeholder="YÇP-2026-001" />
              <div className="rounded-md border border-background-300/50 bg-background-50 p-2.5 text-xs dark:border-background-400/25 dark:bg-background-100/50">
                <div className="flex items-center justify-between"><span className="text-foreground-500">Firma</span><span className="font-medium text-foreground-800">{temel.firma || '—'}</span></div>
                <div className="mt-1.5 flex items-center justify-between"><span className="text-foreground-500">Plan Yılı</span><span className="font-medium text-foreground-800">{temel.planYili || '—'}</span></div>
                <div className="mt-1.5 flex items-center justify-between"><span className="text-foreground-500">Düzenleme</span><span className="font-medium text-foreground-800">{tarihGoster(temel.tarih)}</span></div>
                <div className="mt-1.5 flex items-center justify-between"><span className="text-foreground-500">Faaliyet</span><span className="font-medium text-foreground-800">{faaliyetler.length}</span></div>
              </div>
            </div>
          </RwCard>

          <RwCard title="Raporda Yer Alacak İmzacılar" icon="ri-user-star-line" className="p-3">
            <p className="mb-2 text-xs text-foreground-500">Raporun sonundaki onay bölümünde yer alacak imzacıları ekleyin. Boş bırakılırsa hazırlayan ve onaylayan kişiler otomatik eklenir.</p>
            {imzacilar.length > 0 && (
              <div className="mb-2.5 overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
                <table className="w-full border-collapse">
                  <thead className="bg-background-200 dark:bg-background-300/60">
                    <tr className="text-left text-xs font-semibold text-foreground-500">
                      <th className="w-8 px-2 py-1.5 text-center">#</th>
                      <th className="px-2 py-1.5">Adı Soyadı</th>
                      <th className="px-2 py-1.5">Görevi</th>
                      <th className="w-16 px-2 py-1.5 text-center">İşlem</th>
                    </tr>
                  </thead>
                  <tbody>
                    {imzacilar.map((im, i) => (
                      <tr key={im.id} className="border-t border-background-300/30 dark:border-background-400/20">
                        <td className="px-2 py-1.5 text-center text-xs text-foreground-500">{i + 1}</td>
                        <td className="px-2 py-1.5 text-xs font-medium text-foreground-950">{im.adSoyad || '—'}</td>
                        <td className="px-2 py-1.5 text-xs text-foreground-600">{im.gorev || '—'}</td>
                        <td className="px-2 py-1.5">
                          <div className="flex items-center justify-center gap-0.5">
                            <RwIconButton icon="ri-edit-line" onClick={() => imzaciDuzenle(im)} />
                            <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={() => imzaciSil(im.id)} />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div className="space-y-2 rounded-md border border-dashed border-background-300/60 p-2.5 dark:border-background-400/30">
              <RwInput size="sm" placeholder="Ad Soyad" value={yeniAd} onChange={(e) => setYeniAd(e.target.value)} />
              <RwInput size="sm" placeholder="Görev / Unvan" value={yeniGorev} onChange={(e) => setYeniGorev(e.target.value)} />
              <RwInput size="sm" placeholder="Belge / Sertifika No (opsiyonel)" value={yeniBelge} onChange={(e) => setYeniBelge(e.target.value)} />
              <RwButton variant="outline" size="sm" block icon={duzenlenen ? 'ri-check-line' : 'ri-add-line'} onClick={imzaciKaydet}>
                {duzenlenen ? 'Güncelle' : 'Yeni İmzacı Ekle'}
              </RwButton>
            </div>
          </RwCard>

          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-foreground-950"><i className="ri-information-line text-primary-500" /> Rapor İçeriği</p>
            <p className="mt-1 text-xs leading-relaxed text-foreground-600">
              Rapor; firma ve plan bilgileri, plan kapsamı, 12 aylık çalışma matrisi, faaliyet detayları, özet/dağılım,
              mevzuat dayanakları ve onay bölümlerini içerir.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}