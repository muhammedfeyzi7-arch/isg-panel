import { useCallback, useEffect, useMemo, useState } from 'react';
import Alert from '@/components/ui/Alert';
import { useToastActions } from '@/hooks/useToast';
import { aiHazopOnerileri, type HazopAiCevap, type HazopAiCtx } from '@/lib/riskAiService';
import { pdfIndir } from '@/lib/hazopRapor';
import HzDugumPaneli from '@/components/feature/risk/hz/HzDugumPaneli';
import HzAdim1Temel from '@/components/feature/risk/hz/adimlar/HzAdim1Temel';
import HzAdim2Dugum from '@/components/feature/risk/hz/adimlar/HzAdim2Dugum';
import HzAdim3Sapmalar from '@/components/feature/risk/hz/adimlar/HzAdim3Sapmalar';
import HzAdim4Sonuclar from '@/components/feature/risk/hz/adimlar/HzAdim4Sonuclar';
import HzAdim5Rapor from '@/components/feature/risk/hz/adimlar/HzAdim5Rapor';
import { hzWorkspaceKaydet, hzWorkspaceTemizle, hzWorkspaceYukle } from '@/components/feature/risk/hazopWorkspaceStore';
import { RwButton, RwStepper } from '@/components/feature/risk/sihirbaz/wizardUi';
import {
  HZ_ADIM_BASLIKLARI, bosHzWorkspace, hazopOrnekDugumler, yeniDugumNo,
  type HzDugum, type HzSapma, type HzTemelBilgiler, type HzWorkspace,
} from '@/components/feature/risk/hazopTypes';

// ─────────────────────────────────────────────────────────────────────────────
// HAZOP SİHİRBAZI — KABUK
//
// 5 adım tek merkezi modal içinde yönetilir (Temel Bilgiler → Düğüm ve Tasarım
// Amacı → Sapmalar ve Nedenler → Sonuçlar ve Korunma Önlemleri → Rapor).
// Tüm adımlar aynı workspace'i paylaşır. Sol "Proses Akışındaki Düğümler" paneli
// 2–5. adımlarda sabit kalır. Workspace yerel (IndexedDB) saklanır — KALICI KAYIT
// YOKTUR, sisteme veri gitmez; yalnızca PDF/Word/Excel indirilir.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  onClose: () => void;
}

export default function HzSihirbazContent({ onClose }: Props) {
  const { addToast } = useToastActions();
  const [ws, setWs] = useState<HzWorkspace>(() => bosHzWorkspace());
  const [adim, setAdim] = useState(0);
  const [hazir, setHazir] = useState(false);
  const [sifirlaOnay, setSifirlaOnay] = useState(false);
  const [indiriliyor, setIndiriliyor] = useState(false);

  useEffect(() => {
    let iptal = false;
    void hzWorkspaceYukle().then((kayit) => {
      if (iptal) return;
      if (kayit && Array.isArray(kayit.dugumler)) {
        const temel = { ...bosHzWorkspace().temel, ...(kayit.temel || {}) };
        const dugumler = Array.isArray(kayit.dugumler) ? kayit.dugumler : [];
        setWs({
          ...bosHzWorkspace(),
          ...kayit,
          temel: {
            ...temel,
            ekip: Array.isArray(temel.ekip) ? temel.ekip : [],
            dokumanlar: Array.isArray(temel.dokumanlar) ? temel.dokumanlar : [],
            imzacilar: Array.isArray(temel.imzacilar) ? temel.imzacilar : [],
          },
          dugumler: dugumler.map((d) => ({ ...d, parametreler: Array.isArray(d.parametreler) ? d.parametreler : [] })),
          sapmalar: Array.isArray(kayit.sapmalar) ? kayit.sapmalar : [],
          seciliDugumId: kayit.seciliDugumId || (dugumler[0]?.id ?? ''),
        });
        setAdim(Math.max(0, Math.min(4, kayit.aktifAdim ?? 0)));
      } else {
        // İlk kullanım: referans görseldeki örnek proses düğümleriyle başla.
        const dugumler = hazopOrnekDugumler();
        setWs({ ...bosHzWorkspace(), dugumler, seciliDugumId: dugumler[0]?.id ?? '' });
      }
      setHazir(true);
    });
    return () => { iptal = true; };
  }, []);

  useEffect(() => {
    if (!hazir) return;
    const t = setTimeout(() => { void hzWorkspaceKaydet({ ...ws, aktifAdim: adim }); }, 500);
    return () => clearTimeout(t);
  }, [ws, adim, hazir]);

  const seciliDugum = useMemo<HzDugum | null>(
    () => ws.dugumler.find((d) => d.id === ws.seciliDugumId) ?? ws.dugumler[0] ?? null,
    [ws.dugumler, ws.seciliDugumId],
  );

  // ── Temel ──
  const temelGuncelle = useCallback((patch: Partial<HzTemelBilgiler>) => {
    setWs((p) => ({ ...p, temel: { ...p.temel, ...patch } }));
  }, []);

  // ── Düğüm işlemleri ──
  const dugumEkle = useCallback(() => {
    setWs((p) => {
      // MANTIK DÜZELTMESİ: düğüm no'su (ör. 'R-101') ile düğüm tipi TUTARLI olmalı.
      // Yeni düğüm tipi boş başlar; no da 'belirsiz' köküyle (N-xxx) üretilir.
      // Kullanıcı formdan tipi seçtiğinde no ve tip birbiriyle uyumlu kalır.
      const tip = '';
      const yeni: HzDugum = {
        id: `hz-d-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
        no: yeniDugumNo(p.dugumler, tip),
        ad: '',
        tip,
        tanim: '',
        tasarimAmaci: '',
        isletmeKosullari: '',
        parametreler: [],
      };
      return { ...p, dugumler: [...p.dugumler, yeni], seciliDugumId: yeni.id };
    });
    addToast({ title: 'Düğüm eklendi', message: 'Yeni düğümü sağdaki formdan düzenleyin.', type: 'success' });
  }, [addToast]);

  const dugumGuncelle = useCallback((id: string, patch: Partial<HzDugum>) => {
    setWs((p) => ({ ...p, dugumler: p.dugumler.map((d) => (d.id === id ? { ...d, ...patch } : d)) }));
  }, []);

  const dugumSil = useCallback((id: string) => {
    setWs((p) => {
      const kalan = p.dugumler.filter((d) => d.id !== id);
      return {
        ...p,
        dugumler: kalan,
        sapmalar: p.sapmalar.filter((s) => s.dugumId !== id),
        seciliDugumId: p.seciliDugumId === id ? (kalan[0]?.id ?? '') : p.seciliDugumId,
      };
    });
    addToast({ title: 'Düğüm silindi', message: 'Düğüm ve ilgili sapmalar kaldırıldı.', type: 'success' });
  }, [addToast]);

  const dugumSec = useCallback((id: string) => {
    setWs((p) => ({ ...p, seciliDugumId: id }));
  }, []);

  // ── Sapma işlemleri ──
  const sapmaKaydet = useCallback((s: HzSapma) => {
    setWs((p) => {
      const varMi = p.sapmalar.some((x) => x.id === s.id);
      return { ...p, sapmalar: varMi ? p.sapmalar.map((x) => (x.id === s.id ? s : x)) : [...p.sapmalar, s] };
    });
  }, []);

  const sapmaGuncelle = useCallback((id: string, patch: Partial<HzSapma>) => {
    setWs((p) => ({ ...p, sapmalar: p.sapmalar.map((s) => (s.id === id ? { ...s, ...patch } : s)) }));
  }, []);

  const sapmaSil = useCallback((id: string) => {
    setWs((p) => ({ ...p, sapmalar: p.sapmalar.filter((s) => s.id !== id) }));
  }, []);

  // ── AI ──
  const aiNedenler = useCallback(async (ctx: HazopAiCtx): Promise<HazopAiCevap> => {
    return aiHazopOnerileri({
      ...ctx,
      firma: ws.temel.firma,
      tesis: ws.temel.tesis,
      proses: ws.temel.proses,
      kapsam: ws.temel.kapsam,
      nace: ws.temel.nace,
      tehlikeSinifi: ws.temel.tehlikeSinifi,
    });
  }, [ws.temel]);

  // ── Adım doğrulama ──
  const adimGecerli = useCallback((idx: number): string | null => {
    if (idx === 0) {
      if (!ws.temel.calismaAdi.trim()) return 'Çalışma Adı zorunludur.';
      if (!ws.temel.tesis.trim()) return 'Tesis / İş Yeri zorunludur.';
      if (!ws.temel.kapsam.trim()) return 'HAZOP Kapsamı zorunludur.';
    }
    if (idx === 1) {
      if (ws.dugumler.length === 0) return 'Devam etmek için en az bir düğüm ekleyin.';
      if (ws.dugumler.some((d) => !d.ad.trim())) return 'Tüm düğümlerin adı doldurulmalıdır.';
    }
    if (idx === 2 && ws.sapmalar.length === 0) return 'Devam etmek için en az bir sapma kaydedin.';
    return null;
  }, [ws.temel, ws.dugumler, ws.sapmalar]);

  const sonraki = useCallback(() => {
    const hata = adimGecerli(adim);
    if (hata) { addToast({ title: 'Eksik bilgi', message: hata, type: 'warning' }); return; }
    setAdim((a) => Math.min(4, a + 1));
  }, [adim, adimGecerli, addToast]);

  const sifirla = useCallback(async () => {
    await hzWorkspaceTemizle();
    setWs(bosHzWorkspace());
    setAdim(0);
    setSifirlaOnay(false);
    addToast({ title: 'Çalışma sıfırlandı', message: 'Yeni bir HAZOP çalışmasına başlayabilirsiniz.', type: 'success' });
  }, [addToast]);

  const hizliPdf = useCallback(async () => {
    if (ws.sapmalar.length === 0) {
      addToast({ title: 'Sapma listesi boş', message: 'Rapor için en az bir sapma gerekir.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndiriliyor(true);
    try {
      await pdfIndir({ temel: ws.temel, dugumler: ws.dugumler, sapmalar: ws.sapmalar });
      addToast({ title: 'Rapor hazır', message: 'PDF indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Rapor oluşturulamadı', message: 'Beklenmeyen bir hata oluştu.', type: 'error' });
    } finally {
      setIndiriliyor(false);
    }
  }, [ws, addToast, indiriliyor]);

  const sapmaSayisi = useCallback((dugumId: string) => ws.sapmalar.filter((s) => s.dugumId === dugumId).length, [ws.sapmalar]);

  if (!hazir) {
    return (
      <div className="flex min-h-0 flex-1 items-center justify-center">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex-shrink-0 border-b border-background-300/25 dark:border-background-400/35">
        <RwStepper steps={HZ_ADIM_BASLIKLARI} current={adim} onStepClick={(idx) => { if (idx < adim) setAdim(idx); }} />
      </div>

      <div className="flex min-h-0 flex-1 gap-3 overflow-hidden px-5 py-4">
        {adim >= 1 && (
          <HzDugumPaneli
            dugumler={ws.dugumler}
            seciliId={seciliDugum?.id ?? ''}
            onSec={dugumSec}
            onEkle={dugumEkle}
            onSil={dugumSil}
            onDuzenle={(id) => { dugumSec(id); setAdim(1); }}
            sapmaSayisi={sapmaSayisi}
          />
        )}

        <div className="flex min-h-0 min-w-0 flex-1 flex-col">
          {adim === 0 && <HzAdim1Temel temel={ws.temel} onChange={temelGuncelle} />}
          {adim === 1 && <HzAdim2Dugum dugum={seciliDugum} onChange={dugumGuncelle} />}
          {adim === 2 && (
            <HzAdim3Sapmalar
              dugum={seciliDugum} sapmalar={ws.sapmalar}
              onKaydet={sapmaKaydet} onSil={sapmaSil}
              onDugumDuzenle={() => setAdim(1)} aiNedenler={aiNedenler}
            />
          )}
          {adim === 3 && (
            <HzAdim4Sonuclar
              dugum={seciliDugum} sapmalar={ws.sapmalar}
              onGuncelle={sapmaGuncelle}
              onDugumDuzenle={() => setAdim(1)}
              onGenelNot={(v) => { if (seciliDugum) dugumGuncelle(seciliDugum.id, { genelNot: v }); }}
              aiNedenler={aiNedenler}
            />
          )}
          {adim === 4 && (
            <HzAdim5Rapor
              temel={ws.temel} dugumler={ws.dugumler} sapmalar={ws.sapmalar}
              onTemelChange={temelGuncelle}
            />
          )}
        </div>
      </div>

      <div className="flex flex-shrink-0 items-center justify-between gap-2 border-t isg-divider px-5 py-3">
        <div className="flex items-center gap-2">
          <RwButton variant="ghost" icon="ri-close-line" onClick={onClose}>İptal</RwButton>
          {sifirlaOnay ? (
            <Alert
              variant="danger"
              action={(
                <div className="flex items-center gap-2">
                  <RwButton variant="primary" size="sm" icon="ri-refresh-line" onClick={() => void sifirla()}>Evet, Sıfırla</RwButton>
                  <RwButton variant="ghost" size="sm" onClick={() => setSifirlaOnay(false)}>Vazgeç</RwButton>
                </div>
              )}
            >
              Tüm HAZOP çalışması silinsin mi?
            </Alert>
          ) : (
            <RwButton variant="ghost" icon="ri-refresh-line" onClick={() => setSifirlaOnay(true)}>Sıfırla</RwButton>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden text-xs text-foreground-400 sm:inline">
            <i className="ri-information-line mr-1" /> Bu çalışma geçici olarak tutulur; kalıcı kayıt oluşturmaz.
          </span>
          {adim > 0 && (
            <RwButton variant="secondary" icon="ri-arrow-left-line" onClick={() => setAdim((a) => Math.max(0, a - 1))}>Önceki Adım</RwButton>
          )}
          {adim < 4
            ? <RwButton variant="primary" iconAfter="ri-arrow-right-line" onClick={sonraki}>Sonraki Adım</RwButton>
            : <RwButton variant="primary" icon="ri-file-download-line" onClick={() => void hizliPdf()}>{indiriliyor ? 'Oluşturuluyor...' : 'Raporu Oluştur ve İndir'}</RwButton>}
        </div>
      </div>
    </div>
  );
}