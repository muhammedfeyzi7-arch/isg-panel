// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM EYLEM PLANI — ORTAK VERİ MODELİ
//
// 5x5 / Fine-Kinney / HAZOP / Yıllık Çalışma Planı / Yıllık Eğitim Planı ile
// AYNI sihirbaz mimarisini kullanır. Yöntem "acil durum odaklıdır": acil durum
// ekipleri, olası acil durum senaryoları, tahliye/toplanma bilgileri ve tahliye
// krokisi planlanır.
//
// HUKUKİ DAYANAK:
//  - 6331 sayılı İş Sağlığı ve Güvenliği Kanunu (m.11, m.12 — acil durumlar)
//  - İşyerlerinde Acil Durumlar Hakkında Yönetmelik
//  - Binaların Yangından Korunması Hakkında Yönetmelik
//  - İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği
//
// ÖNEMLİ: Kalıcı kayıt/arşiv YOKTUR. Çalışma yalnızca yerel (IndexedDB) tutulur
// ve kullanıcı yalnızca Word / PDF / Excel (ve CSV/TXT) indirir. Sisteme veri gitmez.
// Acil durum ekibi; ELLE eklenebilir VEYA sistemdeki personelden SEÇİLEBİLİR.
// Seçim yalnızca okuma içindir; personel kaydına HİÇBİR ŞEY yazılmaz.
// ─────────────────────────────────────────────────────────────────────────────
import {
  type TemelBilgiler,
  type Imzaci,
  yeniId,
  benzerMi,
  normalize,
} from './riskSihirbazTypes';

export { yeniId, benzerMi, normalize };
export type { Imzaci, TemelBilgiler };

export const ACIL_METODU =
  'Acil Durum Eylem Planı (6331 s. Kanun · İşyerlerinde Acil Durumlar Hakkında Yönetmelik)';

export const ACIL_PLAN_ADI_ORNEK = 'Acil Durum Eylem Planı';

// ── Ay adları (rapor tarihleri için ortak) ───────────────────────────────────
export const AY_KISA: string[] = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

// ── Acil durum ekip rolleri ──────────────────────────────────────────────────
export const EKIP_ROLLERI: string[] = [
  'Acil Durum Koordinatörü',
  'Söndürme Ekibi',
  'Kurtarma Ekibi',
  'İlk Yardım Ekibi',
  'Koruma Ekibi',
  'Tahliye Ekibi',
  'Haberleşme / İhbar Ekibi',
];

export function rolIkon(rol: string): string {
  const t = (rol || '').toLocaleLowerCase('tr');
  if (t.includes('koordinatör') || t.includes('koordinator')) return 'ri-user-star-line';
  if (t.includes('söndürme') || t.includes('sondurme')) return 'ri-fire-line';
  if (t.includes('kurtarma')) return 'ri-lifebuoy-line';
  if (t.includes('ilk yardım') || t.includes('ilk yardim')) return 'ri-first-aid-kit-line';
  if (t.includes('koruma')) return 'ri-shield-check-line';
  if (t.includes('tahliye')) return 'ri-door-open-line';
  if (t.includes('haberleşme') || t.includes('haberlesme') || t.includes('ihbar')) return 'ri-megaphone-line';
  return 'ri-team-line';
}

export interface RolMeta {
  fg: string;
  bg: string;
  soft: string;
  dot: string;
}

export function rolMeta(rol: string): RolMeta {
  const t = (rol || '').toLocaleLowerCase('tr');
  if (t.includes('koordinatör') || t.includes('koordinator')) return { fg: '#B91C1C', bg: '#FDE7E7', soft: 'bg-danger-500/15 text-danger-700 dark:text-danger-300', dot: 'bg-danger-500' };
  if (t.includes('söndürme') || t.includes('sondurme')) return { fg: '#C2410C', bg: '#FFEDD5', soft: 'bg-orange-500/15 text-orange-700 dark:text-orange-300', dot: 'bg-orange-500' };
  if (t.includes('kurtarma')) return { fg: '#1D4ED8', bg: '#DCE7FA', soft: 'bg-primary-500/15 text-primary-700 dark:text-primary-300', dot: 'bg-primary-500' };
  if (t.includes('ilk yardım') || t.includes('ilk yardim')) return { fg: '#15803D', bg: '#E7F7EE', soft: 'bg-success-500/15 text-success-700 dark:text-success-300', dot: 'bg-success-500' };
  if (t.includes('koruma')) return { fg: '#4338CA', bg: '#E0E7FF', soft: 'bg-secondary-500/15 text-secondary-700 dark:text-secondary-300', dot: 'bg-secondary-500' };
  if (t.includes('tahliye')) return { fg: '#0E7490', bg: '#CFFAFE', soft: 'bg-secondary-500/15 text-secondary-700 dark:text-secondary-300', dot: 'bg-secondary-500' };
  if (t.includes('haberleşme') || t.includes('haberlesme') || t.includes('ihbar')) return { fg: '#B45309', bg: '#FEF3C7', soft: 'bg-accent-500/15 text-accent-700 dark:text-accent-300', dot: 'bg-accent-500' };
  return { fg: '#374151', bg: '#EEF3F9', soft: 'bg-background-200 text-foreground-600', dot: 'bg-foreground-400' };
}

// ── Zorunlu acil durum ekipleri (Yönetmelik m.8) ─────────────────────────────
// İşveren, tehlike sınıfına bakılmaksızın bu dört ekibi oluşturmak zorundadır.
export const ZORUNLU_EKIPLER: string[] = [
  'Söndürme Ekibi',
  'Kurtarma Ekibi',
  'Koruma Ekibi',
  'İlk Yardım Ekibi',
];

export interface DestekHesapSatiri {
  konu: string;
  oran: string;
  gerekli: number;
}

export interface DestekHesap {
  gecerli: boolean;
  kucukIsyeri: boolean;
  ozet: string;
  satirlar: DestekHesapSatiri[];
}

function tehlikeKategori(s: string): 'az' | 'teh' | 'cok' | '' {
  const t = (s || '').toLocaleLowerCase('tr');
  if (t.includes('çok') || t.includes('cok')) return 'cok';
  if (t.includes('az')) return 'az';
  if (t.includes('tehlikeli')) return 'teh';
  return '';
}

/**
 * İşyerlerinde Acil Durumlar Hakkında Yönetmelik m.11 + İlkyardım Yönetmeliği
 * uyarınca AYGARİ destek elemanı (ekip üyesi) sayısı hesabı.
 *  • Çok tehlikeli: her 30 çalışana 1  · Tehlikeli: her 40  · Az tehlikeli: her 50
 *  • 10'dan az çalışan: her konu için en az 1
 *  • İlk yardımcı: çok tehlikeli 10'a 1 · tehlikeli 15'e 1 · az tehlikeli 20'ye 1
 */
export function destekElemaniHesabi(tehlikeSinifi: string, calisanSayisiStr: string): DestekHesap {
  const n = parseInt(String(calisanSayisiStr).replace(/[^0-9]/g, ''), 10) || 0;
  const kat = tehlikeKategori(tehlikeSinifi);
  if (!kat || n <= 0) {
    return {
      gecerli: false,
      kucukIsyeri: false,
      ozet: 'Tehlike sınıfı ve çalışan sayısı girildiğinde zorunlu destek elemanı sayısı otomatik hesaplanır.',
      satirlar: [],
    };
  }
  if (n < 10) {
    return {
      gecerli: true,
      kucukIsyeri: true,
      ozet: '10’dan az çalışanı olan işyerlerinde söndürme, kurtarma ve koruma için en az 1’er destek elemanı yeterlidir.',
      satirlar: [
        { konu: 'Yangınla mücadele (Söndürme)', oran: '10’dan az çalışan → en az 1', gerekli: 1 },
        { konu: 'Arama-Kurtarma-Tahliye', oran: '10’dan az çalışan → en az 1', gerekli: 1 },
        { konu: 'Koruma', oran: '10’dan az çalışan → en az 1', gerekli: 1 },
      ],
    };
  }
  const bolen = kat === 'cok' ? 30 : kat === 'teh' ? 40 : 50;
  const ilkBolen = kat === 'cok' ? 10 : kat === 'teh' ? 15 : 20;
  return {
    gecerli: true,
    kucukIsyeri: false,
    ozet: 'Yönetmelik m.11 uyarınca asgari destek elemanı ve ilk yardımcı sayıları.',
    satirlar: [
      { konu: 'Yangınla mücadele (Söndürme)', oran: `Her ${bolen} çalışana 1`, gerekli: Math.ceil(n / bolen) },
      { konu: 'Arama-Kurtarma-Tahliye', oran: `Her ${bolen} çalışana 1`, gerekli: Math.ceil(n / bolen) },
      { konu: 'İlk Yardım (İlkyardım Yön.)', oran: `Her ${ilkBolen} çalışana 1`, gerekli: Math.ceil(n / ilkBolen) },
    ],
  };
}

// ── Acil durum ekip üyesi ────────────────────────────────────────────────────
export interface EkipUyesi {
  id: string;
  adSoyad: string;
  gorev: string;        // Firma içindeki unvan / pozisyon
  ekipRolu: string;     // EKIP_ROLLERI'den
  telefon: string;
  belge: string;        // Eğitim / sertifika bilgisi
  kaynak: 'manuel' | 'sistem';
  personelId?: string;
}

export function bosEkipUyesi(rol = EKIP_ROLLERI[1]): EkipUyesi {
  return { id: yeniId('ek'), adSoyad: '', gorev: '', ekipRolu: rol, telefon: '', belge: '', kaynak: 'manuel' };
}

// ── Acil durum senaryoları ───────────────────────────────────────────────────
export const SENARYO_KATEGORILERI: string[] = [
  'Yangın ve Patlama',
  'Doğal Afet',
  'Kimyasal ve Gaz',
  'Elektrik ve Enerji',
  'Makine ve Ekipman',
  'İnsan Kaynaklı (Güvenlik)',
  'Sağlık ve Salgın',
  'Çevresel',
];

export function senaryoIkon(kategori: string): string {
  const t = (kategori || '').toLocaleLowerCase('tr');
  if (t.includes('yangın') || t.includes('yangin') || t.includes('patlama')) return 'ri-fire-line';
  if (t.includes('doğal') || t.includes('dogal') || t.includes('afet')) return 'ri-earthquake-line';
  if (t.includes('kimyasal') || t.includes('gaz')) return 'ri-flask-line';
  if (t.includes('elektrik') || t.includes('enerji')) return 'ri-flashlight-line';
  if (t.includes('makine') || t.includes('ekipman')) return 'ri-settings-3-line';
  if (t.includes('insan') || t.includes('güvenlik') || t.includes('guvenlik')) return 'ri-shield-user-line';
  if (t.includes('sağlık') || t.includes('saglik') || t.includes('salgın') || t.includes('saldin')) return 'ri-heart-pulse-line';
  if (t.includes('çevre') || t.includes('cevre')) return 'ri-leaf-line';
  return 'ri-alarm-warning-line';
}

export const ACIL_DERECELERI: string[] = ['Düşük', 'Orta', 'Yüksek'];

export interface DereceMeta {
  label: string;
  soft: string;
  dot: string;
  hex: { fg: string; bg: string };
}

export const DERECE_META: Record<string, DereceMeta> = {
  Yüksek: {
    label: 'Yüksek', soft: 'bg-danger-500/15 text-danger-700 dark:text-danger-300', dot: 'bg-danger-500',
    hex: { fg: '#B91C1C', bg: '#FDE7E7' },
  },
  Orta: {
    label: 'Orta', soft: 'bg-warning-500/15 text-warning-700 dark:text-warning-300', dot: 'bg-warning-500',
    hex: { fg: '#B45309', bg: '#FEF3C7' },
  },
  Düşük: {
    label: 'Düşük', soft: 'bg-success-500/15 text-success-700 dark:text-success-300', dot: 'bg-success-500',
    hex: { fg: '#15803D', bg: '#E7F7EE' },
  },
};

export function dereceMeta(derece: string): DereceMeta {
  return DERECE_META[derece] ?? DERECE_META.Orta;
}

export interface AcilSenaryo {
  id: string;
  kategori: string;
  olay: string;          // Olay / senaryo başlığı
  aciklama: string;      // Senaryo açıklaması
  derece: string;        // ACIL_DERECELERI'den
  etkilenen: string;     // Etkilenen alan / gruplar
  mudahale: string;      // Müdahale / eylem adımları
  sorumluEkip: string;   // Sorumlu ekip rolü
  tahliyeGerekli: boolean;
}

export function bosSenaryo(kategori = SENARYO_KATEGORILERI[0], derece = 'Orta'): AcilSenaryo {
  return {
    id: yeniId('sn'),
    kategori,
    olay: '',
    aciklama: '',
    derece,
    etkilenen: '',
    mudahale: '',
    sorumluEkip: EKIP_ROLLERI[1],
    tahliyeGerekli: true,
  };
}

/** AI acil durum senaryo önerisi — listeye EKLENMEDEN önceki öneri kartı. */
export interface AcilAiOneri {
  id: string;
  kategori: string;
  olay: string;
  aciklama: string;
  derece: string;
  etkilenen: string;
  mudahale: string;
  sorumluEkip: string;
  tahliyeGerekli: boolean;
}

// ── Hazır senaryo şablonları ("Şablondan Ekle") ──────────────────────────────
export interface SenaryoSablon {
  kategori: string;
  olay: string;
  aciklama: string;
  derece: string;
  etkilenen: string;
  mudahale: string;
  sorumluEkip: string;
  tahliyeGerekli: boolean;
}

export const SENARYO_SABLONLARI: SenaryoSablon[] = [
  { kategori: 'Yangın ve Patlama', olay: 'Elektrik Kaynaklı Yangın', aciklama: 'Elektrik panosu/tesisatı kaynaklı yangın çıkması.', derece: 'Yüksek', etkilenen: 'Üretim alanı, elektrik odası', mudahale: 'Enerji kesilir, yangın söndürme ekibi KKT ile müdahale eder, alan tahliye edilir.', sorumluEkip: 'Söndürme Ekibi', tahliyeGerekli: true },
  { kategori: 'Yangın ve Patlama', olay: 'Kimyasal Yangın', aciklama: 'Yanıcı kimyasal maddelerin tutuşması sonucu yangın/patlama.', derece: 'Yüksek', etkilenen: 'Kimyasal depo, üretim', mudahale: 'Uygun tip söndürücü ile müdahale, ilgili GBF/SDS prosedürü uygulanır.', sorumluEkip: 'Söndürme Ekibi', tahliyeGerekli: true },
  { kategori: 'Doğal Afet', olay: 'Deprem', aciklama: 'Deprem sonrası yapısal hasar, yaralanma ve tahliye ihtiyacı.', derece: 'Yüksek', etkilenen: 'Tüm tesis ve çalışanlar', mudahale: 'Sarsıntı geçince güvenli tahliye, toplanma alanında yoklama, kurtarma ekibi devreye girer.', sorumluEkip: 'Kurtarma Ekibi', tahliyeGerekli: true },
  { kategori: 'Doğal Afet', olay: 'Sel / Su Baskını', aciklama: 'Yoğun yağış veya altyapı sorunu nedeniyle su baskını.', derece: 'Orta', etkilenen: 'Zemin kat, depo', mudahale: 'Elektrik kesilir, su kaynağı kapatılır, güvenli alana tahliye edilir.', sorumluEkip: 'Koruma Ekibi', tahliyeGerekli: true },
  { kategori: 'Kimyasal ve Gaz', olay: 'Kimyasal Madde Sızıntısı', aciklama: 'Kimyasal madde dökülmesi/sızıntısı ve buhar yayılımı.', derece: 'Yüksek', etkilenen: 'Kimyasal depo, üretim hattı', mudahale: 'Alan izole edilir, kişisel koruyucu ile müdahale, döküntü seti kullanılır.', sorumluEkip: 'Kurtarma Ekibi', tahliyeGerekli: true },
  { kategori: 'Kimyasal ve Gaz', olay: 'Doğal Gaz Kaçağı', aciklama: 'Doğal gaz hattında kaçak ve birikme.', derece: 'Yüksek', etkilenen: 'Kazan dairesi, mutfak, üretim', mudahale: 'Gaz hattı kesilir, kıvılcım/statik yasak, alan tahliye edilir, gaz dağıtıcısı çağrılır.', sorumluEkip: 'Koruma Ekibi', tahliyeGerekli: true },
  { kategori: 'Elektrik ve Enerji', olay: 'Elektrik Çarpması', aciklama: 'Elektrik teması sonucu yaralanma veya ölüm.', derece: 'Yüksek', etkilenen: 'Elektrik bakım personeli', mudahale: 'Enerji kesilir, güvenli müdahale, ilk yardım ve 112 çağrısı yapılır.', sorumluEkip: 'İlk Yardım Ekibi', tahliyeGerekli: false },
  { kategori: 'Elektrik ve Enerji', olay: 'Enerji Kesintisi', aciklama: 'Kapsamlı elektrik kesintisi ve acil aydınlatma ihtiyacı.', derece: 'Orta', etkilenen: 'Tüm tesis', mudahale: 'Jeneratör/AKS devreye alınır, karanlık alanlar kontrollü tahliye edilir.', sorumluEkip: 'Koruma Ekibi', tahliyeGerekli: false },
  { kategori: 'Makine ve Ekipman', olay: 'Forklift/Kaldırma Kaynaklı Kaza', aciklama: 'Forklift devrilmesi veya çarpma sonucu yaralanma.', derece: 'Orta', etkilenen: 'Depo, yükleme alanı', mudahale: 'Alan boşaltılır, yaralıya ilk yardım, ekipman güvenli konuma alınır.', sorumluEkip: 'İlk Yardım Ekibi', tahliyeGerekli: false },
  { kategori: 'Makine ve Ekipman', olay: 'Basınçlı Kap Patlaması', aciklama: 'Basınçlı kap/kazan patlaması sonucu yaralanma ve maddi hasar.', derece: 'Yüksek', etkilenen: 'Kazan dairesi, üretim', mudahale: 'Enerji kesilir, alan tahliye edilir, kurtarma ekibi devreye girer.', sorumluEkip: 'Kurtarma Ekibi', tahliyeGerekli: true },
  { kategori: 'İnsan Kaynaklı (Güvenlik)', olay: 'Sabotaj / İzinsiz Giriş', aciklama: 'İzinsiz giriş veya kasıtlı zarar verme girişimi.', derece: 'Orta', etkilenen: 'Tüm tesis', mudahale: 'Güvenlik protokolü devreye alınır, kolluk kuvvetlerine haber verilir.', sorumluEkip: 'Haberleşme / İhbar Ekibi', tahliyeGerekli: false },
  { kategori: 'Sağlık ve Salgın', olay: 'Ani Rahatsızlık / Yaralanma', aciklama: 'Çalışanın ani rahatsızlanması veya iş kazası yaralanması.', derece: 'Orta', etkilenen: 'İlgili çalışan', mudahale: 'İlk yardım ekibi müdahale eder, gerekiyorsa 112 çağrılır.', sorumluEkip: 'İlk Yardım Ekibi', tahliyeGerekli: false },
  { kategori: 'Sağlık ve Salgın', olay: 'Bulaşıcı Hastalık / Salgın', aciklama: 'Bulaşıcı hastalık yayılımı ve toplu etkilenme riski.', derece: 'Orta', etkilenen: 'Tüm çalışanlar', mudahale: 'İzolasyon, hijyen önlemleri ve yetkili sağlık kuruluşu bilgilendirmesi.', sorumluEkip: 'Haberleşme / İhbar Ekibi', tahliyeGerekli: false },
  { kategori: 'Çevresel', olay: 'Çevresel Kirlilik / Dökülme', aciklama: 'Atık/yağ/kimyasal dökülmesiyle çevre kirliliği.', derece: 'Düşük', etkilenen: 'Açık alan, drenaj', mudahale: 'Sızıntı kontrol altına alınır, döküntü seti/emici malzeme ile temizlenir.', sorumluEkip: 'Koruma Ekibi', tahliyeGerekli: false },
];

export function sablondanSenaryo(s: SenaryoSablon): AcilSenaryo {
  return { id: yeniId('sn'), ...s };
}

// ── Temel bilgiler (acil duruma özel alanlarla) ──────────────────────────────
export interface AcilTemelBilgiler extends TemelBilgiler {
  planYili: string;
  /** Toplanma / buluşma noktası. */
  toplanmaYeri: string;
  /** Acil durum ihbar / çağrı merkezi bilgisi (112 vb.). */
  acilIhbar: string;
  /** Acil durum aydınlatması ve yönlendirme durumu. */
  isgDurumu?: string;
  /** Engelli / özel durumlu çalışanlar için tahliye önlemleri. */
  ozelDurumNotu?: string;
}

export function bosAcilTemel(): AcilTemelBilgiler {
  const bugun = new Date();
  const iso = `${bugun.getFullYear()}-${String(bugun.getMonth() + 1).padStart(2, '0')}-${String(bugun.getDate()).padStart(2, '0')}`;
  return {
    calismaAdi: '',
    firma: '',
    degerlendirmeMetodu: ACIL_METODU,
    kapsam: '',
    tarih: iso,
    tesis: '',
    gecerlilik: '',
    amac: '',
    ekip: [],
    dokumanlar: [],
    raporNo: '',
    tehlikeSinifi: '',
    adres: '',
    isveren: '',
    nace: '',
    naceId: '',
    calisanSayisi: '',
    hazirlayan: '',
    onaylayan: '',
    imzacilar: [],
    planYili: String(bugun.getFullYear()),
    toplanmaYeri: '',
    acilIhbar: '112 (Acil Çağrı Merkezi)',
    ozelDurumNotu: '',
  };
}

// ── Kapsam maddeleri ─────────────────────────────────────────────────────────
export const KAPSAM_MADDELERI: string[] = [
  'Acil durum ekiplerinin kurulması ve görev tanımları',
  'Acil durum ihbar ve iletişim sisteminin kurulması',
  'Yangın söndürme ekipmanlarının temini ve kontrolü',
  'Tahliye yolları ve acil çıkışların belirlenmesi',
  'Toplanma (buluşma) noktasının belirlenmesi',
  'Acil durum aydınlatması ve yönlendirme levhaları',
  'İlk yardım malzeme ve ekipmanlarının hazır tutulması',
  'Kurtarma ekipmanlarının temini ve kullanımı',
  'Yangın ve tahliye tatbikatlarının periyodik yapılması',
  'Doğal afet (deprem/sel) hazırlık ve önlemleri',
  'Kimyasal/gaz sızıntısına müdahale prosedürleri',
  'Acil durum planının gözden geçirilmesi ve güncellenmesi',
  'Çalışanların acil durum konusunda bilgilendirilmesi',
  'Engelli çalışanlar için özel tahliye önlemleri',
  'Yıllık tatbikat planının hazırlanması ve uygulanması',
  'Acil durum iletişim numaralarının ilan edilmesi',
  'Acil durum malzeme ve ekipman envanterinin takibi',
  'Zorunlu destek elemanı (ekip üyesi) sayılarının sağlanması',
];

// ── Acil iletişim numaraları ─────────────────────────────────────────────────
export interface AcilIletisim {
  id: string;
  kurum: string;
  telefon: string;
}

export const ILETISIM_SABLON: { kurum: string; telefon: string }[] = [
  { kurum: 'Acil Çağrı Merkezi (Ambulans · İtfaiye · Polis)', telefon: '112' },
  { kurum: 'Jandarma', telefon: '156' },
  { kurum: 'Doğal Gaz Acil', telefon: '187' },
  { kurum: 'Elektrik Arıza', telefon: '186' },
  { kurum: 'Zehir Danışma Merkezi (UZEM)', telefon: '114' },
  { kurum: 'İşyeri Acil Durum Koordinatörü', telefon: '' },
  { kurum: 'İşveren / Vekili', telefon: '' },
];

export function varsayilanIletisim(): AcilIletisim[] {
  return ILETISIM_SABLON.map((s) => ({ id: yeniId('il'), kurum: s.kurum, telefon: s.telefon }));
}

export function bosIletisim(): AcilIletisim {
  return { id: yeniId('il'), kurum: '', telefon: '' };
}

// ── Acil durum malzeme / ekipman envanteri ───────────────────────────────────
export interface AcilMalzeme {
  id: string;
  ad: string;
  adet: number;
  konum: string;
  sonKontrol: string;
}

export const MALZEME_SABLON: { ad: string; konum: string }[] = [
  { ad: 'Yangın Söndürücü (Kuru Kimyevi / CO₂)', konum: '' },
  { ad: 'Yangın Hortumu / Dolabı', konum: '' },
  { ad: 'İlk Yardım Çantası', konum: '' },
  { ad: 'Acil Durum Aydınlatması', konum: '' },
  { ad: 'Yangın Alarmı / Siren Sistemi', konum: '' },
  { ad: 'Duman Dedektörü', konum: '' },
  { ad: 'Sedye / Taşıma Ekipmanı', konum: '' },
  { ad: 'Gaz Maskesi / Solunum Koruyucu', konum: '' },
  { ad: 'Acil Çıkış Kapısı / Yönlendirme Levhası', konum: '' },
];

export function varsayilanMalzemeler(): AcilMalzeme[] {
  return MALZEME_SABLON.map((m) => ({ id: yeniId('mz'), ad: m.ad, adet: 0, konum: m.konum, sonKontrol: '' }));
}

export function bosMalzeme(): AcilMalzeme {
  return { id: yeniId('mz'), ad: '', adet: 1, konum: '', sonKontrol: '' };
}

// ── Tatbikat planı (Yönetmelik m.12) ─────────────────────────────────────────
export interface Tatbikat {
  id: string;
  tarih: string;
  konu: string;
  sorumlu: string;
  katilimci: string;
  aciklama: string;
}

export const TATBIKAT_KONULARI: string[] = [
  'Yangın ve Tahliye Tatbikatı',
  'Deprem Tatbikatı',
  'Kimyasal / Gaz Sızıntısı Tatbikatı',
  'İlk Yardım ve Kurtarma Tatbikatı',
  'Tam Kapsamlı Acil Durum Tatbikatı',
];

export function bosTatbikat(): Tatbikat {
  const bugun = new Date();
  const iso = `${bugun.getFullYear()}-${String(bugun.getMonth() + 1).padStart(2, '0')}-${String(bugun.getDate()).padStart(2, '0')}`;
  return { id: yeniId('tb'), tarih: iso, konu: TATBIKAT_KONULARI[0], sorumlu: '', katilimci: '', aciklama: '' };
}

// ── Boş kayıt üreticileri ────────────────────────────────────────────────────
export interface AcilWorkspace {
  temel: AcilTemelBilgiler;
  kapsam: string[];
  ekipler: EkipUyesi[];
  senaryolar: AcilSenaryo[];
  iletisim: AcilIletisim[];
  malzemeler: AcilMalzeme[];
  tatbikatlar: Tatbikat[];
  kroki: string;      // PNG dataURL (boşsa çizilmemiş)
  krokiVeri: string;  // Krokideki öğelerin JSON'u (tekrar düzenleme için)
  krokiNot: string;
  aiOnerileri: AcilAiOneri[];
  aktifAdim: number;
  guncellendi: string;
}

export function bosAcilWorkspace(): AcilWorkspace {
  return {
    temel: bosAcilTemel(),
    kapsam: [...KAPSAM_MADDELERI],
    ekipler: [],
    senaryolar: [],
    iletisim: varsayilanIletisim(),
    malzemeler: varsayilanMalzemeler(),
    tatbikatlar: [],
    kroki: '',
    krokiVeri: '',
    krokiNot: '',
    aiOnerileri: [],
    aktifAdim: 0,
    guncellendi: new Date().toISOString(),
  };
}

/** Referans örnek senaryolarla başlangıç (ilk kullanım). */
export function ornekSenaryolar(): AcilSenaryo[] {
  const secilen = [0, 2, 4, 5, 9, 12];
  return secilen.map((i) => sablondanSenaryo(SENARYO_SABLONLARI[i]));
}