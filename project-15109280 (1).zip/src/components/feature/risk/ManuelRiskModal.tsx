import { useState } from 'react';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import {
  RISK_KATEGORILERI,
  RISK_ALANLARI,
  riskPuani,
  riskSeviyesi,
  SEVIYE_META,
  type RiskItem,
} from './riskSihirbazTypes';

// ─────────────────────────────────────────────────────────────────────────────
// MANUEL RİSK EKLEME FORMU
//
// Kullanıcı tüm alanları girer; Risk Puanı (O × Ş) ve Risk Seviyesi OTOMATİK
// hesaplanır. Kaydedilen risk, AI'dan gelen risklerle AYNI merkezi modele girer;
// bu yüzden 3. ve 4. adıma da otomatik olarak yansır.
// ─────────────────────────────────────────────────────────────────────────────

export type ManuelRiskVerisi = Pick<
  RiskItem,
  'bolum' | 'kategori' | 'tehlike' | 'risk' | 'olasiSonuc' | 'mevcutKontroller' | 'notlar' | 'olasilik' | 'siddet'
>;

interface ManuelRiskModalProps {
  onKaydet: (veri: ManuelRiskVerisi) => void;
  onClose: () => void;
}

const SAYI_OPTIONS = [1, 2, 3, 4, 5].map((n) => ({ value: String(n), label: String(n) }));

export default function ManuelRiskModal({ onKaydet, onClose }: ManuelRiskModalProps) {
  const [bolum, setBolum] = useState('');
  const [kategori, setKategori] = useState('');
  const [tehlike, setTehlike] = useState('');
  const [risk, setRisk] = useState('');
  const [olasiSonuc, setOlasiSonuc] = useState('');
  const [mevcutKontroller, setMevcutKontroller] = useState('');
  const [notlar, setNotlar] = useState('');
  const [olasilik, setOlasilik] = useState('3');
  const [siddet, setSiddet] = useState('3');
  const [hata, setHata] = useState('');

  const o = Number(olasilik) || 1;
  const s = Number(siddet) || 1;
  const puan = riskPuani(o, s);
  const seviye = SEVIYE_META[riskSeviyesi(puan)];

  const kaydet = () => {
    if (!tehlike.trim() || !risk.trim()) {
      setHata('Tehlike ve Risk alanları zorunludur.');
      return;
    }
    onKaydet({
      bolum: bolum.trim(),
      kategori: kategori.trim(),
      tehlike: tehlike.trim(),
      risk: risk.trim(),
      olasiSonuc: olasiSonuc.trim(),
      mevcutKontroller: mevcutKontroller.trim(),
      notlar: notlar.trim(),
      olasilik: o,
      siddet: s,
    });
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Select
          label="Bölüm / Alan"
          options={RISK_ALANLARI.map((v) => ({ value: v, label: v }))}
          value={bolum}
          onChange={(e) => setBolum(e.target.value)}
          placeholder="Seçiniz veya yazın"
          searchable
          creatable
        />
        <Select
          label="Kategori"
          options={RISK_KATEGORILERI.map((v) => ({ value: v, label: v }))}
          value={kategori}
          onChange={(e) => setKategori(e.target.value)}
          placeholder="Seçiniz veya yazın"
          searchable
          creatable
        />
      </div>

      <Input label="Tehlike" required value={tehlike} onChange={(e) => setTehlike(e.target.value)} placeholder="Örn. Elektrik panosu" />
      <Input label="Risk" required value={risk} onChange={(e) => setRisk(e.target.value)} placeholder="Örn. Elektrik çarpması" />
      <Input label="Olası Sonuç" value={olasiSonuc} onChange={(e) => setOlasiSonuc(e.target.value)} placeholder="Örn. Ölüm / ciddi yaralanma" />
      <Textarea
        label="Mevcut Kontroller"
        value={mevcutKontroller}
        onChange={(e) => setMevcutKontroller(e.target.value)}
        maxLength={500}
        placeholder="Örn. Kaçak akım rölesi, topraklama, uyarı etiketleri"
      />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <Select label="Olasılık (1-5)" options={SAYI_OPTIONS} value={olasilik} onChange={(e) => setOlasilik(e.target.value)} />
        <Select label="Şiddet (1-5)" options={SAYI_OPTIONS} value={siddet} onChange={(e) => setSiddet(e.target.value)} />
        <div className="flex flex-col">
          <span className="mb-1.5 text-sm font-medium text-foreground-800">Hesaplanan</span>
          <div className="flex flex-1 items-center justify-between rounded-md border border-background-300/60 bg-background-100 px-3 dark:border-background-400/30 dark:bg-background-200/50">
            <span className="text-sm font-bold text-foreground-900">{puan}</span>
            <span className={`isg-badge isg-badge-sm ${seviye.badge}`}>{seviye.label}</span>
          </div>
        </div>
      </div>

      <Textarea label="Açıklama / Notlar" value={notlar} onChange={(e) => setNotlar(e.target.value)} maxLength={500} />

      {hata && (
        <p className="flex items-center gap-1 text-xs text-danger-600">
          <i className="ri-error-warning-line" />
          {hata}
        </p>
      )}

      <div className="flex items-center justify-end gap-2 border-t border-background-300/30 pt-3 dark:border-background-400/30">
        <button type="button" onClick={onClose} className="isg-btn isg-btn-ghost whitespace-nowrap cursor-pointer">
          İptal
        </button>
        <button type="button" onClick={kaydet} className="isg-btn isg-btn-primary whitespace-nowrap cursor-pointer">
          <i className="ri-add-line" />
          Listeye Ekle
        </button>
      </div>
    </div>
  );
}