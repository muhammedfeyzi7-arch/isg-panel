import { useState } from 'react';
import { bosMadde, type HzMadde } from '@/components/feature/risk/hazopTypes';

// ─────────────────────────────────────────────────────────────────────────────
// HAZOP · İŞARETLENEBİLİR MADDE LİSTESİ
//
// Nedenler, olası sonuçlar, mevcut kontroller ve ek önlemler için ortak widget.
// Her madde: onay kutusu (raporda yalnızca seçili olanlar gider) + metin + sil.
// Referans görsellerdeki "Olası Nedenler" listesine birebir uyar.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  maddeler: HzMadde[];
  onChange: (m: HzMadde[]) => void;
  ekleEtiketi?: string;
  placeholder?: string;
  bosMesaj?: string;
  /** true → satırlar daha sıkı (tablo hücresi içi). */
  kompakt?: boolean;
  /** Onay kutusu gizle (ör. ek önlemler listesi). */
  onayGizle?: boolean;
}

export default function HzMaddeListesi({
  maddeler, onChange, ekleEtiketi = 'Madde Ekle', placeholder = 'Yeni madde...', bosMesaj = 'Henüz madde eklenmedi.', kompakt, onayGizle,
}: Props) {
  const [yeni, setYeni] = useState('');
  const [acik, setAcik] = useState(false);

  const ekle = () => {
    const t = yeni.trim();
    if (!t) { setAcik(false); return; }
    onChange([...maddeler, bosMadde(t, true)]);
    setYeni(''); setAcik(false);
  };

  return (
    <div className={kompakt ? 'space-y-1' : 'space-y-1.5'}>
      {maddeler.length === 0 && !acik && (
        <p className="text-xs text-foreground-400">{bosMesaj}</p>
      )}

      {maddeler.map((m) => (
        <div key={m.id} className="flex items-center gap-2">
          {!onayGizle && (
            <button
              type="button"
              role="checkbox"
              aria-checked={m.secili}
              onClick={() => onChange(maddeler.map((x) => (x.id === m.id ? { ...x, secili: !x.secili } : x)))}
              className={`flex h-4 w-4 flex-shrink-0 cursor-pointer items-center justify-center rounded border text-[10px] ${
                m.secili ? 'border-primary-500 bg-primary-500 text-inverse' : 'border-background-300/80 bg-background-50 dark:border-background-400/50 dark:bg-background-100/60'
              }`}
            >
              {m.secili && <i className="ri-check-line" />}
            </button>
          )}
          <input
            value={m.metin}
            onChange={(e) => onChange(maddeler.map((x) => (x.id === m.id ? { ...x, metin: e.target.value } : x)))}
            className="h-7 min-w-0 flex-1 rounded border border-transparent bg-transparent px-1 text-xs text-foreground-800 outline-none hover:border-background-300/60 focus:border-primary-400 focus:bg-background-50 dark:hover:border-background-400/40 dark:focus:bg-background-100/60"
          />
          <button
            type="button"
            onClick={() => onChange(maddeler.filter((x) => x.id !== m.id))}
            className="flex h-6 w-6 flex-shrink-0 cursor-pointer items-center justify-center rounded text-foreground-400 hover:bg-danger-500/10 hover:text-danger-500"
            aria-label="Sil"
          >
            <i className="ri-delete-bin-line text-xs" />
          </button>
        </div>
      ))}

      {acik ? (
        <div className="flex items-center gap-1.5">
          <input
            autoFocus
            value={yeni}
            onChange={(e) => setYeni(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); ekle(); } if (e.key === 'Escape') setAcik(false); }}
            placeholder={placeholder}
            className="h-7 min-w-0 flex-1 rounded border border-background-300/70 bg-background-50 px-2 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
          />
          <button type="button" onClick={ekle} className="cursor-pointer text-success-600 dark:text-success-400" aria-label="Onayla"><i className="ri-check-line" /></button>
          <button type="button" onClick={() => setAcik(false)} className="cursor-pointer text-foreground-400" aria-label="Vazgeç"><i className="ri-close-line" /></button>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => setAcik(true)}
          className="inline-flex cursor-pointer items-center gap-1 whitespace-nowrap text-xs font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400"
        >
          <i className="ri-add-line" /> {ekleEtiketi}
        </button>
      )}
    </div>
  );
}