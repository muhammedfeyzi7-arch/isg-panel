import { useRef, useState } from 'react';
import DropdownPanel from '@/components/ui/DropdownPanel';
import { dugumTipIkon, type HzDugum } from '@/components/feature/risk/hazopTypes';

// ─────────────────────────────────────────────────────────────────────────────
// HAZOP · PROSES AKIŞINDAKİ DÜĞÜMLER (sol panel)
//
// Referans görsellerdeki sol kolon: numaralı düğüm listesi + üç nokta menüsü
// (düzenle / sil) + altta "+ Düğüm Ekle" düğmesi. Adım 2–5 boyunca sabit kalır.
//
// ÖNEMLİ (MANTIK DÜZELTMESİ): Üç nokta menüsü artık listenin kendi kaydırma
// alanı içine ÇİZİLMEZ. Liste `overflow-y-auto` bir kaptır ve içine absolute
// yerleştirilen menü, kabın dışına taştığında KIRPILIYORDU (listenin alt
// sıralarında menü açılamıyor/görünmüyordu). Menü, global DropdownPanel motoru
// ile document.body'ye PORTAL edilir → hiçbir kaydırma kabı tarafından
// kırpılmaz, viewport'a göre konumlanır.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  dugumler: HzDugum[];
  seciliId: string;
  onSec: (id: string) => void;
  onEkle: () => void;
  onSil: (id: string) => void;
  onDuzenle: (id: string) => void;
  sapmaSayisi: (dugumId: string) => number;
}

export default function HzDugumPaneli({ dugumler, seciliId, onSec, onEkle, onSil, onDuzenle, sapmaSayisi }: Props) {
  const [menuId, setMenuId] = useState('');
  const menuBtnRef = useRef<HTMLButtonElement>(null);

  const kapat = () => setMenuId('');

  return (
    <aside className="flex h-full min-h-0 w-[240px] flex-shrink-0 flex-col rounded-lg border border-background-300/50 bg-background-100 dark:border-background-400/30 dark:bg-background-200/40">
      <div className="flex-shrink-0 border-b border-background-300/40 px-3 py-2.5 dark:border-background-400/30">
        <h3 className="text-xs font-semibold text-foreground-950">Proses Akışındaki Düğümler</h3>
        <p className="mt-0.5 text-[11px] text-foreground-400">Toplam {dugumler.length} düğüm</p>
      </div>

      <div className="isg-scroll-pane min-h-0 flex-1 space-y-1.5 overflow-y-auto p-2">
        {dugumler.length === 0 && (
          <p className="px-1 py-6 text-center text-xs text-foreground-400">
            Henüz düğüm yok. Başlamak için bir düğüm ekleyin.
          </p>
        )}

        {dugumler.map((d, i) => {
          const aktif = seciliId === d.id;
          const adet = sapmaSayisi(d.id);
          return (
            <div
              key={d.id}
              className={`group relative flex items-start gap-2.5 rounded-lg border p-2 transition-colors ${
                aktif
                  ? 'border-primary-500 bg-primary-500/10'
                  : 'border-transparent hover:border-primary-300/60 hover:bg-background-50 dark:hover:bg-background-100/50'
              }`}
            >
              <button type="button" onClick={() => onSec(d.id)} className="flex min-w-0 flex-1 cursor-pointer items-start gap-2.5 text-left">
                <span className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md text-xs font-bold ${aktif ? 'bg-primary-500 text-inverse' : 'bg-background-200 text-foreground-600 dark:bg-background-300/60 dark:text-foreground-300'}`}>
                  {i + 1}
                </span>
                <span className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-md ${aktif ? 'bg-primary-500/15 text-primary-600 dark:text-primary-300' : 'bg-background-200/70 text-foreground-500 dark:bg-background-300/40'}`}>
                  <i className={`${dugumTipIkon(d.tip)} text-sm`} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-xs font-semibold text-foreground-950">{d.ad || 'İsimsiz Düğüm'}</span>
                  <span className="mt-0.5 block truncate text-[11px] text-foreground-500">{d.no}{adet > 0 ? ` · ${adet} sapma` : ''}</span>
                </span>
              </button>

              <div className="relative flex-shrink-0">
                <button
                  ref={menuId === d.id ? menuBtnRef : undefined}
                  type="button"
                  onClick={() => setMenuId((m) => (m === d.id ? '' : d.id))}
                  className="flex h-6 w-6 cursor-pointer items-center justify-center rounded text-foreground-400 opacity-0 transition-opacity hover:bg-background-200 group-hover:opacity-100 dark:hover:bg-background-300/50"
                  aria-label="Menü"
                  aria-haspopup="menu"
                  aria-expanded={menuId === d.id}
                >
                  <i className="ri-more-2-fill" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      <div className="flex-shrink-0 border-t border-background-300/40 p-2 dark:border-background-400/30">
        <button
          type="button"
          onClick={onEkle}
          className="flex w-full cursor-pointer items-center justify-center gap-1.5 rounded-md bg-primary-500 px-3 py-2 text-xs font-semibold text-inverse transition-colors hover:bg-primary-600"
        >
          <i className="ri-add-line" /> Düğüm Ekle
        </button>
      </div>

      {/* Üç nokta menüsü — portal edilir, scroll kabı tarafından KIRPILMAZ. */}
      <DropdownPanel
        open={!!menuId}
        anchorRef={menuBtnRef}
        onClose={kapat}
        align="end"
        minWidth={168}
        role="menu"
        className="isg-popover"
      >
        <div className="p-1">
          <button
            type="button"
            onClick={() => { const id = menuId; kapat(); if (id) onDuzenle(id); }}
            className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40"
          >
            <i className="ri-edit-line" /> Düğümü Düzenle
          </button>
          <button
            type="button"
            onClick={() => { const id = menuId; kapat(); if (id) onSil(id); }}
            className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-danger-600 hover:bg-danger-500/10 dark:text-danger-400"
          >
            <i className="ri-delete-bin-line" /> Düğümü Sil
          </button>
        </div>
      </DropdownPanel>
    </aside>
  );
}