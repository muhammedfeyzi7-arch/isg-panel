import { useRef, useState } from 'react';
import {
  HZ_KLAVUZ_KELIMELER, HZ_METODU, HZ_TESIS_SECENEKLERI, type HzTemelBilgiler,
} from '@/components/feature/risk/hazopTypes';
import { GECERLILIK_SECENEKLERI, TEHLIKE_SINIFLARI, tehlikeGecerlilikPatch } from '@/components/feature/risk/riskSihirbazTypes';
import { RwButton, RwChip, RwInput, RwSelect, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';
import RiskNaceSecici from '@/components/feature/risk/RiskNaceSecici';

// ─────────────────────────────────────────────────────────────────────────────
// HAZOP · ADIM 1 — TEMEL BİLGİLER (Referans görsel 5)
// Sol: iki kolonlu form → HAZOP Çalışma Ekibi → Referans Dokümanlar.
// Sağ: "HAZOP Hakkında" (IEC 61882 – 5 aşama) + "HAZOP Kılavuz Kelimeleri".
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: HzTemelBilgiler;
  onChange: (patch: Partial<HzTemelBilgiler>) => void;
}

const ASAMALAR = [
  'Hazırlık (ekip, kapsam, dokümanların toplanması)',
  'Düğüm (node) belirlenmesi ve tasarım amacının tanımlanması',
  'Kılavuz kelimeler kullanılarak sapmaların incelenmesi',
  'Neden, sonuç, mevcut kontrol ve önlemlerin değerlendirilmesi',
  'Bulguların raporlanması ve takip edilmesi',
];

export default function HzAdim1Temel({ temel, onChange }: Props) {
  const [ekipGirdi, setEkipGirdi] = useState('');
  const dosyaRef = useRef<HTMLInputElement>(null);

  const ekipEkle = () => {
    const ad = ekipGirdi.trim();
    if (!ad) return;
    if (!temel.ekip.includes(ad)) onChange({ ekip: [...temel.ekip, ad] });
    setEkipGirdi('');
  };

  const dosyaSec = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const adlar = Array.from(files).map((f) => f.name);
    onChange({ dokumanlar: Array.from(new Set([...temel.dokumanlar, ...adlar])) });
  };

  return (
    <div className="isg-scroll-pane min-h-0 flex-1 overflow-y-auto overflow-x-hidden pr-1">
      <div className="pb-3">
        <h2 className="text-sm font-bold text-foreground-950">1. Temel Bilgiler</h2>
        <p className="mt-1 text-xs text-foreground-500">
          HAZOP çalışmasına ait temel bilgileri tanımlayın.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
        {/* SOL */}
        <div>
          <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-2">
            <RwInput
              label="Çalışma Adı" required
              value={temel.calismaAdi}
              onChange={(e) => onChange({ calismaAdi: e.target.value })}
              placeholder="Örn. Kimyasal Üretim Tesisi HAZOP Çalışması"
            />
            <RwInput
              label="Çalışma Tarihi" required type="date"
              value={temel.tarih}
              onChange={(e) => onChange({ tarih: e.target.value })}
            />

            <RwInput label="Firma" value={temel.firma} onChange={(e) => onChange({ firma: e.target.value })} placeholder="Firma ünvanı" />
            <RwSelect
              label="Tesis / İş Yeri" required searchable creatable
              options={HZ_TESIS_SECENEKLERI.map((v) => ({ value: v, label: v }))}
              value={temel.tesis} onChange={(v) => onChange({ tesis: v })} placeholder="Tesis seçiniz"
            />

            <RwInput
              label="Proses / Sistem" required
              value={temel.proses}
              onChange={(e) => onChange({ proses: e.target.value })}
              placeholder="Örn. Amonyak Üretim Prosesi"
            />
            <RwInput
              label="HAZOP Kapsamı" required
              value={temel.kapsam}
              onChange={(e) => onChange({ kapsam: e.target.value })}
              placeholder="Örn. Reaktör, Ayırma Sistemi, Depolama ve Transfer"
            />

            <div className="md:col-span-2">
              <RwTextarea
                label="Çalışmanın Amacı / Açıklama" maxLength={1000}
                value={temel.amac} onChange={(e) => onChange({ amac: e.target.value })}
                placeholder="HAZOP çalışmasının amacı ve kapsamına ilişkin açıklama girin..."
              />
            </div>
          </div>

          {/* HAZOP Çalışma Ekibi */}
          <div className="mt-5">
            <span className="mb-1.5 block text-xs font-medium text-foreground-800">HAZOP Çalışma Ekibi</span>
            <div className="flex flex-wrap items-center gap-2 rounded-md border border-background-300/60 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
              {temel.ekip.map((ad) => (
                <RwChip key={ad} onRemove={() => onChange({ ekip: temel.ekip.filter((x) => x !== ad) })}>{ad}</RwChip>
              ))}
              <div className="flex items-center gap-1.5">
                <input
                  value={ekipGirdi}
                  onChange={(e) => setEkipGirdi(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); ekipEkle(); } }}
                  placeholder="İsim / unvan yazın"
                  className="h-8 w-44 rounded-md border border-background-300/70 bg-background-50 px-2.5 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
                />
                <RwButton size="sm" variant="outline" icon="ri-add-line" onClick={ekipEkle}>Ekle</RwButton>
              </div>
            </div>
          </div>

          {/* Referans Dokümanlar */}
          <div className="mt-5">
            <span className="block text-xs font-medium text-foreground-800">Referans Dokümanlar (Opsiyonel)</span>
            <p className="mt-0.5 text-xs text-foreground-500">Bu çalışmada kullanılacak P&ID, proses tanımı ve diğer dokümanları ekleyin.</p>
            <div
              onClick={() => dosyaRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); dosyaSec(e.dataTransfer.files); }}
              className="mt-2 flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-md border border-dashed border-background-300/70 bg-background-100/60 px-4 py-6 text-center transition-colors hover:border-primary-400 dark:border-background-400/40 dark:bg-background-200/30"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                <i className="ri-upload-cloud-2-line text-xl" />
              </span>
              <p className="text-xs text-foreground-600">Dosya seçin veya sürükleyip bırakın</p>
              <p className="text-xs text-foreground-400">PDF, DOC, DOCX, XLS, XLSX, JPG, PNG (Maks. 10 MB)</p>
            </div>
            {temel.dokumanlar.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {temel.dokumanlar.map((d) => (
                  <RwChip key={d} onRemove={() => onChange({ dokumanlar: temel.dokumanlar.filter((x) => x !== d) })}>
                    <i className="ri-file-line text-foreground-400" /> {d}
                  </RwChip>
                ))}
              </div>
            )}
            <input ref={dosyaRef} type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" className="hidden" onChange={(e) => { dosyaSec(e.target.files); e.target.value = ''; }} />
          </div>

          {/* Künye */}
          <div className="mt-5 pb-7">
            <span className="mb-1.5 block text-xs font-medium text-foreground-800">Rapor Künye Bilgileri (Opsiyonel)</span>
            <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-3">
              <RwInput label="Rapor No" value={temel.raporNo} onChange={(e) => onChange({ raporNo: e.target.value })} placeholder="Örn. HZ-2026-001" />
              <RwSelect label="Tehlike Sınıfı" options={TEHLIKE_SINIFLARI.map((v) => ({ value: v, label: v }))} value={temel.tehlikeSinifi} onChange={(v) => onChange(tehlikeGecerlilikPatch(v))} placeholder="Seçiniz" />
              <RwInput label="Çalışan Sayısı" value={temel.calisanSayisi} onChange={(e) => onChange({ calisanSayisi: e.target.value })} placeholder="Örn. 120" />
              <RwInput label="İşveren" value={temel.isveren} onChange={(e) => onChange({ isveren: e.target.value })} placeholder="İşveren adı / ünvanı" />
              <RiskNaceSecici
                naceId={temel.naceId}
                onChange={(s) => onChange({ naceId: s.naceId, nace: s.nace, ...(s.tehlikeSinifi ? tehlikeGecerlilikPatch(s.tehlikeSinifi) : {}) })}
              />
              <RwSelect label="Geçerlilik Süresi" options={GECERLILIK_SECENEKLERI.map((v) => ({ value: v, label: v }))} value={temel.gecerlilik} onChange={(v) => onChange({ gecerlilik: v })} />
              <RwInput label="Hazırlayan" value={temel.hazirlayan} onChange={(e) => onChange({ hazirlayan: e.target.value })} placeholder="İş güvenliği uzmanı" />
              <RwInput label="Onaylayan" value={temel.onaylayan} onChange={(e) => onChange({ onaylayan: e.target.value })} placeholder="İşveren / vekili" />
              <RwInput label="Adres / Lokasyon" value={temel.adres} onChange={(e) => onChange({ adres: e.target.value })} placeholder="Açık adres" />
            </div>
          </div>
        </div>

        {/* SAĞ */}
        <aside className="space-y-3">
          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-information-fill text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">HAZOP Hakkında</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              HAZOP (Hazard and Operability Study), proses ve sistemlerde tasarım amacından sapmaları sistematik bir
              şekilde inceleyerek tehlikeleri, işletilebilme (operability) sorunlarını ve bunların olası neden ve
              sonuçlarını belirlemek için kullanılan, kılavuz kelimelere dayalı bir analiz yöntemidir.
            </p>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              Yöntem IEC 61882 standardında tanımlanmıştır:
            </p>
            <ol className="mt-2 space-y-1.5">
              {ASAMALAR.map((a, i) => (
                <li key={a} className="flex items-start gap-2">
                  <span className="mt-0.5 flex h-4 w-4 flex-shrink-0 items-center justify-center rounded-full bg-primary-500 text-[10px] font-bold text-inverse">{i + 1}</span>
                  <span className="text-xs leading-snug text-foreground-600">{a}</span>
                </li>
              ))}
            </ol>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">HAZOP Kılavuz Kelimeleri (Örnek)</h3>
            <div className="overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
              <table className="w-full border-collapse">
                <thead className="bg-background-200 dark:bg-background-300/60">
                  <tr className="text-left text-[10px] font-semibold text-foreground-500">
                    <th className="px-2 py-1.5">Kılavuz Kelime</th>
                    <th className="px-2 py-1.5">Anlamı / Örnek Sapma</th>
                  </tr>
                </thead>
                <tbody>
                  {HZ_KLAVUZ_KELIMELER.map((k) => (
                    <tr key={k.key} className="border-t border-background-300/25 dark:border-background-400/15">
                      <td className="px-2 py-1.5 align-top text-[11px] font-semibold text-foreground-900">{k.key}</td>
                      <td className="px-2 py-1.5 align-top text-[11px] leading-snug text-foreground-500">{k.aciklama}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="rounded-lg border border-warning-500/30 bg-warning-500/5 p-3">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-warning-500 text-inverse"><i className="ri-lightbulb-line text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Yardımcı Mod</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              Bu çalışma geçici olarak tutulur; kalıcı HAZOP kaydı OLUŞTURULMAZ. Yalnızca PDF / Word / Excel indirilir.
            </p>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-foreground-950"><i className="ri-hashtag text-primary-500" /> Yöntem</p>
            <p className="mt-1 text-xs leading-relaxed text-foreground-600">{HZ_METODU}</p>
          </div>
        </aside>
      </div>
    </div>
  );
}