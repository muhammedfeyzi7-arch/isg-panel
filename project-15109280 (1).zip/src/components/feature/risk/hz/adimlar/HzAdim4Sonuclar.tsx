import { useMemo, useState } from 'react';
import { useToastActions } from '@/hooks/useToast';
import HzMaddeListesi from '@/components/feature/risk/hz/HzMaddeListesi';
import {
  HZ_SEVIYE_META, HZ_SEVIYE_SIRA, dugumTipIkon, hzKalanPuan, hzPuan, hzSeviyeBilgi,
  type HzDugum, type HzMadde, type HzSapma,
} from '@/components/feature/risk/hazopTypes';
import type { HazopAiCevap, HazopAiCtx } from '@/lib/riskAiService';
import { RwButton, RwSectionTitle, RwSelect, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// HAZOP · ADIM 4 — SONUÇLAR VE KORUNMA ÖNLEMLERİ (Referans görsel 2)
// Sapma analizi tablosu + satır düzenleyici (sonuç / kontrol / ek önlem + O/S).
// Sağda risk seviyesi renkleri, korunma önlemi kategorileri ve resmi kaynak.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  dugum: HzDugum | null;
  sapmalar: HzSapma[];
  onGuncelle: (id: string, patch: Partial<HzSapma>) => void;
  onDugumDuzenle: () => void;
  onGenelNot: (v: string) => void;
  aiNedenler: (ctx: HazopAiCtx) => Promise<HazopAiCevap>;
}

const O_OPTS = [1, 2, 3, 4, 5].map((v) => ({ value: String(v), label: String(v) }));
const S_OPTS = O_OPTS;

function ozet(list: HzMadde[]): string {
  return list.filter((m) => m.secili).map((m) => m.metin).filter(Boolean).join('; ');
}

export default function HzAdim4Sonuclar({ dugum, sapmalar, onGuncelle, onDugumDuzenle, onGenelNot, aiNedenler }: Props) {
  const { addToast } = useToastActions();
  const [seciliId, setSeciliId] = useState('');
  const [aiYukleniyor, setAiYukleniyor] = useState(false);
  const [oncekiDugumId, setOncekiDugumId] = useState(dugum?.id ?? '');

  const kendi = useMemo(() => sapmalar.filter((s) => s.dugumId === dugum?.id), [sapmalar, dugum?.id]);
  const secili = kendi.find((s) => s.id === seciliId) ?? null;

  // MANTIK DÜZELTMESİ: Düğüm değişince önceki düğümün seçili satırı TEMİZLENİR.
  // Aksi halde başka düğüme geçildiğinde editör boş kalıyor, ama eski seçim
  // state'te asılı kalıyordu (yanlış satırın düzenlenmesine zemin hazırlıyordu).
  if ((dugum?.id ?? '') !== oncekiDugumId) {
    setOncekiDugumId(dugum?.id ?? '');
    if (seciliId) setSeciliId('');
  }

  if (!dugum) {
    return (
      <div className="flex min-h-0 flex-1 flex-col items-center justify-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-full bg-background-200 text-foreground-400 dark:bg-background-300/40">
          <i className="ri-node-tree text-2xl" />
        </span>
        <p className="mt-3 text-sm font-semibold text-foreground-950">Önce bir düğüm seçin</p>
        <p className="mt-1 text-xs text-foreground-500">Sonuçları değerlendirmek için soldan bir düğüm seçin.</p>
      </div>
    );
  }

  const aiCagir = async () => {
    if (!secili) return;
    setAiYukleniyor(true);
    const cevap = await aiNedenler({
      dugumNo: dugum.no, dugumAdi: dugum.ad, dugumTipi: dugum.tip, dugumTanim: dugum.tanim,
      parametre: secili.parametre, klavuzKelime: secili.klavuzKelime, sapma: secili.sapma,
      mevcutNedenler: secili.nedenler.map((m) => m.metin),
      mevcutSonuclar: secili.sonuclar.map((m) => m.metin),
    });
    setAiYukleniyor(false);
    if (!cevap.ok) {
      addToast({ title: 'AI önerileri alınamadı', message: cevap.message || 'Lütfen tekrar deneyin.', type: 'error' });
      return;
    }
    const birlesik = (mevcut: HzMadde[], yeni: string[] | undefined): HzMadde[] => {
      const set = new Set(mevcut.map((m) => m.metin.toLocaleLowerCase('tr').trim()));
      const ek = (yeni ?? []).filter((m) => m && !set.has(m.toLocaleLowerCase('tr').trim()))
        .map((m) => ({ id: `hz-ai-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`, metin: m, secili: true }));
      return [...mevcut, ...ek];
    };
    onGuncelle(secili.id, {
      sonuclar: birlesik(secili.sonuclar, cevap.sonuclar),
      ekOnlemler: birlesik(secili.ekOnlemler, cevap.ekOnlemler),
    });
    addToast({ title: 'AI önerileri hazır', message: 'Sonuç ve ek önlemler güncellendi.', type: 'success' });
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="4. Sonuçlar ve Korunma Önlemleri"
        desc="Seçilen düğümdeki sapmalar için olası sonuçları, mevcut kontrolleri ve önerilen ek önlemleri tanımlayın."
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 lg:grid-cols-[minmax(0,1fr)_290px]">
        {/* SOL */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto pr-1">
          {/* Seçilen düğüm */}
          <div className="flex items-center gap-3 rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <span className="flex h-10 w-10 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300">
              <i className={`${dugumTipIkon(dugum.tip)} text-lg`} />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-[11px] font-semibold uppercase tracking-wide text-foreground-400">Seçilen Düğüm</p>
              <p className="truncate text-sm font-bold text-foreground-950">{dugum.no} — {dugum.ad}</p>
              <p className="truncate text-xs text-foreground-500">{dugum.tanim}</p>
            </div>
            <RwButton variant="outline" size="sm" icon="ri-edit-line" onClick={onDugumDuzenle}>Düğüm Bilgilerini Düzenle</RwButton>
          </div>

          {/* Sapma analizi tablosu */}
          <div className="rounded-lg border border-background-300/50 bg-background-100 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="border-b border-background-300/40 px-3 py-2.5 dark:border-background-400/25">
              <h3 className="text-xs font-bold text-foreground-950">Sapma Analizi</h3>
            </div>
            <div className="isg-scroll-pane overflow-x-auto">
              <div style={{ minWidth: 980 }}>
                <div className="grid items-center gap-x-3 border-b border-background-300/40 bg-background-200 px-3 py-2 text-[10px] font-semibold uppercase tracking-wide text-foreground-500 dark:border-background-400/30 dark:bg-background-300/60" style={{ gridTemplateColumns: '34px 110px minmax(150px,1.2fr) minmax(150px,1.2fr) minmax(150px,1.2fr) minmax(150px,1.2fr) 100px' }}>
                  <span className="text-center">#</span>
                  <span>Kılavuz Kelime</span>
                  <span>Sapma</span>
                  <span>Olası Nedenler</span>
                  <span>Olası Sonuçlar</span>
                  <span>Mevcut Kontroller</span>
                  <span>Önerilen Ek Önlemler</span>
                </div>
                {kendi.length === 0 && (
                  <p className="px-3 py-10 text-center text-xs text-foreground-400">Bu düğüm için henüz sapma yok. 3. adımda sapma ekleyin.</p>
                )}
                {kendi.map((s, i) => {
                  const p = hzPuan(s.olasilik, s.siddet);
                  const sev = hzSeviyeBilgi(p);
                  const aktif = seciliId === s.id;
                  return (
                    <div
                      key={s.id}
                      onClick={() => setSeciliId(aktif ? '' : s.id)}
                      className={`grid cursor-pointer items-start gap-x-3 border-b border-background-300/20 px-3 py-2.5 transition-colors dark:border-background-400/10 ${aktif ? 'bg-primary-500/8' : i % 2 === 1 ? 'bg-background-100/60 dark:bg-background-200/20' : ''} hover:bg-primary-500/[0.05]`}
                      style={{ gridTemplateColumns: '34px 110px minmax(150px,1.2fr) minmax(150px,1.2fr) minmax(150px,1.2fr) minmax(150px,1.2fr) 100px' }}
                    >
                      <span className={`flex h-6 w-6 items-center justify-center rounded-md text-xs font-bold ${sev.soft}`}>{i + 1}</span>
                      <span className="text-[11px] font-semibold text-foreground-900">{s.klavuzKelime}</span>
                      <span className="text-xs text-foreground-700">{s.sapma || '—'}</span>
                      <span className="text-xs text-foreground-600">{ozet(s.nedenler) || '—'}</span>
                      <span className="text-xs text-foreground-600">{ozet(s.sonuclar) || '—'}</span>
                      <span className="text-xs text-foreground-600">{ozet(s.mevcutKontroller) || '—'}</span>
                      <span className="flex flex-col gap-1">
                        {s.ekOnlemler.filter((m) => m.metin.trim()).length === 0 ? (
                          <span className="text-xs text-foreground-400">—</span>
                        ) : (
                          s.ekOnlemler.filter((m) => m.metin.trim()).slice(0, 3).map((m) => (
                            <span key={m.id} className="inline-flex items-center gap-1 rounded border border-success-500/30 bg-success-500/10 px-1.5 py-0.5 text-[10px] font-medium text-success-700 dark:text-success-300">
                              <i className="ri-add-line" /><span className="line-clamp-1">{m.metin}</span>
                            </span>
                          ))
                        )}
                        <span className={`mt-0.5 inline-flex w-fit items-center gap-0.5 rounded px-1.5 py-0.5 text-[10px] font-bold text-inverse ${sev.badge}`}>
                          <i className={`${sev.icon} text-[10px]`} /> {sev.label}
                        </span>
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Satır düzenleyici */}
          {secili && (
            <div className="rounded-lg border border-primary-300/40 bg-background-100 p-3.5 dark:border-primary-500/25 dark:bg-background-200/40">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300"><i className="ri-edit-2-line text-xs" /></span>
                  <div>
                    <h3 className="text-xs font-bold text-foreground-950">{secili.klavuzKelime} — {secili.sapma}</h3>
                    <p className="text-[11px] text-foreground-500">Sonuç, kontrol ve ek önlemleri düzenleyin.</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <RwButton variant="outline" size="sm" icon="ri-close-line" onClick={() => setSeciliId('')}>Kapat</RwButton>
                  <RwButton variant="primary" size="sm" icon={aiYukleniyor ? undefined : 'ri-sparkling-2-line'} disabled={aiYukleniyor} onClick={() => void aiCagir()}>
                    {aiYukleniyor ? 'Hazırlanıyor...' : 'AI Önerileri'}
                  </RwButton>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-3 lg:grid-cols-3">
                <div className="rounded-md border border-background-300/50 bg-background-50 p-2.5 dark:border-background-400/25 dark:bg-background-100/50">
                  <h4 className="mb-1.5 text-xs font-semibold text-foreground-800">Olası Sonuçlar</h4>
                  <HzMaddeListesi maddeler={secili.sonuclar} onChange={(m) => onGuncelle(secili.id, { sonuclar: m })} ekleEtiketi="Sonuç Ekle" placeholder="Olası sonuç..." bosMesaj="Sonuç eklenmedi." kompakt />
                </div>
                <div className="rounded-md border border-background-300/50 bg-background-50 p-2.5 dark:border-background-400/25 dark:bg-background-100/50">
                  <h4 className="mb-1.5 text-xs font-semibold text-foreground-800">Mevcut Kontroller</h4>
                  <HzMaddeListesi maddeler={secili.mevcutKontroller} onChange={(m) => onGuncelle(secili.id, { mevcutKontroller: m })} ekleEtiketi="Kontrol Ekle" placeholder="Mevcut kontrol..." bosMesaj="Kontrol eklenmedi." kompakt />
                </div>
                <div className="rounded-md border border-background-300/50 bg-background-50 p-2.5 dark:border-background-400/25 dark:bg-background-100/50">
                  <h4 className="mb-1.5 text-xs font-semibold text-foreground-800">Önerilen Ek Önlemler</h4>
                  <HzMaddeListesi maddeler={secili.ekOnlemler} onChange={(m) => onGuncelle(secili.id, { ekOnlemler: m })} ekleEtiketi="Önlem Ekle" placeholder="Ek önlem..." bosMesaj="Önlem eklenmedi." kompakt onayGizle />
                </div>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <RwSelect size="sm" label="Olasılık (O)" options={O_OPTS} value={String(secili.olasilik)} onChange={(v) => onGuncelle(secili.id, { olasilik: Number(v) })} />
                <RwSelect size="sm" label="Şiddet (S)" options={S_OPTS} value={String(secili.siddet)} onChange={(v) => onGuncelle(secili.id, { siddet: Number(v) })} />
                <RwSelect size="sm" label="Kontrol Sonrası O" options={O_OPTS} value={String(secili.kalanOlasilik ?? secili.olasilik)} onChange={(v) => onGuncelle(secili.id, { kalanOlasilik: Number(v) })} />
                <RwSelect size="sm" label="Kontrol Sonrası S" options={S_OPTS} value={String(secili.kalanSiddet ?? secili.siddet)} onChange={(v) => onGuncelle(secili.id, { kalanSiddet: Number(v) })} />
              </div>
              <div className="mt-2.5 flex flex-wrap items-center gap-3 text-xs">
                <span className="flex items-center gap-1.5 text-foreground-600">
                  İlk Puan: <b className="text-foreground-950">{hzPuan(secili.olasilik, secili.siddet)}</b>
                  <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold text-inverse ${hzSeviyeBilgi(hzPuan(secili.olasilik, secili.siddet)).badge}`}>{hzSeviyeBilgi(hzPuan(secili.olasilik, secili.siddet)).label}</span>
                </span>
                <span className="flex items-center gap-1.5 text-foreground-600">
                  Son Puan: <b className="text-foreground-950">{hzKalanPuan(secili)}</b>
                  <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold text-inverse ${hzSeviyeBilgi(hzKalanPuan(secili)).badge}`}>{hzSeviyeBilgi(hzKalanPuan(secili)).label}</span>
                </span>
              </div>
            </div>
          )}

          {/* Genel değerlendirme */}
          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 pb-6 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Genel Değerlendirme / Notlar <span className="font-normal text-foreground-400">(Opsiyonel)</span></h3>
            <RwTextarea
              maxLength={1000}
              value={dugum.genelNot ?? ''}
              onChange={(e) => onGenelNot(e.target.value)}
              placeholder="Bu düğüm için genel değerlendirme, teknik yorumlar veya notlar ekleyin..."
            />
          </div>
        </div>

        {/* SAĞ */}
        <aside className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Risk Seviyesi Renkleri</h3>
            <ul className="space-y-1.5">
              {HZ_SEVIYE_SIRA.map((k) => {
                const m = HZ_SEVIYE_META[k];
                return (
                  <li key={k} className="flex items-center gap-2 text-xs">
                    <span className="h-3 w-3 flex-shrink-0 rounded-full" style={{ backgroundColor: m.renk }} />
                    <span className={`font-medium ${m.text}`}>{m.label}</span>
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Korunma Önlemi Kategorileri</h3>
            <ul className="space-y-2">
              {[
                { ad: 'Mühendislik Önlemleri', ac: 'Tasarım değişiklikleri, otomasyon, interlock', ic: 'ri-settings-3-line' },
                { ad: 'İdari Önlemler', ac: 'Prosedür, talimat, eğitim, bakım', ic: 'ri-file-list-3-line' },
                { ad: 'Kişisel Koruyucu Donanım', ac: 'KKD kullanımı, eğitim', ic: 'ri-shield-check-line' },
                { ad: 'Acil Durum Önlemleri', ac: 'Acil durdurma, tahliye, yangın sistemi', ic: 'ri-alarm-warning-line' },
                { ad: 'İzleme ve Denetim', ac: 'Periyodik kontrol, izleme, test', ic: 'ri-eye-line' },
              ].map((k) => (
                <li key={k.ad} className="flex items-start gap-2">
                  <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300"><i className={`${k.ic} text-xs`} /></span>
                  <span className="min-w-0">
                    <span className="block text-xs font-semibold text-foreground-900">{k.ad}</span>
                    <span className="block text-[11px] leading-snug text-foreground-500">{k.ac}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-government-line text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Resmi Kaynak</h3>
            </div>
            <p className="mt-1.5 text-xs font-semibold text-foreground-800">IEC 61882:2016</p>
            <p className="mt-0.5 text-xs leading-relaxed text-foreground-500">Hazard and Operability Studies (HAZOP) — Application Guide</p>
          </div>
        </aside>
      </div>
    </div>
  );
}