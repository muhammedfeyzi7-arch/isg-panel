import {
  HZ_DUGUM_TIPLERI, HZ_PARAMETRELER, dugumTipIkon, type HzDugum,
} from '@/components/feature/risk/hazopTypes';
import { RwInput, RwSelect, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// HAZOP · ADIM 2 — DÜĞÜM VE TASARIM AMACI (Referans görsel 4)
// Sol: Düğüm Bilgileri + Tasarım Amacı + İlgili Proses Parametreleri.
// Sağ: "Bu Adımda Ne Yapılır?" + Düğüm Örnekleri + Örnek Proses Şeması.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  dugum: HzDugum | null;
  onChange: (id: string, patch: Partial<HzDugum>) => void;
}

const ORNEK_DUGUMLER: { no: string; ad: string; tip: string }[] = [
  { no: 'T-101', ad: 'Hammadde Tankı', tip: 'Tank' },
  { no: 'P-101', ad: 'Besleme Pompası', tip: 'Pompa' },
  { no: 'E-101', ad: 'Isıtıcı Eşanjör', tip: 'Eşanjör' },
  { no: 'R-101', ad: 'Reaktör', tip: 'Reaktör' },
  { no: 'S-101', ad: 'Ayırma Ünitesi', tip: 'Separator' },
  { no: 'T-102', ad: 'Depolama Tankı', tip: 'Tank' },
  { no: 'P-102', ad: 'Transfer Pompası', tip: 'Pompa' },
  { no: 'F-101', ad: 'Dolum Ünitesi', tip: 'Dolum' },
];

export default function HzAdim2Dugum({ dugum, onChange }: Props) {
  if (!dugum) {
    return (
      <div className="flex min-h-0 flex-1 flex-col items-center justify-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-full bg-background-200 text-foreground-400 dark:bg-background-300/40">
          <i className="ri-node-tree text-2xl" />
        </span>
        <p className="mt-3 text-sm font-semibold text-foreground-950">Henüz düğüm seçilmedi</p>
        <p className="mt-1 text-xs text-foreground-500">Soldaki panelden bir düğüm ekleyin veya seçin.</p>
      </div>
    );
  }

  const parametreSec = (p: string) => {
    const varMi = dugum.parametreler.includes(p);
    onChange(dugum.id, { parametreler: varMi ? dugum.parametreler.filter((x) => x !== p) : [...dugum.parametreler, p] });
  };

  return (
    <div className="isg-scroll-pane min-h-0 flex-1 overflow-y-auto overflow-x-hidden pr-1">
      <div className="pb-3">
        <h2 className="text-sm font-bold text-foreground-950">2. Düğüm ve Tasarım Amacı</h2>
        <p className="mt-1 text-xs text-foreground-500">
          Seçilen düğüm için proses bilgilerini ve tasarım amacını tanımlayın.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
        {/* SOL */}
        <div className="space-y-4">
          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-3 text-xs font-bold text-foreground-950">Düğüm Bilgileri</h3>
            <div className="grid grid-cols-1 gap-x-5 gap-y-3.5 md:grid-cols-3">
              <RwInput label="Düğüm No" required value={dugum.no} onChange={(e) => onChange(dugum.id, { no: e.target.value })} placeholder="Örn. R-101" />
              <RwInput label="Düğüm Adı" required value={dugum.ad} onChange={(e) => onChange(dugum.id, { ad: e.target.value })} placeholder="Örn. Reaktör" />
              <RwSelect
                label="Düğüm Tipi" required searchable creatable
                options={HZ_DUGUM_TIPLERI.map((v) => ({ value: v, label: v }))}
                value={dugum.tip} onChange={(v) => onChange(dugum.id, { tip: v })} placeholder="Seçiniz"
              />
              <div className="md:col-span-3">
                <RwTextarea
                  label="Düğüm Tanımı / Prosesin Bu Bölümünün Açıklaması" maxLength={1000}
                  value={dugum.tanim} onChange={(e) => onChange(dugum.id, { tanim: e.target.value })}
                  placeholder="Bu düğümde gerçekleşen proses adımlarını ve işleyişi açıklayın..."
                />
              </div>
            </div>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-3 text-xs font-bold text-foreground-950">Tasarım Amacı</h3>
            <div className="grid grid-cols-1 gap-x-5 gap-y-3.5 md:grid-cols-2">
              <RwTextarea
                label="Ana Tasarım Amacı" required maxLength={1000}
                value={dugum.tasarimAmaci} onChange={(e) => onChange(dugum.id, { tasarimAmaci: e.target.value })}
                placeholder="Bu düğümün tasarım amacı nedir?"
              />
              <RwTextarea
                label="İşletme Koşulları (Tipik)" maxLength={1000}
                value={dugum.isletmeKosullari} onChange={(e) => onChange(dugum.id, { isletmeKosullari: e.target.value })}
                placeholder="- Sıcaklık: 80 – 120 °C&#10;- Basınç: 2 – 5 barg&#10;- Sürekli karıştırma"
              />
            </div>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 pb-6 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-1 text-xs font-bold text-foreground-950">İlgili Proses Parametreleri</h3>
            <p className="mb-2.5 text-xs text-foreground-500">Bu düğümde incelenecek temel proses parametrelerini seçin.</p>
            <div className="flex flex-wrap gap-2">
              {HZ_PARAMETRELER.map((p) => {
                const secili = dugum.parametreler.includes(p);
                return (
                  <button
                    key={p} type="button" onClick={() => parametreSec(p)}
                    className={`inline-flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors ${
                      secili
                        ? 'border-primary-500 bg-primary-500/12 text-primary-700 dark:text-primary-200'
                        : 'border-background-300/70 bg-background-50 text-foreground-600 hover:border-primary-300 dark:border-background-400/40 dark:bg-background-100/60'
                    }`}
                  >
                    <span className={`flex h-3.5 w-3.5 items-center justify-center rounded-sm border text-[9px] ${secili ? 'border-primary-500 bg-primary-500 text-inverse' : 'border-background-300/80 dark:border-background-400/50'}`}>
                      {secili && <i className="ri-check-line" />}
                    </span>
                    {p}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* SAĞ */}
        <aside className="space-y-3">
          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-information-fill text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Bu Adımda Ne Yapılır?</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              Proses akış şemasına göre seçilen düğümün (node) sınırları tanımlanır ve bu düğümün tasarım amacı,
              normal işletme koşulları ve ilgili proses parametreleri belirlenir. Bu bilgiler, bir sonraki adımda
              sapma (deviation) incelemesi için temel oluşturur.
            </p>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Düğüm Örnekleri</h3>
            <div className="overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
              <table className="w-full border-collapse">
                <thead className="bg-background-200 dark:bg-background-300/60">
                  <tr className="text-left text-[10px] font-semibold text-foreground-500">
                    <th className="px-2 py-1.5">Düğüm No</th>
                    <th className="px-2 py-1.5">Düğüm Adı</th>
                    <th className="px-2 py-1.5">Düğüm Tipi</th>
                  </tr>
                </thead>
                <tbody>
                  {ORNEK_DUGUMLER.map((d) => (
                    <tr key={d.no} className="border-t border-background-300/25 dark:border-background-400/15">
                      <td className="px-2 py-1.5 text-[11px] font-semibold text-foreground-900">{d.no}</td>
                      <td className="px-2 py-1.5 text-[11px] text-foreground-600">{d.ad}</td>
                      <td className="px-2 py-1.5 text-[11px] text-foreground-500">{d.tip}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Örnek Proses Şeması</h3>
            <div className="w-full overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
              <img
                src="https://readdy.ai/api/search-image?query=Technical%20process%20flow%20diagram%20illustration%20showing%20storage%20tank%2C%20feed%20pump%2C%20heat%20exchanger%2C%20stirred%20reactor%2C%20separator%20unit%20and%20product%20tank%20connected%20by%20pipes%20with%20valves%2C%20industrial%20schematic%20blueprint%20style%2C%20clean%20flat%20vector%20look%2C%20muted%20blue%20and%20warm%20grey%20tones%2C%20white%20background&width=900&height=420&seq=hazop-proses-sema-v1&orientation=landscape"
                alt="Örnek proses akış şeması"
                title="Örnek proses akış şeması — HAZOP düğümleri"
                className="h-auto w-full object-top"
                style={{ height: 168 }}
                loading="lazy"
                decoding="async"
              />
            </div>
            <p className="mt-2 text-[11px] leading-snug text-foreground-500">
              Tank → pompa → eşanjör → reaktör → separatör → depolama/dolum akışı tipik bir prosestir.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}