import { useRef, useState } from 'react';
import { useToastActions } from '@/hooks/useToast';
import HzMaddeListesi from '@/components/feature/risk/hz/HzMaddeListesi';
import {
  HZ_KLAVUZ_KELIMELER, HZ_PARAMETRELER, bosSapma, dugumTipIkon, klavuzBilgi,
  sapmaOner, type HzDugum, type HzMadde, type HzSapma,
} from '@/components/feature/risk/hazopTypes';
import type { HazopAiCevap, HazopAiCtx } from '@/lib/riskAiService';
import { RwButton, RwSectionTitle, RwSelect, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// HAZOP · ADIM 3 — SAPMALAR VE NEDENLER (Referans görsel 3)
// Seçilen düğüm + incelenecek parametre + kılavuz kelime + sapma + olası nedenler
// (AI önerisi destekli). Sağda kılavuz açıklaması, tipik sorular, diğer sapmalar.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  dugum: HzDugum | null;
  sapmalar: HzSapma[];
  onKaydet: (s: HzSapma) => void;
  onSil: (id: string) => void;
  onDugumDuzenle: () => void;
  aiNedenler: (ctx: HazopAiCtx) => Promise<HazopAiCevap>;
}

export default function HzAdim3Sapmalar({ dugum, sapmalar, onKaydet, onSil, onDugumDuzenle, aiNedenler }: Props) {
  const { addToast } = useToastActions();
  const [aktifId, setAktifId] = useState('');
  const [draft, setDraft] = useState<HzSapma>(() => bosSapma(dugum?.id ?? ''));
  const [aiYukleniyor, setAiYukleniyor] = useState(false);
  const [dugumIdOnceki, setDugumIdOnceki] = useState(dugum?.id ?? '');
  const sonOtoRef = useRef('');

  // Düğüm değişince düzenlenen sapmayı sıfırla (render sırasında senkron).
  if ((dugum?.id ?? '') !== dugumIdOnceki) {
    setDugumIdOnceki(dugum?.id ?? '');
    setAktifId('');
    setDraft(bosSapma(dugum?.id ?? ''));
  }

  if (!dugum) {
    return (
      <div className="flex min-h-0 flex-1 flex-col items-center justify-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-full bg-background-200 text-foreground-400 dark:bg-background-300/40">
          <i className="ri-node-tree text-2xl" />
        </span>
        <p className="mt-3 text-sm font-semibold text-foreground-950">Önce bir düğüm seçin</p>
        <p className="mt-1 text-xs text-foreground-500">Sapma tanımlamak için soldan bir düğüm seçin veya ekleyin.</p>
      </div>
    );
  }

  const kendi = sapmalar.filter((s) => s.dugumId === dugum.id);
  const parametreSecenekleri = (dugum.parametreler.length ? dugum.parametreler : HZ_PARAMETRELER).map((p) => ({ value: p, label: p }));
  const klavuzBilgiD = klavuzBilgi(draft.klavuzKelime);

  const yeniSapma = () => {
    setAktifId('');
    setDraft(bosSapma(dugum.id));
    sonOtoRef.current = '';
  };

  const mevcutSec = (id: string) => {
    const s = kendi.find((x) => x.id === id);
    if (s) { setAktifId(id); setDraft({ ...s, nedenler: [...s.nedenler] }); sonOtoRef.current = s.sapma; }
  };

  const parametreDegistir = (p: string) => {
    const oto = sapmaOner(p, draft.klavuzKelime);
    const yeniSapmaMetni = !draft.sapma.trim() || draft.sapma === sonOtoRef.current ? oto : draft.sapma;
    sonOtoRef.current = yeniSapmaMetni;
    setDraft((d) => ({ ...d, parametre: p, sapma: yeniSapmaMetni }));
  };

  const klavuzDegistir = (k: string) => {
    const oto = sapmaOner(draft.parametre, k);
    const yeniSapmaMetni = !draft.sapma.trim() || draft.sapma === sonOtoRef.current ? oto : draft.sapma;
    sonOtoRef.current = yeniSapmaMetni;
    setDraft((d) => ({ ...d, klavuzKelime: k, sapma: yeniSapmaMetni }));
  };

  const nedenleriDegistir = (m: HzMadde[]) => setDraft((d) => ({ ...d, nedenler: m }));

  const aiCagir = async () => {
    if (!draft.parametre || !draft.klavuzKelime) {
      addToast({ title: 'Eksik bilgi', message: 'Önce parametre ve kılavuz kelime seçin.', type: 'warning' });
      return;
    }
    setAiYukleniyor(true);
    const cevap = await aiNedenler({
      dugumNo: dugum.no, dugumAdi: dugum.ad, dugumTipi: dugum.tip, dugumTanim: dugum.tanim,
      parametre: draft.parametre, klavuzKelime: draft.klavuzKelime, sapma: draft.sapma,
      mevcutNedenler: draft.nedenler.map((m) => m.metin),
      mevcutSonuclar: draft.sonuclar.map((m) => m.metin),
    });
    setAiYukleniyor(false);
    if (!cevap.ok || !cevap.nedenler) {
      addToast({ title: 'AI önerileri alınamadı', message: cevap.message || 'Lütfen tekrar deneyin.', type: 'error' });
      return;
    }
    setDraft((d) => {
      const mevcut = new Set(d.nedenler.map((m) => m.metin.toLocaleLowerCase('tr').trim()));
      const eklenecek: HzMadde[] = cevap.nedenler!
        .filter((m) => m && !mevcut.has(m.toLocaleLowerCase('tr').trim()))
        .map((m) => ({ id: `hz-ai-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`, metin: m, secili: true }));
      return { ...d, nedenler: [...d.nedenler, ...eklenecek] };
    });
    addToast({ title: 'AI önerileri hazır', message: 'Yeni nedenler listenin altına eklendi.', type: 'success' });
  };

  const kaydet = () => {
    if (!draft.parametre || !draft.klavuzKelime) {
      addToast({ title: 'Eksik bilgi', message: 'Parametre ve kılavuz kelime zorunludur.', type: 'warning' });
      return;
    }
    if (!draft.sapma.trim()) {
      addToast({ title: 'Eksik bilgi', message: 'Sapma açıklaması zorunludur.', type: 'warning' });
      return;
    }
    onKaydet({ ...draft, dugumId: dugum.id });
    addToast({ title: 'Sapma kaydedildi', message: 'Sapma listeye eklendi/güncellendi.', type: 'success' });
    if (!draft.id.startsWith('hz-s') || !aktifId) {
      // yeni kayıt: draft id zaten mevcut olan bir sapma değilse seçim olarak ayarla
      setAktifId(draft.id);
    }
  };

  const digerParametreSapmalari = kendi.filter((s) => s.parametre === draft.parametre && s.id !== aktifId);
  const digerKlavuzlar = HZ_KLAVUZ_KELIMELER.filter((k) => k.key !== draft.klavuzKelime);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="3. Sapmalar ve Nedenler"
        desc="Seçilen düğüm için ilgili parametrelerdeki sapmaları ve olası nedenlerini inceleyin."
      />

      {/* Bu düğümdeki mevcut sapmalar */}
      <div className="flex flex-shrink-0 flex-wrap items-center gap-2 pb-3">
        {kendi.map((s, i) => (
          <button
            key={s.id} type="button" onClick={() => mevcutSec(s.id)}
            className={`inline-flex cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors ${
              aktifId === s.id ? 'border-primary-500 bg-primary-500/12 text-primary-700 dark:text-primary-200' : 'border-background-300/70 text-foreground-600 hover:border-primary-300 dark:border-background-400/40'
            }`}
          >
            <span className="flex h-4 w-4 items-center justify-center rounded-sm bg-background-200 text-[10px] font-bold text-foreground-600 dark:bg-background-300/50 dark:text-foreground-300">{i + 1}</span>
            {s.klavuzKelime}
            <span className="text-foreground-400">· {s.parametre.split(' ')[0]}</span>
          </button>
        ))}
        <RwButton size="sm" variant="outline" icon="ri-add-line" onClick={yeniSapma}>Yeni Sapma</RwButton>
      </div>

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 lg:grid-cols-[minmax(0,1fr)_300px]">
        {/* SOL */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto pr-1">
          {/* Seçilen düğüm + parametre */}
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
              <p className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-foreground-400">Seçilen Düğüm</p>
              <div className="flex items-center gap-2.5">
                <span className="flex h-9 w-9 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300">
                  <i className={`${dugumTipIkon(dugum.tip)} text-base`} />
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-bold text-foreground-950">{dugum.no} — {dugum.ad}</p>
                  <p className="truncate text-xs text-foreground-500">{dugum.tanim || dugum.tip}</p>
                </div>
              </div>
            </div>
            <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
              <RwSelect
                label="İncelenecek Parametre" searchable
                options={parametreSecenekleri}
                value={draft.parametre} onChange={parametreDegistir} placeholder="Parametre seçiniz"
              />
            </div>
          </div>

          {/* Kılavuz kelime + sapma */}
          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="grid grid-cols-1 gap-x-5 gap-y-3.5 md:grid-cols-[minmax(0,240px)_minmax(0,1fr)]">
              <RwSelect
                label="Kılavuz Kelime" required searchable
                options={HZ_KLAVUZ_KELIMELER.map((k) => ({ value: k.key, label: k.key }))}
                value={draft.klavuzKelime} onChange={klavuzDegistir} placeholder="Seçiniz"
              />
              <RwTextarea
                label="Sapma (Deviation)" required maxLength={500}
                value={draft.sapma} onChange={(e) => setDraft((d) => ({ ...d, sapma: e.target.value }))}
                placeholder="Sapmayı tanımlayın..."
              />
            </div>
          </div>

          {/* Olası nedenler */}
          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="mb-2 flex items-center justify-between gap-2">
              <div>
                <h3 className="text-xs font-bold text-foreground-950">Olası Nedenler</h3>
                <p className="mt-0.5 text-xs text-foreground-500">Bu sapmanın neden olabileceği olası nedenleri girin veya AI önerilerini kullanın.</p>
              </div>
              <RwButton variant="primary" size="sm" icon={aiYukleniyor ? undefined : 'ri-sparkling-2-line'} disabled={aiYukleniyor} onClick={() => void aiCagir()}>
                {aiYukleniyor
                  ? <><span className="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" /> Hazırlanıyor...</>
                  : 'AI Önerileri'}
              </RwButton>
            </div>
            <HzMaddeListesi maddeler={draft.nedenler} onChange={nedenleriDegistir} ekleEtiketi="Neden Ekle" placeholder="Olası neden..." bosMesaj="Henüz neden eklenmedi." />
          </div>

          {/* Aksiyonlar */}
          <div className="flex flex-wrap items-center justify-end gap-2">
            {aktifId && (
              <RwButton variant="ghost" icon="ri-delete-bin-line" onClick={() => { onSil(aktifId); yeniSapma(); addToast({ title: 'Silindi', message: 'Sapma silindi.', type: 'success' }); }}>
                Sapmayı Sil
              </RwButton>
            )}
            <RwButton variant="primary" icon="ri-save-line" onClick={kaydet}>Sapmayı Kaydet</RwButton>
          </div>

          {/* Önerilen diğer kılavuz kelimeler */}
          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Önerilen Diğer Kılavuz Kelimeler <span className="font-normal text-foreground-400">(Bu parametre için)</span></h3>
            <div className="flex flex-wrap gap-2">
              {digerKlavuzlar.map((k) => (
                <button
                  key={k.key} type="button" onClick={() => klavuzDegistir(k.key)}
                  className="inline-flex cursor-pointer items-center gap-1 whitespace-nowrap rounded-md border border-background-300/70 px-2.5 py-1 text-[11px] font-medium text-foreground-600 transition-colors hover:border-primary-300 hover:text-primary-600 dark:border-background-400/40 dark:text-foreground-400"
                >
                  <span className="font-bold text-foreground-900 dark:text-foreground-700">{k.key.split(' ')[0]}</span>
                  <span>({k.key.split('(')[1]?.replace(')', '') ?? ''})</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* SAĞ */}
        <aside className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-information-fill text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Kılavuz Kelime Açıklaması</h3>
            </div>
            <div className="mt-2 rounded-md border border-background-300/50 bg-background-50 px-2.5 py-1.5 dark:border-background-400/30 dark:bg-background-100/60">
              <p className="text-xs font-bold text-primary-700 dark:text-primary-300">{draft.klavuzKelime || '—'}</p>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-foreground-600">
              {klavuzBilgiD?.aciklama || 'Kılavuz kelime seçildiğinde açıklaması burada görünür.'}
            </p>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Tipik Sorular</h3>
            <ul className="space-y-1.5">
              {(klavuzBilgiD?.sorular ?? []).map((q) => (
                <li key={q} className="flex items-start gap-1.5">
                  <i className="ri-question-line mt-0.5 text-xs text-primary-500" />
                  <span className="text-xs leading-snug text-foreground-600">{q}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Bu Parametredeki Diğer Sapmalar</h3>
            <div className="overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
              <table className="w-full border-collapse">
                <thead className="bg-background-200 dark:bg-background-300/60">
                  <tr className="text-left text-[10px] font-semibold text-foreground-500">
                    <th className="px-2 py-1.5">Kılavuz Kelime</th>
                    <th className="px-2 py-1.5">Örnek Sapma</th>
                  </tr>
                </thead>
                <tbody>
                  {digerParametreSapmalari.length === 0 && (
                    <tr><td colSpan={2} className="px-2 py-3 text-center text-[11px] text-foreground-400">Kayıt yok</td></tr>
                  )}
                  {digerParametreSapmalari.map((s) => (
                    <tr key={s.id} className="border-t border-background-300/25 dark:border-background-400/15">
                      <td className="px-2 py-1.5 align-top text-[11px] font-semibold text-foreground-900">{s.klavuzKelime}</td>
                      <td className="px-2 py-1.5 align-top text-[11px] leading-snug text-foreground-500">{s.sapma}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-government-line text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Resmi Kaynak</h3>
            </div>
            <p className="mt-1.5 text-xs font-semibold text-foreground-800">IEC 61882:2016</p>
            <p className="mt-0.5 text-xs leading-relaxed text-foreground-500">
              Kılavuz kelimeler: HIÇ, AZ, FAZLA, TERS, KISMEN, YAN SIRA, DALGALANMA. Proses parametreleri: Akış, Basınç,
              Sıcaklık, Seviye, Bileşim vb.
            </p>
          </div>

          <button
            type="button"
            onClick={onDugumDuzenle}
            className="flex w-full cursor-pointer items-center gap-2 rounded-lg border border-background-300/50 bg-background-100 p-2.5 text-left transition-colors hover:border-primary-300 dark:border-background-400/30 dark:bg-background-200/40"
          >
            <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300"><i className="ri-edit-line text-xs" /></span>
            <span className="text-xs font-medium text-foreground-700">Düğüm bilgilerini düzenle</span>
            <i className="ri-arrow-right-s-line ml-auto text-foreground-400" />
          </button>
        </aside>
      </div>
    </div>
  );
}