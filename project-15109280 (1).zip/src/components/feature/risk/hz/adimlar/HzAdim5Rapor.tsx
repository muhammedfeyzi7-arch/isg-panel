import { useEffect, useMemo, useState } from 'react';
import Icon from '@/components/ui/Icon';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import {
  HZ_SEVIYE_META, HZ_SEVIYE_SIRA, hzPuan, hzSeviye, hzSeviyeBilgi,
  type HzDugum, type HzSapma, type HzTemelBilgiler,
} from '@/components/feature/risk/hazopTypes';
import { pdfBlob, pdfIndir, wordIndir, excelIndir } from '@/lib/hazopRapor';
import { RwButton, RwCard, RwInput, RwSectionTitle } from '@/components/feature/risk/sihirbaz/wizardUi';
import { matchesSearch } from '@/utils/turkishText';
import Select from '@/components/ui/Select';

// ─────────────────────────────────────────────────────────────────────────────
// ADIM 5 · UYGULAMA İÇİ PDF ÖNİZLEME
//
// "Raporu Önizle" artık gerçekten ÖNİZLER: üretilen PDF (indirilenle birebir
// aynı blob) bir iframe içinde gösterilir. Blob URL bileşen kapanınca serbest
// bırakılır → bellek sızıntısı olmaz. Önceki davranış butonu yanıltıcı şekilde
// doğrudan indirmeye yönlendiriyordu (mantık hatası).
// ─────────────────────────────────────────────────────────────────────────────
function PdfOnizleme({ blob }: { blob: Blob }) {
  const [url, setUrl] = useState('');
  useEffect(() => {
    const u = URL.createObjectURL(blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  if (!url) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-background-200">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }
  return (
    <div className="h-full w-full bg-background-200">
      <iframe src={url} title="HAZOP Raporu Önizleme" className="h-full w-full border-0" />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// HAZOP · ADIM 5 — RAPOR VE ÖNİZLEME (Referans görsel 1)
// Özet kartları + risk seviyesi dağılımı + risk matrisi + önemli bulgular tablosu
// + genel değerlendirme + sağda A4 rapor önizleme ve Word/PDF/Excel indirme.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: HzTemelBilgiler;
  dugumler: HzDugum[];
  sapmalar: HzSapma[];
  onTemelChange: (patch: Partial<HzTemelBilgiler>) => void;
}

function tarihGoster(iso: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

export default function HzAdim5Rapor({ temel, dugumler, sapmalar, onTemelChange }: Props) {
  const { addToast } = useToastActions();
  const { openModal } = useModalActions();
  const [indiriliyor, setIndiriliyor] = useState<'word' | 'pdf' | 'excel' | null>(null);
  const [indirAcik, setIndirAcik] = useState(false);
  const [onizleYukleniyor, setOnizleYukleniyor] = useState(false);
  const [arama, setArama] = useState('');
  const [seviyeFiltre, setSeviyeFiltre] = useState('tumu');

  const sayim = useMemo(() => {
    const s = { dusuk: 0, orta: 0, onemli: 0, yuksek: 0, cokYuksek: 0 };
    sapmalar.forEach((sp) => { s[hzSeviye(hzPuan(sp.olasilik, sp.siddet))] += 1; });
    const onemli = s.yuksek + s.cokYuksek;
    const ekOnlem = sapmalar.reduce((t, sp) => t + sp.ekOnlemler.filter((m) => m.metin.trim()).length, 0);
    return { ...s, onemli, ekOnlem };
  }, [sapmalar]);

  const onemliBulgular = useMemo(() => {
    let l = sapmalar.filter((s) => hzSeviye(hzPuan(s.olasilik, s.siddet)) === 'yuksek' || hzSeviye(hzPuan(s.olasilik, s.siddet)) === 'cokYuksek');
    if (seviyeFiltre !== 'tumu') l = sapmalar.filter((s) => hzSeviye(hzPuan(s.olasilik, s.siddet)) === seviyeFiltre);
    const q = arama.trim().toLocaleLowerCase('tr');
    if (q) l = l.filter((s) => matchesSearch(`${s.sapma} ${s.klavuzKelime} ${s.parametre}`, q));
    return l;
  }, [sapmalar, seviyeFiltre, arama]);

  const donutToplam = Math.max(1, sapmalar.length);
  let aci = 0;
  const donutGradient = sapmalar.length === 0
    ? 'oklch(var(--background-300)) 0% 100%'
    : HZ_SEVIYE_SIRA.map((k) => {
      const bas = (aci / donutToplam) * 100;
      aci += sayim[k];
      const bit = (aci / donutToplam) * 100;
      return `${HZ_SEVIYE_META[k].renk} ${bas}% ${bit}%`;
    }).join(', ');

  // 5x5 matris sayımları
  const matris = useMemo(() => {
    const m: Record<string, number> = {};
    sapmalar.forEach((s) => {
      const key = `${s.olasilik}-${s.siddet}`;
      m[key] = (m[key] ?? 0) + 1;
    });
    return m;
  }, [sapmalar]);

  const indir = async (tip: 'pdf' | 'word' | 'excel') => {
    if (sapmalar.length === 0) {
      addToast({ title: 'Sapma listesi boş', message: 'Rapor oluşturmak için en az bir sapma ekleyin.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndirAcik(false);
    setIndiriliyor(tip);
    try {
      const veri = { temel, dugumler, sapmalar };
      if (tip === 'pdf') await pdfIndir(veri);
      else if (tip === 'excel') await excelIndir(veri);
      else await wordIndir(veri);
      addToast({ title: 'Rapor hazır', message: 'Dosya indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Rapor oluşturulamadı', message: 'Beklenmeyen bir hata oluştu, lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setIndiriliyor(null);
    }
  };

  const onizle = async () => {
    if (sapmalar.length === 0) {
      addToast({ title: 'Sapma listesi boş', message: 'Önizleme için en az bir sapma ekleyin.', type: 'warning' });
      return;
    }
    if (onizleYukleniyor) return;
    setOnizleYukleniyor(true);
    try {
      const blob = await pdfBlob({ temel, dugumler, sapmalar });
      openModal({
        title: 'HAZOP Raporu Önizleme',
        description: temel.firma || 'Rapor önizlemesi',
        variant: 'large',
        width: 1120,
        height: 820,
        minWidth: 720,
        minHeight: 520,
        showFooter: false,
        bodyLayout: 'fill',
        closable: true,
        resizable: true,
        minimizable: true,
        maximizable: true,
        content: <PdfOnizleme blob={blob} />,
      });
    } catch {
      addToast({ title: 'Önizleme oluşturulamadı', message: 'Beklenmeyen bir hata oluştu, lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setOnizleYukleniyor(false);
    }
  };

  const kartlar = [
    { key: 'dugum', label: 'Toplam Düğüm', adet: dugumler.length, icon: 'ri-node-tree', renk: 'bg-primary-500' },
    { key: 'sapma', label: 'Toplam Sapma', adet: sapmalar.length, icon: 'ri-flow-chart', renk: 'bg-secondary-500' },
    { key: 'onemli', label: 'Önemli Bulgular', adet: sayim.onemli, icon: 'ri-error-warning-line', renk: 'bg-danger-500' },
    { key: 'onlem', label: 'Önerilen Önlem', adet: sayim.ekOnlem, icon: 'ri-shield-check-line', renk: 'bg-success-500' },
    { key: 'katilimci', label: 'Katılımcı', adet: temel.ekip.length, icon: 'ri-group-line', renk: 'bg-warning-500' },
  ];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="5. Rapor ve Önizleme"
        desc="HAZOP çalışmasının sonuçlarını gözden geçirin, risk seviyelerini değerlendirin ve raporu önizleyin."
        right={(
          <div className="flex flex-shrink-0 items-center gap-2">
            <RwButton variant="outline" size="sm" icon={onizleYukleniyor ? undefined : 'ri-eye-line'} disabled={onizleYukleniyor} onClick={() => void onizle()}>
              {onizleYukleniyor ? 'Hazırlanıyor...' : 'Raporu Önizle'}
            </RwButton>
          </div>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_360px]">
        {/* SOL */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto pr-1">
          {/* Özet kartları */}
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
            {kartlar.map((k) => (
              <div key={k.key} className="flex items-center gap-2.5 rounded-lg border border-background-300/50 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
                <span className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-md text-inverse ${k.renk}`}><i className={`${k.icon} text-lg`} /></span>
                <span className="min-w-0">
                  <span className="block text-lg font-bold text-foreground-950">{k.adet}</span>
                  <span className="block truncate text-[11px] font-medium text-foreground-500">{k.label}</span>
                </span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            {/* Donut */}
            <RwCard title="Risk Seviyesi Dağılımı (Tüm Sapmalar)" icon="ri-pie-chart-2-line" className="p-3">
              <div className="flex items-center gap-4">
                <div className="relative h-28 w-28 flex-shrink-0">
                  <div className="h-full w-full rounded-full" style={{ background: `conic-gradient(${donutGradient})` }} />
                  <div className="absolute inset-[18%] flex flex-col items-center justify-center rounded-full bg-background-100 dark:bg-background-200">
                    <span className="text-lg font-bold text-foreground-950">{sapmalar.length}</span>
                    <span className="text-[10px] text-foreground-500">Toplam Sapma</span>
                  </div>
                </div>
                <ul className="min-w-0 flex-1 space-y-1">
                  {HZ_SEVIYE_SIRA.map((k) => {
                    const m = HZ_SEVIYE_META[k];
                    const yuzde = sapmalar.length ? Math.round((sayim[k] / sapmalar.length) * 100) : 0;
                    return (
                      <li key={k} className="flex items-center gap-2 text-xs">
                        <span className="h-2.5 w-2.5 flex-shrink-0 rounded-full" style={{ backgroundColor: m.renk }} />
                        <span className="flex-1 truncate text-foreground-600">{m.label}</span>
                        <span className="font-medium text-foreground-800">{sayim[k]}</span>
                        <span className="w-9 text-right text-foreground-400">%{yuzde}</span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </RwCard>

            {/* Risk matrisi */}
            <RwCard title="Risk Matrisi (Olasılık × Şiddet)" icon="ri-grid-fill" className="p-3">
              <div className="flex items-stretch gap-2">
                <div className="flex flex-col items-center justify-center">
                  <span className="mb-1 whitespace-nowrap text-[10px] font-semibold text-foreground-500">Şiddet (S)</span>
                </div>
                <div className="flex-1">
                  <div className="grid grid-cols-5 gap-1">
                    {[5, 4, 3, 2, 1].map((s) => (
                      ([1, 2, 3, 4, 5] as const).map((o) => {
                        const puan = o * s;
                        const m = hzSeviyeBilgi(puan);
                        const adet = matris[`${o}-${s}`] ?? 0;
                        return (
                          <div
                            key={`${o}-${s}`}
                            className="flex h-9 flex-col items-center justify-center rounded text-[11px] font-bold"
                            style={{ backgroundColor: `${m.renk}2E`, color: m.hex.fg, outline: adet > 0 ? `1.5px solid ${m.renk}` : 'none' }}
                            title={`Olasılık ${o} × Şiddet ${s} = ${puan} (${m.label})`}
                          >
                            <span>{adet}</span>
                          </div>
                        );
                      })
                    )).flat()}
                  </div>
                  <div className="mt-1 grid grid-cols-5">
                    {[1, 2, 3, 4, 5].map((o) => (
                      <span key={o} className="text-center text-[10px] text-foreground-400">{o}</span>
                    ))}
                  </div>
                </div>
              </div>
              <p className="mt-2 text-center text-[10px] text-foreground-400">Olasılık (O) →</p>
            </RwCard>
          </div>

          {/* Önemli bulgular */}
          <RwCard className="flex min-h-0 flex-col p-0">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-background-300/40 p-3 dark:border-background-400/25">
              <div className="flex items-center gap-1.5">
                <i className="ri-error-warning-line text-sm text-danger-500" />
                <h3 className="text-xs font-semibold text-foreground-950">Önemli Bulgular <span className="font-normal text-foreground-400">(Risk Seviyesi Yüksek ve Üzeri)</span></h3>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Select
                  size="sm"
                  containerClassName="w-40"
                  value={seviyeFiltre}
                  onChange={(e) => setSeviyeFiltre(e.target.value)}
                  options={[
                    { value: 'tumu', label: 'Tümü' },
                    { value: 'cokYuksek', label: 'Çok Yüksek' },
                    { value: 'yuksek', label: 'Yüksek' },
                  ]}
                />
                <div className="w-40"><RwInput size="sm" placeholder="Ara..." value={arama} onChange={(e) => setArama(e.target.value)} leftIcon={<i className="ri-search-line text-xs" />} /></div>
              </div>
            </div>
            <div className="isg-scroll-pane max-h-[320px] overflow-auto">
              <table className="w-full border-collapse" style={{ minWidth: 820 }}>
                <thead className="sticky top-0 bg-background-200 dark:bg-background-300/70">
                  <tr className="text-left text-[10px] font-semibold uppercase tracking-wide text-foreground-500">
                    <th className="px-2 py-1.5 whitespace-nowrap">#</th>
                    <th className="px-2 py-1.5 whitespace-nowrap">Düğüm</th>
                    <th className="px-2 py-1.5 whitespace-nowrap">Kılavuz Kelime</th>
                    <th className="px-2 py-1.5 whitespace-nowrap">Sapma</th>
                    <th className="px-2 py-1.5 whitespace-nowrap">Olası Nedenler</th>
                    <th className="px-2 py-1.5 whitespace-nowrap">Olası Sonuçlar</th>
                    <th className="px-2 py-1.5 whitespace-nowrap">Önerilen Ek Önlemler</th>
                    <th className="px-2 py-1.5 whitespace-nowrap">Risk Seviyesi</th>
                  </tr>
                </thead>
                <tbody>
                  {onemliBulgular.length === 0 && (
                    <tr><td colSpan={8} className="px-2 py-8 text-center text-xs text-foreground-400">Bu filtreye uyan önemli bulgu yok.</td></tr>
                  )}
                  {onemliBulgular.map((s, i) => {
                    const p = hzPuan(s.olasilik, s.siddet);
                    const m = hzSeviyeBilgi(p);
                    const d = dugumler.find((x) => x.id === s.dugumId);
                    return (
                      <tr key={s.id} className="border-t border-background-300/20 align-top dark:border-background-400/10">
                        <td className="px-2 py-2 text-xs text-foreground-500">{i + 1}</td>
                        <td className="px-2 py-2 text-xs font-medium text-foreground-800">{d ? d.no : '—'}</td>
                        <td className="px-2 py-2 text-xs text-foreground-700">{s.klavuzKelime}</td>
                        <td className="px-2 py-2 text-xs text-foreground-700">{s.sapma}</td>
                        <td className="px-2 py-2 text-xs text-foreground-600">{s.nedenler.filter((x) => x.secili).map((x) => x.metin).join('; ') || '—'}</td>
                        <td className="px-2 py-2 text-xs text-foreground-600">{s.sonuclar.filter((x) => x.secili).map((x) => x.metin).join('; ') || '—'}</td>
                        <td className="px-2 py-2 text-xs text-foreground-600">{s.ekOnlemler.filter((x) => x.metin.trim()).map((x) => x.metin).join('; ') || '—'}</td>
                        <td className="px-2 py-2">
                          <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-md px-2 py-0.5 text-[10px] font-bold text-inverse ${m.badge}`}>
                            <i className={`${m.icon} text-[10px]`} /> {m.label}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </RwCard>

          {/* Genel değerlendirme + takip */}
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2 pb-7">
            <RwCard title="Genel Değerlendirme" icon="ri-file-text-line" className="p-3">
              <p className="text-xs leading-relaxed text-foreground-600">
                Yapılan HAZOP çalışmasında toplam {sapmalar.length} sapma incelenmiş, {sayim.onemli} bulgu tespit edilmiştir.
                Özellikle risk seviyesi yüksek ve çok yüksek olan bulgulara öncelik verilmesi önerilmektedir. Önerilen ek
                önlemlerin uygulanması ve kontrol sonrası risklerin kabul edilebilir seviyeye indirilmesi hedeflenmektedir.
              </p>
            </RwCard>
            <RwCard title="Takip Edilmesi Gerekenler" icon="ri-checkbox-circle-line" className="p-3">
              <ul className="space-y-1.5">
                {[
                  'Yüksek ve çok yüksek riskler için aksiyon planı oluşturulması',
                  'Önerilen ek önlemlerin sorumlu ve termin ile takibi',
                  'Periyodik olarak HAZOP gözden geçirmesi (en az yılda bir kez)',
                  'Kontrol sonrası risklerin yeniden değerlendirilmesi',
                ].map((t) => (
                  <li key={t} className="flex items-start gap-2">
                    <i className="ri-check-line mt-0.5 text-xs text-success-500" />
                    <span className="text-xs leading-snug text-foreground-600">{t}</span>
                  </li>
                ))}
              </ul>
            </RwCard>
          </div>
        </div>

        {/* SAĞ */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <RwCard className="flex flex-col p-0">
            <div className="flex items-center gap-1.5 border-b border-background-300/40 px-3 py-2 dark:border-background-400/25">
              <i className="ri-file-text-line text-sm text-primary-500" />
              <h3 className="text-xs font-semibold text-foreground-950">Rapor Önizleme</h3>
            </div>
            <div className="isg-scroll-pane max-h-[520px] overflow-auto bg-background-200/60 p-3 dark:bg-background-300/25">
              <div className="mx-auto bg-white p-4 text-[10px] text-gray-800" style={{ width: 288 }}>
                <div className="flex items-start justify-between border-b-2 border-[#C8102E] pb-2">
                  <div>
                    <p className="text-xs font-bold text-[#0F2747]">{temel.firma || 'Firma Adı'}</p>
                    <p className="text-[9px] text-gray-500">{temel.tesis || 'Tesis'}</p>
                    <p className="text-[8px] text-gray-400">Üretim / Proses Tesisi</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-[#0F2747]">HAZOP</p>
                    <p className="text-[8px] text-gray-500">No: {temel.raporNo || 'HZ-0001'}</p>
                    <p className="text-[8px] text-gray-500">{tarihGoster(temel.tarih)}</p>
                  </div>
                </div>
                <p className="mt-3 text-center text-[11px] font-bold text-[#0F2747]">HAZOP Çalışma Raporu</p>
                <p className="text-center text-[9px] text-gray-500">Proses: {temel.proses || '—'}</p>
                <div className="mt-2 h-24 w-full overflow-hidden rounded border border-gray-200">
                  <img
                    src="https://readdy.ai/api/search-image?query=Technical%20process%20flow%20diagram%20illustration%20showing%20storage%20tank%2C%20feed%20pump%2C%20heat%20exchanger%2C%20stirred%20reactor%2C%20separator%20unit%20and%20product%20tank%20connected%20by%20pipes%20with%20valves%2C%20industrial%20schematic%20blueprint%20style%2C%20clean%20flat%20vector%20look%2C%20muted%20blue%20and%20warm%20grey%20tones%2C%20white%20background&width=900&height=420&seq=hazop-proses-sema-v1&orientation=landscape"
                    alt="Proses şeması"
                    className="h-full w-full object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                </div>
                <p className="mt-2 font-bold text-[#0F2747]">İçindekiler</p>
                <ol className="mt-1 space-y-0.5 text-[8px] text-gray-600">
                  {['Firma ve Çalışma Bilgileri', 'Metodoloji (IEC 61882)', 'Düğüm ve Sapma Listesi', 'Korunma Önlemleri / Aksiyon Planı', 'Kontrol Sonrası Değerlendirme', 'Özet ve Sonuç'].map((t, i) => (
                    <li key={t}>{i + 1}. {t}</li>
                  ))}
                </ol>
              </div>
            </div>
          </RwCard>

          <RwCard title="Rapor İşlemleri" icon="ri-download-2-line" className="p-3">
            <p className="mb-2.5 text-xs text-foreground-500">Raporu aşağıdaki formatlarda oluşturabilirsiniz.</p>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('word')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-primary-500 text-inverse transition-colors hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'word' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="word" size="md" />}
                <span className="text-xs leading-tight">Word İndir</span>
              </button>
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('pdf')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-danger-500 text-inverse transition-colors hover:bg-danger-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'pdf' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="pdf" size="md" />}
                <span className="text-xs leading-tight">PDF İndir</span>
              </button>
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('excel')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-success-500 text-inverse transition-colors hover:bg-success-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'excel' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="excel" size="md" />}
                <span className="text-xs leading-tight">Excel İndir</span>
              </button>
              <div className="relative">
                <button type="button" onClick={() => setIndirAcik((o) => !o)} className="flex h-16 w-full cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md border border-background-300/70 text-foreground-700 transition-colors hover:bg-background-100 dark:border-background-400/40 dark:hover:bg-background-300/40">
                  <i className="ri-more-2-line text-lg" />
                  <span className="text-xs leading-tight">Diğer</span>
                </button>
                {indirAcik && (
                  <div className="absolute bottom-full right-0 z-20 mb-1 w-48 rounded-md border border-background-300/70 bg-background-50 p-1 shadow-xl dark:border-background-400/50 dark:bg-background-200">
                    <button type="button" onClick={() => void indir('word')} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <Icon name="word" size="sm" /> Word olarak indir
                    </button>
                    <button type="button" onClick={() => void indir('excel')} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <Icon name="excel" size="sm" /> Excel olarak indir
                    </button>
                  </div>
                )}
              </div>
            </div>
          </RwCard>

          <RwCard title="Rapor Bilgileri" icon="ri-file-list-3-line" className="p-3">
            <RwInput label="Rapor Numarası" value={temel.raporNo} onChange={(e) => onTemelChange({ raporNo: e.target.value })} placeholder="HZ-2026-001" />
          </RwCard>

          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-foreground-950"><i className="ri-information-line text-primary-500" /> HAZOP Rapor İçeriği</p>
            <p className="mt-1 text-xs leading-relaxed text-foreground-600">
              Rapor; firma/çalışma bilgileri, düğüm ve tasarım amaçları, sapmalar (neden–sonuç–kontrol), önerilen ek
              önlemler, kontrol sonrası risk, risk seviyesi aralıkları, özet ve imza bölümlerini içerir.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}