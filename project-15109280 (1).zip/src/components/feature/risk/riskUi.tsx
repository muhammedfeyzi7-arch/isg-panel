import { riskSeviyesi, SEVIYE_META } from './riskSihirbazTypes';

// ─────────────────────────────────────────────────────────────────────────────
// RİSK SİHİRBAZI — PAYLAŞILAN GÖRSEL YARDIMCILAR (yalnızca bu sihirbaz kapsamı)
//
// Referans görsellerde:
//   • AI öneri kartlarında ve tablo satırlarında kategorilere özel RENKLİ İKON
//   • Risk seviyeleri YUVARLAK + İKONLU rozet olarak gösterilir.
// Bu dosya o iki görsel dili tek yerden sağlar; global SharedUI'a dokunmaz,
// yalnızca Risk Değerlendirmesi sihirbazında kullanılır.
// ─────────────────────────────────────────────────────────────────────────────

interface KategoriGorunum {
  icon: string;
  cls: string;
}

// Anahtar kelime → ikon + renk. Sıra önemli (ilk eşleşen kazanır).
const KATEGORI_LISTESI: { anahtar: string[]; gorunum: KategoriGorunum }[] = [
  { anahtar: ['makine', 'ekipman', 'tezgah', 'pres'], gorunum: { icon: 'ri-settings-3-line', cls: 'bg-danger-500/15 text-danger-600 dark:text-danger-300' } },
  { anahtar: ['elektrik', 'pano', 'kaçak'], gorunum: { icon: 'ri-flashlight-fill', cls: 'bg-warning-500/15 text-warning-600 dark:text-warning-300' } },
  { anahtar: ['yangın', 'patlama', 'atex', 'tutuşma'], gorunum: { icon: 'ri-fire-line', cls: 'bg-danger-500/15 text-danger-600 dark:text-danger-300' } },
  { anahtar: ['kimyasal', 'kimya', 'gaz', 'solvent'], gorunum: { icon: 'ri-flask-line', cls: 'bg-accent-500/15 text-accent-600 dark:text-accent-300' } },
  { anahtar: ['ergonomi', 'elle', 'kas-iskelet', 'kas iskelet', 'taşıma'], gorunum: { icon: 'ri-user-line', cls: 'bg-secondary-500/15 text-secondary-600 dark:text-secondary-300' } },
  { anahtar: ['yüksekte', 'düşme', 'kayma', 'takılma', 'zemin'], gorunum: { icon: 'ri-arrow-down-line', cls: 'bg-warning-500/15 text-warning-600 dark:text-warning-300' } },
  { anahtar: ['trafik', 'forklift', 'araç', 'yaya', 'kaldırma'], gorunum: { icon: 'ri-truck-line', cls: 'bg-primary-500/15 text-primary-600 dark:text-primary-300' } },
  { anahtar: ['fiziksel', 'gürültü', 'titreşim', 'aydınlatma', 'termal', 'toz'], gorunum: { icon: 'ri-sun-line', cls: 'bg-warning-500/15 text-warning-600 dark:text-warning-300' } },
  { anahtar: ['depo', 'depolama', 'lojistik', 'istif'], gorunum: { icon: 'ri-archive-2-line', cls: 'bg-secondary-500/15 text-secondary-600 dark:text-secondary-300' } },
  { anahtar: ['kapalı alan'], gorunum: { icon: 'ri-door-lock-line', cls: 'bg-foreground-500/15 text-foreground-700 dark:text-foreground-300' } },
  { anahtar: ['biyolojik', 'mikrop', 'bakteri'], gorunum: { icon: 'ri-virus-line', cls: 'bg-success-500/15 text-success-600 dark:text-success-300' } },
  { anahtar: ['basınçlı', 'kompresör'], gorunum: { icon: 'ri-gas-station-line', cls: 'bg-danger-500/15 text-danger-600 dark:text-danger-300' } },
  { anahtar: ['acil durum', 'tahliye'], gorunum: { icon: 'ri-alarm-warning-line', cls: 'bg-danger-500/15 text-danger-600 dark:text-danger-300' } },
  { anahtar: ['bakım', 'onarım', 'kaynak', 'kesme', 'taşlama'], gorunum: { icon: 'ri-tools-line', cls: 'bg-secondary-500/15 text-secondary-600 dark:text-secondary-300' } },
  { anahtar: ['ofis', 'idari', 'büro'], gorunum: { icon: 'ri-briefcase-line', cls: 'bg-primary-500/15 text-primary-600 dark:text-primary-300' } },
  { anahtar: ['eğitim', 'yetkinlik', 'iş organizasyonu', 'insan', 'psikososyal'], gorunum: { icon: 'ri-graduation-cap-line', cls: 'bg-accent-500/15 text-accent-600 dark:text-accent-300' } },
  { anahtar: ['kkd', 'koruyucu'], gorunum: { icon: 'ri-shield-check-line', cls: 'bg-success-500/15 text-success-600 dark:text-success-300' } },
];

const VARSAYILAN: KategoriGorunum = {
  icon: 'ri-shield-line',
  cls: 'bg-primary-500/15 text-primary-600 dark:text-primary-300',
};

export function kategoriGorunum(kategori: string): KategoriGorunum {
  const k = (kategori || '').toLocaleLowerCase('tr');
  const bulunan = KATEGORI_LISTESI.find((x) => x.anahtar.some((a) => k.includes(a)));
  return bulunan?.gorunum ?? VARSAYILAN;
}

/** Kategoriye özel renkli ikon kutusu (referans: AI kartı + tablo satırı). */
export function KategoriIkon({ kategori, className = 'h-9 w-9 text-base' }: { kategori: string; className?: string }) {
  const g = kategoriGorunum(kategori);
  return (
    <span className={`flex flex-shrink-0 items-center justify-center rounded-md ${g.cls} ${className}`} aria-hidden="true">
      <i className={g.icon} />
    </span>
  );
}

/** Yuvarlak + ikonlu risk seviyesi rozeti (referans: Yüksek / Orta / Düşük). */
export function RiskSeviyeBadge({ puan, className = '' }: { puan: number; className?: string }) {
  const m = SEVIYE_META[riskSeviyesi(puan)];
  return (
    <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-0.5 text-xs font-bold text-inverse ${m.badge} ${className}`}>
      <i className={`${m.icon} text-xs`} />
      {m.label}
    </span>
  );
}