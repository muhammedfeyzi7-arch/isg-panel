import { useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { pickColumn } from '@/lib/excel/excelColumnPick';
import { readWorkbookSafe } from '@/lib/spreadsheet/readWorkbook';
import { assertWithinByteLimit, MAX_PARSE_BYTES } from '@/lib/spreadsheet/safeSheet';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import AiTehlikePaneli from '@/components/feature/risk/AiTehlikePaneli';
import { matchesSearch } from '@/utils/turkishText';
import ManuelRiskModal, { type ManuelRiskVerisi } from '@/components/feature/risk/ManuelRiskModal';
import {
  RISK_ALANLARI,
  RISK_KATEGORILERI,
  riskPuani,
  riskSeviyesi,
  SEVIYE_META,
  TUM_ALANLAR,
  TUM_KATEGORILER,
  type AiOneri,
  type RiskItem,
} from '@/components/feature/risk/riskSihirbazTypes';
import {
  RwButton,
  RwIconButton,
  RwInput,
  RwSectionTitle,
  RwSelect,
  RwTabs,
  RwTextarea,
} from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// ADIM 2 — TEHLİKELER VE RİSKLER (Referans görsel 4)
// Sol: AI Tehlike Önerileri · Sağ: Risk Listesi (tab + liste + seçili risk
// detayı). TÜM girişler tek merkezi modele akar; 3. ve 4. adım otomatik beslenir.
//
// NOT: Liste <table> DEĞİL, div + CSS grid'dir. Global modal kuralı
//   `.isg-modal-body td, th { white-space: normal !important }` tablo
// başlıklarını harf harf kırıyordu; grid'de bu kural geçerli olmadığı için
// başlıklar referanstaki gibi tek satır kalır.
// ─────────────────────────────────────────────────────────────────────────────

type Sekme = 'tumu' | 'ai' | 'manuel';

interface Adim2Props {
  riskler: RiskItem[];
  aiOnerileri: AiOneri[];
  aiYukleniyor: boolean;
  onAiYenile: (kategori: string, alan: string) => void;
  onAiEkle: (oneri: AiOneri) => void;
  onManuelEkle: (veri: ManuelRiskVerisi) => void;
  onTopluEkle: (riskler: RiskItem[]) => void;
  onGuncelle: (id: string, patch: Partial<RiskItem>) => void;
  onSil: (id: string) => void;
}

const SEVIYE_OPTIONS = [1, 2, 3, 4, 5].map((n) => ({ value: String(n), label: String(n) }));

const TH = 'text-left text-xs font-semibold uppercase tracking-wide text-foreground-500 whitespace-nowrap';

/** Grid kolon şablonu — başlık ve satırlar AYNI şablonu paylaşır. */
const IZGARA =
  '40px 120px minmax(150px,1.2fr) minmax(130px,1.1fr) minmax(150px,1.3fr) 76px 76px 64px 122px 74px';

export default function Adim2Tehlikeler({
  riskler, aiOnerileri, aiYukleniyor, onAiYenile, onAiEkle, onManuelEkle, onTopluEkle, onGuncelle, onSil,
}: Adim2Props) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const fileRef = useRef<HTMLInputElement>(null);

  const [sekme, setSekme] = useState<Sekme>('tumu');
  const [arama, setArama] = useState('');
  const [seciliId, setSeciliId] = useState('');
  const [aiAlan, setAiAlan] = useState(TUM_ALANLAR);
  const [aiKategori, setAiKategori] = useState(TUM_KATEGORILER);

  const aiAdet = riskler.filter((r) => r.kaynak === 'ai').length;
  const manuelAdet = riskler.filter((r) => r.kaynak === 'manuel').length;

  const filtreli = useMemo(() => {
    let liste = riskler;
    if (sekme === 'ai') liste = liste.filter((r) => r.kaynak === 'ai');
    if (sekme === 'manuel') liste = liste.filter((r) => r.kaynak === 'manuel');
    const q = arama.trim().toLocaleLowerCase('tr');
    if (q) liste = liste.filter((r) => matchesSearch(`${r.tehlike} ${r.risk} ${r.bolum} ${r.kategori}`, q));
    return liste;
  }, [riskler, sekme, arama]);

  const secili = riskler.find((r) => r.id === seciliId) ?? null;
  const ekliMetinler = riskler.map((r) => `${r.tehlike} ${r.risk}`);

  const tehlikeOptions = useMemo(() => Array.from(new Set(riskler.map((r) => r.tehlike).filter(Boolean))).map((v) => ({ value: v, label: v })), [riskler]);
  const riskOptions = useMemo(() => Array.from(new Set(riskler.map((r) => r.risk).filter(Boolean))).map((v) => ({ value: v, label: v })), [riskler]);

  const manuelAc = () => {
    const id = openModal({
      title: 'Manuel Risk Ekle',
      description: 'Risk bilgilerini girin; risk puanı otomatik hesaplanır.',
      variant: 'form', width: 640, showFooter: false, closable: true, resizable: true, minimizable: true,
      content: <ManuelRiskModal onClose={() => closeModal(id)} onKaydet={(veri) => { onManuelEkle(veri); closeModal(id); }} />,
    });
  };

  const secileniSil = () => {
    if (!seciliId) return;
    onSil(seciliId);
    setSeciliId('');
    addToast({ title: 'Kayıt silindi', message: 'Seçili risk listeden kaldırıldı.', type: 'success' });
  };

  const excelAktar = (file: File) => {
    // GUV-19: Ayrıştırma öncesi boyut sınırı.
    try {
      assertWithinByteLimit(file.size, MAX_PARSE_BYTES);
    } catch (e) {
      addToast({ title: 'Dosya çok büyük', message: e instanceof Error ? e.message : 'Dosya boyutu sınırı aşıldı.', type: 'error' });
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const buf = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = readWorkbookSafe(buf);
        const sheet = wb.Sheets[wb.SheetNames[0]];
        if (!sheet) {
          addToast({ title: 'Dosya okunamadı', message: 'Excel içinde okunabilir bir sayfa bulunamadı.', type: 'error' });
          return;
        }
        const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });
        const yeni: RiskItem[] = rows.map((row) => {
          const get = (keys: string[]) => pickColumn(row, keys);
          const sayi = (v: string) => Math.max(1, Math.min(5, parseInt(v, 10) || 3));
          const olasi = sayi(get(['olasılık', 'olasilik', 'olasılık (1-5)', 'olasilik (1-5)', 'o']));
          const sidd = sayi(get(['şiddet', 'siddet', 'şiddet (1-5)', 'siddet (1-5)', 'ş']));
          return {
            id: '', kaynak: 'excel' as const,
            bolum: get(['bölüm', 'bolum', 'alan']), kategori: get(['kategori']),
            tehlike: get(['tehlike']), risk: get(['risk']),
            olasiSonuc: get(['olası sonuç', 'sonuc', 'sonuç']),
            mevcutKontroller: get(['mevcut kontrol', 'kontrol']),
            onerilenKontroller: get(['önerilen', 'onerilen', 'aksiyon']),
            sorumlu: get(['sorumlu', 'sorumlu kişi', 'sorumlu kisi']),
            termin: get(['termin', 'bitiş', 'bitis', 'son tarih']),
            durum: get(['durum', 'statü', 'statu']) || 'Planlandı',
            olasilik: olasi, siddet: sidd,
            notlar: get(['not', 'açıklama', 'aciklama', 'notlar']),
          };
        }).filter((r) => r.tehlike && r.risk);
        if (yeni.length === 0) {
          addToast({ title: 'İçe aktarılamadı', message: 'Geçerli satır bulunamadı. Tehlike ve Risk kolonlarını kontrol edin.', type: 'warning' });
          return;
        }
        onTopluEkle(yeni);
        addToast({ title: 'İçe aktarıldı', message: `${yeni.length} risk Excel’den eklendi.`, type: 'success' });
      } catch {
        addToast({ title: 'Dosya okunamadı', message: 'Excel dosyası ayrıştırılamadı.', type: 'error' });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="2. Tehlikeler ve Riskler"
        desc="İşyerinizdeki tehlikeleri belirleyin. Dilerseniz yapay zekâ önerilerinden faydalanabilir, önerileri düzenleyerek listeye ekleyebilirsiniz."
        right={(
          <div className="flex flex-shrink-0 items-center gap-1.5">
            <RwButton
              variant="primary"
              size="sm"
              icon={aiYukleniyor ? undefined : 'ri-sparkling-2-line'}
              disabled={aiYukleniyor}
              onClick={() => onAiYenile(aiKategori, aiAlan)}
            >
              {aiYukleniyor
                ? <><span className="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" /> Hazırlanıyor...</>
                : 'AI Önerilerini Yenile'}
            </RwButton>
            <RwIconButton
              icon="ri-information-line"
              onClick={() => addToast({ title: 'AI Önerileri', message: 'Her yenilemede 10 yeni öneri üretilir; önceki öneriler silinmez. İnceleyip listeye ekleyebilirsiniz.', type: 'info' })}
            />
          </div>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
        {/* SOL — AI paneli */}
        <div className="min-h-0">
          <AiTehlikePaneli
            oneriler={aiOnerileri}
            yukleniyor={aiYukleniyor}
            alan={aiAlan}
            onAlanChange={setAiAlan}
            kategori={aiKategori}
            onKategoriChange={setAiKategori}
            onEkle={onAiEkle}
            ekliMetinler={ekliMetinler}
          />
        </div>

        {/* SAĞ — liste + detay */}
        <div className="flex min-h-0 flex-col gap-3">
          <div className="flex flex-shrink-0 flex-wrap items-center justify-between gap-2">
            <RwTabs
              active={sekme}
              onChange={(k) => setSekme(k as Sekme)}
              tabs={[
                { key: 'tumu', label: 'Risk Listesi', count: riskler.length },
                { key: 'ai', label: 'AI’dan Eklenenler', count: aiAdet },
                { key: 'manuel', label: 'Manuel Eklenenler', count: manuelAdet },
              ]}
            />
            <div className="flex flex-wrap items-center gap-2">
              <RwButton variant="primary" size="sm" icon="ri-add-line" onClick={manuelAc}>Manuel Risk Ekle</RwButton>
              <RwButton variant="outline" size="sm" icon="ri-delete-bin-line" disabled={!seciliId} onClick={secileniSil}>Seçilenleri Sil</RwButton>
              <RwButton variant="outline" size="sm" icon="ri-file-excel-2-line" onClick={() => fileRef.current?.click()}>Excel’den Aktar</RwButton>
              <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="sr-only" onChange={(e) => { const f = e.target.files?.[0]; if (f) excelAktar(f); e.target.value = ''; }} />
            </div>
          </div>

          {/* Risk listesi (div + grid — <table> DEĞİL) */}
          <div className="isg-scroll-pane min-h-0 flex-1 overflow-auto rounded-lg border border-background-300/50 dark:border-background-400/30">
            <div style={{ minWidth: 1000 }}>
              <div
                className="sticky top-0 z-10 grid items-center border-b border-background-300/60 bg-background-200 px-2 py-2 dark:border-background-400/40 dark:bg-background-300/85"
                style={{ gridTemplateColumns: IZGARA, columnGap: '0.5rem' }}
              >
                <span className={`${TH} text-center`}>#</span>
                <span className={TH}>Bölüm / Alan</span>
                <span className={TH}>Tehlike</span>
                <span className={TH}>Risk</span>
                <span className={TH}>Olası Sonuç</span>
                <span className={`${TH} text-center`}>Olasılık</span>
                <span className={`${TH} text-center`}>Şiddet</span>
                <span className={`${TH} text-center`}>Puan</span>
                <span className={`${TH} text-center`}>Risk Seviyesi</span>
                <span className={`${TH} text-center`}>İşlemler</span>
              </div>

              {filtreli.length === 0 && (
                <div className="px-3 py-12 text-center text-xs text-foreground-400">
                  {riskler.length === 0 ? 'Henüz risk yok. AI önerilerinden veya manuel olarak ekleyin.' : 'Filtreye uyan kayıt yok.'}
                </div>
              )}

              {filtreli.map((r, i) => {
                const puan = riskPuani(r.olasilik, r.siddet);
                const seviye = SEVIYE_META[riskSeviyesi(puan)];
                const aktif = seciliId === r.id;
                return (
                  <div
                    key={r.id}
                    onClick={() => setSeciliId(r.id)}
                    className={`grid cursor-pointer items-center border-b border-background-300/25 px-2 py-2 transition-colors dark:border-background-400/15 ${
                      aktif ? 'bg-primary-500/10' : i % 2 === 1 ? 'bg-background-100/70 dark:bg-background-200/25' : ''
                    } hover:bg-primary-500/[0.06]`}
                    style={{ gridTemplateColumns: IZGARA, columnGap: '0.5rem' }}
                  >
                    <span className="text-center text-xs text-foreground-500">{i + 1}</span>
                    <span className="truncate text-xs text-foreground-700" title={r.bolum}>{r.bolum || '—'}</span>
                    <span className="truncate text-xs font-medium text-foreground-950" title={r.tehlike}>{r.tehlike || '—'}</span>
                    <span className="truncate text-xs text-foreground-700" title={r.risk}>{r.risk || '—'}</span>
                    <span className="truncate text-xs text-foreground-600" title={r.olasiSonuc}>{r.olasiSonuc || '—'}</span>
                    <span className="text-center text-xs text-foreground-700">{r.olasilik}</span>
                    <span className="text-center text-xs text-foreground-700">{r.siddet}</span>
                    <span className="text-center text-xs font-bold text-foreground-950">{puan}</span>
                    <span className="flex justify-center">
                      <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-md px-2 py-0.5 text-xs font-bold text-inverse ${seviye.badge}`}>
                        <i className={`${seviye.icon} text-xs`} /> {seviye.label}
                      </span>
                    </span>
                    <span className="flex items-center justify-center gap-0.5">
                      <RwIconButton icon="ri-edit-line" onClick={(e) => { e.stopPropagation(); setSeciliId(r.id); }} />
                      <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={(e) => { e.stopPropagation(); onSil(r.id); if (seciliId === r.id) setSeciliId(''); }} />
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Seçili risk detayı */}
          <div className="flex-shrink-0 rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="mb-3 flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300">
                <i className="ri-edit-2-line text-xs" />
              </span>
              <div>
                <h3 className="text-xs font-semibold text-foreground-950">Seçili Risk Detayı</h3>
                <p className="text-xs text-foreground-500">Düzenlemek için listeden bir risk seçin.</p>
              </div>
            </div>

            {!secili ? (
              <p className="py-4 text-center text-xs text-foreground-400">Düzenlemek için listeden bir risk seçin.</p>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <RwSelect label="Bölüm / Alan" options={RISK_ALANLARI.map((v) => ({ value: v, label: v }))} value={secili.bolum} onChange={(v) => onGuncelle(secili.id, { bolum: v })} placeholder="Seçiniz" searchable creatable />
                  <RwSelect label="Tehlike" options={tehlikeOptions} value={secili.tehlike} onChange={(v) => onGuncelle(secili.id, { tehlike: v })} placeholder="Seçiniz" searchable creatable />
                  <RwSelect label="Risk" options={riskOptions} value={secili.risk} onChange={(v) => onGuncelle(secili.id, { risk: v })} placeholder="Seçiniz" searchable creatable />
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <RwInput label="Olası Sonuç" value={secili.olasiSonuc} onChange={(e) => onGuncelle(secili.id, { olasiSonuc: e.target.value })} placeholder="Olası sonuç..." />
                  <RwTextarea label="Mevcut Kontroller" value={secili.mevcutKontroller} onChange={(e) => onGuncelle(secili.id, { mevcutKontroller: e.target.value })} placeholder="Mevcut kontrol tedbirleri..." />
                </div>

                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <RwSelect label="Olasılık (1-5)" options={SEVIYE_OPTIONS} value={String(secili.olasilik)} onChange={(v) => onGuncelle(secili.id, { olasilik: Number(v) })} />
                  <RwSelect label="Şiddet (1-5)" options={SEVIYE_OPTIONS} value={String(secili.siddet)} onChange={(v) => onGuncelle(secili.id, { siddet: Number(v) })} />
                  <div>
                    <span className="mb-1.5 block text-xs font-medium text-foreground-800">Risk Puanı</span>
                    <div className="flex h-10 items-center rounded-md border border-background-300/60 bg-background-50 px-3 text-xs font-bold text-foreground-950 dark:border-background-400/30 dark:bg-background-100">
                      {riskPuani(secili.olasilik, secili.siddet)}
                    </div>
                  </div>
                  <div>
                    <span className="mb-1.5 block text-xs font-medium text-foreground-800">Risk Seviyesi</span>
                    <div className="flex h-10 items-center">
                      {(() => {
                        const p = riskPuani(secili.olasilik, secili.siddet);
                        const m = SEVIYE_META[riskSeviyesi(p)];
                        return (
                          <span className={`inline-flex items-center gap-1 rounded-md px-2.5 py-1 text-xs font-bold text-inverse ${m.badge}`}>
                            <i className={`${m.icon} text-xs`} /> {m.label}
                          </span>
                        );
                      })()}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <RwSelect label="Rutin mi?" options={[{ value: 'true', label: 'Evet' }, { value: 'false', label: 'Hayır' }]} value={secili.rutin === false ? 'false' : 'true'} onChange={(v) => onGuncelle(secili.id, { rutin: v === 'true' })} />
                  <RwInput label="Etkilenenler" value={secili.etkilenenler || ''} onChange={(e) => onGuncelle(secili.id, { etkilenenler: e.target.value })} placeholder="Örn. Bölüm Çalışanları, Taşeron / Ziyaretçiler" />
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <RwSelect label="Kategori" options={RISK_KATEGORILERI.map((k) => ({ value: k, label: k }))} value={secili.kategori} onChange={(v) => onGuncelle(secili.id, { kategori: v })} placeholder="Kategori seçiniz" searchable creatable />
                  <RwTextarea label="Açıklama / Notlar" value={secili.notlar} onChange={(e) => onGuncelle(secili.id, { notlar: e.target.value })} placeholder="Ek açıklama ve notlar..." />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}