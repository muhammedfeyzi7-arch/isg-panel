import { useMemo, useState } from 'react';
import Icon from '@/components/ui/Icon';
import { useToastActions } from '@/hooks/useToast';
import { GECERLILIK_SECENEKLERI, riskPuani, riskSeviyesi, SEVIYE_META, type Imzaci, type RiskItem, type TemelBilgiler } from '@/components/feature/risk/riskSihirbazTypes';
import { pdfIndir, excelIndir, wordIndir } from '@/lib/riskRaporService';
import { RwButton, RwCard, RwIconButton, RwInput, RwSectionTitle, RwSelect } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// ADIM 5 — RAPOR VE ÖNİZLEME (Referans görsel 1)
// Sol: A4 doküman önizlemesi (+ yakınlaştırma araç çubuğu) · Sağ: Rapor
// Bilgileri · Raporu Dışa Aktar (Word/PDF/Excel) · İmzacı Bilgileri.
// ─────────────────────────────────────────────────────────────────────────────

interface Adim5Props {
  temel: TemelBilgiler;
  riskler: RiskItem[];
  onTemelChange: (patch: Partial<TemelBilgiler>) => void;
}

function tarihGoster(iso: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

export default function Adim5Rapor({ temel, riskler, onTemelChange }: Adim5Props) {
  const { addToast } = useToastActions();
  const [zoom, setZoom] = useState(100);
  const [indiriliyor, setIndiriliyor] = useState<'word' | 'pdf' | 'excel' | null>(null);
  const imzacilar = temel.imzacilar ?? [];
  // Önizleme, gerçek raporla AYNI imza mantığını kullanır: imzacı yoksa
  // hazırlayan/onaylayan kişiler otomatik gösterilir (rapor motoruyla birebir).
  const onizlemeImzalar: Imzaci[] = imzacilar.length > 0
    ? imzacilar
    : [
      ...(temel.hazirlayan?.trim() ? [{ id: 'h', adSoyad: temel.hazirlayan, gorev: 'Raporu Hazırlayan', belge: '' }] : []),
      ...(temel.onaylayan?.trim() ? [{ id: 'o', adSoyad: temel.onaylayan, gorev: 'Onaylayan', belge: '' }] : []),
    ];
  const [yeniAd, setYeniAd] = useState('');
  const [yeniGorev, setYeniGorev] = useState('');
  const [yeniBelge, setYeniBelge] = useState('');
  const [duzenlenen, setDuzenlenen] = useState<string | null>(null);

  const sayim = useMemo(() => {
    let yuksek = 0; let orta = 0; let dusuk = 0;
    riskler.forEach((r) => {
      const s = riskSeviyesi(riskPuani(r.olasilik, r.siddet));
      if (s === 'yuksek') yuksek += 1; else if (s === 'orta') orta += 1; else dusuk += 1;
    });
    return { yuksek, orta, dusuk, toplam: riskler.length };
  }, [riskler]);

  const raporNo = temel.raporNo?.trim() || `RD-${new Date().getFullYear()}-001`;

  const indir = async (tip: 'pdf' | 'excel' | 'word') => {
    if (riskler.length === 0) {
      addToast({ title: 'Risk listesi boş', message: 'Rapor oluşturmak için en az bir risk ekleyin.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndiriliyor(tip);
    try {
      const veri = { temel, riskler };
      if (tip === 'pdf') await pdfIndir(veri);
      else if (tip === 'excel') await excelIndir(veri);
      else await wordIndir(veri);
      addToast({ title: 'Rapor hazır', message: 'Dosya indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Rapor oluşturulamadı', message: 'Beklenmeyen bir hata oluştu.', type: 'error' });
    } finally {
      setIndiriliyor(null);
    }
  };

  const imzaciKaydet = () => {
    if (!yeniAd.trim()) return;
    const gorev = yeniGorev.trim() || 'Yetkili';
    if (duzenlenen) {
      onTemelChange({ imzacilar: imzacilar.map((x) => (x.id === duzenlenen ? { ...x, adSoyad: yeniAd.trim(), gorev, belge: yeniBelge.trim() } : x)) });
    } else {
      onTemelChange({ imzacilar: [...imzacilar, { id: `i-${Date.now()}`, adSoyad: yeniAd.trim(), gorev, belge: yeniBelge.trim() }] });
    }
    setYeniAd(''); setYeniGorev(''); setYeniBelge(''); setDuzenlenen(null);
  };

  const imzaciDuzenle = (im: Imzaci) => { setDuzenlenen(im.id); setYeniAd(im.adSoyad); setYeniGorev(im.gorev); setYeniBelge(im.belge); };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="5. Rapor ve Önizleme"
        desc="Risk değerlendirme raporunun son halini inceleyin. Gerekli bilgileri tamamlayıp raporu oluşturun."
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 lg:grid-cols-[minmax(0,1fr)_330px]">
        {/* SOL — Önizleme */}
        <div className="flex min-h-0 flex-col rounded-lg border border-background-300/50 bg-background-200/50 dark:border-background-400/30 dark:bg-background-300/20">
          <div className="flex flex-shrink-0 items-center justify-between gap-2 border-b border-background-300/40 px-3 py-2 dark:border-background-400/30">
            <div className="flex items-center gap-1">
              <RwIconButton icon="ri-arrow-left-s-line" />
              <span className="flex h-7 min-w-7 items-center justify-center rounded-md bg-background-100 px-2 text-xs font-semibold text-foreground-700 dark:bg-background-200">1 / 1</span>
              <RwIconButton icon="ri-arrow-right-s-line" />
            </div>
            <div className="flex items-center gap-1">
              <RwIconButton icon="ri-subtract-line" onClick={() => setZoom((z) => Math.max(60, z - 10))} />
              <span className="w-12 text-center text-xs font-medium text-foreground-600">%{zoom}</span>
              <RwIconButton icon="ri-add-line" onClick={() => setZoom((z) => Math.min(150, z + 10))} />
              <RwIconButton icon="ri-fullscreen-line" />
              <RwIconButton icon="ri-search-line" />
            </div>
          </div>

          <div className="isg-scroll-pane min-h-0 flex-1 overflow-auto p-4">
            <div className="mx-auto bg-white shadow-sm" style={{ width: 1040, transform: `scale(${zoom / 100})`, transformOrigin: 'top center' }}>
              <div className="p-8 text-[11px] text-gray-800">
                <div className="flex items-start justify-between border-b-2 border-[#C8102E] pb-3">
                  <div className="flex items-center gap-3">
                    <span className="flex h-12 w-12 items-center justify-center rounded bg-[#0F2747] text-white"><i className="ri-building-2-line text-2xl" /></span>
                    <div>
                      <p className="text-base font-bold text-[#0F2747]">{temel.firma || 'Firma Adı'}</p>
                      <p className="text-[11px] text-gray-500">{temel.tesis || 'Tesis / İş yeri'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-[#0F2747]">RİSK DEĞERLENDİRME RAPORU</p>
                    <p className="text-[10px] text-gray-500">6331 sayılı İSG Kanunu kapsamında hazırlanmıştır.</p>
                    <p className="text-[10px] text-gray-500">Rapor No: {raporNo}</p>
                  </div>
                </div>

                <table className="mt-3 w-full border-collapse">
                  <tbody>
                    <tr>
                      <td className="w-1/4 border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">Firma Adı</td>
                      <td className="border border-gray-300 px-2 py-1">{temel.firma || '—'}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">Adres</td>
                      <td className="border border-gray-300 px-2 py-1">{temel.adres || '—'}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">NACE Kodu</td>
                      <td className="border border-gray-300 px-2 py-1">{temel.nace || '—'}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">Çalışan Sayısı</td>
                      <td className="border border-gray-300 px-2 py-1">{temel.calisanSayisi || '—'}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">Tehlike Sınıfı</td>
                      <td className="border border-gray-300 px-2 py-1">{temel.tehlikeSinifi || '—'}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">Değerlendirme Metodu</td>
                      <td className="border border-gray-300 px-2 py-1">{temel.degerlendirmeMetodu}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">Tarih</td>
                      <td className="border border-gray-300 px-2 py-1">{tarihGoster(temel.tarih)}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">Geçerlilik</td>
                      <td className="border border-gray-300 px-2 py-1">{temel.gecerlilik}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 bg-gray-50 px-2 py-1 font-semibold">Kapsam</td>
                      <td className="border border-gray-300 px-2 py-1">{temel.kapsam || '—'}</td>
                    </tr>
                  </tbody>
                </table>

                <p className="mt-1.5 flex items-start gap-1 text-[9px] italic text-gray-500">
                  <i className="ri-information-line" />
                  Geçerlilik süresi, işyerinin tehlike sınıfına göre (Az Tehlikeli 6 Yıl · Tehlikeli 4 Yıl · Çok Tehlikeli 2 Yıl) otomatik belirlenmiştir.
                </p>

                <div className="mt-3 grid grid-cols-4 gap-2">
                  <div className="rounded border border-[#FDE7E7] bg-[#FDE7E7] p-2 text-center">
                    <p className="text-[10px] font-semibold text-[#B91C1C]">Yüksek Risk</p>
                    <p className="text-lg font-bold text-[#B91C1C]">{sayim.yuksek}</p>
                  </div>
                  <div className="rounded border border-[#FEF3C7] bg-[#FEF3C7] p-2 text-center">
                    <p className="text-[10px] font-semibold text-[#B45309]">Orta Risk</p>
                    <p className="text-lg font-bold text-[#B45309]">{sayim.orta}</p>
                  </div>
                  <div className="rounded border border-[#E7F7EE] bg-[#E7F7EE] p-2 text-center">
                    <p className="text-[10px] font-semibold text-[#15803D]">Düşük Risk</p>
                    <p className="text-lg font-bold text-[#15803D]">{sayim.dusuk}</p>
                  </div>
                  <div className="rounded border border-gray-200 bg-gray-50 p-2 text-center">
                    <p className="text-[10px] font-semibold text-gray-600">Toplam Risk</p>
                    <p className="text-lg font-bold text-gray-800">{sayim.toplam}</p>
                  </div>
                </div>

                <p className="mt-4 mb-1 font-bold text-[#0F2747]">RİSK LİSTESİ</p>
                <table className="w-full border-collapse text-[10px]">
                  <thead>
                    <tr className="bg-[#0F2747] text-white">
                      <th className="border border-gray-300 px-1.5 py-1 text-center">No</th>
                      <th className="border border-gray-300 px-1.5 py-1 text-left">Tehlike</th>
                      <th className="border border-gray-300 px-1.5 py-1 text-left">Risk</th>
                      <th className="border border-gray-300 px-1.5 py-1 text-center">Seviye</th>
                      <th className="border border-gray-300 px-1.5 py-1 text-left">Mevcut Kontroller</th>
                      <th className="border border-gray-300 px-1.5 py-1 text-left">Aksiyon</th>
                    </tr>
                  </thead>
                  <tbody>
                    {riskler.length === 0 && (
                      <tr><td colSpan={6} className="border border-gray-300 px-2 py-3 text-center text-gray-400">Kayıt bulunmuyor.</td></tr>
                    )}
                    {riskler.map((r, i) => {
                      const puan = riskPuani(r.olasilik, r.siddet);
                      const m = SEVIYE_META[riskSeviyesi(puan)];
                      return (
                        <tr key={r.id}>
                          <td className="border border-gray-300 px-1.5 py-1 text-center">{i + 1}</td>
                          <td className="border border-gray-300 px-1.5 py-1">{r.tehlike}</td>
                          <td className="border border-gray-300 px-1.5 py-1">{r.risk}</td>
                          <td className="border border-gray-300 px-1.5 py-1 text-center">
                            <span
                              className="inline-block rounded px-1.5 py-0.5 text-[10px] font-bold text-white"
                              style={{ backgroundColor: m.key === 'yuksek' ? '#B91C1C' : m.key === 'orta' ? '#B45309' : '#15803D' }}
                            >
                              {m.label}
                            </span>
                          </td>
                          <td className="border border-gray-300 px-1.5 py-1">{r.mevcutKontroller || '—'}</td>
                          <td className="border border-gray-300 px-1.5 py-1">{r.onerilenKontroller || '—'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>

                {onizlemeImzalar.length > 0 && (
                  <div className="mt-4 grid grid-cols-2 gap-3">
                    {onizlemeImzalar.map((im) => (
                      <div key={im.id} className="rounded border border-gray-300 p-2 text-center">
                        <p className="text-[10px] text-gray-500">İmza / Tarih</p>
                        <p className="mt-3 font-semibold">{im.adSoyad || '—'}</p>
                        <p className="text-[10px] text-gray-500">{im.gorev}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* SAĞ — Rapor bilgileri + dışa aktar + imzacılar */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <RwCard title="Rapor Bilgileri" icon="ri-file-list-3-line" className="p-3">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <RwInput label="Rapor Başlığı" value="Risk Değerlendirme Raporu" readOnly />
              <RwInput label="Rapor Tarihi" value={tarihGoster(temel.tarih)} readOnly />
              <RwInput label="Rapor Numarası" value={raporNo} readOnly />
              <RwSelect
                label="Geçerlilik Süresi"
                options={GECERLILIK_SECENEKLERI.map((v) => ({ value: v, label: v }))}
                value={temel.gecerlilik}
                onChange={(v) => onTemelChange({ gecerlilik: v })}
              />
              <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-foreground-500 sm:col-span-2">
                <i className="ri-information-line mt-0.5 text-primary-500" />
                <span>
                  Geçerlilik süresi tehlike sınıfına göre mevzuat gereği otomatik belirlenir:{' '}
                  <strong className="font-medium text-foreground-700">Az Tehlikeli 6 Yıl · Tehlikeli 4 Yıl · Çok Tehlikeli 2 Yıl.</strong>{' '}
                  Gerekirse listeden elle değiştirebilirsiniz.
                </span>
              </p>
            </div>
          </RwCard>

          <RwCard title="Raporu Dışa Aktar" icon="ri-download-2-line" className="p-3">
            <p className="mb-2.5 text-xs text-foreground-500">Raporu aşağıdaki formatlarda oluşturabilirsiniz.</p>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                disabled={indiriliyor !== null}
                onClick={() => void indir('word')}
                className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-primary-500 text-inverse transition-colors hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {indiriliyor === 'word' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="word" size="md" />}
                <span className="text-xs leading-tight">Word Olarak İndir</span>
              </button>
              <button
                type="button"
                disabled={indiriliyor !== null}
                onClick={() => void indir('pdf')}
                className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-danger-500 text-inverse transition-colors hover:bg-danger-600 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {indiriliyor === 'pdf' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="pdf" size="md" />}
                <span className="text-xs leading-tight">PDF Olarak İndir</span>
              </button>
              <button
                type="button"
                disabled={indiriliyor !== null}
                onClick={() => void indir('excel')}
                className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-success-500 text-inverse transition-colors hover:bg-success-600 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {indiriliyor === 'excel' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="excel" size="md" />}
                <span className="text-xs leading-tight">Excel Olarak İndir</span>
              </button>
            </div>
          </RwCard>

          <RwCard title="Raporda Yer Alacak İmzacı Bilgileri" icon="ri-user-star-line" className="p-3">
            <p className="mb-2 text-xs text-foreground-500">Raporun sonunda yer alacak imzacı bilgilerini ekleyin.</p>
            <div className="overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
              <table className="w-full border-collapse">
                <thead className="bg-background-200 dark:bg-background-300/60">
                  <tr className="text-left text-xs font-semibold text-foreground-500">
                    <th className="w-8 px-2 py-1.5 text-center">#</th>
                    <th className="px-2 py-1.5">Adı Soyadı</th>
                    <th className="px-2 py-1.5">Görevi</th>
                    <th className="px-2 py-1.5">Belge No</th>
                    <th className="w-16 px-2 py-1.5 text-center">İşlemler</th>
                  </tr>
                </thead>
                <tbody>
                  {imzacilar.map((im, i) => (
                    <tr key={im.id} className="border-t border-background-300/30 dark:border-background-400/20">
                      <td className="px-2 py-1.5 text-center text-xs text-foreground-500">{i + 1}</td>
                      <td className="px-2 py-1.5 text-xs font-medium text-foreground-950">{im.adSoyad || '—'}</td>
                      <td className="px-2 py-1.5 text-xs text-foreground-600">{im.gorev}</td>
                      <td className="px-2 py-1.5 text-xs text-foreground-600">{im.belge || '—'}</td>
                      <td className="px-2 py-1.5">
                        <div className="flex items-center justify-center gap-0.5">
                          <RwIconButton icon="ri-edit-line" onClick={() => imzaciDuzenle(im)} />
                          <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={() => { onTemelChange({ imzacilar: imzacilar.filter((x) => x.id !== im.id) }); if (duzenlenen === im.id) { setDuzenlenen(null); setYeniAd(''); setYeniGorev(''); setYeniBelge(''); } }} />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-2.5 space-y-2 rounded-md border border-dashed border-background-300/60 p-2.5 dark:border-background-400/30">
              <RwInput size="sm" placeholder="Ad Soyad" value={yeniAd} onChange={(e) => setYeniAd(e.target.value)} />
              <RwInput size="sm" placeholder="Görev" value={yeniGorev} onChange={(e) => setYeniGorev(e.target.value)} />
              <RwInput size="sm" placeholder="Belge / Sertifika No (opsiyonel)" value={yeniBelge} onChange={(e) => setYeniBelge(e.target.value)} />
              <RwButton variant="outline" size="sm" block icon={duzenlenen ? 'ri-check-line' : 'ri-add-line'} onClick={imzaciKaydet}>
                {duzenlenen ? 'Güncelle' : 'Yeni İmzacı Ekle'}
              </RwButton>
            </div>
          </RwCard>
        </div>
      </div>
    </div>
  );
}