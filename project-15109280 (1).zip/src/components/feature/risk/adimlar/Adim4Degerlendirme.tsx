import { useMemo, useState } from 'react';
import RiskMatrisInteractive from '@/components/feature/risk/RiskMatrisInteractive';
import RiskDagilimGrafik from '@/components/feature/risk/RiskDagilimGrafik';
import { riskPuani, riskSeviyesi, SEVIYE_META, KONTROL_TURLERI, type RiskItem } from '@/components/feature/risk/riskSihirbazTypes';
import { matchesSearch } from '@/utils/turkishText';
import {
  RwCard,
  RwIconButton,
  RwInfoBanner,
  RwInput,
  RwSectionTitle,
  RwSelect,
  RwTextarea,
} from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// ADIM 4 — DEĞERLENDİRME (Referans görsel 2)
// Sol: interaktif 5x5 matris · Orta: risk listesi (O/Ş düzenlenebilir) · Sağ:
// seçili risk detayı + dağılım grafiği. 2. adımdaki riskler hazır gelir.
// ─────────────────────────────────────────────────────────────────────────────

const SAYI_OPTIONS = [1, 2, 3, 4, 5].map((n) => ({ value: String(n), label: String(n) }));
const OLASILIK_AD: Record<number, string> = { 1: 'Çok Düşük', 2: 'Düşük', 3: 'Orta', 4: 'Yüksek', 5: 'Çok Yüksek' };
const SIDDET_AD: Record<number, string> = { 1: 'Çok Hafif', 2: 'Hafif', 3: 'Orta', 4: 'Ciddi', 5: 'Çok Ciddi' };

const TH = 'px-2 py-2 text-left text-xs font-semibold uppercase tracking-wide text-foreground-500 whitespace-nowrap';

interface Adim4Props {
  riskler: RiskItem[];
  onGuncelle: (id: string, patch: Partial<RiskItem>) => void;
}

export default function Adim4Degerlendirme({ riskler, onGuncelle }: Adim4Props) {
  const [seciliId, setSeciliId] = useState<string>(riskler[0]?.id ?? '');
  const [arama, setArama] = useState('');
  const [seviyeFiltre, setSeviyeFiltre] = useState('tumu');

  const secili = riskler.find((r) => r.id === seciliId) ?? riskler[0] ?? null;

  const sayim = useMemo(() => {
    let yuksek = 0; let orta = 0; let dusuk = 0;
    riskler.forEach((r) => {
      const s = riskSeviyesi(riskPuani(r.olasilik, r.siddet));
      if (s === 'yuksek') yuksek += 1; else if (s === 'orta') orta += 1; else dusuk += 1;
    });
    return { yuksek, orta, dusuk, toplam: riskler.length };
  }, [riskler]);

  const filtreli = useMemo(() => {
    let liste = riskler;
    if (seviyeFiltre !== 'tumu') liste = liste.filter((r) => riskSeviyesi(riskPuani(r.olasilik, r.siddet)) === seviyeFiltre);
    const q = arama.trim().toLocaleLowerCase('tr');
    if (q) liste = liste.filter((r) => matchesSearch(`${r.tehlike} ${r.risk}`, q));
    return liste;
  }, [riskler, seviyeFiltre, arama]);

  const noktalar = riskler.map((r) => ({ olasilik: r.olasilik, siddet: r.siddet }));

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="4. Değerlendirme"
        desc="Belirlediğiniz riskleri olasılık ve şiddet kriterlerine göre değerlendirin. Risk puanları otomatik hesaplanır ve risk seviyeleri belirlenir."
        right={(
          <div className="flex flex-shrink-0 items-start gap-2 rounded-lg border border-accent-300/50 bg-accent-50 p-2.5 dark:border-accent-500/30 dark:bg-accent-500/10">
            <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md bg-accent-500/20 text-accent-600 dark:text-accent-300">
              <i className="ri-sparkling-2-line text-xs" />
            </span>
            <span>
              <span className="block text-xs font-semibold text-foreground-950">Değerlendirme Yardımcısı</span>
              <span className="mt-0.5 block text-xs text-foreground-500">Risk puanları hakkında rehberlik alın</span>
            </span>
          </div>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 lg:grid-cols-[290px_minmax(0,1fr)_290px]">
        {/* SOL — Matris */}
        <RwCard className="isg-scroll-pane overflow-auto p-3">
          <div className="mb-2.5 flex items-center gap-1.5">
            <h3 className="text-xs font-semibold text-foreground-950">Risk Matrisi (5x5)</h3>
            <i className="ri-information-line text-xs text-foreground-400" />
          </div>
          <RiskMatrisInteractive
            noktalar={noktalar}
            secili={secili ? { olasilik: secili.olasilik, siddet: secili.siddet } : null}
            onHucre={(o, s) => { if (secili) onGuncelle(secili.id, { olasilik: o, siddet: s }); }}
          />
        </RwCard>

        {/* ORTA — Liste */}
        <div className="flex min-h-0 flex-col rounded-lg border border-background-300/50 bg-background-100 dark:border-background-400/30 dark:bg-background-200/40">
          <div className="flex flex-shrink-0 flex-wrap items-center justify-between gap-2 border-b border-background-300/40 px-3 py-2.5 dark:border-background-400/30">
            <h3 className="text-xs font-semibold text-foreground-950">Risk Değerlendirme Listesi</h3>
            <div className="flex items-center gap-2">
              <div className="w-40">
                <RwInput size="sm" placeholder="Risklerde ara..." value={arama} onChange={(e) => setArama(e.target.value)} leftIcon={<i className="ri-search-line text-xs" />} />
              </div>
              <div className="w-28">
                <RwSelect
                  size="sm"
                  options={[{ value: 'tumu', label: 'Tümü' }, { value: 'yuksek', label: 'Yüksek' }, { value: 'orta', label: 'Orta' }, { value: 'dusuk', label: 'Düşük' }]}
                  value={seviyeFiltre}
                  onChange={setSeviyeFiltre}
                />
              </div>
            </div>
          </div>

          <div className="isg-scroll-pane min-h-0 flex-1 overflow-auto">
            <table className="w-full min-w-[520px] border-collapse">
              <thead className="sticky top-0 z-10 border-b border-background-300/60 bg-background-200 dark:border-background-400/40 dark:bg-background-300/80">
                <tr>
                  <th className={`${TH} w-10 text-center`}>#</th>
                  <th className={TH}>Risk / Tehlike</th>
                  <th className={`${TH} text-center`}>Olasılık</th>
                  <th className={`${TH} text-center`}>Şiddet</th>
                  <th className={`${TH} text-center`}>Puan</th>
                  <th className={`${TH} text-center`}>Risk Seviyesi</th>
                  <th className={`${TH} w-10 text-center`} />
                </tr>
              </thead>
              <tbody>
                {filtreli.length === 0 && (
                  <tr><td colSpan={7} className="px-3 py-10 text-center text-xs text-foreground-400">{riskler.length === 0 ? 'Henüz risk yok.' : 'Filtreye uyan kayıt yok.'}</td></tr>
                )}
                {filtreli.map((r, i) => {
                  const puan = riskPuani(r.olasilik, r.siddet);
                  const m = SEVIYE_META[riskSeviyesi(puan)];
                  const aktif = secili?.id === r.id;
                  return (
                    <tr
                      key={r.id}
                      onClick={() => setSeciliId(r.id)}
                      className={`cursor-pointer border-b border-background-300/25 transition-colors dark:border-background-400/15 ${aktif ? 'bg-primary-500/10' : 'hover:bg-background-100 dark:hover:bg-background-300/20'}`}
                    >
                      <td className="px-2 py-2 text-center text-xs text-foreground-500">{i + 1}</td>
                      <td className="px-2 py-2 align-middle">
                        <p className="text-xs font-medium text-foreground-950">{r.tehlike}</p>
                        <p className="text-xs text-foreground-500">{r.risk}</p>
                      </td>
                      <td className="px-2 py-1.5">
                        <div className="w-[68px]"><RwSelect size="sm" options={SAYI_OPTIONS} value={String(r.olasilik)} onChange={(v) => onGuncelle(r.id, { olasilik: Number(v) })} /></div>
                      </td>
                      <td className="px-2 py-1.5">
                        <div className="w-[68px]"><RwSelect size="sm" options={SAYI_OPTIONS} value={String(r.siddet)} onChange={(v) => onGuncelle(r.id, { siddet: Number(v) })} /></div>
                      </td>
                      <td className="px-2 py-2 text-center text-xs font-bold text-foreground-950">{puan}</td>
                      <td className="px-2 py-2 text-center">
                        <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-bold text-inverse ${m.badge}`}>{m.label}</span>
                      </td>
                      <td className="px-2 py-2 text-center">
                        <RwIconButton icon="ri-eye-line" onClick={(e) => { e.stopPropagation(); setSeciliId(r.id); }} />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="flex flex-shrink-0 items-center justify-between border-t border-background-300/40 px-3 py-2 text-xs text-foreground-500 dark:border-background-400/30">
            <span>{filtreli.length} kayıt</span>
          </div>
        </div>

        {/* SAĞ — Detay + grafik */}
        <div className="isg-scroll-pane flex min-h-0 flex-col gap-3 overflow-y-auto">
          <RwCard title="Seçili Risk Detayı" className="p-3">
            {!secili ? (
              <p className="py-4 text-center text-xs text-foreground-400">Listeden bir risk seçin.</p>
            ) : (
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs text-foreground-500">{secili.kategori || 'Genel'}</p>
                    <p className="text-xs font-semibold text-foreground-950">{secili.tehlike}</p>
                    <p className="text-xs text-foreground-600">{secili.risk}</p>
                  </div>
                  <span className={`flex-shrink-0 rounded-md px-2 py-0.5 text-xs font-bold text-inverse ${SEVIYE_META[riskSeviyesi(riskPuani(secili.olasilik, secili.siddet))].badge}`}>
                    {SEVIYE_META[riskSeviyesi(riskPuani(secili.olasilik, secili.siddet))].label}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="rounded-md border border-background-300/50 bg-background-50 p-2 text-center dark:border-background-400/25 dark:bg-background-100">
                    <p className="text-xs text-foreground-400">Olasılık</p>
                    <p className="text-xs font-bold text-foreground-950">{secili.olasilik} - {OLASILIK_AD[secili.olasilik]}</p>
                  </div>
                  <div className="rounded-md border border-background-300/50 bg-background-50 p-2 text-center dark:border-background-400/25 dark:bg-background-100">
                    <p className="text-xs text-foreground-400">Şiddet</p>
                    <p className="text-xs font-bold text-foreground-950">{secili.siddet} - {SIDDET_AD[secili.siddet]}</p>
                  </div>
                  <div className="rounded-md border border-background-300/50 bg-background-50 p-2 text-center dark:border-background-400/25 dark:bg-background-100">
                    <p className="text-xs text-foreground-400">Risk Puanı</p>
                    <p className="text-xs font-bold text-foreground-950">{riskPuani(secili.olasilik, secili.siddet)}</p>
                  </div>
                  <div className="rounded-md border border-background-300/50 bg-background-50 p-2 text-center dark:border-background-400/25 dark:bg-background-100">
                    <p className="text-xs text-foreground-400">Risk Seviyesi</p>
                    <p className="text-xs font-bold text-foreground-950">{SEVIYE_META[riskSeviyesi(riskPuani(secili.olasilik, secili.siddet))].label}</p>
                  </div>
                </div>

                <RwTextarea label="Değerlendirme Notu" value={secili.notlar} onChange={(e) => onGuncelle(secili.id, { notlar: e.target.value })} placeholder="Değerlendirme notu..." />
              </div>
            )}
          </RwCard>

          <RwCard title="Kontrol Sonrası Risk" icon="ri-shield-check-line" className="p-3">
            {!secili ? (
              <p className="py-4 text-center text-xs text-foreground-400">Listeden bir risk seçin.</p>
            ) : (() => {
              const ilk = riskPuani(secili.olasilik, secili.siddet);
              const son = riskPuani(secili.kalanOlasilik ?? secili.olasilik, secili.kalanSiddet ?? secili.siddet);
              const az = ilk > 0 ? Math.max(0, Math.round(((ilk - son) / ilk) * 100)) : 0;
              return (
                <div className="space-y-3">
                  <RwSelect
                    label="Kontrol Türü"
                    options={KONTROL_TURLERI.map((k) => ({ value: k, label: k }))}
                    value={secili.kontrolTuru || ''}
                    onChange={(v) => onGuncelle(secili.id, { kontrolTuru: v })}
                    placeholder="Seçiniz"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <RwSelect label="Son Olasılık" options={SAYI_OPTIONS} value={String(secili.kalanOlasilik ?? secili.olasilik)} onChange={(v) => onGuncelle(secili.id, { kalanOlasilik: Number(v) })} />
                    <RwSelect label="Son Şiddet" options={SAYI_OPTIONS} value={String(secili.kalanSiddet ?? secili.siddet)} onChange={(v) => onGuncelle(secili.id, { kalanSiddet: Number(v) })} />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div className="rounded-md border border-background-300/50 bg-background-50 p-2 text-center dark:border-background-400/25 dark:bg-background-100">
                      <p className="text-xs text-foreground-400">İlk Puan</p>
                      <p className="text-xs font-bold text-foreground-950">{ilk}</p>
                    </div>
                    <div className="rounded-md border border-background-300/50 bg-background-50 p-2 text-center dark:border-background-400/25 dark:bg-background-100">
                      <p className="text-xs text-foreground-400">Son Puan</p>
                      <p className="text-xs font-bold text-foreground-950">{son}</p>
                    </div>
                    <div className="rounded-md border border-success-300/50 bg-success-50 p-2 text-center dark:border-success-500/25 dark:bg-success-500/10">
                      <p className="text-xs text-foreground-400">Azalma</p>
                      <p className="text-xs font-bold text-success-700 dark:text-success-300">%{az}</p>
                    </div>
                  </div>
                  <RwInput
                    label="Başlangıç Tarihi" type="date"
                    value={secili.baslangic || ''}
                    onChange={(e) => onGuncelle(secili.id, { baslangic: e.target.value })}
                  />
                </div>
              );
            })()}
          </RwCard>

          <RwCard title="Dağılım Grafiği" className="p-3">
            <RiskDagilimGrafik yuksek={sayim.yuksek} orta={sayim.orta} dusuk={sayim.dusuk} toplam={sayim.toplam} />
          </RwCard>
        </div>
      </div>

      <div className="mt-3">
        <RwInfoBanner icon="ri-check-double-line" title="Değerlendirme Tamamlandı">
          Tüm riskler değerlendirildi. Sonraki adımda raporu önizleyip Word, PDF veya Excel olarak indirebilirsiniz.
        </RwInfoBanner>
      </div>
    </div>
  );
}