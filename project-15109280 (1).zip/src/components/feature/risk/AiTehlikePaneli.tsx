import { useMemo, useState } from 'react';
import {
  RISK_KATEGORILERI,
  RISK_ALANLARI,
  TUM_ALANLAR,
  TUM_KATEGORILER,
  benzerMi,
  type AiOneri,
} from '@/components/feature/risk/riskSihirbazTypes';
import { KategoriIkon, kategoriGorunum } from '@/components/feature/risk/riskUi';
import { RwButton, RwInput, RwSelect } from '@/components/feature/risk/sihirbaz/wizardUi';
import { matchesSearch } from '@/utils/turkishText';

// ─────────────────────────────────────────────────────────────────────────────
// AI TEHLİKE ÖNERİLERİ PANELİ (2. adım — sol panel, Referans görsel 4)
// Renkli kategori ikonu + başlık + açıklama + "+ Ekle" kartları. Shared UI
// yerine sihirbaza özel RwSelect / RwInput / RwButton kullanır.
// ─────────────────────────────────────────────────────────────────────────────

interface AiTehlikePaneliProps {
  oneriler: AiOneri[];
  yukleniyor: boolean;
  alan: string;
  onAlanChange: (v: string) => void;
  kategori: string;
  onKategoriChange: (v: string) => void;
  onEkle: (o: AiOneri) => void;
  ekliMetinler: string[];
}

const BASLANGIC_GORUNEN = 5;

export default function AiTehlikePaneli({
  oneriler, yukleniyor, alan, onAlanChange, kategori, onKategoriChange, onEkle, ekliMetinler,
}: AiTehlikePaneliProps) {
  const [arama, setArama] = useState('');
  const [gosterilen, setGosterilen] = useState(BASLANGIC_GORUNEN);

  const alanOptions = useMemo(() => [TUM_ALANLAR, ...RISK_ALANLARI].map((v) => ({ value: v, label: v })), []);
  const kategoriOptions = useMemo(() => [TUM_KATEGORILER, ...RISK_KATEGORILERI].map((v) => ({ value: v, label: v })), []);

  const filtreli = useMemo(() => {
    const q = arama.trim().toLocaleLowerCase('tr');
    if (!q) return oneriler;
    return oneriler.filter((o) => matchesSearch(`${o.tehlike} ${o.risk} ${o.olasiSonuc} ${o.kategori}`, q));
  }, [oneriler, arama]);

  const gorunen = filtreli.slice(0, gosterilen);
  const eklendiMi = (o: AiOneri) => ekliMetinler.some((m) => benzerMi(m, `${o.tehlike} ${o.risk}`));

  return (
    <div className="flex h-full min-h-0 flex-col rounded-lg border border-background-300/50 bg-background-100 dark:border-background-400/30 dark:bg-background-200/40">
      <div className="flex-shrink-0 border-b border-background-300/40 p-3 dark:border-background-400/30">
        <div className="flex items-center gap-2">
          <span className="flex h-7 w-7 items-center justify-center rounded-md bg-accent-500/15 text-accent-600 dark:text-accent-300">
            <i className="ri-sparkling-2-line text-xs" />
          </span>
          <h3 className="text-xs font-semibold text-foreground-950">AI Tehlike Önerileri</h3>
        </div>
        <p className="mt-1.5 text-xs leading-relaxed text-foreground-500">
          Tesisinizin sektörü, tehlike sınıfı ve çalışma alanlarına göre olası tehlike ve riskleri önerilir.
        </p>

        <div className="mt-2.5 grid grid-cols-2 gap-2">
          <RwSelect size="sm" options={alanOptions} value={alan} onChange={onAlanChange} />
          <RwSelect size="sm" options={kategoriOptions} value={kategori} onChange={onKategoriChange} />
        </div>

        <div className="mt-2">
          <RwInput
            size="sm"
            placeholder="Önerilerde ara..."
            value={arama}
            onChange={(e) => { setArama(e.target.value); setGosterilen(BASLANGIC_GORUNEN); }}
            leftIcon={<i className="ri-search-line text-xs" />}
          />
        </div>
      </div>

      <div className="isg-scroll-pane min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
        {yukleniyor && (
          <div className="flex items-center justify-center gap-2 rounded-md border border-dashed border-background-300/60 p-4 dark:border-background-400/30">
            <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
            <span className="text-xs text-foreground-500">AI önerileri hazırlanıyor...</span>
          </div>
        )}

        {!yukleniyor && oneriler.length === 0 && (
          <div className="rounded-md border border-dashed border-background-300/60 p-4 text-center dark:border-background-400/30">
            <i className="ri-sparkling-2-line text-2xl text-foreground-300" />
            <p className="mt-1 text-xs text-foreground-500">
              Henüz öneri yok. Sağ üstteki “AI Önerilerini Yenile” ile tehlikeler önerilsin.
            </p>
          </div>
        )}

        {gorunen.map((o) => {
          const ekli = eklendiMi(o);
          const kat = kategoriGorunum(o.kategori);
          return (
            <div
              key={o.id}
              className={`rounded-lg border p-2.5 transition-colors ${
                ekli
                  ? 'border-success-500/40 bg-success-500/[0.06]'
                  : 'border-background-300/50 bg-background-50 hover:border-primary-300 dark:border-background-400/25 dark:bg-background-100/60 dark:hover:border-primary-500/40'
              }`}
            >
              <div className="flex items-start gap-2.5">
                <KategoriIkon kategori={o.kategori} className="h-9 w-9 text-sm" />
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold leading-snug text-foreground-950">{o.tehlike}</p>
                  <p className="mt-0.5 text-xs leading-snug text-foreground-500">
                    {o.risk}{o.olasiSonuc ? ` · ${o.olasiSonuc}` : ''}
                  </p>
                  {o.kategori && (
                    <span className={`mt-1.5 inline-flex items-center whitespace-nowrap rounded-md px-1.5 py-0.5 text-xs font-semibold ${kat.cls}`}>
                      {o.kategori}
                    </span>
                  )}
                </div>

                {ekli ? (
                  <span className="inline-flex flex-shrink-0 items-center gap-1 whitespace-nowrap rounded-md bg-success-500/15 px-2 py-1 text-xs font-semibold text-success-700 dark:text-success-300">
                    <i className="ri-check-line" /> Eklenen
                  </span>
                ) : (
                  <RwButton size="sm" variant="primary" icon="ri-add-line" onClick={() => onEkle(o)}>
                    Ekle
                  </RwButton>
                )}
              </div>
            </div>
          );
        })}

        {filtreli.length > gosterilen && (
          <RwButton variant="ghost" size="sm" block icon="ri-arrow-down-s-line" onClick={() => setGosterilen((g) => g + 5)}>
            Daha Fazla Öneri Göster ({filtreli.length - gosterilen})
          </RwButton>
        )}
      </div>
    </div>
  );
}