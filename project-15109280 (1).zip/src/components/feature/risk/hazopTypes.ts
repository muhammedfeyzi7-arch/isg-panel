// ─────────────────────────────────────────────────────────────────────────────
// HAZOP RİSK DEĞERLENDİRMESİ — ORTAK VERİ MODELİ
//
// 5x5 L Tipi Matris ve Fine-Kinney ile AYNI sihirbaz mimarisini kullanır ama
// yöntem PROSES ODAKLIdır (IEC 61882):
//   Düğüm (Node) → Parametre → Kılavuz Kelime → Sapma (Deviation) →
//   Neden → Sonuç → Mevcut Kontroller → İlave Önlemler
//
// RİSK PUANI = Olasılık (O) × Şiddet (S), her ikisi de 1–5 arası.
//
// ÖNEMLİ: Kalıcı kayıt/arşiv YOKTUR. Çalışma yalnızca yerel (IndexedDB) tutulur
// ve kullanıcı yalnızca PDF/Word/Excel indirir. Sisteme/Supabase'e veri gitmez.
// ─────────────────────────────────────────────────────────────────────────────
import {
  type TemelBilgiler,
  type Imzaci,
  yeniId,
  benzerMi,
  normalize,
} from './riskSihirbazTypes';

export { yeniId, benzerMi, normalize };
export type { Imzaci, TemelBilgiler };

export const HZ_METODU = 'HAZOP (Hazard and Operability Study — IEC 61882)';

// ── Parametreler ─────────────────────────────────────────────────────────────
export const HZ_PARAMETRELER: string[] = [
  'Akış (Flow)',
  'Basınç (Pressure)',
  'Sıcaklık (Temperature)',
  'Seviye (Level)',
  'Bileşim (Composition)',
  'pH',
  'Karıştırma (Agitation)',
  'Diğer',
];

// ── Kılavuz Kelimeler (Guide Words) ──────────────────────────────────────────
export interface HzKlavuzKelime {
  key: string;
  aciklama: string;
  sorular: string[];
}

export const HZ_KLAVUZ_KELIMELER: HzKlavuzKelime[] = [
  {
    key: 'HIÇ (NO)',
    aciklama: 'Parametrenin hiç olmaması / sıfır olması. Örn: akış yok, basınç yok, ısıtma yok.',
    sorular: ['Akış neden durabilir?', 'Basınç neden düşebilir?', 'Isıtma neden kesilebilir?', 'Karıştırma neden durur?'],
  },
  {
    key: 'FAZLA (MORE)',
    aciklama: 'Parametrenin tasarım değerinden daha fazla olması. Örn: yüksek sıcaklık, yüksek basınç.',
    sorular: ['Sıcaklık neden artabilir?', 'Akış neden artabilir?', 'Basınç neden yükselebilir?', 'Seviye neden fazla olabilir?'],
  },
  {
    key: 'AZ (LESS)',
    aciklama: 'Parametrenin tasarım değerinden daha az olması. Örn: düşük sıcaklık, düşük debi.',
    sorular: ['Sıcaklık neden düşebilir?', 'Akış neden azalabilir?', 'Basınç neden düşebilir?', 'Debi neden yetersiz kalır?'],
  },
  {
    key: 'TERS (REVERSE)',
    aciklama: 'Tasarım akışının tersine olması / ters reaksiyon / geri akış.',
    sorular: ['Ters akış neden oluşabilir?', 'Ters reaksiyon neden görülür?', 'Geri akışı ne tetikler?', 'Basınç dengesi neden ters döner?'],
  },
  {
    key: 'KISMEN (PART OF)',
    aciklama: 'Normal koşulların bir kısmının oluşması / eksik karışım / kısmi dönüşüm.',
    sorular: ['Kısmi dönüşüm neden oluşur?', 'Eksik karışım neden görülür?', 'Bazı bileşenler neden dönüşmez?', 'Katalizör miktarı yeterli mi?'],
  },
  {
    key: 'YAN SIRA (AS WELL AS)',
    aciklama: 'İstenmeyen ilave bileşenin proses içinde bulunması / safsızlık.',
    sorular: ['Safsızlık neden taşınır?', 'Yabancı bileşen nereden girer?', 'Kontaminasyon kaynağı nedir?', 'Temizlik/işletme hatası olur mu?'],
  },
  {
    key: 'DALGALANMA (FLUCTUATION)',
    aciklama: 'Parametrede dalgalanma / kararsız çalışma durumu.',
    sorular: ['Sıcaklık neden dalgalanır?', 'Basınç neden oynar?', 'Akış neden kararsız?', 'Kontrol döngüsü neden salgı yapar?'],
  },
];

export function klavuzBilgi(key: string): HzKlavuzKelime | undefined {
  return HZ_KLAVUZ_KELIMELER.find((k) => k.key === key);
}

// ── Kılavuz kelime + parametre → önerilen sapma metni ────────────────────────
function parametreKok(parametre: string): string {
  return (parametre || '').split('(')[0].trim();
}

export function sapmaOner(parametre: string, klavuz: string): string {
  const p = parametreKok(parametre);
  const pk = (p || 'değer').toLocaleLowerCase('tr');
  switch (klavuz) {
    case 'HIÇ (NO)': return `${p || 'Değer'}ın hiç olmaması / bulunmaması`;
    case 'FAZLA (MORE)': return `${p}ın tasarım değerinden fazla olması`;
    case 'AZ (LESS)': return `${p}ın tasarım değerinden düşük olması`;
    case 'TERS (REVERSE)': return `${pk}ın ters yönde olması / ters oluşması`;
    case 'KISMEN (PART OF)': return `${pk}ın kısmen oluşması / normalin bir kısmının gerçekleşmesi`;
    case 'YAN SIRA (AS WELL AS)': return `${pk} ile birlikte istenmeyen ilave bileşenin bulunması`;
    case 'DALGALANMA (FLUCTUATION)': return `${pk}ta dalgalanma / kararsız seyir olması`;
    default: return '';
  }
}

// ── Düğüm tipleri ────────────────────────────────────────────────────────────
export const HZ_DUGUM_TIPLERI: string[] = [
  'Hammadde Tankı',
  'Depolama Tankı',
  'Besleme Pompası',
  'Transfer Pompası',
  'Isıtıcı Eşanjör',
  'Soğutucu Eşanjör',
  'Reaktör',
  'Ayırma Ünitesi',
  'Distilasyon Kolonu',
  'Kompresör',
  'Dolum Ünitesi',
  'Diğer',
];

export function dugumTipIkon(tip: string): string {
  const t = (tip || '').toLocaleLowerCase('tr');
  if (t.includes('tank')) return 'ri-archive-2-line';
  if (t.includes('pompa')) return 'ri-settings-3-line';
  if (t.includes('eşanjör') || t.includes('esanjor')) return 'ri-temp-hot-line';
  if (t.includes('reaktör') || t.includes('reaktor')) return 'ri-flask-line';
  if (t.includes('ayırma') || t.includes('ayirma') || t.includes('distilasyon')) return 'ri-filter-3-line';
  if (t.includes('kompresör') || t.includes('kompresor')) return 'ri-gas-station-line';
  if (t.includes('dolum')) return 'ri-gas-station-line';
  return 'ri-node-tree';
}

export function parametreIkon(parametre: string): string {
  const t = (parametre || '').toLocaleLowerCase('tr');
  if (t.includes('akış') || t.includes('akis') || t.includes('flow')) return 'ri-flow-chart';
  if (t.includes('basınç') || t.includes('basinc') || t.includes('pressure')) return 'ri-dashboard-3-line';
  if (t.includes('sıcaklık') || t.includes('sicaklik') || t.includes('temperature')) return 'ri-temp-hot-line';
  if (t.includes('seviye') || t.includes('level')) return 'ri-bar-chart-box-line';
  if (t.includes('bileşim') || t.includes('bilesim') || t.includes('composition')) return 'ri-flask-line';
  if (t.includes('ph')) return 'ri-drop-line';
  if (t.includes('karıştırma') || t.includes('karistirma') || t.includes('agitation')) return 'ri-loader-4-line';
  return 'ri-equalizer-line';
}

// ── Kayıtlar ─────────────────────────────────────────────────────────────────
/** Liste içi işaretlenebilir madde (neden / sonuç / kontrol / önlem). */
export interface HzMadde {
  id: string;
  metin: string;
  secili: boolean;
}

export function bosMadde(metin = '', secili = false): HzMadde {
  return { id: yeniId('hz-m'), metin, secili };
}

/** Bir düğüm (prosesin incelenen bölümü). */
export interface HzDugum {
  id: string;
  no: string;
  ad: string;
  tip: string;
  tanim: string;
  tasarimAmaci: string;
  isletmeKosullari: string;
  parametreler: string[];
  /** Düğüm için genel değerlendirme / not (4. adım alt alanı). */
  genelNot?: string;
}

/** Bir sapma (düğüm + parametre + kılavuz kelime kombinasyonu). */
export interface HzSapma {
  id: string;
  dugumId: string;
  parametre: string;
  klavuzKelime: string;
  sapma: string;
  nedenler: HzMadde[];
  sonuclar: HzMadde[];
  mevcutKontroller: HzMadde[];
  ekOnlemler: HzMadde[];
  olasilik: number;   // 1–5
  siddet: number;     // 1–5
  kalanOlasilik?: number;
  kalanSiddet?: number;
  notlar: string;
}

/** İsteğe bağlı ek bilgi (rapor künye alanları TemelBilgiler ile paylaşılır). */
export interface HzTemelBilgiler extends TemelBilgiler {
  proses: string;
}

export interface HzWorkspace {
  temel: HzTemelBilgiler;
  dugumler: HzDugum[];
  sapmalar: HzSapma[];
  seciliDugumId: string;
  aktifAdim: number;
  guncellendi: string;
}

// ── Hesaplama ────────────────────────────────────────────────────────────────
export type HzSeviye = 'dusuk' | 'orta' | 'onemli' | 'yuksek' | 'cokYuksek';

export function hzPuan(olasilik: number, siddet: number): number {
  return Math.max(1, Math.min(5, Math.round(olasilik || 1))) * Math.max(1, Math.min(5, Math.round(siddet || 1)));
}

export function hzKalanPuan(s: HzSapma): number {
  return hzPuan(s.kalanOlasilik ?? s.olasilik, s.kalanSiddet ?? s.siddet);
}

/** 1–4 Düşük · 5–9 Orta · 10–14 Önemli · 15–19 Yüksek · 20–25 Çok Yüksek */
export function hzSeviye(puan: number): HzSeviye {
  if (puan <= 4) return 'dusuk';
  if (puan <= 9) return 'orta';
  if (puan <= 14) return 'onemli';
  if (puan <= 19) return 'yuksek';
  return 'cokYuksek';
}

export interface HzSeviyeMeta {
  key: HzSeviye;
  label: string;
  badge: string;
  soft: string;
  text: string;
  dot: string;
  icon: string;
  renk: string; // matris hücresi / rozet ham rengi
  hex: { fg: string; bg: string };
}

export const HZ_SEVIYE_META: Record<HzSeviye, HzSeviyeMeta> = {
  dusuk: {
    key: 'dusuk', label: 'Düşük',
    badge: 'bg-success-500 text-inverse', soft: 'bg-success-500/15 text-success-700 dark:text-success-300',
    text: 'text-success-700 dark:text-success-300', dot: 'bg-success-500', icon: 'ri-checkbox-circle-line',
    renk: '#16A34A', hex: { fg: '#15803D', bg: '#E7F7EE' },
  },
  orta: {
    key: 'orta', label: 'Orta',
    badge: 'bg-warning-500 text-inverse', soft: 'bg-warning-500/15 text-warning-700 dark:text-warning-300',
    text: 'text-warning-700 dark:text-warning-300', dot: 'bg-warning-500', icon: 'ri-alert-line',
    renk: '#F59E0B', hex: { fg: '#B45309', bg: '#FEF3C7' },
  },
  onemli: {
    key: 'onemli', label: 'Önemli',
    badge: 'bg-warning-600 text-inverse', soft: 'bg-warning-600/15 text-warning-800 dark:text-warning-200',
    text: 'text-warning-800 dark:text-warning-200', dot: 'bg-warning-600', icon: 'ri-alert-fill',
    renk: '#D97706', hex: { fg: '#92400E', bg: '#FDE8C8' },
  },
  yuksek: {
    key: 'yuksek', label: 'Yüksek',
    badge: 'bg-danger-500 text-inverse', soft: 'bg-danger-500/15 text-danger-700 dark:text-danger-300',
    text: 'text-danger-700 dark:text-danger-300', dot: 'bg-danger-500', icon: 'ri-error-warning-line',
    renk: '#DC2626', hex: { fg: '#B91C1C', bg: '#FDE7E7' },
  },
  cokYuksek: {
    key: 'cokYuksek', label: 'Çok Yüksek',
    badge: 'bg-danger-600 text-inverse', soft: 'bg-danger-600/15 text-danger-800 dark:text-danger-200',
    text: 'text-danger-800 dark:text-danger-200', dot: 'bg-danger-600', icon: 'ri-fire-line',
    renk: '#991B1B', hex: { fg: '#7F1D1D', bg: '#FBC5C5' },
  },
};

export function hzSeviyeBilgi(puan: number): HzSeviyeMeta {
  return HZ_SEVIYE_META[hzSeviye(puan)];
}

export const HZ_SEVIYE_SIRA: HzSeviye[] = ['cokYuksek', 'yuksek', 'onemli', 'orta', 'dusuk'];

/** Önemli bulgu eşiği: Yüksek ve üzeri. */
export function onemliBulgu(s: HzSapma): boolean {
  const k = hzSeviye(hzPuan(s.olasilik, s.siddet));
  return k === 'yuksek' || k === 'cokYuksek';
}

// ── Sabitler ─────────────────────────────────────────────────────────────────
export const HZ_ADIM_BASLIKLARI = [
  'Temel Bilgiler',
  'Düğüm ve Tasarım Amacı',
  'Sapmalar ve Nedenler',
  'Sonuçlar ve Korunma Önlemleri',
  'Rapor ve Önizleme',
];

export const HZ_TESIS_SECENEKLERI = [
  'Ana Üretim Tesisi',
  'Merkez Üretim Tesisi',
  'Kimyasal Üretim Tesisi',
  'Şube / Ek Tesis',
  'Depo / Lojistik Merkezi',
  'Laboratuvar',
  'Rafineri / Proses Tesisi',
  'Diğer',
];

const sayac = { n: 0 };
export function hzId(onek = 'hz'): string {
  sayac.n += 1;
  return `${onek}-${Date.now().toString(36)}-${sayac.n}`;
}

function bugunIso(): string {
  const b = new Date();
  return `${b.getFullYear()}-${String(b.getMonth() + 1).padStart(2, '0')}-${String(b.getDate()).padStart(2, '0')}`;
}

/** Referans görseldeki örnek proses akışına birebir yakın başlangıç düğümleri. */
export function hazopOrnekDugumler(): HzDugum[] {
  return [
    { id: hzId('hz-d'), no: 'T-101', ad: 'Hammadde Tankı', tip: 'Hammadde Tankı', tanim: 'Hammaddelerin depolandığı ve prosese beslendiği tank.', tasarimAmaci: 'Hammaddenin güvenli ve kesintisiz depolanması ile prosese kontrollü beslenmesi.', isletmeKosullari: '- Basınç: Atmosferik\n- Sıcaklık: Ortam sıcaklığı\n- Seviye: %20 – %85', parametreler: ['Akış (Flow)', 'Basınç (Pressure)', 'Seviye (Level)', 'Bileşim (Composition)'] },
    { id: hzId('hz-d'), no: 'P-101', ad: 'Besleme Pompası', tip: 'Besleme Pompası', tanim: 'Hammaddeyi reaktöre besleyen santrifüj pompa.', tasarimAmaci: 'Hammaddenin tasarım debisinde ve sürekli olarak reaktöre iletilmesi.', isletmeKosullari: '- Debi: 12 – 15 m³/sa\n- Basınç: 2 – 5 barg', parametreler: ['Akış (Flow)', 'Basınç (Pressure)'] },
    { id: hzId('hz-d'), no: 'E-101', ad: 'Isıtıcı Eşanjör', tip: 'Isıtıcı Eşanjör', tanim: 'Reaktör beslemesini ön ısıtmaya tabi tutan eşanjör.', tasarimAmaci: 'Besleme akımının reaksiyon sıcaklığına kadar ısıtılması.', isletmeKosullari: '- Çıkış sıcaklığı: 80 – 120 °C\n- Isıtma ortamı: Doymuş buhar', parametreler: ['Sıcaklık (Temperature)', 'Akış (Flow)', 'Basınç (Pressure)'] },
    { id: hzId('hz-d'), no: 'R-101', ad: 'Reaktör', tip: 'Reaktör', tanim: 'Sürekli karıştırmalı reaktör. Organik solvent ve katalizör varlığında ekzotermik reaksiyon.', tasarimAmaci: 'Güvenli, kararlı ve kontrollü şekilde reaksiyon gerçekleştirmek.', isletmeKosullari: '- Sıcaklık: 80 – 120 °C\n- Basınç: 2 – 5 barg\n- Sürekli karıştırma\n- Kapalı sistem (inert atmosfer)', parametreler: ['Sıcaklık (Temperature)', 'Basınç (Pressure)', 'Akış (Flow)', 'Bileşim (Composition)', 'Karıştırma (Agitation)'] },
    { id: hzId('hz-d'), no: 'S-101', ad: 'Ayırma Ünitesi', tip: 'Ayırma Ünitesi', tanim: 'Reaksiyon ürün karışımının fazlara ayrıldığı separatör.', tasarimAmaci: 'Ürün, yan ürün ve solventin verimli şekilde ayrılması.', isletmeKosullari: '- Basınç: 1 – 3 barg\n- Seviye: %30 – %70', parametreler: ['Seviye (Level)', 'Basınç (Pressure)', 'Bileşim (Composition)'] },
    { id: hzId('hz-d'), no: 'T-102', ad: 'Depolama Tankı', tip: 'Depolama Tankı', tanim: 'Ayrılan ürünün geçici olarak depolandığı tank.', tasarimAmaci: 'Nihai ürünün güvenli depolanması.', isletmeKosullari: '- Atmosferik\n- Seviye: %10 – %90', parametreler: ['Seviye (Level)', 'Basınç (Pressure)'] },
    { id: hzId('hz-d'), no: 'P-102', ad: 'Transfer Pompası', tip: 'Transfer Pompası', tanim: 'Ürünü depolama tankından dolum ünitesine aktaran pompa.', tasarimAmaci: 'Ürünün dolum ünitesine kesintisiz transferi.', isletmeKosullari: '- Debi: 10 – 12 m³/sa', parametreler: ['Akış (Flow)', 'Basınç (Pressure)'] },
    { id: hzId('hz-d'), no: 'F-101', ad: 'Dolum Ünitesi', tip: 'Dolum Ünitesi', tanim: 'Ürünün varillere/tanker dolumunun yapıldığı ünite.', tasarimAmaci: 'Ürünün güvenli ve doğru miktarda dolumunu sağlamak.', isletmeKosullari: '- Atmosferik\n- Dolum kapasitesi: 8 – 10 ton/sa', parametreler: ['Akış (Flow)', 'Seviye (Level)'] },
  ];
}

export function bosHzTemelBilgiler(): HzTemelBilgiler {
  return {
    calismaAdi: '',
    firma: '',
    degerlendirmeMetodu: HZ_METODU,
    kapsam: '',
    tarih: bugunIso(),
    tesis: '',
    gecerlilik: '',
    amac: '',
    ekip: [],
    dokumanlar: [],
    raporNo: '',
    tehlikeSinifi: '',
    adres: '',
    isveren: '',
    nace: '',
    calisanSayisi: '',
    hazirlayan: '',
    onaylayan: '',
    imzacilar: [],
    proses: '',
  };
}

export function bosHzWorkspace(): HzWorkspace {
  return {
    temel: bosHzTemelBilgiler(),
    dugumler: [],
    sapmalar: [],
    seciliDugumId: '',
    aktifAdim: 0,
    guncellendi: new Date().toISOString(),
  };
}

export function bosSapma(dugumId: string, parametre = '', klavuzKelime = ''): HzSapma {
  return {
    id: hzId('hz-s'),
    dugumId,
    parametre,
    klavuzKelime,
    sapma: parametre && klavuzKelime ? sapmaOner(parametre, klavuzKelime) : '',
    nedenler: [],
    sonuclar: [],
    mevcutKontroller: [],
    ekOnlemler: [],
    olasilik: 3,
    siddet: 3,
    notlar: '',
  };
}

/** Düğüm için benzersiz düğüm no üretir (T-101, T-102 …). */
export function yeniDugumNo(dugumler: HzDugum[], tip: string): string {
  const onek = tip.toLocaleLowerCase('tr').includes('tank') ? 'T'
    : tip.toLocaleLowerCase('tr').includes('pompa') ? 'P'
      : tip.toLocaleLowerCase('tr').includes('eşanjör') ? 'E'
        : tip.toLocaleLowerCase('tr').includes('reaktör') ? 'R'
          : tip.toLocaleLowerCase('tr').includes('ayırma') || tip.toLocaleLowerCase('tr').includes('distilasyon') ? 'S'
            : tip.toLocaleLowerCase('tr').includes('dolum') ? 'F'
              : tip.toLocaleLowerCase('tr').includes('kompresör') ? 'K'
                : 'N';
  const numaralar = dugumler
    .map((d) => d.no.toLocaleLowerCase('tr'))
    .filter((n) => n.startsWith(onek.toLocaleLowerCase('tr') + '-'))
    .map((n) => parseInt(n.split('-')[1] || '0', 10))
    .filter((n) => Number.isFinite(n));
  const son = numaralar.length ? Math.max(...numaralar) : 100;
  return `${onek}-${son + 1}`;
}