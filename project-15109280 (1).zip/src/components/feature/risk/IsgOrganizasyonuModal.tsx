import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import { useModalActions } from '@/hooks/useModal';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import AcilDurumEkipYonetimiModal from './AcilDurumEkipYonetimiModal';
import AcilDurumTatbikatModal from './AcilDurumTatbikatModal';
import {
  fetchFirma,
  fetchNaceById,
  resolveCalisanSayisi,
  type FirmaData,
  type NaceKod,
} from '@/lib/firmaService';
import { fetchFirmaGereksinimleri, HAZARD_CLASS_LABEL, type FirmaGereksinimRow, type RequirementStatus } from '@/lib/gereksinimService';
import { fetchFirmaAktifAtamalar, personelTuruLabel, type FirmaAktifAtama } from '@/lib/assignmentService';
import { fetchEkipYapisi, type EkipYapisi } from '@/lib/acilDurumEkipService';

interface Props {
  firmaId: string;
  role: 'uzman' | 'firma';
  onClose: () => void;
}

type ProfRole = 'isg_uzmani' | 'isyeri_hekimi' | 'dsp';

const PROF_SIRA: ProfRole[] = ['isg_uzmani', 'isyeri_hekimi', 'dsp'];

const PROF_META: Record<ProfRole, { ad: string; alt: string; ikon: string; renk: string }> = {
  isg_uzmani: { ad: 'İş Güvenliği Uzmanları', alt: 'Görevli İş Güvenliği Uzmanlarını görüntüleyin.', ikon: 'ri-shield-user-line', renk: 'danger' },
  isyeri_hekimi: { ad: 'İşyeri Hekimleri', alt: 'Görevli işyeri hekimlerini görüntüleyin.', ikon: 'ri-stethoscope-line', renk: 'primary' },
  dsp: { ad: 'Diğer Sağlık Personeli', alt: 'Görevli diğer sağlık personelini görüntüleyin.', ikon: 'ri-first-aid-kit-line', renk: 'success' },
};

const RENK_TILE: Record<string, string> = {
  danger: 'bg-danger-50 dark:bg-danger-500/15 text-danger-600 dark:text-danger-300',
  primary: 'bg-primary-100 dark:bg-primary-500/15 text-primary-600 dark:text-primary-300',
  success: 'bg-success-50 dark:bg-success-500/15 text-success-600 dark:text-success-300',
  accent: 'bg-accent-100 dark:bg-accent-500/20 text-accent-700 dark:text-accent-300',
  secondary: 'bg-secondary-100 dark:bg-secondary-500/20 text-secondary-700 dark:text-secondary-300',
};

function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '—';
  if (parts.length === 1) return parts[0].slice(0, 2).toLocaleUpperCase('tr');
  return (parts[0][0] + parts[parts.length - 1][0]).toLocaleUpperCase('tr');
}

function toProfRole(a: { personelTuru: string | null; atamaTuru: string }): ProfRole {
  if (a.personelTuru === 'isg_uzmani' || a.personelTuru === 'isyeri_hekimi' || a.personelTuru === 'dsp') {
    return a.personelTuru;
  }
  return a.atamaTuru === 'hekim' ? 'isyeri_hekimi' : 'isg_uzmani';
}

/**
 * İSG ORGANİZASYONU (görsel 1).
 *
 * İş Güvenliği Uzmanı / işyeri hekimi / DSP kartları SALT OKUNURDUR — buradan atama YAPILMAZ
 * (atamalar OSGB Atamalar modülünden yapılır). Üstte firmanın tehlike sınıfı ve çalışan
 * sayısına göre merkezi gereksinim motorunun çıktısı (karşılanan / eksik) gösterilir.
 * Acil durum ekipleri gerçek personelden atanır ve "Ekipleri Yönet" ile yönetilir.
 */
export default function IsgOrganizasyonuModal({ firmaId, role, onClose }: Props) {
  const { openModal, closeModal } = useModalActions();
  const ekipModalRef = useRef('');
  const tatbikatModalRef = useRef('');

  const [firma, setFirma] = useState<FirmaData | null>(null);
  const [nace, setNace] = useState<NaceKod | null>(null);
  const [gereksinimler, setGereksinimler] = useState<FirmaGereksinimRow[]>([]);
  const [atamalar, setAtamalar] = useState<FirmaAktifAtama[]>([]);
  const [ekipler, setEkipler] = useState<EkipYapisi[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  const yukle = useCallback(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      fetchFirma(firmaId),
      fetchFirmaGereksinimleri(firmaId, 'uzman').catch(() => [] as FirmaGereksinimRow[]),
      fetchFirmaAktifAtamalar(firmaId).catch(() => [] as FirmaAktifAtama[]),
      fetchEkipYapisi(firmaId).catch(() => [] as EkipYapisi[]),
    ])
      .then(async ([f, reqs, ats, ek]) => {
        setFirma(f);
        setGereksinimler(reqs);
        setAtamalar(ats);
        setEkipler(ek);
        if (f.naceId) {
          try {
            setNace(await fetchNaceById(f.naceId));
          } catch {
            setNace(null);
          }
        }
      })
      .catch((e) => setError(friendlyErrorMessage(e, 'Veriler yüklenemedi.')))
      .finally(() => setLoading(false));
  }, [firmaId]);

  useEffect(() => { yukle(); }, [yukle, refreshKey]);

  const profByRole = useMemo(() => {
    const map: Record<ProfRole, FirmaAktifAtama[]> = { isg_uzmani: [], isyeri_hekimi: [], dsp: [] };
    for (const a of atamalar) {
      if (a.assignmentRole === 'helper') continue;
      map[toProfRole(a)].push(a);
    }
    return map;
  }, [atamalar]);

  const ekipKoduIle = useMemo(() => new Map(ekipler.map((e) => [e.code, e])), [ekipler]);
  const toplamEkipUyesi = useMemo(() => ekipler.reduce((s, e) => s + e.uyeler.length, 0), [ekipler]);

  const eksikSet = useMemo(() => {
    const s = new Set<string>();
    for (const r of gereksinimler) {
      const st: RequirementStatus = r.status;
      if (st === 'missing' || st === 'critical') s.add(r.requirement_code);
    }
    return s;
  }, [gereksinimler]);

  const ozet = useMemo(() => {
    let met = 0;
    let eksik = 0;
    for (const r of gereksinimler) {
      if (r.status === 'met') met += 1;
      else if (r.status === 'missing' || r.status === 'critical') eksik += 1;
    }
    return { met, eksik };
  }, [gereksinimler]);

  const ekipModalAc = useCallback(() => {
    const id = openModal({
      title: 'Acil Durum Ekipleri',
      variant: 'large',
      width: 1080,
      minWidth: 720,
      minHeight: 620,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      maximizable: true,
      content: (
        <AcilDurumEkipYonetimiModal
          firmaId={firmaId}
          role={role}
          onClose={() => closeModal(ekipModalRef.current)}
          onChanged={() => setRefreshKey((k) => k + 1)}
        />
      ),
    });
    ekipModalRef.current = id;
  }, [openModal, closeModal, firmaId, role]);

  const tatbikatModalAc = useCallback(() => {
    const id = openModal({
      title: 'Acil Durum Tatbikatları',
      variant: 'large',
      width: 1180,
      minWidth: 860,
      minHeight: 620,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      maximizable: true,
      content: (
        <AcilDurumTatbikatModal
          firmaId={firmaId}
          role={role}
          onClose={() => closeModal(tatbikatModalRef.current)}
          onChanged={() => setRefreshKey((k) => k + 1)}
        />
      ),
    });
    tatbikatModalRef.current = id;
  }, [openModal, closeModal, firmaId, role]);

  if (loading) {
    return <div className="flex justify-center py-16"><Loading size="lg" text="İSG organizasyonu yükleniyor..." /></div>;
  }
  if (error || !firma) {
    return <ErrorState message={error ?? 'Firma bulunamadı.'} onRetry={yukle} />;
  }

  const tehlikeLabel = nace ? HAZARD_CLASS_LABEL[nace.tehlike_sinifi] : HAZARD_CLASS_LABEL[firma.tehlikeSinifi as keyof typeof HAZARD_CLASS_LABEL] ?? '—';
  const calisan = resolveCalisanSayisi(firma);

  return (
    <div className="flex flex-col gap-3">
      {/* Firma bilgi barı */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 px-3 py-2.5 rounded-lg bg-background-100 dark:bg-background-200/50 border border-background-200/70 dark:border-background-400/25">
        <span className="flex items-center gap-2 min-w-0">
          <span className="w-8 h-8 rounded-md bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-300 flex items-center justify-center flex-shrink-0">
            <i className="ri-building-4-line" />
          </span>
          <span className="text-sm font-semibold text-foreground-900 truncate">{firma.ad}</span>
        </span>
        <span className="text-xs text-foreground-500">NACE: <strong className="text-foreground-800">{nace?.kod ?? '—'}</strong></span>
        <span className="text-xs text-foreground-500">Tehlike Sınıfı: <strong className="text-foreground-800">{tehlikeLabel}</strong></span>
        <span className="text-xs text-foreground-500">Çalışan: <strong className="text-foreground-800">{calisan}</strong></span>
        <span className="ml-auto flex items-center gap-1.5">
          {ozet.eksik > 0 ? (
            <Badge variant="danger">{ozet.eksik} eksik yükümlülük</Badge>
          ) : (
            <Badge variant="success">Tüm yükümlülükler karşılandı</Badge>
          )}
        </span>
      </div>

      {/* Kart ızgarası */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
        {PROF_SIRA.map((rk) => {
          const meta = PROF_META[rk];
          const kod = rk === 'isg_uzmani' ? 'ISG_UZMANI' : rk === 'isyeri_hekimi' ? 'ISYERI_HEKIMI' : 'DIGER_SAGLIK_PERSONELI';
          const req = gereksinimler.find((r) => r.requirement_code === kod) ?? null;
          const liste = profByRole[rk];
          const eksik = eksikSet.has(kod);
          return (
            <div key={rk} className="rounded-xl border border-background-200/70 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-4">
              <div className="flex items-start gap-3">
                <span className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${RENK_TILE[meta.renk]}`}>
                  <i className={`${meta.ikon} text-lg`} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="text-sm font-semibold text-foreground-900">{meta.ad}</h4>
                    <Badge variant={liste.length > 0 ? 'success' : 'default'}>{liste.length} Kişi</Badge>
                    {eksik && <Badge variant="danger">Eksik</Badge>}
                  </div>
                  <p className="text-xs text-foreground-500 mt-0.5">{meta.alt}</p>
                </div>
              </div>

              <div className="mt-3 space-y-2">
                {liste.length === 0 ? (
                  <div className="rounded-lg border border-dashed border-background-300/80 dark:border-background-400/40 px-3 py-3 text-center">
                    <p className="text-xs text-foreground-500">
                      Bu pozisyon için atama yok. Atamalar <strong>OSGB → Atamalar</strong> modülünden yapılır.
                      {req?.required_quantity != null ? ` Gerekli: ${req.required_quantity} kişi.` : ''}
                    </p>
                  </div>
                ) : (
                  liste.map((a) => (
                    <div key={a.id} className="flex items-center gap-2.5 rounded-lg border border-background-200/70 dark:border-background-400/25 px-3 py-2">
                      <span className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 text-[10px] font-semibold flex items-center justify-center flex-shrink-0">
                        {initials(a.personelAdSoyad)}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-foreground-900 truncate">{a.personelAdSoyad}</p>
                        <p className="text-[11px] text-foreground-500 truncate">
                          {personelTuruLabel(a.personelTuru) || '—'}
                          {a.uzmanlikSinifi ? ` · ${a.uzmanlikSinifi}` : ''}
                        </p>
                      </div>
                      <Badge variant="success">Atanmış</Badge>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}

        {/* Acil Durum Ekipleri (toplam) */}
        <div className="rounded-xl border border-background-200/70 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-4">
          <div className="flex items-start gap-3">
            <span className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${RENK_TILE.accent}`}>
              <i className="ri-team-line text-lg" />
            </span>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h4 className="text-sm font-semibold text-foreground-900">Acil Durum Ekipleri</h4>
                <Badge variant="info">{toplamEkipUyesi} Kişi</Badge>
              </div>
              <p className="text-xs text-foreground-500 mt-0.5">Acil durum ekiplerini görüntüleyin.</p>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap gap-1.5">
            {ekipler.length === 0 ? (
              <p className="text-xs text-foreground-500">Ekip tanımı yok.</p>
            ) : (
              ekipler.slice(0, 6).map((e) => (
                <span key={e.code} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-background-200 dark:bg-background-300/40 text-[11px] text-foreground-700">
                  <i className={e.ikon} />
                  {e.ad} · {e.uyeler.length}
                </span>
              ))
            )}
          </div>

          <div className="mt-3 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={tatbikatModalAc}
              className="inline-flex items-center gap-1 text-xs font-semibold text-primary-600 hover:text-primary-700 cursor-pointer"
            >
              <i className="ri-alarm-warning-line" />
              Tatbikatlar
            </button>
            <button
              type="button"
              onClick={ekipModalAc}
              className="inline-flex items-center gap-1 text-xs font-semibold text-primary-600 hover:text-primary-700 cursor-pointer"
            >
              <i className="ri-settings-3-line" />
              Ekipleri Yönet
            </button>
          </div>
        </div>
      </div>

      {/* Ekip kartları */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
        {ekipler.map((e) => (
          <div key={e.code} className="rounded-xl border border-background-200/70 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-4">
            <div className="flex items-start gap-3">
              <span className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${RENK_TILE[e.renk] ?? RENK_TILE.primary}`}>
                <i className={`${e.ikon} text-lg`} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h4 className="text-sm font-semibold text-foreground-900">{e.ad}</h4>
                  <Badge variant="default">{e.uyeler.length} Kişi</Badge>
                  {e.eksik != null && e.eksik > 0 && <Badge variant="danger">{e.eksik} eksik</Badge>}
                  {e.ozel && <Badge variant="secondary">Özel</Badge>}
                </div>
                <p className="text-xs text-foreground-500 mt-0.5">{e.gorevTanimi || 'Acil durum ekibi.'}</p>
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-1">
                {e.uyeler.length === 0 ? (
                  <span className="text-xs text-foreground-400">Üye yok</span>
                ) : (
                  <>
                    {e.uyeler.slice(0, 4).map((u) => (
                      <span
                        key={u.atamaId}
                        title={u.adSoyad}
                        className="w-7 h-7 rounded-full bg-background-200 dark:bg-background-300/50 text-foreground-600 text-[9px] font-semibold flex items-center justify-center border-2 border-background-50 dark:border-background-100"
                      >
                        {initials(u.adSoyad)}
                      </span>
                    ))}
                    {e.uyeler.length > 4 && (
                      <span className="w-7 h-7 rounded-full bg-background-300/60 dark:bg-background-400/40 text-foreground-600 text-[9px] font-semibold flex items-center justify-center">
                        +{e.uyeler.length - 4}
                      </span>
                    )}
                  </>
                )}
              </div>
              <button
                type="button"
                onClick={ekipModalAc}
                className="inline-flex items-center gap-1 text-xs font-semibold text-primary-600 hover:text-primary-700 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-settings-3-line" />
                Ekipleri Yönet
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="flex items-center justify-between gap-2 pt-2 border-t isg-divider">
        <p className="text-[11px] text-foreground-500">
          İş Güvenliği Uzmanı / hekim / DSP atamaları OSGB Atamalar modülünden yapılır; bu ekran yalnızca görüntüler.
        </p>
        <Button variant="ghost" className="whitespace-nowrap" onClick={onClose}>İptal</Button>
      </div>
    </div>
  );
}