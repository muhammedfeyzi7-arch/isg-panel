import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import DatePicker from '@/components/ui/DatePicker';
import Search from '@/components/ui/Search';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import EvrakUploadModal from '@/components/feature/evrak/EvrakUploadModal';
import { fetchAcilDurumAtamalari, type AcilDurumPersonel } from '@/lib/acilDurumService';
import { ekipPersonelHavuzu, SISTEM_EKIP_ADI, friendlyEkipError } from '@/lib/acilDurumEkipService';
import { getEvrakUrl, friendlyEvrakError, evrakStatusLabel, type EvrakData } from '@/lib/evrakService';
import { uploadUretilenBelge, EVRAK_SOURCE_TYPE } from '@/lib/evrakSource';
import {
  TATBIKAT_TURLERI,
  TATBIKAT_DURUM,
  TATBIKAT_DURUM_LABEL,
  KATILIM_DURUM,
  EKSIKLIK_ONEM,
  fetchTatbikatlar,
  fetchTatbikatBelgeleri,
  fetchTatbikatTurId,
  kaydetTatbikat,
  silTatbikat,
  generateTatbikatRaporu,
  indirTatbikatRaporu,
  bosTatbikat,
  bosKatilimci,
  bosEksiklik,
  friendlyTatbikatError,
  type Tatbikat,
  type TatbikatKatilimci,
  type TatbikatEksiklik,
} from '@/lib/acilDurumTatbikatService';

interface Props {
  firmaId: string;
  role: 'uzman' | 'firma';
  onClose: () => void;
  onChanged?: () => void;
}

function tarihGoster(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

/**
 * ACİL DURUM TATBİKATI (referans görsel 2).
 *
 * İki görünüm: "liste" (firmanın tatbikatları + Yeni Tatbikat) ve "editor" (3 kolonlu
 * düzenleme ekranı). Tatbikat verisi mevcut `acil_durum_tatbikatlari` tablosunda saklanır;
 * rapor mevcut `acil-durum-tatbikat-rapor` edge function'ı ile üretilir. Belgeler mevcut
 * merkezi `evraklar` altyapısına yazılır. Yalnızca uzman düzenleyebilir (RLS).
 */
export default function AcilDurumTatbikatModal({ firmaId, role, onClose, onChanged }: Props) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();

  const yonetimVar = role === 'uzman';

  const [view, setView] = useState<'liste' | 'editor'>('liste');
  const [tatbikatlar, setTatbikatlar] = useState<Tatbikat[]>([]);
  const [belgeler, setBelgeler] = useState<EvrakData[]>([]);
  const [ekipMap, setEkipMap] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [form, setForm] = useState<Tatbikat>(() => bosTatbikat(firmaId));
  const [busy, setBusy] = useState<string | null>(null);
  const belgeRef = useRef('');

  const yukle = useCallback(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      fetchTatbikatlar(firmaId),
      fetchTatbikatBelgeleri(firmaId).catch(() => [] as EvrakData[]),
      fetchAcilDurumAtamalari(firmaId).catch(() => []),
    ])
      .then(([ts, bel, atamalar]) => {
        setTatbikatlar(ts);
        setBelgeler(bel);
        const m: Record<string, string> = {};
        for (const a of atamalar) {
          if (a.isActive && a.personelActive) m[a.personelId] = SISTEM_EKIP_ADI[a.requirementCode] ?? a.requirementCode;
        }
        setEkipMap(m);
      })
      .catch((e) => setError(friendlyTatbikatError(e)))
      .finally(() => setLoading(false));
  }, [firmaId]);

  useEffect(() => { yukle(); }, [yukle]);

  const refresh = useCallback(() => { yukle(); onChanged?.(); }, [yukle, onChanged]);

  const yeniTatbikat = useCallback(() => {
    setForm(bosTatbikat(firmaId));
    setView('editor');
  }, [firmaId]);

  const duzenle = useCallback((t: Tatbikat) => {
    setForm(t);
    setView('editor');
  }, []);

  const update = useCallback((patch: Partial<Tatbikat>) => {
    setForm((f) => ({ ...f, ...patch }));
  }, []);
  const updateIcerik = useCallback((patch: Partial<Tatbikat['icerik']>) => {
    setForm((f) => ({ ...f, icerik: { ...f.icerik, ...patch } }));
  }, []);

  // ── Katılımcılar ──
  const katilimciEkle = useCallback((p: AcilDurumPersonel) => {
    setForm((f) => ({
      ...f,
      icerik: {
        ...f.icerik,
        katilimcilar: [
          ...f.icerik.katilimcilar,
          { ...bosKatilimci(), personelId: p.id, adSoyad: `${p.ad} ${p.soyad}`.trim(), sicil: p.sicilNo, gorev: p.gorev, ekip: ekipMap[p.id] ?? '' },
        ],
      },
    }));
  }, [ekipMap]);

  const katilimciGuncelle = useCallback((id: string, patch: Partial<TatbikatKatilimci>) => {
    setForm((f) => ({ ...f, icerik: { ...f.icerik, katilimcilar: f.icerik.katilimcilar.map((k) => (k.id === id ? { ...k, ...patch } : k)) } }));
  }, []);
  const katilimciSil = useCallback((id: string) => {
    setForm((f) => ({ ...f, icerik: { ...f.icerik, katilimcilar: f.icerik.katilimcilar.filter((k) => k.id !== id) } }));
  }, []);

  // ── Eksiklikler / aksiyonlar ──
  const eksiklikEkle = useCallback(() => {
    setForm((f) => ({ ...f, icerik: { ...f.icerik, eksiklikler: [...f.icerik.eksiklikler, bosEksiklik()] } }));
  }, []);
  const eksiklikGuncelle = useCallback((id: string, patch: Partial<TatbikatEksiklik>) => {
    setForm((f) => ({ ...f, icerik: { ...f.icerik, eksiklikler: f.icerik.eksiklikler.map((e) => (e.id === id ? { ...e, ...patch } : e)) } }));
  }, []);
  const eksiklikSil = useCallback((id: string) => {
    setForm((f) => ({ ...f, icerik: { ...f.icerik, eksiklikler: f.icerik.eksiklikler.filter((e) => e.id !== id) } }));
  }, []);

  // ── Kaydet / Rapor ──
  const kaydet = useCallback(async (raporUret: boolean): Promise<void> => {
    if (!form.ad.trim()) {
      addToast({ title: 'Tatbikat adı gerekli', message: 'Kaydetmek için tatbikat adı zorunludur.', type: 'warning' });
      return;
    }
    setBusy(raporUret ? 'rapor' : 'kaydet');
    try {
      const durum = raporUret ? 'tamamlandi' : form.durum;
      const id = await kaydetTatbikat({
        firmaId,
        id: form.id || null,
        ad: form.ad,
        senaryo: form.senaryo,
        tur: form.tur,
        durum,
        tarih: form.tarih,
        baslangic: form.baslangic,
        bitis: form.bitis,
        yer: form.yer,
        sorumluAd: form.sorumluAd,
        sorumluGorev: form.sorumluGorev,
        aciklama: form.aciklama,
        icerik: form.icerik,
      });
      if (raporUret) {
        const kayit: Tatbikat = { ...form, id, durum };
        const r = await generateTatbikatRaporu({ tatbikat: kayit });
        // Üretilen rapor merkezi Evrak Merkezi'ne bağlanır (mevcut altyapı).
        let kaydedildi = false;
        try {
          const turId = await fetchTatbikatTurId();
          await uploadUretilenBelge({
            firmaId,
            documentTypeId: turId,
            title: `${kayit.ad || 'Tatbikat'} — Tatbikat Raporu`,
            description: 'Acil durum tatbikatı kurumsal raporu (üretilen belge).',
            sourceType: EVRAK_SOURCE_TYPE.ACIL_TATBIKAT,
            sourceId: id,
            blob: r.blob,
            fileName: r.fileName,
            revizeEt: true,
          });
          kaydedildi = true;
        } catch (upErr) {
          addToast({ title: 'Rapor oluşturuldu, Evraklar\'a kaydedilemedi', message: friendlyEvrakError(upErr), type: 'warning' });
        }
        indirTatbikatRaporu(r);
        if (kaydedildi) {
          addToast({ title: 'Rapor oluşturuldu ve Evraklar\'a kaydedildi', message: `${r.fileName} indirildi.`, type: 'success' });
        }
      } else {
        addToast({ title: 'Kaydedildi', message: 'Tatbikat bilgileri kaydedildi.', type: 'success' });
      }
      refresh();
      if (!form.id) setView('liste');
    } catch (e) {
      addToast({ title: 'Kaydedilemedi', message: friendlyTatbikatError(e), type: 'error' });
    } finally {
      setBusy(null);
    }
  }, [form, firmaId, addToast, refresh]);

  const silOnay = useCallback(() => {
    if (!form.id) return;
    confirm({
      title: 'Tatbikatı Sil',
      message: `"${form.ad}" kaydı kalıcı olarak silinecek. Bu işlem geri alınamaz.`,
      variant: 'danger',
      confirmText: 'Evet, Sil',
      cancelText: 'Vazgeç',
      onConfirm: async () => {
        try {
          await silTatbikat(form.id);
          addToast({ title: 'Silindi', message: 'Tatbikat kaydı silindi.', type: 'success' });
          setView('liste');
          refresh();
        } catch (e) {
          addToast({ title: 'Silinemedi', message: friendlyTatbikatError(e), type: 'error' });
        }
      },
    });
  }, [form, confirm, addToast, refresh]);

  const katilimciSecAc = useCallback(() => {
    const id = openModal({
      title: 'Katılımcı Ekle',
      description: 'Firma personel havuzundan seçin.',
      width: 560,
      minWidth: 420,
      minHeight: 460,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <KatilimciSecici
          firmaId={firmaId}
          onSelect={(p) => { katilimciEkle(p); closeModal(id); }}
          onClose={() => closeModal(id)}
        />
      ),
    });
  }, [openModal, closeModal, firmaId, katilimciEkle]);

  const belgeYukle = useCallback((previous?: EvrakData) => {
    const id = openModal({
      title: previous ? 'Yeni Sürüm Yükle' : 'Tatbikat Belgesi Yükle',
      description: previous ? previous.title : 'Firma Tatbikat kategorisine belge ekleyin.',
      width: 720,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EvrakUploadModal
          role={role}
          initialFirmaId={firmaId}
          lockOwnerType="firma"
          allowedCodes={['ACIL_DURUM_TATBIKATI']}
          previousEvrak={previous}
          onClose={() => closeModal(id)}
          onUploaded={() => { refresh(); }}
        />
      ),
    });
  }, [openModal, closeModal, role, firmaId, refresh]);

  const belgeAcUrl = useCallback(async (b: EvrakData) => {
    try {
      const url = await getEvrakUrl(b.id);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
      addToast({ title: 'Dosya açılamadı', message: friendlyEvrakError(e), type: 'error' });
    }
  }, [addToast]);

  const katilimciColumns: TableColumn<TatbikatKatilimci>[] = useMemo(() => [
    { key: 'adSoyad', header: 'Ad Soyad', render: (k) => <span className="text-sm font-medium text-foreground-900 truncate">{k.adSoyad}</span> },
    { key: 'ekip', header: 'Ekip / Görev', render: (k) => <span className="text-xs text-foreground-600">{k.ekip || k.gorev || '—'}</span> },
    {
      key: 'katilim', header: 'Katılım', width: '120px',
      render: (k) => (
        <Select
          size="sm"
          options={KATILIM_DURUM.map((v) => ({ value: v, label: v }))}
          value={k.katilim}
          onChange={(e) => katilimciGuncelle(k.id, { katilim: e.target.value })}
        />
      ),
    },
    {
      key: 'islem', header: '', width: '44px',
      render: (k) => (
        <button type="button" onClick={() => katilimciSil(k.id)} className="w-7 h-7 rounded-md flex items-center justify-center text-danger-500 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer" title="Çıkar" aria-label="Çıkar">
          <i className="ri-close-line" />
        </button>
      ),
    },
  ], [katilimciGuncelle, katilimciSil]);

  if (loading) return <div className="flex justify-center py-16"><Loading size="lg" text="Tatbikatlar yükleniyor..." /></div>;
  if (error) return <ErrorState message={error} onRetry={yukle} />;

  // ── LİSTE GÖRÜNÜMÜ ──
  if (view === 'liste') {
    return (
      <div className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-semibold text-foreground-950">Acil Durum Tatbikatları</h3>
            <p className="text-xs text-foreground-500 mt-0.5">Tatbikat planlayın, katılımcı ve sonuçları kaydedip kurumsal rapor oluşturun.</p>
          </div>
          {yonetimVar && (
            <Button variant="primary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-add-line" />} onClick={yeniTatbikat}>
              Yeni Tatbikat
            </Button>
          )}
        </div>

        {tatbikatlar.length === 0 ? (
          <EmptyState icon="ri-alarm-warning-line" title="Henüz tatbikat yok" description="İlk tatbikatı oluşturarak başlayın." />
        ) : (
          <ul className="space-y-1.5 max-h-[460px] overflow-y-auto pr-0.5">
            {tatbikatlar.map((t) => (
              <li key={t.id}>
                <button type="button" onClick={() => duzenle(t)} className="w-full flex items-center gap-3 p-3 rounded-lg border border-background-200/70 dark:border-background-400/25 text-left hover:bg-background-100 dark:hover:bg-background-200/50 cursor-pointer">
                  <span className="w-9 h-9 rounded-md bg-danger-50 dark:bg-danger-500/15 text-danger-600 dark:text-danger-300 flex items-center justify-center flex-shrink-0">
                    <i className="ri-alarm-warning-line" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-medium text-foreground-900 truncate">{t.ad}</span>
                    <span className="block text-[11px] text-foreground-500 truncate">{t.tur} · {tarihGoster(t.tarih)} · {t.icerik.katilimcilar.length} katılımcı</span>
                  </span>
                  <Badge variant={t.durum === 'tamamlandi' ? 'success' : t.durum === 'iptal' ? 'danger' : 'info'}>
                    {TATBIKAT_DURUM_LABEL[t.durum] ?? t.durum}
                  </Badge>
                </button>
              </li>
            ))}
          </ul>
        )}

        <div className="flex items-center justify-end gap-2 pt-2 border-t isg-divider">
          <Button variant="ghost" className="whitespace-nowrap" onClick={onClose}>Kapat</Button>
        </div>
      </div>
    );
  }

  // ── EDİTÖR GÖRÜNÜMÜ ──
  return (
    <div className="flex flex-col gap-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <button type="button" onClick={() => setView('liste')} className="inline-flex items-center gap-1 text-xs text-foreground-600 hover:text-foreground-900 cursor-pointer">
          <i className="ri-arrow-left-line" /> Tatbikat listesi
        </button>
        <Badge variant={form.durum === 'tamamlandi' ? 'success' : form.durum === 'iptal' ? 'danger' : 'info'}>
          {TATBIKAT_DURUM_LABEL[form.durum] ?? form.durum}
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,300px)_minmax(0,1fr)_minmax(0,300px)] gap-3">
        {/* SOL — Tatbikat Bilgileri */}
        <div className="space-y-3">
          <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide">Tatbikat Bilgileri</p>
          {!yonetimVar && (
            <p className="text-[11px] text-foreground-500 flex items-center gap-1"><i className="ri-lock-line" /> Yalnızca uzman düzenleyebilir.</p>
          )}
          <fieldset disabled={!yonetimVar} className="space-y-2.5 disabled:opacity-70">
            <Select label="Tatbikat Türü" options={TATBIKAT_TURLERI.map((v) => ({ value: v, label: v }))} value={form.tur} onChange={(e) => update({ tur: e.target.value })} searchable />
            <Input label="Tatbikat Adı" value={form.ad} onChange={(e) => update({ ad: e.target.value })} placeholder="Örn: 2026 Yangın Tahliye Tatbikatı" />
            <div className="grid grid-cols-2 gap-2">
              <DatePicker label="Tarih" value={form.tarih ?? ''} onChange={(e) => update({ tarih: e.target.value })} />
              <Input label="Başlangıç" value={form.baslangic} onChange={(e) => update({ baslangic: e.target.value })} placeholder="10:00" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Input label="Bitiş" value={form.bitis} onChange={(e) => update({ bitis: e.target.value })} placeholder="10:25" />
              <Input label="Yer" value={form.yer} onChange={(e) => update({ yer: e.target.value })} placeholder="Üretim alanı" />
            </div>
            <Input label="Sorumlu Ad Soyad" value={form.sorumluAd} onChange={(e) => update({ sorumluAd: e.target.value })} />
            <Input label="Sorumlu Görev" value={form.sorumluGorev} onChange={(e) => update({ sorumluGorev: e.target.value })} placeholder="İş Güvenliği Uzmanı" />
            <Textarea label="Senaryo / Açıklama" value={form.senaryo} onChange={(e) => update({ senaryo: e.target.value })} maxLength={500} placeholder="Tatbikat senaryosu..." />
            <Select label="Durum" options={TATBIKAT_DURUM} value={form.durum} onChange={(e) => update({ durum: e.target.value })} />
          </fieldset>
        </div>

        {/* ORTA — Katılımcılar + Sonuçlar */}
        <div className="min-w-0 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide">Katılımcılar ({form.icerik.katilimcilar.length})</p>
            {yonetimVar && (
              <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-user-add-line" />} onClick={katilimciSecAc}>
                Katılımcı Ekle
              </Button>
            )}
          </div>
          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 overflow-hidden p-1">
            <Table
              data={form.icerik.katilimcilar}
              columns={katilimciColumns}
              keyExtractor={(k) => k.id}
              emptyState={<p className="text-sm text-foreground-500 text-center py-6">Henüz katılımcı eklenmemiş.</p>}
            />
          </div>

          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2.5">
            <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide">Tatbikat Sonuçları</p>
            <fieldset disabled={!yonetimVar} className="space-y-2.5 disabled:opacity-70">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <Select label="Genel Değerlendirme" options={['Başarılı', 'Kısmen Başarılı', 'Başarısız'].map((v) => ({ value: v, label: v }))} value={form.icerik.genelDegerlendirme} onChange={(e) => updateIcerik({ genelDegerlendirme: e.target.value })} placeholder="Seçin" />
                <Input label="Süre (dk)" value={form.icerik.sureDk} onChange={(e) => updateIcerik({ sureDk: e.target.value })} placeholder="25" />
              </div>
              <Textarea label="Güçlü Yönler" value={form.icerik.gucluYonler} onChange={(e) => updateIcerik({ gucluYonler: e.target.value })} maxLength={500} />
              <Textarea label="Tespit Edilen Eksiklikler" value={form.icerik.aksiyonlar} onChange={(e) => updateIcerik({ aksiyonlar: e.target.value })} maxLength={500} />
            </fieldset>

            {/* Eksiklik / aksiyon listesi */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide">Aksiyonlar / Eksiklikler</span>
                {yonetimVar && (
                  <button type="button" onClick={eksiklikEkle} className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary-600 hover:text-primary-700 cursor-pointer">
                    <i className="ri-add-line" /> Ekle
                  </button>
                )}
              </div>
              {form.icerik.eksiklikler.length === 0 ? (
                <p className="text-xs text-foreground-400 py-2">Kayıt yok.</p>
              ) : (
                form.icerik.eksiklikler.map((e) => (
                  <div key={e.id} className="flex flex-wrap items-end gap-2 p-2 rounded-md border border-background-200/70 dark:border-background-400/25">
                    <div className="flex-1 min-w-[140px]">
                      <Input label="Eksiklik" value={e.baslik} onChange={(ev) => eksiklikGuncelle(e.id, { baslik: ev.target.value })} />
                    </div>
                    <div className="w-28">
                      <Select size="sm" label="Önem" options={EKSIKLIK_ONEM.map((v) => ({ value: v, label: v }))} value={e.onem} onChange={(ev) => eksiklikGuncelle(e.id, { onem: ev.target.value })} />
                    </div>
                    <div className="w-32">
                      <Input label="Sorumlu" value={e.sorumlu} onChange={(ev) => eksiklikGuncelle(e.id, { sorumlu: ev.target.value })} />
                    </div>
                    <div className="w-36">
                      <DatePicker label="Termin" value={e.termin} onChange={(ev) => eksiklikGuncelle(e.id, { termin: ev.target.value })} />
                    </div>
                    <button type="button" onClick={() => eksiklikSil(e.id)} className="w-8 h-8 mb-0.5 rounded-md flex items-center justify-center text-danger-500 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer" aria-label="Sil" title="Sil">
                      <i className="ri-delete-bin-line" />
                    </button>
                  </div>
                ))
              )}
            </div>

            {/* DÖF */}
            <button
              type="button"
              disabled={!yonetimVar}
              onClick={() => updateIcerik({ dofOlustur: !form.icerik.dofOlustur })}
              className="flex items-center gap-2 cursor-pointer disabled:opacity-70"
            >
              <span className={`w-9 h-5 rounded-full p-0.5 flex items-center transition-colors ${form.icerik.dofOlustur ? 'bg-primary-500 justify-end' : 'bg-background-300 dark:bg-background-400 justify-start'}`}>
                <span className="w-4 h-4 rounded-full bg-white" />
              </span>
              <span className="text-xs text-foreground-700">DÖF Oluştur (tespit edilen eksiklikler için düzeltici/önleyici faaliyet)</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <Input label="Toplanma Alanı" value={form.icerik.toplanmaAlani} onChange={(e) => updateIcerik({ toplanmaAlani: e.target.value })} placeholder="Ana Toplanma Alanı" />
            <Input label="Toplanma Süresi (dk)" value={form.icerik.toplanmaSuresi} onChange={(e) => updateIcerik({ toplanmaSuresi: e.target.value })} placeholder="6" />
          </div>
        </div>

        {/* SAĞ — Belgeler + Özet */}
        <div className="space-y-3">
          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide">Tatbikat Belgeleri</p>
              {yonetimVar && (
                <button type="button" onClick={() => belgeYukle()} className="inline-flex items-center gap-1 text-xs font-semibold text-primary-600 hover:text-primary-700 cursor-pointer whitespace-nowrap">
                  <i className="ri-upload-2-line" /> Belge Yükle
                </button>
              )}
            </div>
            {belgeler.length === 0 ? (
              <p className="text-xs text-foreground-400 text-center py-4">Henüz belge yok.</p>
            ) : (
              <ul className="space-y-1.5 max-h-[200px] overflow-y-auto pr-0.5">
                {belgeler.map((b) => (
                  <li key={b.id} className="flex items-center gap-2 p-2 rounded-md border border-background-200/70 dark:border-background-400/25">
                    <i className="ri-file-text-line text-foreground-400 flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground-800 truncate">{b.title}</p>
                      <p className="text-[10px] text-foreground-500">{evrakStatusLabel(b.status)} · {tarihGoster(b.documentDate ?? b.createdAt)}</p>
                    </div>
                    <button type="button" onClick={() => void belgeAcUrl(b)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer" title="Görüntüle / İndir" aria-label="Görüntüle">
                      <i className="ri-eye-line text-xs" />
                    </button>
                    {yonetimVar && (
                      <button type="button" onClick={() => belgeYukle(b)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer" title="Yeni sürüm yükle" aria-label="Yeni sürüm">
                        <i className="ri-refresh-line text-xs" />
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Özet önizleme */}
          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
            <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide mb-2">Rapor Önizleme</p>
            <div className="rounded-md border border-background-200/70 dark:border-background-400/25 overflow-hidden">
              <div className="bg-danger-50 dark:bg-danger-500/10 px-2.5 py-2 border-b border-background-200/70 dark:border-background-400/25">
                <p className="text-[11px] font-bold text-foreground-900 text-center">ACİL DURUM TATBİKAT RAPORU</p>
                <p className="text-[9px] text-foreground-500 text-center">{tarihGoster(form.tarih)}</p>
              </div>
              <dl className="text-[10px] divide-y divide-background-200/60 dark:divide-background-400/20">
                {[
                  ['Tatbikat Türü', form.tur],
                  ['Tatbikat Adı', form.ad || '—'],
                  ['Sorumlu', form.sorumluAd || '—'],
                  ['Süre', form.icerik.sureDk ? `${form.icerik.sureDk} dk` : '—'],
                  ['Katılımcı', String(form.icerik.katilimcilar.length)],
                  ['Genel Değerlendirme', form.icerik.genelDegerlendirme || '—'],
                ].map(([k, v]) => (
                  <div key={k} className="flex gap-2 px-2 py-1">
                    <dt className="text-foreground-500 w-24 flex-shrink-0">{k}</dt>
                    <dd className="text-foreground-800 truncate">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>
      </div>

      {/* Alt bar */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t isg-divider">
        <div>
          {yonetimVar && form.id && (
            <Button variant="ghost" size="sm" className="whitespace-nowrap text-danger-600" leftIcon={<i className="ri-delete-bin-line" />} onClick={silOnay}>
              Kaydı Sil
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="ghost" className="whitespace-nowrap" onClick={onClose}>İptal</Button>
          {yonetimVar && (
            <>
              <Button variant="secondary" className="whitespace-nowrap" isLoading={busy === 'kaydet'} onClick={() => void kaydet(false)}>Kaydet</Button>
              <Button variant="primary" className="whitespace-nowrap" leftIcon={<i className="ri-file-word-2-line" />} isLoading={busy === 'rapor'} onClick={() => void kaydet(true)}>Kaydet ve Belgeyi Oluştur</Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

/** Tatbikat katılımcısı seçici (firma personel havuzu, arama destekli). */
function KatilimciSecici({
  firmaId,
  onSelect,
  onClose,
}: {
  firmaId: string;
  onSelect: (p: AcilDurumPersonel) => void;
  onClose: () => void;
}) {
  const [search, setSearch] = useState('');
  const [liste, setListe] = useState<AcilDurumPersonel[]>([]);
  const [loading, setLoading] = useState(true);
  const [hata, setHata] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setHata(null);
    ekipPersonelHavuzu(firmaId, search)
      .then((p) => { if (alive) setListe(p); })
      .catch((e) => { if (alive) setHata(friendlyEkipError(e)); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [firmaId, search]);

  return (
    <div className="flex flex-col gap-3">
      <Search placeholder="Ad, soyad veya görev ile ara..." value={search} onSearch={setSearch} size="sm" debounceMs={350} />
      <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 overflow-hidden">
        {loading ? (
          <div className="flex justify-center py-10"><Loading size="md" text="Aranıyor..." /></div>
        ) : hata ? (
          <ErrorState message={hata} onRetry={() => setSearch((s) => s)} />
        ) : liste.length === 0 ? (
          <EmptyState icon="ri-user-search-line" title="Personel yok" description="Kriterlere uygun aktif personel bulunamadı." />
        ) : (
          <ul className="divide-y divide-background-200/70 dark:divide-background-400/25 max-h-[320px] overflow-y-auto">
            {liste.map((p) => (
              <li key={p.id}>
                <button type="button" onClick={() => onSelect(p)} className="w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-background-100 dark:hover:bg-background-200/50 cursor-pointer">
                  <span className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 text-[10px] font-semibold flex items-center justify-center flex-shrink-0">
                    {`${p.ad ?? ''} ${p.soyad ?? ''}`.trim().slice(0, 2).toUpperCase()}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-medium text-foreground-900 truncate">{`${p.ad ?? ''} ${p.soyad ?? ''}`.trim() || '—'}</span>
                    <span className="block text-[11px] text-foreground-500 truncate">{p.gorev} · {p.sicilNo}</span>
                  </span>
                  <i className="ri-add-line text-primary-500" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div className="flex justify-end">
        <Button variant="ghost" size="sm" className="whitespace-nowrap" onClick={onClose}>Kapat</Button>
      </div>
    </div>
  );
}