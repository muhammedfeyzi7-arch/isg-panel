/**
 * İSGDenetim Sihirbazı — ANA EKRAN (modül seçimi).
 *
 * Referans: "İSGDenetim Sihirbazı" modalı → 2×2 EŞİT kart ızgarası.
 * AKTİF ve tıklanabilir modüller:
 *   - **Risk Değerlendirmesi** (5x5 / Fine-Kinney / HAZOP)
 *   - **Yıllık Çalışma Planı** (AI destekli, yerel çalışan)
 *   - **Yıllık Eğitim Planı** (AI destekli, yerel çalışan)
 *   - **Acil Durum Eylem Planı** (AI destekli, ekip + senaryo + kroki, yerel çalışan)
 *
 * PERFORMANS: Bu ekranda BÜYÜK GÖRSEL KULLANILMAZ. Kartların görsel ihtiyacı
 * yalnızca mevcut icon sisteminden (Remix Icon) karşılanır. Tüm renkler merkezi
 * tema tokenlarından gelir.
 */

export type RiskModulKey = 'risk' | 'calisma' | 'egitim' | 'acil';

interface RiskModulSecimProps {
  /** Seçilen modülü üst bileşene bildirir. */
  onSelect: (modul: RiskModulKey) => void;
}

export default function RiskModulSecim({ onSelect }: RiskModulSecimProps) {
  return (
    <div className="grid grid-cols-1 gap-3 sm:auto-rows-fr sm:grid-cols-2 md:gap-4">
      {/* ── AKTİF MODÜL — Risk Değerlendirmesi ── */}
      <button
        type="button"
        onClick={() => onSelect('risk')}
        className="group relative flex min-h-[230px] cursor-pointer flex-col rounded-lg border border-danger-500/45 bg-background-100 p-5 text-left transition-colors hover:border-danger-500/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-danger-500/60 dark:border-danger-500/50 dark:bg-background-200/50 dark:hover:border-danger-500"
      >
        <div className="flex items-start justify-between gap-3">
          <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg bg-danger-500 text-inverse">
            <i className="ri-shield-cross-line text-xl" />
          </span>
          <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full border border-danger-500/40 text-danger-600 transition-colors group-hover:bg-danger-500 group-hover:text-inverse dark:text-danger-300">
            <i className="ri-arrow-right-line" />
          </span>
        </div>

        <h2 className="mt-3 text-lg font-bold text-foreground-800">Risk Değerlendirmesi</h2>
        <p className="mt-1 text-sm leading-relaxed text-foreground-600">
          5x5 Matris, Fine-Kinney ve HAZOP yöntemleriyle adım adım risk değerlendirmesi oluşturun ve raporlayın.
        </p>

        <div className="mt-auto flex flex-wrap gap-2 pt-4">
          {['5x5 Matris', 'Fine-Kinney', 'HAZOP', 'Word / PDF / Excel'].map((chip) => (
            <span key={chip} className="isg-badge isg-badge-sm border border-danger-500/30 bg-danger-500/10 text-danger-700 dark:text-danger-300">
              {chip}
            </span>
          ))}
        </div>
      </button>

      {/* ── AKTİF MODÜL — Yıllık Çalışma Planı ── */}
      <button
        type="button"
        onClick={() => onSelect('calisma')}
        className="group relative flex min-h-[230px] cursor-pointer flex-col rounded-lg border border-primary-500/45 bg-background-100 p-5 text-left transition-colors hover:border-primary-500/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-500/60 dark:border-primary-500/50 dark:bg-background-200/50 dark:hover:border-primary-500"
      >
        <div className="flex items-start justify-between gap-3">
          <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg bg-primary-500 text-inverse">
            <i className="ri-calendar-2-line text-xl" />
          </span>
          <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full border border-primary-500/40 text-primary-600 transition-colors group-hover:bg-primary-500 group-hover:text-inverse dark:text-primary-300">
            <i className="ri-arrow-right-line" />
          </span>
        </div>

        <h2 className="mt-3 text-lg font-bold text-foreground-800">Yıllık Çalışma Planı</h2>
        <p className="mt-1 text-sm leading-relaxed text-foreground-600">
          Bir sonraki yılın İSG faaliyetlerini 12 aylık matrise planlayın; AI önerileri alın ve raporlayın.
        </p>

        <div className="mt-auto flex flex-wrap gap-2 pt-4">
          {['12 Aylık Matris', 'AI Önerileri', 'Faaliyet Şablonları', 'Word / PDF / Excel'].map((chip) => (
            <span key={chip} className="isg-badge isg-badge-sm border border-primary-500/30 bg-primary-500/10 text-primary-700 dark:text-primary-300">
              {chip}
            </span>
          ))}
        </div>
      </button>

      {/* ── AKTİF MODÜL — Yıllık Eğitim Planı ── */}
      <button
        type="button"
        onClick={() => onSelect('egitim')}
        className="group relative flex min-h-[230px] cursor-pointer flex-col rounded-lg border border-secondary-500/45 bg-background-100 p-5 text-left transition-colors hover:border-secondary-500/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-secondary-500/60 dark:border-secondary-500/50 dark:bg-background-200/50 dark:hover:border-secondary-500"
      >
        <div className="flex items-start justify-between gap-3">
          <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg bg-secondary-500 text-inverse">
            <i className="ri-graduation-cap-line text-xl" />
          </span>
          <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full border border-secondary-500/40 text-secondary-600 transition-colors group-hover:bg-secondary-500 group-hover:text-inverse dark:text-secondary-300">
            <i className="ri-arrow-right-line" />
          </span>
        </div>

        <h2 className="mt-3 text-lg font-bold text-foreground-800">Yıllık Eğitim Planı</h2>
        <p className="mt-1 text-sm leading-relaxed text-foreground-600">
          Bir sonraki yılın İSG eğitimlerini 12 aylık matrise planlayın; AI önerileri alın ve raporlayın.
        </p>

        <div className="mt-auto flex flex-wrap gap-2 pt-4">
          {['12 Aylık Matris', 'AI Eğitim Önerileri', 'Eğitim Şablonları', 'Word / PDF / Excel'].map((chip) => (
            <span key={chip} className="isg-badge isg-badge-sm border border-secondary-500/30 bg-secondary-500/10 text-secondary-700 dark:text-secondary-300">
              {chip}
            </span>
          ))}
        </div>
      </button>

      {/* ── AKTİF MODÜL — Acil Durum Eylem Planı ── */}
      <button
        type="button"
        onClick={() => onSelect('acil')}
        className="group relative flex min-h-[230px] cursor-pointer flex-col rounded-lg border border-accent-500/45 bg-background-100 p-5 text-left transition-colors hover:border-accent-500/80 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-500/60 dark:border-accent-500/50 dark:bg-background-200/50 dark:hover:border-accent-500"
      >
        <div className="flex items-start justify-between gap-3">
          <span className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg bg-accent-500 text-inverse">
            <i className="ri-alarm-warning-line text-xl" />
          </span>
          <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full border border-accent-500/40 text-accent-600 transition-colors group-hover:bg-accent-500 group-hover:text-inverse dark:text-accent-300">
            <i className="ri-arrow-right-line" />
          </span>
        </div>

        <h2 className="mt-3 text-lg font-bold text-foreground-800">Acil Durum Eylem Planı</h2>
        <p className="mt-1 text-sm leading-relaxed text-foreground-600">
          Acil durum ekiplerini ve senaryoları oluşturun, tahliye krokinizi çizin ve AI önerileriyle planınızı hazırlayın.
        </p>

        <div className="mt-auto flex flex-wrap gap-2 pt-4">
          {['Acil Durum Ekipleri', 'AI Senaryo Önerileri', 'Tahliye Krokisi', 'Word / PDF / Excel'].map((chip) => (
            <span key={chip} className="isg-badge isg-badge-sm border border-accent-500/30 bg-accent-500/10 text-accent-700 dark:text-accent-300">
              {chip}
            </span>
          ))}
        </div>
      </button>
    </div>
  );
}