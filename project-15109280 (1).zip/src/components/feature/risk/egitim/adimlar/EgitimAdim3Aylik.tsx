import { useMemo } from 'react';
import {
  AY_ADLARI, AY_KISA, ONCELIK_META, kategoriIkon, turMeta,
  type EgitimKaydi,
} from '@/components/feature/risk/egitimTypes';
import { RwButton, RwCard, RwSectionTitle } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// YILLIK EĞİTİM PLANI · ADIM 3 — AYLIK PLANLAMA
// 12 aylık matris (Ocak…Aralık işaretlenebilir hücreler). Sağda Planlama Özeti
// (ay bazında planlanan eğitim sayısı) ve periyot dağıtım rehberi. Yatay kaydırma.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  egitimler: EgitimKaydi[];
  onGuncelle: (id: string, patch: Partial<EgitimKaydi>) => void;
  onTumunuTemizle: () => void;
  onOnerilenUygula: () => void;
  onEgitimDuzenle: () => void;
}

export default function EgitimAdim3Aylik({ egitimler, onGuncelle, onTumunuTemizle, onOnerilenUygula, onEgitimDuzenle }: Props) {
  const aylikSayim = useMemo(() => {
    const d = Array.from({ length: 12 }, () => 0);
    egitimler.forEach((e) => (e.aylar || []).forEach((v, i) => { if (v && i < 12) d[i] += 1; }));
    return d;
  }, [egitimler]);

  const toplamPlanlanan = aylikSayim.reduce((t, v) => t + v, 0);
  const planlanmisEgitim = egitimler.filter((e) => (e.aylar || []).some(Boolean)).length;

  const ayToggle = (e: EgitimKaydi, idx: number) => {
    const aylar = [...e.aylar];
    aylar[idx] = !aylar[idx];
    onGuncelle(e.id, { aylar });
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="3. Aylık Planlama"
        desc="Her eğitimin hangi aylarda verileceğini işaretleyin. İsterseniz periyoda göre otomatik dağıtın."
        right={(
          <div className="flex flex-shrink-0 items-center gap-2">
            <RwButton variant="ghost" size="sm" icon="ri-eraser-line" onClick={onTumunuTemizle}>Tamamını Temizle</RwButton>
            <RwButton variant="secondary" size="sm" icon="ri-magic-line" onClick={onOnerilenUygula}>Önerilen Planı Uygula</RwButton>
          </div>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_320px]">
        {/* SOL — matris */}
        <div className="flex min-h-0 flex-col rounded-lg border border-background-300/60 bg-background-100 dark:border-background-400/30 dark:bg-background-200/40">
          {egitimler.length === 0 ? (
            <div className="flex flex-1 flex-col items-center justify-center px-4 py-16 text-center">
              <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                <i className="ri-calendar-2-line text-2xl" />
              </span>
              <p className="mt-2 text-sm font-medium text-foreground-700">Planlanacak eğitim yok</p>
              <p className="mt-1 text-xs text-foreground-500">Önce "Eğitimler" adımından eğitim ekleyin.</p>
              <div className="mt-3"><RwButton variant="secondary" size="sm" icon="ri-arrow-left-line" onClick={onEgitimDuzenle}>Eğitimlere Dön</RwButton></div>
            </div>
          ) : (
            <div className="isg-scroll-pane min-h-0 flex-1 overflow-auto">
              <table className="w-full border-collapse" style={{ minWidth: 940 }}>
                <thead className="sticky top-0 z-10 bg-background-200 dark:bg-background-300/80">
                  <tr className="text-left text-[10px] font-semibold uppercase tracking-wide text-foreground-500">
                    <th className="sticky left-0 z-20 bg-background-200 px-2.5 py-2.5 whitespace-nowrap dark:bg-background-300">#</th>
                    <th className="px-2.5 py-2.5 whitespace-nowrap" style={{ minWidth: 240 }}>Eğitim</th>
                    <th className="px-2.5 py-2.5 whitespace-nowrap" style={{ minWidth: 110 }}>Tür</th>
                    <th className="px-2.5 py-2.5 whitespace-nowrap" style={{ minWidth: 70 }}>Süre</th>
                    <th className="px-2.5 py-2.5 whitespace-nowrap" style={{ minWidth: 90 }}>Periyot</th>
                    {AY_KISA.map((a, i) => (
                      <th key={a} className="px-1 py-2.5 text-center whitespace-nowrap" title={AY_ADLARI[i]}>{a}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {egitimler.map((e, ei) => {
                    const om = ONCELIK_META[e.oncelik] ?? ONCELIK_META.Orta;
                    const tm = turMeta(e.tur);
                    return (
                      <tr key={e.id} className="border-t border-background-300/20 align-middle dark:border-background-400/10">
                        <td className="sticky left-0 bg-background-100 px-2.5 py-2 text-xs text-foreground-500 dark:bg-background-200">{ei + 1}</td>
                        <td className="px-2.5 py-2">
                          <div className="flex items-center gap-2">
                            <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-primary-500/12 text-primary-600 dark:text-primary-300">
                              <i className={`${kategoriIkon(e.kategori)} text-xs`} />
                            </span>
                            <div className="min-w-0">
                              <p className="truncate text-xs font-medium text-foreground-900">{e.egitim || 'İsimsiz eğitim'}</p>
                              <p className="truncate text-[10px] text-foreground-400">{e.kategori}</p>
                            </div>
                            <span className={`ml-1 hidden flex-shrink-0 rounded px-1.5 py-0.5 text-[9px] font-semibold sm:inline ${om.soft}`}>{e.oncelik}</span>
                          </div>
                        </td>
                        <td className="px-2.5 py-2">
                          <span className={`inline-flex whitespace-nowrap rounded px-1.5 py-0.5 text-[10px] font-semibold ${tm.soft}`}>{e.tur}</span>
                        </td>
                        <td className="px-2.5 py-2 text-xs text-foreground-600">{e.sure ? `${e.sure} sa` : '—'}</td>
                        <td className="px-2.5 py-2 text-xs text-foreground-600">{e.periyot}</td>
                        {AY_ADLARI.map((ayAd, i) => (
                          <td key={ayAd} className="px-1 py-2 text-center">
                            <button
                              type="button"
                              onClick={() => ayToggle(e, i)}
                              aria-label={`${e.egitim} — ${ayAd}`}
                              aria-pressed={!!e.aylar[i]}
                              className={`mx-auto flex h-6 w-6 cursor-pointer items-center justify-center rounded-md border transition-colors ${
                                e.aylar[i]
                                  ? 'border-primary-500 bg-primary-500 text-inverse'
                                  : 'border-background-300/70 bg-background-50 hover:border-primary-400 dark:border-background-400/40 dark:bg-background-100/60'
                              }`}
                            >
                              {e.aylar[i] && <i className="ri-check-line text-[11px]" />}
                            </button>
                          </td>
                        ))}
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot className="sticky bottom-0 bg-background-200 dark:bg-background-300/80">
                  <tr className="text-[11px] font-semibold text-foreground-600">
                    <td className="sticky left-0 bg-background-200 px-2.5 py-2 dark:bg-background-300" colSpan={5}>Aylık Planlanan Eğitim Sayısı</td>
                    {aylikSayim.map((v, i) => (
                      <td key={AY_KISA[i]} className="px-1 py-2 text-center">
                        <span className={`inline-flex h-6 min-w-6 items-center justify-center rounded-md px-1 text-[11px] font-bold ${v > 0 ? 'bg-primary-500/15 text-primary-700 dark:text-primary-300' : 'text-foreground-300'}`}>{v}</span>
                      </td>
                    ))}
                  </tr>
                </tfoot>
              </table>
            </div>
          )}

          <div className="flex flex-shrink-0 flex-wrap items-center gap-4 border-t border-background-300/40 px-3 py-2 dark:border-background-400/25">
            <span className="flex items-center gap-1.5 text-[11px] text-foreground-500">
              <span className="flex h-4 w-4 items-center justify-center rounded border border-primary-500 bg-primary-500 text-inverse"><i className="ri-check-line text-[9px]" /></span> Planlandı
            </span>
            <span className="flex items-center gap-1.5 text-[11px] text-foreground-500">
              <span className="h-4 w-4 rounded border border-background-300/70 bg-background-50 dark:border-background-400/40 dark:bg-background-100/60" /> Boş
            </span>
            <span className="ml-auto text-[11px] text-foreground-500">Toplam planlanan ay girdisi: <strong className="text-foreground-800">{toplamPlanlanan}</strong></span>
          </div>
        </div>

        {/* SAĞ — Planlama özeti */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <RwCard title="Planlama Özeti" icon="ri-bar-chart-2-line" className="p-3">
            <div className="mb-2.5 grid grid-cols-2 gap-2">
              <div className="rounded-md border border-background-300/50 bg-background-50 p-2 dark:border-background-400/25 dark:bg-background-100/50">
                <p className="text-lg font-bold text-foreground-950">{egitimler.length}</p>
                <p className="text-[10px] text-foreground-500">Toplam Eğitim</p>
              </div>
              <div className="rounded-md border border-background-300/50 bg-background-50 p-2 dark:border-background-400/25 dark:bg-background-100/50">
                <p className="text-lg font-bold text-primary-600 dark:text-primary-300">{planlanmisEgitim}</p>
                <p className="text-[10px] text-foreground-500">Planlanmış Eğitim</p>
              </div>
            </div>
            <div className="overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
              <table className="w-full border-collapse">
                <thead className="bg-background-200 dark:bg-background-300/60">
                  <tr className="text-left text-[10px] font-semibold text-foreground-500">
                    <th className="px-2 py-1.5">Ay</th>
                    <th className="px-2 py-1.5 text-center">Planlanan</th>
                    <th className="px-2 py-1.5">Yoğunluk</th>
                  </tr>
                </thead>
                <tbody>
                  {AY_ADLARI.map((a, i) => {
                    const maxAy = Math.max(1, ...aylikSayim);
                    const oran = Math.round((aylikSayim[i] / maxAy) * 100);
                    return (
                      <tr key={a} className="border-t border-background-300/20 dark:border-background-400/10">
                        <td className="px-2 py-1.5 text-[11px] text-foreground-700">{a}</td>
                        <td className="px-2 py-1.5 text-center text-[11px] font-semibold text-foreground-800">{aylikSayim[i]}</td>
                        <td className="px-2 py-1.5">
                          <div className="h-1.5 w-full overflow-hidden rounded-full bg-background-200 dark:bg-background-300/60">
                            <div className="h-full rounded-full bg-primary-500" style={{ width: `${oran}%` }} />
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </RwCard>

          <RwCard title="Periyot Dağıtımı" icon="ri-information-line" className="p-3">
            <ul className="space-y-1.5">
              {[
                ['Haftalık / Aylık / Sürekli', 'Her ay'],
                ['2 Aylık', 'Oca, Mar, May, Tem, Eyl, Kas'],
                ['3 Aylık', 'Oca, Nis, Tem, Eki'],
                ['6 Aylık', 'Oca, Tem'],
                ['Yıllık', 'Ocak'],
                ['Tek Seferlik', 'Kullanıcı seçer'],
              ].map(([p, a]) => (
                <li key={p} className="flex items-start justify-between gap-2 text-[11px]">
                  <span className="font-medium text-foreground-700">{p}</span>
                  <span className="text-right text-foreground-500">{a}</span>
                </li>
              ))}
            </ul>
            <p className="mt-2 rounded-md border border-primary-300/40 bg-primary-50 px-2 py-1.5 text-[10px] leading-snug text-foreground-600 dark:border-primary-500/25 dark:bg-primary-500/10">
              "Önerilen Planı Uygula" her eğitimi periyoduna göre otomatik yerleştirir; istediğiniz hücreyi elle değiştirebilirsiniz.
            </p>
          </RwCard>
        </div>
      </div>
    </div>
  );
}