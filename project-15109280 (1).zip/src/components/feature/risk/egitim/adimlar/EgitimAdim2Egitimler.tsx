import { useMemo, useState } from 'react';
import {
  AY_KISA, EGITIM_KATEGORILERI, EGITIM_SABLONLARI, EGITIM_TURLERI, ONCELIKLER, ONCELIK_META, PERIYOTLAR,
  kategoriIkon, periyotAylari, aylariUygula, turMeta,
  type EgitimAiOneri, type EgitimKaydi, type EgitimSablon,
} from '@/components/feature/risk/egitimTypes';
import { RwButton, RwCard, RwInput, RwSectionTitle, RwSelect } from '@/components/feature/risk/sihirbaz/wizardUi';
import { matchesSearch } from '@/utils/turkishText';

// ─────────────────────────────────────────────────────────────────────────────
// YILLIK EĞİTİM PLANI · ADIM 2 — EĞİTİMLER
// Sol: eğitim listesi (kategori · eğitim konusu · açıklama · tür · hedef grup ·
// eğitici · süre · periyot · öncelik, satır içi düzenlenebilir) + "AI ile Öneri Al",
// "Şablondan Ekle", "+ Eğitim Ekle" aksiyonları.
// Sağ: AI Asistan öneri kartları + Eğitim Şablon Kütüphanesi + Örnek sorular.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  egitimler: EgitimKaydi[];
  aiOnerileri: EgitimAiOneri[];
  aiYukleniyor: boolean;
  onEkle: () => void;
  onGuncelle: (id: string, patch: Partial<EgitimKaydi>) => void;
  onSil: (id: string) => void;
  onAiYenile: () => void;
  onOneriEkle: (o: EgitimAiOneri) => void;
  onSablondanEkle: (s: EgitimSablon) => void;
}

const HEDEF_GRUPLAR = [
  'Tüm Çalışanlar',
  'Yeni Çalışanlar',
  'Üretim Personeli',
  'Bakım Personeli',
  'İdari Personel',
  'Depo / Lojistik Personeli',
  'Acil Durum Ekipleri',
  'Çalışan Temsilcileri',
  'Yöneticiler',
  'Forklift Operatörleri',
];

const ORNEK_SORULAR = [
  'Bu tehlike sınıfı için hangi eğitimler zorunludur?',
  'İşe giriş ve yenileme eğitimleri kaç saat olmalı?',
  'Sektörümüze özel hangi eğitimleri planlamalıyız?',
  'Yıllık eğitim takvimi nasıl dengeli oluşturulur?',
];

export default function EgitimAdim2Egitimler({
  egitimler, aiOnerileri, aiYukleniyor,
  onEkle, onGuncelle, onSil, onAiYenile, onOneriEkle, onSablondanEkle,
}: Props) {
  const [sablonArama, setSablonArama] = useState('');

  const sablonlar = useMemo(() => {
    const q = sablonArama.trim().toLocaleLowerCase('tr');
    if (!q) return EGITIM_SABLONLARI;
    return EGITIM_SABLONLARI.filter((s) => matchesSearch(`${s.kategori} ${s.egitim} ${s.aciklama}`, q));
  }, [sablonArama]);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="2. Eğitimler"
        desc="Planlanacak İSG eğitimlerini ekleyin. Tür, hedef grup, süre ve zaman bilgilerini belirleyin."
        right={(
          <div className="flex flex-shrink-0 items-center gap-2">
            <RwButton variant="outline" size="sm" icon={aiYukleniyor ? undefined : 'ri-sparkling-2-line'} disabled={aiYukleniyor} onClick={onAiYenile}>
              {aiYukleniyor ? 'Üretiliyor...' : 'AI ile Öneri Al'}
            </RwButton>
            <RwButton variant="secondary" size="sm" icon="ri-add-line" onClick={onEkle}>Eğitim Ekle</RwButton>
          </div>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_340px]">
        {/* SOL — Eğitim listesi */}
        <div className="isg-scroll-pane min-h-0 space-y-2.5 overflow-y-auto pr-1">
          {egitimler.length === 0 && (
            <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-background-300/70 bg-background-100/60 px-4 py-14 text-center dark:border-background-400/40 dark:bg-background-200/30">
              <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                <i className="ri-graduation-cap-line text-2xl" />
              </span>
              <p className="mt-2 text-sm font-medium text-foreground-700">Henüz eğitim eklenmemiş</p>
              <p className="mt-1 text-xs text-foreground-500">AI ile öneri alın, şablondan ekleyin veya kendiniz ekleyin.</p>
              <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                <RwButton variant="outline" size="sm" icon="ri-sparkling-2-line" disabled={aiYukleniyor} onClick={onAiYenile}>AI ile Öneri Al</RwButton>
                <RwButton variant="secondary" size="sm" icon="ri-add-line" onClick={onEkle}>Eğitim Ekle</RwButton>
              </div>
            </div>
          )}

          {egitimler.map((e, i) => {
            const om = ONCELIK_META[e.oncelik] ?? ONCELIK_META.Orta;
            const tm = turMeta(e.tur);
            return (
              <div key={e.id} className="rounded-lg border border-background-300/60 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
                <div className="flex items-center gap-2">
                  <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300">
                    <i className={`${kategoriIkon(e.kategori)} text-xs`} />
                  </span>
                  <span className="text-xs font-semibold text-foreground-400">#{i + 1}</span>
                  <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold ${tm.soft}`}>
                    <span className={`h-1.5 w-1.5 rounded-full ${tm.dot}`} /> {e.tur}
                  </span>
                  <span className="ml-auto flex items-center gap-2">
                    <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold ${om.soft}`}>
                      <span className={`h-1.5 w-1.5 rounded-full ${om.dot}`} /> {e.oncelik}
                    </span>
                    <button type="button" onClick={() => onSil(e.id)} className="flex h-7 w-7 cursor-pointer items-center justify-center rounded-md text-foreground-400 transition-colors hover:bg-danger-500/12 hover:text-danger-600" aria-label="Sil">
                      <i className="ri-delete-bin-line text-xs" />
                    </button>
                  </span>
                </div>

                <div className="mt-2.5 grid grid-cols-1 gap-2.5 md:grid-cols-2">
                  <RwSelect
                    label="Kategori" size="sm" searchable
                    options={EGITIM_KATEGORILERI.map((k) => ({ value: k, label: k }))}
                    value={e.kategori} onChange={(v) => onGuncelle(e.id, { kategori: v })}
                  />
                  <RwSelect
                    label="Eğitim Türü" size="sm"
                    options={EGITIM_TURLERI.map((t) => ({ value: t, label: t }))}
                    value={e.tur} onChange={(v) => onGuncelle(e.id, { tur: v })}
                  />
                  <div className="md:col-span-2">
                    <RwInput
                      label="Eğitim Konusu" size="sm" required
                      value={e.egitim} onChange={(ev) => onGuncelle(e.id, { egitim: ev.target.value })}
                      placeholder="Örn. Temel İSG Eğitimi (İşe Giriş)"
                      className={!e.egitim.trim() ? 'border-danger-400/70' : ''}
                    />
                  </div>
                  <div className="md:col-span-2">
                    <RwInput
                      label="Açıklama" size="sm"
                      value={e.aciklama} onChange={(ev) => onGuncelle(e.id, { aciklama: ev.target.value })}
                      placeholder="Eğitimin kapsamı ve içeriği"
                    />
                  </div>
                  <RwSelect
                    label="Hedef Grup" size="sm" creatable
                    options={HEDEF_GRUPLAR.map((g) => ({ value: g, label: g }))}
                    value={e.hedefGrup} onChange={(v) => onGuncelle(e.id, { hedefGrup: v })}
                    placeholder="Tüm Çalışanlar"
                  />
                  <RwInput
                    label="Eğitici / Sorumlu" size="sm"
                    value={e.egitici} onChange={(ev) => onGuncelle(e.id, { egitici: ev.target.value })}
                    placeholder="Örn. İş Güvenliği Uzmanı"
                  />
                  <RwInput
                    label="Süre (saat)" size="sm"
                    value={e.sure} onChange={(ev) => onGuncelle(e.id, { sure: ev.target.value })}
                    placeholder="Örn. 8"
                  />
                  <RwSelect
                    label="Periyot" size="sm"
                    options={PERIYOTLAR.map((p) => ({ value: p, label: p }))}
                    value={e.periyot}
                    onChange={(v) => onGuncelle(e.id, { periyot: v, aylar: aylariUygula(periyotAylari(v)) })}
                  />
                  <RwSelect
                    label="Öncelik" size="sm"
                    options={ONCELIKLER.map((o) => ({ value: o, label: o }))}
                    value={e.oncelik} onChange={(v) => onGuncelle(e.id, { oncelik: v })}
                  />
                </div>

                <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                  <span className="text-[10px] font-medium text-foreground-400">Planlanan aylar:</span>
                  {AY_KISA.map((a, idx) => (
                    <span key={a} className={`rounded px-1.5 py-0.5 text-[10px] font-semibold ${e.aylar[idx] ? 'bg-primary-500 text-inverse' : 'bg-background-200 text-foreground-400 dark:bg-background-300/50'}`}>{a}</span>
                  ))}
                </div>
              </div>
            );
          })}
          {egitimler.length > 0 && (
            <button type="button" onClick={onEkle} className="flex w-full cursor-pointer items-center justify-center gap-1.5 rounded-lg border border-dashed border-background-300/70 px-3 py-2.5 text-xs font-medium text-foreground-500 transition-colors hover:border-primary-400 hover:text-primary-600 dark:border-background-400/40">
              <i className="ri-add-line" /> Eğitim Ekle
            </button>
          )}
        </div>

        {/* SAĞ — AI Asistan + Şablonlar */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <RwCard className="p-0">
            <div className="flex items-center justify-between gap-2 border-b border-background-300/40 px-3 py-2.5 dark:border-background-400/25">
              <div className="flex items-center gap-1.5">
                <span className="flex h-6 w-6 items-center justify-center rounded-md bg-primary-500 text-inverse"><i className="ri-sparkling-2-line text-xs" /></span>
                <h3 className="text-xs font-semibold text-foreground-950">AI Asistan</h3>
              </div>
              <button type="button" disabled={aiYukleniyor} onClick={onAiYenile} className="cursor-pointer text-xs font-medium text-primary-600 hover:underline disabled:opacity-50 dark:text-primary-300">
                {aiYukleniyor ? 'Üretiliyor...' : 'Yenile'}
              </button>
            </div>
            <div className="max-h-[360px] overflow-y-auto p-2.5">
              {aiYukleniyor && (
                <div className="flex items-center justify-center gap-2 py-8 text-xs text-foreground-500">
                  <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" /> Öneriler üretiliyor...
                </div>
              )}
              {!aiYukleniyor && aiOnerileri.length === 0 && (
                <p className="px-1 py-6 text-center text-xs text-foreground-400">
                  İşyerinize uygun eğitim önerileri için "AI ile Öneri Al" butonuna basın.
                </p>
              )}
              <div className="space-y-2">
                {aiOnerileri.map((o) => {
                  const om = ONCELIK_META[o.oncelik] ?? ONCELIK_META.Orta;
                  return (
                    <div key={o.id} className="rounded-md border border-background-300/50 bg-background-50 p-2.5 dark:border-background-400/25 dark:bg-background-100/50">
                      <div className="flex items-center justify-between gap-2">
                        <span className="flex items-center gap-1.5 text-[11px] font-semibold text-primary-600 dark:text-primary-300">
                          <i className={kategoriIkon(o.kategori)} /> {o.kategori}
                        </span>
                        <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold ${om.soft}`}>{o.oncelik}</span>
                      </div>
                      <p className="mt-1 text-xs font-medium text-foreground-900">{o.egitim}</p>
                      {o.aciklama && <p className="mt-0.5 text-[11px] leading-snug text-foreground-500">{o.aciklama}</p>}
                      <div className="mt-1.5 flex items-center justify-between">
                        <span className="text-[10px] text-foreground-400">
                          <i className="ri-time-line mr-0.5" /> {o.sure || '—'} sa · <i className="ri-repeat-line mx-0.5" /> {o.periyot}
                        </span>
                        <button type="button" onClick={() => onOneriEkle(o)} className="cursor-pointer rounded-md bg-primary-500 px-2 py-1 text-[10px] font-semibold text-inverse transition-colors hover:bg-primary-600">
                          <i className="ri-add-line mr-0.5" /> Eğitime Ekle
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div className="border-t border-background-300/40 p-2.5 dark:border-background-400/25">
              <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-foreground-400">Örnek Sorular</p>
              <ul className="space-y-1">
                {ORNEK_SORULAR.map((s) => (
                  <li key={s} className="flex items-start gap-1.5 text-[11px] text-foreground-600">
                    <i className="ri-question-line mt-0.5 text-primary-400" /> {s}
                  </li>
                ))}
              </ul>
            </div>
          </RwCard>

          <RwCard className="p-0">
            <div className="flex items-center gap-1.5 border-b border-background-300/40 px-3 py-2.5 dark:border-background-400/25">
              <i className="ri-bookmark-3-line text-sm text-primary-500" />
              <h3 className="text-xs font-semibold text-foreground-950">Eğitim Şablon Kütüphanesi</h3>
            </div>
            <div className="border-b border-background-300/40 p-2.5 dark:border-background-400/25">
              <RwInput size="sm" placeholder="Şablon ara..." value={sablonArama} onChange={(e) => setSablonArama(e.target.value)} leftIcon={<i className="ri-search-line text-xs" />} />
            </div>
            <div className="max-h-[320px] overflow-y-auto p-2">
              {sablonlar.length === 0 && <p className="px-1 py-4 text-center text-xs text-foreground-400">Sonuç yok</p>}
              <div className="space-y-1.5">
                {sablonlar.map((s, i) => (
                  <div key={`${s.egitim}-${i}`} className="flex items-start justify-between gap-2 rounded-md border border-transparent p-2 hover:border-primary-300/50 hover:bg-background-50 dark:hover:bg-background-100/40">
                    <div className="min-w-0">
                      <p className="text-[11px] font-medium text-foreground-800">{s.egitim}</p>
                      <p className="mt-0.5 flex items-center gap-1.5 text-[10px] text-foreground-400">
                        <i className={kategoriIkon(s.kategori)} /> {s.kategori} · <i className="ri-time-line" /> {s.sure} sa
                      </p>
                    </div>
                    <button type="button" onClick={() => onSablondanEkle(s)} className="flex flex-shrink-0 cursor-pointer items-center gap-1 rounded-md border border-primary-300/60 px-2 py-1 text-[10px] font-semibold text-primary-600 transition-colors hover:bg-primary-500 hover:text-inverse dark:text-primary-300">
                      <i className="ri-add-line" /> Ekle
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </RwCard>
        </div>
      </div>
    </div>
  );
}