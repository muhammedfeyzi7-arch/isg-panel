// ─────────────────────────────────────────────────────────────────────────────
// FINE-KINNEY RİSK DEĞERLENDİRMESİ — ORTAK VERİ MODELİ
//
// 5x5 L Tipi Matris ile AYNI sihirbaz mimarisini kullanır ama HESAP FARKLIDIR:
//   Risk Puanı = Olasılık (O) × Frekans (F) × Şiddet (S)
//
// ÖLÇEKLER (Fine-Kinney standardı):
//   Olasılık (O): 0,1 · 0,2 · 0,5 · 1 · 3 · 6 · 10
//   Frekans  (F): 0,5 · 1 · 2 · 3 · 6 · 10
//   Şiddet   (S): 1 · 3 · 7 · 15 · 40 · 100
//
// SEVİYE ARALIKLARI: <20 Kabul · 20–70 Olası · 70–200 Önemli · 200–400 Yüksek · >400 Çok Yüksek
//
// ÖNEMLİ: Kalıcı kayıt/arşiv YOKTUR. Çalışma yalnızca yerel (IndexedDB) tutulur ve
// kullanıcı yalnızca PDF/Word/Excel indirir. Sisteme/Supabase'e hiçbir veri gitmez.
// ─────────────────────────────────────────────────────────────────────────────
import {
  type Imzaci,
  type RiskKaynagi,
  type TemelBilgiler,
  benzerMi,
  normalize,
  yeniId,
  RISK_ALANLARI,
  RISK_DURUMLARI,
  RISK_KATEGORILERI,
  KONTROL_TURLERI,
} from './riskSihirbazTypes';

export {
  RISK_ALANLARI,
  RISK_DURUMLARI,
  RISK_KATEGORILERI,
  KONTROL_TURLERI,
  benzerMi,
  normalize,
  yeniId,
};
export type { Imzaci, TemelBilgiler };

export type FkSeviye = 'kabul' | 'olasi' | 'onemli' | 'yuksek' | 'cokYuksek';

export interface FkOlcek {
  value: number;
  label: string;
}

/** Olasılık (O) ölçeği. */
export const FK_OLASILIK: FkOlcek[] = [
  { value: 0.1, label: 'Neredeyse imkânsız' },
  { value: 0.2, label: 'Beklenmez / çok düşük ihtimal' },
  { value: 0.5, label: 'Beklenmez fakat olabilir' },
  { value: 1, label: 'Mümkün fakat düşük' },
  { value: 3, label: 'Olağandışı ama mümkün' },
  { value: 6, label: 'Oldukça mümkün' },
  { value: 10, label: 'Beklenir / kesin' },
];

/** Frekans (F) ölçeği. */
export const FK_FREKANS: FkOlcek[] = [
  { value: 0.5, label: 'Çok seyrek' },
  { value: 1, label: 'Seyrek' },
  { value: 2, label: 'Sık değil' },
  { value: 3, label: 'Ara sıra' },
  { value: 6, label: 'Sık' },
  { value: 10, label: 'Sürekli' },
];

/** Şiddet (S) ölçeği. */
export const FK_SIDDET: FkOlcek[] = [
  { value: 1, label: 'Ramak kala / önemsiz zarar' },
  { value: 3, label: 'Hafif yaralanma / küçük hasar' },
  { value: 7, label: 'Önemli yaralanma / hasar' },
  { value: 15, label: 'Ciddi yaralanma / kalıcı hasar' },
  { value: 40, label: 'Ölümlü kaza / ciddi çevresel zarar' },
  { value: 100, label: 'Birden fazla ölümlü kaza / çevresel felaket' },
];

export const FK_METODU = 'Fine-Kinney (Olasılık × Frekans × Şiddet)';

export interface FkRiskItem {
  id: string;
  kaynak: RiskKaynagi;
  bolum: string;
  kategori: string;
  tehlike: string;
  risk: string;
  olasiSonuc: string;
  mevcutKontroller: string;
  onerilenKontroller: string;
  sorumlu: string;
  termin: string;
  durum: string;
  /** Faaliyet rutin bir iş mi? (Rapor "Rutin" kolonu: Evet/Hayır) */
  rutin?: boolean;
  /** Etkilenen kişi/gruplar (Rapor "Etkilenenler" kolonu). */
  etkilenenler?: string;
  olasilik: number;   // O
  frekans: number;    // F
  siddet: number;     // S
  notlar: string;
  kontrolTuru?: string;
  baslangic?: string;
  kalanOlasilik?: number;
  kalanFrekans?: number;
  kalanSiddet?: number;
}

export interface FkAiOneri {
  id: string;
  kategori: string;
  bolum: string;
  tehlike: string;
  risk: string;
  olasiSonuc: string;
  mevcutKontroller: string;
  onerilenKontroller: string;
  olasilik: number;
  frekans: number;
  siddet: number;
}

export interface FkWorkspace {
  temel: TemelBilgiler;
  riskler: FkRiskItem[];
  aiOnerileri: FkAiOneri[];
  aktifAdim: number;
  guncellendi: string;
}

// ── Hesaplama ────────────────────────────────────────────────────────────────
export function fkPuan(olasilik: number, frekans: number, siddet: number): number {
  const v = (Number(olasilik) || 0) * (Number(frekans) || 0) * (Number(siddet) || 0);
  return Math.round(v * 100) / 100;
}

export function fkPuanGoster(puan: number): string {
  if (!Number.isFinite(puan)) return '0';
  return Number.isInteger(puan) ? String(puan) : puan.toFixed(2).replace('.', ',');
}

/** Fine-Kinney seviyesi — <20 Kabul · 20–70 Olası · 70–200 Önemli · 200–400 Yüksek · >400 Çok Yüksek */
export function fkSeviye(puan: number): FkSeviye {
  if (puan < 20) return 'kabul';
  if (puan < 70) return 'olasi';
  if (puan < 200) return 'onemli';
  if (puan < 400) return 'yuksek';
  return 'cokYuksek';
}

export interface FkSeviyeMeta {
  key: FkSeviye;
  label: string;
  /** Katı rozet (dolgu). */
  badge: string;
  /** Yumuşak rozet. */
  soft: string;
  text: string;
  dot: string;
  icon: string;
  /** Rapor için ham renk. */
  hex: { fg: string; bg: string };
}

export const FK_SEVIYE_META: Record<FkSeviye, FkSeviyeMeta> = {
  kabul: {
    key: 'kabul', label: 'Kabul Edilebilir',
    badge: 'bg-success-500 text-inverse', soft: 'bg-success-50 text-success-700 dark:bg-success-500/15 dark:text-success-300',
    text: 'text-success-700 dark:text-success-300', dot: 'bg-success-500', icon: 'ri-checkbox-circle-line',
    hex: { fg: '#15803D', bg: '#E7F7EE' },
  },
  olasi: {
    key: 'olasi', label: 'Olası Risk',
    badge: 'bg-warning-500 text-inverse', soft: 'bg-warning-50 text-warning-700 dark:bg-warning-500/15 dark:text-warning-300',
    text: 'text-warning-700 dark:text-warning-300', dot: 'bg-warning-500', icon: 'ri-alert-line',
    hex: { fg: '#B45309', bg: '#FEF3C7' },
  },
  onemli: {
    key: 'onemli', label: 'Önemli Risk',
    badge: 'bg-warning-600 text-inverse', soft: 'bg-warning-100 text-warning-800 dark:bg-warning-500/20 dark:text-warning-200',
    text: 'text-warning-800 dark:text-warning-200', dot: 'bg-warning-600', icon: 'ri-alert-fill',
    hex: { fg: '#92400E', bg: '#FDE8C8' },
  },
  yuksek: {
    key: 'yuksek', label: 'Yüksek Risk',
    badge: 'bg-danger-500 text-inverse', soft: 'bg-danger-50 text-danger-700 dark:bg-danger-500/15 dark:text-danger-300',
    text: 'text-danger-700 dark:text-danger-300', dot: 'bg-danger-500', icon: 'ri-error-warning-line',
    hex: { fg: '#B91C1C', bg: '#FDE7E7' },
  },
  cokYuksek: {
    key: 'cokYuksek', label: 'Çok Yüksek Risk',
    badge: 'bg-danger-600 text-inverse', soft: 'bg-danger-100 text-danger-800 dark:bg-danger-500/25 dark:text-danger-200',
    text: 'text-danger-800 dark:text-danger-200', dot: 'bg-danger-600', icon: 'ri-fire-line',
    hex: { fg: '#7F1D1D', bg: '#FBC5C5' },
  },
};

export function fkSeviyeBilgi(puan: number): FkSeviyeMeta {
  return FK_SEVIYE_META[fkSeviye(puan)];
}

/** Ölçek değerine en yakın geçerli Fine-Kinney değerini döner. */
function enYakin(olcek: FkOlcek[], value: number): number {
  let enIyi = olcek[0].value;
  let fark = Math.abs(value - enIyi);
  olcek.forEach((o) => {
    const f = Math.abs(value - o.value);
    if (f < fark) { fark = f; enIyi = o.value; }
  });
  return enIyi;
}

export const fkOlasiYakin = (value: number) => enYakin(FK_OLASILIK, value);
export const fkFrekansYakin = (value: number) => enYakin(FK_FREKANS, value);
export const fkSiddetYakin = (value: number) => enYakin(FK_SIDDET, value);

export function fkOlcekEtiket(olcek: FkOlcek[], value: number): string {
  const bulunan = olcek.find((o) => o.value === value);
  return bulunan ? bulunan.label : String(value);
}

export function fkBosRisk(bolum = '', kaynak: RiskKaynagi = 'manuel'): FkRiskItem {
  return {
    id: yeniId('fk'),
    kaynak,
    bolum,
    kategori: '',
    tehlike: '',
    risk: '',
    olasiSonuc: '',
    mevcutKontroller: '',
    onerilenKontroller: '',
    sorumlu: '',
    termin: '',
    durum: 'Planlandı',
    rutin: true,
    etkilenenler: '',
    olasilik: 1,
    frekans: 1,
    siddet: 3,
    notlar: '',
  };
}

export function bosFkWorkspace(): FkWorkspace {
  return {
    temel: {
      calismaAdi: '',
      firma: '',
      degerlendirmeMetodu: FK_METODU,
      kapsam: '',
      tarih: bugunIso(),
      tesis: '',
      gecerlilik: '',
      amac: '',
      ekip: [],
      dokumanlar: [],
      raporNo: '',
      tehlikeSinifi: '',
      adres: '',
      isveren: '',
      nace: '',
      calisanSayisi: '',
      hazirlayan: '',
      onaylayan: '',
      imzacilar: [],
    },
    riskler: [],
    aiOnerileri: [],
    aktifAdim: 0,
    guncellendi: new Date().toISOString(),
  };
}

function bugunIso(): string {
  const b = new Date();
  return `${b.getFullYear()}-${String(b.getMonth() + 1).padStart(2, '0')}-${String(b.getDate()).padStart(2, '0')}`;
}

export const FK_ADIM_BASLIKLARI = [
  'Temel Bilgiler',
  'Tehlikeler ve Riskler',
  'Kontroller ve Aksiyonlar',
  'Değerlendirme',
  'Rapor ve Önizleme',
];