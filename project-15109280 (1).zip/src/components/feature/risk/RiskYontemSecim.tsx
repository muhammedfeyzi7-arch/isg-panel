import { useState } from 'react';
import RiskMatrisGorseli from './RiskMatrisGorseli';

// ─────────────────────────────────────────────────────────────────────────────
// RİSK DEĞERLENDİRME YÖNTEMİ SEÇİMİ (Referans görsel — birebir UI)
//
// Bu ekran REFERANS UI'dır: 3 yöntem kartı (5x5 Matris / Fine-Kinney / HAZOP)
// + sağ bilgi kolonu (Yöntem Seçimi Hakkında / Yasal Dayanak / Ortak Özellikler
// / Önemli Not) + sabit footer (İptal · Devam Et) AYNEN korunur.
//
// Üç yöntem de (5x5 L Tipi Matris, Fine-Kinney, HAZOP) seçilebilir; "Devam Et"
// seçilen yöntemin sihirbaz akışına yönlendirir.
// ─────────────────────────────────────────────────────────────────────────────

export type YontemKey = '5x5' | 'fine-kinney' | 'hazop';

interface RiskYontemSecimProps {
  onDevam: (yontem: YontemKey) => void;
  onClose: () => void;
}

export default function RiskYontemSecim({ onDevam, onClose }: RiskYontemSecimProps) {
  const [secili, setSecili] = useState<YontemKey>('5x5');

  return (
    <div
      className="flex min-h-0 flex-1 flex-col"
      style={{
        marginLeft: 'calc(var(--d-modal-body-px) * -1)',
        marginRight: 'calc(var(--d-modal-body-px) * -1)',
        marginBottom: 'calc(var(--d-modal-body-py) * -1)',
      }}
    >
      {/* ── Gövde ── */}
      <div className="isg-scroll-pane min-h-0 flex-1 overflow-y-auto overflow-x-hidden px-[var(--d-modal-body-px)] py-[var(--d-modal-body-py)]">
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
          {/* SOL — başlık + 3 yöntem kartı */}
          <div>
            <h2 className="text-xl font-bold text-foreground-950">Risk Değerlendirme Yöntemi</h2>
            <p className="mt-1 text-sm text-foreground-500">
              İşyerinizin ihtiyaçlarına ve değerlendirme ekibinin tercihlerine göre aşağıdaki yöntemlerden birini seçin.
            </p>

            <div role="radiogroup" aria-label="Risk değerlendirme yöntemi" className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-3">
              {/* 5x5 MATRİS — seçili/öne çıkan kart */}
              <YontemKarti
                secili={secili === '5x5'}
                onSelect={() => setSecili('5x5')}
                seciliKenar="border-danger-500"
                seciliArka="bg-danger-500/5"
                radioKenar={secili === '5x5' ? 'border-danger-500' : 'border-foreground-300 dark:border-background-400'}
                radioNokta="bg-danger-500"
              >
                <div className="mb-3 flex items-start justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-danger-500 text-inverse">
                    <i className="ri-apps-2-fill text-xl" />
                  </span>
                </div>
                <h3 className="text-base font-bold text-foreground-950">5x5 Matris</h3>
                <p className="mt-0.5 text-sm font-semibold text-foreground-700">Olasılık × Şiddet yöntemi</p>
                <p className="mt-1.5 text-xs leading-relaxed text-foreground-500">
                  Tehlikelerin olasılık ve şiddet değerleri 1–5 aralığında değerlendirilerek risk puanı oluşturulur.
                </p>
                <div className="mt-3 rounded-md border border-background-300/50 bg-background-50/70 p-2.5 dark:border-background-400/25 dark:bg-background-100/40">
                  <RiskMatrisGorseli />
                </div>
                <div className="mt-3 flex items-center gap-2 rounded-md border border-danger-500/25 bg-danger-500/10 p-2.5">
                  <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md bg-danger-500/15 text-danger-600 dark:text-danger-300">
                    <i className="ri-calculator-line text-sm" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-xs font-semibold text-foreground-900">Risk Puanı = Olasılık × Şiddet</span>
                    <span className="block text-[11px] text-foreground-500">1 – 25 arası</span>
                  </span>
                </div>
              </YontemKarti>

              {/* FINE-KINNEY */}
              <YontemKarti
                secili={secili === 'fine-kinney'}
                onSelect={() => setSecili('fine-kinney')}
                seciliKenar="border-secondary-500"
                seciliArka="bg-secondary-500/5"
                radioKenar={secili === 'fine-kinney' ? 'border-secondary-500' : 'border-foreground-300 dark:border-background-400'}
                radioNokta="bg-secondary-500"
              >
                <div className="mb-3 flex items-start justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-secondary-500 text-inverse">
                    <i className="ri-calculator-fill text-xl" />
                  </span>
                </div>
                <h3 className="text-base font-bold text-foreground-950">Fine-Kinney</h3>
                <p className="mt-0.5 text-sm font-semibold text-foreground-700">Olasılık × Şiddet × Frekans</p>
                <p className="mt-1.5 text-xs leading-relaxed text-foreground-500">
                  Riski daha detaylı analiz etmek için olasılığa ek olarak frekans (maruziyet) faktörünü de değerlendirir.
                </p>
                <div className="mt-3 flex min-h-[132px] items-center justify-center rounded-md border border-background-300/50 bg-background-50/70 p-2.5 dark:border-background-400/25 dark:bg-background-100/40">
                  <div className="flex items-center gap-1.5">
                    <FineKutu harf="O" ad="Olasılık" aralik="(1–10)" boxClass="bg-primary-500" />
                    <span className="text-lg font-bold text-foreground-400">×</span>
                    <FineKutu harf="Ş" ad="Şiddet" aralik="(1–100)" boxClass="bg-secondary-500" />
                    <span className="text-lg font-bold text-foreground-400">×</span>
                    <FineKutu harf="F" ad="Frekans" aralik="(1–10)" boxClass="bg-success-500" />
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-2 rounded-md border border-secondary-500/25 bg-secondary-500/10 p-2.5">
                  <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md bg-secondary-500/15 text-secondary-600 dark:text-secondary-300">
                    <i className="ri-calculator-line text-sm" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-xs font-semibold text-foreground-900">Risk Puanı = O × Ş × F</span>
                    <span className="block text-[11px] text-foreground-500">1 – 10.000 arası</span>
                  </span>
                </div>
              </YontemKarti>

              {/* HAZOP */}
              <YontemKarti
                secili={secili === 'hazop'}
                onSelect={() => setSecili('hazop')}
                seciliKenar="border-success-500"
                seciliArka="bg-success-500/5"
                radioKenar={secili === 'hazop' ? 'border-success-500' : 'border-foreground-300 dark:border-background-400'}
                radioNokta="bg-success-500"
              >
                <div className="mb-3 flex items-start justify-between">
                  <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-success-500 text-inverse">
                    <i className="ri-settings-3-fill text-xl" />
                  </span>
                </div>
                <h3 className="text-base font-bold text-foreground-950">HAZOP</h3>
                <p className="mt-0.5 text-sm font-semibold text-foreground-700">Proses odaklı analiz</p>
                <p className="mt-1.5 text-xs leading-relaxed text-foreground-500">
                  Özellikle kimyasal ve endüstriyel tesislerde proses tehlikelerini sistematik olarak analiz etmek için kullanılır.
                </p>
                <div className="mt-3 flex min-h-[132px] items-center justify-center rounded-md border border-background-300/50 bg-background-50/70 dark:border-background-400/25 dark:bg-background-100/40">
                  <span className="flex h-20 w-20 items-center justify-center rounded-lg bg-success-500/10 text-success-500">
                    <i className="ri-oil-line text-5xl" />
                  </span>
                </div>
                <div className="mt-3 flex items-center gap-2 rounded-md border border-success-500/25 bg-success-500/10 p-2.5">
                  <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md bg-success-500/15 text-success-600 dark:text-success-300">
                    <i className="ri-file-list-3-line text-sm" />
                  </span>
                  <span className="min-w-0">
                    <span className="block text-xs font-semibold text-foreground-900">Nitel değerlendirme</span>
                    <span className="block text-[11px] text-foreground-500">Rehber kelimeler ile analiz</span>
                  </span>
                </div>
              </YontemKarti>
            </div>
          </div>

          {/* SAĞ — bilgi kolonu (referansta AYNEN korunur) */}
          <aside className="space-y-3">
            <BilgiKarti
              icon="ri-information-fill"
              iconSinif="bg-primary-500 text-inverse"
              baslik="Yöntem Seçimi Hakkında"
            >
              Mevzuat, risk değerlendirmesinde belirli bir yöntemi zorunlu tutmamaktadır. Yöntem seçimi; işyerinin
              faaliyet konusu, tehlike türleri, karmaşıklığı, mevcut veriler ve uzman ekibin değerlendirmesi dikkate
              alınarak yapılmalıdır.
            </BilgiKarti>

            <BilgiKarti
              icon="ri-file-text-fill"
              iconSinif="bg-primary-500 text-inverse"
              baslik="Yasal Dayanak"
            >
              İş Sağlığı ve Güvenliği Risk Değerlendirmesi Yönetmeliği uyarınca, risk değerlendirmesi; “işyerinin
              tehlikelerini tanımlama, riskleri analiz etme, kontrol tedbirlerini kararlaştırma ve izleme” süreçlerini
              içermelidir.
            </BilgiKarti>

            <BilgiKarti
              icon="ri-checkbox-circle-fill"
              iconSinif="bg-primary-500 text-inverse"
              baslik="Ortak Özellikler"
            >
              <ul className="mt-1 space-y-1.5">
                {[
                  'Tehlikelerin sistematik olarak değerlendirilmesi',
                  'Risk seviyelerinin belirlenmesi',
                  'Kontrol tedbirlerinin planlanması',
                  'Kontrol sonrası riskin yeniden değerlendirilmesi',
                  'Dokümantasyon ve izleme',
                ].map((m) => (
                  <li key={m} className="flex items-start gap-2">
                    <i className="ri-check-line mt-0.5 text-sm text-primary-500" />
                    <span className="text-xs leading-relaxed text-foreground-600">{m}</span>
                  </li>
                ))}
              </ul>
            </BilgiKarti>

            <BilgiKarti
              icon="ri-alert-fill"
              iconSinif="bg-warning-500 text-inverse"
              baslik="Önemli Not"
              vurgu
            >
              Seçtiğiniz yöntem, değerlendirme sürecinin içeriğini ve kullanıcı arayüzündeki adımları belirleyecektir.
            </BilgiKarti>
          </aside>
        </div>
      </div>

      {/* ── Sabit footer (referans: sol İptal · sağ Devam Et) ── */}
      <div className="flex flex-shrink-0 items-center justify-between gap-2 border-t border-background-300/25 px-[var(--d-modal-body-px)] py-3 dark:border-background-400/35">
        <button type="button" onClick={onClose} className="isg-btn isg-btn-ghost whitespace-nowrap cursor-pointer">
          <i className="ri-close-line" /> İptal
        </button>
        <button type="button" onClick={() => onDevam(secili)} className="isg-btn isg-btn-primary whitespace-nowrap cursor-pointer">
          Devam Et <i className="ri-arrow-right-line" />
        </button>
      </div>
    </div>
  );
}

// ── Yardımcı bileşenler ──────────────────────────────────────────────────────

interface YontemKartiProps {
  secili: boolean;
  onSelect: () => void;
  seciliKenar: string;
  seciliArka: string;
  radioKenar: string;
  radioNokta: string;
  children: React.ReactNode;
}

function YontemKarti({ secili, onSelect, seciliKenar, seciliArka, radioKenar, radioNokta, children }: YontemKartiProps) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={secili}
      onClick={onSelect}
      className={`relative flex h-full cursor-pointer flex-col rounded-lg border p-4 text-left transition-colors ${
        secili
          ? `${seciliKenar} ${seciliArka}`
          : 'border-background-300/60 bg-background-100 hover:border-foreground-300 dark:border-background-400/30 dark:bg-background-200/40 dark:hover:border-background-400'
      }`}
    >
      <span
        className={`absolute right-4 top-4 flex h-5 w-5 items-center justify-center rounded-full border-2 ${radioKenar}`}
        aria-hidden="true"
      >
        {secili && <span className={`h-2.5 w-2.5 rounded-full ${radioNokta}`} />}
      </span>
      {children}
    </button>
  );
}

function FineKutu({ harf, ad, aralik, boxClass }: { harf: string; ad: string; aralik: string; boxClass: string }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <span className={`flex h-11 w-11 items-center justify-center rounded-md text-lg font-bold text-inverse ${boxClass}`}>
        {harf}
      </span>
      <span className="text-[10px] font-semibold text-foreground-700">{ad}</span>
      <span className="text-[9px] text-foreground-400">{aralik}</span>
    </div>
  );
}

interface BilgiKartiProps {
  icon: string;
  iconSinif: string;
  baslik: string;
  vurgu?: boolean;
  children: React.ReactNode;
}

function BilgiKarti({ icon, iconSinif, baslik, vurgu, children }: BilgiKartiProps) {
  return (
    <div
      className={`rounded-lg border p-3.5 ${
        vurgu
          ? 'border-warning-500/30 bg-warning-500/5'
          : 'border-background-300/50 bg-background-100 dark:border-background-400/30 dark:bg-background-200/40'
      }`}
    >
      <div className="flex items-center gap-2">
        <span className={`flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full ${iconSinif}`}>
          <i className={`${icon} text-xs`} />
        </span>
        <h3 className="text-sm font-semibold text-foreground-900">{baslik}</h3>
      </div>
      <div className="mt-2 text-xs leading-relaxed text-foreground-600">{children}</div>
    </div>
  );
}