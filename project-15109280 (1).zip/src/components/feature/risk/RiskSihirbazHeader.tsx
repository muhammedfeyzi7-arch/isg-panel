import { useToastActions } from '@/hooks/useToast';

/**
 * İSGDenetim Sihirbazı — modal başlık parçaları (Shared UI başlık şeridi
 * `headerIcon` / `headerExtra` alanlarına verilir). Renkler merkezi tokenlardan
 * gelir; başlık geometrisi Modal.tsx tarafından yönetilir (sayfaya özel header
 * sistemi kurulmaz).
 */

/** Ana sihirbaz başlık ikonu — primary vurgulu sihirbaz kutusu. */
export function SihirbazHeaderIcon() {
  return (
    <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary-500 text-inverse">
      <i className="ri-magic-line text-2xl" />
    </span>
  );
}

/** Risk Değerlendirmesi başlık ikonu — danger vurgulu kalkan kutusu. */
export function RiskHeaderIcon() {
  return (
    <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-danger-500 text-inverse">
      <i className="ri-shield-cross-line text-xl" />
    </span>
  );
}

/** Yıllık Çalışma Planı başlık ikonu — primary vurgulu takvim kutusu. */
export function CalismaHeaderIcon() {
  return (
    <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary-500 text-inverse">
      <i className="ri-calendar-2-line text-xl" />
    </span>
  );
}

/** Yıllık Eğitim Planı başlık ikonu — secondary vurgulu mezuniyet kepi kutusu. */
export function EgitimHeaderIcon() {
  return (
    <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-secondary-500 text-inverse">
      <i className="ri-graduation-cap-line text-xl" />
    </span>
  );
}

/** Acil Durum Eylem Planı başlık ikonu — accent vurgulu alarm kutusu. */
export function AcilHeaderIcon() {
  return (
    <span className="flex h-11 w-11 items-center justify-center rounded-lg bg-accent-500 text-inverse">
      <i className="ri-alarm-warning-line text-xl" />
    </span>
  );
}

/** Başlık sağındaki yardım butonu. */
export function SihirbazYardimButton() {
  const { addToast } = useToastActions();
  return (
    <button
      type="button"
      className="isg-btn isg-btn-outline isg-btn-sm whitespace-nowrap cursor-pointer"
      onClick={() =>
        addToast({
          title: 'İSGDenetim Sihirbazı nedir?',
          message:
            'İhtiyacınız olan İSG dokümanını adım adım oluşturmanızı sağlar. Bir modül seçip yöntemi belirleyerek ilerlersiniz.',
          type: 'info',
        })
      }
    >
      <i className="ri-question-line" />
      Sihirbaz Nedir?
    </button>
  );
}