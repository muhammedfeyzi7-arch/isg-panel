// ─────────────────────────────────────────────────────────────────────────────
// YILLIK ÇALIŞMA PLANI — ORTAK VERİ MODELİ
//
// 5x5 / Fine-Kinney / HAZOP ile AYNI sihirbaz mimarisini kullanır. Yöntem
// "faaliyet odaklıdır": İSG profesyonellerinin bir sonraki yıl için planladığı
// çalışma ortamı gözetimi, sağlık gözetimi, eğitim, acil durum, periyodik
// kontrol, KKD, İSG kurulu gibi faaliyetler aylık matrise yerleştirilir.
//
// HUKUKİ DAYANAK: İş Sağlığı ve Güvenliği Hizmetleri Yönetmeliği (Madde 15 —
// Yıllık çalışma planı): iş sağlığı ve güvenliği hizmetleri ile ilgili yıllık
// çalışma planı, işyeri hekimi ve iş güvenliği uzmanı tarafından hazırlanır.
//
// ÖNEMLİ: Kalıcı kayıt/arşiv YOKTUR. Çalışma yalnızca yerel (IndexedDB) tutulur
// ve kullanıcı yalnızca PDF/Word/Excel indirir. Sisteme/Supabase'e veri gitmez.
// ─────────────────────────────────────────────────────────────────────────────
import {
  type TemelBilgiler,
  type Imzaci,
  yeniId,
  benzerMi,
  normalize,
} from './riskSihirbazTypes';

export { yeniId, benzerMi, normalize };
export type { Imzaci, TemelBilgiler };

export const CALISMA_METODU = 'Yıllık Çalışma Planı (İSG Hizmetleri Yönetmeliği m.15)';

// ── Ay adları ────────────────────────────────────────────────────────────────
export const AY_ADLARI: string[] = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
];

export const AY_KISA: string[] = [
  'Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara',
];

// ── Faaliyet kategorileri ────────────────────────────────────────────────────
export const CALISMA_KATEGORILERI: string[] = [
  'Çalışma Ortamı Gözetimi',
  'Sağlık Gözetimi',
  'Risk Değerlendirmesi',
  'Eğitim ve Bilgilendirme',
  'Acil Durum',
  'İş Ekipmanı ve Periyodik Kontrol',
  'KKD Yönetimi',
  'İSG Kurulu ve Temsilci',
  'İş Kazası ve Kayıt',
  'Ölçüm ve Analiz',
  'Denetim ve Teftiş',
  'Dokümantasyon ve Raporlama',
];

export function kategoriIkon(kategori: string): string {
  const t = (kategori || '').toLocaleLowerCase('tr');
  if (t.includes('ortam') || t.includes('gözetim')) return 'ri-eye-line';
  if (t.includes('sağlık') || t.includes('saglik')) return 'ri-heart-pulse-line';
  if (t.includes('risk')) return 'ri-shield-cross-line';
  if (t.includes('eğitim') || t.includes('egitim') || t.includes('bilgilendirme')) return 'ri-graduation-cap-line';
  if (t.includes('acil')) return 'ri-alarm-warning-line';
  if (t.includes('ekipman') || t.includes('periyodik')) return 'ri-settings-3-line';
  if (t.includes('kkd')) return 'ri-shield-user-line';
  if (t.includes('kurul') || t.includes('temsilci')) return 'ri-group-line';
  if (t.includes('kaza') || t.includes('kayıt') || t.includes('kayit')) return 'ri-first-aid-kit-line';
  if (t.includes('ölçüm') || t.includes('olcum') || t.includes('analiz')) return 'ri-flask-line';
  if (t.includes('denetim') || t.includes('teftiş') || t.includes('teftis')) return 'ri-search-eye-line';
  if (t.includes('doküman') || t.includes('dokuman') || t.includes('rapor')) return 'ri-file-list-3-line';
  return 'ri-calendar-check-line';
}

// ── Periyotlar ───────────────────────────────────────────────────────────────
export const PERIYOTLAR: string[] = [
  'Haftalık', 'Aylık', '2 Aylık', '3 Aylık', '6 Aylık', 'Yıllık', 'Sürekli', 'Tek Seferlik',
];

export const ONCELIKLER: string[] = ['Yüksek', 'Orta', 'Düşük'];

export interface OncelikMeta {
  label: string;
  badge: string;
  soft: string;
  dot: string;
  renk: string;
  hex: { fg: string; bg: string };
}

export const ONCELIK_META: Record<string, OncelikMeta> = {
  Yüksek: {
    label: 'Yüksek', badge: 'bg-danger-500 text-inverse',
    soft: 'bg-danger-500/15 text-danger-700 dark:text-danger-300', dot: 'bg-danger-500',
    renk: '#DC2626', hex: { fg: '#B91C1C', bg: '#FDE7E7' },
  },
  Orta: {
    label: 'Orta', badge: 'bg-warning-500 text-inverse',
    soft: 'bg-warning-500/15 text-warning-700 dark:text-warning-300', dot: 'bg-warning-500',
    renk: '#F59E0B', hex: { fg: '#B45309', bg: '#FEF3C7' },
  },
  Düşük: {
    label: 'Düşük', badge: 'bg-success-500 text-inverse',
    soft: 'bg-success-500/15 text-success-700 dark:text-success-300', dot: 'bg-success-500',
    renk: '#16A34A', hex: { fg: '#15803D', bg: '#E7F7EE' },
  },
};

export function oncelikBilgi(oncelik: string): OncelikMeta {
  return ONCELIK_META[oncelik] ?? ONCELIK_META.Orta;
}

// ── Periyot → ay eşlemesi (deterministik "önerilen plan") ────────────────────
export function bosAylar(): boolean[] {
  return Array.from({ length: 12 }, () => false);
}

export function periyotAylari(periyot: string): number[] {
  switch (periyot) {
    case 'Haftalık':
    case 'Aylık':
    case 'Sürekli':
      return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
    case '2 Aylık': return [0, 2, 4, 6, 8, 10];
    case '3 Aylık': return [0, 3, 6, 9];
    case '6 Aylık': return [0, 6];
    case 'Yıllık': return [0];
    default: return [];
  }
}

export function aylariUygula(aylar: number[]): boolean[] {
  const a = bosAylar();
  aylar.forEach((i) => { if (i >= 0 && i < 12) a[i] = true; });
  return a;
}

// ── Kayıtlar ─────────────────────────────────────────────────────────────────
/** Bir planlanan faaliyet. */
export interface CalismaFaaliyet {
  id: string;
  kategori: string;
  faaliyet: string;
  aciklama: string;
  sorumlu: string;
  periyot: string;
  oncelik: string;
  /** 12 aylık plan (Ocak…Aralık). */
  aylar: boolean[];
}

/** AI faaliyet önerisi — listeye EKLENMEDEN önceki öneri kartı. */
export interface CalismaAiOneri {
  id: string;
  kategori: string;
  faaliyet: string;
  aciklama: string;
  periyot: string;
  oncelik: string;
}

export interface CalismaTemelBilgiler extends TemelBilgiler {
  planYili: string;
}

/** Sihirbazın GEÇİCİ çalışma alanı (kalıcı kayıt DEĞİLDİR). */
export interface CalismaWorkspace {
  temel: CalismaTemelBilgiler;
  kapsam: string[];
  faaliyetler: CalismaFaaliyet[];
  aiOnerileri: CalismaAiOneri[];
  aktifAdim: number;
  guncellendi: string;
}

// ── Kapsam maddeleri ─────────────────────────────────────────────────────────
export const KAPSAM_MADDELERI: string[] = [
  'Çalışma ortamı gözetimi ve saha denetimleri',
  'Çalışanların sağlık gözetimi ve periyodik muayeneleri',
  'Risk değerlendirmesinin hazırlanması ve güncellenmesi',
  'İş sağlığı ve güvenliği eğitimleri ve bilgilendirme',
  'Acil durum planları, tatbikatlar ve ekipler',
  'İş ekipmanları ve periyodik kontroller',
  'Kişisel koruyucu donanım (KKD) yönetimi',
  'İş kazası ve meslek hastalığı kayıt ve bildirimleri',
  'İSG kurulu / çalışan temsilcisi faaliyetleri',
  'Dokümantasyon, ölçüm ve raporlama',
];

// ── Hazır faaliyet şablonları ("Şablondan Ekle") ─────────────────────────────
export interface CalismaSablon {
  kategori: string;
  faaliyet: string;
  aciklama: string;
  periyot: string;
  oncelik: string;
}

export const CALISMA_SABLONLARI: CalismaSablon[] = [
  { kategori: 'Çalışma Ortamı Gözetimi', faaliyet: 'Aylık saha gözetim turu', aciklama: 'İşyerinin tamamında çalışma ortamı gözetimi yapılması ve gözlem raporunun düzenlenmesi.', periyot: 'Aylık', oncelik: 'Yüksek' },
  { kategori: 'Çalışma Ortamı Gözetimi', faaliyet: 'Ortam ölçümleri (gürültü, toz, aydınlatma)', aciklama: 'Fiziksel ve kimyasal etkenlerin yetkili laboratuvara ölçümünün yaptırılması.', periyot: '6 Aylık', oncelik: 'Yüksek' },
  { kategori: 'Sağlık Gözetimi', faaliyet: 'Periyodik sağlık muayenesi', aciklama: 'Çalışanların işe giriş ve periyodik sağlık muayenelerinin planlanması.', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Sağlık Gözetimi', faaliyet: 'Tahlil ve tetkiklerin yapılması', aciklama: 'Sağlık gözetimi kapsamında gerekli tetkik ve tahlillerin tamamlanması.', periyot: 'Yıllık', oncelik: 'Orta' },
  { kategori: 'Risk Değerlendirmesi', faaliyet: 'Risk değerlendirmesinin gözden geçirilmesi', aciklama: 'Mevcut risk değerlendirmesinin güncelliğinin kontrol edilmesi ve revize edilmesi.', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Risk Değerlendirmesi', faaliyet: 'Yeni tehlike ve risklerin eklenmesi', aciklama: 'Değişen üretim ve koşullara göre yeni risk kayıtlarının eklenmesi.', periyot: '3 Aylık', oncelik: 'Orta' },
  { kategori: 'Eğitim ve Bilgilendirme', faaliyet: 'Temel İSG eğitimi', aciklama: 'Yeni işe başlayan ve mevcut çalışanlara temel İSG eğitimi verilmesi.', periyot: 'Aylık', oncelik: 'Yüksek' },
  { kategori: 'Eğitim ve Bilgilendirme', faaliyet: 'Bilgilendirme toplantıları', aciklama: 'Çalışanlara güncel İSG konularında kısa bilgilendirme yapılması.', periyot: '3 Aylık', oncelik: 'Orta' },
  { kategori: 'Acil Durum', faaliyet: 'Acil durum tatbikatı', aciklama: 'Yangın ve tahliye tatbikatının gerçekleştirilmesi ve raporlanması.', periyot: '6 Aylık', oncelik: 'Yüksek' },
  { kategori: 'Acil Durum', faaliyet: 'Acil durum planı güncellemesi', aciklama: 'Acil durum planlarının gözden geçirilmesi ve gerekiyorsa güncellenmesi.', periyot: 'Yıllık', oncelik: 'Orta' },
  { kategori: 'İş Ekipmanı ve Periyodik Kontrol', faaliyet: 'Periyodik kontrol takibi', aciklama: 'İş ekipmanlarının periyodik kontrol takviminin oluşturulması ve takibi.', periyot: '3 Aylık', oncelik: 'Yüksek' },
  { kategori: 'İş Ekipmanı ve Periyodik Kontrol', faaliyet: 'Bakım-onarım kontrolü', aciklama: 'Ekipman bakım kayıtlarının mevzuata uygunluğunun kontrol edilmesi.', periyot: '3 Aylık', oncelik: 'Orta' },
  { kategori: 'KKD Yönetimi', faaliyet: 'KKD teslimi ve kullanım denetimi', aciklama: 'Çalışanlara KKD tesliminin yapılması ve kullanımının denetlenmesi.', periyot: '3 Aylık', oncelik: 'Orta' },
  { kategori: 'KKD Yönetimi', faaliyet: 'KKD uygunluk kontrolü', aciklama: 'Kullanılan KKD’lerin CE ve uygunluk belgelerinin kontrol edilmesi.', periyot: 'Yıllık', oncelik: 'Düşük' },
  { kategori: 'İSG Kurulu ve Temsilci', faaliyet: 'İSG kurulu toplantısı', aciklama: 'İSG kurulunun mevzuata uygun toplanması ve alınan kararların takibi.', periyot: 'Aylık', oncelik: 'Yüksek' },
  { kategori: 'İSG Kurulu ve Temsilci', faaliyet: 'Çalışan temsilcisi görüşleri', aciklama: 'Çalışan temsilcisinin görüş ve önerilerinin değerlendirilmesi.', periyot: '3 Aylık', oncelik: 'Orta' },
  { kategori: 'İş Kazası ve Kayıt', faaliyet: 'Kaza istatistiklerinin değerlendirilmesi', aciklama: 'İş kazası ve ramak kala olaylarının istatistiksel olarak değerlendirilmesi.', periyot: 'Aylık', oncelik: 'Orta' },
  { kategori: 'İş Kazası ve Kayıt', faaliyet: 'Kaza kayıt ve bildirim takibi', aciklama: 'İş kazalarının yasal süresinde kayıt altına alınması ve bildirilmesi.', periyot: 'Sürekli', oncelik: 'Orta' },
  { kategori: 'Ölçüm ve Analiz', faaliyet: 'Yasal ölçümlerin takibi', aciklama: 'Mevzuat gereği yapılması gereken ortam ölçümlerinin takibi.', periyot: 'Yıllık', oncelik: 'Orta' },
  { kategori: 'Denetim ve Teftiş', faaliyet: 'İSG iç denetimi', aciklama: 'İşyerinde İSG iç denetiminin yapılması ve uygunsuzlukların takibi.', periyot: '3 Aylık', oncelik: 'Orta' },
  { kategori: 'Dokümantasyon ve Raporlama', faaliyet: 'Yıllık değerlendirme raporu', aciklama: 'İSG yıllık değerlendirme raporunun hazırlanması ve sunulması.', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Dokümantasyon ve Raporlama', faaliyet: 'Kayıt ve dosyalama kontrolü', aciklama: 'İSG kayıtlarının güncel tutulması ve dosyalanmasının sağlanması.', periyot: 'Aylık', oncelik: 'Düşük' },
];

// ── Boş kayıt üreticileri ────────────────────────────────────────────────────
function bugunIso(): string {
  const b = new Date();
  return `${b.getFullYear()}-${String(b.getMonth() + 1).padStart(2, '0')}-${String(b.getDate()).padStart(2, '0')}`;
}

export function bosFaaliyet(periyot = 'Aylık', oncelik = 'Orta'): CalismaFaaliyet {
  return {
    id: yeniId('cf'),
    kategori: CALISMA_KATEGORILERI[0],
    faaliyet: '',
    aciklama: '',
    sorumlu: '',
    periyot,
    oncelik,
    aylar: aylariUygula(periyotAylari(periyot)),
  };
}

export function sablondanFaaliyet(s: CalismaSablon): CalismaFaaliyet {
  return {
    id: yeniId('cf'),
    kategori: s.kategori,
    faaliyet: s.faaliyet,
    aciklama: s.aciklama,
    sorumlu: '',
    periyot: s.periyot,
    oncelik: s.oncelik,
    aylar: aylariUygula(periyotAylari(s.periyot)),
  };
}

export function bosCalismaTemel(): CalismaTemelBilgiler {
  return {
    calismaAdi: '',
    firma: '',
    degerlendirmeMetodu: CALISMA_METODU,
    kapsam: '',
    tarih: bugunIso(),
    tesis: '',
    gecerlilik: '',
    amac: '',
    ekip: [],
    dokumanlar: [],
    raporNo: '',
    tehlikeSinifi: '',
    adres: '',
    isveren: '',
    nace: '',
    naceId: '',
    calisanSayisi: '',
    hazirlayan: '',
    onaylayan: '',
    imzacilar: [],
    planYili: String(new Date().getFullYear() + 1),
  };
}

export function bosCalismaWorkspace(): CalismaWorkspace {
  return {
    temel: bosCalismaTemel(),
    kapsam: [...KAPSAM_MADDELERI],
    faaliyetler: [],
    aiOnerileri: [],
    aktifAdim: 0,
    guncellendi: new Date().toISOString(),
  };
}

/** Referans görseldeki örnek faaliyetlerle başlangıç (ilk kullanım). */
export function ornekFaaliyetler(): CalismaFaaliyet[] {
  const secilen = [0, 2, 4, 6, 8, 10, 14, 16, 20];
  return secilen.map((i) => sablondanFaaliyet(CALISMA_SABLONLARI[i])).filter(Boolean);
}