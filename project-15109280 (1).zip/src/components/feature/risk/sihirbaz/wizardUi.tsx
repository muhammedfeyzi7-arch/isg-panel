import {
  useRef,
  useState,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type ReactNode,
  type TextareaHTMLAttributes,
} from 'react';
import Alert from '@/components/ui/Alert';
import DropdownPanel from '@/components/ui/DropdownPanel';
import DatePicker from '@/components/ui/DatePicker';
import TimePicker from '@/components/ui/TimePicker';
import SegmentedControl from '@/components/ui/SegmentedControl';
import WizardStepper from '@/components/ui/WizardStepper';
import Pagination from '@/components/ui/Pagination';
import Chip from '@/components/ui/Chip';
import SectionTitle from '@/components/ui/SectionTitle';
import { matchesSearch, normalizeForSearch } from '@/utils/turkishText';

// ═══════════════════════════════════════════════════════════════════════════════
// RİSK SİHİRBAZI — İNCE KATMAN (SHARED UI TEK KAYNAK)
// -----------------------------------------------------------------------------
// ÖNEMLİ (tek kaynak kuralı): Bu dosyadaki bileşenler artık BAĞIMSIZ bir UI
// katmanı DEĞİLDİR. Hepsi Shared UI'ın kanonik sözleşmelerine DELEGE eder:
//   RwButton / RwIconButton → .isg-btn / .isg-btn-icon  (Button standardı)
//   RwInput / RwTextarea    → .isg-input + .isg-form-label (Input standardı)
//   RwInput(date/time)      → Shared DatePicker / TimePicker
//   RwSelect                → .isg-input trigger + .isg-popover panel motoru
//   RwCard                  → .isg-card + .isg-divider
//   RwStepper               → Shared WizardStepper
//   RwTabs                  → Shared SegmentedControl
// Public API (prop adları) AYNEN korunur; böylece risk modülündeki yüzlerce
// çağrı hiç değişmeden TEK kaynaktan beslenir. Geometri/tipografi/renk sadece
// ortak tokenlardan gelir; Light ve Dark aynı kuralları paylaşır.
// ═══════════════════════════════════════════════════════════════════════════════

function Zorunlu() {
  return <span className="ml-0.5 text-danger-500">*</span>;
}

// ── RwInput ──────────────────────────────────────────────────────────────────
interface RwInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  required?: boolean;
  leftIcon?: ReactNode;
  hint?: ReactNode;
  size?: 'sm' | 'md';
}

export function RwInput({ label, required, leftIcon, hint, size = 'md', className = '', ...rest }: RwInputProps) {
  // Tek kaynak kuralı: yerel (native) tarih/saat kontrolü ASLA gösterilmez.
  // type="date"/"time" verilirse Shared DatePicker/TimePicker'a delege edilir.
  if (rest.type === 'date' || rest.type === 'time') {
    const Picker = rest.type === 'date' ? DatePicker : TimePicker;
    const { type: _pickerType, ...pickerProps } = rest;
    void _pickerType;
    return (
      <Picker
        label={label}
        required={required}
        className={className}
        {...(pickerProps as Record<string, unknown>)}
      />
    );
  }
  const sizeCls = size === 'sm' ? 'isg-input-sm' : '';
  return (
    <div className="w-full">
      {label && (
        <label className="isg-form-label">
          {label}
          {required && <Zorunlu />}
        </label>
      )}
      <span className="relative block">
        {leftIcon && (
          <span className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-foreground-400">
            {leftIcon}
          </span>
        )}
        <input
          className={`isg-input w-full ${sizeCls} ${leftIcon ? 'pl-9' : ''} ${className}`}
          {...rest}
        />
      </span>
      {hint}
    </div>
  );
}

// ── RwTextarea ───────────────────────────────────────────────────────────────
interface RwTextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  required?: boolean;
  maxLength?: number;
}

export function RwTextarea({ label, required, maxLength = 500, className = '', value, ...rest }: RwTextareaProps) {
  const metin = typeof value === 'string' ? value : '';
  return (
    <div className="w-full">
      {label && (
        <label className="isg-form-label">
          {label}
          {required && <Zorunlu />}
        </label>
      )}
      <textarea
        value={value}
        maxLength={maxLength}
        className={`isg-input w-full min-h-[86px] resize-y ${className}`}
        {...rest}
      />
      <span className="isg-form-help block text-right">{metin.length}/{maxLength}</span>
    </div>
  );
}

// ── RwSelect (özel açılır liste — tarayıcı varsayılanı KULLANILMAZ) ───────────
// Panel, global DropdownPanel motoru ile document.body'ye PORTAL edilir; böylece
// modal gövdesinin taşma (overflow) alanı tarafından kırpılmaz, viewport'a göre
// aşağı/yukarı otomatik açılır. Panel yalnızca dışarı tıklamada kapanır; scroll
// sırasında KAPANMAZ (arama kutusunun autoFocus kaydırması dropdown'ı kapatmaz).
interface RwOption { value: string; label: string }
interface RwSelectProps {
  label?: string;
  required?: boolean;
  options: RwOption[];
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  size?: 'sm' | 'md';
  disabled?: boolean;
  searchable?: boolean;
  creatable?: boolean;
  className?: string;
}

export function RwSelect({
  label, required, options, value, onChange, placeholder = 'Seçiniz',
  size = 'md', disabled, searchable, creatable, className = '',
}: RwSelectProps) {
  const [acik, setAcik] = useState(false);
  const [q, setQ] = useState('');
  const btnRef = useRef<HTMLButtonElement>(null);

  const secili = options.find((o) => o.value === value);
  const qTrim = q.trim();
  const aramaAcik = !!searchable || !!creatable;
  const liste = aramaAcik && qTrim ? options.filter((o) => matchesSearch(o.label, qTrim)) : options;
  const sizeCls = size === 'sm' ? 'isg-input-sm' : '';
  // Türkçe-duyarlı TEK normalize ile karşılaştır: "ALI" ↔ "Ali" eşleşir; mevcut kayıt
  // yanlışlıkla "Ekle: ..." diye YENİ kayıt gibi ÖNERİLMEZ (search tek-kaynak kuralı).
  const qKey = normalizeForSearch(qTrim);
  const canCreate = !!creatable && qTrim !== '' && !options.some((o) => normalizeForSearch(o.label) === qKey);

  const kapat = () => { setAcik(false); setQ(''); };
  const sec = (v: string) => { onChange(v); kapat(); };

  return (
    <div className={`w-full ${className}`}>
      {label && (
        <label className="isg-form-label">
          {label}
          {required && <Zorunlu />}
        </label>
      )}
      <button
        ref={btnRef}
        type="button"
        disabled={disabled}
        onClick={() => { if (!disabled) setAcik((o) => !o); }}
        aria-haspopup="listbox"
        aria-expanded={acik}
        className={`isg-input ${sizeCls} flex w-full items-center justify-between gap-2 text-left cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <span className={`truncate ${secili ? 'text-foreground-950' : 'text-foreground-400'}`}>{secili ? secili.label : placeholder}</span>
        <i className={`ri-arrow-down-s-line flex-shrink-0 text-foreground-400 transition-transform ${acik ? 'rotate-180' : ''}`} />
      </button>

      <DropdownPanel
        open={acik}
        anchorRef={btnRef}
        onClose={kapat}
        role="listbox"
        className="isg-popover"
      >
        {aramaAcik && (
          <div className="border-b isg-divider p-1.5">
            <input
              autoFocus
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  if (liste.length > 0) sec(liste[0].value);
                  else if (canCreate) sec(q.trim());
                }
                if (e.key === 'Escape') kapat();
              }}
              placeholder={creatable ? 'Yazın veya listeden seçin...' : 'Ara...'}
              className="isg-input isg-input-sm w-full"
            />
          </div>
        )}
        <div className="min-h-0 flex-1 overflow-y-auto p-1">
          {liste.length === 0 && !canCreate && <p className="px-2.5 py-2 text-xs text-foreground-400">Sonuç yok</p>}
          {liste.map((o) => (
            <button
              key={o.value}
              type="button"
              role="option"
              aria-selected={o.value === value}
              onClick={() => sec(o.value)}
              data-active={o.value === value ? 'true' : 'false'}
              className="isg-cat-item justify-between"
            >
              <span className="truncate">{o.label}</span>
              {o.value === value && <i className="ri-check-line text-primary-500" />}
            </button>
          ))}
          {canCreate && (
            <button
              type="button"
              onClick={() => sec(q.trim())}
              className="flex w-full items-center gap-1.5 rounded px-2.5 py-1.5 text-left text-xs font-medium text-primary-600 hover:bg-primary-500/10 cursor-pointer dark:text-primary-300"
            >
              <i className="ri-add-line" /> Ekle: {q.trim()}
            </button>
          )}
        </div>
      </DropdownPanel>
    </div>
  );
}

// ── RwButton (kanonik Button sözleşmesine delege) ────────────────────────────
type RwVariant = 'primary' | 'secondary' | 'ghost' | 'outline' | 'danger';

interface RwButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: RwVariant;
  size?: 'sm' | 'md';
  icon?: string;
  iconAfter?: string;
  block?: boolean;
}

const BTN_VARIANT: Record<RwVariant, string> = {
  primary: 'isg-btn-primary',
  secondary: 'isg-btn-secondary',
  ghost: 'isg-btn-ghost',
  outline: 'isg-btn-outline',
  danger: 'isg-btn-danger',
};

export function RwButton({ variant = 'ghost', size = 'md', icon, iconAfter, block, className = '', children, ...rest }: RwButtonProps) {
  const sizeCls = size === 'sm' ? 'isg-btn-sm' : '';
  return (
    <button
      type="button"
      className={`isg-btn ${BTN_VARIANT[variant]} ${sizeCls} ${block ? 'w-full' : ''} ${className}`}
      {...rest}
    >
      {icon && <i className={icon} />}
      {children}
      {iconAfter && <i className={iconAfter} />}
    </button>
  );
}

// ── RwIconButton (kanonik ikon buton sözleşmesine delege) ─────────────────────
interface RwIconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  icon: string;
  size?: 'sm' | 'md';
  tone?: 'default' | 'danger';
}

export function RwIconButton({ icon, size = 'sm', tone = 'default', className = '', ...rest }: RwIconButtonProps) {
  const sizeCls = size === 'sm' ? 'isg-btn-sm' : '';
  const toneCls = tone === 'danger' ? 'text-danger-600 hover:bg-danger-500/12 hover:text-danger-600' : '';
  return (
    <button
      type="button"
      className={`isg-btn isg-btn-icon ${sizeCls} ${toneCls} ${className}`}
      {...rest}
    >
      <i className={icon} />
    </button>
  );
}

// ── RwCard (kanonik kart sözleşmesine delege) ────────────────────────────────
export function RwCard({ children, className = '', title, icon }: { children: ReactNode; className?: string; title?: string; icon?: string }) {
  return (
    <div className={`isg-card overflow-hidden ${className}`}>
      {title && (
        <div className="flex items-center gap-1.5 border-b isg-divider px-3 py-2.5">
          {icon && <i className={`${icon} text-sm text-primary-500`} />}
          <h3 className="isg-text-card-title text-foreground-950">{title}</h3>
        </div>
      )}
      {children}
    </div>
  );
}

// ── RwTabs (kanonik SegmentedControl'e delege) ───────────────────────────────
interface RwTabItem { key: string; label: string; count?: number }

export function RwTabs({ tabs, active, onChange }: { tabs: RwTabItem[]; active: string; onChange: (k: string) => void }) {
  return (
    <SegmentedControl
      size="sm"
      value={active}
      onChange={(v) => onChange(String(v))}
      options={tabs.map((t) => ({ value: t.key, label: t.label, count: t.count }))}
      ariaLabel="Görünüm"
    />
  );
}

// ── RwChip (kanonik Chip'e delege — tek kaynak) ──────────────────────────────
// Renk/geometri YEREL tanımlanmaz; Shared UI Chip sözleşmesinden gelir.
export function RwChip({ children, onRemove }: { children: ReactNode; onRemove?: () => void }) {
  return <Chip onRemove={onRemove}>{children}</Chip>;
}

// ── RwInfoBanner (kanonik Alert'e delege — tek kaynak) ───────────────────────
// Not: Renk/ikon/kenarlık YEREL tanımlanmaz; Shared UI Alert sözleşmesinden
// (info varyantı) gelir. Böylece tema geçişinde tüm bilgi bantları birlikte uyar.
export function RwInfoBanner({ icon, title, children, action }: { icon: string; title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <Alert variant="info" icon={icon} title={title} action={action} className="flex-shrink-0">
      {children}
    </Alert>
  );
}

// ── RwStepper (kanonik WizardStepper'a delege) ───────────────────────────────
export function RwStepper({ steps, current, onStepClick }: { steps: string[]; current: number; onStepClick?: (i: number) => void }) {
  return (
    <WizardStepper
      steps={steps.map((s) => ({ title: s }))}
      current={current}
      onStepClick={onStepClick}
    />
  );
}

// ── RwPagination (kanonik Pagination'a delege — tek kaynak) ──────────────────
// Eski imza (total/page/pageSize/onPage) korunur; görsel/performans artık
// Shared UI Pagination'dan gelir. Böylece tek bir yerde sayfalama değişince
// sihirbaz listeleri de otomatik güncellenir.
export function RwPagination({ total, page, pageSize, onPage }: { total: number; page: number; pageSize: number; onPage: (p: number) => void }) {
  return (
    <Pagination
      currentPage={page}
      totalPages={Math.max(1, Math.ceil(total / pageSize))}
      pageSize={pageSize}
      totalItems={total}
      onPageChange={onPage}
      className="flex-shrink-0 pt-3"
    />
  );
}

// ── RwSectionTitle (kanonik SectionTitle'a delege — tek kaynak) ─────────────
// Tipografi/boşluk YEREL tanımlanmaz; Shared UI SectionTitle sözleşmesinden gelir.
export function RwSectionTitle({ title, desc, right }: { title: string; desc?: string; right?: ReactNode }) {
  return <SectionTitle title={title} desc={desc} right={right} />;
}