import { hucreSinifi, riskPuani } from './riskSihirbazTypes';

// ─────────────────────────────────────────────────────────────────────────────
// MİNİ 5x5 RİSK MATRİSİ GÖRSELİ (yöntem seçim kartı için)
//
// Yöntem seçim ekranındaki "5x5 Matris" kartının içinde gösterilen küçük,
// salt-görsel matris. SATIR = Şiddet (5 → 1), KOLON = Olasılık (1 → 5).
// Hücre rengi yeşil → sarı → turuncu → kırmızı geçişini merkezi tokenlardan
// alır (hucreSinifi). Etkileşim YOKTUR; yalnızca referans görseldeki görünümü
// sağlar. Sayfaya özel renk sistemi kurulmaz.
// ─────────────────────────────────────────────────────────────────────────────

const SATIRLAR = [5, 4, 3, 2, 1];
const KOLONLAR = [1, 2, 3, 4, 5];

export default function RiskMatrisGorseli() {
  return (
    <div className="w-full select-none" aria-hidden="true">
      <p className="text-center text-[10px] font-semibold text-foreground-500">Olasılık</p>
      <div className="mt-1 flex gap-1">
        {/* Dikey eksen etiketi */}
        <div className="flex w-4 items-center justify-center">
          <span
            className="text-[9px] font-semibold uppercase tracking-wide text-foreground-500"
            style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
          >
            Şiddet
          </span>
        </div>

        <div className="min-w-0 flex-1">
          {/* Şiddet eksen değerleri */}
          <div className="mb-1 flex gap-1 pl-4">
            {KOLONLAR.map((s) => (
              <span key={s} className="flex-1 text-center text-[9px] font-medium text-foreground-400">{s}</span>
            ))}
          </div>

          {SATIRLAR.map((o) => (
            <div key={o} className="mb-1 flex gap-1 last:mb-0">
              <span className="flex w-4 items-center justify-center text-[9px] font-medium text-foreground-400">{o}</span>
              <div className="grid min-w-0 flex-1 grid-cols-5 gap-1">
                {KOLONLAR.map((s) => (
                  <span key={s} className={`aspect-square rounded-[2px] ${hucreSinifi(riskPuani(s, o))}`} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}