import { useCallback, useEffect, useMemo, useState } from 'react';
import Alert from '@/components/ui/Alert';
import { useToastActions } from '@/hooks/useToast';
import { aiTehlikeOnerileri } from '@/lib/riskAiService';
import { pdfIndir } from '@/lib/riskRaporService';
import Adim1TemelBilgiler from '@/components/feature/risk/adimlar/Adim1TemelBilgiler';
import Adim2Tehlikeler from '@/components/feature/risk/adimlar/Adim2Tehlikeler';
import Adim3Kontroller from '@/components/feature/risk/adimlar/Adim3Kontroller';
import Adim4Degerlendirme from '@/components/feature/risk/adimlar/Adim4Degerlendirme';
import Adim5Rapor from '@/components/feature/risk/adimlar/Adim5Rapor';
import type { ManuelRiskVerisi } from '@/components/feature/risk/ManuelRiskModal';
import { workspaceKaydet, workspaceTemizle, workspaceYukle } from '@/components/feature/risk/riskWorkspaceStore';
import {
  ADIM_BASLIKLARI,
  benzerMi,
  bosRisk,
  bosTemelBilgiler,
  bosWorkspace,
  yeniId,
  type AiOneri,
  type RiskItem,
  type RiskWorkspace,
  type TemelBilgiler,
} from '@/components/feature/risk/riskSihirbazTypes';
import { RwButton, RwStepper } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// RİSK DEĞERLENDİRMESİ SİHİRBAZI — KABUK (Referans görseller)
//
// 5 adım TEK merkezi modal içinde yönetilir. Kabuk (stepper + gövde + footer)
// bu sihirbaza ÖZEL yazılmıştır; global Shared UI stepper/butonları KULLANILMAZ.
// Tüm adımlar AYNI workspace'i paylaşır; adım 2'de oluşan risk 3 ve 4'e otomatik
// yansır, 5'in çıktısı rapora gider. Workspace yerel (IndexedDB) saklanır.
// ─────────────────────────────────────────────────────────────────────────────

interface RiskSihirbazContentProps {
  onClose: () => void;
}

export default function RiskSihirbazContent({ onClose }: RiskSihirbazContentProps) {
  const { addToast } = useToastActions();
  const [ws, setWs] = useState<RiskWorkspace>(() => bosWorkspace());
  const [adim, setAdim] = useState(0);
  const [hazir, setHazir] = useState(false);
  const [aiYukleniyor, setAiYukleniyor] = useState(false);
  const [sifirlaOnay, setSifirlaOnay] = useState(false);
  const [raporYukleniyor, setRaporYukleniyor] = useState(false);

  useEffect(() => {
    let iptal = false;
    void workspaceYukle().then((kayit) => {
      if (iptal) return;
      if (kayit && Array.isArray(kayit.riskler)) {
        // Eski kayıtlarda bulunmayabilecek alanlara karşı DERİN birleştirme:
        // aksi halde temel.imzacilar / ekip / dokumanlar undefined kalır ve
        // adımlar (özellikle 5. adım) render sırasında çöker.
        const temelKayit = { ...bosTemelBilgiler(), ...(kayit.temel || {}) };
        setWs({
          ...bosWorkspace(),
          ...kayit,
          temel: {
            ...temelKayit,
            ekip: Array.isArray(temelKayit.ekip) ? temelKayit.ekip : [],
            dokumanlar: Array.isArray(temelKayit.dokumanlar) ? temelKayit.dokumanlar : [],
            imzacilar: Array.isArray(temelKayit.imzacilar) ? temelKayit.imzacilar : [],
          },
          riskler: kayit.riskler,
          aiOnerileri: Array.isArray(kayit.aiOnerileri) ? kayit.aiOnerileri : [],
        });
        setAdim(Math.max(0, Math.min(4, kayit.aktifAdim ?? 0)));
      }
      setHazir(true);
    });
    return () => { iptal = true; };
  }, []);

  useEffect(() => {
    if (!hazir) return;
    const t = setTimeout(() => { void workspaceKaydet({ ...ws, aktifAdim: adim }); }, 500);
    return () => clearTimeout(t);
  }, [ws, adim, hazir]);

  const temelGuncelle = useCallback((patch: Partial<TemelBilgiler>) => {
    setWs((p) => ({ ...p, temel: { ...p.temel, ...patch } }));
  }, []);

  const manuelEkle = useCallback((veri: ManuelRiskVerisi) => {
    setWs((p) => ({ ...p, riskler: [...p.riskler, { ...bosRisk(veri.bolum, 'manuel'), ...veri }] }));
    addToast({ title: 'Risk eklendi', message: 'Manuel risk listeye eklendi.', type: 'success' });
  }, [addToast]);

  const aiEkle = useCallback((o: AiOneri) => {
    const yeniRisk: RiskItem = {
      ...bosRisk(o.bolum, 'ai'),
      kategori: o.kategori,
      tehlike: o.tehlike,
      risk: o.risk,
      olasiSonuc: o.olasiSonuc,
      mevcutKontroller: o.mevcutKontroller,
      onerilenKontroller: o.onerilenKontroller,
      olasilik: o.olasilik,
      siddet: o.siddet,
    };
    setWs((p) => {
      if (p.riskler.some((r) => benzerMi(`${r.tehlike} ${r.risk}`, `${o.tehlike} ${o.risk}`))) return p;
      return { ...p, riskler: [...p.riskler, yeniRisk] };
    });
  }, []);

  const topluEkle = useCallback((liste: RiskItem[]) => {
    setWs((p) => {
      const yeniler = liste
        .filter((r) => r.tehlike && r.risk)
        .filter((r) => !p.riskler.some((x) => benzerMi(`${x.tehlike} ${x.risk}`, `${r.tehlike} ${r.risk}`)))
        .map((r) => ({ ...r, id: r.id || yeniId() }));
      return { ...p, riskler: [...p.riskler, ...yeniler] };
    });
  }, []);

  const guncelle = useCallback((id: string, patch: Partial<RiskItem>) => {
    setWs((p) => ({ ...p, riskler: p.riskler.map((r) => (r.id === id ? { ...r, ...patch } : r)) }));
  }, []);

  const sil = useCallback((id: string) => {
    setWs((p) => ({ ...p, riskler: p.riskler.filter((r) => r.id !== id) }));
  }, []);

  const aiYenile = useCallback(async (kategori: string, alan: string) => {
    setAiYukleniyor(true);
    const cevap = await aiTehlikeOnerileri({
      firma: ws.temel.firma,
      tesis: ws.temel.tesis,
      kapsam: ws.temel.kapsam,
      nace: ws.temel.nace,
      tehlikeSinifi: ws.temel.tehlikeSinifi,
      kategori,
      alan,
      mevcutRiskler: ws.riskler.map((r) => `${r.tehlike} — ${r.risk}`),
      oncekiOneriler: ws.aiOnerileri.map((o) => `${o.tehlike} — ${o.risk}`),
    });
    setAiYukleniyor(false);
    if (!cevap.ok || !cevap.oneriler) {
      addToast({ title: 'AI önerileri alınamadı', message: cevap.message || 'Lütfen tekrar deneyin.', type: 'error' });
      return;
    }
    setWs((p) => {
      const mevcut = [
        ...p.aiOnerileri.map((o) => `${o.tehlike} ${o.risk}`),
        ...p.riskler.map((r) => `${r.tehlike} ${r.risk}`),
      ];
      const benzersiz: AiOneri[] = [];
      cevap.oneriler!.forEach((o) => {
        const anahtar = `${o.tehlike} ${o.risk}`;
        const tekrar = mevcut.some((m) => benzerMi(m, anahtar)) || benzersiz.some((b) => benzerMi(`${b.tehlike} ${b.risk}`, anahtar));
        if (!tekrar) benzersiz.push({ ...o, id: yeniId('ai') });
      });
      return { ...p, aiOnerileri: [...p.aiOnerileri, ...benzersiz] };
    });
    addToast({ title: 'AI önerileri hazır', message: 'Yeni öneriler listenin altına eklendi.', type: 'success' });
  }, [ws.temel, ws.riskler, ws.aiOnerileri, addToast]);

  const adimGecerli = useCallback((idx: number): string | null => {
    if (idx === 0) {
      if (!ws.temel.calismaAdi.trim()) return 'Çalışma Adı zorunludur.';
      if (!ws.temel.tesis.trim()) return 'Tesis / İş yeri zorunludur.';
      if (!ws.temel.kapsam.trim()) return 'Çalışmanın Kapsamı zorunludur.';
    }
    if (idx === 1 && ws.riskler.length === 0) return 'Devam etmek için en az bir risk ekleyin.';
    return null;
  }, [ws.temel, ws.riskler]);

  const sonraki = useCallback(() => {
    const hata = adimGecerli(adim);
    if (hata) { addToast({ title: 'Eksik bilgi', message: hata, type: 'warning' }); return; }
    setAdim((a) => Math.min(4, a + 1));
  }, [adim, adimGecerli, addToast]);

  const raporOlustur = useCallback(async () => {
    if (ws.riskler.length === 0) {
      addToast({ title: 'Risk listesi boş', message: 'Rapor için en az bir risk gerekir.', type: 'warning' });
      return;
    }
    if (raporYukleniyor) return;
    setRaporYukleniyor(true);
    try {
      await pdfIndir({ temel: ws.temel, riskler: ws.riskler });
      addToast({ title: 'Rapor hazır', message: 'PDF indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Rapor oluşturulamadı', message: 'Beklenmeyen bir hata oluştu.', type: 'error' });
    } finally {
      setRaporYukleniyor(false);
    }
  }, [ws.temel, ws.riskler, addToast, raporYukleniyor]);

  /** Kullanıcı sıfırlarsa tüm geçici çalışma silinir ve baştan başlanır. */
  const sifirla = useCallback(async () => {
    await workspaceTemizle();
    setWs(bosWorkspace());
    setAdim(0);
    setSifirlaOnay(false);
    addToast({ title: 'Çalışma sıfırlandı', message: 'Yeni bir değerlendirmeye başlayabilirsiniz.', type: 'success' });
  }, [addToast]);

  const stepperAdimlari = useMemo(() => ADIM_BASLIKLARI, []);

  if (!hazir) {
    return (
      <div className="flex min-h-0 flex-1 items-center justify-center">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      {/* Sabit stepper — sihirbaza özel */}
      <div className="flex-shrink-0 border-b border-background-300/25 dark:border-background-400/35">
        <RwStepper steps={stepperAdimlari} current={adim} onStepClick={(idx) => { if (idx < adim) setAdim(idx); }} />
      </div>

      {/* Gövde */}
      <div className="flex min-h-0 flex-1 flex-col overflow-hidden px-5 py-4">
        {adim === 0 ? (
          <div className="flex min-h-0 flex-1 flex-col">
            <Adim1TemelBilgiler temel={ws.temel} onChange={temelGuncelle} />
          </div>
        ) : adim === 1 ? (
          <Adim2Tehlikeler
            riskler={ws.riskler}
            aiOnerileri={ws.aiOnerileri}
            aiYukleniyor={aiYukleniyor}
            onAiYenile={aiYenile}
            onAiEkle={aiEkle}
            onManuelEkle={manuelEkle}
            onTopluEkle={topluEkle}
            onGuncelle={guncelle}
            onSil={sil}
          />
        ) : adim === 2 ? (
          <Adim3Kontroller riskler={ws.riskler} onGuncelle={guncelle} />
        ) : adim === 3 ? (
          <Adim4Degerlendirme riskler={ws.riskler} onGuncelle={guncelle} />
        ) : (
          <Adim5Rapor temel={ws.temel} riskler={ws.riskler} onTemelChange={temelGuncelle} />
        )}
      </div>

      {/* Sabit footer */}
      <div className="flex flex-shrink-0 items-center justify-between gap-2 border-t border-background-300/25 px-5 py-3 dark:border-background-400/35">
        <div className="flex items-center gap-2">
          <RwButton variant="ghost" icon="ri-close-line" onClick={onClose}>İptal</RwButton>
          {sifirlaOnay ? (
            <Alert
              variant="danger"
              action={(
                <div className="flex items-center gap-2">
                  <RwButton variant="primary" size="sm" icon="ri-refresh-line" onClick={() => void sifirla()}>Evet, Sıfırla</RwButton>
                  <RwButton variant="ghost" size="sm" onClick={() => setSifirlaOnay(false)}>Vazgeç</RwButton>
                </div>
              )}
            >
              Tüm çalışma silinsin mi?
            </Alert>
          ) : (
            <RwButton variant="ghost" icon="ri-refresh-line" onClick={() => setSifirlaOnay(true)}>Sıfırla</RwButton>
          )}
        </div>
        <div className="flex items-center gap-2">
          {adim > 0 && (
            <RwButton variant="secondary" icon="ri-arrow-left-line" onClick={() => setAdim((a) => Math.max(0, a - 1))}>
              Önceki Adım
            </RwButton>
          )}
          {adim < 4 ? (
            <RwButton variant="primary" iconAfter="ri-arrow-right-line" onClick={sonraki}>Sonraki Adım</RwButton>
          ) : (
            <RwButton variant="primary" icon="ri-file-download-line" onClick={() => void raporOlustur()}>{raporYukleniyor ? 'Oluşturuluyor...' : 'Raporu Oluştur ve İndir'}</RwButton>
          )}
        </div>
      </div>
    </div>
  );
}