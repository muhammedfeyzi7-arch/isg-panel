import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import Search from '@/components/ui/Search';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import EvrakUploadModal from '@/components/feature/evrak/EvrakUploadModal';
import EkipUyeBelgeModal from './EkipUyeBelgeModal';
import {
  adSoyadUret,
  ataAcilDurum,
  ekipPersonelHavuzu,
  fetchEkipYapisi,
  kaydetEkip,
  kaldirAcilDurum,
  setAcilDurumLideri,
  silEkip,
  friendlyEkipError,
  fetchAcilDurumKoordinatoru,
  setAcilDurumKoordinatoru,
  kaldirAcilDurumKoordinatoru,
  type EkipYapisi,
  type EkipUye,
  type AcilDurumKoordinator,
} from '@/lib/acilDurumEkipService';
import {
  generateEkipPlaniWord,
  generateAtamaYazisiWord,
  indirUretilenBelge,
  fetchEkipBelgeleri,
  fetchEkipTurId,
  type BelgeEkip,
} from '@/lib/acilDurumEkipBelge';
import { uploadUretilenBelge, EVRAK_SOURCE_TYPE } from '@/lib/evrakSource';
import { fetchEvraklarPage, getEvrakUrl, friendlyEvrakError, evrakStatusLabel, type EvrakData } from '@/lib/evrakService';
import { ACIL_DURUM_EKIPLERI_TUR_KODU, type AcilDurumPersonel } from '@/lib/acilDurumService';

interface Props {
  firmaId: string;
  role: 'uzman' | 'firma';
  onClose: () => void;
  onChanged?: () => void;
}

const RENK_OPTIONS = [
  { value: 'danger', label: 'Kırmızı' },
  { value: 'primary', label: 'Ana Renk' },
  { value: 'success', label: 'Yeşil' },
  { value: 'accent', label: 'Vurgu' },
  { value: 'secondary', label: 'İkincil' },
];

const RENK_TILE: Record<string, string> = {
  danger: 'bg-danger-50 dark:bg-danger-500/15 text-danger-600 dark:text-danger-300',
  primary: 'bg-primary-100 dark:bg-primary-500/15 text-primary-600 dark:text-primary-300',
  success: 'bg-success-50 dark:bg-success-500/15 text-success-600 dark:text-success-300',
  accent: 'bg-accent-100 dark:bg-accent-500/20 text-accent-700 dark:text-accent-300',
  secondary: 'bg-secondary-100 dark:bg-secondary-500/20 text-secondary-700 dark:text-secondary-300',
};

const canManage = (role: string) => role === 'uzman' || role === 'firma';

function tarihGoster(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

/**
 * ACİL DURUM EKİPLERİ (referans görsel 1).
 *
 * Üst: özet istatistikler + tek tıkla "Tüm Ekip Listesi" ve "Görevlendirme Yazıları".
 * Sol: ekipler + koordinatör. Orta: seçili ekibin personeli (belge + atama işlemleri).
 * Sağ: belge şablonları (mevcut `acil-durum-belge` edge function ile üretim) + ekip belgeleri.
 *
 * Mevcut `acil_durum_atamalari` / `acil_durum_ekipleri` / `acil_durum_koordinatoru` veri
 * modeli korunur; yeni belge sistemi kurulmaz, evraklar merkezi tablodadır.
 */
export default function AcilDurumEkipYonetimiModal({ firmaId, role, onClose, onChanged }: Props) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();

  const [ekipler, setEkipler] = useState<EkipYapisi[]>([]);
  const [aktifCode, setAktifCode] = useState('');
  const [koordinator, setKoordinator] = useState<AcilDurumKoordinator | null>(null);
  const [dosyaSayilari, setDosyaSayilari] = useState<Record<string, number>>({});
  const [belgeler, setBelgeler] = useState<EvrakData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const belgeModalRef = useRef('');

  const aktif = useMemo(() => ekipler.find((e) => e.code === aktifCode) ?? ekipler[0] ?? null, [ekipler, aktifCode]);
  const yonetimVar = canManage(role);

  const yukle = useCallback(() => {
    setLoading(true);
    setError(null);
    Promise.all([
      fetchEkipYapisi(firmaId),
      fetchAcilDurumKoordinatoru(firmaId).catch(() => null),
      fetchEkipBelgeleri(firmaId).catch(() => [] as EvrakData[]),
    ])
      .then(([ek, koord, bel]) => {
        setEkipler(ek);
        setKoordinator(koord);
        setBelgeler(bel);
        setAktifCode((prev) => prev || ek[0]?.code || '');
      })
      .catch((e) => setError(friendlyEkipError(e)))
      .finally(() => setLoading(false));
  }, [firmaId]);

  useEffect(() => { yukle(); }, [yukle]);

  // Tüm ekip üyelerinin belge sayıları (özet "Belgeli Personel" + tablo "Belge" kolonu).
  useEffect(() => {
    const ids = Array.from(new Set(ekipler.flatMap((e) => e.uyeler.map((u) => u.personelId))));
    if (ids.length === 0) { setDosyaSayilari({}); return; }
    let alive = true;
    Promise.all(
      ids.map((pid) =>
        fetchEvraklarPage({ ownerType: 'personel', personelId: pid, pageSize: 1 })
          .then((p) => [pid, p.count] as const)
          .catch(() => [pid, 0] as const),
      ),
    ).then((pairs) => { if (alive) setDosyaSayilari(Object.fromEntries(pairs)); });
    return () => { alive = false; };
  }, [ekipler]);

  const refresh = useCallback(() => { yukle(); onChanged?.(); }, [yukle, onChanged]);

  // ── Özet ──
  const ozet = useMemo(() => {
    const tamam = ekipler.filter((e) => (e.gerekli != null ? e.uyeler.length >= e.gerekli : e.uyeler.length > 0)).length;
    const gerekli = ekipler.reduce((s, e) => s + (e.gerekli ?? 0), 0);
    const atanan = ekipler.reduce((s, e) => s + e.uyeler.length, 0);
    const eksik = ekipler.reduce((s, e) => s + (e.gerekli != null ? Math.max(0, e.gerekli - e.uyeler.length) : 0), 0);
    const uyeler = ekipler.flatMap((e) => e.uyeler);
    const belgeli = uyeler.filter((u) => (dosyaSayilari[u.personelId] ?? 0) > 0).length;
    return { tamam, toplam: ekipler.length, gerekli, atanan, eksik, belgeli, uyeToplam: uyeler.length };
  }, [ekipler, dosyaSayilari]);

  // ── Belge üretimi ──
  const belgeEkipleri = useCallback((): BelgeEkip[] =>
    ekipler.map((e) => ({
      code: e.code,
      ad: e.ad,
      gorevTanimi: e.gorevTanimi,
      gerekli: e.gerekli,
      atanan: e.uyeler.length,
      eksik: e.eksik,
      lider: (() => { const l = e.uyeler.find((u) => u.isLeader); return l ? { adSoyad: l.adSoyad } : null; })(),
      uyeler: e.uyeler.map((u) => ({ adSoyad: u.adSoyad, gorev: u.gorev, telefon: u.telefon, lider: u.isLeader })),
    })), [ekipler]);

  const ekipListesiIndir = useCallback(async () => {
    if (busy) return;
    setBusy('liste');
    try {
      const r = await generateEkipPlaniWord({
        firmaId,
        koordinator: koordinator
          ? { adSoyad: adSoyadUret(koordinator.ad, koordinator.soyad), gorev: koordinator.gorev, telefon: koordinator.telefon }
          : null,
        toplamaAlani: '',
        ekipler: belgeEkipleri(),
      });
      // Üretilen belge merkezi Evrak Merkezi'ne bağlanır (mevcut altyapı).
      try {
        const turId = await fetchEkipTurId();
        await uploadUretilenBelge({
          firmaId,
          documentTypeId: turId,
          title: 'Acil Durum Ekip Planı / Tüm Ekip Listesi',
          description: 'Acil durum ekipleri kurumsal ekip planı (üretilen belge).',
          sourceType: EVRAK_SOURCE_TYPE.ACIL_EKIP_PLANI,
          sourceId: firmaId,
          blob: r.blob,
          fileName: r.fileName,
          revizeEt: true,
        });
      } catch (upErr) {
        indirUretilenBelge(r);
        addToast({ title: 'Belge üretildi, kayıt eklenemedi', message: friendlyEvrakError(upErr), type: 'warning' });
        return;
      }
      indirUretilenBelge(r);
      refresh();
      addToast({ title: 'Belge oluşturuldu', message: 'Ekip planı oluşturuldu ve Evraklar\'a kaydedildi.', type: 'success' });
    } catch (e) {
      addToast({ title: 'Belge oluşturulamadı', message: friendlyEkipError(e), type: 'error' });
    } finally {
      setBusy(null);
    }
  }, [busy, firmaId, koordinator, belgeEkipleri, addToast, refresh]);

  const atamaYazisiUret = useCallback(async (uye: EkipUye, ekip: EkipYapisi) => {
    if (busy) return;
    setBusy(`atama-${uye.atamaId}`);
    try {
      const r = await generateAtamaYazisiWord({
        firmaId,
        personelId: uye.personelId,
        requirementCode: ekip.code,
        ekipAdi: ekip.ad,
        ekipGorevTanimi: ekip.gorevTanimi,
        ekipLideri: (ekip.uyeler.find((u) => u.isLeader)?.adSoyad) ?? '—',
        toplamUye: ekip.uyeler.length,
        koordinatorAd: koordinator ? adSoyadUret(koordinator.ad, koordinator.soyad) : '—',
        koordinatorGorev: koordinator?.gorev ?? '',
        gorevlendirmeGorevi: uye.rol,
        atamaTarihi: tarihGoster(new Date().toISOString()),
      });
      // Üretilen görevlendirme yazısı merkezi Evrak Merkezi'ne bağlanır.
      try {
        const turId = await fetchEkipTurId();
        await uploadUretilenBelge({
          firmaId,
          documentTypeId: turId,
          title: `${uye.adSoyad} — Görevlendirme Yazısı (${ekip.ad})`,
          description: 'Acil durum ekibi görevlendirme (atama) yazısı (üretilen belge).',
          sourceType: EVRAK_SOURCE_TYPE.ACIL_EKIP_GOREVLENDIRME,
          sourceId: firmaId,
          // Revizyon yalnızca AYNI personel+ekip görevlendirmesini kapsar; diğer
          // personellerin yazıları etkilenmez. (source_ref ayrıştırıcı)
          sourceRef: `${uye.personelId}:${ekip.code}`,
          blob: r.blob,
          fileName: r.fileName,
          revizeEt: true,
        });
      } catch (upErr) {
        indirUretilenBelge(r);
        addToast({ title: 'Belge üretildi, kayıt eklenemedi', message: friendlyEvrakError(upErr), type: 'warning' });
        return;
      }
      indirUretilenBelge(r);
      refresh();
      addToast({ title: 'Atama yazısı hazır', message: `${uye.adSoyad} için görevlendirme yazısı oluşturuldu ve Evraklar'a kaydedildi.`, type: 'success' });
    } catch (e) {
      addToast({ title: 'Belge oluşturulamadı', message: friendlyEkipError(e), type: 'error' });
    } finally {
      setBusy(null);
    }
  }, [busy, firmaId, koordinator, addToast, refresh]);

  const topluAtamaYazisi = useCallback(async () => {
    if (!aktif || aktif.uyeler.length === 0) {
      addToast({ title: 'Personel yok', message: 'Önce seçili ekibe personel atayın.', type: 'warning' });
      return;
    }
    for (const u of aktif.uyeler) {
      // Sıralı üretim — tarayıcı çoklu indirmeyi reddetmesin diye tek tek tetiklenir.
      await atamaYazisiUret(u, aktif);
    }
  }, [aktif, atamaYazisiUret, addToast]);

  // ── Atama işlemleri ──
  const atamaYap = useCallback(async (personelId: string, code: string) => {
    try {
      await ataAcilDurum(firmaId, personelId, code);
      addToast({ title: 'Atandı', message: 'Personel ekibe eklendi.', type: 'success' });
      refresh();
    } catch (e) {
      addToast({ title: 'Atanamadı', message: friendlyEkipError(e), type: 'error' });
    }
  }, [firmaId, addToast, refresh]);

  const atamaKaldir = useCallback(async (atamaId: string) => {
    try {
      await kaldirAcilDurum(firmaId, atamaId);
      addToast({ title: 'Kaldırıldı', message: 'Personel ekipten çıkarıldı.', type: 'success' });
      refresh();
    } catch (e) {
      addToast({ title: 'İşlem başarısız', message: friendlyEkipError(e), type: 'error' });
    }
  }, [firmaId, addToast, refresh]);

  const liderYap = useCallback(async (atamaId: string) => {
    try {
      await setAcilDurumLideri(firmaId, atamaId);
      addToast({ title: 'Ekip başı belirlendi', message: 'Ekip başı güncellendi.', type: 'success' });
      refresh();
    } catch (e) {
      addToast({ title: 'İşlem başarısız', message: friendlyEkipError(e), type: 'error' });
    }
  }, [firmaId, addToast, refresh]);

  // ── Alt modallar ──
  const ekipFormuAc = useCallback((ekip: EkipYapisi | null) => {
    if (!yonetimVar) return;
    const id = openModal({
      title: ekip ? 'Ekibi Düzenle' : 'Yeni Ekip',
      width: 560,
      minWidth: 420,
      minHeight: 420,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EkipFormu
          ekip={ekip}
          onSave={async (payload) => {
            try {
              await kaydetEkip({ firmaId, id: ekip?.ekipId ?? null, ...payload });
              addToast({ title: ekip ? 'Ekip güncellendi' : 'Ekip eklendi', message: payload.ad, type: 'success' });
              refresh();
              closeModal(id);
            } catch (e) {
              addToast({ title: 'Kaydedilemedi', message: friendlyEkipError(e), type: 'error' });
            }
          }}
          onClose={() => closeModal(id)}
        />
      ),
    });
  }, [openModal, closeModal, firmaId, yonetimVar, addToast, refresh]);

  const personelSecAc = useCallback((code: string, ekipAdi: string) => {
    const id = openModal({
      title: `Personele Ekle — ${ekipAdi}`,
      description: 'Firma personel havuzundan seçin.',
      width: 560,
      minWidth: 420,
      minHeight: 460,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <PersonelSecici
          firmaId={firmaId}
          onSelect={async (p) => {
            await atamaYap(p.id, code);
            closeModal(id);
          }}
          onClose={() => closeModal(id)}
        />
      ),
    });
  }, [openModal, closeModal, firmaId, atamaYap]);

  const belgeAc = useCallback((uye: EkipUye) => {
    const id = openModal({
      title: 'Personel Belgeleri',
      width: 600,
      minWidth: 440,
      minHeight: 460,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EkipUyeBelgeModal
          firmaId={firmaId}
          personelId={uye.personelId}
          personelAd={uye.adSoyad}
          onClose={() => closeModal(belgeModalRef.current)}
          onChanged={refresh}
        />
      ),
    });
    belgeModalRef.current = id;
  }, [openModal, closeModal, firmaId, refresh]);

  const ekipBelgeYukle = useCallback((previous?: EvrakData) => {
    const id = openModal({
      title: previous ? 'Yeni Sürüm Yükle' : 'Ekip Belgesi Yükle',
      description: previous ? previous.title : 'Firma Acil Durum kategorisine belge ekleyin.',
      width: 720,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <EvrakUploadModal
          role={role}
          initialFirmaId={firmaId}
          lockOwnerType="firma"
          allowedCodes={[ACIL_DURUM_EKIPLERI_TUR_KODU]}
          previousEvrak={previous}
          onClose={() => closeModal(id)}
          onUploaded={() => { refresh(); }}
        />
      ),
    });
  }, [openModal, closeModal, role, firmaId, refresh]);

  const koordinatorSecAc = useCallback(() => {
    const id = openModal({
      title: 'Koordinasyon Sorumlusu Seç',
      width: 560,
      minWidth: 420,
      minHeight: 460,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <PersonelSecici
          firmaId={firmaId}
          onSelect={async (p) => {
            try {
              await setAcilDurumKoordinatoru(firmaId, p.id);
              refresh();
            } catch (e) {
              addToast({ title: 'İşlem başarısız', message: friendlyEkipError(e), type: 'error' });
            }
            closeModal(id);
          }}
          onClose={() => closeModal(id)}
        />
      ),
    });
  }, [openModal, closeModal, firmaId, addToast, refresh]);

  const belgeAcUrl = useCallback(async (b: EvrakData) => {
    try {
      const url = await getEvrakUrl(b.id);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
      addToast({ title: 'Dosya açılamadı', message: friendlyEvrakError(e), type: 'error' });
    }
  }, [addToast]);

  const ekipSilOnay = useCallback((id: string) => {
    confirm({
      title: 'Ekibi Sil',
      message: 'Bu özel ekip pasifleştirilecek ve üyelerinin ataması kaldırılacak. Kayıt korunur (fiziksel silme yapılmaz).',
      variant: 'danger',
      confirmText: 'Evet, Sil',
      cancelText: 'Vazgeç',
      onConfirm: async () => {
        try {
          await silEkip(firmaId, id);
          addToast({ title: 'Ekip silindi', message: 'Ekip pasifleştirildi.', type: 'success' });
          setAktifCode('');
          refresh();
        } catch (e) {
          addToast({ title: 'Silinemedi', message: friendlyEkipError(e), type: 'error' });
        }
      },
    });
  }, [confirm, firmaId, addToast, refresh]);

  if (loading) {
    return <div className="flex justify-center py-16"><Loading size="lg" text="Ekipler yükleniyor..." /></div>;
  }
  if (error) {
    return <ErrorState message={error} onRetry={yukle} />;
  }

  const uyeColumns: TableColumn<EkipUye>[] = [
    {
      key: 'no',
      header: '#',
      width: '36px',
      render: (_u, i) => <span className="text-xs text-foreground-500 tabular-nums">{i + 1}</span>,
    },
    {
      key: 'adSoyad',
      header: 'Ad Soyad',
      render: (u) => (
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-7 h-7 rounded-full bg-background-200 dark:bg-background-300/50 text-foreground-600 text-[10px] font-semibold flex items-center justify-center flex-shrink-0">
            {u.adSoyad.slice(0, 2).toUpperCase()}
          </span>
          <div className="min-w-0">
            <span className="block text-sm font-medium text-foreground-900 truncate">{u.adSoyad}</span>
            <span className="block text-[11px] text-foreground-500 truncate">{u.gorev}</span>
          </div>
        </div>
      ),
    },
    {
      key: 'rol',
      header: 'Rol',
      render: (u) => <Badge variant={u.isLeader ? 'info' : 'secondary'}>{u.rol}</Badge>,
    },
    {
      key: 'telefon',
      header: 'Telefon',
      render: (u) => <span className="text-xs text-foreground-700 tabular-nums whitespace-nowrap">{u.telefon || '—'}</span>,
    },
    {
      key: 'belge',
      header: 'Belge',
      width: '82px',
      render: (u) => (
        <button
          type="button"
          onClick={() => belgeAc(u)}
          className="inline-flex items-center gap-1 text-xs text-primary-600 hover:text-primary-700 cursor-pointer whitespace-nowrap"
          title="Personel belgeleri"
        >
          <i className="ri-folder-line" />
          {dosyaSayilari[u.personelId] ?? 0}
        </button>
      ),
    },
    {
      key: 'islem',
      header: 'İşlem',
      width: '108px',
      render: (u) => (
        <div className="flex items-center gap-0.5">
          <button
            type="button"
            onClick={() => atamaYazisiUret(u, aktif as EkipYapisi)}
            disabled={busy === `atama-${u.atamaId}`}
            className="w-7 h-7 rounded-md flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer disabled:opacity-50"
            title="Görevlendirme yazısı oluştur"
            aria-label="Görevlendirme yazısı"
          >
            <i className={busy === `atama-${u.atamaId}` ? 'ri-loader-4-line animate-spin' : 'ri-file-text-line'} />
          </button>
          {yonetimVar && !u.isLeader && (
            <button
              type="button"
              onClick={() => liderYap(u.atamaId)}
              className="w-7 h-7 rounded-md flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer"
              title="Ekip başı yap"
              aria-label="Ekip başı yap"
            >
              <i className="ri-vip-crown-line" />
            </button>
          )}
          {yonetimVar && (
            <button
              type="button"
              onClick={() => atamaKaldir(u.atamaId)}
              className="w-7 h-7 rounded-md flex items-center justify-center text-danger-500 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer"
              title="Ekipten çıkar"
              aria-label="Ekipten çıkar"
            >
              <i className="ri-user-unfollow-line" />
            </button>
          )}
        </div>
      ),
    },
  ];

  return (
    <div className="flex flex-col gap-3">
      {/* Üst bar: başlık + aksiyonlar */}
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <h3 className="text-base font-semibold text-foreground-950">Acil Durum Ekipleri</h3>
          <p className="text-xs text-foreground-500 mt-0.5">Firma için acil durum ekiplerini yönetin, görevlendirme belgelerini oluşturun.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            className="whitespace-nowrap"
            leftIcon={<i className="ri-file-word-2-line" />}
            isLoading={busy === 'liste'}
            onClick={() => void ekipListesiIndir()}
          >
            Tüm Ekip Listesi İndir
          </Button>
          <Button
            variant="primary"
            size="sm"
            className="whitespace-nowrap"
            leftIcon={<i className="ri-file-user-line" />}
            onClick={() => void topluAtamaYazisi()}
          >
            Görevlendirme Yazıları
          </Button>
        </div>
      </div>

      {/* Özet istatistikler */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <OzetKarti
          ikon="ri-team-line"
          renk="primary"
          deger={`${ozet.tamam}/${ozet.toplam}`}
          etiket="Tamamlanan Ekip"
          alt={ozet.tamam === ozet.toplam ? 'Ağır uyumlu' : `${ozet.toplam - ozet.tamam} ekip eksik`}
          altDanger={ozet.tamam !== ozet.toplam}
        />
        <OzetKarti
          ikon="ri-group-line"
          renk="accent"
          deger={`${ozet.atanan}/${ozet.gerekli}`}
          etiket="Toplam Personel"
          alt={ozet.eksik > 0 ? `${ozet.eksik} kişi eksik` : 'Kadro tam'}
          altDanger={ozet.eksik > 0}
        />
        <OzetKarti
          ikon="ri-folder-shield-2-line"
          renk="success"
          deger={`${ozet.belgeli}/${ozet.uyeToplam}`}
          etiket="Belgeli Personel"
          alt={ozet.belgeli < ozet.uyeToplam ? `${ozet.uyeToplam - ozet.belgeli} belge eksik` : 'Belgeler tam'}
          altDanger={ozet.belgeli < ozet.uyeToplam}
        />
        <OzetKarti
          ikon="ri-calendar-check-line"
          renk="secondary"
          deger={tarihGoster(new Date().toISOString())}
          etiket="Son Kontrol"
          alt={koordinator ? `Koordinatör: ${adSoyadUret(koordinator.ad, koordinator.soyad)}` : 'Koordinatör atanmadı'}
          altDanger={!koordinator}
        />
      </div>

      {/* 3 kolonlu gövde */}
      <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,240px)_minmax(0,1fr)_minmax(0,280px)] gap-3">
        {/* SOL — Ekipler */}
        <div className="space-y-2">
          <div className="flex items-center justify-between gap-2">
            <span className="text-xs font-semibold text-foreground-500 uppercase tracking-wide">Ekipler</span>
            {yonetimVar && (
              <Button variant="secondary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-add-line" />} onClick={() => ekipFormuAc(null)}>
                Ekip Ekle
              </Button>
            )}
          </div>
          <div className="space-y-1.5 max-h-[460px] overflow-y-auto pr-0.5">
            {ekipler.map((e) => (
              <button
                key={e.code}
                type="button"
                onClick={() => setAktifCode(e.code)}
                className={`w-full flex items-center gap-2.5 p-2.5 rounded-lg border text-left transition-colors cursor-pointer ${
                  aktif?.code === e.code
                    ? 'border-primary-300 bg-primary-50 dark:border-primary-500/40 dark:bg-primary-500/10'
                    : 'border-background-200/70 dark:border-background-400/25 hover:bg-background-100 dark:hover:bg-background-200/50'
                }`}
              >
                <span className={`w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0 ${RENK_TILE[e.renk] ?? RENK_TILE.primary}`}>
                  <i className={e.ikon} />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block text-sm font-medium text-foreground-900 truncate">{e.ad}</span>
                  <span className="block text-[11px] text-foreground-500">
                    {e.uyeler.length} Kişi{e.gerekli != null ? ` / ${e.gerekli} gerekli` : ''}{e.ozel ? ' · Özel' : ''}
                  </span>
                </span>
                {e.eksik != null && e.eksik > 0
                  ? <Badge variant="danger">{e.eksik} eksik</Badge>
                  : <Badge variant="success">Tam</Badge>}
              </button>
            ))}
          </div>

          {/* Koordinasyon sorumlusu */}
          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
            <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide mb-2">Koordinasyon Sorumlusu</p>
            {koordinator ? (
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-foreground-900 truncate">{adSoyadUret(koordinator.ad, koordinator.soyad)}</p>
                  <p className="text-[11px] text-foreground-500 truncate">{koordinator.gorev}{koordinator.telefon ? ` · ${koordinator.telefon}` : ''}</p>
                </div>
                {yonetimVar && (
                  <button
                    type="button"
                    onClick={async () => {
                      try { await kaldirAcilDurumKoordinatoru(firmaId); refresh(); }
                      catch (e) { addToast({ title: 'İşlem başarısız', message: friendlyEkipError(e), type: 'error' }); }
                    }}
                    className="text-xs text-danger-600 hover:text-danger-700 cursor-pointer whitespace-nowrap"
                  >
                    Kaldır
                  </button>
                )}
              </div>
            ) : yonetimVar ? (
              <Button variant="secondary" size="sm" className="whitespace-nowrap w-full" leftIcon={<i className="ri-user-add-line" />} onClick={koordinatorSecAc}>
                Sorumlu Ata
              </Button>
            ) : (
              <p className="text-xs text-foreground-500">Belirlenmemiş.</p>
            )}
          </div>
        </div>

        {/* ORTA — Seçili ekip */}
        <div className="min-w-0 space-y-3">
          {!aktif ? (
            <EmptyState icon="ri-team-line" title="Ekip seçin" description="Soldan bir ekip seçin." />
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <span className={`w-9 h-9 rounded-md flex items-center justify-center flex-shrink-0 ${RENK_TILE[aktif.renk] ?? RENK_TILE.primary}`}>
                    <i className={aktif.ikon} />
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-foreground-950 truncate">{aktif.ad}</span>
                      {aktif.ozel && <Badge variant="secondary">Özel Ekip</Badge>}
                    </div>
                    <span className="text-[11px] text-foreground-500">
                      {aktif.uyeler.length} kişi{aktif.gerekli != null ? ` / ${aktif.gerekli} gerekli` : ''}
                    </span>
                  </div>
                </div>
                {yonetimVar && (
                  <div className="flex items-center gap-1.5">
                    {aktif.ozel && aktif.ekipId && (
                      <>
                        <Button variant="ghost" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-pencil-line" />} onClick={() => ekipFormuAc(aktif)}>Düzenle</Button>
                        <Button variant="ghost" size="sm" className="whitespace-nowrap text-danger-600" leftIcon={<i className="ri-delete-bin-line" />} onClick={() => ekipSilOnay(aktif.ekipId as string)}>Sil</Button>
                      </>
                    )}
                    <Button variant="primary" size="sm" className="whitespace-nowrap" leftIcon={<i className="ri-user-add-line" />} onClick={() => personelSecAc(aktif.code, aktif.ad)}>
                      Personel Ekle
                    </Button>
                  </div>
                )}
              </div>

              {aktif.gorevTanimi && (
                <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
                  <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide mb-1">Görev Tanımı</p>
                  <p className="text-xs text-foreground-700 leading-relaxed">{aktif.gorevTanimi}</p>
                </div>
              )}

              <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 overflow-hidden p-1">
                <Table
                  data={aktif.uyeler}
                  columns={uyeColumns}
                  keyExtractor={(u) => u.atamaId}
                  emptyState={<p className="text-sm text-foreground-500 text-center py-8">Bu ekipte henüz personel yok.</p>}
                />
              </div>
            </>
          )}
        </div>

        {/* SAĞ — Şablonlar + Belgeler */}
        <div className="space-y-3">
          {/* Belge şablonları */}
          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2">
            <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide">Belge Şablonları</p>
            <SablonSatiri
              ikon="ri-file-user-line"
              ad="Görevlendirme Yazısı"
              alt="Atama yazısı (mevzuata dayalı)"
              onOlustur={() => void topluAtamaYazisi()}
              disabled={!aktif || aktif.uyeler.length === 0}
            />
            <SablonSatiri
              ikon="ri-list-check-2"
              ad="Ekip Listesi"
              alt="Tüm ekip planı (Word)"
              onOlustur={() => void ekipListesiIndir()}
            />
          </div>

          {/* Ekip belgeleri */}
          <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <p className="text-[11px] font-semibold text-foreground-500 uppercase tracking-wide">Ekip Belgeleri</p>
              <button
                type="button"
                onClick={() => ekipBelgeYukle()}
                className="inline-flex items-center gap-1 text-xs font-semibold text-primary-600 hover:text-primary-700 cursor-pointer whitespace-nowrap"
              >
                <i className="ri-upload-2-line" /> Belge Yükle
              </button>
            </div>
            {belgeler.length === 0 ? (
              <p className="text-xs text-foreground-400 text-center py-4">Henüz belge yok.</p>
            ) : (
              <ul className="space-y-1.5 max-h-[240px] overflow-y-auto pr-0.5">
                {belgeler.map((b) => (
                  <li key={b.id} className="flex items-center gap-2 p-2 rounded-md border border-background-200/70 dark:border-background-400/25">
                    <i className="ri-file-text-line text-foreground-400 flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground-800 truncate">{b.title}</p>
                      <p className="text-[10px] text-foreground-500">
                        {evrakStatusLabel(b.status)} · {tarihGoster(b.documentDate ?? b.createdAt)}
                      </p>
                    </div>
                    <button type="button" onClick={() => void belgeAcUrl(b)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer" title="Görüntüle / İndir" aria-label="Görüntüle">
                      <i className="ri-eye-line text-xs" />
                    </button>
                    {yonetimVar && (
                      <button type="button" onClick={() => ekipBelgeYukle(b)} className="w-6 h-6 rounded flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer" title="Yeni sürüm yükle" aria-label="Yeni sürüm">
                        <i className="ri-refresh-line text-xs" />
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>

      {/* Alt bar */}
      <div className="flex items-center justify-between gap-2 pt-2 border-t isg-divider">
        <div>
          {aktif?.ozel && aktif.ekipId && yonetimVar && (
            <Button variant="ghost" size="sm" className="whitespace-nowrap text-danger-600" leftIcon={<i className="ri-delete-bin-line" />} onClick={() => ekipSilOnay(aktif.ekipId as string)}>
              Ekipi Kaldır
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2">
          <Button variant="primary" className="whitespace-nowrap" onClick={onClose}>Tamamla</Button>
        </div>
      </div>
    </div>
  );
}

/** Özet istatistik kartı. */
function OzetKarti({ ikon, renk, deger, etiket, alt, altDanger }: {
  ikon: string;
  renk: string;
  deger: string;
  etiket: string;
  alt: string;
  altDanger?: boolean;
}) {
  return (
    <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 bg-background-50 dark:bg-background-100/40 p-2.5 flex items-center gap-2.5">
      <span className={`w-9 h-9 rounded-md flex items-center justify-center flex-shrink-0 ${RENK_TILE[renk] ?? RENK_TILE.primary}`}>
        <i className={`${ikon} text-lg`} />
      </span>
      <div className="min-w-0">
        <p className="text-[11px] text-foreground-500 truncate">{etiket}</p>
        <p className="text-base font-semibold text-foreground-950 leading-tight truncate">{deger}</p>
        <p className={`text-[10px] truncate ${altDanger ? 'text-danger-600' : 'text-foreground-500'}`}>{alt}</p>
      </div>
    </div>
  );
}

/** Belge şablonu satırı. */
function SablonSatiri({ ikon, ad, alt, onOlustur, disabled }: {
  ikon: string;
  ad: string;
  alt: string;
  onOlustur: () => void;
  disabled?: boolean;
}) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-8 h-8 rounded-md bg-background-200/70 dark:bg-background-300/40 text-foreground-500 flex items-center justify-center flex-shrink-0">
        <i className={ikon} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-medium text-foreground-800 truncate">{ad}</p>
        <p className="text-[10px] text-foreground-500 truncate">{alt}</p>
      </div>
      <button
        type="button"
        onClick={onOlustur}
        disabled={disabled}
        className="inline-flex items-center gap-1 text-[11px] font-semibold text-primary-600 hover:text-primary-700 cursor-pointer whitespace-nowrap disabled:opacity-40 disabled:cursor-not-allowed"
      >
        <i className="ri-add-line" /> Oluştur
      </button>
    </div>
  );
}

/** Ekip oluşturma / düzenleme formu. */
function EkipFormu({
  ekip,
  onSave,
  onClose,
}: {
  ekip: EkipYapisi | null;
  onSave: (p: { ad: string; ikon: string; renk: string; gorevTanimi: string }) => void;
  onClose: () => void;
}) {
  const [ad, setAd] = useState(ekip?.ad ?? '');
  const [ikon, setIkon] = useState(ekip?.ikon ?? 'ri-team-line');
  const [renk, setRenk] = useState(ekip?.renk ?? 'primary');
  const [gorevTanimi, setGorevTanimi] = useState(ekip?.gorevTanimi ?? '');

  const ikonlar = ['ri-team-line', 'ri-fire-line', 'ri-hand-heart-line', 'ri-shield-cross-line', 'ri-first-aid-kit-line', 'ri-alarm-warning-line', 'ri-run-line', 'ri-radio-line', 'ri-tools-line', 'ri-flask-line'];

  return (
    <div className="flex flex-col">
      <div className="p-4 md:p-5 space-y-3 overflow-y-auto">
        <Input label="Ekip Adı" required value={ad} onChange={(e) => setAd(e.target.value)} placeholder="Örn: Tahliye Ekibi" />
        <Select label="Renk" options={RENK_OPTIONS} value={renk} onChange={(e) => setRenk(e.target.value)} />
        <div>
          <p className="text-sm font-medium text-foreground-800 mb-1.5">İkon</p>
          <div className="flex flex-wrap gap-1.5">
            {ikonlar.map((ic) => (
              <button
                key={ic}
                type="button"
                onClick={() => setIkon(ic)}
                className={`w-9 h-9 rounded-md flex items-center justify-center border cursor-pointer ${ikon === ic ? 'border-primary-400 bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-300' : 'border-background-300/60 dark:border-background-400/30 text-foreground-500 hover:bg-background-100 dark:hover:bg-background-200/50'}`}
              >
                <i className={ic} />
              </button>
            ))}
          </div>
        </div>
        <Textarea label="Görev Tanımı" value={gorevTanimi} onChange={(e) => setGorevTanimi(e.target.value)} placeholder="Bu ekibin acil durumdaki görevi..." />
      </div>
      <div className="flex items-center justify-end gap-2 border-t border-background-300/30 dark:border-background-400/25 px-4 py-3">
        <Button variant="ghost" className="whitespace-nowrap" onClick={onClose}>İptal</Button>
        <Button variant="primary" className="whitespace-nowrap" disabled={!ad.trim()} onClick={() => onSave({ ad: ad.trim(), ikon, renk, gorevTanimi })}>Kaydet</Button>
      </div>
    </div>
  );
}

/** Personel seçici (arama + liste). */
function PersonelSecici({
  firmaId,
  onSelect,
  onClose,
}: {
  firmaId: string;
  onSelect: (p: AcilDurumPersonel) => void;
  onClose: () => void;
}) {
  const [search, setSearch] = useState('');
  const [liste, setListe] = useState<AcilDurumPersonel[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    ekipPersonelHavuzu(firmaId, search)
      .then((p) => { if (alive) setListe(p); })
      .catch(() => { if (alive) setListe([]); })
      .finally(() => { if (alive) setLoading(false); });
    return () => { alive = false; };
  }, [firmaId, search]);

  return (
    <div className="flex flex-col gap-3">
      <Search placeholder="Personel ara..." value={search} onSearch={setSearch} size="sm" debounceMs={350} />
      <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 overflow-hidden">
        {loading ? (
          <div className="flex justify-center py-10"><Loading size="md" text="Aranıyor..." /></div>
        ) : liste.length === 0 ? (
          <EmptyState icon="ri-user-search-line" title="Personel yok" description="Kriterlere uygun aktif personel bulunamadı." />
        ) : (
          <ul className="divide-y divide-background-200/70 dark:divide-background-400/25 max-h-[320px] overflow-y-auto">
            {liste.map((p) => (
              <li key={p.id}>
                <button
                  type="button"
                  onClick={() => onSelect(p)}
                  className="w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-background-100 dark:hover:bg-background-200/50 cursor-pointer"
                >
                  <span className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 text-[10px] font-semibold flex items-center justify-center flex-shrink-0">
                    {adSoyadUret(p.ad, p.soyad).slice(0, 2).toUpperCase()}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-medium text-foreground-900 truncate">{adSoyadUret(p.ad, p.soyad)}</span>
                    <span className="block text-[11px] text-foreground-500 truncate">{p.gorev} · {p.sicilNo}</span>
                  </span>
                  <i className="ri-add-line text-primary-500" />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div className="flex justify-end">
        <Button variant="ghost" size="sm" className="whitespace-nowrap" onClick={onClose}>Kapat</Button>
      </div>
    </div>
  );
}