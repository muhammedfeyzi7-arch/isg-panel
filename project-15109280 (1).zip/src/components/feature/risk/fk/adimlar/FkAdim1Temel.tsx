import { useRef, useState } from 'react';
import {
  GECERLILIK_SECENEKLERI, TEHLIKE_SINIFLARI, tehlikeGecerlilikPatch, type TemelBilgiler,
} from '@/components/feature/risk/riskSihirbazTypes';
import { FK_METODU, FK_OLASILIK, FK_FREKANS, FK_SIDDET } from '@/components/feature/risk/fkTypes';
import { RwButton, RwChip, RwInput, RwSelect, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';
import RiskNaceSecici from '@/components/feature/risk/RiskNaceSecici';

// ─────────────────────────────────────────────────────────────────────────────
// FINE-KINNEY · ADIM 1 — TEMEL BİLGİLER (Referans görsel 1)
// Sol: iki kolonlu form → Çalışma Ekibi → İlgili Dokümanlar.
// Sağ: "Fine-Kinney Hakkında" kartı (O/F/S ölçekleri) + "Yardımcı Mod" notu.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: TemelBilgiler;
  onChange: (patch: Partial<TemelBilgiler>) => void;
}

const TESIS_SECENEKLERI = [
  'Ana Üretim Tesisi', 'Şube / Ek Tesis', 'Depo / Lojistik Merkezi', 'Laboratuvar',
  'Ofis / İdari Bina', 'Şantiye', 'Diğer',
];

export default function FkAdim1Temel({ temel, onChange }: Props) {
  const [ekipGirdi, setEkipGirdi] = useState('');
  const dosyaRef = useRef<HTMLInputElement>(null);

  const ekipEkle = () => {
    const ad = ekipGirdi.trim();
    if (!ad) return;
    if (!temel.ekip.includes(ad)) onChange({ ekip: [...temel.ekip, ad] });
    setEkipGirdi('');
  };

  const dosyaSec = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const adlar = Array.from(files).map((f) => f.name);
    onChange({ dokumanlar: Array.from(new Set([...temel.dokumanlar, ...adlar])) });
  };

  return (
    <div className="isg-scroll-pane min-h-0 flex-1 overflow-y-auto overflow-x-hidden pr-1">
      <div className="pb-3">
        <h2 className="text-sm font-bold text-foreground-950">1. Temel Bilgiler</h2>
        <p className="mt-1 text-xs text-foreground-500">
          Fine-Kinney risk değerlendirmesi çalışmasına ait temel bilgileri girin.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_300px]">
        {/* SOL — Form */}
        <div>
          <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-2">
            <RwInput
              label="Çalışma Adı" required
              value={temel.calismaAdi}
              onChange={(e) => onChange({ calismaAdi: e.target.value })}
              placeholder="Örn. Üretim Tesisi Fine-Kinney Risk Değerlendirmesi"
            />
            <RwInput
              label="Değerlendirme Tarihi" required type="date"
              value={temel.tarih}
              onChange={(e) => onChange({ tarih: e.target.value })}
            />

            <RwInput label="Firma" value={temel.firma} onChange={(e) => onChange({ firma: e.target.value })} placeholder="Firma ünvanı" />
            <RwSelect
              label="Tesis / İş Yeri" required searchable creatable
              options={TESIS_SECENEKLERI.map((v) => ({ value: v, label: v }))}
              value={temel.tesis} onChange={(v) => onChange({ tesis: v })} placeholder="Tesis seçiniz"
            />

            <RwSelect
              label="Değerlendirme Metodu" required disabled
              options={[{ value: FK_METODU, label: 'Fine-Kinney  ( O × F × S )' }]}
              value={FK_METODU} onChange={() => undefined}
            />
            <RwSelect
              label="Geçerlilik Süresi" required
              options={GECERLILIK_SECENEKLERI.map((v) => ({ value: v, label: v }))}
              value={temel.gecerlilik} onChange={(v) => onChange({ gecerlilik: v })}
            />

            <RwTextarea
              label="Çalışmanın Kapsamı" required maxLength={500}
              value={temel.kapsam} onChange={(e) => onChange({ kapsam: e.target.value })}
              placeholder="Kapsam dahilindeki alanlar, faaliyetler ve sınırlar..."
            />
            <RwTextarea
              label="Çalışmanın Amacı / Açıklama" maxLength={500}
              value={temel.amac} onChange={(e) => onChange({ amac: e.target.value })}
              placeholder="Çalışmanın amacı ve açıklaması..."
            />
          </div>

          {/* Künye */}
          <div className="mt-5">
            <span className="mb-1.5 block text-xs font-medium text-foreground-800">Firma ve Rapor Künye Bilgileri</span>
            <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-3">
              <RwInput label="Rapor No" value={temel.raporNo} onChange={(e) => onChange({ raporNo: e.target.value })} placeholder="Örn. FK-2026-001" />
              <RwSelect
                label="Tehlike Sınıfı" options={TEHLIKE_SINIFLARI.map((v) => ({ value: v, label: v }))}
                value={temel.tehlikeSinifi} onChange={(v) => onChange(tehlikeGecerlilikPatch(v))} placeholder="Seçiniz"
              />
              <RwInput label="Çalışan Sayısı" value={temel.calisanSayisi} onChange={(e) => onChange({ calisanSayisi: e.target.value })} placeholder="Örn. 85" />
              <RwInput label="İşveren" value={temel.isveren} onChange={(e) => onChange({ isveren: e.target.value })} placeholder="İşveren adı / ünvanı" />
              <RiskNaceSecici
                naceId={temel.naceId}
                onChange={(s) => onChange({ naceId: s.naceId, nace: s.nace, ...(s.tehlikeSinifi ? tehlikeGecerlilikPatch(s.tehlikeSinifi) : {}) })}
              />
              <RwInput label="Hazırlayan" value={temel.hazirlayan} onChange={(e) => onChange({ hazirlayan: e.target.value })} placeholder="İş güvenliği uzmanı" />
              <RwInput label="Onaylayan" value={temel.onaylayan} onChange={(e) => onChange({ onaylayan: e.target.value })} placeholder="İşveren / vekili" />
              <div className="md:col-span-3">
                <RwInput label="Adres / Lokasyon" value={temel.adres} onChange={(e) => onChange({ adres: e.target.value })} placeholder="Açık adres" />
              </div>
            </div>
          </div>

          {/* Ekip */}
          <div className="mt-5">
            <span className="mb-1.5 block text-xs font-medium text-foreground-800">Çalışma Ekibi</span>
            <div className="flex flex-wrap items-center gap-2 rounded-md border border-background-300/60 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
              {temel.ekip.map((ad) => (
                <RwChip key={ad} onRemove={() => onChange({ ekip: temel.ekip.filter((x) => x !== ad) })}>{ad}</RwChip>
              ))}
              <div className="flex items-center gap-1.5">
                <input
                  value={ekipGirdi}
                  onChange={(e) => setEkipGirdi(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); ekipEkle(); } }}
                  placeholder="İsim yazın"
                  className="h-8 w-40 rounded-md border border-background-300/70 bg-background-50 px-2.5 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
                />
                <RwButton size="sm" variant="outline" icon="ri-add-line" onClick={ekipEkle}>Ekle</RwButton>
              </div>
            </div>
          </div>

          {/* Dokümanlar */}
          <div className="mt-5 pb-2">
            <span className="block text-xs font-medium text-foreground-800">İlgili Dokümanlar (Opsiyonel)</span>
            <p className="mt-0.5 text-xs text-foreground-500">Bu çalışmada kullanılacak referans dokümanları ekleyin.</p>
            <div
              onClick={() => dosyaRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); dosyaSec(e.dataTransfer.files); }}
              className="mt-2 flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-md border border-dashed border-background-300/70 bg-background-100/60 px-4 py-6 text-center transition-colors hover:border-primary-400 dark:border-background-400/40 dark:bg-background-200/30"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                <i className="ri-upload-cloud-2-line text-xl" />
              </span>
              <p className="text-xs text-foreground-600">Dosya sürükleyin veya <span className="font-semibold text-primary-600 dark:text-primary-400">inceleyin</span></p>
              <p className="text-xs text-foreground-400">PDF, DOC, XLS · JPEG, PNG (Maks. 10 MB)</p>
            </div>
            {temel.dokumanlar.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {temel.dokumanlar.map((d) => (
                  <RwChip key={d} onRemove={() => onChange({ dokumanlar: temel.dokumanlar.filter((x) => x !== d) })}>
                    <i className="ri-file-line text-foreground-400" /> {d}
                  </RwChip>
                ))}
              </div>
            )}
            <input ref={dosyaRef} type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" className="hidden" onChange={(e) => { dosyaSec(e.target.files); e.target.value = ''; }} />
          </div>
        </div>

        {/* SAĞ — Fine-Kinney bilgi kolonu */}
        <aside className="space-y-3">
          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-information-fill text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Fine-Kinney Hakkında</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              Fine-Kinney yöntemi, risk puanını üç ayrı faktörün çarpımı ile hesaplar.
            </p>
            <div className="mt-2 rounded-md border border-background-300/50 bg-background-50 px-3 py-2 text-center text-xs font-bold text-foreground-900 dark:border-background-400/30 dark:bg-background-100/60">
              R = O × F × S
            </div>
          </div>

          <OlcekKart baslik="Olasılık (O)" renk="bg-primary-500" olcek={FK_OLASILIK} />
          <OlcekKart baslik="Frekans (F)" renk="bg-secondary-500" olcek={FK_FREKANS} />
          <OlcekKart baslik="Şiddet (S)" renk="bg-success-500" olcek={FK_SIDDET} />

          <div className="rounded-lg border border-warning-500/30 bg-warning-500/5 p-3">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-warning-500 text-inverse"><i className="ri-lightbulb-line text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Yardımcı Mod</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              Bu çalışma geçici olarak tutulur; kalıcı Risk Değerlendirmesi kaydı OLUŞTURULMAZ. İSG gereksinimlerine dahil edilmez.
            </p>
          </div>
        </aside>
      </div>
    </div>
  );
}

function OlcekKart({ baslik, renk, olcek }: { baslik: string; renk: string; olcek: { value: number; label: string }[] }) {
  return (
    <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
      <h3 className="text-xs font-bold text-foreground-950">{baslik}</h3>
      <ul className="mt-1.5 space-y-1">
        {olcek.map((o) => (
          <li key={o.value} className="flex items-start gap-2 text-xs">
            <span className={`mt-0.5 flex h-5 w-7 flex-shrink-0 items-center justify-center rounded text-[10px] font-bold text-inverse ${renk}`}>
              {String(o.value).replace('.', ',')}
            </span>
            <span className="leading-snug text-foreground-600">{o.label}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}