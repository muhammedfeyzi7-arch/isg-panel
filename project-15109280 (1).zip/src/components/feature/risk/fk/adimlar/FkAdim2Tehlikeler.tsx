import { useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { pickColumn } from '@/lib/excel/excelColumnPick';
import { readWorkbookSafe } from '@/lib/spreadsheet/readWorkbook';
import { assertWithinByteLimit, MAX_PARSE_BYTES } from '@/lib/spreadsheet/safeSheet';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import FkTehlikePaneli from '@/components/feature/risk/fk/FkTehlikePaneli';
import { matchesSearch } from '@/utils/turkishText';
import FkManuelRiskModal, { type FkManuelVerisi } from '@/components/feature/risk/fk/FkManuelRiskModal';
import {
  RISK_ALANLARI, RISK_KATEGORILERI, TUM_ALANLAR, TUM_KATEGORILER,
} from '@/components/feature/risk/riskSihirbazTypes';
import {
  FK_OLASILIK, FK_FREKANS, FK_SIDDET,
  fkPuan, fkPuanGoster, fkSeviyeBilgi, fkOlasiYakin, fkFrekansYakin, fkSiddetYakin,
  type FkAiOneri, type FkRiskItem,
} from '@/components/feature/risk/fkTypes';
import {
  RwButton, RwIconButton, RwInput, RwSectionTitle, RwSelect, RwTabs, RwTextarea,
} from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// FINE-KINNEY · ADIM 2 — TEHLİKELER VE RİSKLER (Referans görsel 2)
// Sol: AI Tehlike Önerileri · Sağ: risk listesi (O/F/S kolonları) + seçili risk.
// ─────────────────────────────────────────────────────────────────────────────

type Sekme = 'tumu' | 'ai' | 'manuel';
const IZGARA = '36px 104px minmax(140px,1.2fr) minmax(120px,1.05fr) minmax(140px,1.2fr) 60px 60px 54px 66px 92px 60px';
const TH = 'text-left text-xs font-semibold uppercase tracking-wide text-foreground-500 whitespace-nowrap';

const O_OPTS = FK_OLASILIK.map((x) => ({ value: String(x.value), label: String(x.value).replace('.', ',') }));
const F_OPTS = FK_FREKANS.map((x) => ({ value: String(x.value), label: String(x.value).replace('.', ',') }));
const S_OPTS = FK_SIDDET.map((x) => ({ value: String(x.value), label: String(x.value) }));

interface Props {
  riskler: FkRiskItem[];
  aiOnerileri: FkAiOneri[];
  aiYukleniyor: boolean;
  onAiYenile: (kategori: string, alan: string) => void;
  onAiEkle: (o: FkAiOneri) => void;
  onManuelEkle: (v: FkManuelVerisi) => void;
  onTopluEkle: (l: FkRiskItem[]) => void;
  onGuncelle: (id: string, patch: Partial<FkRiskItem>) => void;
  onSil: (id: string) => void;
}

export default function FkAdim2Tehlikeler({
  riskler, aiOnerileri, aiYukleniyor, onAiYenile, onAiEkle, onManuelEkle, onTopluEkle, onGuncelle, onSil,
}: Props) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const fileRef = useRef<HTMLInputElement>(null);

  const [sekme, setSekme] = useState<Sekme>('tumu');
  const [arama, setArama] = useState('');
  const [seciliId, setSeciliId] = useState('');
  const [aiAlan, setAiAlan] = useState(TUM_ALANLAR);
  const [aiKategori, setAiKategori] = useState(TUM_KATEGORILER);

  const aiAdet = riskler.filter((r) => r.kaynak === 'ai').length;
  const manuelAdet = riskler.filter((r) => r.kaynak === 'manuel').length;

  const filtreli = useMemo(() => {
    let liste = riskler;
    if (sekme === 'ai') liste = liste.filter((r) => r.kaynak === 'ai');
    if (sekme === 'manuel') liste = liste.filter((r) => r.kaynak === 'manuel');
    const q = arama.trim().toLocaleLowerCase('tr');
    if (q) liste = liste.filter((r) => matchesSearch(`${r.tehlike} ${r.risk} ${r.bolum} ${r.kategori}`, q));
    return liste;
  }, [riskler, sekme, arama]);

  const secili = riskler.find((r) => r.id === seciliId) ?? null;
  const ekliMetinler = riskler.map((r) => `${r.tehlike} ${r.risk}`);

  const tehlikeOptions = useMemo(() => Array.from(new Set(riskler.map((r) => r.tehlike).filter(Boolean))).map((v) => ({ value: v, label: v })), [riskler]);
  const riskOptions = useMemo(() => Array.from(new Set(riskler.map((r) => r.risk).filter(Boolean))).map((v) => ({ value: v, label: v })), [riskler]);

  const manuelAc = () => {
    const id = openModal({
      title: 'Manuel Risk Ekle',
      description: 'Fine-Kinney kriterlerini girin; risk puanı otomatik hesaplanır.',
      variant: 'form', width: 640, showFooter: false, closable: true, resizable: true, minimizable: true,
      content: <FkManuelRiskModal onClose={() => closeModal(id)} onKaydet={(veri) => { onManuelEkle(veri); closeModal(id); }} />,
    });
  };

  const excelAktar = (file: File) => {
    // GUV-19: Ayrıştırma öncesi boyut sınırı.
    try {
      assertWithinByteLimit(file.size, MAX_PARSE_BYTES);
    } catch (e) {
      addToast({ title: 'Dosya çok büyük', message: e instanceof Error ? e.message : 'Dosya boyutu sınırı aşıldı.', type: 'error' });
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const buf = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = readWorkbookSafe(buf);
        const sheet = wb.Sheets[wb.SheetNames[0]];
        if (!sheet) { addToast({ title: 'Dosya okunamadı', message: 'Excel içinde okunabilir bir sayfa bulunamadı.', type: 'error' }); return; }
        const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });
        const yeni: FkRiskItem[] = rows.map((row) => {
          const get = (keys: string[]) => pickColumn(row, keys);
          const sayi = (v: string) => parseFloat(v.replace(',', '.')) || 0;
          const o = fkOlasiYakin(sayi(get(['olasılık', 'olasilik', 'o'])) || 1);
          const f = fkFrekansYakin(sayi(get(['frekans', 'f'])) || 6);
          const s = fkSiddetYakin(sayi(get(['şiddet', 'siddet', 's'])) || 15);
          return {
            id: '', kaynak: 'excel' as const,
            bolum: get(['bölüm', 'bolum', 'alan']), kategori: get(['kategori']),
            tehlike: get(['tehlike']), risk: get(['risk']),
            olasiSonuc: get(['olası sonuç', 'sonuc', 'sonuç']),
            mevcutKontroller: get(['mevcut kontrol', 'kontrol']),
            onerilenKontroller: get(['önerilen', 'onerilen', 'aksiyon']),
            sorumlu: get(['sorumlu', 'sorumlu kişi', 'sorumlu kisi']),
            termin: get(['termin', 'bitiş', 'bitis', 'son tarih']),
            durum: get(['durum', 'statü', 'statu']) || 'Planlandı',
            olasilik: o, frekans: f, siddet: s,
            notlar: get(['not', 'açıklama', 'aciklama', 'notlar']),
          };
        }).filter((r) => r.tehlike && r.risk);
        if (yeni.length === 0) { addToast({ title: 'İçe aktarılamadı', message: 'Geçerli satır bulunamadı. Tehlike ve Risk kolonlarını kontrol edin.', type: 'warning' }); return; }
        onTopluEkle(yeni);
        addToast({ title: 'İçe aktarıldı', message: `${yeni.length} risk Excel’den eklendi.`, type: 'success' });
      } catch {
        addToast({ title: 'Dosya okunamadı', message: 'Excel dosyası ayrıştırılamadı.', type: 'error' });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="2. Tehlikeler ve Riskler"
        desc="İşyerinizdeki tehlikeleri belirleyin. Dilerseniz yapay zekâ önerilerinden faydalanabilir, önerileri düzenleyerek listeye ekleyebilirsiniz."
        right={(
          <div className="flex flex-shrink-0 items-center gap-1.5">
            <RwButton variant="primary" size="sm" icon={aiYukleniyor ? undefined : 'ri-sparkling-2-line'} disabled={aiYukleniyor} onClick={() => onAiYenile(aiKategori, aiAlan)}>
              {aiYukleniyor
                ? <><span className="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-current border-t-transparent" /> Hazırlanıyor...</>
                : 'AI Önerilerini Yenile'}
            </RwButton>
            <RwIconButton icon="ri-information-line" onClick={() => addToast({ title: 'AI Önerileri', message: 'Her yenilemede 10 yeni öneri üretilir; Fine-Kinney O/F/S değerleriyle gelir.', type: 'info' })} />
          </div>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-4 lg:grid-cols-[320px_minmax(0,1fr)]">
        <div className="min-h-0">
          <FkTehlikePaneli
            oneriler={aiOnerileri} yukleniyor={aiYukleniyor}
            alan={aiAlan} onAlanChange={setAiAlan} kategori={aiKategori} onKategoriChange={setAiKategori}
            onEkle={onAiEkle} ekliMetinler={ekliMetinler}
          />
        </div>

        <div className="flex min-h-0 flex-col gap-3">
          <div className="flex flex-shrink-0 flex-wrap items-center justify-between gap-2">
            <RwTabs
              active={sekme}
              onChange={(k) => setSekme(k as Sekme)}
              tabs={[
                { key: 'tumu', label: 'Risk Listesi', count: riskler.length },
                { key: 'ai', label: 'AI’dan Eklenenler', count: aiAdet },
                { key: 'manuel', label: 'Manuel Eklenenler', count: manuelAdet },
              ]}
            />
            <div className="flex flex-wrap items-center gap-2">
              <RwButton variant="primary" size="sm" icon="ri-add-line" onClick={manuelAc}>Manuel Risk Ekle</RwButton>
              <RwButton variant="outline" size="sm" icon="ri-delete-bin-line" disabled={!seciliId} onClick={() => { if (seciliId) { onSil(seciliId); setSeciliId(''); } }}>Seçilenleri Sil</RwButton>
              <RwButton variant="outline" size="sm" icon="ri-file-excel-2-line" onClick={() => fileRef.current?.click()}>Excel’den Aktar</RwButton>
              <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="sr-only" onChange={(e) => { const f = e.target.files?.[0]; if (f) excelAktar(f); e.target.value = ''; }} />
            </div>
          </div>

          <div className="isg-scroll-pane min-h-0 flex-1 overflow-auto rounded-lg border border-background-300/50 dark:border-background-400/30">
            <div style={{ minWidth: 1080 }}>
              <div
                className="sticky top-0 z-10 grid items-center border-b border-background-300/60 bg-background-200 px-2 py-2 dark:border-background-400/40 dark:bg-background-300/85"
                style={{ gridTemplateColumns: IZGARA, columnGap: '0.5rem' }}
              >
                <span className={`${TH} text-center`}>#</span>
                <span className={TH}>Bölüm / Alan</span>
                <span className={TH}>Tehlike</span>
                <span className={TH}>Risk</span>
                <span className={TH}>Olası Sonuç</span>
                <span className={`${TH} text-center`}>O</span>
                <span className={`${TH} text-center`}>F</span>
                <span className={`${TH} text-center`}>S</span>
                <span className={`${TH} text-center`}>Puan</span>
                <span className={`${TH} text-center`}>Seviye</span>
                <span className={`${TH} text-center`}>İşlem</span>
              </div>

              {filtreli.length === 0 && (
                <div className="px-3 py-12 text-center text-xs text-foreground-400">
                  {riskler.length === 0 ? 'Henüz risk yok. AI önerilerinden veya manuel olarak ekleyin.' : 'Filtreye uyan kayıt yok.'}
                </div>
              )}

              {filtreli.map((r, i) => {
                const puan = fkPuan(r.olasilik, r.frekans, r.siddet);
                const sev = fkSeviyeBilgi(puan);
                const aktif = seciliId === r.id;
                return (
                  <div
                    key={r.id}
                    onClick={() => setSeciliId(r.id)}
                    className={`grid cursor-pointer items-center border-b border-background-300/25 px-2 py-2 transition-colors dark:border-background-400/15 ${
                      aktif ? 'bg-primary-500/10' : i % 2 === 1 ? 'bg-background-100/70 dark:bg-background-200/25' : ''
                    } hover:bg-primary-500/[0.06]`}
                    style={{ gridTemplateColumns: IZGARA, columnGap: '0.5rem' }}
                  >
                    <span className="text-center text-xs text-foreground-500">{i + 1}</span>
                    <span className="truncate text-xs text-foreground-700" title={r.bolum}>{r.bolum || '—'}</span>
                    <span className="truncate text-xs font-medium text-foreground-950" title={r.tehlike}>{r.tehlike || '—'}</span>
                    <span className="truncate text-xs text-foreground-700" title={r.risk}>{r.risk || '—'}</span>
                    <span className="truncate text-xs text-foreground-600" title={r.olasiSonuc}>{r.olasiSonuc || '—'}</span>
                    <span className="text-center text-xs text-foreground-700">{String(r.olasilik).replace('.', ',')}</span>
                    <span className="text-center text-xs text-foreground-700">{String(r.frekans).replace('.', ',')}</span>
                    <span className="text-center text-xs text-foreground-700">{r.siddet}</span>
                    <span className="text-center text-xs font-bold text-foreground-950">{fkPuanGoster(puan)}</span>
                    <span className="flex justify-center">
                      <span className={`inline-flex items-center gap-0.5 whitespace-nowrap rounded-md px-1.5 py-0.5 text-[10px] font-bold text-inverse ${sev.badge}`}>
                        <i className={`${sev.icon} text-[10px]`} /> {sev.label}
                      </span>
                    </span>
                    <span className="flex items-center justify-center gap-0.5">
                      <RwIconButton icon="ri-edit-line" onClick={(e) => { e.stopPropagation(); setSeciliId(r.id); }} />
                      <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={(e) => { e.stopPropagation(); onSil(r.id); if (seciliId === r.id) setSeciliId(''); }} />
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Seçili risk detayı */}
          <div className="flex-shrink-0 rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="mb-3 flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300">
                <i className="ri-edit-2-line text-xs" />
              </span>
              <div>
                <h3 className="text-xs font-semibold text-foreground-950">Seçili Risk Detayı</h3>
                <p className="text-xs text-foreground-500">Düzenlemek için listeden bir risk seçin.</p>
              </div>
            </div>

            {!secili ? (
              <p className="py-4 text-center text-xs text-foreground-400">Düzenlemek için listeden bir risk seçin.</p>
            ) : (
              <div className="space-y-3">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                  <RwSelect label="Bölüm / Alan" options={RISK_ALANLARI.map((v) => ({ value: v, label: v }))} value={secili.bolum} onChange={(v) => onGuncelle(secili.id, { bolum: v })} placeholder="Seçiniz" searchable creatable />
                  <RwSelect label="Tehlike" options={tehlikeOptions} value={secili.tehlike} onChange={(v) => onGuncelle(secili.id, { tehlike: v })} placeholder="Seçiniz" searchable creatable />
                  <RwSelect label="Risk" options={riskOptions} value={secili.risk} onChange={(v) => onGuncelle(secili.id, { risk: v })} placeholder="Seçiniz" searchable creatable />
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <RwInput label="Olası Sonuç" value={secili.olasiSonuc} onChange={(e) => onGuncelle(secili.id, { olasiSonuc: e.target.value })} placeholder="Olası sonuç..." />
                  <RwTextarea label="Mevcut Kontroller" value={secili.mevcutKontroller} onChange={(e) => onGuncelle(secili.id, { mevcutKontroller: e.target.value })} placeholder="Mevcut kontrol tedbirleri..." />
                </div>

                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                  <RwSelect label="Olasılık (O)" options={O_OPTS} value={String(secili.olasilik)} onChange={(v) => onGuncelle(secili.id, { olasilik: Number(v) })} searchable />
                  <RwSelect label="Frekans (F)" options={F_OPTS} value={String(secili.frekans)} onChange={(v) => onGuncelle(secili.id, { frekans: Number(v) })} searchable />
                  <RwSelect label="Şiddet (S)" options={S_OPTS} value={String(secili.siddet)} onChange={(v) => onGuncelle(secili.id, { siddet: Number(v) })} searchable />
                  <div>
                    <span className="mb-1.5 block text-xs font-medium text-foreground-800">Risk Puanı = O × F × S</span>
                    <div className="flex h-10 items-center justify-between rounded-md border border-background-300/60 bg-background-50 px-3 dark:border-background-400/30 dark:bg-background-100">
                      <span className="text-xs font-bold text-foreground-950">{fkPuanGoster(fkPuan(secili.olasilik, secili.frekans, secili.siddet))}</span>
                      <span className={`rounded px-1.5 py-0.5 text-[10px] font-bold text-inverse ${fkSeviyeBilgi(fkPuan(secili.olasilik, secili.frekans, secili.siddet)).badge}`}>
                        {fkSeviyeBilgi(fkPuan(secili.olasilik, secili.frekans, secili.siddet)).label}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <RwSelect label="Rutin mi?" options={[{ value: 'true', label: 'Evet' }, { value: 'false', label: 'Hayır' }]} value={secili.rutin === false ? 'false' : 'true'} onChange={(v) => onGuncelle(secili.id, { rutin: v === 'true' })} />
                  <RwInput label="Etkilenenler" value={secili.etkilenenler || ''} onChange={(e) => onGuncelle(secili.id, { etkilenenler: e.target.value })} placeholder="Örn. Bölüm Çalışanları, Taşeron / Ziyaretçiler" />
                </div>

                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <RwSelect label="Kategori" options={RISK_KATEGORILERI.map((k) => ({ value: k, label: k }))} value={secili.kategori} onChange={(v) => onGuncelle(secili.id, { kategori: v })} placeholder="Kategori seçiniz" searchable creatable />
                  <RwTextarea label="Açıklama / Notlar" value={secili.notlar} onChange={(e) => onGuncelle(secili.id, { notlar: e.target.value })} placeholder="Ek açıklama ve notlar..." />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}