import { useMemo, useState } from 'react';
import { useToastActions } from '@/hooks/useToast';
import { KategoriIkon } from '@/components/feature/risk/riskUi';
import { matchesSearch } from '@/utils/turkishText';
import {
  FK_OLASILIK, FK_FREKANS, FK_SIDDET,
  fkPuan, fkPuanGoster, fkSeviyeBilgi, type FkOlcek, type FkRiskItem,
} from '@/components/feature/risk/fkTypes';
import { RwButton, RwInput, RwSectionTitle, RwSelect } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// FINE-KINNEY · ADIM 4 — DEĞERLENDİRME (Referans görsel 4)
// Sol: risk listesi · Orta: Seçili Risk için O/F/S ölçek seçicileri ·
// Sağ: risk puanı hesaplama (O×F×S) + seviye aralıkları tablosu.
// ─────────────────────────────────────────────────────────────────────────────

/** Referans görseldeki risk seviyesi aralıkları tablosu. */
const ARALIKLAR: { label: string; aralik: string; renk: string; dot: string }[] = [
  { label: 'Kabul Edilebilir', aralik: '< 20', renk: 'text-success-700 dark:text-success-300', dot: 'bg-success-500' },
  { label: 'Olası', aralik: '20 – 70', renk: 'text-warning-700 dark:text-warning-300', dot: 'bg-warning-500' },
  { label: 'Önemli', aralik: '70 – 200', renk: 'text-warning-800 dark:text-warning-200', dot: 'bg-warning-600' },
  { label: 'Yüksek', aralik: '200 – 400', renk: 'text-danger-700 dark:text-danger-300', dot: 'bg-danger-500' },
  { label: 'Çok Yüksek', aralik: '≥ 400', renk: 'text-danger-800 dark:text-danger-200', dot: 'bg-danger-600' },
];

interface OlcekSeciciProps {
  baslik: string;
  kod: string;
  aciklama: string;
  olcek: FkOlcek[];
  deger: number;
  onSec: (v: number) => void;
  sutun: number;
}

function OlcekSecici({ baslik, kod, aciklama, olcek, deger, onSec, sutun }: OlcekSeciciProps) {
  return (
    <div>
      <div className="mb-1.5 flex items-center gap-1.5">
        <h4 className="text-xs font-bold text-foreground-950">{baslik}</h4>
        <span className="flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-bold text-foreground-400 ring-1 ring-background-300/70 dark:ring-background-400/50">i</span>
        <span className="rounded bg-background-200/70 px-1.5 py-0.5 text-[10px] font-bold text-foreground-600 dark:bg-background-300/50 dark:text-foreground-300">{kod}</span>
      </div>
      <p className="mb-2 text-xs text-foreground-500">{aciklama}</p>
      <div className={`grid gap-1.5 ${sutun === 2 ? 'grid-cols-2' : 'grid-cols-1'}`}>
        {olcek.map((x) => {
          const aktif = deger === x.value;
          return (
            <button
              key={x.value}
              type="button"
              onClick={() => onSec(x.value)}
              className={`flex items-center gap-2 rounded-md border px-2.5 py-1.5 text-left text-xs transition-colors cursor-pointer ${
                aktif
                  ? 'border-primary-500 bg-primary-500/15 text-primary-700 dark:text-primary-200'
                  : 'border-background-300/60 bg-background-50 text-foreground-700 hover:border-primary-300 dark:border-background-400/30 dark:bg-background-100/60'
              }`}
            >
              <span className={`flex h-6 min-w-8 items-center justify-center rounded px-1 text-[11px] font-bold ${aktif ? 'bg-primary-500 text-inverse' : 'bg-background-200 text-foreground-700 dark:bg-background-300/60 dark:text-foreground-300'}`}>
                {String(x.value).replace('.', ',')}
              </span>
              <span className="leading-snug">{x.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

interface Props {
  riskler: FkRiskItem[];
  onGuncelle: (id: string, patch: Partial<FkRiskItem>) => void;
}

export default function FkAdim4Degerlendirme({ riskler, onGuncelle }: Props) {
  const { addToast } = useToastActions();
  const [seciliId, setSeciliId] = useState<string>(riskler[0]?.id ?? '');
  const [arama, setArama] = useState('');

  const secili = riskler.find((r) => r.id === seciliId) ?? riskler[0] ?? null;

  const filtreli = useMemo(() => {
    const q = arama.trim().toLocaleLowerCase('tr');
    if (!q) return riskler;
    return riskler.filter((r) => matchesSearch(`${r.tehlike} ${r.risk}`, q));
  }, [riskler, arama]);

  const puan = secili ? fkPuan(secili.olasilik, secili.frekans, secili.siddet) : 0;
  const sev = fkSeviyeBilgi(puan);
  const kalanPuan = secili ? fkPuan(secili.kalanOlasilik ?? secili.olasilik, secili.kalanFrekans ?? secili.frekans, secili.kalanSiddet ?? secili.siddet) : 0;
  const kalanSev = fkSeviyeBilgi(kalanPuan);
  const azalma = puan > 0 ? Math.max(0, Math.round(((puan - kalanPuan) / puan) * 100)) : 0;
  const kalanGirilmis = !!secili && (secili.kalanOlasilik !== undefined || secili.kalanFrekans !== undefined || secili.kalanSiddet !== undefined);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="4. Değerlendirme"
        desc="Her risk için Fine-Kinney kriterlerini belirleyin. Olasılık, frekans ve şiddet değerleri seçilerek risk puanı otomatik hesaplanır."
        right={(
          <RwButton
            variant="outline" size="sm" icon="ri-book-open-line"
            onClick={() => addToast({
              title: 'Fine-Kinney Ölçekleri',
              message: 'Olasılık (O): 0,1 – 10 · Frekans (F): 0,5 – 10 · Şiddet (S): 1 – 100. Risk Puanı = O × F × S.',
              type: 'info',
            })}
          >
            Ölçekleri Görüntüle
          </RwButton>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 lg:grid-cols-[260px_minmax(0,1fr)_300px]">
        {/* SOL — Risk listesi */}
        <div className="flex min-h-0 flex-col rounded-lg border border-background-300/50 bg-background-100 dark:border-background-400/30 dark:bg-background-200/40">
          <div className="flex flex-shrink-0 items-center justify-between border-b border-background-300/40 px-3 py-2.5 dark:border-background-400/30">
            <h3 className="text-xs font-semibold text-foreground-950">Risk Listesi ({riskler.length})</h3>
          </div>
          <div className="flex-shrink-0 px-3 py-2">
            <RwInput size="sm" placeholder="Risklerde ara..." value={arama} onChange={(e) => setArama(e.target.value)} leftIcon={<i className="ri-search-line text-xs" />} />
          </div>
          <div className="isg-scroll-pane min-h-0 flex-1 space-y-1.5 overflow-y-auto px-2.5 pb-2.5">
            {filtreli.length === 0 && <p className="py-8 text-center text-xs text-foreground-400">{riskler.length === 0 ? 'Henüz risk yok.' : 'Sonuç yok.'}</p>}
            {filtreli.map((r, i) => {
              const p = fkPuan(r.olasilik, r.frekans, r.siddet);
              const s = fkSeviyeBilgi(p);
              const aktif = secili?.id === r.id;
              return (
                <button
                  key={r.id} type="button" onClick={() => setSeciliId(r.id)}
                  className={`flex w-full items-start gap-2.5 rounded-lg border p-2.5 text-left transition-colors cursor-pointer ${
                    aktif ? 'border-primary-500 bg-primary-500/10' : 'border-background-300/50 bg-background-50 hover:border-primary-300 dark:border-background-400/25 dark:bg-background-100/60'
                  }`}
                >
                  <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-background-200 text-xs font-bold text-foreground-600 dark:bg-background-300/60 dark:text-foreground-300">{i + 1}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-xs font-semibold text-foreground-950">{r.tehlike || '—'}</span>
                    <span className="mt-0.5 block truncate text-xs text-foreground-500">{r.risk || '—'}</span>
                    <span className={`mt-1 inline-flex items-center gap-0.5 rounded px-1.5 py-0.5 text-[10px] font-bold text-inverse ${s.badge}`}>
                      <i className={`${s.icon} text-[10px]`} /> {s.label}
                    </span>
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* ORTA — Ölçek seçicileri */}
        <div className="isg-scroll-pane min-h-0 overflow-y-auto rounded-lg border border-background-300/50 bg-background-100 p-4 dark:border-background-400/30 dark:bg-background-200/40">
          {!secili ? (
            <p className="py-12 text-center text-xs text-foreground-400">Listeden bir risk seçin.</p>
          ) : (
            <div className="space-y-5">
              <div className="rounded-lg border border-background-300/50 bg-background-50 p-3 dark:border-background-400/25 dark:bg-background-100/50">
                <div className="flex items-start gap-2.5">
                  <KategoriIkon kategori={secili.kategori} className="h-9 w-9 text-sm" />
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-foreground-950">{secili.tehlike}</p>
                    <p className="text-xs text-foreground-600">{secili.risk}</p>
                  </div>
                </div>
                <div className="mt-2.5 grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-md border border-background-300/50 bg-background-100 p-2 dark:border-background-400/25 dark:bg-background-200/40">
                    <p className="text-[10px] text-foreground-400">Bölüm / Alan</p>
                    <p className="truncate text-xs font-semibold text-foreground-800">{secili.bolum || '—'}</p>
                  </div>
                  <div className="rounded-md border border-background-300/50 bg-background-100 p-2 dark:border-background-400/25 dark:bg-background-200/40">
                    <p className="text-[10px] text-foreground-400">Kategori</p>
                    <p className="truncate text-xs font-semibold text-foreground-800">{secili.kategori || '—'}</p>
                  </div>
                  <div className="rounded-md border border-background-300/50 bg-background-100 p-2 dark:border-background-400/25 dark:bg-background-200/40">
                    <p className="text-[10px] text-foreground-400">Olası Sonuç</p>
                    <p className="truncate text-xs font-semibold text-foreground-800">{secili.olasiSonuc || '—'}</p>
                  </div>
                </div>
              </div>

              <ol className="space-y-5">
                <li>
                  <OlcekSecici
                    baslik="Olasılık (O)" kod="O" sutun={2}
                    aciklama="Olayın meydana gelme ihtimali"
                    olcek={FK_OLASILIK} deger={secili.olasilik}
                    onSec={(v) => onGuncelle(secili.id, { olasilik: v })}
                  />
                </li>
                <li>
                  <OlcekSecici
                    baslik="Frekans (F)" kod="F" sutun={2}
                    aciklama="Olayın tekrarlanma sıklığı (maruziyet)"
                    olcek={FK_FREKANS} deger={secili.frekans}
                    onSec={(v) => onGuncelle(secili.id, { frekans: v })}
                  />
                </li>
                <li>
                  <OlcekSecici
                    baslik="Şiddet (S)" kod="S" sutun={2}
                    aciklama="Olayın etkisinin ciddiyeti"
                    olcek={FK_SIDDET} deger={secili.siddet}
                    onSec={(v) => onGuncelle(secili.id, { siddet: v })}
                  />
                </li>
              </ol>
            </div>
          )}
        </div>

        {/* SAĞ — Hesaplama + seviye aralıkları */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="mb-3 flex items-center gap-2">
              <span className="flex h-7 w-7 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300"><i className="ri-calculator-line text-xs" /></span>
              <h3 className="text-xs font-semibold text-foreground-950">Risk Puanı Hesaplama</h3>
            </div>

            {!secili ? (
              <p className="py-4 text-center text-xs text-foreground-400">Listeden bir risk seçin.</p>
            ) : (
              <>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-md border border-background-300/50 bg-background-50 p-2 dark:border-background-400/25 dark:bg-background-100">
                    <p className="text-[10px] text-foreground-400">Olasılık (O)</p>
                    <p className="text-base font-bold text-foreground-950">{String(secili.olasilik).replace('.', ',')}</p>
                  </div>
                  <div className="rounded-md border border-background-300/50 bg-background-50 p-2 dark:border-background-400/25 dark:bg-background-100">
                    <p className="text-[10px] text-foreground-400">Frekans (F)</p>
                    <p className="text-base font-bold text-foreground-950">{String(secili.frekans).replace('.', ',')}</p>
                  </div>
                  <div className="rounded-md border border-background-300/50 bg-background-50 p-2 dark:border-background-400/25 dark:bg-background-100">
                    <p className="text-[10px] text-foreground-400">Şiddet (S)</p>
                    <p className="text-base font-bold text-foreground-950">{secili.siddet}</p>
                  </div>
                </div>

                <div className="my-3 flex items-center justify-center gap-2 text-center">
                  <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-background-200 text-2xl font-bold text-foreground-500 dark:bg-background-300/50">=</div>
                  <div className={`flex h-16 flex-1 flex-col items-center justify-center rounded-lg ${sev.badge}`}>
                    <span className="text-2xl font-bold">{fkPuanGoster(puan)}</span>
                    <span className="text-xs font-semibold"><i className={`${sev.icon} mr-1`} />{sev.label}</span>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Kontrol Sonrası Risk */}
          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <div className="mb-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="flex h-7 w-7 items-center justify-center rounded-md bg-success-500/15 text-success-600 dark:text-success-300"><i className="ri-shield-check-line text-xs" /></span>
                <h3 className="text-xs font-semibold text-foreground-950">Kontrol Sonrası Risk</h3>
              </div>
              {kalanGirilmis && (
                <button
                  type="button"
                  onClick={() => secili && onGuncelle(secili.id, { kalanOlasilik: undefined, kalanFrekans: undefined, kalanSiddet: undefined })}
                  className="cursor-pointer whitespace-nowrap text-xs font-medium text-foreground-400 hover:text-danger-500 dark:hover:text-danger-400"
                >
                  <i className="ri-refresh-line" /> Sıfırla
                </button>
              )}
            </div>

            {!secili ? (
              <p className="py-4 text-center text-xs text-foreground-400">Listeden bir risk seçin.</p>
            ) : (
              <>
                <p className="mb-2 text-xs leading-relaxed text-foreground-500">Planlanan kontroller uygulandıktan sonra beklenen O, F ve S değerlerini girin.</p>
                <div className="grid grid-cols-3 gap-2">
                  <RwSelect size="sm" label="O" searchable options={FK_OLASILIK.map((x) => ({ value: String(x.value), label: String(x.value).replace('.', ',') }))} value={String(secili.kalanOlasilik ?? secili.olasilik)} onChange={(v) => onGuncelle(secili.id, { kalanOlasilik: Number(v) })} />
                  <RwSelect size="sm" label="F" searchable options={FK_FREKANS.map((x) => ({ value: String(x.value), label: String(x.value).replace('.', ',') }))} value={String(secili.kalanFrekans ?? secili.frekans)} onChange={(v) => onGuncelle(secili.id, { kalanFrekans: Number(v) })} />
                  <RwSelect size="sm" label="S" searchable options={FK_SIDDET.map((x) => ({ value: String(x.value), label: String(x.value) }))} value={String(secili.kalanSiddet ?? secili.siddet)} onChange={(v) => onGuncelle(secili.id, { kalanSiddet: Number(v) })} />
                </div>
                <div className="mt-2.5 flex items-center justify-between rounded-md border border-background-300/50 bg-background-50 px-3 py-2 dark:border-background-400/25 dark:bg-background-100">
                  <span className="text-xs text-foreground-500">Son Puan = O × F × S</span>
                  <div className="flex items-center gap-2">
                    <span className="text-base font-bold text-foreground-950">{fkPuanGoster(kalanPuan)}</span>
                    <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-bold text-inverse ${kalanSev.badge}`}>
                      <i className={`${kalanSev.icon} text-[10px]`} /> {kalanSev.label}
                    </span>
                  </div>
                </div>
                {azalma > 0 && (
                  <p className="mt-2 flex items-center gap-1 text-xs font-medium text-success-600 dark:text-success-300">
                    <i className="ri-arrow-down-line" /> Risk azalması: %{azalma}
                  </p>
                )}
              </>
            )}
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3.5 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2.5 text-xs font-semibold text-foreground-950">Risk Seviyesi Aralıkları</h3>
            <div className="overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
              <table className="w-full border-collapse">
                <thead className="bg-background-200 dark:bg-background-300/60">
                  <tr className="text-left text-xs font-semibold text-foreground-500">
                    <th className="px-2.5 py-1.5 whitespace-nowrap">Puan</th>
                    <th className="px-2.5 py-1.5 whitespace-nowrap">Risk Seviyesi</th>
                  </tr>
                </thead>
                <tbody>
                  {ARALIKLAR.map((a) => (
                    <tr key={a.label} className="border-t border-background-300/25 dark:border-background-400/15">
                      <td className="px-2.5 py-1.5 text-xs font-medium text-foreground-700">{a.aralik}</td>
                      <td className="px-2.5 py-1.5">
                        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold ${a.renk}`}>
                          <span className={`h-2.5 w-2.5 rounded-full ${a.dot}`} /> {a.label}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}