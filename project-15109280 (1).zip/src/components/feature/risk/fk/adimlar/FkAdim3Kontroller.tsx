import { useMemo, useState } from 'react';
import * as XLSX from 'xlsx';
import { useToastActions } from '@/hooks/useToast';
import { buildDownloadFilename, downloadBlobFile } from '@/lib/downloadFile';
import { KategoriIkon, kategoriGorunum } from '@/components/feature/risk/riskUi';
import { RISK_DURUMLARI } from '@/components/feature/risk/riskSihirbazTypes';
import { fkPuan, fkPuanGoster, fkSeviyeBilgi, type FkRiskItem, type FkSeviye } from '@/components/feature/risk/fkTypes';
import { matchesSearch } from '@/utils/turkishText';
import {
  RwButton, RwIconButton, RwInfoBanner, RwInput, RwPagination, RwSectionTitle, RwSelect,
} from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// FINE-KINNEY · ADIM 3 — KONTROLLER VE AKSİYONLAR (Referans görsel 3)
// ─────────────────────────────────────────────────────────────────────────────

type Filtre = 'tumu' | FkSeviye;
const SAYFA_BOYUT = 10;
const IZGARA = '36px minmax(180px,1.55fr) minmax(150px,1.2fr) minmax(185px,1.55fr) minmax(130px,1fr) 116px 86px 116px 60px';
const TH = 'text-left text-xs font-semibold uppercase tracking-wide text-foreground-500 whitespace-nowrap';

const DURUM_RENK: Record<string, string> = {
  Planlandı: 'bg-warning-500', 'Devam Ediyor': 'bg-primary-500', 'Başlamadı': 'bg-foreground-400', Tamamlandı: 'bg-success-500',
};

function bas(ad: string): string {
  const p = ad.trim().split(/\s+/).filter(Boolean);
  if (p.length === 0) return '';
  if (p.length === 1) return p[0].slice(0, 2).toUpperCase();
  return (p[0][0] + p[p.length - 1][0]).toUpperCase();
}

function OnerilenKontrollerListe({ deger, onChange }: { deger: string; onChange: (v: string) => void }) {
  const satirlar = deger.split('\n').map((s) => s.trim()).filter(Boolean);
  const [yeni, setYeni] = useState('');
  const [acik, setAcik] = useState(false);
  const sil = (i: number) => onChange(satirlar.filter((_, idx) => idx !== i).join('\n'));
  const ekle = () => {
    const t = yeni.trim();
    if (!t) { setAcik(false); return; }
    onChange([...satirlar, t].join('\n'));
    setYeni(''); setAcik(false);
  };
  return (
    <div className="space-y-1.5">
      {satirlar.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {satirlar.map((s, i) => (
            <span key={i} className="group inline-flex items-center gap-1 rounded-md border border-success-500/40 bg-success-500/10 px-2 py-0.5 text-xs font-medium text-success-700 dark:border-success-500/30 dark:text-success-300">
              <i className="ri-add-line text-xs" />
              <span className="max-w-[180px] truncate">{s}</span>
              <button type="button" onClick={() => sil(i)} className="cursor-pointer text-success-600/70 hover:text-danger-500" aria-label="Kaldır"><i className="ri-close-line text-xs" /></button>
            </span>
          ))}
        </div>
      )}
      {acik ? (
        <div className="flex items-center gap-1">
          <input
            autoFocus value={yeni}
            onChange={(e) => setYeni(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); ekle(); } if (e.key === 'Escape') setAcik(false); }}
            placeholder="Kontrol tedbiri..."
            className="h-7 min-w-0 flex-1 rounded border border-background-300/70 bg-background-50 px-2 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
          />
          <button type="button" onClick={ekle} className="cursor-pointer text-success-600" aria-label="Onayla"><i className="ri-check-line" /></button>
        </div>
      ) : (
        <button type="button" onClick={() => setAcik(true)} className="inline-flex cursor-pointer items-center gap-1 whitespace-nowrap text-xs font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400">
          <i className="ri-add-line" /> Kontrol Ekle
        </button>
      )}
    </div>
  );
}

interface Props {
  riskler: FkRiskItem[];
  onGuncelle: (id: string, patch: Partial<FkRiskItem>) => void;
}

export default function FkAdim3Kontroller({ riskler, onGuncelle }: Props) {
  const { addToast } = useToastActions();
  const [filtre, setFiltre] = useState<Filtre>('tumu');
  const [arama, setArama] = useState('');
  const [sayfa, setSayfa] = useState(1);

  const sayilar = useMemo(() => {
    const s = { cokYuksek: 0, yuksek: 0, onemli: 0, olasi: 0, kabul: 0 };
    riskler.forEach((r) => { s[fkSeviyeBilgi(fkPuan(r.olasilik, r.frekans, r.siddet)).key] += 1; });
    return s;
  }, [riskler]);

  const filtreli = useMemo(() => {
    let liste = riskler;
    if (filtre !== 'tumu') liste = liste.filter((r) => fkSeviyeBilgi(fkPuan(r.olasilik, r.frekans, r.siddet)).key === filtre);
    const q = arama.trim().toLocaleLowerCase('tr');
    if (q) liste = liste.filter((r) => matchesSearch(`${r.tehlike} ${r.risk} ${r.bolum}`, q));
    return liste;
  }, [riskler, filtre, arama]);

  const toplamSayfa = Math.max(1, Math.ceil(filtreli.length / SAYFA_BOYUT));
  const aktifSayfa = Math.min(sayfa, toplamSayfa);
  const kayitlar = filtreli.slice((aktifSayfa - 1) * SAYFA_BOYUT, aktifSayfa * SAYFA_BOYUT);

  const sorumluOptions = useMemo(() => Array.from(new Set(riskler.map((x) => x.sorumlu).filter(Boolean))).map((v) => ({ value: v, label: v })), [riskler]);

  const topluIslem = (islem: string) => {
    if (!islem) return;
    riskler.forEach((r) => onGuncelle(r.id, { durum: islem }));
    addToast({ title: 'Toplu işlem uygulandı', message: `Tüm risklerin durumu “${islem}” yapıldı.`, type: 'success' });
  };

  const excelAktar = () => {
    const veri = riskler.map((r, i) => {
      const p = fkPuan(r.olasilik, r.frekans, r.siddet);
      return {
        No: i + 1, 'Bölüm / Alan': r.bolum, Tehlike: r.tehlike, Risk: r.risk,
        'Mevcut Kontroller': r.mevcutKontroller, 'Önerilen Ek Kontroller': r.onerilenKontroller,
        Sorumlu: r.sorumlu, Termin: r.termin, Durum: r.durum,
        O: r.olasilik, F: r.frekans, S: r.siddet, 'Risk Puanı': p, 'Risk Seviyesi': fkSeviyeBilgi(p).label,
      };
    });
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(veri), 'Kontroller');
    // Merkezî indirme: anlamlı dosya adı (UUID yok).
    const buffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    downloadBlobFile(blob, buildDownloadFilename({ type: 'Fine-Kinney Kontroller ve Aksiyonlar', extension: 'xlsx' }));
  };

  const filtreButonlari: { key: Filtre; label: string; adet: number; cls: string; dot: string }[] = [
    { key: 'tumu', label: 'Tümü', adet: riskler.length, cls: 'bg-primary-500 text-inverse', dot: 'bg-inverse' },
    { key: 'cokYuksek', label: 'Çok Yüksek', adet: sayilar.cokYuksek, cls: 'bg-danger-600 text-inverse', dot: 'bg-danger-600' },
    { key: 'yuksek', label: 'Yüksek', adet: sayilar.yuksek, cls: 'bg-danger-500 text-inverse', dot: 'bg-danger-500' },
    { key: 'onemli', label: 'Önemli', adet: sayilar.onemli, cls: 'bg-warning-600 text-inverse', dot: 'bg-warning-600' },
    { key: 'olasi', label: 'Olası', adet: sayilar.olasi, cls: 'bg-warning-500 text-inverse', dot: 'bg-warning-500' },
    { key: 'kabul', label: 'Kabul Edilebilir', adet: sayilar.kabul, cls: 'bg-success-500 text-inverse', dot: 'bg-success-500' },
  ];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="3. Kontroller ve Aksiyonlar"
        desc="Her risk için mevcut kontrolleri gözden geçirin, ek kontrol tedbirlerini belirleyin ve aksiyon planı oluşturun."
        right={(
          <button
            type="button"
            onClick={() => addToast({ title: 'Kontrol Önerileri', message: 'Ek kontrol önerileri 2. adımda gelen verilerden otomatik doldurulur; buradan düzenleyebilirsiniz.', type: 'info' })}
            className="flex flex-shrink-0 cursor-pointer items-start gap-2 rounded-lg border border-accent-300/50 bg-accent-50 p-2.5 text-left transition-colors hover:border-accent-400 dark:border-accent-500/30 dark:bg-accent-500/10"
          >
            <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-md bg-accent-500/20 text-accent-600 dark:text-accent-300"><i className="ri-sparkling-2-line text-xs" /></span>
            <span>
              <span className="block text-xs font-semibold text-foreground-950">Kontrol Önerileri</span>
              <span className="mt-0.5 block text-xs text-foreground-500">Seçili riskler için kontrol önerileri alın</span>
            </span>
          </button>
        )}
      />

      <div className="flex flex-shrink-0 flex-wrap items-center justify-between gap-2 pb-3">
        <div className="flex flex-wrap items-center gap-2">
          {filtreButonlari.map((f) => {
            const aktif = filtre === f.key;
            return (
              <button
                key={f.key} type="button"
                onClick={() => { setFiltre(f.key); setSayfa(1); }}
                className={`inline-flex h-8 cursor-pointer items-center gap-1.5 whitespace-nowrap rounded-md px-3 text-xs font-medium transition-colors ${
                  aktif ? f.cls : 'border border-background-300/70 text-foreground-700 hover:bg-background-100 dark:border-background-400/40 dark:hover:bg-background-300/40'
                }`}
              >
                <span className={`inline-block h-2 w-2 rounded-full ${aktif ? 'bg-inverse' : f.dot}`} />
                {f.label} ({f.adet})
              </button>
            );
          })}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="w-48"><RwInput size="sm" placeholder="Risklerde ara..." value={arama} onChange={(e) => { setArama(e.target.value); setSayfa(1); }} leftIcon={<i className="ri-search-line text-xs" />} /></div>
          <div className="w-44">
            <RwSelect size="sm" placeholder="Toplu İşlem" options={RISK_DURUMLARI.map((d) => ({ value: d, label: `Tümünü “${d}” yap` }))} value="" onChange={topluIslem} />
          </div>
          <RwButton variant="outline" size="sm" icon="ri-file-excel-2-line" onClick={excelAktar}>Excel’e Aktar</RwButton>
        </div>
      </div>

      <div className="isg-scroll-pane min-h-0 flex-1 overflow-auto rounded-lg border border-background-300/50 dark:border-background-400/30">
        <div style={{ minWidth: 1080 }}>
          <div className="sticky top-0 z-10 grid items-center border-b border-background-300/60 bg-background-200 px-3 py-2 dark:border-background-400/40 dark:bg-background-300/85" style={{ gridTemplateColumns: IZGARA, columnGap: '0.75rem' }}>
            <span className={`${TH} text-center`}>#</span>
            <span className={TH}>Risk / Tehlike</span>
            <span className={TH}>Mevcut Kontroller</span>
            <span className={TH}>Önerilen Ek Kontroller</span>
            <span className={TH}>Sorumlu</span>
            <span className={TH}>Termin</span>
            <span className={TH}>Durum</span>
            <span className={`${TH} text-center`}>İşlem</span>
          </div>

          <div className="space-y-2 p-2">
            {kayitlar.length === 0 && (
              <div className="py-12 text-center text-xs text-foreground-400">
                {riskler.length === 0 ? 'Henüz risk yok. 2. adımda risk ekleyin.' : 'Filtreye uyan kayıt yok.'}
              </div>
            )}

            {kayitlar.map((r, i) => {
              const puan = fkPuan(r.olasilik, r.frekans, r.siddet);
              const sev = fkSeviyeBilgi(puan);
              const no = (aktifSayfa - 1) * SAYFA_BOYUT + i + 1;
              const kat = kategoriGorunum(r.kategori);
              return (
                <div key={r.id} className="grid items-start rounded-lg border border-background-300/50 bg-background-100 p-3 transition-colors hover:border-primary-300 dark:border-background-400/30 dark:bg-background-200/40 dark:hover:border-primary-500/40" style={{ gridTemplateColumns: IZGARA, columnGap: '0.75rem' }}>
                  <span className={`flex h-7 w-7 items-center justify-center rounded-md text-xs font-bold ${sev.soft}`}>{no}</span>

                  <div className="flex min-w-0 items-start gap-2.5">
                    <KategoriIkon kategori={r.kategori} className="h-8 w-8 text-xs" />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold leading-snug text-foreground-950">{r.tehlike || '—'}</p>
                      <p className="mt-0.5 text-xs leading-snug text-foreground-500">{r.risk || '—'}</p>
                      <span className={`mt-1.5 inline-flex items-center gap-0.5 whitespace-nowrap rounded-md px-1.5 py-0.5 text-[10px] font-bold text-inverse ${sev.badge}`}>
                        <i className={`${sev.icon} text-[10px]`} /> {fkPuanGoster(puan)} · {sev.label}
                      </span>
                      {r.kategori && (
                        <span className={`ml-1 mt-1.5 inline-flex items-center whitespace-nowrap rounded-md px-1.5 py-0.5 text-xs font-semibold ${kat.cls}`}>{r.kategori}</span>
                      )}
                    </div>
                  </div>

                  <div className="min-w-0 text-xs leading-relaxed text-foreground-600">
                    {r.mevcutKontroller
                      ? <ul className="list-disc space-y-0.5 pl-4">{r.mevcutKontroller.split(/[,\n]/).map((k, idx) => k.trim() && <li key={idx}>{k.trim()}</li>)}</ul>
                      : <span className="text-foreground-400">—</span>}
                  </div>

                  <OnerilenKontrollerListe deger={r.onerilenKontroller} onChange={(v) => onGuncelle(r.id, { onerilenKontroller: v })} />

                  <div className="flex items-center gap-1.5">
                    {r.sorumlu && (
                      <span className="flex h-7 w-7 flex-shrink-0 items-center justify-center rounded-full bg-primary-500 text-xs font-bold text-inverse" aria-hidden="true">{bas(r.sorumlu)}</span>
                    )}
                    <div className="min-w-0 flex-1">
                      <RwSelect size="sm" options={sorumluOptions} value={r.sorumlu} onChange={(v) => onGuncelle(r.id, { sorumlu: v })} placeholder="Sorumlu" searchable creatable />
                    </div>
                  </div>

                  <RwInput
                    size="sm" type="date"
                    value={r.termin}
                    onChange={(e) => onGuncelle(r.id, { termin: e.target.value })}
                  />

                  <div className="flex items-center gap-1.5">
                    <span className={`h-2 w-2 flex-shrink-0 rounded-full ${DURUM_RENK[r.durum] ?? 'bg-foreground-400'}`} />
                    <div className="min-w-0 flex-1">
                      <RwSelect size="sm" options={RISK_DURUMLARI.map((d) => ({ value: d, label: d }))} value={r.durum} onChange={(v) => onGuncelle(r.id, { durum: v })} />
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-0.5">
                    <RwIconButton icon="ri-file-copy-line" onClick={() => addToast({ title: 'Kopyalandı', message: `${r.tehlike} — kontrol satırı kopyalandı.`, type: 'info' })} />
                    <RwIconButton icon="ri-information-line" onClick={() => addToast({ title: r.tehlike, message: `${r.risk} · Puan ${fkPuanGoster(puan)} (${sev.label})`, type: 'info' })} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <RwPagination total={filtreli.length} page={aktifSayfa} pageSize={SAYFA_BOYUT} onPage={setSayfa} />

      <div className="mt-3">
        <RwInfoBanner
          icon="ri-lightbulb-line"
          title="Kontrol Hiyerarşisini Unutmayın"
          action={(
            <button type="button" onClick={() => addToast({ title: 'Kontrol Hiyerarşisi', message: '1) Kaynağında yok etme, 2) Mühendislik kontrolleri, 3) İdari kontroller, 4) KKD.', type: 'info' })} className="cursor-pointer whitespace-nowrap text-xs font-medium text-primary-600 hover:text-primary-700 dark:text-primary-400">
              <i className="ri-book-open-line" /> Kontrol Hiyerarşisi Rehberi
            </button>
          )}
        >
          Öncelikle riskin kaynağında yok etmeyi, mümkün değilse mühendislik kontrolleri, idari kontroller ve son olarak kişisel koruyucu donanım uygulamalarını değerlendirin.
        </RwInfoBanner>
      </div>
    </div>
  );
}