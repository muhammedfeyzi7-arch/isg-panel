import { useMemo, useState } from 'react';
import Icon from '@/components/ui/Icon';
import { useToastActions } from '@/hooks/useToast';
import { GECERLILIK_SECENEKLERI, type TemelBilgiler } from '@/components/feature/risk/riskSihirbazTypes';
import {
  fkPuan, fkPuanGoster, fkSeviye, type FkRiskItem,
} from '@/components/feature/risk/fkTypes';
import { pdfIndir, wordIndir, excelIndir } from '@/lib/fineKinneyRapor';
import { RwButton, RwCard, RwIconButton, RwInput, RwSectionTitle, RwSelect } from '@/components/feature/risk/sihirbaz/wizardUi';
import { matchesSearch } from '@/utils/turkishText';

// ─────────────────────────────────────────────────────────────────────────────
// FINE-KINNEY · ADIM 5 — RAPOR VE ÖNİZLEME (Referans görsel 5)
// Sol: özet kartları + çalışma bilgileri + risk özeti + dağılım grafikleri.
// Sağ: A4 rapor önizlemesi + Rapor İşlemleri (Word / PDF / Paylaş).
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: TemelBilgiler;
  riskler: FkRiskItem[];
  onTemelChange: (patch: Partial<TemelBilgiler>) => void;
}

function tarihGoster(iso: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

const SEVIYE_SIRA = ['cokYuksek', 'yuksek', 'onemli', 'olasi', 'kabul'] as const;

export default function FkAdim5Rapor({ temel, riskler, onTemelChange }: Props) {
  const { addToast } = useToastActions();
  const [zoom, setZoom] = useState(100);
  const [indiriliyor, setIndiriliyor] = useState<'word' | 'pdf' | 'excel' | null>(null);
  const [paylasAcik, setPaylasAcik] = useState(false);
  const [arama, setArama] = useState('');

  const sayim = useMemo(() => {
    const s = { cokYuksek: 0, yuksek: 0, onemli: 0, olasi: 0, kabul: 0, toplam: riskler.length };
    riskler.forEach((r) => { s[fkSeviye(fkPuan(r.olasilik, r.frekans, r.siddet))] += 1; });
    return s;
  }, [riskler]);

  const raporNo = temel.raporNo?.trim() || `FK-${new Date().getFullYear()}-001`;
  const puanDagilim = useMemo(() => {
    const bantlar = [
      { label: '<20', min: 0, max: 20, renk: 'bg-success-500' },
      { label: '20-70', min: 20, max: 70, renk: 'bg-warning-500' },
      { label: '70-200', min: 70, max: 200, renk: 'bg-warning-600' },
      { label: '200-400', min: 200, max: 400, renk: 'bg-danger-500' },
      { label: '≥400', min: 400, max: Infinity, renk: 'bg-danger-600' },
    ];
    const say = bantlar.map((b) => ({ ...b, adet: riskler.filter((r) => { const p = fkPuan(r.olasilik, r.frekans, r.siddet); return p >= b.min && p < b.max; }).length }));
    const enBuyuk = Math.max(1, ...say.map((x) => x.adet));
    return { say, enBuyuk };
  }, [riskler]);

  const filtreli = useMemo(() => {
    const q = arama.trim().toLocaleLowerCase('tr');
    if (!q) return riskler;
    return riskler.filter((r) => matchesSearch(`${r.tehlike} ${r.risk} ${r.bolum}`, q));
  }, [riskler, arama]);

  const indir = async (tip: 'pdf' | 'word' | 'excel') => {
    if (riskler.length === 0) {
      addToast({ title: 'Risk listesi boş', message: 'Rapor oluşturmak için en az bir risk ekleyin.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndiriliyor(tip);
    try {
      const veri = { temel, riskler };
      if (tip === 'pdf') await pdfIndir(veri);
      else if (tip === 'excel') await excelIndir(veri);
      else await wordIndir(veri);
      addToast({ title: 'Rapor hazır', message: 'Dosya indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Rapor oluşturulamadı', message: 'Beklenmeyen bir hata oluştu, lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setIndiriliyor(null);
    }
  };

  const ozetKopyala = async () => {
    try {
      const metin = [
        `Firma: ${temel.firma || '—'}`,
        `Rapor No: ${raporNo}`,
        `Tarih: ${tarihGoster(temel.tarih)}`,
        `Toplam Risk: ${sayim.toplam}`,
        `Çok Yüksek: ${sayim.cokYuksek} · Yüksek: ${sayim.yuksek} · Önemli: ${sayim.onemli} · Olası: ${sayim.olasi} · Kabul Edilebilir: ${sayim.kabul}`,
      ].join('\n');
      await navigator.clipboard.writeText(metin);
      addToast({ title: 'Kopyalandı', message: 'Rapor özeti panoya kopyalandı.', type: 'success' });
    } catch {
      addToast({ title: 'Kopyalanamadı', message: 'Panoya erişilemedi.', type: 'error' });
    }
    setPaylasAcik(false);
  };

  const kartlar = [
    { key: 'toplam', label: 'Toplam Risk', adet: sayim.toplam, text: 'text-foreground-700 dark:text-foreground-300', btn: 'bg-primary-500', icon: 'ri-file-list-3-line' },
    { key: 'cokYuksek', label: 'Çok Yüksek', adet: sayim.cokYuksek, text: 'text-danger-800 dark:text-danger-200', btn: 'bg-danger-600', icon: 'ri-fire-line' },
    { key: 'yuksek', label: 'Yüksek Risk', adet: sayim.yuksek, text: 'text-danger-700 dark:text-danger-300', btn: 'bg-danger-500', icon: 'ri-error-warning-line' },
    { key: 'onemli', label: 'Önemli Risk', adet: sayim.onemli, text: 'text-warning-800 dark:text-warning-200', btn: 'bg-warning-600', icon: 'ri-alert-fill' },
    { key: 'olasi', label: 'Olası Risk', adet: sayim.olasi, text: 'text-warning-700 dark:text-warning-300', btn: 'bg-warning-500', icon: 'ri-alert-line' },
    { key: 'kabul', label: 'Kabul Edilebilir', adet: sayim.kabul, text: 'text-success-700 dark:text-success-300', btn: 'bg-success-500', icon: 'ri-checkbox-circle-line' },
  ];

  const donutToplam = Math.max(1, sayim.toplam);
  const donutSegments = SEVIYE_SIRA.map((k, i) => {
    const meta = { cokYuksek: '#991B1B', yuksek: '#DC2626', onemli: '#D97706', olasi: '#F59E0B', kabul: '#16A34A' }[k];
    return { key: k, renk: meta, adet: sayim[k], i };
  });
  let aciBas = 0;
  const donutGradient = donutSegments.map((s) => {
    const bas = (aciBas / donutToplam) * 100;
    aciBas += s.adet;
    const bit = (aciBas / donutToplam) * 100;
    return `${s.renk} ${bas}% ${bit}%`;
  }).join(', ');

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle title="5. Rapor ve Önizleme" desc="Hazırladığınız Fine-Kinney risk değerlendirmesini gözden geçirin, önizleyin ve raporu oluşturun." />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_360px]">
        {/* SOL */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto pr-1">
          {/* Özet kartları */}
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {kartlar.map((k) => (
              <div key={k.key} className="flex items-center gap-2.5 rounded-lg border border-background-300/50 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
                <span className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-md text-inverse ${k.btn}`}><i className={`${k.icon} text-lg`} /></span>
                <span className="min-w-0">
                  <span className="block text-lg font-bold text-foreground-950">{k.adet}</span>
                  <span className={`block truncate text-[11px] font-medium ${k.text}`}>{k.label}</span>
                </span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            {/* Çalışma bilgileri */}
            <RwCard title="Çalışma Bilgileri" icon="ri-file-info-line" className="p-3">
              <dl className="space-y-1.5 text-xs">
                {[
                  ['Çalışma Adı', temel.calismaAdi],
                  ['Firma', temel.firma],
                  ['Tesis / İş Yeri', temel.tesis],
                  ['Değerlendirme Tarihi', tarihGoster(temel.tarih)],
                  ['Geçerlilik Süresi', temel.gecerlilik],
                  ['Metod', 'Fine-Kinney (O × F × S)'],
                  ['Hazırlayan', temel.hazirlayan],
                ].map(([k, v]) => (
                  <div key={k} className="flex gap-2">
                    <dt className="w-36 flex-shrink-0 text-foreground-400">{k}</dt>
                    <dd className="min-w-0 flex-1 truncate font-medium text-foreground-900" title={v}>{v || '—'}</dd>
                  </div>
                ))}
              </dl>
              <div className="mt-2.5 border-t border-background-300/30 pt-2.5 dark:border-background-400/25">
                <span className="mb-1 block text-xs text-foreground-400">Çalışma Ekibi</span>
                <div className="flex flex-wrap gap-1.5">
                  {(temel.ekip.length ? temel.ekip : ['—']).map((e) => (
                    <span key={e} className="rounded-md border border-background-300/60 bg-background-50 px-2 py-0.5 text-xs font-medium text-foreground-800 dark:border-background-400/30 dark:bg-background-100/60">{e}</span>
                  ))}
                </div>
              </div>
            </RwCard>

            {/* Risk listesi özeti */}
            <RwCard className="flex min-h-0 flex-col p-0">
              <div className="flex items-center justify-between gap-2 border-b border-background-300/40 p-3 dark:border-background-400/25">
                <div className="flex items-center gap-1.5">
                  <i className="ri-list-check-2 text-sm text-primary-500" />
                  <h3 className="text-xs font-semibold text-foreground-950">Risk Listesi Özeti</h3>
                </div>
                <div className="w-40"><RwInput size="sm" placeholder="Risklerde ara..." value={arama} onChange={(e) => setArama(e.target.value)} leftIcon={<i className="ri-search-line text-xs" />} /></div>
              </div>
              <div className="isg-scroll-pane max-h-64 min-h-0 overflow-y-auto">
                <table className="w-full border-collapse">
                  <thead className="sticky top-0 bg-background-200 dark:bg-background-300/70">
                    <tr className="text-left text-xs font-semibold text-foreground-500">
                      <th className="px-2 py-1.5 whitespace-nowrap">#</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Tehlike</th>
                      <th className="px-2 py-1.5 text-center whitespace-nowrap">O</th>
                      <th className="px-2 py-1.5 text-center whitespace-nowrap">F</th>
                      <th className="px-2 py-1.5 text-center whitespace-nowrap">S</th>
                      <th className="px-2 py-1.5 text-center whitespace-nowrap">Puan</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Seviye</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filtreli.length === 0 && <tr><td colSpan={7} className="px-2 py-6 text-center text-xs text-foreground-400">{riskler.length === 0 ? 'Kayıt yok.' : 'Sonuç yok.'}</td></tr>}
                    {filtreli.map((r, i) => {
                      const p = fkPuan(r.olasilik, r.frekans, r.siddet);
                      const meta = { cokYuksek: 'Çok Yüksek', yuksek: 'Yüksek', onemli: 'Önemli', olasi: 'Olası', kabul: 'Kabul' }[fkSeviye(p)];
                      const renk = { cokYuksek: '#991B1B', yuksek: '#DC2626', onemli: '#D97706', olasi: '#F59E0B', kabul: '#16A34A' }[fkSeviye(p)];
                      return (
                        <tr key={r.id} className="border-t border-background-300/25 dark:border-background-400/15">
                          <td className="px-2 py-1.5 text-xs text-foreground-500">{i + 1}</td>
                          <td className="px-2 py-1.5 text-xs font-medium text-foreground-900"><span className="line-clamp-1">{r.tehlike}</span></td>
                          <td className="px-2 py-1.5 text-center text-xs text-foreground-700">{String(r.olasilik).replace('.', ',')}</td>
                          <td className="px-2 py-1.5 text-center text-xs text-foreground-700">{String(r.frekans).replace('.', ',')}</td>
                          <td className="px-2 py-1.5 text-center text-xs text-foreground-700">{r.siddet}</td>
                          <td className="px-2 py-1.5 text-center text-xs font-bold text-foreground-950">{fkPuanGoster(p)}</td>
                          <td className="px-2 py-1.5">
                            <span className="inline-block rounded px-1.5 py-0.5 text-[10px] font-bold text-inverse" style={{ backgroundColor: renk }}>{meta}</span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </RwCard>
          </div>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            {/* Donut */}
            <RwCard title="Risk Seviyesi Dağılımı" icon="ri-pie-chart-2-line" className="p-3">
              <div className="flex items-center gap-4">
                <div className="relative h-28 w-28 flex-shrink-0">
                  <div className="h-full w-full rounded-full" style={{ background: `conic-gradient(${donutGradient})` }} />
                  <div className="absolute inset-[18%] flex flex-col items-center justify-center rounded-full bg-background-100 dark:bg-background-200">
                    <span className="text-lg font-bold text-foreground-950">{sayim.toplam}</span>
                    <span className="text-[10px] text-foreground-500">Toplam</span>
                  </div>
                </div>
                <ul className="min-w-0 flex-1 space-y-1">
                  {donutSegments.map((s) => {
                    const label = { cokYuksek: 'Çok Yüksek', yuksek: 'Yüksek', onemli: 'Önemli', olasi: 'Olası', kabul: 'Kabul Edilebilir' }[s.key];
                    const yuzde = sayim.toplam ? Math.round((s.adet / sayim.toplam) * 100) : 0;
                    return (
                      <li key={s.key} className="flex items-center gap-2 text-xs">
                        <span className="h-2.5 w-2.5 flex-shrink-0 rounded-full" style={{ backgroundColor: s.renk }} />
                        <span className="flex-1 truncate text-foreground-600">{label}</span>
                        <span className="font-medium text-foreground-800">{s.adet}</span>
                        <span className="w-9 text-right text-foreground-400">%{yuzde}</span>
                      </li>
                    );
                  })}
                </ul>
              </div>
            </RwCard>

            {/* Bar */}
            <RwCard title="Risk Puanı Dağılımı" icon="ri-bar-chart-2-line" className="p-3">
              <div className="flex h-32 items-end justify-around gap-2">
                {puanDagilim.say.map((b) => (
                  <div key={b.label} className="flex flex-1 flex-col items-center gap-1">
                    <span className="text-xs font-bold text-foreground-800">{b.adet}</span>
                    <div className={`w-full rounded-t ${b.renk}`} style={{ height: `${Math.max(4, (b.adet / puanDagilim.enBuyuk) * 84)}px` }} />
                    <span className="whitespace-nowrap text-[10px] text-foreground-400">{b.label}</span>
                  </div>
                ))}
              </div>
              <p className="mt-2 text-center text-[10px] text-foreground-400">Risk Puanı Aralığı</p>
            </RwCard>
          </div>
        </div>

        {/* SAĞ — Önizleme + işlemler */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <RwCard className="flex flex-col p-0">
            <div className="flex items-center justify-between gap-2 border-b border-background-300/40 px-3 py-2 dark:border-background-400/25">
              <div className="flex items-center gap-1.5">
                <i className="ri-file-text-line text-sm text-primary-500" />
                <h3 className="text-xs font-semibold text-foreground-950">Rapor Önizleme</h3>
              </div>
              <div className="flex items-center gap-1">
                <RwIconButton icon="ri-subtract-line" onClick={() => setZoom((z) => Math.max(70, z - 10))} />
                <span className="w-10 text-center text-xs font-medium text-foreground-600">%{zoom}</span>
                <RwIconButton icon="ri-add-line" onClick={() => setZoom((z) => Math.min(130, z + 10))} />
              </div>
            </div>
            <div className="isg-scroll-pane max-h-[520px] overflow-auto bg-background-200/60 p-3 dark:bg-background-300/25">
              <div className="mx-auto bg-white p-5 text-[10px] text-gray-800" style={{ width: 460, transform: `scale(${zoom / 100})`, transformOrigin: 'top center' }}>
                <div className="flex items-start justify-between border-b-2 border-[#C8102E] pb-2">
                  <div>
                    <p className="text-xs font-bold text-[#0F2747]">{temel.firma || 'Firma Adı'}</p>
                    <p className="text-[9px] text-gray-500">{temel.tesis || 'Tesis'}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-bold text-[#0F2747]">FINE-KINNEY</p>
                    <p className="text-[8px] text-gray-500">No: {raporNo}</p>
                  </div>
                </div>
                <p className="mt-3 text-center text-[11px] font-bold text-[#0F2747]">FINE-KINNEY RİSK DEĞERLENDİRME RAPORU</p>
                <p className="text-center text-[9px] text-[#C8102E]">Olasılık × Frekans × Şiddet</p>

                <div className="mt-3 grid grid-cols-5 gap-1 text-center">
                  {[
                    ['Toplam', sayim.toplam, '#0F2747', '#EEF3F9'],
                    ['Ç.Yüksek', sayim.cokYuksek, '#7F1D1D', '#FBC5C5'],
                    ['Yüksek', sayim.yuksek, '#B91C1C', '#FDE7E7'],
                    ['Önemli', sayim.onemli, '#92400E', '#FDE8C8'],
                    ['Kabul', sayim.kabul, '#15803D', '#E7F7EE'],
                  ].map(([l, v, fg, bg]) => (
                    <div key={String(l)} className="rounded p-1" style={{ backgroundColor: bg as string }}>
                      <p className="text-[8px]" style={{ color: fg as string }}>{l}</p>
                      <p className="text-xs font-bold" style={{ color: fg as string }}>{v}</p>
                    </div>
                  ))}
                </div>

                <p className="mt-1.5 flex items-start gap-1 text-[8px] italic text-gray-500">
                  <i className="ri-information-line" />
                  Geçerlilik süresi, işyerinin tehlike sınıfına göre (Az Tehlikeli 6 Yıl · Tehlikeli 4 Yıl · Çok Tehlikeli 2 Yıl) otomatik belirlenmiştir.
                </p>

                <p className="mt-3 mb-1 font-bold text-[#0F2747]">RİSK LİSTESİ</p>
                <table className="w-full border-collapse text-[8px]">
                  <thead>
                    <tr className="bg-[#0F2747] text-white">
                      <th className="border border-gray-300 px-1 py-0.5">No</th>
                      <th className="border border-gray-300 px-1 py-0.5 text-left">Tehlike</th>
                      <th className="border border-gray-300 px-1 py-0.5">O×F×S</th>
                      <th className="border border-gray-300 px-1 py-0.5">Puan</th>
                      <th className="border border-gray-300 px-1 py-0.5">Seviye</th>
                    </tr>
                  </thead>
                  <tbody>
                    {riskler.slice(0, 8).map((r, i) => {
                      const p = fkPuan(r.olasilik, r.frekans, r.siddet);
                      const label = { cokYuksek: 'Çok Yük.', yuksek: 'Yüksek', onemli: 'Önemli', olasi: 'Olası', kabul: 'Kabul' }[fkSeviye(p)];
                      return (
                        <tr key={r.id}>
                          <td className="border border-gray-300 px-1 py-0.5 text-center">{i + 1}</td>
                          <td className="border border-gray-300 px-1 py-0.5"><span className="line-clamp-1">{r.tehlike}</span></td>
                          <td className="border border-gray-300 px-1 py-0.5 text-center">{String(r.olasilik).replace('.', ',')}×{String(r.frekans).replace('.', ',')}×{r.siddet}</td>
                          <td className="border border-gray-300 px-1 py-0.5 text-center font-bold">{fkPuanGoster(p)}</td>
                          <td className="border border-gray-300 px-1 py-0.5 text-center">{label}</td>
                        </tr>
                      );
                    })}
                    {riskler.length === 0 && <tr><td colSpan={5} className="border border-gray-300 py-2 text-center text-gray-400">Kayıt yok.</td></tr>}
                  </tbody>
                </table>
                {riskler.length > 8 && <p className="mt-1 text-center text-[8px] text-gray-400">+{riskler.length - 8} kayıt daha…</p>}
              </div>
            </div>
          </RwCard>

          <RwCard title="Rapor İşlemleri" icon="ri-download-2-line" className="p-3">
            <p className="mb-2.5 text-xs text-foreground-500">Raporu aşağıdaki formatlarda oluşturabilirsiniz.</p>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('word')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-primary-500 text-inverse transition-colors hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'word' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="word" size="md" />}
                <span className="text-xs leading-tight">Word İndir</span>
              </button>
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('pdf')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-danger-500 text-inverse transition-colors hover:bg-danger-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'pdf' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="pdf" size="md" />}
                <span className="text-xs leading-tight">PDF İndir</span>
              </button>
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('excel')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-success-500 text-inverse transition-colors hover:bg-success-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'excel' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="excel" size="md" />}
                <span className="text-xs leading-tight">Excel İndir</span>
              </button>
              <div className="relative">
                <button type="button" onClick={() => setPaylasAcik((o) => !o)} className="flex h-16 w-full cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md border border-background-300/70 text-foreground-700 transition-colors hover:bg-background-100 dark:border-background-400/40 dark:hover:bg-background-300/40">
                  <i className="ri-share-line text-lg" />
                  <span className="text-xs leading-tight">Paylaş</span>
                </button>
                {paylasAcik && (
                  <div className="absolute bottom-full right-0 z-20 mb-1 w-52 rounded-md border border-background-300/70 bg-background-50 p-1 shadow-xl dark:border-background-400/50 dark:bg-background-200">
                    <button type="button" onClick={() => void ozetKopyala()} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <i className="ri-clipboard-line" /> Özeti panoya kopyala
                    </button>
                    <button type="button" onClick={() => { setPaylasAcik(false); void indir('pdf'); }} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <Icon name="pdf" size="sm" /> PDF olarak indir
                    </button>
                  </div>
                )}
              </div>
            </div>
          </RwCard>

          <RwCard title="Rapor Bilgileri" icon="ri-file-list-3-line" className="p-3">
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <RwInput label="Rapor Numarası" value={raporNo} onChange={(e) => onTemelChange({ raporNo: e.target.value })} placeholder="FK-2026-001" />
              <RwSelect label="Geçerlilik Süresi" options={GECERLILIK_SECENEKLERI.map((v) => ({ value: v, label: v }))} value={temel.gecerlilik} onChange={(v) => onTemelChange({ gecerlilik: v })} />
              <p className="flex items-start gap-1.5 text-[11px] leading-relaxed text-foreground-500 sm:col-span-2">
                <i className="ri-information-line mt-0.5 text-primary-500" />
                <span>
                  Geçerlilik süresi tehlike sınıfına göre mevzuat gereği otomatik belirlenir:{' '}
                  <strong className="font-medium text-foreground-700">Az Tehlikeli 6 Yıl · Tehlikeli 4 Yıl · Çok Tehlikeli 2 Yıl.</strong>{' '}
                  Gerekirse listeden elle değiştirebilirsiniz.
                </span>
              </p>
            </div>
          </RwCard>

          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-foreground-950"><i className="ri-information-line text-primary-500" /> Fine-Kinney Rapor İçeriği</p>
            <p className="mt-1 text-xs leading-relaxed text-foreground-600">
              Rapor; çalışma bilgileri, tehlike ve risk listesi, Fine-Kinney ölçekleri, kontrol aksiyon planı, kontrol sonrası risk, özet ve imza bölümlerini içerir.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}