import { useState } from 'react';
import { RISK_KATEGORILERI, RISK_ALANLARI } from '@/components/feature/risk/riskSihirbazTypes';
import {
  FK_OLASILIK, FK_FREKANS, FK_SIDDET, fkPuan, fkPuanGoster, fkSeviyeBilgi, type FkRiskItem,
} from '@/components/feature/risk/fkTypes';
import { RwButton, RwInput, RwSelect, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// FINE-KINNEY · MANUEL RİSK EKLEME
// Olasılık (O), Frekans (F), Şiddet (S) Fine-Kinney ölçeklerinden seçilir;
// Risk Puanı (O×F×S) ve Seviyesi otomatik hesaplanır.
// ─────────────────────────────────────────────────────────────────────────────

export type FkManuelVerisi = Pick<
  FkRiskItem,
  'bolum' | 'kategori' | 'tehlike' | 'risk' | 'olasiSonuc' | 'mevcutKontroller' | 'notlar' | 'olasilik' | 'frekans' | 'siddet'
>;

interface Props {
  onKaydet: (veri: FkManuelVerisi) => void;
  onClose: () => void;
}

export default function FkManuelRiskModal({ onKaydet, onClose }: Props) {
  const [bolum, setBolum] = useState('');
  const [kategori, setKategori] = useState('');
  const [tehlike, setTehlike] = useState('');
  const [risk, setRisk] = useState('');
  const [olasiSonuc, setOlasiSonuc] = useState('');
  const [mevcutKontroller, setMevcutKontroller] = useState('');
  const [notlar, setNotlar] = useState('');
  const [o, setO] = useState('1');
  const [f, setF] = useState('6');
  const [s, setS] = useState('15');
  const [hata, setHata] = useState('');

  const puan = fkPuan(Number(o), Number(f), Number(s));
  const seviye = fkSeviyeBilgi(puan);

  const olasiOptions = FK_OLASILIK.map((x) => ({ value: String(x.value), label: `${String(x.value).replace('.', ',')} — ${x.label}` }));
  const frekansOptions = FK_FREKANS.map((x) => ({ value: String(x.value), label: `${String(x.value).replace('.', ',')} — ${x.label}` }));
  const siddetOptions = FK_SIDDET.map((x) => ({ value: String(x.value), label: `${String(x.value)} — ${x.label}` }));

  const kaydet = () => {
    if (!tehlike.trim() || !risk.trim()) {
      setHata('Tehlike ve Risk alanları zorunludur.');
      return;
    }
    onKaydet({
      bolum: bolum.trim(), kategori: kategori.trim(), tehlike: tehlike.trim(), risk: risk.trim(),
      olasiSonuc: olasiSonuc.trim(), mevcutKontroller: mevcutKontroller.trim(), notlar: notlar.trim(),
      olasilik: Number(o), frekans: Number(f), siddet: Number(s),
    });
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <RwSelect label="Bölüm / Alan" options={RISK_ALANLARI.map((v) => ({ value: v, label: v }))} value={bolum} onChange={setBolum} placeholder="Seçiniz veya yazın" searchable creatable />
        <RwSelect label="Kategori" options={RISK_KATEGORILERI.map((v) => ({ value: v, label: v }))} value={kategori} onChange={setKategori} placeholder="Seçiniz veya yazın" searchable creatable />
      </div>

      <RwInput label="Tehlike" required value={tehlike} onChange={(e) => setTehlike(e.target.value)} placeholder="Örn. Elektrik panosu" />
      <RwInput label="Risk" required value={risk} onChange={(e) => setRisk(e.target.value)} placeholder="Örn. Elektrik çarpması" />
      <RwInput label="Olası Sonuç" value={olasiSonuc} onChange={(e) => setOlasiSonuc(e.target.value)} placeholder="Örn. Ölüm / ciddi yaralanma" />
      <RwTextarea label="Mevcut Kontroller" value={mevcutKontroller} onChange={(e) => setMevcutKontroller(e.target.value)} placeholder="Örn. Kaçak akım rölesi, topraklama" />

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <RwSelect label="Olasılık (O)" options={olasiOptions} value={o} onChange={setO} searchable />
        <RwSelect label="Frekans (F)" options={frekansOptions} value={f} onChange={setF} searchable />
        <RwSelect label="Şiddet (S)" options={siddetOptions} value={s} onChange={setS} searchable />
      </div>

      <div className="flex items-center justify-between rounded-md border border-background-300/60 bg-background-100 px-3 py-2.5 dark:border-background-400/30 dark:bg-background-200/50">
        <span className="text-xs text-foreground-500">Risk Puanı = O × F × S</span>
        <div className="flex items-center gap-2">
          <span className="text-base font-bold text-foreground-950">{fkPuanGoster(puan)}</span>
          <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-bold text-inverse ${seviye.badge}`}>
            <i className={`${seviye.icon} text-xs`} /> {seviye.label}
          </span>
        </div>
      </div>

      <RwTextarea label="Açıklama / Notlar" value={notlar} onChange={(e) => setNotlar(e.target.value)} />

      {hata && (
        <p className="flex items-center gap-1 text-xs text-danger-600"><i className="ri-error-warning-line" /> {hata}</p>
      )}

      <div className="flex items-center justify-end gap-2 border-t border-background-300/30 pt-3 dark:border-background-400/30">
        <RwButton variant="ghost" onClick={onClose}>İptal</RwButton>
        <RwButton variant="primary" icon="ri-add-line" onClick={kaydet}>Listeye Ekle</RwButton>
      </div>
    </div>
  );
}