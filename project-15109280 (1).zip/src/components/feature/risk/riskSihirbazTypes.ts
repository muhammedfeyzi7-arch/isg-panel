// ─────────────────────────────────────────────────────────────────────────────
// RİSK DEĞERLENDİRMESİ DOKÜMAN HAZIRLAMA SİHİRBAZI — ORTAK VERİ MODELİ
//
// Bu dosya 4 adımın tamamının (ve rapor çıktısının) paylaştığı TEK merkezi veri
// modelini tanımlar. Adımlar birbirinden kopuk state tutmaz; hepsi bu workspace
// üzerinden beslenir. Bu sayede adım 2'de oluşan risk, adım 3 ve 4'te otomatik
// hazır gelir; adım 4 sonuçları Word/PDF/Excel çıktısına gider.
//
// ÖNEMLİ: Bu modül 5x5 L Tipi Matris (Olasılık × Şiddet) veri modelini tanımlar.
// Fine-Kinney (fkTypes.ts) ve HAZOP (hazopTypes.ts) ayrı yöntemlerdir ve kendi
// veri modellerini kullanır. Kalıcı kayıt/arşiv için Supabase tabloları vardır;
// workspace kenar çubuğu GEÇİCİ çalışma alanıdır (IndexedDB).
// ─────────────────────────────────────────────────────────────────────────────

export type RiskKaynagi = 'ai' | 'manuel' | 'sablon' | 'excel';
export type RiskSeviyesi = 'dusuk' | 'orta' | 'yuksek';

/** Bir risk kaydı — 2, 3 ve 4. adımların paylaştığı tek kayıt. */
export interface RiskItem {
  id: string;
  kaynak: RiskKaynagi;
  bolum: string;          // Bölüm / Alan
  kategori: string;       // Kategori
  tehlike: string;        // Tehlike
  risk: string;           // Risk
  olasiSonuc: string;     // Olası Sonuç
  mevcutKontroller: string;
  onerilenKontroller: string;
  sorumlu: string;
  termin: string;
  durum: string;
  /** Faaliyet rutin bir iş mi? (Rapor "Rutin" kolonu: Evet/Hayır) */
  rutin?: boolean;
  /** Etkilenen kişi/gruplar (Rapor "Etkilenenler" kolonu). */
  etkilenenler?: string;
  olasilik: number;       // 1–5
  siddet: number;         // 1–5
  notlar: string;
  /** Kontrol türü (Ortadan kaldırma / İkame / Mühendislik / İdari / KKD). */
  kontrolTuru?: string;
  /** Aksiyon başlangıç tarihi (ISO). */
  baslangic?: string;
  /** Kontrol SONRASI olasılık (1–5). Boşsa raporda ilk değer kullanılır. */
  kalanOlasilik?: number;
  /** Kontrol SONRASI şiddet (1–5). Boşsa raporda ilk değer kullanılır. */
  kalanSiddet?: number;
}

/** Rapor imzacı/ekip satırı. */
export interface Imzaci {
  id: string;
  adSoyad: string;
  gorev: string;
  belge: string;
}

/** AI tehlike önerisi — workspace'e EKLENMEDEN önceki öneri kartı. */
export interface AiOneri {
  id: string;
  kategori: string;
  bolum: string;
  tehlike: string;
  risk: string;
  olasiSonuc: string;
  mevcutKontroller: string;
  onerilenKontroller: string;
  olasilik: number;
  siddet: number;
}

/** 1. adım — Temel bilgiler. */
export interface TemelBilgiler {
  calismaAdi: string;
  firma: string;
  degerlendirmeMetodu: string;
  kapsam: string;
  tarih: string;
  tesis: string;
  gecerlilik: string;
  amac: string;
  ekip: string[];
  /** Yalnızca dosya adları tutulur (rapor dipnotu); binary saklanmaz. */
  dokumanlar: string[];
  /* ── Rapor künye alanları (opsiyonel; boşsa raporda “—”) ── */
  raporNo: string;
  tehlikeSinifi: string;
  adres: string;
  isveren: string;
  nace: string;
  /** Seçili NACE kaydının id'si (nace_kodlari tablosu). Seçim yeniden yüklenince korunur. */
  naceId?: string;
  calisanSayisi: string;
  hazirlayan: string;
  onaylayan: string;
  imzacilar: Imzaci[];
}

/** Sihirbazın GEÇİCİ çalışma alanı (kalıcı kayıt DEĞİLDİR). */
export interface RiskWorkspace {
  temel: TemelBilgiler;
  riskler: RiskItem[];
  aiOnerileri: AiOneri[];
  aktifAdim: number;
  guncellendi: string;
}

// ── Risk seviyesi mantığı (referans: 5x5) ────────────────────────────────────
export function riskPuani(olasilik: number, siddet: number): number {
  return Math.max(1, Math.min(5, olasilik)) * Math.max(1, Math.min(5, siddet));
}

/** 1–5 Düşük · 6–15 Orta · 16–25 Yüksek */
export function riskSeviyesi(puan: number): RiskSeviyesi {
  if (puan <= 5) return 'dusuk';
  if (puan <= 15) return 'orta';
  return 'yuksek';
}

export interface SeviyeMeta {
  key: RiskSeviyesi;
  label: string;
  /** Katı rozet (dolgu). */
  badge: string;
  /** Yumuşak rozet (açık zemin). */
  soft: string;
  text: string;
  dot: string;
  /** Rozet ikonu (referans: yuvarlak + ikonlu etiket). */
  icon: string;
  /** Matris hücre dolgusu için ham token. */
  hucre: string;
}

export const SEVIYE_META: Record<RiskSeviyesi, SeviyeMeta> = {
  dusuk: {
    key: 'dusuk',
    label: 'Düşük',
    badge: 'bg-success-500 text-inverse',
    soft: 'bg-success-50 text-success-700 dark:bg-success-500/15 dark:text-success-300',
    text: 'text-success-700 dark:text-success-300',
    dot: 'bg-success-500',
    icon: 'ri-checkbox-circle-line',
    hucre: 'bg-success-500',
  },
  orta: {
    key: 'orta',
    label: 'Orta',
    badge: 'bg-warning-500 text-inverse',
    soft: 'bg-warning-50 text-warning-700 dark:bg-warning-500/15 dark:text-warning-300',
    text: 'text-warning-700 dark:text-warning-300',
    dot: 'bg-warning-500',
    icon: 'ri-alert-line',
    hucre: 'bg-warning-500',
  },
  yuksek: {
    key: 'yuksek',
    label: 'Yüksek',
    badge: 'bg-danger-500 text-inverse',
    soft: 'bg-danger-50 text-danger-700 dark:bg-danger-500/15 dark:text-danger-300',
    text: 'text-danger-700 dark:text-danger-300',
    dot: 'bg-danger-500',
    icon: 'ri-error-warning-line',
    hucre: 'bg-danger-500',
  },
};

/**
 * Puan → matris hücresi rengi. RENK AİLELERİ `riskSeviyesi` ile BİREBİR uyumlu
 * olmalıdır (5x5 L Tipi Matris, 6331 sayılı Kanun kapsamı):
 *   Düşük (1–5)   → yeşil
 *   Orta  (6–15)  → sarı / turuncu
 *   Yüksek (16–25)→ kırmızı
 * Bu sayede matris, seviye açıklamaları ve özet kartları AYNI sonucu verir;
 * 6–9 puan aralığı yanlışlıkla yeşil gösterilmez.
 */
export function hucreSinifi(puan: number): string {
  if (puan <= 5) return 'bg-success-500';
  if (puan <= 9) return 'bg-warning-400';
  if (puan <= 15) return 'bg-warning-500';
  if (puan <= 20) return 'bg-danger-400';
  return 'bg-danger-600';
}

// ── Sabit listeler ───────────────────────────────────────────────────────────
export const RISK_KATEGORILERI: string[] = [
  'Makine ve Ekipmanlar',
  'Elektrik',
  'Yangın',
  'Kimyasal Riskler',
  'Fiziksel Riskler',
  'Ergonomi',
  'Elle Taşıma',
  'Yüksekte Çalışma',
  'Kapalı Alan',
  'Kayma / Takılma / Düşme',
  'Trafik / Araç / Forklift',
  'Depolama',
  'Basınçlı Ekipman',
  'Kaldırma Ekipmanları',
  'İş Organizasyonu',
  'Çalışma Ortamı',
  'Gürültü',
  'Titreşim',
  'Aydınlatma',
  'Termal Konfor',
  'Toz',
  'Biyolojik Riskler',
  'Acil Durum',
  'Patlama / ATEX',
  'Bakım / Onarım',
  'Kaynak / Kesme / Taşlama',
  'Ofis / İdari Alanlar',
  'Laboratuvar',
  'Şantiye',
  'Depo / Lojistik',
  'Atölye',
  'Üretim',
  'Temizlik',
  'Kişisel Koruyucu Donanım',
  'İnsan Faktörleri',
  'Eğitim / Yetkinlik',
  'Diğer',
];

export const RISK_ALANLARI: string[] = [
  'Üretim Alanı',
  'Depolama Alanı',
  'Bakım Atölyesi',
  'İdari Binalar',
  'Açık Alanlar',
  'Elektrik Odası',
  'Kimyasal Depo',
  'Yükleme / Boşaltma Alanı',
  'Ofis / İdari',
  'Laboratuvar',
  'Şantiye',
  'Depo / Lojistik',
  'Atölye',
];

export const RISK_DURUMLARI = ['Planlandı', 'Devam Ediyor', 'Başlamadı', 'Tamamlandı'];
export const KONTROL_TURLERI = ['Ortadan Kaldırma', 'İkame', 'Mühendislik Kontrolü', 'İdari Kontrol', 'KKD'];
export const TEHLIKE_SINIFLARI = ['Az Tehlikeli', 'Tehlikeli', 'Çok Tehlikeli'];
// Geçerlilik süresi MEVZUATA göre tehlike sınıfına bağlıdır (İş Sağlığı ve Güvenliği
// Risk Değerlendirmesi Yönetmeliği · m.12 yenileme sıklığı):
//   Az Tehlikeli → 6 Yıl · Tehlikeli → 4 Yıl · Çok Tehlikeli → 2 Yıl
export const GECERLILIK_SECENEKLERI = ['2 Yıl', '4 Yıl', '6 Yıl'];

/** Tehlike sınıfı → mevzuata uygun geçerlilik süresi eşlemesi. */
export const GECERLILIK_BY_TEHLIKE: Record<string, string> = {
  'Az Tehlikeli': '6 Yıl',
  'Tehlikeli': '4 Yıl',
  'Çok Tehlikeli': '2 Yıl',
};

/** Tehlike sınıfına karşılık gelen geçerlilik süresini döner (eşleşme yoksa null). */
export function gecerlilikForTehlike(tehlikeSinifi: string): string | null {
  return GECERLILIK_BY_TEHLIKE[tehlikeSinifi] ?? null;
}

/**
 * Tehlike sınıfı seçildiğinde temel bilgiler için patch üretir; geçerlilik süresini
 * MEVZUATA göre (Az 6 / Tehlikeli 4 / Çok Tehlikeli 2 Yıl) otomatik doldurur.
 */
export function tehlikeGecerlilikPatch(tehlikeSinifi: string): { tehlikeSinifi: string; gecerlilik?: string } {
  const g = gecerlilikForTehlike(tehlikeSinifi);
  return g ? { tehlikeSinifi, gecerlilik: g } : { tehlikeSinifi };
}
export const RISK_METODU = '5x5 L Tipi Matris (Olasılık × Şiddet)';

export const TUM_ALANLAR = 'Tüm Alanlar';
export const TUM_KATEGORILER = 'Tüm Kategoriler';

export const ADIM_BASLIKLARI = [
  'Temel Bilgiler',
  'Tehlikeler ve Riskler',
  'Kontroller ve Aksiyonlar',
  'Değerlendirme',
  'Rapor ve Önizleme',
];

let sayac = 0;
export function yeniId(onek = 'risk'): string {
  sayac += 1;
  return `${onek}-${Date.now().toString(36)}-${sayac}`;
}

export function bosRisk(bolum = '', kaynak: RiskKaynagi = 'manuel'): RiskItem {
  return {
    id: yeniId(),
    kaynak,
    bolum,
    kategori: '',
    tehlike: '',
    risk: '',
    olasiSonuc: '',
    mevcutKontroller: '',
    onerilenKontroller: '',
    sorumlu: '',
    termin: '',
    durum: 'Planlandı',
    rutin: true,
    etkilenenler: '',
    olasilik: 3,
    siddet: 3,
    notlar: '',
  };
}

export function bosTemelBilgiler(): TemelBilgiler {
  const bugun = new Date();
  const iso = `${bugun.getFullYear()}-${String(bugun.getMonth() + 1).padStart(2, '0')}-${String(bugun.getDate()).padStart(2, '0')}`;
  return {
    calismaAdi: '',
    firma: '',
    degerlendirmeMetodu: RISK_METODU,
    kapsam: '',
    tarih: iso,
    tesis: '',
    gecerlilik: '',
    amac: '',
    ekip: [],
    dokumanlar: [],
    raporNo: '',
    tehlikeSinifi: '',
    adres: '',
    isveren: '',
    nace: '',
    naceId: '',
    calisanSayisi: '',
    hazirlayan: '',
    onaylayan: '',
    imzacilar: [],
  };
}

export function bosWorkspace(): RiskWorkspace {
  return {
    temel: bosTemelBilgiler(),
    riskler: [],
    aiOnerileri: [],
    aktifAdim: 0,
    guncellendi: new Date().toISOString(),
  };
}

// ── Yardımcılar ──────────────────────────────────────────────────────────────
/** Türkçe-duyarsız normalize (duplicate kontrolü için). */
export function normalize(s: string): string {
  return (s || '')
    .toLocaleLowerCase('tr')
    .replace(/[çğıöşü]/g, (c) => ({ ç: 'c', ğ: 'g', ı: 'i', ö: 'o', ş: 's', ü: 'u' }[c] ?? c))
    .replace(/[^a-z0-9\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/** Anlamsal-benzer duplicate kontrolü (hafif): ortak kelime oranı. */
export function benzerMi(a: string, b: string): boolean {
  const na = normalize(a);
  const nb = normalize(b);
  if (!na || !nb) return false;
  if (na === nb) return true;
  if (na.includes(nb) || nb.includes(na)) return true;
  const ka = new Set(na.split(' ').filter((w) => w.length > 2));
  const kb = new Set(nb.split(' ').filter((w) => w.length > 2));
  if (ka.size === 0 || kb.size === 0) return false;
  let ortak = 0;
  ka.forEach((w) => { if (kb.has(w)) ortak += 1; });
  return ortak / Math.min(ka.size, kb.size) >= 0.75;
}

export function riskDoluluk(r: RiskItem): boolean {
  return !!r.tehlike.trim() && !!r.risk.trim();
}