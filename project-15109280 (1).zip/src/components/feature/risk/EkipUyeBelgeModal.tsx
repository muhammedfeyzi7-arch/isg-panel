import { useCallback, useEffect, useState } from 'react';
import Button from '@/components/ui/Button';
import Select from '@/components/ui/Select';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import { useToastActions } from '@/hooks/useToast';
import {
  type EvrakTuru,
  type EvrakData,
  fetchEvrakTurleri,
  fetchEvraklarPage,
  uploadEvrak,
  getEvrakUrl,
  friendlyEvrakError,
  scopeShownToGenericPersonel,
} from '@/lib/evrakService';

interface Props {
  firmaId: string;
  personelId: string;
  personelAd: string;
  onClose: () => void;
  onChanged?: () => void;
}

const MAX_EVRAK_SIZE = 15 * 1024 * 1024;
const EVRAK_ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.odt,.ods,.txt,image/jpeg,image/png,image/webp';

/**
 * Bir ekip üyesinin dijital dosyasındaki belgeleri gösterir ve yeni belge yükler.
 * Merkezi evrak altyapısını (uploadEvrak + fetchEvraklarPage + evrak edge function)
 * kullanır; yeni bir yükleme sistemi OLUŞTURMAZ. Yüklenen belge personel dosyasında
 * ve Evraklar > Personel Dosyaları sekmesinde otomatik görünür.
 */
export default function EkipUyeBelgeModal({ firmaId, personelId, personelAd, onClose, onChanged }: Props) {
  const { addToast } = useToastActions();
  const [turler, setTurler] = useState<EvrakTuru[]>([]);
  const [belgeler, setBelgeler] = useState<EvrakData[]>([]);
  const [loading, setLoading] = useState(true);
  const [tip, setTip] = useState('');
  const [dosyalar, setDosyalar] = useState<UploadFile[]>([]);
  const [yukleniyor, setYukleniyor] = useState(false);
  const [hata, setHata] = useState<string | null>(null);

  const yukle = useCallback(() => {
    setLoading(true);
    Promise.all([
      fetchEvraklarPage({ ownerType: 'personel', personelId, pageSize: 50 }),
      fetchEvrakTurleri().catch(() => [] as EvrakTuru[]),
    ])
      .then(([page, tumTurler]) => {
        setBelgeler(page.data);
        setTurler(tumTurler.filter((t) => t.ownerType === 'personel' && !t.isHealth));
      })
      .catch(() => {
        setBelgeler([]);
        setTurler([]);
      })
      .finally(() => setLoading(false));
  }, [personelId]);

  useEffect(() => { yukle(); }, [yukle]);

  const tipOptions = turler
    .filter((t) => scopeShownToGenericPersonel(t.personelRoleScope))
    .map((t) => ({ value: t.id, label: t.name }));

  const handleYukle = async () => {
    const raw = dosyalar[0]?.raw;
    if (!raw) {
      setHata('Lütfen bir dosya seçin.');
      return;
    }
    setHata(null);
    setYukleniyor(true);
    try {
      const tipLabel = tipOptions.find((t) => t.value === tip)?.label ?? raw.name;
      await uploadEvrak({
        ownerType: 'personel',
        firmaId,
        personelId,
        documentTypeId: tip || null,
        title: tipLabel,
        file: raw,
      });
      addToast({ title: 'Belge yüklendi', message: 'Belge personel dosyasına eklendi.', type: 'success' });
      setDosyalar([]);
      setTip('');
      yukle();
      onChanged?.();
    } catch (e) {
      setHata(friendlyEvrakError(e));
    } finally {
      setYukleniyor(false);
    }
  };

  const ac = async (b: EvrakData) => {
    if (!b.originalFileName) return;
    try {
      const url = await getEvrakUrl(b.id);
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch (e) {
      addToast({ title: 'Dosya açılamadı', message: friendlyEvrakError(e), type: 'error' });
    }
  };

  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-background-100 dark:bg-background-200/50">
        <span className="w-8 h-8 rounded-md bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-300 flex items-center justify-center flex-shrink-0">
          <i className="ri-folder-user-line" />
        </span>
        <div className="min-w-0">
          <p className="text-sm font-semibold text-foreground-900 truncate">{personelAd}</p>
          <p className="text-[11px] text-foreground-500">Personel belgeleri ({belgeler.length})</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-8"><Loading size="md" text="Belgeler yükleniyor..." /></div>
      ) : belgeler.length === 0 ? (
        <EmptyState icon="ri-folder-open-line" title="Belge yok" description="Bu personel için henüz belge yüklenmemiş." />
      ) : (
        <ul className="space-y-1.5 max-h-56 overflow-y-auto">
          {belgeler.map((b) => (
            <li key={b.id} className="flex items-center gap-2 p-2 rounded-md border border-background-200/70 dark:border-background-400/25">
              <i className="ri-file-line text-foreground-400" />
              <span className="flex-1 min-w-0 text-sm text-foreground-800 truncate">{b.title}</span>
              <button
                type="button"
                onClick={() => ac(b)}
                className="w-7 h-7 rounded-md flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 cursor-pointer"
                aria-label="Aç"
                title="Aç"
              >
                <i className="ri-external-link-line" />
              </button>
            </li>
          ))}
        </ul>
      )}

      <div className="pt-2 border-t isg-divider space-y-3">
        <Select
          label="Belge Türü"
          options={tipOptions}
          value={tip}
          onChange={(e) => setTip(e.target.value)}
          placeholder="Belge türü seçin (opsiyonel)"
          searchable
        />
        <FileUpload
          label="Dosya"
          accept={EVRAK_ACCEPT}
          maxSize={MAX_EVRAK_SIZE}
          files={dosyalar}
          onChange={setDosyalar}
          multiple={false}
          helpText="PDF, Word, Excel veya görsel. En fazla 15 MB."
        />
        {hata && (
          <p className="text-sm text-danger-600 flex items-center gap-1.5">
            <i className="ri-error-warning-line" />{hata}
          </p>
        )}
        <div className="flex items-center justify-end gap-2">
          <Button variant="ghost" size="sm" onClick={onClose} disabled={yukleniyor}>Kapat</Button>
          <Button
            variant="primary"
            size="sm"
            leftIcon={<i className="ri-upload-2-line" />}
            onClick={handleYukle}
            isLoading={yukleniyor}
            disabled={dosyalar.length === 0}
          >
            Yükle
          </Button>
        </div>
      </div>
    </div>
  );
}