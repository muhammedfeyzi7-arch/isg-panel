import { useMemo, useRef, useState } from 'react';
import { useModalActions } from '@/hooks/useModal';
import AcilPersonelSecModal, { type SecilenPersonel } from '@/components/feature/risk/acil/AcilPersonelSecModal';
import {
  ACIL_DERECELERI, EKIP_ROLLERI, SENARYO_KATEGORILERI, SENARYO_SABLONLARI, TATBIKAT_KONULARI, ZORUNLU_EKIPLER,
  dereceMeta, rolIkon, rolMeta, senaryoIkon,
  type AcilAiOneri, type AcilIletisim, type AcilMalzeme, type AcilSenaryo, type DestekHesap, type EkipUyesi, type SenaryoSablon, type Tatbikat,
} from '@/components/feature/risk/acilDurumTypes';
import { RwButton, RwCard, RwIconButton, RwInput, RwSectionTitle, RwSelect, RwTabs, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';
import { matchesSearch } from '@/utils/turkishText';

// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM EYLEM PLANI · ADIM 2 — EKİPLER, SENARYOLAR, İLETİŞİM, MALZEME, TATBİKAT
//
// Beş sekmeli tam çalışma alanı. Mevzuatın zorunlu kıldığı unsurlar (destek
// elemanı sayı kontrolü, zorunlu ekipler, acil iletişim numaraları, acil durum
// malzeme envanteri ve tatbikat planı) burada yönetilir. Acil durum ekibi elle
// VEYA sistem personelinden seçilebilir — seçim yalnızca okumadır.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  ekipler: EkipUyesi[];
  senaryolar: AcilSenaryo[];
  iletisim: AcilIletisim[];
  malzemeler: AcilMalzeme[];
  tatbikatlar: Tatbikat[];
  aiOnerileri: AcilAiOneri[];
  aiYukleniyor: boolean;
  destek: DestekHesap;
  onEkipEkle: () => void;
  onEkipGuncelle: (id: string, patch: Partial<EkipUyesi>) => void;
  onEkipSil: (id: string) => void;
  onPersoneldenEkle: (secilenler: SecilenPersonel[]) => void;
  onZorunluEkipleriEkle: () => void;
  onEkipRolEkle: (rol: string) => void;
  onSenaryoEkle: () => void;
  onSenaryoGuncelle: (id: string, patch: Partial<AcilSenaryo>) => void;
  onSenaryoSil: (id: string) => void;
  onAiYenile: () => void;
  onOneriEkle: (o: AcilAiOneri) => void;
  onSablondanEkle: (s: SenaryoSablon) => void;
  onIletisimEkle: () => void;
  onIletisimGuncelle: (id: string, patch: Partial<AcilIletisim>) => void;
  onIletisimSil: (id: string) => void;
  onMalzemeEkle: () => void;
  onMalzemeGuncelle: (id: string, patch: Partial<AcilMalzeme>) => void;
  onMalzemeSil: (id: string) => void;
  onTatbikatEkle: () => void;
  onTatbikatGuncelle: (id: string, patch: Partial<Tatbikat>) => void;
  onTatbikatSil: (id: string) => void;
}

type Sekme = 'ekipler' | 'senaryolar' | 'iletisim' | 'malzeme' | 'tatbikat';

const ORNEK_SORULAR = [
  'Bu tehlike sınıfı için hangi acil durum senaryoları öncelikli?',
  'Acil durum ekibinde hangi roller bulunmalı?',
  'Kimyasal/gaz riski olan işyerinde hangi senaryolara hazırlık gerekir?',
  'Tahliye gerektiren durumlar nasıl belirlenir?',
];

export default function AcilAdim2Ekipler({
  ekipler, senaryolar, iletisim, malzemeler, tatbikatlar, aiOnerileri, aiYukleniyor, destek,
  onEkipEkle, onEkipGuncelle, onEkipSil, onPersoneldenEkle, onZorunluEkipleriEkle, onEkipRolEkle,
  onSenaryoEkle, onSenaryoGuncelle, onSenaryoSil, onAiYenile, onOneriEkle, onSablondanEkle,
  onIletisimEkle, onIletisimGuncelle, onIletisimSil,
  onMalzemeEkle, onMalzemeGuncelle, onMalzemeSil,
  onTatbikatEkle, onTatbikatGuncelle, onTatbikatSil,
}: Props) {
  const [sekme, setSekme] = useState<Sekme>('ekipler');
  const [sablonArama, setSablonArama] = useState('');
  const { openModal, closeModal } = useModalActions();
  const modalIdRef = useRef('');

  const personelSecAc = () => {
    const kapat = () => { if (modalIdRef.current) closeModal(modalIdRef.current); };
    modalIdRef.current = openModal({
      title: 'Sistem Personelinden Seç',
      description: 'Acil durum ekibine eklemek istediğiniz personeli seçin.',
      size: 'md', width: 540, height: 640, minWidth: 400, minHeight: 420,
      bodyLayout: 'fill', showFooter: false, closable: true,
      content: <AcilPersonelSecModal onKapat={kapat} onEkle={onPersoneldenEkle} />,
    });
  };

  const sablonlar = useMemo(() => {
    const q = sablonArama.trim().toLocaleLowerCase('tr');
    if (!q) return SENARYO_SABLONLARI;
    return SENARYO_SABLONLARI.filter((s) => matchesSearch(`${s.kategori} ${s.olay} ${s.aciklama}`, q));
  }, [sablonArama]);

  // Zorunlu ekip kontrolü (m.8)
  const rolSayilari = useMemo(() => {
    const m = new Map<string, number>();
    ekipler.forEach((e) => m.set(e.ekipRolu, (m.get(e.ekipRolu) ?? 0) + 1));
    return m;
  }, [ekipler]);
  const eksikEkipler = ZORUNLU_EKIPLER.filter((r) => (rolSayilari.get(r) ?? 0) === 0);

  const malzemeToplam = malzemeler.reduce((t, m) => t + (Number(m.adet) || 0), 0);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="2. Ekipler, Senaryolar ve Hazırlık"
        desc="Acil durum ekiplerini kurun, senaryoları belirleyin; iletişim, malzeme ve tatbikat bilgilerini tamamlayın."
        right={(
          <RwTabs
            tabs={[
              { key: 'ekipler', label: 'Ekipler', count: ekipler.length },
              { key: 'senaryolar', label: 'Senaryolar', count: senaryolar.length },
              { key: 'iletisim', label: 'İletişim', count: iletisim.length },
              { key: 'malzeme', label: 'Malzeme', count: malzemeler.length },
              { key: 'tatbikat', label: 'Tatbikat', count: tatbikatlar.length },
            ]}
            active={sekme}
            onChange={(k) => setSekme(k as Sekme)}
          />
        )}
      />

      <div className={`grid min-h-0 flex-1 grid-cols-1 gap-3 ${sekme === 'senaryolar' ? 'xl:grid-cols-[minmax(0,1fr)_340px]' : ''}`}>
        {/* SOL */}
        <div className="isg-scroll-pane min-h-0 space-y-2.5 overflow-y-auto pr-1">
          {sekme === 'ekipler' && (
            <>
              {/* Zorunlu ekip kontrol bandı */}
              <div className={`rounded-lg border p-2.5 ${eksikEkipler.length === 0 ? 'border-success-500/40 bg-success-500/5' : 'border-warning-500/40 bg-warning-500/5'}`}>
                <div className="flex flex-wrap items-center gap-1.5">
                  <i className={`${eksikEkipler.length === 0 ? 'ri-checkbox-circle-line text-success-600' : 'ri-error-warning-line text-warning-600'}`} />
                  <span className="text-xs font-semibold text-foreground-900">Zorunlu Ekipler (m.8)</span>
                  <span className="text-[11px] text-foreground-500">
                    {eksikEkipler.length === 0 ? '— tüm zorunlu ekipler kadrolu' : `— ${eksikEkipler.length} ekip eksik`}
                  </span>
                </div>
                <div className="mt-1.5 flex flex-wrap gap-1.5">
                  {ZORUNLU_EKIPLER.map((r) => {
                    const var_ = (rolSayilari.get(r) ?? 0) > 0;
                    return (
                      <button
                        key={r}
                        type="button"
                        onClick={() => { if (!var_) onEkipRolEkle(r); }}
                        className={`inline-flex cursor-pointer items-center gap-1 rounded-md border px-2 py-1 text-[10px] font-medium transition-colors ${
                          var_
                            ? 'border-success-500/50 bg-success-500/12 text-success-700 dark:text-success-300'
                            : 'border-warning-500/50 bg-warning-500/12 text-warning-700 hover:bg-warning-500/20 dark:text-warning-300'
                        }`}
                      >
                        <i className={var_ ? 'ri-check-line' : 'ri-add-line'} /> {r}{var_ ? '' : ' ekle'}
                      </button>
                    );
                  })}
                </div>
              </div>

              {destek.gecerli && (
                <div className="rounded-lg border border-background-300/50 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
                  <div className="flex items-center gap-1.5">
                    <i className="ri-team-line text-xs text-primary-500" />
                    <span className="text-xs font-semibold text-foreground-900">Zorunlu Asgari Destek Elemanı</span>
                  </div>
                  <div className="mt-1.5 flex flex-wrap gap-1.5">
                    {destek.satirlar.map((s) => (
                      <span key={s.konu} className="inline-flex items-center gap-1 rounded-md bg-secondary-100 px-2 py-1 text-[10px] font-medium text-secondary-900 dark:bg-secondary-500/15 dark:text-secondary-200">
                        {s.konu}: en az <strong className="mx-0.5">{s.gerekli}</strong>
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-2">
                <RwButton variant="outline" size="sm" icon="ri-team-line" onClick={personelSecAc}>Personelden Seç</RwButton>
                <RwButton variant="secondary" size="sm" icon="ri-add-line" onClick={onEkipEkle}>Manuel Üye Ekle</RwButton>
                {eksikEkipler.length > 0 && (
                  <RwButton variant="outline" size="sm" icon="ri-magic-line" onClick={onZorunluEkipleriEkle}>Eksik Ekipleri Oluştur ({eksikEkipler.length})</RwButton>
                )}
              </div>

              {ekipler.length === 0 && (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-background-300/70 bg-background-100/60 px-4 py-14 text-center dark:border-background-400/40 dark:bg-background-200/30">
                  <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                    <i className="ri-team-line text-2xl" />
                  </span>
                  <p className="mt-2 text-sm font-medium text-foreground-700">Henüz ekip üyesi eklenmemiş</p>
                  <p className="mt-1 text-xs text-foreground-500">Sistem personelinden seçin veya manuel üye ekleyin.</p>
                </div>
              )}

              {ekipler.map((u, i) => {
                const rm = rolMeta(u.ekipRolu);
                return (
                  <div key={u.id} className="rounded-lg border border-background-300/60 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
                    <div className="flex items-center gap-2">
                      <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300">
                        <i className={`${rolIkon(u.ekipRolu)} text-xs`} />
                      </span>
                      <span className="text-xs font-semibold text-foreground-400">#{i + 1}</span>
                      <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold ${rm.soft}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${rm.dot}`} /> {u.ekipRolu}
                      </span>
                      {u.kaynak === 'sistem' && (
                        <span className="inline-flex items-center gap-1 rounded-md bg-background-200 px-2 py-0.5 text-[10px] font-medium text-foreground-500 dark:bg-background-300/50">
                          <i className="ri-cloud-line" /> Sistem
                        </span>
                      )}
                      <span className="ml-auto">
                        <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={() => onEkipSil(u.id)} />
                      </span>
                    </div>

                    <div className="mt-2.5 grid grid-cols-1 gap-2.5 md:grid-cols-2">
                      <RwInput label="Ad Soyad" size="sm" required value={u.adSoyad} onChange={(e) => onEkipGuncelle(u.id, { adSoyad: e.target.value })} placeholder="Ad Soyad" className={!u.adSoyad.trim() ? 'border-danger-400/70' : ''} />
                      <RwInput label="Unvan / Görev" size="sm" value={u.gorev} onChange={(e) => onEkipGuncelle(u.id, { gorev: e.target.value })} placeholder="Örn. Üretim Şefi" />
                      <RwSelect label="Ekip Rolü" size="sm" options={EKIP_ROLLERI.map((r) => ({ value: r, label: r }))} value={u.ekipRolu} onChange={(v) => onEkipGuncelle(u.id, { ekipRolu: v })} />
                      <RwInput label="Telefon" size="sm" value={u.telefon} onChange={(e) => onEkipGuncelle(u.id, { telefon: e.target.value })} placeholder="Örn. 0532 000 00 00" />
                      <div className="md:col-span-2">
                        <RwInput label="Belge / Eğitim (Örn. sertifika)" size="sm" value={u.belge} onChange={(e) => onEkipGuncelle(u.id, { belge: e.target.value })} placeholder="Örn. Yangın eğitimi sertifikası" />
                      </div>
                    </div>
                  </div>
                );
              })}
            </>
          )}

          {sekme === 'senaryolar' && (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <RwButton variant="outline" size="sm" icon={aiYukleniyor ? undefined : 'ri-sparkling-2-line'} disabled={aiYukleniyor} onClick={onAiYenile}>
                  {aiYukleniyor ? 'Üretiliyor...' : 'AI ile Öneri Al'}
                </RwButton>
                <RwButton variant="secondary" size="sm" icon="ri-add-line" onClick={onSenaryoEkle}>Senaryo Ekle</RwButton>
              </div>

              {senaryolar.length === 0 && (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-background-300/70 bg-background-100/60 px-4 py-14 text-center dark:border-background-400/40 dark:bg-background-200/30">
                  <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                    <i className="ri-alarm-warning-line text-2xl" />
                  </span>
                  <p className="mt-2 text-sm font-medium text-foreground-700">Henüz senaryo eklenmemiş</p>
                  <p className="mt-1 text-xs text-foreground-500">AI ile öneri alın, şablondan ekleyin veya kendiniz ekleyin.</p>
                  <div className="mt-3 flex flex-wrap items-center justify-center gap-2">
                    <RwButton variant="outline" size="sm" icon="ri-sparkling-2-line" disabled={aiYukleniyor} onClick={onAiYenile}>AI ile Öneri Al</RwButton>
                    <RwButton variant="secondary" size="sm" icon="ri-add-line" onClick={onSenaryoEkle}>Senaryo Ekle</RwButton>
                  </div>
                </div>
              )}

              {senaryolar.map((sn, i) => {
                const dm = dereceMeta(sn.derece);
                return (
                  <div key={sn.id} className="rounded-lg border border-background-300/60 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
                    <div className="flex items-center gap-2">
                      <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-300">
                        <i className={`${senaryoIkon(sn.kategori)} text-xs`} />
                      </span>
                      <span className="text-xs font-semibold text-foreground-400">#{i + 1}</span>
                      <span className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold ${dm.soft}`}>
                        <span className={`h-1.5 w-1.5 rounded-full ${dm.dot}`} /> {sn.derece}
                      </span>
                      {sn.tahliyeGerekli && (
                        <span className="inline-flex items-center gap-1 rounded-md bg-accent-500/15 px-2 py-0.5 text-[10px] font-semibold text-accent-700 dark:text-accent-300">
                          <i className="ri-door-open-line" /> Tahliye
                        </span>
                      )}
                      <span className="ml-auto">
                        <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={() => onSenaryoSil(sn.id)} />
                      </span>
                    </div>

                    <div className="mt-2.5 grid grid-cols-1 gap-2.5 md:grid-cols-2">
                      <RwSelect label="Kategori" size="sm" options={SENARYO_KATEGORILERI.map((k) => ({ value: k, label: k }))} value={sn.kategori} onChange={(v) => onSenaryoGuncelle(sn.id, { kategori: v })} />
                      <RwSelect label="Derece (Acil Durum Seviyesi)" size="sm" options={ACIL_DERECELERI.map((d) => ({ value: d, label: d }))} value={sn.derece} onChange={(v) => onSenaryoGuncelle(sn.id, { derece: v })} />
                      <div className="md:col-span-2">
                        <RwInput label="Olay / Senaryo" size="sm" required value={sn.olay} onChange={(e) => onSenaryoGuncelle(sn.id, { olay: e.target.value })} placeholder="Örn. Elektrik Kaynaklı Yangın" className={!sn.olay.trim() ? 'border-danger-400/70' : ''} />
                      </div>
                      <div className="md:col-span-2">
                        <RwTextarea label="Senaryo Açıklaması" maxLength={400} value={sn.aciklama} onChange={(e) => onSenaryoGuncelle(sn.id, { aciklama: e.target.value })} placeholder="Senaryonun kısa açıklaması" />
                      </div>
                      <RwInput label="Etkilenen Alan / Gruplar" size="sm" value={sn.etkilenen} onChange={(e) => onSenaryoGuncelle(sn.id, { etkilenen: e.target.value })} placeholder="Örn. Üretim alanı, depo" />
                      <RwSelect label="Sorumlu Ekip" size="sm" options={EKIP_ROLLERI.map((r) => ({ value: r, label: r }))} value={sn.sorumluEkip} onChange={(v) => onSenaryoGuncelle(sn.id, { sorumluEkip: v })} />
                      <div className="md:col-span-2">
                        <RwTextarea label="Müdahale / Eylem Adımları" maxLength={500} value={sn.mudahale} onChange={(e) => onSenaryoGuncelle(sn.id, { mudahale: e.target.value })} placeholder="Müdahale adımlarını kısaca yazın" />
                      </div>
                      <div className="md:col-span-2">
                        <button
                          type="button"
                          onClick={() => onSenaryoGuncelle(sn.id, { tahliyeGerekli: !sn.tahliyeGerekli })}
                          className={`inline-flex cursor-pointer items-center gap-2 rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors ${sn.tahliyeGerekli ? 'border-primary-500/60 bg-primary-500/10 text-primary-700 dark:text-primary-300' : 'border-background-300/60 text-foreground-600 dark:border-background-400/30'}`}
                        >
                          <span className={`flex h-4 w-4 items-center justify-center rounded border ${sn.tahliyeGerekli ? 'border-primary-500 bg-primary-500 text-inverse' : 'border-foreground-300 dark:border-background-400'}`}>
                            {sn.tahliyeGerekli && <i className="ri-check-line text-[10px]" />}
                          </span>
                          Tahliye gerektirir
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </>
          )}

          {sekme === 'iletisim' && (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <RwButton variant="secondary" size="sm" icon="ri-add-line" onClick={onIletisimEkle}>İletişim Satırı Ekle</RwButton>
                <span className="text-[11px] text-foreground-500">Acil durumda aranacak kurum ve numaralar (rapora yansır).</span>
              </div>
              <div className="overflow-hidden rounded-lg border border-background-300/60 dark:border-background-400/30">
                <table className="w-full border-collapse">
                  <thead className="bg-background-200 dark:bg-background-300/60">
                    <tr className="text-left text-[10px] font-semibold uppercase tracking-wide text-foreground-500">
                      <th className="px-2.5 py-2">Kurum / Kişi</th>
                      <th className="w-44 px-2.5 py-2">Telefon</th>
                      <th className="w-12 px-2.5 py-2 text-center">Sil</th>
                    </tr>
                  </thead>
                  <tbody>
                    {iletisim.map((k) => (
                      <tr key={k.id} className="border-t border-background-300/30 dark:border-background-400/20">
                        <td className="px-2.5 py-1.5">
                          <RwInput size="sm" value={k.kurum} onChange={(e) => onIletisimGuncelle(k.id, { kurum: e.target.value })} placeholder="Kurum / kişi adı" />
                        </td>
                        <td className="px-2.5 py-1.5">
                          <RwInput size="sm" value={k.telefon} onChange={(e) => onIletisimGuncelle(k.id, { telefon: e.target.value })} placeholder="Telefon" />
                        </td>
                        <td className="px-2.5 py-1.5 text-center">
                          <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={() => onIletisimSil(k.id)} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {sekme === 'malzeme' && (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <RwButton variant="secondary" size="sm" icon="ri-add-line" onClick={onMalzemeEkle}>Malzeme Ekle</RwButton>
                <span className="rounded-md bg-secondary-100 px-2 py-1 text-[11px] font-medium text-secondary-900 dark:bg-secondary-500/15 dark:text-secondary-200">Toplam adet: {malzemeToplam}</span>
              </div>
              <div className="overflow-hidden rounded-lg border border-background-300/60 dark:border-background-400/30">
                <table className="w-full border-collapse">
                  <thead className="bg-background-200 dark:bg-background-300/60">
                    <tr className="text-left text-[10px] font-semibold uppercase tracking-wide text-foreground-500">
                      <th className="px-2.5 py-2">Malzeme / Ekipman</th>
                      <th className="w-20 px-2.5 py-2">Adet</th>
                      <th className="w-48 px-2.5 py-2">Konum</th>
                      <th className="w-12 px-2.5 py-2 text-center">Sil</th>
                    </tr>
                  </thead>
                  <tbody>
                    {malzemeler.map((m) => (
                      <tr key={m.id} className="border-t border-background-300/30 dark:border-background-400/20">
                        <td className="px-2.5 py-1.5">
                          <RwInput size="sm" value={m.ad} onChange={(e) => onMalzemeGuncelle(m.id, { ad: e.target.value })} placeholder="Malzeme adı" />
                        </td>
                        <td className="px-2.5 py-1.5">
                          <RwInput size="sm" type="number" min={0} value={String(m.adet)} onChange={(e) => onMalzemeGuncelle(m.id, { adet: parseInt(e.target.value, 10) || 0 })} />
                        </td>
                        <td className="px-2.5 py-1.5">
                          <RwInput size="sm" value={m.konum} onChange={(e) => onMalzemeGuncelle(m.id, { konum: e.target.value })} placeholder="Örn. Giriş holü" />
                        </td>
                        <td className="px-2.5 py-1.5 text-center">
                          <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={() => onMalzemeSil(m.id)} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {sekme === 'tatbikat' && (
            <>
              <div className="flex flex-wrap items-center gap-2">
                <RwButton variant="secondary" size="sm" icon="ri-add-line" onClick={onTatbikatEkle}>Tatbikat Ekle</RwButton>
                <span className="text-[11px] text-foreground-500">Yönetmelik m.12 — acil durum tatbikatları yılda en az bir kez yapılır.</span>
              </div>
              {tatbikatlar.length === 0 && (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-background-300/70 bg-background-100/60 px-4 py-12 text-center dark:border-background-400/40 dark:bg-background-200/30">
                  <span className="flex h-12 w-12 items-center justify-center rounded-lg bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                    <i className="ri-calendar-check-line text-2xl" />
                  </span>
                  <p className="mt-2 text-sm font-medium text-foreground-700">Henüz tatbikat planlanmamış</p>
                  <p className="mt-1 text-xs text-foreground-500">Yıllık tatbikat planını buradan oluşturun.</p>
                </div>
              )}
              {tatbikatlar.map((t, i) => (
                <div key={t.id} className="rounded-lg border border-background-300/60 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-md bg-accent-500/15 text-accent-600 dark:text-accent-300"><i className="ri-calendar-check-line text-xs" /></span>
                    <span className="text-xs font-semibold text-foreground-400">Tatbikat #{i + 1}</span>
                    <span className="ml-auto"><RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={() => onTatbikatSil(t.id)} /></span>
                  </div>
                  <div className="mt-2.5 grid grid-cols-1 gap-2.5 md:grid-cols-2">
                    <RwSelect label="Tatbikat Konusu" size="sm" options={TATBIKAT_KONULARI.map((k) => ({ value: k, label: k }))} value={t.konu} onChange={(v) => onTatbikatGuncelle(t.id, { konu: v })} creatable />
                    <RwInput
                      label="Planlanan Tarih" size="sm" type="date"
                      value={t.tarih}
                      onChange={(e) => onTatbikatGuncelle(t.id, { tarih: e.target.value })}
                    />
                    <RwInput label="Sorumlu" size="sm" value={t.sorumlu} onChange={(e) => onTatbikatGuncelle(t.id, { sorumlu: e.target.value })} placeholder="Örn. Acil Durum Koordinatörü" />
                    <RwInput label="Katılımcı / Kapsam" size="sm" value={t.katilimci} onChange={(e) => onTatbikatGuncelle(t.id, { katilimci: e.target.value })} placeholder="Örn. Tüm çalışanlar" />
                    <div className="md:col-span-2">
                      <RwTextarea label="Açıklama / Senaryo" maxLength={400} value={t.aciklama} onChange={(e) => onTatbikatGuncelle(t.id, { aciklama: e.target.value })} placeholder="Tatbikat senaryosu ve hedefleri" />
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        {/* SAĞ — AI + Şablonlar (yalnızca senaryolar sekmesinde) */}
        {sekme === 'senaryolar' && (
          <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
            <RwCard className="p-0">
              <div className="flex items-center justify-between gap-2 border-b border-background-300/40 px-3 py-2.5 dark:border-background-400/25">
                <div className="flex items-center gap-1.5">
                  <span className="flex h-6 w-6 items-center justify-center rounded-md bg-primary-500 text-inverse"><i className="ri-sparkling-2-line text-xs" /></span>
                  <h3 className="text-xs font-semibold text-foreground-950">AI Asistan — Senaryo Önerileri</h3>
                </div>
                <button type="button" disabled={aiYukleniyor} onClick={onAiYenile} className="cursor-pointer text-xs font-medium text-primary-600 hover:underline disabled:opacity-50 dark:text-primary-300">
                  {aiYukleniyor ? 'Üretiliyor...' : 'Yenile'}
                </button>
              </div>
              <div className="max-h-[380px] overflow-y-auto p-2.5">
                {aiYukleniyor && (
                  <div className="flex items-center justify-center gap-2 py-8 text-xs text-foreground-500">
                    <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" /> Öneriler üretiliyor...
                  </div>
                )}
                {!aiYukleniyor && aiOnerileri.length === 0 && (
                  <p className="px-1 py-6 text-center text-xs text-foreground-400">
                    İşyerinize uygun acil durum senaryoları için "AI ile Öneri Al" butonuna basın.
                  </p>
                )}
                <div className="space-y-2">
                  {aiOnerileri.map((o) => {
                    const dm = dereceMeta(o.derece);
                    return (
                      <div key={o.id} className="rounded-md border border-background-300/50 bg-background-50 p-2.5 dark:border-background-400/25 dark:bg-background-100/50">
                        <div className="flex items-center justify-between gap-2">
                          <span className="flex items-center gap-1.5 text-[11px] font-semibold text-primary-600 dark:text-primary-300">
                            <i className={senaryoIkon(o.kategori)} /> {o.kategori}
                          </span>
                          <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold ${dm.soft}`}>{o.derece}</span>
                        </div>
                        <p className="mt-1 text-xs font-medium text-foreground-900">{o.olay}</p>
                        {o.aciklama && <p className="mt-0.5 text-[11px] leading-snug text-foreground-500">{o.aciklama}</p>}
                        <div className="mt-1.5 flex items-center justify-between">
                          <span className="text-[10px] text-foreground-400">
                            <i className="ri-team-line mr-0.5" /> {o.sorumluEkip || '—'}
                          </span>
                          <button type="button" onClick={() => onOneriEkle(o)} className="cursor-pointer rounded-md bg-primary-500 px-2 py-1 text-[10px] font-semibold text-inverse transition-colors hover:bg-primary-600">
                            <i className="ri-add-line mr-0.5" /> Listeye Ekle
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="border-t border-background-300/40 p-2.5 dark:border-background-400/25">
                <p className="mb-1.5 text-[10px] font-semibold uppercase tracking-wide text-foreground-400">Örnek Sorular</p>
                <ul className="space-y-1">
                  {ORNEK_SORULAR.map((s) => (
                    <li key={s} className="flex items-start gap-1.5 text-[11px] text-foreground-600">
                      <i className="ri-question-line mt-0.5 text-primary-400" /> {s}
                    </li>
                  ))}
                </ul>
              </div>
            </RwCard>

            <RwCard className="p-0">
              <div className="flex items-center gap-1.5 border-b border-background-300/40 px-3 py-2.5 dark:border-background-400/25">
                <i className="ri-bookmark-3-line text-sm text-primary-500" />
                <h3 className="text-xs font-semibold text-foreground-950">Senaryo Şablon Kütüphanesi</h3>
              </div>
              <div className="border-b border-background-300/40 p-2.5 dark:border-background-400/25">
                <RwInput size="sm" placeholder="Şablon ara..." value={sablonArama} onChange={(e) => setSablonArama(e.target.value)} leftIcon={<i className="ri-search-line text-xs" />} />
              </div>
              <div className="max-h-[340px] overflow-y-auto p-2">
                {sablonlar.length === 0 && <p className="px-1 py-4 text-center text-xs text-foreground-400">Sonuç yok</p>}
                <div className="space-y-1.5">
                  {sablonlar.map((s, i) => (
                    <div key={`${s.olay}-${i}`} className="flex items-start justify-between gap-2 rounded-md border border-transparent p-2 hover:border-primary-300/50 hover:bg-background-50 dark:hover:bg-background-100/40">
                      <div className="min-w-0">
                        <p className="text-[11px] font-medium text-foreground-800">{s.olay}</p>
                        <p className="mt-0.5 flex items-center gap-1.5 text-[10px] text-foreground-400">
                          <i className={senaryoIkon(s.kategori)} /> {s.kategori}
                        </p>
                      </div>
                      <button type="button" onClick={() => onSablondanEkle(s)} className="flex flex-shrink-0 cursor-pointer items-center gap-1 rounded-md border border-primary-300/60 px-2 py-1 text-[10px] font-semibold text-primary-600 transition-colors hover:bg-primary-500 hover:text-inverse dark:text-primary-300">
                        <i className="ri-add-line" /> Ekle
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </RwCard>
          </div>
        )}
      </div>
    </div>
  );
}