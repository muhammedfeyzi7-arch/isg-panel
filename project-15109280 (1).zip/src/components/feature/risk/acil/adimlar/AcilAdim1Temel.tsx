import { useRef, useState } from 'react';
import { ACIL_METODU, KAPSAM_MADDELERI, ZORUNLU_EKIPLER, destekElemaniHesabi, type AcilTemelBilgiler } from '@/components/feature/risk/acilDurumTypes';
import { GECERLILIK_SECENEKLERI, TEHLIKE_SINIFLARI, tehlikeGecerlilikPatch } from '@/components/feature/risk/riskSihirbazTypes';
import { RwButton, RwChip, RwInput, RwSelect, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';
import RiskNaceSecici from '@/components/feature/risk/RiskNaceSecici';
import { naceProfilCoz } from '@/lib/acilDurumRapor/naceProfilleri';

// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM EYLEM PLANI · ADIM 1 — TEMEL BİLGİLER VE KAPSAM
// Sol: iki kolonlu form → Plan Kapsamı (işaretlenebilir) → Plan Ekibi → Referans
// Dokümanlar → Rapor künyesi + acil duruma özel alanlar (toplanma noktası, ihbar).
// Sağ: "Acil Durum Eylem Planı Hakkında" + Mevzuat + Plan Hedefleri + Yardımcı Mod.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: AcilTemelBilgiler;
  kapsam: string[];
  onChange: (patch: Partial<AcilTemelBilgiler>) => void;
  onKapsamChange: (kapsam: string[]) => void;
  onNaceProfilUygula?: () => void;
}

const PLAN_HEDEFLERI = [
  'Acil durumların olumsuz etkilerinden çalışanları korumak',
  'Acil durum ekiplerinin oluşturulması ve görev tanımları',
  'Tahliye yolları ve toplanma noktasının belirlenmesi',
  'Yangın, deprem, kimyasal gibi senaryolara hazırlık',
  'Acil durum ihbar ve iletişim sisteminin kurulması',
  'Periyodik tatbikatlarla hazırlık seviyesini ölçmek',
  'İlk yardım ve kurtarma kapasitesini güçlendirmek',
];

export default function AcilAdim1Temel({ temel, kapsam, onChange, onKapsamChange, onNaceProfilUygula }: Props) {
  const [ekipGirdi, setEkipGirdi] = useState('');
  const [ozelKapsam, setOzelKapsam] = useState('');
  const dosyaRef = useRef<HTMLInputElement>(null);

  const yillar = Array.from({ length: 5 }, (_, i) => String(new Date().getFullYear() - 1 + i));
  const destek = destekElemaniHesabi(temel.tehlikeSinifi, temel.calisanSayisi);
  const naceProfil = naceProfilCoz(temel.nace || '').bolum;

  const ekipEkle = () => {
    const ad = ekipGirdi.trim();
    if (!ad) return;
    if (!temel.ekip.includes(ad)) onChange({ ekip: [...temel.ekip, ad] });
    setEkipGirdi('');
  };

  const dosyaSec = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const adlar = Array.from(files).map((f) => f.name);
    onChange({ dokumanlar: Array.from(new Set([...temel.dokumanlar, ...adlar])) });
  };

  const kapsamToggle = (k: string) => {
    onKapsamChange(kapsam.includes(k) ? kapsam.filter((x) => x !== k) : [...kapsam, k]);
  };
  const tumunuSec = () => onKapsamChange(kapsam.length === KAPSAM_MADDELERI.length ? [] : [...KAPSAM_MADDELERI]);
  const ozelEkle = () => {
    const v = ozelKapsam.trim();
    if (v && !kapsam.includes(v)) onKapsamChange([...kapsam, v]);
    setOzelKapsam('');
  };

  return (
    <div className="isg-scroll-pane min-h-0 flex-1 overflow-y-auto overflow-x-hidden pr-1">
      <div className="pb-3">
        <h2 className="text-sm font-bold text-foreground-950">1. Temel Bilgiler ve Kapsam</h2>
        <p className="mt-1 text-xs text-foreground-500">
          Acil durum eylem planına ait temel bilgileri tanımlayın ve planın kapsamını belirleyin.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
        {/* SOL */}
        <div>
          <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-2">
            <RwInput
              label="Plan Adı" required
              value={temel.calismaAdi}
              onChange={(e) => onChange({ calismaAdi: e.target.value })}
              placeholder="Örn. Acil Durum Eylem Planı"
            />
            <RwSelect
              label="Plan Yılı" required
              options={yillar.map((y) => ({ value: y, label: y }))}
              value={temel.planYili} onChange={(v) => onChange({ planYili: v })}
              placeholder={String(new Date().getFullYear())}
            />

            <RwInput label="Firma" value={temel.firma} onChange={(e) => onChange({ firma: e.target.value })} placeholder="Firma ünvanı" />
            <RwInput
              label="Tesis / İş Yeri" required
              value={temel.tesis} onChange={(e) => onChange({ tesis: e.target.value })}
              placeholder="Örn. Merkez Üretim Tesisi"
            />

            <RwInput
              label="Düzenleme Tarihi" required type="date"
              value={temel.tarih}
              onChange={(e) => onChange({ tarih: e.target.value })}
            />
            <RwSelect
              label="Geçerlilik Süresi"
              options={GECERLILIK_SECENEKLERI.map((v) => ({ value: v, label: v }))}
              value={temel.gecerlilik} onChange={(v) => onChange({ gecerlilik: v })}
            />

            <RwInput
              label="Toplanma (Buluşma) Noktası"
              value={temel.toplanmaYeri}
              onChange={(e) => onChange({ toplanmaYeri: e.target.value })}
              placeholder="Örn. Ana bina önü otopark alanı"
            />
            <RwInput
              label="Acil İhbar / Çağrı"
              value={temel.acilIhbar}
              onChange={(e) => onChange({ acilIhbar: e.target.value })}
              placeholder="Örn. 112 (Acil Çağrı Merkezi)"
            />

            <div className="md:col-span-2">
              <RwTextarea
                label="Planın Amacı / Açıklama" maxLength={1000}
                value={temel.amac} onChange={(e) => onChange({ amac: e.target.value })}
                placeholder="Acil durum eylem planının amacı ve genel çerçevesine ilişkin açıklama girin..."
              />
            </div>
          </div>

          {/* Plan Kapsamı */}
          <div className="mt-5">
            <div className="flex items-center justify-between">
              <span className="block text-xs font-medium text-foreground-800">Plan Kapsamı</span>
              <button type="button" onClick={tumunuSec} className="cursor-pointer text-xs font-medium text-primary-600 hover:underline dark:text-primary-300">
                {kapsam.length === KAPSAM_MADDELERI.length ? 'Tümünü Temizle' : 'Tümünü Seç'}
              </button>
            </div>
            <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2">
              {KAPSAM_MADDELERI.map((k) => {
                const secili = kapsam.includes(k);
                return (
                  <button
                    key={k}
                    type="button"
                    onClick={() => kapsamToggle(k)}
                    className={`flex cursor-pointer items-start gap-2 rounded-md border p-2.5 text-left transition-colors ${
                      secili
                        ? 'border-primary-500/60 bg-primary-500/10'
                        : 'border-background-300/60 bg-background-100 hover:border-primary-300 dark:border-background-400/30 dark:bg-background-200/40'
                    }`}
                  >
                    <span className={`mt-0.5 flex h-4 w-4 flex-shrink-0 items-center justify-center rounded border ${secili ? 'border-primary-500 bg-primary-500 text-inverse' : 'border-foreground-300 dark:border-background-400'}`}>
                      {secili && <i className="ri-check-line text-[10px]" />}
                    </span>
                    <span className="text-xs leading-snug text-foreground-700">{k}</span>
                  </button>
                );
              })}
            </div>
            {kapsam.filter((k) => !KAPSAM_MADDELERI.includes(k)).length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {kapsam.filter((k) => !KAPSAM_MADDELERI.includes(k)).map((k) => (
                  <RwChip key={k} onRemove={() => onKapsamChange(kapsam.filter((x) => x !== k))}>{k}</RwChip>
                ))}
              </div>
            )}
            <div className="mt-2 flex items-center gap-1.5">
              <input
                value={ozelKapsam}
                onChange={(e) => setOzelKapsam(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); ozelEkle(); } }}
                placeholder="Özel kapsam maddesi ekleyin"
                className="h-8 w-full max-w-xs rounded-md border border-background-300/70 bg-background-50 px-2.5 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
              />
              <RwButton size="sm" variant="outline" icon="ri-add-line" onClick={ozelEkle}>Ekle</RwButton>
            </div>
          </div>

          {/* Özel Durum Tahliye Notu */}
          <div className="mt-5">
            <RwTextarea
              label="Engelli / Özel Durumlu Çalışanlar İçin Tahliye Önlemleri"
              maxLength={500}
              value={temel.ozelDurumNotu || ''}
              onChange={(e) => onChange({ ozelDurumNotu: e.target.value })}
              placeholder="Örn. Zemin katta çalışan 2 engelli personel için tahliye refakatçisi görevlendirilmiştir..."
            />
          </div>

          {/* Plan Ekibi */}
          <div className="mt-5">
            <span className="mb-1.5 block text-xs font-medium text-foreground-800">Acil Durum Planlama Ekibi</span>
            <div className="flex flex-wrap items-center gap-2 rounded-md border border-background-300/60 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
              {temel.ekip.map((ad) => (
                <RwChip key={ad} onRemove={() => onChange({ ekip: temel.ekip.filter((x) => x !== ad) })}>{ad}</RwChip>
              ))}
              <div className="flex items-center gap-1.5">
                <input
                  value={ekipGirdi}
                  onChange={(e) => setEkipGirdi(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); ekipEkle(); } }}
                  placeholder="İsim / unvan yazın"
                  className="h-8 w-44 rounded-md border border-background-300/70 bg-background-50 px-2.5 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
                />
                <RwButton size="sm" variant="outline" icon="ri-add-line" onClick={ekipEkle}>Ekle</RwButton>
              </div>
            </div>
          </div>

          {/* Referans Dokümanlar */}
          <div className="mt-5">
            <span className="block text-xs font-medium text-foreground-800">Referans Dokümanlar (Opsiyonel)</span>
            <div
              onClick={() => dosyaRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => { e.preventDefault(); dosyaSec(e.dataTransfer.files); }}
              className="mt-2 flex cursor-pointer flex-col items-center justify-center gap-1.5 rounded-md border border-dashed border-background-300/70 bg-background-100/60 px-4 py-6 text-center transition-colors hover:border-primary-400 dark:border-background-400/40 dark:bg-background-200/30"
            >
              <span className="flex h-10 w-10 items-center justify-center rounded-md bg-background-200/70 text-foreground-400 dark:bg-background-300/40">
                <i className="ri-upload-cloud-2-line text-xl" />
              </span>
              <p className="text-xs text-foreground-600">Dosya seçin veya sürükleyip bırakın</p>
              <p className="text-xs text-foreground-400">PDF, DOC, DOCX, XLS, XLSX, JPG, PNG (Maks. 10 MB)</p>
            </div>
            {temel.dokumanlar.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {temel.dokumanlar.map((d) => (
                  <RwChip key={d} onRemove={() => onChange({ dokumanlar: temel.dokumanlar.filter((x) => x !== d) })}>
                    <i className="ri-file-line text-foreground-400" /> {d}
                  </RwChip>
                ))}
              </div>
            )}
            <input ref={dosyaRef} type="file" multiple accept=".pdf,.doc,.docx,.xls,.xlsx,.jpg,.jpeg,.png" className="hidden" onChange={(e) => { dosyaSec(e.target.files); e.target.value = ''; }} />
          </div>

          {/* Künye */}
          <div className="mt-5 pb-7">
            <span className="mb-1.5 block text-xs font-medium text-foreground-800">Rapor Künye Bilgileri (Opsiyonel)</span>
            <div className="grid grid-cols-1 gap-x-6 gap-y-4 md:grid-cols-3">
              <RwInput label="Rapor No" value={temel.raporNo} onChange={(e) => onChange({ raporNo: e.target.value })} placeholder="Örn. ADEP-2026-001" />
              <RwSelect label="Tehlike Sınıfı" options={TEHLIKE_SINIFLARI.map((v) => ({ value: v, label: v }))} value={temel.tehlikeSinifi} onChange={(v) => onChange(tehlikeGecerlilikPatch(v))} placeholder="Seçiniz" />
              <RwInput label="Çalışan Sayısı" value={temel.calisanSayisi} onChange={(e) => onChange({ calisanSayisi: e.target.value })} placeholder="Örn. 120" />
              <RwInput label="İşveren" value={temel.isveren} onChange={(e) => onChange({ isveren: e.target.value })} placeholder="İşveren adı / ünvanı" />
              <RiskNaceSecici
                naceId={temel.naceId}
                onChange={(s) => onChange({ naceId: s.naceId, nace: s.nace, ...(s.tehlikeSinifi ? tehlikeGecerlilikPatch(s.tehlikeSinifi) : {}) })}
              />
              <RwInput label="Hazırlayan" value={temel.hazirlayan} onChange={(e) => onChange({ hazirlayan: e.target.value })} placeholder="İş güvenliği uzmanı" />
              <RwInput label="Onaylayan" value={temel.onaylayan} onChange={(e) => onChange({ onaylayan: e.target.value })} placeholder="İşveren / vekili" />
              <RwInput label="Adres / Lokasyon" value={temel.adres} onChange={(e) => onChange({ adres: e.target.value })} placeholder="Açık adres" />
            </div>
          </div>
        </div>

        {/* SAĞ */}
        <aside className="space-y-3">
          {naceProfil ? (
            <div className="rounded-lg border border-primary-400/50 bg-primary-50 p-3 dark:border-primary-500/30 dark:bg-primary-500/10">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-flashlight-line text-xs" /></span>
                <h3 className="text-xs font-bold text-foreground-950">NACE Profili: {naceProfil.kod} — {naceProfil.ad}</h3>
              </div>
              <p className="mt-1.5 text-[11px] leading-relaxed text-foreground-600">
                Seçilen faaliyet bölümüne göre senaryolar, müdahale adımları, kapsam, mevzuat ve malzeme listesi otomatik hazırlanabilir.
              </p>
              <div className="mt-2 grid grid-cols-3 gap-1.5 text-center">
                <div className="rounded-md border border-background-300/50 bg-background-50 px-1 py-1.5 dark:border-background-400/25 dark:bg-background-100/50">
                  <span className="block text-sm font-bold text-foreground-950">{naceProfil.senaryolar.length}</span>
                  <span className="block text-[10px] text-foreground-500">Senaryo</span>
                </div>
                <div className="rounded-md border border-background-300/50 bg-background-50 px-1 py-1.5 dark:border-background-400/25 dark:bg-background-100/50">
                  <span className="block text-sm font-bold text-foreground-950">{naceProfil.kapsamEkleri.length}</span>
                  <span className="block text-[10px] text-foreground-500">Kapsam</span>
                </div>
                <div className="rounded-md border border-background-300/50 bg-background-50 px-1 py-1.5 dark:border-background-400/25 dark:bg-background-100/50">
                  <span className="block text-sm font-bold text-foreground-950">{naceProfil.malzemeler.length}</span>
                  <span className="block text-[10px] text-foreground-500">Malzeme</span>
                </div>
              </div>
              {onNaceProfilUygula && (
                <RwButton variant="primary" size="sm" block className="mt-2.5" icon="ri-magic-line" onClick={onNaceProfilUygula}>
                  NACE Profilini Uygula
                </RwButton>
              )}
              <p className="mt-1.5 text-[10px] leading-snug text-foreground-400">Eklenen içerik mevcut kayıtlarınızı korur; tekrar eden maddeler eklenmez.</p>
            </div>
          ) : (
            <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
              <h3 className="flex items-center gap-1.5 text-xs font-bold text-foreground-950"><i className="ri-flashlight-line text-primary-500" /> NACE Kodu ile İçerik</h3>
              <p className="mt-1.5 text-[11px] leading-relaxed text-foreground-600">
                Künye bölümünden NACE kodu seçtiğinizde, faaliyetinize özgü senaryolar, müdahale adımları, kapsam ve malzeme listesi otomatik olarak hazırlanır.
              </p>
            </div>
          )}

          <div className={`rounded-lg border p-3 ${destek.gecerli ? 'border-success-500/40 bg-success-500/5' : 'border-warning-500/40 bg-warning-500/5'}`}>
            <div className="flex items-center gap-2">
              <span className={`flex h-6 w-6 items-center justify-center rounded-full text-inverse ${destek.gecerli ? 'bg-success-500' : 'bg-warning-500'}`}>
                <i className="ri-team-line text-xs" />
              </span>
              <h3 className="text-xs font-bold text-foreground-950">Zorunlu Destek Elemanı (m.11)</h3>
            </div>
            <p className="mt-1.5 text-[11px] leading-relaxed text-foreground-600">{destek.ozet}</p>
            {destek.gecerli ? (
              <div className="mt-2 space-y-1.5">
                {destek.satirlar.map((s) => (
                  <div key={s.konu} className="flex items-center justify-between gap-2 rounded-md border border-background-300/50 bg-background-50 px-2.5 py-1.5 dark:border-background-400/25 dark:bg-background-100/50">
                    <span className="min-w-0">
                      <span className="block truncate text-[11px] font-medium text-foreground-800">{s.konu}</span>
                      <span className="block text-[10px] text-foreground-400">{s.oran}</span>
                    </span>
                    <span className="flex h-7 min-w-7 flex-shrink-0 items-center justify-center rounded-md bg-primary-500 px-1.5 text-xs font-bold text-inverse">{s.gerekli}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="mt-2 rounded-md border border-dashed border-background-300/60 px-2.5 py-2.5 text-center text-[11px] text-foreground-400 dark:border-background-400/30">
                Hesap için “Tehlike Sınıfı” ve “Çalışan Sayısı” alanlarını doldurun.
              </div>
            )}
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 flex items-center gap-1.5 text-xs font-bold text-foreground-950"><i className="ri-shield-check-line text-primary-500" /> Zorunlu Acil Durum Ekipleri (m.8)</h3>
            <ul className="space-y-1.5">
              {ZORUNLU_EKIPLER.map((e) => (
                <li key={e} className="flex items-start gap-2">
                  <i className="ri-checkbox-circle-line mt-0.5 flex-shrink-0 text-xs text-success-500" />
                  <span className="text-[11px] leading-snug text-foreground-600">{e}</span>
                </li>
              ))}
            </ul>
            <p className="mt-2 text-[10px] leading-snug text-foreground-400">Tehlike sınıfı ve çalışan sayısına bakılmaksızın bu ekipler kurulmak zorundadır.</p>
          </div>

          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary-500 text-inverse"><i className="ri-information-fill text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Acil Durum Eylem Planı Hakkında</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              6331 sayılı Kanun (m.11) uyarınca işveren; acil durumların olumsuz etkilerinden korunmak için
              önleyici tedbirleri almak ve acil durum planını hazırlamak zorundadır.
            </p>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              Plan; acil durum ekiplerini, senaryoları, tahliye yollarını ve toplanma noktasını kapsar.
            </p>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Yasal Dayanaklar</h3>
            <ul className="space-y-1.5">
              {[
                '6331 s. Kanun — m.11 (acil durum planları)',
                '6331 s. Kanun — m.12 (tatbikatlar)',
                'İşyerlerinde Acil Durumlar Hakkında Yönetmelik',
                'Binaların Yangından Korunması Yönetmeliği',
                'Sağlık ve Güvenlik İşaretleri Yönetmeliği',
                'İlk Yardım Yönetmeliği',
              ].map((m) => (
                <li key={m} className="flex items-start gap-2">
                  <i className="ri-scales-3-line mt-0.5 text-xs text-primary-500" />
                  <span className="text-[11px] leading-snug text-foreground-600">{m}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <h3 className="mb-2 text-xs font-bold text-foreground-950">Planın Hedefleri</h3>
            <ul className="space-y-1.5">
              {PLAN_HEDEFLERI.map((h) => (
                <li key={h} className="flex items-start gap-2">
                  <i className="ri-check-line mt-0.5 text-xs text-primary-500" />
                  <span className="text-xs leading-snug text-foreground-600">{h}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-lg border border-warning-500/30 bg-warning-500/5 p-3">
            <div className="flex items-center gap-2">
              <span className="flex h-6 w-6 items-center justify-center rounded-full bg-warning-500 text-inverse"><i className="ri-lightbulb-line text-xs" /></span>
              <h3 className="text-xs font-bold text-foreground-950">Yardımcı Mod</h3>
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-foreground-600">
              Bu çalışma geçici olarak tutulur; kalıcı kayıt OLUŞTURULMAZ. Yalnızca Word / PDF / Excel indirilir.
            </p>
          </div>

          <div className="rounded-lg border border-background-300/50 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-foreground-950"><i className="ri-hashtag text-primary-500" /> Yöntem</p>
            <p className="mt-1 text-xs leading-relaxed text-foreground-600">{ACIL_METODU}</p>
          </div>
        </aside>
      </div>
    </div>
  );
}