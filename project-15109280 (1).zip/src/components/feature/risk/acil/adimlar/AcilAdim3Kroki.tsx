import KrokiTuvali from '@/components/feature/risk/acil/KrokiTuvali';
import { dereceMeta, senaryoIkon, type AcilSenaryo, type AcilTemelBilgiler } from '@/components/feature/risk/acilDurumTypes';
import { RwCard, RwInput, RwSectionTitle, RwTextarea } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM EYLEM PLANI · ADIM 3 — TAHLİYE KROKİSİ
// Tahliye/toplanma bilgileri + kroki çizim tuvali + kroki notu. Sağda tahliye
// gerektiren senaryoların özeti. Kroki çizimi rapora (PDF/Word/Excel) gömülür.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: AcilTemelBilgiler;
  senaryolar: AcilSenaryo[];
  kroki: string;
  krokiVeri: string;
  krokiNot: string;
  onTemelChange: (patch: Partial<AcilTemelBilgiler>) => void;
  onKrokiChange: (dataUrl: string, veri: string) => void;
  onKrokiNotChange: (v: string) => void;
}

export default function AcilAdim3Kroki({ temel, senaryolar, kroki, krokiVeri, krokiNot, onTemelChange, onKrokiChange, onKrokiNotChange }: Props) {
  const tahliyeSenaryolar = senaryolar.filter((s) => s.tahliyeGerekli);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="3. Tahliye ve Kroki"
        desc="İşyerinizin tahliye planını (kroki) çizin, toplanma noktasını ve tahliye bilgilerini tanımlayın."
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_320px]">
        {/* SOL — Tuval */}
        <div className="flex min-h-0 flex-col rounded-lg border border-background-300/60 bg-background-100 p-3 dark:border-background-400/30 dark:bg-background-200/40">
          <KrokiTuvali veri={krokiVeri} onChange={onKrokiChange} />
        </div>

        {/* SAĞ */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <RwCard title="Tahliye Bilgileri" icon="ri-route-line" className="p-3">
            <div className="space-y-2.5">
              <RwInput
                label="Toplanma (Buluşma) Noktası"
                value={temel.toplanmaYeri}
                onChange={(e) => onTemelChange({ toplanmaYeri: e.target.value })}
                placeholder="Örn. Ana bina önü otopark alanı"
              />
              <RwInput
                label="Acil İhbar / Çağrı"
                value={temel.acilIhbar}
                onChange={(e) => onTemelChange({ acilIhbar: e.target.value })}
                placeholder="Örn. 112 (Acil Çağrı Merkezi)"
              />
              <RwTextarea
                label="Kroki Açıklama Notu" maxLength={500}
                value={krokiNot}
                onChange={(e) => onKrokiNotChange(e.target.value)}
                placeholder="Krokiye ilişkin kısa açıklama / not (rapora eklenir)"
              />
            </div>
          </RwCard>

          <RwCard title="Tahliye Gerektiren Senaryolar" icon="ri-door-open-line" className="p-3">
            {tahliyeSenaryolar.length === 0 ? (
              <p className="py-3 text-center text-xs text-foreground-400">
                Tahliye gerektiren senaryo yok. "Senaryolar" adımından ekleyebilirsiniz.
              </p>
            ) : (
              <ul className="space-y-2">
                {tahliyeSenaryolar.map((s) => {
                  const dm = dereceMeta(s.derece);
                  return (
                    <li key={s.id} className="flex items-start gap-2 rounded-md border border-background-300/50 bg-background-50 p-2 dark:border-background-400/25 dark:bg-background-100/50">
                      <i className={`${senaryoIkon(s.kategori)} mt-0.5 text-sm text-primary-500`} />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-xs font-medium text-foreground-800">{s.olay || 'İsimsiz senaryo'}</p>
                        <p className="truncate text-[10px] text-foreground-400">{s.sorumluEkip || '—'}</p>
                      </div>
                      <span className={`inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold ${dm.soft}`}>{s.derece}</span>
                    </li>
                  );
                })}
              </ul>
            )}
          </RwCard>

          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-foreground-950"><i className="ri-information-line text-primary-500" /> Kroki Nasıl Çizilir?</p>
            <ul className="mt-1.5 space-y-1">
              {[
                '"Duvar" aracıyla bina/bölümleri sürükleyerek çizin (yatay/dikey otomatik).',
                '"Kapı" ve "Pencere" araçlarıyla açıklıkları çizin.',
                '"Acil Çıkış", "Söndürücü" ve "İlk Yardım" sembollerini yerleştirin.',
                '"Toplanma" aracıyla buluşma noktasını belirtin.',
                '"Metin" ile bölüm adlarını yazın; "Seç & Taşı" ile taşıyın, "Sil" ile kaldırın.',
                'Hazır "Ofis / Atölye / Depo" şablonlarıyla hızlı başlayın; lejant otomatik eklenir.',
              ].map((t) => (
                <li key={t} className="flex items-start gap-1.5 text-[11px] leading-snug text-foreground-600">
                  <i className="ri-check-line mt-0.5 text-primary-500" /> {t}
                </li>
              ))}
            </ul>
          </div>

          {kroki && (
            <p className="flex items-center gap-1.5 text-[11px] text-success-600">
              <i className="ri-checkbox-circle-line" /> Kroki çizildi; rapora otomatik eklenecek.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}