import { useEffect, useMemo, useState } from 'react';
import Icon from '@/components/ui/Icon';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import {
  EKIP_ROLLERI, dereceMeta, rolIkon, rolMeta, senaryoIkon, yeniId,
  type AcilIletisim, type AcilMalzeme, type AcilSenaryo, type AcilTemelBilgiler, type EkipUyesi, type Imzaci, type Tatbikat,
} from '@/components/feature/risk/acilDurumTypes';
import { mevzuatListesi, acilSayim } from '@/lib/acilDurumRapor/model';
import { pdfBlob, pdfIndir, wordIndir, excelIndir, csvIndir, txtIndir } from '@/lib/acilDurumRapor';
import { RwButton, RwCard, RwIconButton, RwInput, RwSectionTitle } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM EYLEM PLANI · ADIM 4 — RAPOR VE ÖNİZLEME
// Özet kartları + rol/kategori dağılımı + senaryo matrisi + kroki önizleme +
// imza alanları + mevzuat + gerçek PDF önizleme ve Word / PDF / Excel / CSV / TXT.
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  temel: AcilTemelBilgiler;
  kapsam: string[];
  ekipler: EkipUyesi[];
  senaryolar: AcilSenaryo[];
  iletisim: AcilIletisim[];
  malzemeler: AcilMalzeme[];
  tatbikatlar: Tatbikat[];
  kroki: string;
  krokiNot: string;
  onTemelChange: (patch: Partial<AcilTemelBilgiler>) => void;
}

const ROL_RENK = [
  'oklch(var(--primary-500))', 'oklch(var(--secondary-500))', 'oklch(var(--accent-500))',
  'oklch(var(--primary-700))', 'oklch(var(--secondary-700))', 'oklch(var(--accent-700))',
  'oklch(var(--primary-300))',
];

function PdfOnizleme({ blob }: { blob: Blob }) {
  const [url, setUrl] = useState('');
  useEffect(() => {
    const u = URL.createObjectURL(blob);
    setUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [blob]);
  if (!url) {
    return (
      <div className="flex h-full w-full items-center justify-center bg-background-200">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }
  return (
    <div className="h-full w-full bg-background-200">
      <iframe src={url} title="Acil Durum Eylem Planı Önizleme" className="h-full w-full border-0" />
    </div>
  );
}

function tarihGoster(iso: string): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return `${String(d.getDate()).padStart(2, '0')}.${String(d.getMonth() + 1).padStart(2, '0')}.${d.getFullYear()}`;
}

export default function AcilAdim4Rapor({ temel, kapsam, ekipler, senaryolar, iletisim, malzemeler, tatbikatlar, kroki, krokiNot, onTemelChange }: Props) {
  const { addToast } = useToastActions();
  const { openModal } = useModalActions();
  const [indiriliyor, setIndiriliyor] = useState<'word' | 'pdf' | 'excel' | 'csv' | 'txt' | null>(null);
  const [indirAcik, setIndirAcik] = useState(false);
  const [onizleYukleniyor, setOnizleYukleniyor] = useState(false);

  const imzacilar = temel.imzacilar ?? [];
  const [yeniAd, setYeniAd] = useState('');
  const [yeniGorev, setYeniGorev] = useState('');
  const [yeniBelge, setYeniBelge] = useState('');
  const [duzenlenen, setDuzenlenen] = useState<string | null>(null);

  const s = useMemo(() => acilSayim({ temel, kapsam, ekipler, senaryolar, iletisim, malzemeler, tatbikatlar }), [temel, kapsam, ekipler, senaryolar, iletisim, malzemeler, tatbikatlar]);

  const rolDagilim = useMemo(() => {
    const m = new Map<string, number>();
    ekipler.forEach((e) => m.set(e.ekipRolu || '—', (m.get(e.ekipRolu || '—') ?? 0) + 1));
    return Array.from(m.entries()).map(([rol, adet]) => ({ rol, adet })).sort((a, b) => b.adet - a.adet);
  }, [ekipler]);

  const kategoriDagilim = useMemo(() => {
    const m = new Map<string, number>();
    senaryolar.forEach((e) => m.set(e.kategori || '—', (m.get(e.kategori || '—') ?? 0) + 1));
    return Array.from(m.entries()).map(([kategori, adet]) => ({ kategori, adet })).sort((a, b) => b.adet - a.adet);
  }, [senaryolar]);

  const veri = { temel, kapsam, ekipler, senaryolar, iletisim, malzemeler, tatbikatlar, kroki, krokiNot };
  const mevzuat = useMemo(() => mevzuatListesi(veri), [temel, kapsam, ekipler, senaryolar, iletisim, malzemeler, tatbikatlar, kroki, krokiNot]);

  const donutToplam = Math.max(1, ekipler.length);
  let aci = 0;
  const donutGradient = ekipler.length === 0
    ? 'oklch(var(--background-300)) 0% 100%'
    : rolDagilim.map((k, i) => {
      const bas = (aci / donutToplam) * 100;
      aci += k.adet;
      const bit = (aci / donutToplam) * 100;
      return `${ROL_RENK[i % ROL_RENK.length]} ${bas}% ${bit}%`;
    }).join(', ');

  const indir = async (tip: 'pdf' | 'word' | 'excel' | 'csv' | 'txt') => {
    if (senaryolar.length === 0) {
      addToast({ title: 'Senaryo listesi boş', message: 'Rapor oluşturmak için en az bir acil durum senaryosu ekleyin.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndirAcik(false);
    setIndiriliyor(tip);
    try {
      if (tip === 'pdf') await pdfIndir(veri);
      else if (tip === 'excel') await excelIndir(veri);
      else if (tip === 'csv') csvIndir(veri);
      else if (tip === 'txt') txtIndir(veri);
      else await wordIndir(veri);
      addToast({ title: 'Rapor hazır', message: 'Dosya indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Rapor oluşturulamadı', message: 'Beklenmeyen bir hata oluştu, lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setIndiriliyor(null);
    }
  };

  const ozetKopyala = async () => {
    setIndirAcik(false);
    try {
      const metin = [
        'ACİL DURUM EYLEM PLANI',
        `Firma: ${temel.firma || '—'}`,
        `Plan Yılı: ${temel.planYili || '—'}`,
        `Rapor No: ${temel.raporNo || '—'}`,
        `Düzenleme Tarihi: ${tarihGoster(temel.tarih)}`,
        `Toplanma Noktası: ${temel.toplanmaYeri || '—'}`,
        `Toplam Senaryo: ${senaryolar.length}`,
        `Ekip Üyesi: ${ekipler.length}`,
      ].join('\n');
      await navigator.clipboard.writeText(metin);
      addToast({ title: 'Kopyalandı', message: 'Plan özeti panoya kopyalandı.', type: 'success' });
    } catch {
      addToast({ title: 'Kopyalanamadı', message: 'Panoya erişilemedi.', type: 'error' });
    }
  };

  const imzaciKaydet = () => {
    if (!yeniAd.trim()) {
      addToast({ title: 'Eksik bilgi', message: 'İmzacı için ad soyad girin.', type: 'warning' });
      return;
    }
    const gorev = yeniGorev.trim() || 'Yetkili';
    if (duzenlenen) {
      onTemelChange({ imzacilar: imzacilar.map((x) => (x.id === duzenlenen ? { ...x, adSoyad: yeniAd.trim(), gorev, belge: yeniBelge.trim() } : x)) });
    } else {
      onTemelChange({ imzacilar: [...imzacilar, { id: yeniId('im'), adSoyad: yeniAd.trim(), gorev, belge: yeniBelge.trim() }] });
    }
    setYeniAd(''); setYeniGorev(''); setYeniBelge(''); setDuzenlenen(null);
  };

  const imzaciDuzenle = (im: Imzaci) => { setDuzenlenen(im.id); setYeniAd(im.adSoyad); setYeniGorev(im.gorev); setYeniBelge(im.belge); };
  const imzaciSil = (id: string) => {
    onTemelChange({ imzacilar: imzacilar.filter((x) => x.id !== id) });
    if (duzenlenen === id) { setDuzenlenen(null); setYeniAd(''); setYeniGorev(''); setYeniBelge(''); }
  };

  const onizle = async () => {
    if (senaryolar.length === 0) {
      addToast({ title: 'Senaryo listesi boş', message: 'Önizleme için en az bir senaryo ekleyin.', type: 'warning' });
      return;
    }
    if (onizleYukleniyor) return;
    setOnizleYukleniyor(true);
    try {
      const blob = await pdfBlob(veri);
      openModal({
        title: 'Acil Durum Eylem Planı Önizleme',
        description: temel.firma || 'Rapor önizlemesi',
        variant: 'large',
        width: 1120,
        height: 820,
        minWidth: 720,
        minHeight: 520,
        showFooter: false,
        bodyLayout: 'fill',
        closable: true,
        resizable: true,
        minimizable: true,
        maximizable: true,
        content: <PdfOnizleme blob={blob} />,
      });
    } catch {
      addToast({ title: 'Önizleme oluşturulamadı', message: 'Beklenmeyen bir hata oluştu, lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setOnizleYukleniyor(false);
    }
  };

  const kartlar = [
    { key: 'senaryo', label: 'Toplam Senaryo', adet: s.toplamSenaryo, icon: 'ri-alarm-warning-line', renk: 'bg-primary-500' },
    { key: 'ekip', label: 'Ekip Üyesi', adet: s.toplamEkip, icon: 'ri-team-line', renk: 'bg-secondary-500' },
    { key: 'yuksek', label: 'Yüksek Derece', adet: s.yuksek, icon: 'ri-error-warning-line', renk: 'bg-danger-500' },
    { key: 'tahliye', label: 'Tahliye Gerekli', adet: s.tahliyeGerekli, icon: 'ri-door-open-line', renk: 'bg-accent-500' },
    { key: 'tatbikat', label: 'Tatbikat', adet: s.tatbikatSayisi, icon: 'ri-calendar-check-line', renk: 'bg-primary-400' },
    { key: 'malzeme', label: 'Malzeme (adet)', adet: s.malzemeAdet, icon: 'ri-fire-line', renk: 'bg-success-500' },
  ];

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <RwSectionTitle
        title="4. Rapor ve Önizleme"
        desc="Planın özetini gözden geçirin, ekip ve senaryoları kontrol edin; raporu önizleyin/indirin."
        right={(
          <RwButton variant="outline" size="sm" icon={onizleYukleniyor ? undefined : 'ri-eye-line'} disabled={onizleYukleniyor} onClick={() => void onizle()}>
            {onizleYukleniyor ? 'Hazırlanıyor...' : 'Planı Önizle'}
          </RwButton>
        )}
      />

      <div className="grid min-h-0 flex-1 grid-cols-1 gap-3 xl:grid-cols-[minmax(0,1fr)_360px]">
        {/* SOL */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto pr-1">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {kartlar.map((k) => (
              <div key={k.key} className="flex items-center gap-2.5 rounded-lg border border-background-300/50 bg-background-100 p-2.5 dark:border-background-400/30 dark:bg-background-200/40">
                <span className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-md text-inverse ${k.renk}`}><i className={`${k.icon} text-lg`} /></span>
                <span className="min-w-0">
                  <span className="block text-lg font-bold text-foreground-950">{k.adet}</span>
                  <span className="block truncate text-[11px] font-medium text-foreground-500">{k.label}</span>
                </span>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <RwCard title="Ekip Rolü Dağılımı" icon="ri-pie-chart-2-line" className="p-3">
              {ekipler.length === 0 ? (
                <p className="py-8 text-center text-xs text-foreground-400">Ekip üyesi eklenince dağılım görünecek.</p>
              ) : (
                <div className="flex items-center gap-4">
                  <div className="relative h-28 w-28 flex-shrink-0">
                    <div className="h-full w-full rounded-full" style={{ background: `conic-gradient(${donutGradient})` }} />
                    <div className="absolute inset-[18%] flex flex-col items-center justify-center rounded-full bg-background-100 dark:bg-background-200">
                      <span className="text-lg font-bold text-foreground-950">{ekipler.length}</span>
                      <span className="text-[10px] text-foreground-500">Üye</span>
                    </div>
                  </div>
                  <ul className="min-w-0 flex-1 space-y-1">
                    {rolDagilim.slice(0, 7).map((k, i) => (
                      <li key={k.rol} className="flex items-center gap-2 text-xs">
                        <span className="h-2.5 w-2.5 flex-shrink-0 rounded-full" style={{ backgroundColor: ROL_RENK[i % ROL_RENK.length] }} />
                        <span className="flex-1 truncate text-foreground-600">{k.rol}</span>
                        <span className="font-medium text-foreground-800">{k.adet}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </RwCard>

            <RwCard title="Senaryo Kategori Dağılımı" icon="ri-bar-chart-2-line" className="p-3">
              {senaryolar.length === 0 ? (
                <p className="py-8 text-center text-xs text-foreground-400">Senaryo eklenince dağılım görünecek.</p>
              ) : (
                <ul className="space-y-2">
                  {kategoriDagilim.map((k) => {
                    const maxK = Math.max(1, ...kategoriDagilim.map((x) => x.adet));
                    return (
                      <li key={k.kategori} className="text-xs">
                        <div className="mb-1 flex items-center justify-between gap-2">
                          <span className="flex items-center gap-1.5 truncate text-foreground-600"><i className={senaryoIkon(k.kategori)} /> {k.kategori}</span>
                          <span className="font-medium text-foreground-800">{k.adet}</span>
                        </div>
                        <div className="h-1.5 w-full overflow-hidden rounded-full bg-background-200 dark:bg-background-300/60">
                          <div className="h-full rounded-full bg-primary-500" style={{ width: `${(k.adet / maxK) * 100}%` }} />
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </RwCard>
          </div>

          {/* Kroki önizleme */}
          <RwCard className="p-0">
            <div className="border-b border-background-300/40 p-3 dark:border-background-400/25">
              <h3 className="text-xs font-semibold text-foreground-950">Tahliye Krokisi</h3>
              <p className="mt-0.5 text-[11px] text-foreground-500">Çizdiğiniz kroki rapora aynen gömülür.</p>
            </div>
            {kroki ? (
              <div className="p-3">
                <img src={kroki} alt="Tahliye krokisi önizleme" title="Tahliye krokisi" className="h-auto w-full rounded-md border border-background-300/60 bg-white" />
              </div>
            ) : (
              <p className="px-3 py-8 text-center text-xs text-foreground-400">Kroki çizilmemiş. "Kroki" adımından çizebilirsiniz.</p>
            )}
          </RwCard>

          {/* Senaryo matrisi */}
          <RwCard className="p-0">
            <div className="border-b border-background-300/40 p-3 dark:border-background-400/25">
              <h3 className="text-xs font-semibold text-foreground-950">Acil Durum Senaryoları</h3>
              <p className="mt-0.5 text-[11px] text-foreground-500">Senaryolar ve müdahale yaklaşımları (rapora aynen yansır).</p>
            </div>
            {senaryolar.length === 0 ? (
              <p className="px-3 py-8 text-center text-xs text-foreground-400">Senaryo eklenince liste görünecek.</p>
            ) : (
              <div className="isg-scroll-pane max-h-[360px] overflow-auto">
                <table className="w-full border-collapse" style={{ minWidth: 860 }}>
                  <thead className="sticky top-0 bg-background-200 dark:bg-background-300/70">
                    <tr className="text-left text-[10px] font-semibold uppercase tracking-wide text-foreground-500">
                      <th className="px-2 py-1.5 whitespace-nowrap">#</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Olay / Senaryo</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Kategori</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Derece</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Sorumlu Ekip</th>
                      <th className="px-2 py-1.5 whitespace-nowrap">Tahliye</th>
                    </tr>
                  </thead>
                  <tbody>
                    {senaryolar.map((sn, i) => {
                      const dm = dereceMeta(sn.derece);
                      return (
                        <tr key={sn.id} className="border-t border-background-300/20 align-middle dark:border-background-400/10">
                          <td className="px-2 py-2 text-xs text-foreground-500">{i + 1}</td>
                          <td className="px-2 py-2">
                            <div className="flex items-center gap-2">
                              <i className={`${senaryoIkon(sn.kategori)} text-xs text-primary-500`} />
                              <span className="text-xs font-medium text-foreground-800">{sn.olay || '—'}</span>
                            </div>
                          </td>
                          <td className="px-2 py-2 text-xs text-foreground-600">{sn.kategori}</td>
                          <td className="px-2 py-2">
                            <span className={`inline-flex items-center gap-1 whitespace-nowrap rounded-md px-1.5 py-0.5 text-[10px] font-semibold ${dm.soft}`}>
                              <span className={`h-1.5 w-1.5 rounded-full ${dm.dot}`} /> {sn.derece}
                            </span>
                          </td>
                          <td className="px-2 py-2 text-xs text-foreground-600">{sn.sorumluEkip}</td>
                          <td className="px-2 py-2 text-xs text-foreground-600">{sn.tahliyeGerekli ? <i className="ri-check-line text-success-600" /> : '—'}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </RwCard>

          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <RwCard title="Acil İletişim Numaraları" icon="ri-phone-line" className="p-3">
              {iletisim.length === 0 ? (
                <p className="py-6 text-center text-xs text-foreground-400">Kayıt yok.</p>
              ) : (
                <ul className="space-y-1.5">
                  {iletisim.map((k) => (
                    <li key={k.id} className="flex items-center justify-between gap-2 rounded-md border border-background-300/50 bg-background-50 px-2.5 py-1.5 dark:border-background-400/25 dark:bg-background-100/50">
                      <span className="truncate text-xs text-foreground-700">{k.kurum || '—'}</span>
                      <span className="flex-shrink-0 text-xs font-semibold text-foreground-900">{k.telefon || '—'}</span>
                    </li>
                  ))}
                </ul>
              )}
            </RwCard>

            <RwCard title="Malzeme Envanteri" icon="ri-fire-line" className="p-3">
              {malzemeler.length === 0 ? (
                <p className="py-6 text-center text-xs text-foreground-400">Kayıt yok.</p>
              ) : (
                <ul className="space-y-1.5">
                  {malzemeler.map((m) => (
                    <li key={m.id} className="flex items-center justify-between gap-2 rounded-md border border-background-300/50 bg-background-50 px-2.5 py-1.5 dark:border-background-400/25 dark:bg-background-100/50">
                      <span className="truncate text-xs text-foreground-700">{m.ad || '—'}{m.konum ? ` · ${m.konum}` : ''}</span>
                      <span className="flex-shrink-0 rounded-md bg-secondary-100 px-1.5 py-0.5 text-[10px] font-semibold text-secondary-900 dark:bg-secondary-500/15 dark:text-secondary-200">{m.adet || 0}</span>
                    </li>
                  ))}
                </ul>
              )}
            </RwCard>
          </div>

          <RwCard title="Tatbikat Planı" icon="ri-calendar-check-line" className="p-3">
            {tatbikatlar.length === 0 ? (
              <p className="py-6 text-center text-xs text-foreground-400">Tatbikat planlanmamış. "Tatbikat" sekmesinden ekleyebilirsiniz.</p>
            ) : (
              <ul className="space-y-1.5">
                {tatbikatlar.map((t) => (
                  <li key={t.id} className="flex flex-wrap items-center gap-2 rounded-md border border-background-300/50 bg-background-50 px-2.5 py-2 dark:border-background-400/25 dark:bg-background-100/50">
                    <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-md bg-accent-500/15 text-accent-600 dark:text-accent-300"><i className="ri-calendar-check-line" /></span>
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-xs font-medium text-foreground-900">{t.konu || '—'}</span>
                      <span className="block truncate text-[11px] text-foreground-500">{tarihGoster(t.tarih)}{t.sorumlu ? ` · ${t.sorumlu}` : ''}</span>
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </RwCard>

          {/* Mevzuat */}
          <RwCard title="Mevzuat Dayanakları" icon="ri-scales-3-line" className="p-3">
            <ul className="space-y-2">
              {mevzuat.map((m) => (
                <li key={m.baslik} className="flex items-start gap-2">
                  <i className="ri-checkbox-circle-line mt-0.5 flex-shrink-0 text-sm text-success-500" />
                  <span className="min-w-0">
                    <span className="block text-xs font-semibold text-foreground-900">{m.baslik}</span>
                    <span className="block text-[11px] leading-snug text-foreground-500">{m.aciklama}</span>
                  </span>
                </li>
              ))}
            </ul>
          </RwCard>

          <div className="pb-7" />
        </div>

        {/* SAĞ */}
        <div className="isg-scroll-pane min-h-0 space-y-3 overflow-y-auto">
          <RwCard title="Rapor İşlemleri" icon="ri-download-2-line" className="p-3">
            <p className="mb-2.5 text-xs text-foreground-500">Planı aşağıdaki formatlarda oluşturabilirsiniz.</p>
            <div className="grid grid-cols-2 gap-2">
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('word')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-primary-500 text-inverse transition-colors hover:bg-primary-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'word' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="word" size="md" />}
                <span className="text-xs leading-tight">Word İndir</span>
              </button>
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('pdf')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-danger-500 text-inverse transition-colors hover:bg-danger-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'pdf' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="pdf" size="md" />}
                <span className="text-xs leading-tight">PDF İndir</span>
              </button>
              <button type="button" disabled={indiriliyor !== null} onClick={() => void indir('excel')} className="flex h-16 cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md bg-success-500 text-inverse transition-colors hover:bg-success-600 disabled:cursor-not-allowed disabled:opacity-60">
                {indiriliyor === 'excel' ? <i className="ri-loader-4-line animate-spin text-lg" /> : <Icon name="excel" size="md" />}
                <span className="text-xs leading-tight">Excel İndir</span>
              </button>
              <div className="relative">
                <button type="button" onClick={() => setIndirAcik((o) => !o)} className="flex h-16 w-full cursor-pointer flex-col items-center justify-center gap-1 whitespace-nowrap rounded-md border border-background-300/70 text-foreground-700 transition-colors hover:bg-background-100 dark:border-background-400/40 dark:hover:bg-background-300/40">
                  <i className="ri-more-2-line text-lg" />
                  <span className="text-xs leading-tight">Diğer</span>
                </button>
                {indirAcik && (
                  <div className="absolute right-0 top-full z-30 mt-1 w-56 rounded-md border border-background-300/70 bg-background-50 p-1 shadow-xl dark:border-background-400/50 dark:bg-background-200">
                    <button type="button" onClick={() => void indir('csv')} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <i className="ri-file-chart-2-line text-success-600" /> CSV (ham veri) indir
                    </button>
                    <button type="button" onClick={() => void indir('txt')} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <Icon name="text" size="sm" /> Metin (TXT) raporu indir
                    </button>
                    <button type="button" onClick={() => void ozetKopyala()} className="flex w-full cursor-pointer items-center gap-2 rounded px-2.5 py-1.5 text-left text-xs text-foreground-700 hover:bg-background-100 dark:hover:bg-background-300/40">
                      <i className="ri-clipboard-line text-secondary-600" /> Özeti panoya kopyala
                    </button>
                  </div>
                )}
              </div>
            </div>
          </RwCard>

          <RwCard title="Rapor Bilgileri" icon="ri-file-list-3-line" className="p-3">
            <div className="space-y-2.5">
              <RwInput label="Rapor Numarası" value={temel.raporNo} onChange={(e) => onTemelChange({ raporNo: e.target.value })} placeholder="ADEP-2026-001" />
              <div className="rounded-md border border-background-300/50 bg-background-50 p-2.5 text-xs dark:border-background-400/25 dark:bg-background-100/50">
                <div className="flex items-center justify-between"><span className="text-foreground-500">Firma</span><span className="font-medium text-foreground-800">{temel.firma || '—'}</span></div>
                <div className="mt-1.5 flex items-center justify-between"><span className="text-foreground-500">Plan Yılı</span><span className="font-medium text-foreground-800">{temel.planYili || '—'}</span></div>
                <div className="mt-1.5 flex items-center justify-between"><span className="text-foreground-500">Düzenleme</span><span className="font-medium text-foreground-800">{tarihGoster(temel.tarih)}</span></div>
                <div className="mt-1.5 flex items-center justify-between"><span className="text-foreground-500">Toplanma Noktası</span><span className="max-w-[55%] truncate font-medium text-foreground-800">{temel.toplanmaYeri || '—'}</span></div>
                <div className="mt-1.5 flex items-center justify-between"><span className="text-foreground-500">Senaryo / Ekip</span><span className="font-medium text-foreground-800">{senaryolar.length} / {ekipler.length}</span></div>
              </div>
            </div>
          </RwCard>

          <RwCard title="Raporda Yer Alacak İmzacılar" icon="ri-user-star-line" className="p-3">
            <p className="mb-2 text-xs text-foreground-500">Raporun sonundaki onay bölümünde yer alacak imzacıları ekleyin. Boş bırakılırsa hazırlayan ve onaylayan kişiler otomatik eklenir.</p>
            {imzacilar.length > 0 && (
              <div className="mb-2.5 overflow-hidden rounded-md border border-background-300/50 dark:border-background-400/25">
                <table className="w-full border-collapse">
                  <thead className="bg-background-200 dark:bg-background-300/60">
                    <tr className="text-left text-xs font-semibold text-foreground-500">
                      <th className="w-8 px-2 py-1.5 text-center">#</th>
                      <th className="px-2 py-1.5">Adı Soyadı</th>
                      <th className="px-2 py-1.5">Görevi</th>
                      <th className="w-16 px-2 py-1.5 text-center">İşlem</th>
                    </tr>
                  </thead>
                  <tbody>
                    {imzacilar.map((im, i) => (
                      <tr key={im.id} className="border-t border-background-300/30 dark:border-background-400/20">
                        <td className="px-2 py-1.5 text-center text-xs text-foreground-500">{i + 1}</td>
                        <td className="px-2 py-1.5 text-xs font-medium text-foreground-950">{im.adSoyad || '—'}</td>
                        <td className="px-2 py-1.5 text-xs text-foreground-600">{im.gorev || '—'}</td>
                        <td className="px-2 py-1.5">
                          <div className="flex items-center justify-center gap-0.5">
                            <RwIconButton icon="ri-edit-line" onClick={() => imzaciDuzenle(im)} />
                            <RwIconButton icon="ri-delete-bin-line" tone="danger" onClick={() => imzaciSil(im.id)} />
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div className="space-y-2 rounded-md border border-dashed border-background-300/60 p-2.5 dark:border-background-400/30">
              <RwInput size="sm" placeholder="Ad Soyad" value={yeniAd} onChange={(e) => setYeniAd(e.target.value)} />
              <RwInput size="sm" placeholder="Görev / Unvan" value={yeniGorev} onChange={(e) => setYeniGorev(e.target.value)} />
              <RwInput size="sm" placeholder="Belge / Sertifika No (opsiyonel)" value={yeniBelge} onChange={(e) => setYeniBelge(e.target.value)} />
              <RwButton variant="outline" size="sm" block icon={duzenlenen ? 'ri-check-line' : 'ri-add-line'} onClick={imzaciKaydet}>
                {duzenlenen ? 'Güncelle' : 'Yeni İmzacı Ekle'}
              </RwButton>
            </div>
          </RwCard>

          <div className="rounded-lg border border-primary-300/40 bg-primary-50 p-3 dark:border-primary-500/25 dark:bg-primary-500/10">
            <p className="flex items-center gap-1.5 text-xs font-semibold text-foreground-950"><i className="ri-information-line text-primary-500" /> Rapor İçeriği</p>
            <p className="mt-1 text-xs leading-relaxed text-foreground-600">
              Rapor; firma ve plan bilgileri, plan kapsamı, acil durum ekipleri, senaryolar ve müdahale,
              tahliye bilgileri + kroki, özet/dağılım, mevzuat dayanakları ve onay bölümlerini içerir.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}