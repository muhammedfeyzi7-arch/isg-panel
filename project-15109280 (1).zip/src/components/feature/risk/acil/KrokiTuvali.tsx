import { useCallback, useEffect, useRef, useState } from 'react';
import { RwButton } from '@/components/feature/risk/sihirbaz/wizardUi';

// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM — TAHLİYE KROKİSİ ÇİZİM TUVALİ (PREMIUM)
//
// Tam işlevli teknik çizim tahtası:
//   • Duvar (kalın) / Kapı (yay) / Pencere (çift çizgi) / Serbest kalem
//   • Semboller: Acil Çıkış, Yangın Söndürücü, Toplanma Noktası, Merdiven, İlk Yardım
//   • Metin / Seç & Taşı / Sil
//   • Izgaraya yakalama (snap), Geri Al / İleri Al (undo/redo)
//   • Hazır şablonlar: Ofis, Atölye, Depo
//   • Lejant kutusu otomatik çizilir
//   • Rapora gömülmek için yüksek çözünürlüklü PNG (2.5x) dışarı verilir
//
// Çizim öğeleri JSON (tekrar düzenlenebilsin diye) + PNG dataURL (rapora gömülsün
// diye) olarak dışarı verilir. Harici kütüphane kullanılmaz.
// ─────────────────────────────────────────────────────────────────────────────

const EN = 1200;
const BOY = 760;
const IZGARA = 20;
const KALINLIK = 7;

type IconKind = 'cikis' | 'sondurucu' | 'toplanma' | 'merdiven' | 'ilkyardim';

type El =
  | { t: 'wall'; x: number; y: number; w: number; h: number }
  | { t: 'door'; a: P; b: P }
  | { t: 'window'; a: P; b: P }
  | { t: 'path'; pts: P[] }
  | { t: 'icon'; kind: IconKind; x: number; y: number }
  | { t: 'text'; x: number; y: number; text: string };

interface P { x: number; y: number }

type Tool = 'duvar' | 'kapi' | 'pencere' | 'kalem' | 'sec' | 'metin' | 'sil' | IconKind;

const IKON_ETIKET: Record<IconKind, string> = {
  cikis: 'Acil Çıkış',
  sondurucu: 'Söndürücü',
  toplanma: 'Toplanma Noktası',
  merdiven: 'Merdiven',
  ilkyardim: 'İlk Yardım',
};

const IKON_RENK: Record<IconKind, string> = {
  cikis: '#16A34A',
  sondurucu: '#DC2626',
  toplanma: '#15803D',
  merdiven: '#6B7280',
  ilkyardim: '#FFFFFF',
};

const ARAÇLAR: { key: Tool; label: string; icon: string }[] = [
  { key: 'duvar', label: 'Duvar', icon: 'ri-layout-line' },
  { key: 'kapi', label: 'Kapı', icon: 'ri-door-open-line' },
  { key: 'pencere', label: 'Pencere', icon: 'ri-window-line' },
  { key: 'kalem', label: 'Kalem', icon: 'ri-pencil-line' },
  { key: 'cikis', label: 'Acil Çıkış', icon: 'ri-run-line' },
  { key: 'sondurucu', label: 'Söndürücü', icon: 'ri-fire-line' },
  { key: 'toplanma', label: 'Toplanma', icon: 'ri-flag-line' },
  { key: 'merdiven', label: 'Merdiven', icon: 'ri-stairs-line' },
  { key: 'ilkyardim', label: 'İlk Yardım', icon: 'ri-first-aid-kit-line' },
  { key: 'metin', label: 'Metin', icon: 'ri-text' },
  { key: 'sec', label: 'Seç & Taşı', icon: 'ri-drag-move-2-line' },
  { key: 'sil', label: 'Sil', icon: 'ri-eraser-line' },
];

const snap = (v: number) => Math.round(v / IZGARA) * IZGARA;

// ── Şablonlar ────────────────────────────────────────────────────────────────
function sablonOfis(): El[] {
  return [
    { t: 'wall', x: 120, y: 120, w: 960, h: 520 },
    { t: 'wall', x: 120, y: 340, w: 560, h: 0 },
    { t: 'wall', x: 560, y: 340, w: 0, h: 300 },
    { t: 'door', a: { x: 460, y: 340 }, b: { x: 560, y: 340 } },
    { t: 'window', a: { x: 300, y: 120 }, b: { x: 620, y: 120 } },
    { t: 'window', a: { x: 300, y: 640 }, b: { x: 640, y: 640 } },
    { t: 'icon', kind: 'cikis', x: 210, y: 210 },
    { t: 'icon', kind: 'cikis', x: 1000, y: 210 },
    { t: 'icon', kind: 'sondurucu', x: 1000, y: 580 },
    { t: 'icon', kind: 'ilkyardim', x: 210, y: 580 },
    { t: 'icon', kind: 'toplanma', x: 660, y: 700 },
    { t: 'text', x: 300, y: 230, text: 'OFİS / TOPLANTI' },
    { t: 'text', x: 700, y: 470, text: 'DEPO' },
  ];
}

function sablonAtolye(): El[] {
  return [
    { t: 'wall', x: 80, y: 100, w: 1040, h: 560 },
    { t: 'wall', x: 620, y: 100, w: 0, h: 320 },
    { t: 'wall', x: 620, y: 100, w: 500, h: 0 },
    { t: 'door', a: { x: 520, y: 100 }, b: { x: 620, y: 100 } },
    { t: 'window', a: { x: 250, y: 660 }, b: { x: 700, y: 660 } },
    { t: 'icon', kind: 'cikis', x: 170, y: 170 },
    { t: 'icon', kind: 'cikis', x: 1040, y: 600 },
    { t: 'icon', kind: 'sondurucu', x: 400, y: 170 },
    { t: 'icon', kind: 'sondurucu', x: 1040, y: 170 },
    { t: 'icon', kind: 'ilkyardim', x: 170, y: 600 },
    { t: 'icon', kind: 'merdiven', x: 980, y: 470 },
    { t: 'icon', kind: 'toplanma', x: 170, y: 720 },
    { t: 'text', x: 260, y: 260, text: 'ÜRETİM / ATÖLYE' },
    { t: 'text', x: 760, y: 260, text: 'KİMYASAL DEPO' },
  ];
}

function sablonDepo(): El[] {
  return [
    { t: 'wall', x: 100, y: 120, w: 1000, h: 520 },
    { t: 'door', a: { x: 520, y: 640 }, b: { x: 680, y: 640 } },
    { t: 'window', a: { x: 200, y: 120 }, b: { x: 1000, y: 120 } },
    { t: 'path', pts: [{ x: 200, y: 300 }, { x: 1000, y: 300 }] },
    { t: 'path', pts: [{ x: 200, y: 480 }, { x: 1000, y: 480 }] },
    { t: 'icon', kind: 'cikis', x: 190, y: 220 },
    { t: 'icon', kind: 'cikis', x: 190, y: 560 },
    { t: 'icon', kind: 'sondurucu', x: 1040, y: 200 },
    { t: 'icon', kind: 'sondurucu', x: 1040, y: 560 },
    { t: 'icon', kind: 'toplanma', x: 640, y: 720 },
    { t: 'text', x: 300, y: 230, text: 'RAF ALANI A' },
    { t: 'text', x: 300, y: 410, text: 'RAF ALANI B' },
  ];
}

const SABLONLAR: { key: string; label: string; icon: string; kur: () => El[] }[] = [
  { key: 'ofis', label: 'Ofis', icon: 'ri-building-2-line', kur: sablonOfis },
  { key: 'atolye', label: 'Atölye', icon: 'ri-tools-line', kur: sablonAtolye },
  { key: 'depo', label: 'Depo', icon: 'ri-stack-line', kur: sablonDepo },
];

// ── Çizim ────────────────────────────────────────────────────────────────────
function drawGrid(ctx: CanvasRenderingContext2D): void {
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, EN, BOY);
  ctx.strokeStyle = '#EDF2F8';
  ctx.lineWidth = 1;
  for (let x = 0; x <= EN; x += IZGARA) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, BOY); ctx.stroke(); }
  for (let y = 0; y <= BOY; y += IZGARA) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(EN, y); ctx.stroke(); }
  // Ana ızgara (100px)
  ctx.strokeStyle = '#DCE6F2';
  ctx.lineWidth = 1;
  for (let x = 0; x <= EN; x += IZGARA * 5) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, BOY); ctx.stroke(); }
  for (let y = 0; y <= BOY; y += IZGARA * 5) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(EN, y); ctx.stroke(); }
}

function drawWall(ctx: CanvasRenderingContext2D, e: Extract<El, { t: 'wall' }>): void {
  ctx.save();
  ctx.fillStyle = 'rgba(15,39,71,0.10)';
  ctx.fillRect(e.x, e.y, e.w || KALINLIK, e.h || KALINLIK);
  ctx.strokeStyle = '#0F2747';
  ctx.lineWidth = KALINLIK;
  ctx.lineJoin = 'miter';
  if (e.h === 0) {
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x + e.w, e.y); ctx.stroke();
  } else if (e.w === 0) {
    ctx.beginPath(); ctx.moveTo(e.x, e.y); ctx.lineTo(e.x, e.y + e.h); ctx.stroke();
  } else {
    ctx.strokeRect(e.x, e.y, e.w, e.h);
  }
  ctx.restore();
}

function drawDoor(ctx: CanvasRenderingContext2D, e: Extract<El, { t: 'door' }>): void {
  const { a, b } = e;
  const r = Math.hypot(b.x - a.x, b.y - a.y);
  if (r < 4) return;
  const aci = Math.atan2(b.y - a.y, b.x - a.x);
  ctx.save();
  ctx.strokeStyle = '#0F2747';
  ctx.lineWidth = 2;
  // Kapı kanadı
  ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(a.x + Math.cos(aci), a.y + Math.sin(aci)); ctx.stroke();
  // Yay
  ctx.beginPath(); ctx.arc(a.x, a.y, r, aci, aci + Math.PI / 2, false); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(a.x + r * Math.cos(aci + Math.PI / 2), a.y + r * Math.sin(aci + Math.PI / 2)); ctx.stroke();
  ctx.restore();
}

function drawWindow(ctx: CanvasRenderingContext2D, e: Extract<El, { t: 'window' }>): void {
  const { a, b } = e;
  const len = Math.hypot(b.x - a.x, b.y - a.y);
  if (len < 4) return;
  const nx = -(b.y - a.y) / len; const ny = (b.x - a.x) / len;
  ctx.save();
  ctx.strokeStyle = '#2563EB';
  ctx.lineWidth = 3;
  [-3, 3].forEach((off) => {
    ctx.beginPath();
    ctx.moveTo(a.x + nx * off, a.y + ny * off);
    ctx.lineTo(b.x + nx * off, b.y + ny * off);
    ctx.stroke();
  });
  ctx.restore();
}

function drawIcon(ctx: CanvasRenderingContext2D, kind: IconKind, x: number, y: number): void {
  const r = 16;
  ctx.save();
  if (kind === 'cikis') {
    ctx.fillStyle = IKON_RENK.cikis;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath(); ctx.moveTo(x - 6, y - 7); ctx.lineTo(x + 8, y); ctx.lineTo(x - 6, y + 7); ctx.closePath(); ctx.fill();
  } else if (kind === 'sondurucu') {
    ctx.fillStyle = IKON_RENK.sondurucu;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; ctx.font = 'bold 17px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('S', x, y + 1);
  } else if (kind === 'toplanma') {
    ctx.fillStyle = IKON_RENK.toplanma;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#FFFFFF'; ctx.font = 'bold 17px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText('T', x, y + 1);
  } else if (kind === 'merdiven') {
    ctx.fillStyle = IKON_RENK.merdiven;
    ctx.fillRect(x - 15, y - 15, 30, 30);
    ctx.strokeStyle = '#FFFFFF'; ctx.lineWidth = 2;
    for (let i = -10; i <= 10; i += 6) { ctx.beginPath(); ctx.moveTo(x - 15, y + i); ctx.lineTo(x + 15, y + i); ctx.stroke(); }
  } else if (kind === 'ilkyardim') {
    ctx.fillStyle = '#FFFFFF'; ctx.fillRect(x - 15, y - 15, 30, 30);
    ctx.strokeStyle = '#DC2626'; ctx.lineWidth = 2; ctx.strokeRect(x - 15, y - 15, 30, 30);
    ctx.fillStyle = '#DC2626';
    ctx.fillRect(x - 3, y - 10, 6, 20); ctx.fillRect(x - 10, y - 3, 20, 6);
  }
  ctx.restore();
  ctx.save();
  ctx.fillStyle = '#374151'; ctx.font = '11px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'top';
  ctx.fillText(IKON_ETIKET[kind], x, y + r + 2);
  ctx.restore();
}

function drawLegend(ctx: CanvasRenderingContext2D, els: El[]): void {
  const kullanilan = Array.from(new Set(els.filter((e) => e.t === 'icon').map((e) => (e as Extract<El, { t: 'icon' }>).kind)));
  if (kullanilan.length === 0) return;
  const w = 190; const h = 24 + kullanilan.length * 22; const x = 14; const y = BOY - h - 14;
  ctx.save();
  ctx.fillStyle = 'rgba(255,255,255,0.94)';
  ctx.strokeStyle = '#C8D2DE'; ctx.lineWidth = 1;
  ctx.fillRect(x, y, w, h); ctx.strokeRect(x, y, w, h);
  ctx.fillStyle = '#0F2747'; ctx.font = 'bold 11px sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
  ctx.fillText('LEJANT', x + 10, y + 14);
  kullanilan.forEach((k, i) => {
    const cy = y + 30 + i * 22;
    if (k === 'ilkyardim') {
      ctx.fillStyle = '#FFFFFF'; ctx.fillRect(x + 10, cy - 7, 14, 14);
      ctx.strokeStyle = '#DC2626'; ctx.strokeRect(x + 10, cy - 7, 14, 14);
      ctx.fillStyle = '#DC2626'; ctx.fillRect(x + 16, cy - 1, 2, 2);
      ctx.fillRect(x + 14, cy - 4, 6, 2); ctx.fillRect(x + 14, cy + 2, 6, 2);
    } else {
      ctx.fillStyle = IKON_RENK[k];
      ctx.beginPath(); ctx.arc(x + 17, cy, 7, 0, Math.PI * 2); ctx.fill();
    }
    ctx.fillStyle = '#374151'; ctx.font = '11px sans-serif';
    ctx.fillText(IKON_ETIKET[k], x + 32, cy);
  });
  ctx.restore();
}

function render(ctx: CanvasRenderingContext2D, els: El[], gecici: El | null, seciliId: number): void {
  drawGrid(ctx);
  const ciz = (e: El, idx: number) => {
    if (e.t === 'wall') drawWall(ctx, e);
    else if (e.t === 'door') drawDoor(ctx, e);
    else if (e.t === 'window') drawWindow(ctx, e);
    else if (e.t === 'path') {
      if (e.pts.length < 2) return;
      ctx.save();
      ctx.strokeStyle = '#1F2937'; ctx.lineWidth = 2.5; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(e.pts[0].x, e.pts[0].y);
      for (let i = 1; i < e.pts.length; i += 1) ctx.lineTo(e.pts[i].x, e.pts[i].y);
      ctx.stroke(); ctx.restore();
    } else if (e.t === 'icon') drawIcon(ctx, e.kind, e.x, e.y);
    else if (e.t === 'text') {
      ctx.save();
      ctx.fillStyle = '#0F2747'; ctx.font = 'bold 16px sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
      ctx.fillText(e.text, e.x, e.y); ctx.restore();
    }
    if (idx === seciliId) {
      ctx.save();
      ctx.strokeStyle = '#2563EB'; ctx.lineWidth = 1.5; ctx.setLineDash([5, 4]);
      const b = bounds(e);
      ctx.strokeRect(b.x - 6, b.y - 6, b.w + 12, b.h + 12);
      ctx.restore();
    }
  };
  els.forEach((e, i) => ciz(e, i));
  if (gecici) ciz(gecici, -1);
  drawLegend(ctx, els);
}

function bounds(e: El): { x: number; y: number; w: number; h: number } {
  if (e.t === 'wall') return { x: e.x, y: e.y, w: e.w || KALINLIK, h: e.h || KALINLIK };
  if (e.t === 'door' || e.t === 'window') return { x: Math.min(e.a.x, e.b.x), y: Math.min(e.a.y, e.b.y), w: Math.abs(e.a.x - e.b.x), h: Math.abs(e.a.y - e.b.y) };
  if (e.t === 'path') {
    const xs = e.pts.map((p) => p.x); const ys = e.pts.map((p) => p.y);
    return { x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys) };
  }
  if (e.t === 'icon') return { x: e.x - 18, y: e.y - 18, w: 36, h: 36 };
  return { x: e.x, y: e.y - 10, w: e.text.length * 9, h: 20 };
}

interface Props {
  veri: string;
  onChange: (dataUrl: string, veriJson: string) => void;
}

export default function KrokiTuvali({ veri, onChange }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const elsRef = useRef<El[]>([]);
  const gecmis = useRef<El[][]>([]);
  const ileri = useRef<El[][]>([]);
  const [els, setEls] = useState<El[]>(() => {
    if (!veri) return [];
    try { const p = JSON.parse(veri); return Array.isArray(p) ? (p as El[]) : []; } catch { return []; }
  });
  elsRef.current = els;

  const [arac, setArac] = useState<Tool>('duvar');
  const [metin, setMetin] = useState('');
  const [seciliId, setSeciliId] = useState<number>(-1);
  const [ciziyor, setCiziyor] = useState(false);
  const baslangicRef = useRef<P | null>(null);
  const geciciRef = useRef<El | null>(null);
  const tasiRef = useRef<{ idx: number; dx: number; dy: number } | null>(null);

  const yuzeyCiz = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    render(ctx, els, geciciRef.current, seciliId);
  }, [els, seciliId]);

  useEffect(() => { yuzeyCiz(); }, [yuzeyCiz]);

  // Değişiklikte dışarıya: yüksek çözünürlüklü PNG (2.5x) + JSON.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const olcek = 2.5;
    const off = document.createElement('canvas');
    off.width = EN * olcek; off.height = BOY * olcek;
    const octx = off.getContext('2d');
    if (octx) { octx.scale(olcek, olcek); render(octx, els, null, -1); }
    onChange(off.toDataURL('image/png'), JSON.stringify(els));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [els]);

  const commit = (next: El[]) => {
    gecmis.current.push(elsRef.current);
    if (gecmis.current.length > 100) gecmis.current.shift();
    ileri.current = [];
    setEls(next);
  };

  const geriAl = () => {
    if (gecmis.current.length === 0) return;
    ileri.current.push(elsRef.current);
    const p = gecmis.current.pop();
    if (p) { setEls(p); setSeciliId(-1); }
  };
  const ileriAl = () => {
    if (ileri.current.length === 0) return;
    gecmis.current.push(elsRef.current);
    const n = ileri.current.pop();
    if (n) { setEls(n); setSeciliId(-1); }
  };

  const nokta = (e: React.PointerEvent<HTMLCanvasElement>): P => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return { x: (e.clientX - rect.left) * (EN / rect.width), y: (e.clientY - rect.top) * (BOY / rect.height) };
  };

  const silmeHedefi = (p: P): number => {
    for (let i = els.length - 1; i >= 0; i -= 1) {
      const e = els[i];
      const b = bounds(e);
      if (p.x >= b.x - 8 && p.x <= b.x + b.w + 8 && p.y >= b.y - 8 && p.y <= b.y + b.h + 8) return i;
    }
    return -1;
  };

  const basla = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const p = nokta(e);
    if (arac === 'duvar' || arac === 'kapi' || arac === 'pencere') {
      baslangicRef.current = { x: snap(p.x), y: snap(p.y) };
      setCiziyor(true);
      yuzeyCiz();
    } else if (arac === 'kalem') {
      geciciRef.current = { t: 'path', pts: [p] };
      setCiziyor(true);
      yuzeyCiz();
    } else if (arac === 'metin') {
      const t = metin.trim();
      if (t) { commit([...els, { t: 'text', x: p.x, y: p.y, text: t }]); setMetin(''); }
    } else if (arac === 'sil') {
      const idx = silmeHedefi(p);
      if (idx >= 0) { commit(els.filter((_, i) => i !== idx)); setSeciliId(-1); }
    } else if (arac === 'sec') {
      const idx = silmeHedefi(p);
      setSeciliId(idx);
      if (idx >= 0) {
        gecmis.current.push(elsRef.current);
        const b = bounds(els[idx]);
        tasiRef.current = { idx, dx: p.x - b.x, dy: p.y - b.y };
      }
    } else {
      commit([...els, { t: 'icon', kind: arac as IconKind, x: snap(p.x), y: snap(p.y) }]);
    }
  };

  const hareket = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (tasiRef.current) {
      const p = nokta(e);
      const { idx, dx, dy } = tasiRef.current;
      const eski = elsRef.current;
      const b = bounds(eski[idx]);
      const nx = snap(p.x - dx); const ny = snap(p.y - dy);
      const ox = nx - b.x; const oy = ny - b.y;
      const yeni = eski.map((el, i) => {
        if (i !== idx) return el;
        if (el.t === 'wall') return { ...el, x: el.x + ox, y: el.y + oy };
        if (el.t === 'door' || el.t === 'window') return { ...el, a: { x: el.a.x + ox, y: el.a.y + oy }, b: { x: el.b.x + ox, y: el.b.y + oy } };
        if (el.t === 'path') return { ...el, pts: el.pts.map((pt) => ({ x: pt.x + ox, y: pt.y + oy })) };
        if (el.t === 'icon') return { ...el, x: el.x + ox, y: el.y + oy };
        return { ...el, x: el.x + ox, y: el.y + oy };
      });
      setEls(yeni);
      return;
    }
    if (!ciziyor) return;
    const p = nokta(e);
    const b = baslangicRef.current;
    if (!b) return;
    if (arac === 'duvar') {
      const x2 = snap(p.x); const y2 = snap(p.y);
      const w = Math.abs(x2 - b.x); const h = Math.abs(y2 - b.y);
      geciciRef.current = w >= h
        ? { t: 'wall', x: Math.min(b.x, x2), y: b.y, w, h: 0 }
        : { t: 'wall', x: b.x, y: Math.min(b.y, y2), w: 0, h };
      yuzeyCiz();
    } else if (arac === 'kapi') {
      geciciRef.current = { t: 'door', a: b, b: { x: snap(p.x), y: snap(p.y) } };
      yuzeyCiz();
    } else if (arac === 'pencere') {
      geciciRef.current = { t: 'window', a: b, b: { x: snap(p.x), y: snap(p.y) } };
      yuzeyCiz();
    } else if (arac === 'kalem' && geciciRef.current && geciciRef.current.t === 'path') {
      geciciRef.current = { t: 'path', pts: [...geciciRef.current.pts, p] };
      yuzeyCiz();
    }
  };

  const bitir = () => {
    if (tasiRef.current) { tasiRef.current = null; return; }
    if (!ciziyor) return;
    const g = geciciRef.current;
    if (g) {
      if (g.t === 'wall' && (g.w > 20 || g.h > 20)) commit([...els, g]);
      else if ((g.t === 'door' || g.t === 'window') && Math.hypot(g.b.x - g.a.x, g.b.y - g.a.y) > 20) commit([...els, g]);
      else if (g.t === 'path' && g.pts.length > 1) commit([...els, g]);
    }
    geciciRef.current = null;
    baslangicRef.current = null;
    setCiziyor(false);
    yuzeyCiz();
  };

  const temizle = () => commit([]);
  const sablonYukle = (kur: () => El[]) => commit(kur());

  const yardimMetni = (() => {
    if (arac === 'duvar') return 'Sürükleyerek duvar çizin (yatay/dikey otomatik).';
    if (arac === 'kapi') return 'Sürükleyerek kapı açıklığı (yay) çizin.';
    if (arac === 'pencere') return 'Sürükleyerek pencere (çift çizgi) çizin.';
    if (arac === 'kalem') return 'Basılı tutup serbest çizin.';
    if (arac === 'metin') return 'Metni yazın, ardından tuvale tıklayın.';
    if (arac === 'sec') return 'Bir öğeye tıklayıp sürükleyerek taşıyın.';
    if (arac === 'sil') return 'Silmek istediğiniz öğeye tıklayın.';
    return 'Yerleştirmek için tuvale tıklayın.';
  })();

  return (
    <div className="flex min-h-0 flex-1 flex-col gap-2.5">
      <div className="flex flex-wrap items-center gap-1.5">
        {ARAÇLAR.map((a) => (
          <button
            key={a.key}
            type="button"
            onClick={() => setArac(a.key)}
            className={`inline-flex cursor-pointer items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-medium transition-colors whitespace-nowrap ${
              arac === a.key
                ? 'border-primary-500 bg-primary-500 text-inverse'
                : 'border-background-300/60 bg-background-100 text-foreground-700 hover:border-primary-300 dark:border-background-400/30 dark:bg-background-200/40'
            }`}
          >
            <i className={a.icon} /> {a.label}
          </button>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2">
        {arac === 'metin' && (
          <input
            value={metin}
            onChange={(e) => setMetin(e.target.value)}
            placeholder="Yerleştirilecek metin"
            className="h-8 w-52 rounded-md border border-background-300/70 bg-background-50 px-2.5 text-xs text-foreground-950 outline-none placeholder:text-foreground-400 focus:border-primary-400 dark:border-background-400/40 dark:bg-background-100/70"
          />
        )}
        <RwButton variant="outline" size="sm" icon="ri-arrow-go-back-line" onClick={geriAl}>Geri Al</RwButton>
        <RwButton variant="outline" size="sm" icon="ri-arrow-go-forward-line" onClick={ileriAl}>İleri Al</RwButton>
        <RwButton variant="ghost" size="sm" icon="ri-delete-bin-line" onClick={temizle}>Temizle</RwButton>
        <span className="mx-1 hidden h-5 w-px bg-background-300/60 sm:block dark:bg-background-400/30" />
        {SABLONLAR.map((s) => (
          <RwButton key={s.key} variant="outline" size="sm" icon={s.icon} onClick={() => sablonYukle(s.kur)}>{s.label} Şablonu</RwButton>
        ))}
      </div>

      <p className="text-[11px] text-foreground-500">{yardimMetni} Izgaraya otomatik yakalanır.</p>

      <div className="flex min-h-0 flex-1 items-center justify-center overflow-hidden rounded-lg border border-background-300/60 bg-white p-2 dark:border-background-400/30">
        <canvas
          ref={canvasRef}
          width={EN}
          height={BOY}
          onPointerDown={basla}
          onPointerMove={hareket}
          onPointerUp={bitir}
          onPointerLeave={bitir}
          className="h-auto w-full max-w-full touch-none rounded-md border border-background-200"
          style={{ aspectRatio: `${EN} / ${BOY}`, cursor: arac === 'sec' ? 'move' : 'crosshair' }}
        />
      </div>
    </div>
  );
}