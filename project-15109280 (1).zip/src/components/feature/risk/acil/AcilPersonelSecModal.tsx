import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { RwButton, RwInput } from '@/components/feature/risk/sihirbaz/wizardUi';
import { matchesSearch } from '@/utils/turkishText';

// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM EKİBİ — SİSTEM PERSONELİNDEN SEÇME MODALI
//
// Kullanıcı acil durum ekibine üye eklerken SİSTEMDEKİ personelden seçebilir.
// Bu işlem YALNIZCA OKUMADIR: seçilen kişiler yerel çalışma alanına eklenir,
// personel kaydına HİÇBİR ŞEY yazılmaz. RLS'a uygun şekilde yalnızca erişilebilen
// personel listelenir. Ağ hatasında anlaşılır mesaj + yeniden deneme gösterilir.
// ─────────────────────────────────────────────────────────────────────────────

export interface SecilenPersonel {
  personelId: string;
  adSoyad: string;
  gorev: string;
}

interface Props {
  onKapat: () => void;
  onEkle: (secilenler: SecilenPersonel[]) => void;
}

interface PersonelRow {
  id: string;
  ad: string | null;
  soyad: string | null;
  gorev: string | null;
  personel_turu: string | null;
}

export default function AcilPersonelSecModal({ onKapat, onEkle }: Props) {
  const [personeller, setPersoneller] = useState<PersonelRow[]>([]);
  const [yukleniyor, setYukleniyor] = useState(true);
  const [hata, setHata] = useState<string | null>(null);
  const [arama, setArama] = useState('');
  const [secilen, setSecilen] = useState<Record<string, boolean>>({});

  const yukle = async () => {
    setYukleniyor(true);
    setHata(null);
    try {
      const { data, error } = await supabase
        .from('personeller')
        .select('id, ad, soyad, gorev, personel_turu, is_active')
        .eq('is_active', true)
        .order('ad', { ascending: true })
        .limit(500);
      if (error) throw error;
      setPersoneller((data ?? []) as PersonelRow[]);
    } catch {
      setHata('Personel listesi alınamadı. Lütfen tekrar deneyin.');
    } finally {
      setYukleniyor(false);
    }
  };

  useEffect(() => { void yukle(); }, []);

  const seciliListe = useMemo(() => {
    const q = arama.trim();
    if (!q) return personeller;
    return personeller.filter((p) => matchesSearch(`${p.ad ?? ''} ${p.soyad ?? ''} ${p.gorev ?? ''}`, q));
  }, [personeller, arama]);

  const seciliSayi = Object.values(secilen).filter(Boolean).length;

  const toggle = (id: string) => setSecilen((p) => ({ ...p, [id]: !p[id] }));

  const ekle = () => {
    const secilenler: SecilenPersonel[] = personeller
      .filter((p) => secilen[p.id])
      .map((p) => ({
        personelId: p.id,
        adSoyad: `${p.ad ?? ''} ${p.soyad ?? ''}`.trim() || 'İsimsiz Personel',
        gorev: p.gorev || p.personel_turu || '',
      }));
    if (secilenler.length === 0) { onKapat(); return; }
    onEkle(secilenler);
    onKapat();
  };

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex-shrink-0 border-b border-background-300/40 p-3 dark:border-background-400/25">
        <RwInput
          size="sm"
          placeholder="Ad, soyad veya görev ile ara..."
          value={arama}
          onChange={(e) => setArama(e.target.value)}
          leftIcon={<i className="ri-search-line text-xs" />}
        />
        <p className="mt-2 flex items-center gap-1.5 text-[11px] text-foreground-500">
          <i className="ri-information-line text-primary-500" />
          Seçim yalnızca okunur; personel kaydına yazılmaz. Seçilenler yerel çalışma alanına eklenir.
        </p>
      </div>

      <div className="isg-scroll-pane min-h-0 flex-1 overflow-y-auto p-2">
        {yukleniyor && (
          <div className="flex items-center justify-center gap-2 py-12 text-xs text-foreground-500">
            <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" /> Personel yükleniyor...
          </div>
        )}
        {!yukleniyor && hata && (
          <div className="flex flex-col items-center justify-center gap-3 py-12 text-center">
            <span className="flex h-10 w-10 items-center justify-center rounded-full bg-danger-500/12 text-danger-600"><i className="ri-error-warning-line text-lg" /></span>
            <p className="text-xs text-foreground-600">{hata}</p>
            <RwButton variant="outline" size="sm" icon="ri-refresh-line" onClick={() => void yukle()}>Yeniden Dene</RwButton>
          </div>
        )}
        {!yukleniyor && !hata && seciliListe.length === 0 && (
          <p className="py-12 text-center text-xs text-foreground-400">
            {personeller.length === 0 ? 'Sistemde personel kaydı bulunamadı.' : 'Sonuç bulunamadı.'}
          </p>
        )}
        {!yukleniyor && !hata && seciliListe.length > 0 && (
          <div className="space-y-1">
            {seciliListe.map((p) => {
              const t = !!secilen[p.id];
              return (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => toggle(p.id)}
                  className={`flex w-full cursor-pointer items-center gap-2.5 rounded-md border px-2.5 py-2 text-left transition-colors ${
                    t ? 'border-primary-500/60 bg-primary-500/10' : 'border-background-300/50 bg-background-100 hover:border-primary-300 dark:border-background-400/25 dark:bg-background-200/40'
                  }`}
                >
                  <span className={`flex h-4 w-4 flex-shrink-0 items-center justify-center rounded border ${t ? 'border-primary-500 bg-primary-500 text-inverse' : 'border-foreground-300 dark:border-background-400'}`}>
                    {t && <i className="ri-check-line text-[10px]" />}
                  </span>
                  <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-background-200 text-xs font-semibold text-foreground-600 dark:bg-background-300/60">
                    {(p.ad || '?').charAt(0).toLocaleUpperCase('tr')}{(p.soyad || '').charAt(0).toLocaleUpperCase('tr')}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-xs font-medium text-foreground-900">{`${p.ad ?? ''} ${p.soyad ?? ''}`.trim() || 'İsimsiz Personel'}</span>
                    {p.gorev && <span className="block truncate text-[11px] text-foreground-500">{p.gorev}</span>}
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      <div className="flex flex-shrink-0 items-center justify-between gap-2 border-t border-background-300/40 px-3 py-2.5 dark:border-background-400/25">
        <span className="text-xs text-foreground-500">{seciliSayi} kişi seçildi</span>
        <div className="flex items-center gap-2">
          <RwButton variant="ghost" size="sm" onClick={onKapat}>Vazgeç</RwButton>
          <RwButton variant="primary" size="sm" icon="ri-add-line" disabled={seciliSayi === 0} onClick={ekle}>Seçilenleri Ekle</RwButton>
        </div>
      </div>
    </div>
  );
}