import { hucreSinifi, riskPuani, riskSeviyesi, SEVIYE_META } from './riskSihirbazTypes';

// ─────────────────────────────────────────────────────────────────────────────
// 5x5 İNTERAKTİF RİSK MATRİSİ (Referans görsel 4)
//
// Statik bir resim DEĞİLDİR. SATIR = Şiddet (5 → 1, solda tanımlarıyla),
// KOLON = Olasılık (1 → 5, altta tanımlarıyla). Her hücre Olasılık × Şiddet
// puanını gösterir. Kullanıcı hücreye tıklayabilir; seçili riskin hücresi
// senkron vurgulanır. Renkler yalnızca merkezi tokenlardan gelir.
// ─────────────────────────────────────────────────────────────────────────────

const SIDDET_SIRA = [5, 4, 3, 2, 1];
const OLASILIK_SIRA = [1, 2, 3, 4, 5];

const SIDDET_AD: Record<number, string> = {
  5: 'Çok Ciddi', 4: 'Ciddi', 3: 'Orta', 2: 'Hafif', 1: 'Çok Hafif',
};

const OLASILIK_AD: Record<number, string> = {
  1: 'Çok Düşük', 2: 'Düşük', 3: 'Orta', 4: 'Yüksek', 5: 'Çok Yüksek',
};

interface RiskMatrisInteractiveProps {
  /** Tüm risklerin (olasilik, siddet) çiftleri — hücrelerde sayaç göstermek için. */
  noktalar?: { olasilik: number; siddet: number }[];
  /** Seçili riskin konumu — hücre vurgulanır. */
  secili?: { olasilik: number; siddet: number } | null;
  /** Hücre seçildiğinde çağrılır (olasilik, siddet). */
  onHucre?: (olasilik: number, siddet: number) => void;
}

export default function RiskMatrisInteractive({ noktalar = [], secili, onHucre }: RiskMatrisInteractiveProps) {
  const sayim = (o: number, s: number) => noktalar.filter((n) => n.olasilik === o && n.siddet === s).length;

  return (
    <div className="w-full select-none" aria-label="5x5 risk matrisi: Olasılık × Şiddet">
      <div className="flex gap-1">
        {/* Dikey eksen etiketi */}
        <div className="flex w-4 items-center justify-center">
          <span
            className="text-xs font-semibold uppercase tracking-wide text-foreground-500"
            style={{ writingMode: 'vertical-rl', transform: 'rotate(180deg)' }}
          >
            Şiddet
          </span>
        </div>

        <div className="min-w-0 flex-1">
          {SIDDET_SIRA.map((siddet) => (
            <div key={siddet} className="mb-1 flex items-center gap-1 last:mb-0">
              <span className="w-3 flex-shrink-0 text-right text-xs font-semibold text-foreground-500">{siddet}</span>
              <span className="w-[50px] flex-shrink-0 text-[0.6875rem] leading-tight text-foreground-400">{SIDDET_AD[siddet]}</span>
              <div className="grid min-w-0 flex-1 grid-cols-5 gap-1">
                {OLASILIK_SIRA.map((olasilik) => {
                  const puan = riskPuani(olasilik, siddet);
                  const adet = sayim(olasilik, siddet);
                  const aktif = secili?.olasilik === olasilik && secili?.siddet === siddet;
                  const seviye = SEVIYE_META[riskSeviyesi(puan)];
                  return (
                    <button
                      key={olasilik}
                      type="button"
                      onClick={() => onHucre?.(olasilik, siddet)}
                      title={`Olasılık ${olasilik} × Şiddet ${siddet} = ${puan} (${seviye.label})`}
                      className={`relative flex aspect-square min-h-[28px] items-center justify-center rounded-[3px] text-xs font-bold text-inverse transition-transform cursor-pointer ${hucreSinifi(puan)} ${
                        aktif ? 'z-10 ring-2 ring-foreground-950 ring-offset-1 ring-offset-background-50' : 'hover:opacity-85'
                      }`}
                    >
                      {puan}
                      {adet > 0 && (
                        <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-foreground-950 px-1 text-[0.6875rem] font-bold text-background-50">
                          {adet}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Alt eksen — Olasılık değerleri + tanımları */}
          <div className="mt-0.5 flex items-center gap-1">
            <span className="w-3 flex-shrink-0" />
            <span className="w-[50px] flex-shrink-0" />
            <div className="grid min-w-0 flex-1 grid-cols-5 gap-1">
              {OLASILIK_SIRA.map((o) => (
                <span key={o} className="text-center text-xs font-semibold text-foreground-500">{o}</span>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-3 flex-shrink-0" />
            <span className="w-[50px] flex-shrink-0" />
            <div className="grid min-w-0 flex-1 grid-cols-5 gap-1">
              {OLASILIK_SIRA.map((o) => (
                <span key={o} className="text-center text-[0.625rem] leading-tight text-foreground-400">{OLASILIK_AD[o]}</span>
              ))}
            </div>
          </div>
          <p className="mt-1 text-center text-xs font-semibold uppercase tracking-wide text-foreground-400">Olasılık</p>
        </div>
      </div>

      {/* Seviye açıklamaları (referans: Risk Seviyesi Açıklamaları) */}
      <div className="mt-3">
        <p className="mb-1.5 text-xs font-semibold text-foreground-700">Risk Seviyesi Açıklamaları</p>
        <ul className="space-y-1.5">
          {(['yuksek', 'orta', 'dusuk'] as const).map((k) => {
            const m = SEVIYE_META[k];
            const aralik = k === 'yuksek' ? '16-25' : k === 'orta' ? '6-15' : '1-5';
            const not = k === 'yuksek' ? 'Acil önlem alınmalı' : k === 'orta' ? 'Planlı tedbir gerekli' : 'Mevcut kontroller yeterli';
            return (
              <li key={k} className="flex items-center gap-2">
                <span className={`h-3 w-3 flex-shrink-0 rounded-sm ${m.dot}`} />
                <span className="text-xs font-semibold text-foreground-700">{m.label} ({aralik})</span>
                <span className="text-xs text-foreground-400">{not}</span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}