// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM EYLEM PLANI SİHİRBAZI — GEÇİCİ ÇALIŞMA ALANI DEPOSU
//
// Diğer sihirbazlarla AYNI mantık: kullanıcı modalı kapatıp tekrar açınca kaldığı
// yerden devam edebilsin diye çalışma YEREL (IndexedDB, ayrı veritabanı adı)
// saklanır. KALICI KAYIT / arşiv DEĞİLDİR; Supabase'e hiçbir veri gönderilmez.
// Kullanıcı "Sıfırla" derse tamamen silinir.
// ─────────────────────────────────────────────────────────────────────────────
import { bosAcilWorkspace, type AcilWorkspace } from './acilDurumTypes';

const DB_NAME = 'isgdenetim-acil-sihirbaz';
const DB_VERSION = 1;
const STORE = 'workspace';
const KAYIT_ID = 'aktif';

function hasIdb(): boolean {
  return typeof indexedDB !== 'undefined';
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function acilWorkspaceYukle(): Promise<AcilWorkspace | null> {
  if (!hasIdb()) return null;
  try {
    const db = await openDb();
    return await new Promise<AcilWorkspace | null>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readonly');
      const req = tx.objectStore(STORE).get(KAYIT_ID);
      req.onsuccess = () => resolve((req.result as AcilWorkspace | undefined) ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

export async function acilWorkspaceKaydet(ws: AcilWorkspace): Promise<void> {
  if (!hasIdb()) return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).put({ ...ws, guncellendi: new Date().toISOString() }, KAYIT_ID);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // yerel kayıt başarısız olsa bile sihirbaz çalışmaya devam eder
  }
}

export async function acilWorkspaceTemizle(): Promise<void> {
  if (!hasIdb()) return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, 'readwrite');
      tx.objectStore(STORE).delete(KAYIT_ID);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // yut
  }
}

export function bosAcilWorkspaceAl(): AcilWorkspace {
  return bosAcilWorkspace();
}