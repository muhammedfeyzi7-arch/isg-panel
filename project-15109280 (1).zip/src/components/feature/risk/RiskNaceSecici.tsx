import NaceSelect, { type NaceSelectValue } from '@/pages/osgb/firmalar/components/NaceSelect';
import { tehlikeSinifiLabel } from '@/lib/firmaService';

// ─────────────────────────────────────────────────────────────────────────────
// RİSK / FINE-KINNEY / HAZOP SİHİRBAZLARI — ORTAK NACE KODU SEÇİCİ
//
// Üç yöntemin de 1. adımında (Temel Bilgiler) kullanılır. Veri YALNIZCA Firma
// ekleme ekranıyla AYNI kaynaktan (`nace_kodlari` tablosu, `firmaService`)
// gelir — kod içine uydurma NACE değeri YAZILMAZ.
//
// Seçim yapıldığında ilgili alanlar TEK çağrıda güncellenir:
//   naceId        → seçili NACE kaydının id'si (yeniden yüklenince seçim korunur)
//   nace          → "KOD — Faaliyet tanımı" (raporlarda bu metin görünür)
//   tehlikeSinifi → NACE kaydından çözümlenen tehlike sınıfı ("Az Tehlikeli" vb.)
// Böylece seçilen NACE hem rapora hem de AI öneri bağlamına otomatik yansır.
// ─────────────────────────────────────────────────────────────────────────────

export interface RiskNaceSecim {
  naceId: string;
  nace: string;
  /** NACE kaydından çözümlenen tehlike sınıfı etiketi. Boşsa (seçim temizlendi) boş string. */
  tehlikeSinifi: string;
}

interface Props {
  naceId?: string;
  required?: boolean;
  error?: string;
  onChange: (secim: RiskNaceSecim) => void;
}

export default function RiskNaceSecici({ naceId, required, error, onChange }: Props) {
  const handle = (v: NaceSelectValue | null) => {
    if (!v) {
      onChange({ naceId: '', nace: '', tehlikeSinifi: '' });
      return;
    }
    onChange({
      naceId: v.id,
      nace: `${v.kod} — ${v.faaliyetTanimi}`,
      tehlikeSinifi: tehlikeSinifiLabel(v.tehlikeSinifi),
    });
  };

  return (
    <NaceSelect
      label="NACE Kodu / Faaliyet"
      required={required}
      error={error}
      value={naceId && naceId.trim() ? naceId : null}
      onChange={handle}
    />
  );
}