import { useCallback, useEffect, useState } from 'react';
import Alert from '@/components/ui/Alert';
import { useToastActions } from '@/hooks/useToast';
import { aiAcilOnerileri } from '@/lib/riskAiService';
import { pdfIndir } from '@/lib/acilDurumRapor';
import AcilAdim1Temel from '@/components/feature/risk/acil/adimlar/AcilAdim1Temel';
import AcilAdim2Ekipler from '@/components/feature/risk/acil/adimlar/AcilAdim2Ekipler';
import AcilAdim3Kroki from '@/components/feature/risk/acil/adimlar/AcilAdim3Kroki';
import AcilAdim4Rapor from '@/components/feature/risk/acil/adimlar/AcilAdim4Rapor';
import type { SecilenPersonel } from '@/components/feature/risk/acil/AcilPersonelSecModal';
import { acilWorkspaceKaydet, acilWorkspaceTemizle, acilWorkspaceYukle } from '@/components/feature/risk/acilWorkspaceStore';
import { naceProfilCoz } from '@/lib/acilDurumRapor/naceProfilleri';
import { RwButton, RwStepper } from '@/components/feature/risk/sihirbaz/wizardUi';
import {
  EKIP_ROLLERI, KAPSAM_MADDELERI, ZORUNLU_EKIPLER, bosAcilWorkspace, bosEkipUyesi, bosIletisim, bosMalzeme, bosSenaryo, bosTatbikat, destekElemaniHesabi, ornekSenaryolar, sablondanSenaryo, yeniId,
  type AcilAiOneri, type AcilIletisim, type AcilMalzeme, type AcilSenaryo, type AcilTemelBilgiler, type AcilWorkspace, type EkipUyesi, type SenaryoSablon, type Tatbikat,
} from '@/components/feature/risk/acilDurumTypes';

// ─────────────────────────────────────────────────────────────────────────────
// ACİL DURUM EYLEM PLANI SİHİRBAZI — KABUK
//
// 4 adım tek merkezi modal içinde yönetilir (Temel Bilgiler ve Kapsam → Ekipler ve
// Senaryolar → Tahliye ve Kroki → Rapor ve Önizleme). Tüm adımlar aynı workspace'i
// paylaşır. Workspace yerel (IndexedDB) saklanır — KALICI KAYIT YOKTUR; yalnızca
// Word/PDF/Excel/CSV/TXT indirilir. Acil durum ekibi elle VEYA sistem personelinden
// seçilebilir (yalnızca okuma; personel kaydına yazılmaz).
// ─────────────────────────────────────────────────────────────────────────────

interface Props {
  onClose: () => void;
}

const ADIM_BASLIKLARI = ['Temel Bilgiler', 'Ekipler & Senaryolar', 'Kroki', 'Rapor'];

export default function AcilSihirbazContent({ onClose }: Props) {
  const { addToast } = useToastActions();
  const [ws, setWs] = useState<AcilWorkspace>(() => bosAcilWorkspace());
  const [adim, setAdim] = useState(0);
  const [hazir, setHazir] = useState(false);
  const [sifirlaOnay, setSifirlaOnay] = useState(false);
  const [aiYukleniyor, setAiYukleniyor] = useState(false);
  const [indiriliyor, setIndiriliyor] = useState(false);

  useEffect(() => {
    let iptal = false;
    void acilWorkspaceYukle().then((kayit) => {
      if (iptal) return;
      if (kayit && Array.isArray(kayit.senaryolar)) {
        const temel = { ...bosAcilWorkspace().temel, ...(kayit.temel || {}) };
        setWs({
          ...bosAcilWorkspace(),
          ...kayit,
          temel: {
            ...temel,
            ekip: Array.isArray(temel.ekip) ? temel.ekip : [],
            dokumanlar: Array.isArray(temel.dokumanlar) ? temel.dokumanlar : [],
            imzacilar: Array.isArray(temel.imzacilar) ? temel.imzacilar : [],
          },
          kapsam: Array.isArray(kayit.kapsam) ? kayit.kapsam : [...KAPSAM_MADDELERI],
          ekipler: Array.isArray(kayit.ekipler) ? kayit.ekipler : [],
          senaryolar: Array.isArray(kayit.senaryolar) ? kayit.senaryolar : [],
          iletisim: Array.isArray(kayit.iletisim) ? kayit.iletisim : bosAcilWorkspace().iletisim,
          malzemeler: Array.isArray(kayit.malzemeler) ? kayit.malzemeler : bosAcilWorkspace().malzemeler,
          tatbikatlar: Array.isArray(kayit.tatbikatlar) ? kayit.tatbikatlar : [],
          aiOnerileri: Array.isArray(kayit.aiOnerileri) ? kayit.aiOnerileri : [],
        });
        setAdim(Math.max(0, Math.min(3, kayit.aktifAdim ?? 0)));
      } else {
        setWs({ ...bosAcilWorkspace(), senaryolar: ornekSenaryolar() });
      }
      setHazir(true);
    });
    return () => { iptal = true; };
  }, []);

  useEffect(() => {
    if (!hazir) return;
    const t = setTimeout(() => { void acilWorkspaceKaydet({ ...ws, aktifAdim: adim }); }, 500);
    return () => clearTimeout(t);
  }, [ws, adim, hazir]);

  // ── Temel ──
  const temelGuncelle = useCallback((patch: Partial<AcilTemelBilgiler>) => {
    setWs((p) => ({ ...p, temel: { ...p.temel, ...patch } }));
  }, []);
  const kapsamGuncelle = useCallback((kapsam: string[]) => {
    setWs((p) => ({ ...p, kapsam }));
  }, []);

  // ── Ekipler ──
  const ekipEkle = useCallback(() => {
    setWs((p) => ({ ...p, ekipler: [...p.ekipler, bosEkipUyesi()] }));
  }, []);
  const ekipGuncelle = useCallback((id: string, patch: Partial<EkipUyesi>) => {
    setWs((p) => ({ ...p, ekipler: p.ekipler.map((e) => (e.id === id ? { ...e, ...patch } : e)) }));
  }, []);
  const ekipSil = useCallback((id: string) => {
    setWs((p) => ({ ...p, ekipler: p.ekipler.filter((e) => e.id !== id) }));
  }, []);
  const personeldenEkle = useCallback((secilenler: SecilenPersonel[]) => {
    const yeni: EkipUyesi[] = secilenler.map((s) => ({
      id: yeniId('ek'),
      adSoyad: s.adSoyad,
      gorev: s.gorev,
      ekipRolu: EKIP_ROLLERI[1],
      telefon: '',
      belge: '',
      kaynak: 'sistem',
      personelId: s.personelId,
    }));
    setWs((p) => ({ ...p, ekipler: [...p.ekipler, ...yeni] }));
    addToast({ title: 'Personel eklendi', message: `${yeni.length} kişi acil durum ekibine eklendi.`, type: 'success' });
  }, [addToast]);

  // ── Senaryolar ──
  const senaryoEkle = useCallback(() => {
    setWs((p) => ({ ...p, senaryolar: [...p.senaryolar, bosSenaryo()] }));
  }, []);
  const senaryoGuncelle = useCallback((id: string, patch: Partial<AcilSenaryo>) => {
    setWs((p) => ({ ...p, senaryolar: p.senaryolar.map((s) => (s.id === id ? { ...s, ...patch } : s)) }));
  }, []);
  const senaryoSil = useCallback((id: string) => {
    setWs((p) => ({ ...p, senaryolar: p.senaryolar.filter((s) => s.id !== id) }));
  }, []);
  const sablondanEkle = useCallback((s: SenaryoSablon) => {
    const yeni = sablondanSenaryo(s);
    setWs((p) => ({ ...p, senaryolar: [...p.senaryolar, yeni] }));
    addToast({ title: 'Şablondan eklendi', message: s.olay, type: 'success' });
  }, [addToast]);

  const ekipRolEkle = useCallback((rol: string) => {
    setWs((p) => ({ ...p, ekipler: [...p.ekipler, bosEkipUyesi(rol)] }));
  }, []);
  // ── NACE Profilini Uygula ──
  // Seçilen NACE kodunun faaliyet bölümüne göre senaryo, kapsam ve malzeme
  // içeriğini otomatik doldurur (mevcut kayıtları KORUYARAK, tekrar etmeden ekler).
  const naceProfilUygula = useCallback(() => {
    const bolum = naceProfilCoz(ws.temel.nace || '').bolum;
    if (!bolum) {
      addToast({ title: 'NACE kodu gerekli', message: 'Önce künye bölümünden bir NACE kodu / faaliyet seçin.', type: 'warning' });
      return;
    }
    let ekSenaryo = 0; let ekKapsam = 0; let ekMalzeme = 0;
    setWs((p) => {
      const kucuk = (s: string) => (s || '').trim().toLocaleLowerCase('tr');
      const mevcutOlay = new Set(p.senaryolar.map((s) => kucuk(s.olay)));
      const yeniSenaryolar = bolum.senaryolar
        .filter((s) => !mevcutOlay.has(kucuk(s.olay)))
        .map((s) => sablondanSenaryo(s));
      const kapsam = Array.from(new Set([...p.kapsam, ...bolum.kapsamEkleri]));
      const mevcutMal = new Set(p.malzemeler.map((m) => kucuk(m.ad)));
      const ekMalzemeler = bolum.malzemeler
        .filter((m) => !mevcutMal.has(kucuk(m.ad)))
        .map((m) => ({ id: yeniId('mz'), ad: m.ad, adet: 0, konum: m.konum, sonKontrol: '' }));
      ekSenaryo = yeniSenaryolar.length;
      ekKapsam = kapsam.length - p.kapsam.length;
      ekMalzeme = ekMalzemeler.length;
      return { ...p, senaryolar: [...p.senaryolar, ...yeniSenaryolar], kapsam, malzemeler: [...p.malzemeler, ...ekMalzemeler] };
    });
    addToast({
      title: 'NACE profili uygulandı',
      message: `${bolum.ad}: ${ekSenaryo} senaryo, ${ekKapsam} kapsam maddesi, ${ekMalzeme} malzeme eklendi.`,
      type: 'success',
    });
  }, [ws.temel.nace, addToast]);

  const zorunluEkipleriEkle = useCallback(() => {
    setWs((p) => {
      const mevcut = new Set(p.ekipler.map((e) => e.ekipRolu));
      const eksikler = ZORUNLU_EKIPLER.filter((r) => !mevcut.has(r));
      if (eksikler.length === 0) return p;
      return { ...p, ekipler: [...p.ekipler, ...eksikler.map((r) => bosEkipUyesi(r))] };
    });
    addToast({ title: 'Zorunlu ekipler eklendi', message: 'Eksik ekipler için üye satırları oluşturuldu; ad soyad bilgilerini doldurun.', type: 'success' });
  }, [addToast]);

  // ── Acil İletişim ──
  const iletisimEkle = useCallback(() => setWs((p) => ({ ...p, iletisim: [...p.iletisim, bosIletisim()] })), []);
  const iletisimGuncelle = useCallback((id: string, patch: Partial<AcilIletisim>) => {
    setWs((p) => ({ ...p, iletisim: p.iletisim.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));
  }, []);
  const iletisimSil = useCallback((id: string) => setWs((p) => ({ ...p, iletisim: p.iletisim.filter((x) => x.id !== id) })), []);

  // ── Malzeme Envanteri ──
  const malzemeEkle = useCallback(() => setWs((p) => ({ ...p, malzemeler: [...p.malzemeler, bosMalzeme()] })), []);
  const malzemeGuncelle = useCallback((id: string, patch: Partial<AcilMalzeme>) => {
    setWs((p) => ({ ...p, malzemeler: p.malzemeler.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));
  }, []);
  const malzemeSil = useCallback((id: string) => setWs((p) => ({ ...p, malzemeler: p.malzemeler.filter((x) => x.id !== id) })), []);

  // ── Tatbikat Planı ──
  const tatbikatEkle = useCallback(() => setWs((p) => ({ ...p, tatbikatlar: [...p.tatbikatlar, bosTatbikat()] })), []);
  const tatbikatGuncelle = useCallback((id: string, patch: Partial<Tatbikat>) => {
    setWs((p) => ({ ...p, tatbikatlar: p.tatbikatlar.map((x) => (x.id === id ? { ...x, ...patch } : x)) }));
  }, []);
  const tatbikatSil = useCallback((id: string) => setWs((p) => ({ ...p, tatbikatlar: p.tatbikatlar.filter((x) => x.id !== id) })), []);

  // ── AI ──
  const aiYenile = useCallback(async () => {
    if (aiYukleniyor) return;
    setAiYukleniyor(true);
    try {
      const cevap = await aiAcilOnerileri({
        firma: ws.temel.firma,
        tesis: ws.temel.tesis,
        nace: ws.temel.nace,
        tehlikeSinifi: ws.temel.tehlikeSinifi,
        planYili: ws.temel.planYili,
        kapsam: ws.kapsam,
        mevcutSenaryolar: ws.senaryolar.map((s) => s.olay).filter(Boolean),
        oncekiOneriler: ws.aiOnerileri.map((o) => o.olay),
      });
      if (cevap.ok && cevap.oneriler) {
        const yeni: AcilAiOneri[] = cevap.oneriler.map((o) => ({ id: yeniId('ao'), ...o }));
        setWs((p) => ({ ...p, aiOnerileri: [...yeni, ...p.aiOnerileri] }));
        addToast({ title: 'AI önerileri hazır', message: `${yeni.length} yeni senaryo önerildi.`, type: 'success' });
      } else {
        addToast({ title: 'AI önerisi alınamadı', message: cevap.message || 'Lütfen tekrar deneyin.', type: 'warning' });
      }
    } catch {
      addToast({ title: 'AI bağlantı hatası', message: 'Lütfen tekrar deneyin.', type: 'error' });
    } finally {
      setAiYukleniyor(false);
    }
  }, [aiYukleniyor, ws, addToast]);

  const oneriEkle = useCallback((o: AcilAiOneri) => {
    const sn: AcilSenaryo = {
      id: yeniId('sn'),
      kategori: o.kategori,
      olay: o.olay,
      aciklama: o.aciklama,
      derece: o.derece,
      etkilenen: o.etkilenen,
      mudahale: o.mudahale,
      sorumluEkip: o.sorumluEkip,
      tahliyeGerekli: o.tahliyeGerekli,
    };
    setWs((p) => ({ ...p, senaryolar: [...p.senaryolar, sn], aiOnerileri: p.aiOnerileri.filter((x) => x.id !== o.id) }));
    addToast({ title: 'Senaryoya eklendi', message: o.olay, type: 'success' });
  }, [addToast]);

  // ── Kroki ──
  const krokiDegistir = useCallback((dataUrl: string, veri: string) => {
    setWs((p) => ({ ...p, kroki: dataUrl, krokiVeri: veri }));
  }, []);
  const krokiNotDegistir = useCallback((v: string) => {
    setWs((p) => ({ ...p, krokiNot: v }));
  }, []);

  // ── Adım doğrulama ──
  const adimGecerli = useCallback((idx: number): string | null => {
    if (idx === 0) {
      if (!ws.temel.calismaAdi.trim()) return 'Plan Adı zorunludur.';
      if (!ws.temel.tesis.trim()) return 'Tesis / İş Yeri zorunludur.';
    }
    if (idx === 1) {
      if (ws.senaryolar.length === 0) return 'Devam etmek için en az bir acil durum senaryosu ekleyin.';
      if (ws.senaryolar.some((s) => !s.olay.trim())) return 'Tüm senaryoların olay adı doldurulmalıdır.';
      if (ws.ekipler.some((e) => !e.adSoyad.trim())) return 'Tüm ekip üyelerinin ad soyad bilgisi doldurulmalıdır.';
    }
    return null;
  }, [ws.temel, ws.senaryolar, ws.ekipler]);

  const sonraki = useCallback(() => {
    const hata = adimGecerli(adim);
    if (hata) { addToast({ title: 'Eksik bilgi', message: hata, type: 'warning' }); return; }
    setAdim((a) => Math.min(3, a + 1));
  }, [adim, adimGecerli, addToast]);

  const sifirla = useCallback(async () => {
    await acilWorkspaceTemizle();
    setWs(bosAcilWorkspace());
    setAdim(0);
    setSifirlaOnay(false);
    addToast({ title: 'Çalışma sıfırlandı', message: 'Yeni bir acil durum eylem planına başlayabilirsiniz.', type: 'success' });
  }, [addToast]);

  const hizliPdf = useCallback(async () => {
    if (ws.senaryolar.length === 0) {
      addToast({ title: 'Senaryo listesi boş', message: 'Rapor için en az bir senaryo gerekir.', type: 'warning' });
      return;
    }
    if (indiriliyor) return;
    setIndiriliyor(true);
    try {
      await pdfIndir({ temel: ws.temel, kapsam: ws.kapsam, ekipler: ws.ekipler, senaryolar: ws.senaryolar, iletisim: ws.iletisim, malzemeler: ws.malzemeler, tatbikatlar: ws.tatbikatlar, kroki: ws.kroki, krokiNot: ws.krokiNot });
      addToast({ title: 'Plan hazır', message: 'PDF indirme başlatıldı.', type: 'success' });
    } catch {
      addToast({ title: 'Plan oluşturulamadı', message: 'Beklenmeyen bir hata oluştu.', type: 'error' });
    } finally {
      setIndiriliyor(false);
    }
  }, [ws, addToast, indiriliyor]);

  if (!hazir) {
    return (
      <div className="flex min-h-0 flex-1 items-center justify-center">
        <span className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary-500 border-t-transparent" />
      </div>
    );
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="flex-shrink-0 border-b border-background-300/25 dark:border-background-400/35">
        <RwStepper steps={ADIM_BASLIKLARI} current={adim} onStepClick={(idx) => { if (idx < adim) setAdim(idx); }} />
      </div>

      <div className="flex min-h-0 flex-1 overflow-hidden px-5 py-4">
        {adim === 0 && (
          <AcilAdim1Temel temel={ws.temel} kapsam={ws.kapsam} onChange={temelGuncelle} onKapsamChange={kapsamGuncelle} onNaceProfilUygula={naceProfilUygula} />
        )}
        {adim === 1 && (
          <AcilAdim2Ekipler
            ekipler={ws.ekipler}
            senaryolar={ws.senaryolar}
            iletisim={ws.iletisim}
            malzemeler={ws.malzemeler}
            tatbikatlar={ws.tatbikatlar}
            aiOnerileri={ws.aiOnerileri}
            aiYukleniyor={aiYukleniyor}
            destek={destekElemaniHesabi(ws.temel.tehlikeSinifi, ws.temel.calisanSayisi)}
            onEkipEkle={ekipEkle}
            onEkipGuncelle={ekipGuncelle}
            onEkipSil={ekipSil}
            onPersoneldenEkle={personeldenEkle}
            onZorunluEkipleriEkle={zorunluEkipleriEkle}
            onEkipRolEkle={ekipRolEkle}
            onSenaryoEkle={senaryoEkle}
            onSenaryoGuncelle={senaryoGuncelle}
            onSenaryoSil={senaryoSil}
            onAiYenile={() => void aiYenile()}
            onOneriEkle={oneriEkle}
            onSablondanEkle={sablondanEkle}
            onIletisimEkle={iletisimEkle}
            onIletisimGuncelle={iletisimGuncelle}
            onIletisimSil={iletisimSil}
            onMalzemeEkle={malzemeEkle}
            onMalzemeGuncelle={malzemeGuncelle}
            onMalzemeSil={malzemeSil}
            onTatbikatEkle={tatbikatEkle}
            onTatbikatGuncelle={tatbikatGuncelle}
            onTatbikatSil={tatbikatSil}
          />
        )}
        {adim === 2 && (
          <AcilAdim3Kroki
            temel={ws.temel}
            senaryolar={ws.senaryolar}
            kroki={ws.kroki}
            krokiVeri={ws.krokiVeri}
            krokiNot={ws.krokiNot}
            onTemelChange={temelGuncelle}
            onKrokiChange={krokiDegistir}
            onKrokiNotChange={krokiNotDegistir}
          />
        )}
        {adim === 3 && (
          <AcilAdim4Rapor
            temel={ws.temel}
            kapsam={ws.kapsam}
            ekipler={ws.ekipler}
            senaryolar={ws.senaryolar}
            iletisim={ws.iletisim}
            malzemeler={ws.malzemeler}
            tatbikatlar={ws.tatbikatlar}
            kroki={ws.kroki}
            krokiNot={ws.krokiNot}
            onTemelChange={temelGuncelle}
          />
        )}
      </div>

      <div className="flex flex-shrink-0 items-center justify-between gap-2 border-t isg-divider px-5 py-3">
        <div className="flex items-center gap-2">
          <RwButton variant="ghost" icon="ri-close-line" onClick={onClose}>İptal</RwButton>
          {sifirlaOnay ? (
            <Alert
              variant="danger"
              action={(
                <div className="flex items-center gap-2">
                  <RwButton variant="primary" size="sm" icon="ri-refresh-line" onClick={() => void sifirla()}>Evet, Sıfırla</RwButton>
                  <RwButton variant="ghost" size="sm" onClick={() => setSifirlaOnay(false)}>Vazgeç</RwButton>
                </div>
              )}
            >
              Tüm plan silinsin mi?
            </Alert>
          ) : (
            <RwButton variant="ghost" icon="ri-refresh-line" onClick={() => setSifirlaOnay(true)}>Sıfırla</RwButton>
          )}
        </div>
        <div className="flex items-center gap-2">
          <span className="hidden text-xs text-foreground-400 sm:inline">
            <i className="ri-information-line mr-1" /> Bu çalışma geçici olarak tutulur; kalıcı kayıt oluşturmaz.
          </span>
          {adim > 0 && (
            <RwButton variant="secondary" icon="ri-arrow-left-line" onClick={() => setAdim((a) => Math.max(0, a - 1))}>Önceki Adım</RwButton>
          )}
          {adim < 3
            ? <RwButton variant="primary" iconAfter="ri-arrow-right-line" onClick={sonraki}>Sonraki Adım</RwButton>
            : <RwButton variant="primary" icon="ri-file-download-line" onClick={() => void hizliPdf()}>{indiriliyor ? 'Oluşturuluyor...' : 'Planı Oluştur ve İndir'}</RwButton>}
        </div>
      </div>
    </div>
  );
}