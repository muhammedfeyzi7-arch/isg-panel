import { useEffect, useState } from 'react';
import { useModalActions } from '@/hooks/useModal';
import RiskModulSecim, { type RiskModulKey } from './RiskModulSecim';
import RiskSihirbazContent from './RiskSihirbazContent';
import FkSihirbazContent from './FkSihirbazContent';
import RiskYontemSecim, { type YontemKey } from './RiskYontemSecim';
import HzSihirbazContent from './HzSihirbazContent';
import CalismaSihirbazContent from './CalismaSihirbazContent';
import EgitimSihirbazContent from './EgitimSihirbazContent';
import AcilSihirbazContent from './AcilSihirbazContent';
import { AcilHeaderIcon, CalismaHeaderIcon, EgitimHeaderIcon, RiskHeaderIcon, SihirbazHeaderIcon, SihirbazYardimButton } from './RiskSihirbazHeader';

// ─────────────────────────────────────────────────────────────────────────────
// İSGDenetim Sihirbazı — ÜÇ ekranı TEK merkezi modal içinde yöneten orkestratör.
//
// Akış: modül seçimi → Risk Değerlendirme Yöntemi (referans UI) → 5 adımlı risk
// sihirbazı + rapor. Ekran değişince YENİ modal açılmaz; aynı modalın başlığı
// `updateModal` ile güncellenir (tek modal standardı).
//
// Yöntem seçim ekranı; seçilen yönteme göre (5x5, Fine-Kinney, HAZOP) ilgili
// sihirbaz akışı açılır. Ekran görünümü korunur.
// ─────────────────────────────────────────────────────────────────────────────

interface RiskSihirbazModalProps {
  modalIdRef: { current: string };
  onClose: () => void;
}

type SihirbazEkran = 'modul' | 'yontem' | 'sihirbaz' | 'fk' | 'hazop' | 'calisma' | 'egitim' | 'acil';

export default function RiskSihirbazModal({ modalIdRef, onClose }: RiskSihirbazModalProps) {
  const { updateModal } = useModalActions();
  const [ekran, setEkran] = useState<SihirbazEkran>('modul');

  useEffect(() => {
    const id = modalIdRef.current;
    if (!id) return;
    if (ekran === 'sihirbaz') {
      updateModal(id, {
        title: 'Risk Değerlendirmesi',
        description: 'Riskleri belirleyin, değerlendirin ve gerekli kontrol tedbirlerini planlayın.',
        headerIcon: <RiskHeaderIcon />,
        headerExtra: undefined,
      });
    } else if (ekran === 'fk') {
      updateModal(id, {
        title: 'Fine-Kinney Risk Değerlendirmesi',
        description: 'Risk değerlendirmesini hazırlamak için temel bilgileri girin.',
        headerIcon: <RiskHeaderIcon />,
        headerExtra: undefined,
      });
    } else if (ekran === 'hazop') {
      updateModal(id, {
        title: 'HAZOP Çalışması',
        description: 'Proses ve sistemler için HAZOP analizini adım adım oluşturun. Bu çalışma kaydedilmeyecektir.',
        headerIcon: <RiskHeaderIcon />,
        headerExtra: undefined,
      });
    } else if (ekran === 'calisma') {
      updateModal(id, {
        title: 'Yıllık Çalışma Planı',
        description: 'Bir sonraki yılın İSG faaliyetlerini planlayın. Bu çalışma kaydedilmez; yalnızca rapor üretir.',
        headerIcon: <CalismaHeaderIcon />,
        headerExtra: undefined,
      });
    } else if (ekran === 'egitim') {
      updateModal(id, {
        title: 'Yıllık Eğitim Planı',
        description: 'Bir sonraki yılın İSG eğitimlerini planlayın. Bu çalışma kaydedilmez; yalnızca rapor üretir.',
        headerIcon: <EgitimHeaderIcon />,
        headerExtra: undefined,
      });
    } else if (ekran === 'acil') {
      updateModal(id, {
        title: 'Acil Durum Eylem Planı',
        description: 'Acil durum ekiplerini, senaryoları ve tahliye krokinizi hazırlayın. Bu çalışma kaydedilmez; yalnızca rapor üretir.',
        headerIcon: <AcilHeaderIcon />,
        headerExtra: undefined,
      });
    } else if (ekran === 'yontem') {
      updateModal(id, {
        title: 'Risk Değerlendirmesi',
        description: 'İşyeriniz için uygun yöntemi seçerek risk değerlendirmesine başlayın.',
        headerIcon: <RiskHeaderIcon />,
        headerExtra: undefined,
      });
    } else {
      updateModal(id, {
        title: 'İSGDenetim Sihirbazı',
        description: 'İhtiyacınız olan dokümanı kolayca oluşturun. Aşağıdaki modüllerden birini seçerek başlayın.',
        headerIcon: <SihirbazHeaderIcon />,
        headerExtra: <SihirbazYardimButton />,
      });
    }
  }, [ekran, modalIdRef, updateModal]);

  const modulSec = (modul: RiskModulKey) => {
    if (modul === 'calisma') { setEkran('calisma'); return; }
    if (modul === 'egitim') { setEkran('egitim'); return; }
    if (modul === 'acil') { setEkran('acil'); return; }
    setEkran('yontem');
  };

  const yontemDevam = (yontem: YontemKey) => {
    if (yontem === 'fine-kinney') {
      setEkran('fk');
      return;
    }
    if (yontem === 'hazop') {
      setEkran('hazop');
      return;
    }
    setEkran('sihirbaz');
  };

  if (ekran === 'sihirbaz') {
    return <RiskSihirbazContent onClose={onClose} />;
  }

  if (ekran === 'fk') {
    return <FkSihirbazContent onClose={onClose} />;
  }

  if (ekran === 'calisma') {
    return <CalismaSihirbazContent onClose={onClose} />;
  }

  if (ekran === 'egitim') {
    return <EgitimSihirbazContent onClose={onClose} />;
  }

  if (ekran === 'acil') {
    return <AcilSihirbazContent onClose={onClose} />;
  }

  if (ekran === 'hazop') {
    return <HzSihirbazContent onClose={onClose} />;
  }

  if (ekran === 'yontem') {
    return <RiskYontemSecim onDevam={yontemDevam} onClose={onClose} />;
  }

  return (
    <div
      className="flex min-h-0 flex-1 flex-col"
      style={{
        marginLeft: 'calc(var(--d-modal-body-px) * -1)',
        marginRight: 'calc(var(--d-modal-body-px) * -1)',
        marginBottom: 'calc(var(--d-modal-body-py) * -1)',
      }}
    >
      <div className="isg-scroll-pane flex min-h-0 flex-1 flex-col overflow-y-auto overflow-x-hidden px-[var(--d-modal-body-px)] py-[var(--d-modal-body-py)]">
        <div className="my-auto w-full">
          <RiskModulSecim onSelect={modulSec} />
        </div>
      </div>

      <div className="flex flex-shrink-0 items-center justify-start gap-2 border-t border-background-300/25 px-[var(--d-modal-body-px)] py-3 dark:border-background-400/35">
        <button type="button" onClick={onClose} className="isg-btn isg-btn-ghost whitespace-nowrap cursor-pointer">
          <i className="ri-close-line" /> İptal
        </button>
      </div>
    </div>
  );
}