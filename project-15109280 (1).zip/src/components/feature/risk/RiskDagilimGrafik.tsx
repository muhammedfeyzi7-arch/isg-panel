// ─────────────────────────────────────────────────────────────────────────────
// RİSK DAĞILIM GRAFİĞİ
//
// 4. adımdaki donut grafik. Gerçek risk listesinden hesaplanan sayıları gösterir;
// demo veri KULLANMAZ. Renkler merkezi tema tokenlarından (oklch(var(--...))).
// ─────────────────────────────────────────────────────────────────────────────

interface RiskDagilimGrafikProps {
  yuksek: number;
  orta: number;
  dusuk: number;
  toplam: number;
}

export default function RiskDagilimGrafik({ yuksek, orta, dusuk, toplam }: RiskDagilimGrafikProps) {
  const safeToplam = Math.max(1, toplam);
  const yuksekPct = Math.round((yuksek / safeToplam) * 100);
  const ortaPct = Math.round((orta / safeToplam) * 100);
  const dusukPct = Math.max(0, 100 - yuksekPct - ortaPct);

  const birinci = yuksekPct;
  const ikinci = yuksekPct + ortaPct;

  const donut =
    toplam === 0
      ? 'oklch(var(--background-300))'
      : `conic-gradient(
          oklch(var(--danger-500)) 0% ${birinci}%,
          oklch(var(--warning-500)) ${birinci}% ${ikinci}%,
          oklch(var(--success-500)) ${ikinci}% 100%
        )`;

  const satirlar = [
    { label: 'Yüksek', adet: yuksek, pct: yuksekPct, dot: 'bg-danger-500' },
    { label: 'Orta', adet: orta, pct: ortaPct, dot: 'bg-warning-500' },
    { label: 'Düşük', adet: dusuk, pct: dusukPct, dot: 'bg-success-500' },
  ];

  return (
    <div className="flex items-center gap-4">
      <div className="relative h-28 w-28 flex-shrink-0">
        <div className="h-full w-full rounded-full" style={{ background: donut }} />
        <div className="absolute inset-[22%] flex flex-col items-center justify-center rounded-full bg-background-50 dark:bg-background-200">
          <span className="text-lg font-bold leading-none text-foreground-950">{toplam}</span>
          <span className="text-xs text-foreground-500">Toplam Risk</span>
        </div>
      </div>

      <ul className="min-w-0 flex-1 space-y-2">
        {satirlar.map((s) => (
          <li key={s.label} className="flex items-center gap-2">
            <span className={`h-2.5 w-2.5 flex-shrink-0 rounded-full ${s.dot}`} />
            <span className="flex-1 text-xs font-medium text-foreground-700">{s.label}</span>
            <span className="text-xs font-semibold text-foreground-900">{s.adet}</span>
            <span className="w-10 text-right text-xs text-foreground-400">%{s.pct}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}