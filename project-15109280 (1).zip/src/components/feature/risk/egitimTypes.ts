// ─────────────────────────────────────────────────────────────────────────────
// YILLIK EĞİTİM PLANI — ORTAK VERİ MODELİ
//
// 5x5 / Fine-Kinney / HAZOP / Yıllık Çalışma Planı ile AYNI sihirbaz mimarisini
// kullanır. Yöntem "eğitim odaklıdır": İSG profesyonellerinin bir sonraki yıl
// için planladığı İSG eğitimleri (işe giriş, yenileme, işe özel, ilk yardım,
// yangın, KKD vb.) aylık matrise yerleştirilir.
//
// HUKUKİ DAYANAK:
//  - 6331 sayılı İş Sağlığı ve Güvenliği Kanunu (m.17 — eğitim yükümlülüğü)
//  - Çalışanların İş Sağlığı ve Güvenliği Eğitimlerinin Usul ve Esasları Hakkında
//    Yönetmelik (Ek-1): tehlike sınıfına göre ASGARİ temel eğitim süreleri
//      · Az Tehlikeli    → en az 8 saat   (yenileme: 3 yılda bir)
//      · Tehlikeli       → en az 12 saat  (yenileme: 2 yılda bir)
//      · Çok Tehlikeli   → en az 16 saat  (yenileme: yılda bir)
//    (Yenileme eğitimlerinin süresi tüm sınıflarda asgari 8 saat olarak düzenlenir.)
//
// ÖNEMLİ: Kalıcı kayıt/arşiv YOKTUR. Çalışma yalnızca yerel (IndexedDB) tutulur
// ve kullanıcı yalnızca Word / PDF / Excel (ve CSV/TXT) indirir. Sisteme veri gitmez.
// ─────────────────────────────────────────────────────────────────────────────
import {
  type TemelBilgiler,
  type Imzaci,
  yeniId,
  benzerMi,
  normalize,
} from './riskSihirbazTypes';

export { yeniId, benzerMi, normalize };
export type { Imzaci, TemelBilgiler };

export const EGITIM_METODU =
  'Yıllık İSG Eğitim Planı (6331 s. Kanun · Çalışanların İSG Eğitimleri Yönetmeliği)';

// ── Ay adları ────────────────────────────────────────────────────────────────
export const AY_ADLARI: string[] = [
  'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
  'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık',
];

export const AY_KISA: string[] = [
  'Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara',
];

// ── Mevzuata göre ASGARİ eğitim süreleri (saat) ──────────────────────────────
export const ASGARI_SURELER: Record<string, number> = {
  'Az Tehlikeli': 8,
  'Tehlikeli': 12,
  'Çok Tehlikeli': 16,
};

export function asgariSaat(tehlikeSinifi: string): number {
  return ASGARI_SURELER[tehlikeSinifi] ?? 8;
}

export function yenilemePeriyodu(tehlikeSinifi: string): string {
  if (tehlikeSinifi === 'Az Tehlikeli') return '3 yılda bir';
  if (tehlikeSinifi === 'Tehlikeli') return '2 yılda bir';
  if (tehlikeSinifi === 'Çok Tehlikeli') return 'yılda bir';
  return '—';
}

// ── Eğitim kategorileri ──────────────────────────────────────────────────────
export const EGITIM_KATEGORILERI: string[] = [
  'Genel İSG Konuları',
  'Sağlık Konuları',
  'Teknik Konular',
  'Yangın ve Acil Durum',
  'Kimyasal Güvenlik',
  'Elektrik Güvenliği',
  'Yüksekte Çalışma',
  'Makine ve Ekipman Güvenliği',
  'Ergonomi ve Elle Taşıma',
  'Kişisel Koruyucu Donanım',
  'İlk Yardım',
  'Çevre ve Atık',
  'Sektörel / İşe Özel',
  'Yasal ve İdari',
];

export function kategoriIkon(kategori: string): string {
  const t = (kategori || '').toLocaleLowerCase('tr');
  if (t.includes('genel') || t.includes('yasal') || t.includes('idari')) return 'ri-list-check-2';
  if (t.includes('sağlık') || t.includes('saglik')) return 'ri-heart-pulse-line';
  if (t.includes('teknik')) return 'ri-tools-line';
  if (t.includes('yangın') || t.includes('yangin') || t.includes('acil')) return 'ri-fire-line';
  if (t.includes('kimyasal')) return 'ri-flask-line';
  if (t.includes('elektrik')) return 'ri-flashlight-line';
  if (t.includes('yüksekte') || t.includes('yuksekte')) return 'ri-building-line';
  if (t.includes('makine') || t.includes('ekipman')) return 'ri-settings-3-line';
  if (t.includes('ergonomi') || t.includes('taşıma') || t.includes('tasima')) return 'ri-hand-heart-line';
  if (t.includes('kkd') || t.includes('koruyucu')) return 'ri-shield-user-line';
  if (t.includes('ilk yardım') || t.includes('ilk yardim')) return 'ri-first-aid-kit-line';
  if (t.includes('çevre') || t.includes('cevre') || t.includes('atık') || t.includes('atik')) return 'ri-leaf-line';
  if (t.includes('sektör') || t.includes('sektor') || t.includes('işe özel') || t.includes('ise ozel')) return 'ri-briefcase-line';
  return 'ri-graduation-cap-line';
}

// ── Eğitim türleri ───────────────────────────────────────────────────────────
export const EGITIM_TURLERI: string[] = [
  'İşe Giriş (Temel)',
  'Yenileme',
  'İşe Özel / Ek',
  'Bilgilendirme',
  'Uygulamalı / Tatbikat',
];

export function turMeta(tur: string): { soft: string; dot: string; hex: { fg: string; bg: string } } {
  const t = (tur || '').toLocaleLowerCase('tr');
  if (t.includes('giriş')) return { soft: 'bg-primary-500/15 text-primary-700 dark:text-primary-300', dot: 'bg-primary-500', hex: { fg: '#1D4ED8', bg: '#DCE7FA' } };
  if (t.includes('yenileme')) return { soft: 'bg-secondary-500/15 text-secondary-700 dark:text-secondary-300', dot: 'bg-secondary-500', hex: { fg: '#0E7490', bg: '#CFFAFE' } };
  if (t.includes('tatbikat') || t.includes('uygulama')) return { soft: 'bg-accent-500/15 text-accent-700 dark:text-accent-300', dot: 'bg-accent-500', hex: { fg: '#B45309', bg: '#FEF3C7' } };
  if (t.includes('bilgilendirme')) return { soft: 'bg-success-500/15 text-success-700 dark:text-success-300', dot: 'bg-success-500', hex: { fg: '#15803D', bg: '#E7F7EE' } };
  return { soft: 'bg-background-200 text-foreground-600', dot: 'bg-foreground-400', hex: { fg: '#374151', bg: '#EEF3F9' } };
}

// ── Periyotlar ───────────────────────────────────────────────────────────────
export const PERIYOTLAR: string[] = [
  'Haftalık', 'Aylık', '2 Aylık', '3 Aylık', '6 Aylık', 'Yıllık', 'Sürekli', 'Tek Seferlik',
];

export const ONCELIKLER: string[] = ['Yüksek', 'Orta', 'Düşük'];

export interface OncelikMeta {
  label: string;
  badge: string;
  soft: string;
  dot: string;
  renk: string;
  hex: { fg: string; bg: string };
}

export const ONCELIK_META: Record<string, OncelikMeta> = {
  Yüksek: {
    label: 'Yüksek', badge: 'bg-danger-500 text-inverse',
    soft: 'bg-danger-500/15 text-danger-700 dark:text-danger-300', dot: 'bg-danger-500',
    renk: '#DC2626', hex: { fg: '#B91C1C', bg: '#FDE7E7' },
  },
  Orta: {
    label: 'Orta', badge: 'bg-warning-500 text-inverse',
    soft: 'bg-warning-500/15 text-warning-700 dark:text-warning-300', dot: 'bg-warning-500',
    renk: '#F59E0B', hex: { fg: '#B45309', bg: '#FEF3C7' },
  },
  Düşük: {
    label: 'Düşük', badge: 'bg-success-500 text-inverse',
    soft: 'bg-success-500/15 text-success-700 dark:text-success-300', dot: 'bg-success-500',
    renk: '#16A34A', hex: { fg: '#15803D', bg: '#E7F7EE' },
  },
};

export function oncelikBilgi(oncelik: string): OncelikMeta {
  return ONCELIK_META[oncelik] ?? ONCELIK_META.Orta;
}

// ── Periyot → ay eşlemesi (deterministik "önerilen plan") ────────────────────
export function bosAylar(): boolean[] {
  return Array.from({ length: 12 }, () => false);
}

export function periyotAylari(periyot: string): number[] {
  switch (periyot) {
    case 'Haftalık':
    case 'Aylık':
    case 'Sürekli':
      return [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];
    case '2 Aylık': return [0, 2, 4, 6, 8, 10];
    case '3 Aylık': return [0, 3, 6, 9];
    case '6 Aylık': return [0, 6];
    case 'Yıllık': return [0];
    default: return [];
  }
}

export function aylariUygula(aylar: number[]): boolean[] {
  const a = bosAylar();
  aylar.forEach((i) => { if (i >= 0 && i < 12) a[i] = true; });
  return a;
}

// ── Kayıtlar ─────────────────────────────────────────────────────────────────
/** Bir planlanan İSG eğitimi. */
export interface EgitimKaydi {
  id: string;
  kategori: string;
  egitim: string;
  aciklama: string;
  tur: string;
  hedefGrup: string;
  egitici: string;
  /** Eğitim süresi (saat). Metin tutulur; raporda sayıya çevrilir. */
  sure: string;
  periyot: string;
  oncelik: string;
  /** 12 aylık plan (Ocak…Aralık). */
  aylar: boolean[];
}

/** AI eğitim önerisi — listeye EKLENMEDEN önceki öneri kartı. */
export interface EgitimAiOneri {
  id: string;
  kategori: string;
  egitim: string;
  aciklama: string;
  tur: string;
  hedefGrup: string;
  sure: string;
  periyot: string;
  oncelik: string;
}

export interface EgitimTemelBilgiler extends TemelBilgiler {
  planYili: string;
}

/** Sihirbazın GEÇİCİ çalışma alanı (kalıcı kayıt DEĞİLDİR). */
export interface EgitimWorkspace {
  temel: EgitimTemelBilgiler;
  kapsam: string[];
  egitimler: EgitimKaydi[];
  aiOnerileri: EgitimAiOneri[];
  aktifAdim: number;
  guncellendi: string;
}

// ── Kapsam maddeleri ─────────────────────────────────────────────────────────
export const KAPSAM_MADDELERI: string[] = [
  'Yeni işe başlayan çalışanların temel İSG eğitimi',
  'Mevcut çalışanların yenileme eğitimleri',
  'Tehlike sınıfına göre asgari eğitim sürelerinin karşılanması',
  'Çalışana özgü işe / ekipmana yönelik özel eğitimler',
  'İlk yardım eğitimi',
  'Yangın ve acil durum eğitimi ve tatbikatları',
  'Kişisel koruyucu donanım (KKD) kullanım eğitimi',
  'Ergonomi ve elle taşıma eğitimi',
  'Kimyasal maddelerle güvenli çalışma eğitimi',
  'Eğitim kayıtlarının (katılım belgesi vb.) tutulması',
];

// ── Hazır eğitim şablonları ("Şablondan Ekle") ──────────────────────────────
export interface EgitimSablon {
  kategori: string;
  egitim: string;
  aciklama: string;
  tur: string;
  sure: string;
  periyot: string;
  oncelik: string;
}

export const EGITIM_SABLONLARI: EgitimSablon[] = [
  { kategori: 'Genel İSG Konuları', egitim: 'Temel İSG Eğitimi (İşe Giriş)', aciklama: 'İşe yeni başlayan çalışanlara 6331 s. Kanun ve Ek-1 konularını kapsayan temel İSG eğitimi.', tur: 'İşe Giriş (Temel)', sure: '8', periyot: 'Tek Seferlik', oncelik: 'Yüksek' },
  { kategori: 'Genel İSG Konuları', egitim: 'Temel İSG Eğitimi (Yenileme)', aciklama: 'Mevcut çalışanların tehlike sınıfına göre periyodik yenileme eğitimi.', tur: 'Yenileme', sure: '8', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Genel İSG Konuları', egitim: 'İş Kazaları ve Ramak Kala Bildirimi', aciklama: 'İş kazası ve ramak kala olayların tanımı, bildirimi ve davranış kuralları.', tur: 'Bilgilendirme', sure: '2', periyot: '6 Aylık', oncelik: 'Orta' },
  { kategori: 'Sağlık Konuları', egitim: 'Çalışan Sağlığı ve Hijyen', aciklama: 'Kişisel hijyen, bulaşıcı hastalıklardan korunma ve sağlıklı çalışma alışkanlıkları.', tur: 'Bilgilendirme', sure: '3', periyot: 'Yıllık', oncelik: 'Orta' },
  { kategori: 'Sağlık Konuları', egitim: 'İlk Yardım Eğitimi', aciklama: 'Temel ilk yardım bilgisi, müdahale ve kurtarma teknikleri (yetkili kurum sertifikalı).', tur: 'Uygulamalı / Tatbikat', sure: '8', periyot: '3 Aylık', oncelik: 'Yüksek' },
  { kategori: 'Sağlık Konuları', egitim: 'Meslek Hastalıkları ve Korunma', aciklama: 'Meslek hastalıklarının nedenleri, belirtileri ve korunma yöntemleri.', tur: 'Bilgilendirme', sure: '3', periyot: 'Yıllık', oncelik: 'Orta' },
  { kategori: 'Teknik Konular', egitim: 'İş Ekipmanı Güvenli Kullanımı', aciklama: 'Kullanılan iş ekipmanlarının güvenli kullanımı ve kontrol gereklilikleri.', tur: 'İşe Özel / Ek', sure: '4', periyot: '6 Aylık', oncelik: 'Yüksek' },
  { kategori: 'Teknik Konular', egitim: 'Kaldırma ve Taşıma Ekipmanları', aciklama: 'Vinç, forklift ve kaldırma ekipmanlarının güvenli kullanımı ve işaretçi görevleri.', tur: 'İşe Özel / Ek', sure: '4', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Teknik Konular', egitim: 'Bakım-Onarım Güvenliği', aciklama: 'Bakım onarım işlerinde enerji kesme, kilitleme ve güvenli çalışma kuralları.', tur: 'İşe Özel / Ek', sure: '4', periyot: 'Yıllık', oncelik: 'Orta' },
  { kategori: 'Yangın ve Acil Durum', egitim: 'Yangın Güvenliği ve Söndürme', aciklama: 'Yangın çıkış nedenleri, yangın sınıfları ve yangın söndürme ekipmanlarının kullanımı.', tur: 'Uygulamalı / Tatbikat', sure: '4', periyot: '6 Aylık', oncelik: 'Yüksek' },
  { kategori: 'Yangın ve Acil Durum', egitim: 'Acil Durum ve Tahliye Tatbikatı', aciklama: 'Acil durum planı, tahliye yolları ve tatbikat uygulaması.', tur: 'Uygulamalı / Tatbikat', sure: '3', periyot: '6 Aylık', oncelik: 'Yüksek' },
  { kategori: 'Kimyasal Güvenlik', egitim: 'Kimyasal Maddelerle Güvenli Çalışma', aciklama: 'Kimyasalların sınıflandırılması, etiketleme, SDS/GBF ve maruziyetten korunma.', tur: 'İşe Özel / Ek', sure: '4', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Elektrik Güvenliği', egitim: 'Elektrikte Güvenli Çalışma', aciklama: 'Elektrik tehlikeleri, topraklama, yetkisiz müdahale yasağı ve güvenli çalışma kuralları.', tur: 'İşe Özel / Ek', sure: '4', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Yüksekte Çalışma', egitim: 'Yüksekte Çalışma ve Düşme Korunması', aciklama: 'Yüksekte çalışma kuralları, iskele/güvenlik ağı ve tam vücut kemeri kullanımı.', tur: 'İşe Özel / Ek', sure: '4', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Makine ve Ekipman Güvenliği', egitim: 'Makine Koruyucuları ve Kilitleme', aciklama: 'Makine koruyucuları, dönen aksamlardan korunma ve LOTO uygulamaları.', tur: 'İşe Özel / Ek', sure: '4', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Ergonomi ve Elle Taşıma', egitim: 'Ergonomi ve Elle Taşıma Teknikleri', aciklama: 'Doğru kaldırma/taşıma teknikleri, ergonomik çalışma ve kas-iskelet korunması.', tur: 'Bilgilendirme', sure: '3', periyot: 'Yıllık', oncelik: 'Orta' },
  { kategori: 'Kişisel Koruyucu Donanım', egitim: 'KKD Kullanımı ve Önemi', aciklama: 'İşe uygun KKD seçimi, doğru kullanımı, bakımı ve değişim zamanları.', tur: 'Bilgilendirme', sure: '2', periyot: '6 Aylık', oncelik: 'Orta' },
  { kategori: 'İlk Yardım', egitim: 'Yaralanmalarda İlk Müdahale', aciklama: 'Kesik, yanık, kırık ve kanamalarda ilk müdahale esasları.', tur: 'Bilgilendirme', sure: '3', periyot: 'Yıllık', oncelik: 'Orta' },
  { kategori: 'Çevre ve Atık', egitim: 'Atık Yönetimi ve Çevre Bilinci', aciklama: 'Atık türleri, ayrıştırma, bertaraf ve çevre koruma yükümlülükleri.', tur: 'Bilgilendirme', sure: '2', periyot: 'Yıllık', oncelik: 'Düşük' },
  { kategori: 'Sektörel / İşe Özel', egitim: 'Sektöre Özel Tehlike ve Riskler', aciklama: 'İşyerinin faaliyet alanına özgü tehlike/riskler ve alınacak önlemler.', tur: 'İşe Özel / Ek', sure: '4', periyot: 'Yıllık', oncelik: 'Yüksek' },
  { kategori: 'Sektörel / İşe Özel', egitim: 'Yeni Çalışan Oryantasyonu', aciklama: 'İşyeri tanıtımı, çalışma alanı, acil çıkışlar ve genel kurallar.', tur: 'İşe Giriş (Temel)', sure: '4', periyot: 'Tek Seferlik', oncelik: 'Orta' },
  { kategori: 'Yasal ve İdari', egitim: 'İSG Mevzuatı ve Yükümlülükler', aciklama: 'Çalışan ve işverenin 6331 s. Kanun kapsamındaki hak, yetki ve yükümlülükleri.', tur: 'Bilgilendirme', sure: '3', periyot: 'Yıllık', oncelik: 'Orta' },
];

// ── Boş kayıt üreticileri ────────────────────────────────────────────────────
function bugunIso(): string {
  const b = new Date();
  return `${b.getFullYear()}-${String(b.getMonth() + 1).padStart(2, '0')}-${String(b.getDate()).padStart(2, '0')}`;
}

export function bosEgitim(periyot = 'Yıllık', oncelik = 'Orta'): EgitimKaydi {
  return {
    id: yeniId('eg'),
    kategori: EGITIM_KATEGORILERI[0],
    egitim: '',
    aciklama: '',
    tur: EGITIM_TURLERI[0],
    hedefGrup: 'Tüm Çalışanlar',
    egitici: '',
    sure: '8',
    periyot,
    oncelik,
    aylar: aylariUygula(periyotAylari(periyot)),
  };
}

export function sablondanEgitim(s: EgitimSablon): EgitimKaydi {
  return {
    id: yeniId('eg'),
    kategori: s.kategori,
    egitim: s.egitim,
    aciklama: s.aciklama,
    tur: s.tur,
    hedefGrup: 'Tüm Çalışanlar',
    egitici: '',
    sure: s.sure,
    periyot: s.periyot,
    oncelik: s.oncelik,
    aylar: aylariUygula(periyotAylari(s.periyot)),
  };
}

export function bosEgitimTemel(): EgitimTemelBilgiler {
  return {
    calismaAdi: '',
    firma: '',
    degerlendirmeMetodu: EGITIM_METODU,
    kapsam: '',
    tarih: bugunIso(),
    tesis: '',
    gecerlilik: '',
    amac: '',
    ekip: [],
    dokumanlar: [],
    raporNo: '',
    tehlikeSinifi: '',
    adres: '',
    isveren: '',
    nace: '',
    naceId: '',
    calisanSayisi: '',
    hazirlayan: '',
    onaylayan: '',
    imzacilar: [],
    planYili: String(new Date().getFullYear() + 1),
  };
}

export function bosEgitimWorkspace(): EgitimWorkspace {
  return {
    temel: bosEgitimTemel(),
    kapsam: [...KAPSAM_MADDELERI],
    egitimler: [],
    aiOnerileri: [],
    aktifAdim: 0,
    guncellendi: new Date().toISOString(),
  };
}

/** Referans örnek eğitimlerle başlangıç (ilk kullanım). */
export function ornekEgitimler(): EgitimKaydi[] {
  const secilen = [0, 1, 4, 9, 11, 13, 15, 16, 19];
  return secilen.map((i) => sablondanEgitim(EGITIM_SABLONLARI[i])).filter(Boolean);
}