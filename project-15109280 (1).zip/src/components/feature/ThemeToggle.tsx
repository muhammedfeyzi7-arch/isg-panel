import { useTheme } from '@/context/ThemeContext';

type ThemeMode = 'auto' | 'light' | 'dark';

const ORDER: ThemeMode[] = ['auto', 'light', 'dark'];

const LABELS: Record<ThemeMode, string> = {
  auto: 'A',
  light: 'Açık',
  dark: 'Koyu',
};

const ICONS: Record<ThemeMode, string> = {
  auto: 'ri-contrast-line',
  light: 'ri-sun-line',
  dark: 'ri-moon-line',
};

/**
 * Ortak ThemeManager üzerinden çalışan tema kontrolü — tek ikon buton.
 * Her tıklamada sırayla döner: A → Açık → Koyu → A.
 * İkon, seçili modu (auto iken zaman tabanlı temayı) yansıtır.
 */
export default function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  const currentIndex = ORDER.indexOf(theme);
  const next = ORDER[(currentIndex + 1) % ORDER.length];
  const nextLabel = LABELS[next];

  return (
    <button
      type="button"
      onClick={() => setTheme(next)}
      className="w-8 h-8 flex items-center justify-center rounded-md text-foreground-500 hover:text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors"
      title={`Tema: ${LABELS[theme]} — sonraki: ${nextLabel}`}
      aria-label={`Tema: ${LABELS[theme]}. Sonraki temaya geç: ${nextLabel}`}
    >
      <i className={ICONS[theme]} />
    </button>
  );
}