/**
 * FAZ 2 — OSGB Personeller/Atamalar için İSG-KATİP SENKRONİZASYON DURUMU (SALT-OKUMA sunum).
 *
 * SAF sunum bileşenidir: hiçbir veri okumaz/yazmaz; yalnızca canonical entegrasyon
 * durumunu (PII'siz) gösterir. Proje StyleSystem token'ları (background/foreground/
 * primary/accent/secondary) kullanılır; yeni tasarım sistemi KURULMAZ.
 *
 * GÖRSEL: Referans tasarıma uygun TEK YATAY KOMPAKT panel:
 *   [ikon + başlık + Bağlı durumu + son senkronizasyon] | [4 özet stat] | [Detayları Gör]
 * Panel normalde kompakt kalır; detaylar yalnızca "Detayları Gör" ile açılır.
 * Sahte "Bağlı" GÖSTERİLMEZ; veri yoksa dürüst durum metni gösterilir.
 */
import { useState } from 'react';
import Badge from '@/components/ui/Badge';
import { formatIstanbulDateTime } from '@/lib/dateFormat';
import type {
  KatipEntityLinkStatus,
  KatipOsgbIntegration,
} from '@/lib/isgKatip/osgbIntegration';
import { describeKatipEntityStatus } from '@/lib/isgKatip/osgbIntegration';

type BadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'secondary' | 'accent';

function toneVariant(tone: 'match' | 'conflict' | 'warning' | 'muted' | 'new'): BadgeVariant {
  if (tone === 'match') return 'primary';
  if (tone === 'conflict') return 'danger';
  if (tone === 'new') return 'accent';
  if (tone === 'muted') return 'default';
  return 'warning';
}

/** Bir yerel kaydın KATİP bağlantı durumunu küçük badge olarak gösterir. */
export function KatipDurumBadge({ status }: { status: KatipEntityLinkStatus | null | undefined }) {
  if (!status) return null;
  const d = describeKatipEntityStatus(status);
  return <Badge variant={toneVariant(d.tone)}>{d.label}</Badge>;
}

/** Kanonik veri durumunun (panel düzeyi) kısa etiketi + renk yönü. */
function overallLabel(integration: KatipOsgbIntegration | null): { label: string; variant: BadgeVariant } {
  if (!integration) return { label: 'Veri Bekleniyor', variant: 'warning' };
  if (!integration.bridgeOk) return { label: 'Bağlantı Yok', variant: 'danger' };
  if (!integration.captured) return { label: 'Veri Bekleniyor', variant: 'warning' };
  if (!integration.scopeValidated) return { label: 'Kapsam Doğrulanamadı', variant: 'warning' };
  if (integration.dataState === 'ERROR') return { label: 'Veri Hatası', variant: 'danger' };
  if (integration.ready) return { label: 'Bağlı', variant: 'success' };
  if (integration.dataState === 'DATA_INCOMPLETE') return { label: 'Veri Toplanıyor', variant: 'warning' };
  return { label: 'Veri Bekleniyor', variant: 'warning' };
}

/** ISO zaman damgasını Atamalar modülüyle AYNI TEK biçimde gösterir: "5 Eyl 2026 14:32". */
function formatSyncStamp(iso: string | null | undefined): string | null {
  if (!iso) return null;
  const s = formatIstanbulDateTime(iso);
  return s === '—' ? null : s;
}

interface StatDef {
  key: string;
  icon: string;
  iconWrap: string;
  iconColor: string;
  label: string;
  sub: string;
  value: number | null;
  hint: string;
}

function CountLine({ label, counts }: { label: string; counts: { match: number; new: number; conflict: number; unresolved: number } }) {
  return (
    <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs">
      <span className="text-foreground-500 w-24 flex-shrink-0">{label}</span>
      <span className="inline-flex items-center gap-1 text-foreground-700">
        <i className="ri-link text-primary-500" /> {counts.match} Bağlı
      </span>
      <span className="inline-flex items-center gap-1 text-foreground-700">
        <i className="ri-add-circle-line text-accent-600" /> {counts.new} Yeni
      </span>
      <span className="inline-flex items-center gap-1 text-foreground-700">
        <i className="ri-error-warning-line text-danger-600" /> {counts.conflict} Çakışma
      </span>
      {counts.unresolved > 0 && (
        <span className="inline-flex items-center gap-1 text-foreground-700">
          <i className="ri-question-line text-warning-600" /> {counts.unresolved} İncelenecek
        </span>
      )}
    </div>
  );
}

interface KatipSyncStatusPanelProps {
  integration: KatipOsgbIntegration | null;
  isLoading: boolean;
  error: string | null;
  onRefresh: () => void;
  /** Panel başlığı (varsayılan: KATİP Senkronizasyon Durumu). */
  title?: string;
  /** Karşılaştırma kapsamı: personel mi yasal atama mı (etiket/sayım seçimi). */
  scope?: 'personel' | 'atama';
}

/**
 * KATİP veri toplama + eşleşme özetini gösteren kompakt TEK SATIR panel.
 * Veri seti DATA_COMPLETE/ready değilse RAKAM GÖSTERİLMEZ ("—" ve dürüst durum metni).
 * Rakamlar frontend'de yeniden hesaplanmaz; canonical sayımlar aynen kullanılır.
 */
export default function KatipSyncStatusPanel({
  integration,
  isLoading,
  error,
  onRefresh,
  title = 'KATİP Senkronizasyon Durumu',
  scope = 'personel',
}: KatipSyncStatusPanelProps) {
  const [expanded, setExpanded] = useState(false);
  const badge = !integration && error ? { label: 'Bağlantı Yok', variant: 'danger' as BadgeVariant } : overallLabel(integration);
  const isAtama = scope === 'atama';
  const ready = integration?.ready === true;
  const lastSync = formatSyncStamp(integration?.generatedAt);
  const connected = integration?.bridgeOk === true && integration?.captured === true;

  const counts = isAtama ? integration?.assignment.counts : integration?.personel.counts;
  const subtitle = isAtama
    ? 'İSG-KATİP yasal atama verilerinizle karşılaştırma özeti'
    : 'İSG-KATİP verilerinizle karşılaştırma özeti';
  const stats: StatDef[] = [
    {
      key: 'new',
      icon: 'ri-user-add-line',
      iconWrap: 'bg-primary-50 dark:bg-primary-500/15',
      iconColor: 'text-primary-600 dark:text-primary-400',
      label: isAtama ? 'Yeni Kayıt' : 'Yeni Personel',
      sub: 'Son senkronizasyonda',
      value: ready ? (counts?.new ?? 0) : null,
      hint: isAtama
        ? "İSG-KATİP'te olup yerelde karşılığı bulunmayan yasal atama"
        : "İSG-KATİP'te olup yerelde karşılığı bulunmayan personel",
    },
    {
      key: 'match',
      icon: 'ri-refresh-line',
      iconWrap: 'bg-success-50 dark:bg-success-500/15',
      iconColor: 'text-success-600 dark:text-success-400',
      label: 'Güncellenen Kayıt',
      sub: 'Son senkronizasyonda',
      value: ready ? (counts?.match ?? 0) : null,
      hint: isAtama
        ? 'İSG-KATİP ile eşleşen yerel yasal atama kaydı'
        : 'İSG-KATİP ile eşleşen yerel personel kaydı',
    },
    {
      key: 'unresolved',
      icon: 'ri-error-warning-line',
      iconWrap: 'bg-warning-50 dark:bg-warning-500/15',
      iconColor: 'text-warning-600 dark:text-warning-400',
      label: 'Eşleşmeyen Kayıt',
      sub: 'Kontrol edildi',
      value: ready ? (counts?.unresolved ?? 0) : null,
      hint: 'Kesin karar için ek inceleme gereken kayıt',
    },
    {
      key: 'conflict',
      icon: 'ri-close-circle-line',
      iconWrap: 'bg-danger-50 dark:bg-danger-500/15',
      iconColor: 'text-danger-600 dark:text-danger-400',
      label: 'Hata',
      sub: 'Tespit edilmedi',
      value: ready ? (counts?.conflict ?? 0) : null,
      hint: 'İSG-KATİP ile çakışan kayıt',
    },
  ];

  return (
    <div className="isg-card p-3">
      <div className="flex flex-col lg:flex-row lg:items-center gap-3 lg:gap-4">
        {/* SOL — bağlantı ikonu + başlık + durum + son senkronizasyon */}
        <div className="flex items-center gap-3 lg:w-[320px] flex-shrink-0 min-w-0">
          <span className="w-9 h-9 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-link-m text-primary-600 dark:text-primary-400 text-lg" />
          </span>
          <div className="min-w-0">
            <div className="flex items-center gap-2 min-w-0">
              <h3 className="text-sm font-semibold text-foreground-800 truncate">{title}</h3>
              <Badge variant={badge.variant}>{badge.label}</Badge>
            </div>
            <p className="text-[11px] text-foreground-500 truncate">{subtitle}</p>
            {connected && ready ? (
              <p className="text-[11px] text-foreground-500 truncate flex items-center gap-1">
                <i className="ri-time-line" /> Son senkronizasyon: {lastSync ?? '—'}
              </p>
            ) : (
              <p className="text-[11px] text-warning-600 truncate flex items-center gap-1" title={integration?.note ?? error ?? undefined}>
                <i className="ri-alert-line flex-shrink-0" />
                <span className="truncate">{error && !integration ? error : (integration?.note ?? 'İSG-KATİP durumu için veri yok.')}</span>
              </p>
            )}
          </div>
        </div>

        {/* ORTA — 4 özet stat */}
        <div className="flex-1 grid grid-cols-2 sm:grid-cols-4 gap-x-4 gap-y-2.5 min-w-0">
          {stats.map((s) => (
            <div key={s.key} className="flex items-center gap-2 min-w-0" title={s.hint}>
              <span className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${s.iconWrap}`}>
                <i className={`${s.icon} ${s.iconColor}`} />
              </span>
              <div className="min-w-0">
                <p className={`text-lg font-bold leading-none ${s.value == null ? 'text-foreground-300' : 'text-foreground-950'}`}>
                  {s.value == null ? '—' : s.value}
                </p>
                <p className="text-[11px] font-medium text-foreground-700 truncate mt-0.5">{s.label}</p>
                <p className="text-[10px] text-foreground-500 truncate">{s.sub}</p>
              </div>
            </div>
          ))}
        </div>

        {/* SAĞ — yenile + Detayları Gör */}
        <div className="flex items-center gap-2 flex-shrink-0 lg:pl-2">
          <button
            type="button"
            onClick={onRefresh}
            disabled={isLoading}
            className="w-8 h-8 rounded-md flex items-center justify-center text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer disabled:opacity-50"
            aria-label="Yenile"
          >
            <i className={isLoading ? 'ri-loader-4-line animate-spin' : 'ri-refresh-line'} />
          </button>
          <button
            type="button"
            onClick={() => setExpanded((v) => !v)}
            className="h-8 px-3 rounded-md border border-background-300/60 dark:border-background-400/40 flex items-center gap-1.5 text-xs font-medium text-foreground-700 hover:bg-background-200/70 dark:hover:bg-background-300/40 transition-colors cursor-pointer whitespace-nowrap"
            aria-expanded={expanded}
          >
            Detayları Gör
            <i className={`${expanded ? 'ri-arrow-up-s-line' : 'ri-arrow-down-s-line'} text-base`} />
          </button>
        </div>
      </div>

      {/* AÇILIR DETAY */}
      {expanded && (
        <div className="mt-3 pt-3 border-t isg-divider">
          {isLoading && !integration ? (
            <p className="text-xs text-foreground-500">KATİP durumu yükleniyor…</p>
          ) : error && !integration ? (
            <p className="text-xs text-danger-600 flex items-center gap-1">
              <i className="ri-error-warning-line" /> {error}
            </p>
          ) : integration ? (
            integration.ready ? (
              <div className="space-y-1.5">
                <CountLine label="Personel" counts={integration.personel.counts} />
                <CountLine label="Yasal Atama" counts={integration.assignment.counts} />
              </div>
            ) : (
              <p className="text-xs text-foreground-600 flex items-start gap-1.5">
                <i className="ri-information-line text-warning-600 mt-0.5 flex-shrink-0" />
                <span>{integration.note}</span>
              </p>
            )
          ) : (
            <p className="text-xs text-foreground-500">KATİP durumu için veri yok.</p>
          )}
        </div>
      )}
    </div>
  );
}

/** Saha Personeli görevlerinin KATİP yasal ataması SAYILMADIĞINI belirten küçük not. */
export function KatipSahaUzmaniNot() {
  return (
    <p className="text-[11px] text-foreground-500 flex items-start gap-1">
      <i className="ri-information-line mt-0.5" /> Saha Personeli görevleri operasyoneldir; KATİP yasal ataması sayılmaz.
    </p>
  );
}