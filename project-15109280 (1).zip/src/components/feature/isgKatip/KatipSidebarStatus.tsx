import { useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { useKatipOsgbIntegration } from '@/hooks/useKatipOsgbIntegration';
import type { KatipConnectionState } from '@/lib/isgKatip/connectionStatus';

/**
 * OSGB Paneli sidebar'ı için GERÇEK İSG-KATİP bağlantı durumu kartı.
 *
 * KURAL: Sahte "Bağlı" üretilmez. Durum, kanonik `useKatipOsgbIntegration().connection`
 * (uzantı yanıtı + yakalama + veri hazırlığı) üzerinden türetilir. Ayarlar ekranındaki
 * durum kartı ile AYNI kaynağı kullandığı için iki yüzey çelişemez.
 *
 * Yalnızca OSGB panelinde render edilir (Sidebar tarafından koşullu çizilir), böylece
 * diğer 4 panelde hiçbir ağ isteği tetiklenmez.
 *
 * GÖRSEL STANDART: Sidebar rail TEMA-AWARE'dir; kart yüzeyi/kenarlığı/metni yalnızca
 * `--sidebar-*` tokenlarından gelir. Durum vurgusu (nokta/ikon/etiket) açık rail'de
 * `-600/-700`, koyu rail'de `-400` tonlarıyla okunur.
 */

interface StateMeta {
  /** Durum noktası rengi (rail üzerinde okunur). */
  dot: string;
  /** Etiket metin rengi. */
  text: string;
  /** İkon kutusu rengi. */
  bubble: string;
  /** Kart zemini üzerine çok hafif semantic tint (rail üzerinde). */
  tint: string;
  /** Devam eden durumlarda nokta nefes alma animasyonu. */
  pulse: boolean;
}

const META: Record<KatipConnectionState, StateMeta> = {
  checking: {
    dot: 'bg-foreground-400',
    text: 'isg-sidebar-fg',
    bubble: 'bg-foreground-500/15 isg-sidebar-fg',
    tint: '',
    pulse: true,
  },
  'no-extension': {
    dot: 'bg-danger-500',
    text: 'text-danger-600 dark:text-danger-400',
    bubble: 'bg-danger-500/15 text-danger-600 dark:text-danger-400',
    tint: 'bg-danger-500/[0.08]',
    pulse: false,
  },
  waiting: {
    dot: 'bg-warning-500',
    text: 'text-warning-700 dark:text-warning-400',
    bubble: 'bg-warning-500/15 text-warning-700 dark:text-warning-400',
    tint: 'bg-warning-500/[0.08]',
    pulse: false,
  },
  preparing: {
    dot: 'bg-warning-500',
    text: 'text-warning-700 dark:text-warning-400',
    bubble: 'bg-warning-500/15 text-warning-700 dark:text-warning-400',
    tint: 'bg-warning-500/[0.08]',
    pulse: true,
  },
  active: {
    dot: 'bg-success-500',
    text: 'text-success-700 dark:text-success-400',
    bubble: 'bg-success-500/15 text-success-700 dark:text-success-400',
    tint: 'bg-success-500/[0.08]',
    pulse: false,
  },
  error: {
    dot: 'bg-danger-500',
    text: 'text-danger-600 dark:text-danger-400',
    bubble: 'bg-danger-500/15 text-danger-600 dark:text-danger-400',
    tint: 'bg-danger-500/[0.08]',
    pulse: false,
  },
};

interface KatipSidebarStatusProps {
  collapsed: boolean;
}

export default function KatipSidebarStatus({ collapsed }: KatipSidebarStatusProps) {
  const navigate = useNavigate();
  const { connection, refresh } = useKatipOsgbIntegration();

  // Yalnızca KULLANICI "Kontrol Et"e bastığında gösterilen kısa geri bildirim.
  // Arka plan otomatik tazelemesiyle karışmaz ve refetch asılı kalsa bile buton
  // kalıcı olarak kilitli kalmaz (finally ile her durumda açılır).
  const [manualBusy, setManualBusy] = useState(false);
  const handleRefresh = async () => {
    if (manualBusy) return;
    setManualBusy(true);
    try {
      await refresh();
    } finally {
      setManualBusy(false);
    }
  };

  const meta = META[connection.state];
  const label = connection.shortLabel;

  const openSettings = () => navigate('/osgb-panel/ayarlar?katip=1');

  if (collapsed) {
    return (
      <div className="px-2 pt-3 flex justify-center flex-shrink-0">
        <button
          type="button"
          onClick={openSettings}
          title={`İSG-KATİP · ${label}`}
          aria-label={`İSG-KATİP durumu: ${label}`}
          className={`relative w-10 h-10 flex items-center justify-center rounded-xl cursor-pointer transition-colors isg-sidebar-chip ${meta.tint}`}
        >
          <i className="ri-puzzle-2-line text-lg" />
          <span
            className={`absolute -top-0.5 -right-0.5 w-3 h-3 rounded-full ring-2 ring-[oklch(var(--sidebar-bg))] ${meta.dot} ${meta.pulse ? 'animate-pulse' : ''}`}
            aria-hidden="true"
          />
        </button>
      </div>
    );
  }

  return (
    <div className="px-3 py-3 flex-shrink-0">
      <div className={`rounded-xl border isg-sidebar-surface ${meta.tint} overflow-hidden`}>
        <div className="flex items-center gap-2.5 px-3 pt-2.5 pb-2">
          <span className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${meta.bubble}`}>
            <i className="ri-puzzle-2-line text-base" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-[11px] font-medium isg-sidebar-fg-muted leading-none">İSG-KATİP</p>
            <div className="flex items-center gap-1.5 mt-1">
              <span
                className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${meta.dot} ${meta.pulse ? 'animate-pulse' : ''}`}
                aria-hidden="true"
              />
              <span className={`text-xs font-semibold leading-none truncate ${meta.text}`}>{label}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1.5 px-3 pb-2.5">
          <button
            type="button"
            onClick={handleRefresh}
            disabled={manualBusy}
            className="flex-1 flex items-center justify-center gap-1.5 rounded-lg isg-sidebar-chip px-2 py-1.5 text-[11px] font-medium transition-colors cursor-pointer whitespace-nowrap disabled:opacity-60 disabled:cursor-default"
          >
            <i className={manualBusy ? 'ri-loader-4-line animate-spin' : 'ri-refresh-line'} />
            {manualBusy ? 'Kontrol ediliyor…' : 'Kontrol Et'}
          </button>
          <button
            type="button"
            onClick={openSettings}
            title="İSG-KATİP ayarları"
            aria-label="İSG-KATİP ayarları"
            className="w-7 h-7 flex items-center justify-center flex-shrink-0 rounded-lg isg-sidebar-chip transition-colors cursor-pointer"
          >
            <i className="ri-settings-3-line text-xs" />
          </button>
        </div>
      </div>
    </div>
  );
}