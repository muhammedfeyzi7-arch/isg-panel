import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import type { KatipConnectionStatus } from '@/lib/isgKatip/connectionStatus';
import { isChromeExtensionSupported } from '@/lib/isgKatip/extensionConfig';
import { KATIP_TONE_CLASSES, KatipStepBadge } from './katipDurumUi';

interface KatipUzantiKartiProps {
  connection: KatipConnectionStatus;
  onInstall: () => void;
}

/**
 * Adım 1 — İSG-KATİP Chrome Uzantısı kurulum alanı (YALNIZCA MASAÜSTÜ).
 *
 * İSGDenetim Chrome Uzantısı yalnızca masaüstü Chrome tarayıcısında çalışır; bu nedenle
 * mobil/QR kurulum alanı YOKTUR. Kart tam genişlikte tek kolonda hizalanır ve "Chrome
 * Web Store'dan Yükle" butonu ekranın ANA CTA'sı olacak şekilde belirgindir.
 *
 * Bağlantı/aktarım mantığına DOKUNMAZ; yalnızca kurulum yönlendirmesi yapar.
 */
export default function KatipUzantiKarti({ connection, onInstall }: KatipUzantiKartiProps) {
  const chromeOk = isChromeExtensionSupported();
  const tone = KATIP_TONE_CLASSES[connection.tone];

  return (
    <Card
      header={
        <div className="flex items-start gap-3">
          <KatipStepBadge no={1} />
          <div className="min-w-0 flex-1">
            <h3 className="text-sm font-semibold text-foreground-950">İSG-KATİP Chrome Uzantısı</h3>
            <p className="text-xs text-foreground-500 mt-0.5">
              İSG-KATİP bağlantısını tamamlamak için uzantıyı masaüstü Chrome&apos;a yükleyin ve İSG-KATİP hesabınıza giriş yapın.
            </p>
          </div>
          <Badge variant={tone.badge} className="flex-shrink-0">
            <i className={`mr-1 ${connection.icon}`} />
            {connection.label}
          </Badge>
        </div>
      }
      footer={
        <p className="text-[11px] text-foreground-500 flex items-start gap-1.5">
          <i className="ri-information-line mt-0.5 flex-shrink-0" />
          <span>
            Uzantıyı yükledikten sonra Chrome&apos;da İSG-KATİP&apos;e giriş yapın; bağlantı otomatik olarak doğrulanır.
          </span>
        </p>
      }
    >
      {!chromeOk && (
        <div className="flex items-start gap-2 rounded-lg border border-warning-300/60 bg-warning-50 dark:bg-warning-500/10 px-3 py-2.5 mb-4">
          <i className="ri-chrome-line text-warning-600 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-foreground-600 dark:text-foreground-500">
            Bu entegrasyon yalnızca masaüstü Google Chrome tarayıcısında çalışır. Lütfen masaüstü Chrome kullanın.
          </p>
        </div>
      )}

      {/* Masaüstü kurulum alanı — tek kolon, gereksiz genişleme yok */}
      <div className="rounded-lg border border-background-300/60 dark:border-background-400/30 p-4 sm:p-5">
        <div className="flex items-start gap-3">
          <span className="w-11 h-11 rounded-lg bg-background-100 dark:bg-background-200/50 flex items-center justify-center flex-shrink-0">
            <i className="ri-chrome-line text-foreground-700 text-2xl" />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-semibold text-foreground-800">Chrome Uzantısını Yükle</p>
            <p className="text-xs text-foreground-500 mt-0.5">
              İSGDenetim Chrome Uzantısını resmi Chrome Web Store üzerinden masaüstü Chrome&apos;a kurun.
            </p>
          </div>
        </div>

        <div className="mt-4">
          <Button
            variant="primary"
            size="lg"
            fullWidth
            onClick={onInstall}
            leftIcon={<i className="ri-chrome-line" />}
          >
            Chrome Web Store&apos;dan Yükle
          </Button>
        </div>

        <p className="text-xs text-foreground-500 mt-2.5 text-center">
          Chrome Web Store&apos;dan İSGDenetim Chrome Uzantısını yükleyin.
        </p>
        <p className="text-[11px] text-foreground-400 mt-1 text-center">
          Uzantı yalnızca masaüstü Chrome tarayıcısında kullanılabilir.
        </p>
      </div>
    </Card>
  );
}