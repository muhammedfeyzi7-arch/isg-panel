import { Fragment } from 'react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import type { KatipConnectionStatus } from '@/lib/isgKatip/connectionStatus';
import { KATIP_TONE_CLASSES } from './katipDurumUi';

const STEP_LABELS = ['Uzantı', 'Giriş', 'Kontrol', 'Aktif'];

/** 4 adımlı kurulum ilerleme göstergesi (Uzantı → Giriş → Kontrol → Aktif). */
function ConnectionStepper({ current }: { current: number }) {
  return (
    <div className="flex items-start">
      {STEP_LABELS.map((label, idx) => {
        const step = idx + 1;
        const done = current > step;
        const active = current === step;
        return (
          <Fragment key={label}>
            {idx > 0 && (
              <span className={`flex-1 h-0.5 mt-3.5 ${done || active ? 'bg-primary-400' : 'bg-background-300 dark:bg-background-400/40'}`} />
            )}
            <div className="flex flex-col items-center gap-1 px-0.5">
              <span
                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold transition-colors ${
                  active
                    ? 'bg-primary-500 text-inverse'
                    : done
                      ? 'bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300'
                      : 'bg-background-200 dark:bg-background-300/50 text-foreground-500'
                }`}
              >
                {done ? <i className="ri-check-line" /> : step}
              </span>
              <span className={`text-[10px] whitespace-nowrap ${active || done ? 'text-foreground-700 font-medium' : 'text-foreground-400'}`}>
                {label}
              </span>
            </div>
          </Fragment>
        );
      })}
    </div>
  );
}

interface KatipDurumKartiProps {
  connection: KatipConnectionStatus;
  /** "Bağlantıyı Kontrol Et" sürüyor mu? (gerçek kontrol; loading gösterilir). */
  checking: boolean;
  onCheck: () => void;
}

/**
 * Sağ kolon — Bağlantı Durumu kartı.
 * Durum YALNIZCA kanonik `connection`'dan gelir; "Kontrol Et" gerçek köprü kontrolü tetikler.
 */
export default function KatipDurumKarti({ connection, checking, onCheck }: KatipDurumKartiProps) {
  const tone = KATIP_TONE_CLASSES[connection.tone];

  return (
    <Card title="Bağlantı Durumu" icon="ri-link" padding="md">
      <div className={`flex items-start gap-2.5 rounded-lg border px-3 py-3 ${tone.soft}`}>
        <span className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 ${tone.iconWrap}`}>
          <i className={`${connection.icon} text-lg`} />
        </span>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full flex-shrink-0 ${tone.dot} ${connection.pulse ? 'animate-pulse' : ''}`} aria-hidden="true" />
            <p className="text-sm font-semibold text-foreground-800">{connection.label}</p>
          </div>
          <p className="text-xs text-foreground-500 mt-1">{connection.description}</p>
        </div>
      </div>

      <div className="mt-4">
        <ConnectionStepper current={connection.progressStep} />
      </div>

      <div className="mt-4">
        <Button
          variant="secondary"
          size="sm"
          fullWidth
          leftIcon={<i className="ri-refresh-line" />}
          isLoading={checking}
          onClick={onCheck}
        >
          Bağlantıyı Kontrol Et
        </Button>
      </div>
      <p className="text-xs text-foreground-500 mt-2 flex items-start gap-1.5">
        <i className="ri-loop-right-line mt-0.5 flex-shrink-0" />
        <span>Durum otomatik olarak güncellenir. Gerekirse &quot;Bağlantıyı Kontrol Et&quot; ile anında yenileyin.</span>
      </p>
    </Card>
  );
}