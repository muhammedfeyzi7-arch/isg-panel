import Card from '@/components/ui/Card';
import BrandLogo from '@/components/feature/BrandLogo';

/** İSG-KATİP → İSGDenetim görsel veri akışı (iki kaynak kutusu + kesikli ok). */
function DataFlow() {
  return (
    <div className="flex items-center gap-2 sm:gap-3">
      {/* Kaynak — İSG-KATİP */}
      <div className="flex flex-col items-center gap-1.5">
        <span className="w-14 h-14 rounded-xl bg-danger-50 dark:bg-danger-500/15 border border-danger-200/70 dark:border-danger-500/25 flex items-center justify-center">
          <i className="ri-government-line text-danger-600 dark:text-danger-300 text-2xl" />
        </span>
        <span className="text-[10px] font-bold text-foreground-700 whitespace-nowrap">İSG-KATİP</span>
      </div>

      {/* Akış oku */}
      <div className="flex items-center text-primary-400 pb-5">
        <span className="w-6 sm:w-8 border-t-2 border-dashed border-primary-300 dark:border-primary-500/40" />
        <i className="ri-arrow-right-s-line text-xl -ml-1.5" />
      </div>

      {/* Hedef — İSGDenetim */}
      <div className="flex flex-col items-center gap-1.5">
        <span className="w-14 h-14 rounded-xl bg-primary-50 dark:bg-primary-500/15 border border-primary-200/70 dark:border-primary-500/25 flex items-center justify-center overflow-hidden">
          <BrandLogo variant="mark" className="w-10 h-10" alt="İSGDenetim" />
        </span>
        <span className="text-[10px] font-bold text-foreground-700 whitespace-nowrap">İSGDenetim</span>
      </div>
    </div>
  );
}

const BENEFITS = [
  'İşyeri ve personel verilerini aktarın',
  'Yasal atama bilgilerini senkronize edin',
  'Zaman kazanın, hataları azaltın',
];

/**
 * Büyük entegrasyon başlık kartı: solda başlık/açıklama, sağda veri akışı + fayda listesi.
 * Bu kart SALT SUNUMdur; bağlantı mantığına dokunmaz.
 */
export default function KatipHeroCard() {
  return (
    <Card padding="md">
      <div className="flex flex-col xl:flex-row xl:items-center gap-5 xl:gap-6">
        {/* SOL — başlık + açıklama */}
        <div className="flex items-start gap-3 min-w-0 flex-1">
          <span className="w-11 h-11 rounded-lg bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-puzzle-2-line text-primary-600 dark:text-primary-400 text-xl" />
          </span>
          <div className="min-w-0">
            <h3 className="text-base font-semibold text-foreground-950">İSG-KATİP Entegrasyonu</h3>
            <p className="text-sm text-foreground-500 mt-1">
              İSG-KATİP&apos;teki işyeri, personel ve yasal atama bilgilerini İSGDenetim&apos;e güvenle aktarın.
            </p>
          </div>
        </div>

        {/* SAĞ — veri akışı + fayda listesi */}
        <div className="flex flex-col sm:flex-row sm:items-center gap-5 sm:gap-6 xl:flex-shrink-0">
          <DataFlow />
          <ul className="space-y-2">
            {BENEFITS.map((b) => (
              <li key={b} className="flex items-center gap-2 text-sm text-foreground-700">
                <i className="ri-checkbox-circle-fill text-success-500 flex-shrink-0" />
                <span>{b}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </Card>
  );
}