import { useState } from 'react';
import Card from '@/components/ui/Card';
import { KATIP_GUIDE_STEPS, KATIP_INSTALL_STEPS } from '@/lib/isgKatip/extensionConfig';

/** Sağ kolon — "İSG-KATİP bağlantısı nasıl kurulur?" 4 numaralı adım listesi. */
export function KatipKurulumAdimlariKarti() {
  return (
    <Card title="İSG-KATİP bağlantısı nasıl kurulur?" icon="ri-guide-line" padding="md">
      <ol className="space-y-3">
        {KATIP_INSTALL_STEPS.map((step) => (
          <li key={step.no} className="flex items-start gap-3">
            <span className="text-lg font-bold text-primary-500/80 leading-none w-7 flex-shrink-0 tabular-nums">
              {step.no}
            </span>
            <span className="w-8 h-8 rounded-lg bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-300 flex items-center justify-center flex-shrink-0">
              <i className={`${step.icon} text-base`} />
            </span>
            <div className="min-w-0 pt-0.5">
              <p className="text-sm font-semibold text-foreground-800">{step.title}</p>
              <p className="text-xs text-foreground-500 mt-0.5">{step.description}</p>
            </div>
          </li>
        ))}
      </ol>
    </Card>
  );
}

/** Sağ kolon — açılır kurulum rehberi (teknik detay içermez). */
export function KatipRehberKarti() {
  const [open, setOpen] = useState(false);
  return (
    <Card title="Kurulum Rehberi" icon="ri-book-open-line" padding="md">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between gap-2 text-left cursor-pointer"
        aria-expanded={open}
      >
        <span className="text-sm font-medium text-foreground-800">İSG-KATİP Entegrasyonu Nasıl Çalışır?</span>
        <i className={`ri-arrow-down-s-line text-foreground-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <ol className="mt-3 space-y-2">
          {KATIP_GUIDE_STEPS.map((step, i) => (
            <li key={step} className="flex items-start gap-2.5">
              <span className="flex items-center justify-center w-6 h-6 rounded-full bg-background-200 dark:bg-background-300/50 text-foreground-600 text-[11px] font-bold flex-shrink-0">
                {i + 1}
              </span>
              <span className="text-sm text-foreground-700 pt-0.5">{step}</span>
            </li>
          ))}
        </ol>
      )}
    </Card>
  );
}

/** Sağ kolon — güvenlik kartı. */
export function KatipGuvenlikKarti() {
  return (
    <Card title="Güvenlik" icon="ri-shield-check-line" padding="md">
      <div className="flex items-start gap-2.5">
        <span className="w-8 h-8 rounded-lg bg-success-50 dark:bg-success-500/15 text-success-600 dark:text-success-300 flex items-center justify-center flex-shrink-0">
          <i className="ri-shield-check-line text-base" />
        </span>
        <p className="text-xs text-foreground-600 dark:text-foreground-500 pt-0.5">
          İSGDenetim, İSG-KATİP hesabınızın şifresini veya oturum bilgilerini saklamaz. KATİP verileri Chrome uzantısı üzerinden salt-okuma ile okunarak aktarım için kullanılır.
        </p>
      </div>
    </Card>
  );
}