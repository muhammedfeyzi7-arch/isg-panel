import Card from '@/components/ui/Card';
import Toggle from '@/components/ui/Toggle';
import type { KatipConnectionStatus } from '@/lib/isgKatip/connectionStatus';
import { KatipStepBadge } from './katipDurumUi';

interface KatipAktarimAyarlariProps {
  connection: KatipConnectionStatus;
}

/**
 * Adım 2 — Aktarım Ayarları.
 * Ayarlar İSGDenetim tarafından yönetilir (salt-görünüm). Bağlantı aktif değilken
 * kullanıcıya net bir uyarı gösterilir; aktarım mantığı DEĞİŞTİRİLMEZ.
 */
export default function KatipAktarimAyarlari({ connection }: KatipAktarimAyarlariProps) {
  const connected = connection.katipActive;

  return (
    <Card
      header={
        <div className="flex items-start gap-3">
          <KatipStepBadge no={2} />
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-foreground-950">Aktarım Ayarları</h3>
            <p className="text-xs text-foreground-500 mt-0.5">İSG-KATİP entegrasyonunun çalışma biçimi.</p>
          </div>
        </div>
      }
      footer={
        <p className="text-[11px] text-foreground-500 flex items-center gap-1.5">
          <i className="ri-information-line flex-shrink-0" />
          Bu ayarlar İSGDenetim tarafından yönetilir. Herhangi bir değişiklik için destek ekibimizle iletişime geçin.
        </p>
      }
    >
      {!connected && (
        <div className="flex items-start gap-2 rounded-lg border border-warning-300/60 bg-warning-50 dark:bg-warning-500/10 px-3 py-2.5 mb-3">
          <i className="ri-lock-2-line text-warning-600 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-foreground-600 dark:text-foreground-500">
            İSG-KATİP bağlantısı aktif olmadan veri aktarımı başlatılamaz. Önce Chrome uzantısını yükleyip İSG-KATİP&apos;e giriş yapın.
          </p>
        </div>
      )}

      <div className="space-y-1">
        <div className="flex items-center justify-between gap-3 py-2.5">
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground-800">İSG-KATİP Entegrasyonu</p>
            <p className="text-xs text-foreground-500 mt-0.5">İSG-KATİP işyeri ve atama verilerini aktarmaya izin verir.</p>
          </div>
          <div className="flex-shrink-0">
            <Toggle checked disabled readOnly labelOn="Açık" labelOff="Kapalı" />
          </div>
        </div>
        <div className="flex items-center justify-between gap-3 py-2.5 border-t isg-divider">
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground-800">İSG-KATİP çalışan sayısını gereksinim hesabında kullan</p>
            <p className="text-xs text-foreground-500 mt-0.5">
              Firma İSG-KATİP ile eşleşmiş ve geçerli KATİP çalışan sayısı varsa İSG gereksinim hesabında bu değer kullanılır. Merkezi firma çalışan sayısı değişmez.
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Toggle checked disabled readOnly labelOn="Açık" />
            <i className="ri-lock-2-line text-foreground-400" aria-hidden="true" />
          </div>
        </div>
      </div>
    </Card>
  );
}