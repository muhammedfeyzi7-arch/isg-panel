/**
 * İSG-KATİP Entegrasyon ekranı — ORTAK durum görsel eşlemeleri.
 * Kanonik `KatipConnectionTone` → proje token sınıfları. Sayfaya özel renk ÜRETİLMEZ.
 */
import type { KatipConnectionTone } from '@/lib/isgKatip/connectionStatus';

export type KatipBadgeVariant = 'success' | 'warning' | 'danger' | 'info';

export interface KatipToneClasses {
  /** Durum noktası (dolgu). */
  dot: string;
  /** Yuvarlak ikon kutusu (zemin + metin). */
  iconWrap: string;
  /** Vurgu metin rengi. */
  text: string;
  /** Yumuşak bilgi/kutu zemini + kenarlık. */
  soft: string;
  /** Rozet varyantı. */
  badge: KatipBadgeVariant;
}

export const KATIP_TONE_CLASSES: Record<KatipConnectionTone, KatipToneClasses> = {
  success: {
    dot: 'bg-success-500',
    iconWrap: 'bg-success-50 dark:bg-success-500/15 text-success-600 dark:text-success-300',
    text: 'text-success-700 dark:text-success-300',
    soft: 'bg-success-50/70 dark:bg-success-500/10 border-success-200/60 dark:border-success-500/25',
    badge: 'success',
  },
  warning: {
    dot: 'bg-warning-500',
    iconWrap: 'bg-warning-50 dark:bg-warning-500/15 text-warning-600 dark:text-warning-300',
    text: 'text-warning-700 dark:text-warning-300',
    soft: 'bg-warning-50/70 dark:bg-warning-500/10 border-warning-200/60 dark:border-warning-500/25',
    badge: 'warning',
  },
  danger: {
    dot: 'bg-danger-500',
    iconWrap: 'bg-danger-50 dark:bg-danger-500/15 text-danger-600 dark:text-danger-300',
    text: 'text-danger-700 dark:text-danger-300',
    soft: 'bg-danger-50/70 dark:bg-danger-500/10 border-danger-200/60 dark:border-danger-500/25',
    badge: 'danger',
  },
  info: {
    dot: 'bg-primary-500',
    iconWrap: 'bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-300',
    text: 'text-primary-700 dark:text-primary-300',
    soft: 'bg-primary-50/70 dark:bg-primary-500/10 border-primary-200/60 dark:border-primary-500/25',
    badge: 'info',
  },
};

/** Kart başlığındaki numaralı adım rozeti ("1", "2"). */
export function KatipStepBadge({ no }: { no: number }) {
  return (
    <span className="w-7 h-7 rounded-lg bg-primary-500 text-inverse flex items-center justify-center text-sm font-bold flex-shrink-0">
      {no}
    </span>
  );
}