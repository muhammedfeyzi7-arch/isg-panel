import { useEffect, useRef, useState } from 'react';
import { useToastActions } from '@/hooks/useToast';
import { useKatipOsgbIntegration } from '@/hooks/useKatipOsgbIntegration';
import { getExtensionInstallUrl } from '@/lib/isgKatip/extensionConfig';
import KatipHeroCard from './entegrasyon/KatipHeroCard';
import KatipUzantiKarti from './entegrasyon/KatipUzantiKarti';
import KatipAktarimAyarlari from './entegrasyon/KatipAktarimAyarlari';
import KatipDurumKarti from './entegrasyon/KatipDurumKarti';
import {
  KatipKurulumAdimlariKarti,
  KatipRehberKarti,
  KatipGuvenlikKarti,
} from './entegrasyon/KatipKurulumKartlari';

/**
 * OSGB Paneli → Ayarlar → İSG-KATİP Entegrasyonu.
 *
 * SADECE İSG-KATİP entegrasyonunun yönetildiği ekrandır: Chrome uzantısı, GERÇEK bağlantı
 * durumu, kurulum adımları, aktarım ayarları ve güvenlik. Raporlama / analiz / atama YOKTUR.
 *
 * KURALLAR:
 *  - Bağlantı durumu KANONİK kaynaktan (`useKatipOsgbIntegration().connection`) türetilir;
 *    SAHTE "Bağlı" YOK. Aynı durum sol menü kartında da kullanılır (senkron).
 *  - Kurulum URL'si merkezi config'ten gelir; sahte URL/Extension ID ÜRETİLMEZ.
 *  - "Bağlantıyı Kontrol Et" GERÇEK köprü kontrolü yapar; kontrol boyunca loading gösterilir.
 *  - Sayfa yenilenmeden durum güncellenir: SWR odak/reconnect + sayfa görünürlüğü ile tazelenir.
 *  - Mevcut aktarım mantığına / Chrome extension iletişimine DOKUNULMAZ.
 */
export default function KatipEntegrasyonSection() {
  const { addToast } = useToastActions();
  const { integration, isLoading, connection, refresh } = useKatipOsgbIntegration();
  const [checking, setChecking] = useState(false);

  const installUrl = getExtensionInstallUrl();

  // Sayfa görünür olduğunda (sekme geri geldiğinde) durumu yeniden kontrol et — sayfa
  // yenilemeye gerek kalmadan uzantı kurulumu sonrası durum güncellenir.
  const refreshRef = useRef(refresh);
  useEffect(() => { refreshRef.current = refresh; }, [refresh]);
  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState === 'visible') void refreshRef.current();
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, []);

  const installExtension = () => {
    if (installUrl) {
      window.open(installUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    addToast({
      type: 'info',
      title: 'Uzantı yakında kullanıma sunulacak',
      message: 'İSG-KATİP Chrome Uzantısı yayına alındığında buradan kurulabilecek.',
    });
  };

  const handleCheck = async () => {
    if (checking) return;
    setChecking(true);
    try {
      await refresh();
    } finally {
      setChecking(false);
    }
  };

  const checkBusy = checking || (isLoading && !integration);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px] gap-4 items-start">
      {/* ── SOL KOLON ── */}
      <div className="space-y-4 min-w-0">
        <KatipHeroCard />
        <KatipUzantiKarti connection={connection} onInstall={installExtension} />
        <KatipAktarimAyarlari connection={connection} />
      </div>

      {/* ── SAĞ KOLON (mobilde içeriğin altına taşar) ── */}
      <div className="space-y-4 min-w-0">
        <KatipDurumKarti connection={connection} checking={checkBusy} onCheck={handleCheck} />
        <KatipKurulumAdimlariKarti />
        <KatipRehberKarti />
        <KatipGuvenlikKarti />
      </div>
    </div>
  );
}