/**
 * Tutanak belge modalı — görüntüleme yardımcıları (iş mantığı DEĞİL).
 *
 * Buradaki her şey yalnızca SUNUM/İNDİRME/YAZDIRMA içindir. Belge içeriği
 * server-side (scope doğrulamalı) alınır; bu dosya hiçbir veriyi değiştirmez.
 */
import { downloadBytesFile } from '@/lib/downloadFile';

/**
 * Bayt dizisini tarayıcıda indirir (gerçek dosya).
 * Dosya adı MERKEZÎ motorda güvenli/anlamlı hale getirilir; yeni sekme AÇILMAZ.
 */
export function downloadBytes(bytes: ArrayBuffer, mime: string | null, name: string): void {
  downloadBytesFile(bytes, mime, name || 'Belge.pdf');
}

/**
 * Tarayıcının doğrudan yazdırabildiği türleri (PDF/görsel) gizli bir iframe
 * üzerinden yazdırır. Word/Excel gibi türler tarayıcıda yazdırılamaz → çağıran
 * tarafında buton gizlenir.
 */
export function printBytes(bytes: ArrayBuffer, mime: string | null): void {
  const blob = new Blob([bytes], { type: mime || 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const iframe = document.createElement('iframe');
  iframe.setAttribute('aria-hidden', 'true');
  iframe.style.position = 'fixed';
  iframe.style.right = '0';
  iframe.style.bottom = '0';
  iframe.style.width = '0';
  iframe.style.height = '0';
  iframe.style.border = '0';
  iframe.src = url;
  iframe.onload = () => {
    try {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
    } catch {
      /* yoksay */
    }
  };
  document.body.appendChild(iframe);
  window.setTimeout(() => {
    if (iframe.parentNode) iframe.parentNode.removeChild(iframe);
    URL.revokeObjectURL(url);
  }, 60000);
}

/** Sistem tarafından ÜRETİLEN (imzasız) Word belgesi mi? (.docx) */
export function isSystemWordDocx(mime: string | null, name: string | null): boolean {
  const ext = name ? name.split('.').pop()?.toLowerCase() : '';
  return (
    mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    ext === 'docx'
  );
}

export type RevizyonVariant = 'success' | 'warning' | 'secondary' | 'default' | 'info';

export interface RevizyonGorunum {
  label: string;
  variant: RevizyonVariant;
}

/**
 * Bir revizyonun görüntüleme etiketini çözer.
 *
 * Belge yaşam döngüsü:
 *   draft      → Taslak
 *   generated  → İmzalanmayı Bekliyor (sistem belgeyi üretti, imza yüklenmedi)
 *   signed     → Tamamlandı (imzalı nihai belge yüklendi)
 *   superseded → geçmiş revizyon (yeni revizyon üretilince arşivlendi; Tamamlanmış kabul edilir)
 *
 * 'Tamamlandı' etiketi yalnızca imzalı nihai belge için kullanılır; superseded (geçmiş)
 * revizyonlar da tamamlanmış sayıldığından geçmişte 'Tamamlandı' olarak gösterilir.
 */
export function revisionLabel(
  r: { belgeDurumu: string | null; mimeType: string | null; originalFileName: string | null },
  active: boolean,
): RevizyonGorunum {
  const suffix = active ? '' : ' (geçmiş)';
  if (r.belgeDurumu === 'draft') {
    return { label: `Taslak${suffix}`, variant: 'warning' };
  }
  if (r.belgeDurumu === 'generated') {
    return { label: `İmzalanmayı Bekliyor${suffix}`, variant: active ? 'info' : 'secondary' };
  }
  if (r.belgeDurumu === 'signed') {
    return { label: `Tamamlandı${suffix}`, variant: active ? 'success' : 'secondary' };
  }
  if (r.belgeDurumu === 'superseded') {
    return { label: 'Tamamlandı', variant: 'secondary' };
  }
  // belge_durumu boş (eski kayıtlar) → dosya türüne göre tamamlanmış kabul edilir.
  return isSystemWordDocx(r.mimeType, r.originalFileName)
    ? { label: `İmzalanmayı Bekliyor${suffix}`, variant: active ? 'info' : 'secondary' }
    : { label: `Tamamlandı${suffix}`, variant: active ? 'success' : 'secondary' };
}