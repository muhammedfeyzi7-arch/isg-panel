import { useCallback, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Toggle from '@/components/ui/Toggle';
import FileUpload, { type UploadFile } from '@/components/ui/FileUpload';
import EmptyState from '@/components/ui/EmptyState';
import {
  DocumentPreviewEngine,
  DocumentPreviewModal,
  detectPreviewKind,
  type PreviewDocumentSource,
} from '@/components/feature/preview';
import { useToastActions } from '@/hooks/useToast';
import { useModalActions } from '@/hooks/useModal';
import { useConfirmActions } from '@/hooks/useConfirm';
import { base64ToArrayBuffer } from '@/lib/ocrService';
import { getEvrakContent, setFirmVisible, friendlyEvrakError } from '@/lib/evrakService';
import {
  type TutanakData,
  type TutanakAttachment,
  belgeDurumuVariant,
  deleteTutanakAttachment,
  fetchTutanakHistory,
  friendlyTutanakError,
  getTutanakAttachmentContent,
  uploadTutanakAttachment,
} from '@/lib/tutanakService';
import { regenerateTutanakDocx } from '@/lib/tutanakEkler';
import {
  formatEvrakDate,
  formatEvrakDateTime,
  formatEvrakSize,
  evrakFileIcon,
} from '@/components/feature/evrak/evrakUi';
import TutanakEmailModal from '@/pages/uzman/tutanaklar/components/TutanakEmailModal';
import { buildTutanakPdf } from '@/lib/tutanakRapor/pdf';
import { loadRiskBrandMeta } from '@/lib/riskRapor/brand';
import { downloadBytes, printBytes, revisionLabel } from './tutanakBelgeUi';

const ATTACH_ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.odt,.ods,image/jpeg,image/png,image/webp';
const MAX_SIZE = 15 * 1024 * 1024;

const NAV_BTN =
  'w-7 h-7 flex items-center justify-center rounded-md text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-default';

function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1">
      <span className="text-xs text-foreground-500 flex-shrink-0">{label}</span>
      <span className="text-xs text-foreground-800 text-right min-w-0 break-words">{value}</span>
    </div>
  );
}

/** Kompakt, katlanabilir bölüm kartı (sağ panel). Varsayılan açık; gerektiğinde kapatılıp alan kazanılır. */
function Section({
  title,
  icon,
  children,
  defaultOpen = true,
}: {
  title: string;
  icon: string;
  children: ReactNode;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-lg border border-background-300/50 dark:border-background-400/25 bg-background-50 dark:bg-background-100 overflow-hidden flex-shrink-0">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-expanded={open}
        className="w-full flex items-center gap-2 px-3 py-2 hover:bg-background-100 dark:hover:bg-background-200/40 transition-colors cursor-pointer"
      >
        <i className={`${icon} text-primary-600 dark:text-primary-400 text-sm flex-shrink-0`} />
        <span className="flex-1 text-left text-[11px] font-semibold uppercase tracking-wide text-foreground-600">
          {title}
        </span>
        <i className={`${open ? 'ri-subtract-line' : 'ri-add-line'} text-foreground-400 text-sm flex-shrink-0`} />
      </button>
      {open && (
        <div className="px-3 pb-2.5 pt-1.5 border-t border-background-300/30 dark:border-background-400/20 flex flex-col gap-0.5">
          {children}
        </div>
      )}
    </div>
  );
}

function ActionButton({
  icon,
  label,
  onClick,
  disabled,
  busy,
}: {
  icon: string;
  label: string;
  onClick: () => void;
  disabled?: boolean;
  busy?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled || busy}
      className="flex items-center gap-2 w-full px-3 py-2 rounded-md text-sm text-foreground-700 bg-background-100 dark:bg-background-200/50 hover:bg-background-200 dark:hover:bg-background-300/50 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-default whitespace-nowrap"
    >
      <i className={`${icon} text-base ${busy ? 'animate-pulse' : ''}`} />
      {label}
    </button>
  );
}

interface TutanakBelgeModalProps {
  tutanak: TutanakData;
  /** true → uzman/OSGB (görünürlük, ek yükleme); false → firma (yalnızca görüntüle/indir). */
  canManage: boolean;
  onClose: () => void;
  onChanged: () => void;
  /** Aktif TASLAK tutanağı sihirbazda yeniden düzenlemeyi başlatır. */
  onEdit?: (t: TutanakData) => void;
  /** Aktif taslak/üretilmiş tutanağa imzalı nihai belge yükleme akışını başlatır. */
  onAddSigned?: (t: TutanakData) => void;
  /** Tamamlanmış tutanaktan Rev.N+1 (taslak) oluşturma akışını başlatır. */
  onNewRevision?: (t: TutanakData) => void;
}

/**
 * ORTAK TUTANAK BELGE MODALI — İş Kazası / Ramak Kala / Tehlikeli Durum tutanaklarının
 * TAMAMI için tek detay + önizleme merkezi (Uzman ve Firma panelleri dahil).
 *
 * YERLEŞİM: Modal başlığı (ikon + ad + rozet + pencere kontrolleri) paylaşılan modal
 * motorundan gelir ve SABİTTİR. Gövde İKİ KOLONA ayrılır ve viewport yüksekliğini
 * doldurur; ANA MODAL ASLA KAYDIRILMAZ. Yalnızca sağ panel (ve belge) kendi içinde
 * kontrollü kaydırılır.
 *
 * Sol/orta: MERKEZİ `DocumentPreviewEngine` — belge OKUNABİLİR ölçekte (genişliğe
 * sığdır) açılır; sayfa/zoom/tam ekran/yazdır. Sağ: Belge Bilgileri · İşlemler ·
 * Sürüm İşlemleri · Ekler · Belge Geçmişi.
 */
export default function TutanakBelgeModal({ tutanak, canManage, onClose, onChanged, onEdit, onAddSigned, onNewRevision }: TutanakBelgeModalProps) {
  const { addToast } = useToastActions();
  const { openModal, closeModal } = useModalActions();
  const { confirm } = useConfirmActions();

  const [viewing, setViewing] = useState<TutanakData>(tutanak);
  const [history, setHistory] = useState<TutanakData[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  const [visible, setVisible] = useState(tutanak.firmVisible);
  const [toggling, setToggling] = useState(false);

  const [attachments, setAttachments] = useState<TutanakAttachment[]>(tutanak.attachments);
  const [attachFiles, setAttachFiles] = useState<UploadFile[]>([]);
  const [attachUploading, setAttachUploading] = useState(false);
  const [attachDeleting, setAttachDeleting] = useState<string | null>(null);
  const [attachmentPreview, setAttachmentPreview] = useState<TutanakAttachment | null>(null);
  /** Word belgesi yeniden üretildiğinde önizleme önbelleğini kırar. */
  const [docxNonce, setDocxNonce] = useState(0);

  const [busyDownload, setBusyDownload] = useState(false);
  const [pdfBusy, setPdfBusy] = useState(false);

  const isViewingActive = viewing.id === tutanak.id;

  // Belge yaşam döngüsü: draft/generated = imzalanmamış; signed / superseded / null(eski) = tamamlanmış.
  const isUnsigned = tutanak.belgeDurumu === 'draft' || tutanak.belgeDurumu === 'generated';

  const loadHistory = useCallback(() => {
    setHistoryLoading(true);
    fetchTutanakHistory(tutanak.id)
      .then(setHistory)
      .catch(() => setHistory([]))
      .finally(() => setHistoryLoading(false));
  }, [tutanak.id]);

  useEffect(() => {
    setViewing(tutanak);
    setAttachments(tutanak.attachments);
    setVisible(tutanak.firmVisible);
    loadHistory();
  }, [tutanak, loadHistory]);

  /* ---- Önizleme kaynağı (aktif veya seçili revizyon) ---- */
  const source: PreviewDocumentSource = useMemo(
    () => ({
      cacheKey: `${viewing.id}:${viewing.revisionNo ?? 1}:${docxNonce}`,
      fileName: viewing.originalFileName ?? viewing.title ?? 'belge',
      mimeType: viewing.mimeType,
      fileSize: viewing.fileSize,
      getBytes: async () => base64ToArrayBuffer((await getEvrakContent(viewing.id)).fileBase64),
    }),
    [viewing, docxNonce],
  );

  const kind = detectPreviewKind(viewing.mimeType, viewing.originalFileName ?? viewing.title ?? '');
  const canPrint = kind === 'pdf' || kind === 'image';

  /* ---- Belge Geçmişi: aktif + tüm eski revizyonlar ---- */
  const allRevisions = useMemo(() => [tutanak, ...history], [tutanak, history]);

  const downloadEvrak = useCallback(
    async (target: TutanakData) => {
      setBusyDownload(true);
      try {
        const c = await getEvrakContent(target.id);
        downloadBytes(
          base64ToArrayBuffer(c.fileBase64),
          c.mimeType ?? target.mimeType,
          target.originalFileName ?? target.title ?? 'belge',
        );
      } catch (e) {
        addToast({ title: 'Dosya indirilemedi', message: friendlyEvrakError(e), type: 'error' });
      } finally {
        setBusyDownload(false);
      }
    },
    [addToast],
  );

  const handlePrint = useCallback(async () => {
    try {
      const c = await getEvrakContent(viewing.id);
      printBytes(base64ToArrayBuffer(c.fileBase64), c.mimeType ?? viewing.mimeType);
    } catch (e) {
      addToast({ title: 'Yazdırma başarısız', message: friendlyEvrakError(e), type: 'error' });
    }
  }, [viewing, addToast]);

  /* ---- PDF ÇIKTISI — belge bölüm modelinden markalı PDF (Word'ün yanında) ---- */
  const hasPdfModel = (viewing.sections?.length ?? 0) > 0;

  const buildPdfResult = useCallback(async () => {
    const brand = await loadRiskBrandMeta({ firmaAdi: viewing.firmaName });
    let dofRows: Record<string, unknown>[] = [];
    const rawDof = viewing.fieldValues?._dof;
    if (rawDof) {
      try {
        const parsed = JSON.parse(rawDof);
        if (Array.isArray(parsed)) dofRows = parsed as Record<string, unknown>[];
      } catch {
        dofRows = [];
      }
    }
    return buildTutanakPdf({
      typeName: viewing.typeName,
      tutanakNo: viewing.tutanakNo,
      firmaName: viewing.firmaName,
      personelName: viewing.personelName,
      documentDate: viewing.documentDate,
      revisionNo: viewing.revisionNo,
      belgeDurumuLabel: viewing.belgeDurumuLabel,
      sections: viewing.sections,
      signers: viewing.signers,
      dofRows,
      brand,
    });
  }, [viewing]);

  const handleDownloadPdf = useCallback(async () => {
    if (!hasPdfModel) return;
    setPdfBusy(true);
    try {
      const { blob, fileName } = await buildPdfResult();
      downloadBytes(await blob.arrayBuffer(), 'application/pdf', fileName);
    } catch (e) {
      addToast({ title: 'PDF oluşturulamadı', message: friendlyTutanakError(e), type: 'error' });
    } finally {
      setPdfBusy(false);
    }
  }, [hasPdfModel, buildPdfResult, addToast]);

  const handlePrintPdf = useCallback(async () => {
    if (!hasPdfModel) return;
    setPdfBusy(true);
    try {
      const { blob } = await buildPdfResult();
      printBytes(await blob.arrayBuffer(), 'application/pdf');
    } catch (e) {
      addToast({ title: 'PDF yazdırılamadı', message: friendlyTutanakError(e), type: 'error' });
    } finally {
      setPdfBusy(false);
    }
  }, [hasPdfModel, buildPdfResult, addToast]);

  const handleToggleVisible = async (next: boolean) => {
    setToggling(true);
    try {
      await setFirmVisible(tutanak.id, next);
      setVisible(next);
      addToast({
        title: next ? 'Firmaya gösteriliyor' : 'Firmadan gizlendi',
        message: 'Firma görünürlüğü güncellendi.',
        type: 'success',
      });
      onChanged();
    } catch (e) {
      addToast({ title: 'Görünürlük değiştirilemedi', message: friendlyEvrakError(e), type: 'error' });
      setVisible(tutanak.firmVisible);
    } finally {
      setToggling(false);
    }
  };

  /** Ek değişince, imzasız belgenin Word'ünü yeni ek listesiyle yeniden üretir. */
  const runRegen = useCallback(
    async (list: TutanakAttachment[]) => {
      if (!canManage || !isUnsigned) return;
      try {
        const ok = await regenerateTutanakDocx({ ...tutanak, attachments: list });
        if (ok) setDocxNonce((n) => n + 1);
      } catch (e) {
        addToast({ title: 'Belge güncellenemedi', message: friendlyTutanakError(e), type: 'warning' });
      }
    },
    [canManage, isUnsigned, tutanak, addToast],
  );

  const handleUploadAttachment = async () => {
    const file = attachFiles[0]?.raw;
    if (!file) {
      addToast({ title: 'Dosya seçilmedi', message: 'Eklenecek dosyayı seçin.', type: 'warning' });
      return;
    }
    if (file.size > MAX_SIZE) {
      addToast({ title: 'Dosya çok büyük', message: 'Dosya boyutu 15 MB sınırını aşıyor.', type: 'warning' });
      return;
    }
    setAttachUploading(true);
    try {
      const res = await uploadTutanakAttachment(tutanak.id, file);
      setAttachments(res.attachments);
      setAttachFiles([]);
      addToast({ title: 'Ek yüklendi', message: 'Dosya tutanağa ek olarak eklendi.', type: 'success' });
      await runRegen(res.attachments);
      onChanged();
    } catch (e) {
      addToast({ title: 'Ek yüklenemedi', message: friendlyTutanakError(e), type: 'error' });
    } finally {
      setAttachUploading(false);
    }
  };

  const handleDeleteAttachment = (a: TutanakAttachment) => {
    if (!a.storagePath) return;
    confirm({
      title: 'Ek dosyayı sil',
      message: `"${a.name}" eki tutanaktan kaldırılacak ve Word belgesi yeniden üretilecek. Devam edilsin mi?`,
      confirmText: 'Evet, Sil',
      variant: 'danger',
      onConfirm: () => {
        void (async () => {
          setAttachDeleting(a.storagePath as string);
          try {
            const res = await deleteTutanakAttachment(tutanak.id, a.storagePath as string);
            setAttachments(res.attachments);
            addToast({ title: 'Ek silindi', message: 'Dosya tutanaktan kaldırıldı.', type: 'success' });
            await runRegen(res.attachments);
            onChanged();
          } catch (e) {
            addToast({ title: 'Ek silinemedi', message: friendlyTutanakError(e), type: 'error' });
          } finally {
            setAttachDeleting(null);
          }
        })();
      },
    });
  };

  const downloadAttachment = useCallback(
    async (a: TutanakAttachment) => {
      if (!a.storagePath) return;
      try {
        const c = await getTutanakAttachmentContent(tutanak.id, a.storagePath);
        downloadBytes(base64ToArrayBuffer(c.fileBase64), c.mimeType ?? a.mimeType, a.name);
      } catch (e) {
        addToast({ title: 'Ek indirilemedi', message: friendlyTutanakError(e), type: 'error' });
      }
    },
    [tutanak.id, addToast],
  );

  const attachmentSource = useCallback(
    (a: TutanakAttachment): PreviewDocumentSource => ({
      cacheKey: `att-${tutanak.id}-${a.storagePath}`,
      fileName: a.name,
      mimeType: a.mimeType,
      fileSize: a.size,
      getBytes: async () =>
        base64ToArrayBuffer((await getTutanakAttachmentContent(tutanak.id, a.storagePath as string)).fileBase64),
    }),
    [tutanak.id],
  );

  const handleOpenEmail = () => {
    const vw = typeof window !== 'undefined' ? window.innerWidth : 1280;
    const vh = typeof window !== 'undefined' ? window.innerHeight : 900;
    const id = openModal({
      title: 'E-posta Gönder',
      description: `${tutanak.typeName} - ${tutanak.firmaName}`,
      headerIcon: (
        <span className="w-9 h-9 rounded-lg bg-primary-500/15 dark:bg-primary-500/25 flex items-center justify-center">
          <i className="ri-mail-send-line text-primary-600 dark:text-primary-400 text-lg" />
        </span>
      ),
      variant: 'form',
      width: Math.min(vw - 48, 1080),
      height: Math.min(Math.max(vh - 80, 620), 960),
      minWidth: 520,
      minHeight: 560,
      showFooter: false,
      bodyLayout: 'fill',
      closable: true,
      resizable: true,
      minimizable: true,
      maximizable: true,
      content: (
        <TutanakEmailModal tutanak={tutanak} onClose={() => closeModal(id)} onSent={() => {}} />
      ),
    });
  };

  return (
    <div className="flex flex-1 min-h-0 flex-col gap-3">
      {/* Arşiv sürümü uyarısı (dinamik) */}
      {!isViewingActive && (
        <div className="flex items-center gap-2 rounded-md border border-warning-200/70 dark:border-warning-500/25 bg-warning-50 dark:bg-warning-500/10 px-3 py-2 flex-shrink-0">
          <i className="ri-history-line text-warning-600 dark:text-warning-400" />
          <p className="text-xs text-foreground-700 flex-1 min-w-0">
            Arşiv sürümü görüntüleniyor (Revizyon {viewing.revisionNo ?? 1}).
          </p>
          <Button variant="ghost" size="sm" onClick={() => setViewing(tutanak)}>
            Aktif Sürüme Dön
          </Button>
        </div>
      )}

      {/* İKİ KOLON — viewport yüksekliğini doldurur, ana modal kaymaz.
          Geniş ekranda panel içleri kendi kaydırmasını yönetir; dar ekranda
          (tablet/mobil) bölümler sırayla akabilmesi için kontrollü kaydırma açılır. */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row gap-3 overflow-y-auto lg:overflow-hidden isg-scroll-pane">
        {/* SOL — belge önizleme (okunabilir ölçek) */}
        <div className="flex-1 min-w-0 min-h-[280px] rounded-lg border border-background-300/50 dark:border-background-400/25 overflow-hidden bg-background-50 dark:bg-background-100 flex flex-col">
          {viewing.originalFileName || viewing.id ? (
            <DocumentPreviewEngine
              key={viewing.id}
              source={source}
              title={viewing.title}
              defaultFit="width"
              onDownload={() => downloadEvrak(viewing)}
              downloadBusy={busyDownload}
              className="flex-1 min-h-0"
            />
          ) : (
            <EmptyState
              icon="ri-file-unknow-line"
              title="Önizlenecek belge yok"
              description="Bu tutanak için yüklenmiş bir dosya bulunmuyor."
            />
          )}
        </div>

        {/* SAĞ — belge bilgileri / işlemler / sürüm / ekler / geçmiş */}
        <aside className="w-full lg:w-[360px] xl:w-[400px] flex-shrink-0 min-h-0 flex flex-col rounded-lg border border-background-300/50 dark:border-background-400/25 overflow-hidden bg-background-50 dark:bg-background-100">
          <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane p-2.5 flex flex-col gap-2.5">
            {/* BELGE BİLGİLERİ — sadeleştirilmiş (aynı bilgi tekrarı yok) */}
            <Section title="Belge Bilgileri" icon="ri-information-line">
              <div className="flex items-start gap-2.5 rounded-md bg-background-100 dark:bg-background-200/50 px-2.5 py-2 mb-1">
                <span className="w-9 h-9 rounded-md bg-primary-100 dark:bg-primary-500/20 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
                  <i className="ri-file-text-line text-base" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold text-foreground-900 truncate" title={tutanak.typeName}>{tutanak.typeName}</p>
                  <p className="text-[11px] text-foreground-500">{tutanak.tutanakNo ? `${tutanak.tutanakNo} · ` : ''}Rev.{tutanak.revisionNo ?? 1}</p>
                </div>
                <Badge variant={belgeDurumuVariant(tutanak.belgeDurumu)}>{tutanak.belgeDurumuLabel}</Badge>
              </div>
              <InfoRow label="Firma" value={tutanak.firmaName} />
              {tutanak.personelName && <InfoRow label="İlgili Personel" value={tutanak.personelName} />}
              {tutanak.documentDate && <InfoRow label="Belge Tarihi" value={formatEvrakDate(tutanak.documentDate)} />}
              <InfoRow label="Oluşturan" value={tutanak.uploaderName} />

              {/* Firma Görünürlüğü */}
              {canManage ? (
                <div className="flex items-center justify-between gap-3 rounded-md bg-background-100 dark:bg-background-200/50 px-3 py-2 mt-1.5">
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-foreground-700">Firma Görünürlüğü</p>
                    <p className="text-[11px] text-foreground-500 flex items-center gap-1 mt-0.5">
                      <i className="ri-information-line" />
                      {visible ? 'Firma tutanaklarında gösteriliyor' : 'Firma tutanaklarında gizli'}
                    </p>
                  </div>
                  <Toggle
                    label="Görünürlük"
                    checked={visible}
                    disabled={toggling}
                    onChange={(e) => handleToggleVisible(e.target.checked)}
                  />
                </div>
              ) : (
                <InfoRow
                  label="Firma Görünürlüğü"
                  value={<Badge variant={visible ? 'success' : 'default'}>{visible ? 'Gösteriliyor' : 'Gizli'}</Badge>}
                />
              )}
            </Section>

            {/* İŞLEMLER */}
            <Section title="İşlemler" icon="ri-tools-line">
              <ActionButton icon="ri-download-2-line" label="İndir" onClick={() => downloadEvrak(viewing)} busy={busyDownload} />
              {hasPdfModel && (
                <ActionButton icon="ri-file-pdf-2-line" label="PDF İndir" onClick={() => void handleDownloadPdf()} busy={pdfBusy} />
              )}
              {canPrint && <ActionButton icon="ri-printer-line" label="Yazdır" onClick={handlePrint} />}
              {hasPdfModel && (
                <ActionButton icon="ri-printer-line" label="PDF Yazdır" onClick={() => void handlePrintPdf()} busy={pdfBusy} />
              )}
              {canManage && <ActionButton icon="ri-mail-send-line" label="E-posta Gönder" onClick={handleOpenEmail} />}
              {/* Taslağı düzenle: YALNIZCA aktif ve Taslak (draft) revizyonda. */}
              {canManage && isViewingActive && tutanak.belgeDurumu === 'draft' && onEdit && (
                <ActionButton icon="ri-edit-2-line" label="Düzenle" onClick={() => onEdit(tutanak)} />
              )}
              {/* İmzalı nihai belge yükleme: YALNIZCA aktif ve henüz imzalanmamış revizyonda. */}
              {canManage && isViewingActive && isUnsigned && onAddSigned && (
                <ActionButton
                  icon="ri-shield-check-line"
                  label="İmzalı Tutanak Ekle"
                  onClick={() => onAddSigned(tutanak)}
                />
              )}
              {/* Yeni revizyon: YALNIZCA aktif ve tamamlanmış revizyondan üretilir. */}
              {canManage && isViewingActive && !isUnsigned && onNewRevision && (
                <ActionButton
                  icon="ri-git-branch-line"
                  label="Yeni Revizyon Oluştur"
                  onClick={() => onNewRevision(tutanak)}
                />
              )}
              {!isViewingActive && (
                <p className="text-[11px] text-foreground-500 px-1 pt-1">
                  Geçmiş revizyon yalnızca görüntülenebilir ve indirilebilir; düzenlenemez ve imzalı belge yüklenemez.
                </p>
              )}
            </Section>

            {/* EKLER */}
            <Section title={`Ekler${attachments.length ? ` (${attachments.length})` : ''}`} icon="ri-attachment-2">
              {attachments.length === 0 && <p className="text-xs text-foreground-500 py-1">Bu tutanağa bağlı ek dosya yok.</p>}
              {attachments.map((a, i) => (
                <div
                  key={`${a.storagePath ?? a.name}-${i}`}
                  className="flex items-center justify-between gap-2 rounded-md bg-background-100 dark:bg-background-200/50 px-2.5 py-2"
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <i className={`${evrakFileIcon(a.mimeType, a.name)} text-foreground-500`} />
                    <div className="min-w-0">
                      <p className="text-xs font-medium text-foreground-800 truncate">{a.name}</p>
                      <p className="text-[11px] text-foreground-500">{formatEvrakSize(a.size)}</p>
                    </div>
                  </div>
                  {a.storagePath ? (
                    <div className="flex items-center gap-0.5 flex-shrink-0">
                      <button
                        type="button"
                        className={NAV_BTN}
                        title="Görüntüle"
                        aria-label="Eki görüntüle"
                        onClick={() => setAttachmentPreview(a)}
                      >
                        <i className="ri-eye-line text-sm" />
                      </button>
                      <button
                        type="button"
                        className={NAV_BTN}
                        title="İndir"
                        aria-label="Eki indir"
                        onClick={() => downloadAttachment(a)}
                      >
                        <i className="ri-download-2-line text-sm" />
                      </button>
                      {canManage && isUnsigned && (
                        <button
                          type="button"
                          className={NAV_BTN}
                          title="Sil"
                          aria-label="Eki sil"
                          disabled={attachDeleting === a.storagePath}
                          onClick={() => handleDeleteAttachment(a)}
                        >
                          <i className={`${attachDeleting === a.storagePath ? 'ri-loader-4-line animate-spin' : 'ri-delete-bin-line'} text-sm`} />
                        </button>
                      )}
                    </div>
                  ) : (
                    <span className="text-[11px] text-foreground-400 flex-shrink-0">dosya yok</span>
                  )}
                </div>
              ))}

              {canManage && (
                <div className="rounded-md border border-background-300/40 dark:border-background-400/25 bg-background-100 dark:bg-background-200/40 p-2.5 flex flex-col gap-2 mt-1">
                  <p className="text-xs text-foreground-500">Tutanağa ek dosya (PDF/Word/Excel/görsel) ekleyin.</p>
                  <FileUpload
                    label="Ek Dosya"
                    accept={ATTACH_ACCEPT}
                    multiple={false}
                    maxSize={MAX_SIZE}
                    files={attachFiles}
                    onChange={setAttachFiles}
                    dropClassName="p-3"
                  />
                  <Button
                    variant="secondary"
                    size="sm"
                    leftIcon={<i className="ri-attachment-line" />}
                    onClick={handleUploadAttachment}
                    isLoading={attachUploading}
                    disabled={!attachFiles[0]?.raw}
                  >
                    Eki Yükle
                  </Button>
                </div>
              )}
            </Section>

            {/* BELGE GEÇMİŞİ */}
            <Section title={`Belge Geçmişi${allRevisions.length > 1 ? ` (${allRevisions.length})` : ''}`} icon="ri-history-line">
              {historyLoading && <p className="text-xs text-foreground-500 py-1">Geçmiş yükleniyor…</p>}
              {allRevisions.map((rev) => {
                const activeRow = rev.id === tutanak.id;
                const lbl = revisionLabel(rev, activeRow);
                return (
                  <div
                    key={rev.id}
                    className={`flex items-center justify-between gap-2 rounded-md px-2.5 py-2 ${
                      rev.id === viewing.id
                        ? 'bg-primary-50 dark:bg-primary-500/10 border border-primary-200/60 dark:border-primary-500/25'
                        : 'bg-background-100 dark:bg-background-200/50'
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-foreground-800">
                        Revizyon {rev.revisionNo ?? 1}
                        {activeRow && <span className="text-success-600"> · Aktif</span>}
                      </p>
                      <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                        <Badge variant={lbl.variant}>{lbl.label}</Badge>
                        <span className="text-[11px] text-foreground-500">{formatEvrakDateTime(rev.createdAt)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-0.5 flex-shrink-0">
                      <button
                        type="button"
                        className={NAV_BTN}
                        title="Bu sürümü görüntüle"
                        aria-label="Bu sürümü görüntüle"
                        onClick={() => setViewing(rev)}
                      >
                        <i className="ri-eye-line text-sm" />
                      </button>
                      <button
                        type="button"
                        className={NAV_BTN}
                        title="Bu sürümü indir"
                        aria-label="Bu sürümü indir"
                        onClick={() => downloadEvrak(rev)}
                      >
                        <i className="ri-download-2-line text-sm" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </Section>
          </div>
        </aside>
      </div>

      {/* EK ÖNİZLEME (tam ekran, merkezi motor) */}
      {attachmentPreview && attachmentPreview.storagePath && (
        <DocumentPreviewModal
          source={attachmentSource(attachmentPreview)}
          title={attachmentPreview.name}
          onDownload={() => downloadAttachment(attachmentPreview)}
          onClose={() => setAttachmentPreview(null)}
        />
      )}
    </div>
  );
}