import { useState, useCallback, useRef, useMemo } from 'react';
import useSWR from 'swr';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import FilterBar from '@/components/ui/FilterBar';
import type { FilterField, FilterValue } from '@/components/ui/FilterBar';
import Pagination from '@/components/ui/Pagination';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import Loading from '@/components/ui/Loading';
import StatCard from '@/components/ui/StatCard';
import IconButton from '@/components/ui/IconButton';
import ActionMenu from '@/components/ui/ActionMenu';
import SharedListCard, { ListCardBadge } from '@/components/ui/SharedListCard';
import { useModalActions } from '@/hooks/useModal';
import {
  type ZimmetListItem,
  type ZimmetDurum,
  fetchZimmetlerPage,
  fetchZimmetOzet,
  friendlyZimmetError,
} from '@/lib/zimmetService';
import { zimmetDurumVariant, zimmetDurumIcon, envanterTuruIcon, formatZimmetDate } from './zimmetUi';
import ZimmetDetailModal from './ZimmetDetailModal';

function asStr(v: FilterValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

function envanterTuruLabel(turu: string | null | undefined): string {
  if (turu === 'arac') return 'Araç';
  if (turu === 'bilgisayar') return 'Bilgisayar';
  if (turu === 'diger') return 'Diğer';
  return '—';
}

// Sıralama seçenekleri → mevcut 'list' aksiyonunun desteklediği alanlara eşlenir.
// (Backend'e yeni sıralama alanı eklenmez.)
function sortParams(v: string): { sortBy: 'zimmet_tarihi' | 'created_at' | 'updated_at'; sortDir: 'asc' | 'desc' } {
  if (v === 'zimmet_asc') return { sortBy: 'zimmet_tarihi', sortDir: 'asc' };
  if (v === 'created_desc') return { sortBy: 'created_at', sortDir: 'desc' };
  return { sortBy: 'zimmet_tarihi', sortDir: 'desc' };
}

const TUR_OPTIONS = [
  { value: 'arac', label: 'Araç' },
  { value: 'bilgisayar', label: 'Bilgisayar' },
  { value: 'diger', label: 'Diğer' },
];

const SIRALA_OPTIONS = [
  { value: 'zimmet_desc', label: 'Zimmet Tarihi (Yeni → Eski)' },
  { value: 'zimmet_asc', label: 'Zimmet Tarihi (Eski → Yeni)' },
  { value: 'created_desc', label: 'En Son Eklenen' },
];

/**
 * Personel (Uzman / Hekim / DSP) "Zimmetlerim" listesi — görsel referans birebir.
 * Üstte KPI kartları, sonra arama + Tür / Durum / Sırala filtreleri ve
 * envanter + zimmet durumu kolonlu liste. Tüm veri mevcut zimmet servisinden gelir;
 * backend'e yeni alan eklenmez. Satıra tıklayınca zimmet detay modalı açılır.
 */
export default function ZimmetlerimList() {
  const { openModal, closeModal } = useModalActions();
  const detailModalIdRef = useRef('');

  const [search, setSearch] = useState('');
  const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const buildQuery = useCallback(
    () => {
      const { sortBy, sortDir } = sortParams(asStr(filterValues['sirala']) || 'zimmet_desc');
      return {
        search: search || undefined,
        durum: (asStr(filterValues['durum']) as ZimmetDurum | '') || '',
        tur: asStr(filterValues['tur']) || '',
        sortBy,
        sortDir,
        page,
        pageSize,
      };
    },
    [search, filterValues, page, pageSize],
  );

  const queryKey = useMemo(() => JSON.stringify(buildQuery()), [buildQuery]);
  const { data, error, isLoading, mutate } = useSWR(
    ['zimmetler', queryKey],
    () => fetchZimmetlerPage(buildQuery()),
  );
  const { data: ozet, mutate: mutateOzet } = useSWR('zimmet-ozet', fetchZimmetOzet);

  const turFilter = asStr(filterValues['tur']);
  // Tür filtresi SERVER-SIDE uygulanır (count ve sayfalama filtrelenmiş kümeden gelir).
  const rows = data?.data ?? [];
  const count = data?.count ?? 0;
  const loading = isLoading;
  const errorMsg = error ? friendlyZimmetError(error) : null;

  const handleOpenDetail = useCallback(
    (zimmet: ZimmetListItem) => {
      const id = openModal({
        title: 'Zimmet Detayı',
        description: zimmet.envanter?.envanter_kodu ? `Kod: ${zimmet.envanter.envanter_kodu}` : undefined,
        variant: 'detail',
        width: 1100,
        minWidth: 440,
        minHeight: 520,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        bodyLayout: 'fill',
        content: (
          <ZimmetDetailModal
            zimmetId={zimmet.id}
            onClose={() => closeModal(detailModalIdRef.current)}
            onChanged={() => { mutate(); mutateOzet(); }}
          />
        ),
      });
      detailModalIdRef.current = id;
    },
    [openModal, closeModal, mutate, mutateOzet],
  );

  const filters = useMemo<FilterField[]>(
    () => [
      {
        key: 'tur',
        label: 'Tür',
        type: 'status',
        placeholder: 'Tür — Tümü',
        options: TUR_OPTIONS,
      },
      {
        key: 'durum',
        label: 'Durum',
        type: 'status',
        placeholder: 'Durum — Tümü',
        options: [
          { value: 'bekliyor', label: 'Onay Bekliyor' },
          { value: 'aktif', label: 'Zimmetli' },
          { value: 'iade_talebi', label: 'İade Talebi' },
          { value: 'iade_onayi_bekliyor', label: 'İade Onayı Bekliyor' },
          { value: 'kapatildi', label: 'Kapatıldı' },
        ],
      },
      {
        key: 'sirala',
        label: 'Sırala',
        type: 'status',
        placeholder: 'Sırala',
        options: SIRALA_OPTIONS,
      },
    ],
    [],
  );

  const columns: TableColumn<ZimmetListItem>[] = [
    {
      key: 'envanter',
      header: 'Envanter',
      render: (r) => (
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="w-9 h-9 rounded-lg bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
            <i className={`${envanterTuruIcon(r.envanter?.envanter_turu)} text-foreground-600 dark:text-foreground-400`} />
          </span>
          <span className="text-sm font-medium text-foreground-800 truncate">{r.envanter?.ad || '—'}</span>
        </div>
      ),
    },
    {
      key: 'kod',
      header: 'Envanter Kodu',
      render: (r) => <span className="text-sm text-foreground-700">{r.envanter?.envanter_kodu || '—'}</span>,
    },
    {
      key: 'turu',
      header: 'Tür',
      render: (r) => (
        <Badge variant="secondary" leftIcon={<i className={envanterTuruIcon(r.envanter?.envanter_turu)} />}>
          {envanterTuruLabel(r.envanter?.envanter_turu)}
        </Badge>
      ),
    },
    {
      key: 'zimmetTarihi',
      header: 'Zimmet Tarihi',
      render: (r) => <span className="text-sm text-foreground-600">{formatZimmetDate(r.zimmetTarihi)}</span>,
    },
    {
      key: 'kabulTarihi',
      header: 'Kabul Tarihi',
      render: (r) => <span className="text-sm text-foreground-600">{formatZimmetDate(r.kabulTarihi)}</span>,
    },
    {
      key: 'durum',
      header: 'Zimmet Durumu',
      render: (r) => (
        <Badge variant={zimmetDurumVariant(r.durum)} leftIcon={<i className={zimmetDurumIcon(r.durum)} />}>
          {r.durumLabel}
        </Badge>
      ),
    },
  ];

  const totalPages = Math.max(1, Math.ceil(count / pageSize));

  return (
    <div className="isg-page">
      <PageHeader title="Zimmetlerim" subtitle="Tarafınıza zimmetlenen envanterlerin listesi" className="flex-shrink-0" />

      {/* KPI kartları (salt-okuma özet) */}
      <div className="isg-stat-grid">
        <StatCard
          title="Toplam Zimmet"
          value={ozet ? ozet.toplam : '—'}
          icon="ri-archive-2-line"
          iconBg="bg-primary-50 dark:bg-primary-500/15"
          iconColor="text-primary-600 dark:text-primary-400"
        />
        <StatCard
          title="Zimmetli"
          value={ozet ? ozet.zimmetli : '—'}
          icon="ri-checkbox-circle-line"
          iconBg="bg-success-50 dark:bg-success-500/15"
          iconColor="text-success-600 dark:text-success-400"
        />
        <StatCard
          title="Onay Bekleyen"
          value={ozet ? ozet.bekleyen : '—'}
          icon="ri-time-line"
          iconBg="bg-warning-50 dark:bg-warning-500/15"
          iconColor="text-warning-600 dark:text-warning-400"
        />
        <StatCard
          title="İade Sürecinde"
          value={ozet ? ozet.iadeSurecinde : '—'}
          icon="ri-arrow-go-back-line"
          iconBg="bg-secondary-100 dark:bg-secondary-500/15"
          iconColor="text-secondary-700 dark:text-secondary-400"
        />
      </div>

      <div className="isg-card flex flex-col p-3">
        <FilterBar
          filters={filters}
          values={filterValues}
          onChange={(key, value) => {
            setFilterValues((prev) => ({ ...prev, [key]: value }));
            setPage(1);
          }}
          onReset={() => {
            setFilterValues({});
            setSearch('');
            setPage(1);
          }}
          onSearch={(v) => { setSearch(v); setPage(1); }}
          searchPlaceholder="Ara... envanter kodu, ad, marka, model, seri no, zimmetli kişi"
          searchDebounceMs={400}
        />

        <div className="mt-3 flex-1 min-h-0">
          {loading ? (
            <div className="flex justify-center py-16">
              <Loading size="lg" text="Zimmetler yükleniyor..." />
            </div>
          ) : errorMsg ? (
            <ErrorState message={errorMsg} onRetry={() => mutate()} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon="ri-handbag-line"
              title={search || asStr(filterValues['durum']) || turFilter ? 'Sonuç bulunamadı' : 'Henüz zimmet bulunmuyor.'}
              description={search || asStr(filterValues['durum']) || turFilter ? 'Seçtiğiniz filtrelere uygun zimmet yok.' : 'Size atanan zimmetler burada listelenir.'}
            />
          ) : (
            <>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-foreground-500">
                  Toplam <span className="font-semibold text-foreground-800">{count}</span> zimmet
                </p>
              </div>
              <div className="overflow-x-auto">
                <Table
                  data={rows}
                  columns={columns}
                  keyExtractor={(r) => r.id}
                  onRowClick={handleOpenDetail}
                  rowActions={(row) => (
                    <>
                      <IconButton
                        icon={<i className="ri-eye-line" />}
                        variant="ghost"
                        size="sm"
                        label="Detay"
                        onClick={() => handleOpenDetail(row)}
                      />
                      <ActionMenu
                        items={[{ label: 'Detayı Aç', icon: 'ri-eye-line', onClick: () => handleOpenDetail(row) }]}
                      />
                    </>
                  )}
                  mobileCardRenderer={(row) => (
                    <SharedListCard
                      recordNo={`#${row.envanter?.envanter_kodu || ''}`}
                      icon={envanterTuruIcon(row.envanter?.envanter_turu)}
                      iconBg="bg-primary-50 dark:bg-primary-500/20"
                      iconColor="text-primary-600 dark:text-primary-400"
                      title={row.envanter?.ad || '—'}
                      description={envanterTuruLabel(row.envanter?.envanter_turu)}
                      badges={[
                        <ListCardBadge key="durum" variant={zimmetDurumVariant(row.durum)}>{row.durumLabel}</ListCardBadge>,
                      ]}
                      metadata={[
                        { label: 'Zimmet', value: formatZimmetDate(row.zimmetTarihi) },
                      ]}
                      onClick={() => handleOpenDetail(row)}
                    />
                  )}
                />
              </div>
              <div className="mt-3 pt-3 border-t border-background-300/25 dark:border-background-400/25">
                <Pagination
                  currentPage={page}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={count}
                  onPageChange={setPage}
                  onPageSizeChange={(size) => {
                    setPageSize(size);
                    setPage(1);
                  }}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}