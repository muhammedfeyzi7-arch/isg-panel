import { useState } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import DatePicker from '@/components/ui/DatePicker';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import { useToastActions } from '@/hooks/useToast';
import {
  createAracOperasyon,
  friendlyOperasyonError,
  YAKIT_TURU_OPTIONS,
  type AracOperasyonTur,
} from '@/lib/operasyonService';
import DosyaSecici, { type SeciliDosya } from '@/components/feature/operasyon/DosyaSecici';

interface FisEkleModalProps {
  envanterId: string;
  envanterAd?: string;
  envanterKod?: string;
  onClose: () => void;
  onSaved: () => void;
}

// Fiş kaydı türleri (referans görsel: Yakıt / Yıkama / Tamir / Servis / Gider).
const FIS_TUR_OPTIONS: { value: AracOperasyonTur; label: string }[] = [
  { value: 'yakit', label: 'Yakıt Fişi' },
  { value: 'yikama', label: 'Yıkama Fişi' },
  { value: 'tamir', label: 'Tamir Fişi' },
  { value: 'servis', label: 'Servis Fişi' },
  { value: 'diger_gider', label: 'Gider Fişi' },
];

function bugunIso(): string {
  return new Date().toISOString().slice(0, 10);
}

/**
 * "Fiş Kaydı Ekle" modalı (Uzman / Hekim / DSP). Sol: fiş görseli + yükleme.
 * Sağ: kayıt türüne uygun alanlar. Tüm alanlar OPSİYONELDİR (zorunlu yok).
 * Mevcut operasyon/service/storage yapısı kullanılır; türe özel ek alanlar
 * backend'deki additive `metadata` kolonunda saklanır.
 */
export default function FisEkleModal({ envanterId, envanterAd, envanterKod, onClose, onSaved }: FisEkleModalProps) {
  const { addToast } = useToastActions();

  const [tur, setTur] = useState<AracOperasyonTur>('yakit');
  const [tarih, setTarih] = useState(bugunIso());
  const [fisNo, setFisNo] = useState('');
  const [istasyon, setIstasyon] = useState('');
  const [yakitTuru, setYakitTuru] = useState('');
  const [litre, setLitre] = useState('');
  const [birimFiyat, setBirimFiyat] = useState('');
  const [tutar, setTutar] = useState('');
  const [kilometre, setKilometre] = useState('');
  const [aciklama, setAciklama] = useState('');
  const [files, setFiles] = useState<SeciliDosya[]>([]);
  const [submitError, setSubmitError] = useState('');
  const [loading, setLoading] = useState(false);

  const isYakit = tur === 'yakit';

  // Toplam tutar boşsa ve litre + birim fiyat girildiyse otomatik hesapla.
  const handleLitre = (v: string) => {
    setLitre(v);
    if (tutar === '' && birimFiyat !== '' && v !== '') {
      const t = Number(v) * Number(birimFiyat);
      if (Number.isFinite(t)) setTutar(String(t));
    }
  };
  const handleBirim = (v: string) => {
    setBirimFiyat(v);
    if (tutar === '' && litre !== '' && v !== '') {
      const t = Number(litre) * Number(v);
      if (Number.isFinite(t)) setTutar(String(t));
    }
  };

  const handleSubmit = async () => {
    if (loading) return;
    setLoading(true);
    setSubmitError('');
    try {
      await createAracOperasyon({
        kind: tur,
        envanterId,
        tarih: tarih || null,
        yakitTuru: isYakit ? (yakitTuru || null) : null,
        litre: isYakit && litre !== '' ? Number(litre) : null,
        tutar: tutar !== '' ? Number(tutar) : null,
        aciklama: aciklama.trim() || null,
        metadata: {
          fisNo: fisNo.trim() || null,
          istasyonFirma: istasyon.trim() || null,
          birimFiyat: birimFiyat !== '' ? Number(birimFiyat) : null,
          kilometre: kilometre !== '' ? Number(kilometre) : null,
        },
        files: files.map((f) => f.file),
      });
      addToast({ title: 'Kayıt oluşturuldu', message: 'Fiş kaydı başarıyla eklendi.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      const msg = friendlyOperasyonError(e);
      setSubmitError(msg);
      addToast({ title: 'İşlem başarısız', message: msg, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full min-h-0 gap-3">
      {/* Mini başlık kartı (referans): araç adı + kod + tür + zimmetli rozeti */}
      {envanterAd && (
        <div className="flex items-center gap-3 p-3 isg-section">
          <div className="w-11 h-11 rounded-xl bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-car-line text-primary-600 dark:text-primary-400 text-lg" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm font-semibold text-foreground-950 truncate">{envanterAd}</h3>
              <span className="inline-flex items-center gap-1 text-xs text-success-700 dark:text-success-400 font-medium">
                <i className="ri-checkbox-circle-fill text-success-500" />
                Zimmetli
              </span>
            </div>
            <p className="text-xs text-foreground-500 mt-0.5">
              {envanterKod && <>Kod: <span className="font-medium text-foreground-700">{envanterKod}</span><span className="mx-2 text-foreground-300">|</span></>}
              Tür: <span className="font-medium text-foreground-700">Araç</span>
            </p>
          </div>
        </div>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto pr-0.5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {/* SOL: Fiş görseli */}
          <div className="isg-card isg-card-pad">
            <h3 className="isg-text-card-title text-foreground-950 mb-3">Fiş Görseli</h3>
            <DosyaSecici
              label=""
              files={files}
              onChange={setFiles}
              helpText="Sürekli birkaç veya tıklayarak seçin · JPG, PNG, PDF (Maks. 10 MB)"
            />
          </div>

          {/* SAĞ: Fiş bilgileri */}
          <div className="isg-card isg-card-pad">
            <h3 className="isg-text-card-title text-foreground-950 mb-3">Fiş Bilgileri</h3>
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Select
                  label="Kayıt Türü"
                  options={FIS_TUR_OPTIONS}
                  value={tur}
                  onChange={(e) => setTur(e.target.value as AracOperasyonTur)}
                />
                <DatePicker label="Tarih" value={tarih} onChange={(e) => setTarih(e.target.value)} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input label="Fiş No" placeholder="Ör. YPZ2026000123" value={fisNo} onChange={(e) => setFisNo(e.target.value)} />
                <Input
                  label={isYakit ? 'İstasyon / Firma' : 'Firma'}
                  placeholder={isYakit ? 'Ör. Opet' : 'Ör. Servis adı'}
                  value={istasyon}
                  onChange={(e) => setIstasyon(e.target.value)}
                />
              </div>

              {isYakit && (
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <Select
                    label="Yakıt Türü"
                    options={YAKIT_TURU_OPTIONS}
                    value={yakitTuru}
                    onChange={(e) => setYakitTuru(e.target.value)}
                    placeholder="Seçiniz"
                  />
                  <Input label="Litre" type="number" min={0} step="0.01" placeholder="Ör. 34,25" value={litre} onChange={(e) => handleLitre(e.target.value)} />
                  <Input label="Birim Fiyat (₺)" type="number" min={0} step="0.01" placeholder="Ör. 21,90" value={birimFiyat} onChange={(e) => handleBirim(e.target.value)} />
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input label="Toplam Tutar (₺)" type="number" min={0} step="0.01" placeholder="Ör. 750,00" value={tutar} onChange={(e) => setTutar(e.target.value)} />
                <Input label="Kilometre" type="number" min={0} step="1" placeholder="Ör. 28.560" value={kilometre} onChange={(e) => setKilometre(e.target.value)} />
              </div>

              <Textarea
                label="Açıklama"
                placeholder="Kısa açıklama (opsiyonel)"
                value={aciklama}
                onChange={(e) => setAciklama(e.target.value)}
                maxLength={500}
              />
            </div>
          </div>
        </div>

        {submitError && <Alert variant="danger" className="mt-3">{submitError}</Alert>}
      </div>

      <div className="flex-shrink-0 flex justify-end gap-2 pt-3 border-t border-background-300/20 dark:border-background-400/20">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={loading}>İptal</Button>
        <Button variant="primary" size="sm" isLoading={loading} onClick={handleSubmit} leftIcon={<i className="ri-save-line" />}>
          Fişi Kaydet
        </Button>
      </div>
    </div>
  );
}