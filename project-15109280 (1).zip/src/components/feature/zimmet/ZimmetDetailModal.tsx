import { useState, useEffect, useRef } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import ImageViewer from '@/components/ui/ImageViewer';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import { useAuth } from '@/context/AuthContext';
import {
  fetchZimmet,
  zimmetDurumLabel,
  kapanisNedeniLabel,
  friendlyZimmetError,
  rejectZimmet,
  zimmetOsgbIadeOnayla,
  type ZimmetDetail,
} from '@/lib/zimmetService';
import {
  zimmetDurumVariant,
  zimmetDurumIcon,
  envanterTuruIcon,
  formatZimmetDate,
  formatZimmetDateTime,
} from './zimmetUi';
import ZimmetTeslimModal from './ZimmetTeslimModal';
import ZimmetDusurModal from './ZimmetDusurModal';
import ZimmetIadeModal from './ZimmetIadeModal';
import ZimmetEnvanterPersonelGorunum from './ZimmetEnvanterPersonelGorunum';
import { ListSkeleton } from '@/components/ui/Skeleton';

interface ZimmetDetailModalProps {
  zimmetId: string;
  onClose: () => void;
  onChanged: () => void;
}

const TUR_LABEL: Record<string, string> = {
  arac: 'Araç',
  bilgisayar: 'Bilgisayar',
  diger: 'Diğer',
};

const YAKIT_LABEL: Record<string, string> = {
  benzin: 'Benzin',
  dizel: 'Dizel',
  lpg: 'LPG',
  elektrik: 'Elektrik',
  hibrit: 'Hibrit',
};

const ROL_LABEL: Record<string, string> = {
  admin: 'Sistem Yöneticisi',
  osgb_admin: 'OSGB Yöneticisi',
};

// Zimmet durumu → kısa açıklama (üst durum bloğu).
const DURUM_ACIKLAMA: Record<string, string> = {
  bekliyor: 'Tarafınıza zimmet atanmıştır.',
  aktif: 'Zimmet aktif; envanter teslim alındı.',
  iade_talebi: 'Zimmetiniz için iade talebi başlatıldı.',
  iade_onayi_bekliyor: 'İade işlemi gönderildi, onay bekleniyor.',
  kapatildi: 'Zimmet kapatıldı.',
};

// Durum bloğu renk tonları (tasarım dili: soft yüzey + güçlü metin).
const DURUM_TONE: Record<string, { box: string; icon: string; title: string }> = {
  bekliyor: { box: 'bg-warning-50 dark:bg-warning-500/10 border-warning-200/70 dark:border-warning-500/30', icon: 'ri-time-line text-warning-600 dark:text-warning-400', title: 'text-warning-800 dark:text-warning-300' },
  aktif: { box: 'bg-success-50 dark:bg-success-500/10 border-success-200/70 dark:border-success-500/30', icon: 'ri-checkbox-circle-line text-success-600 dark:text-success-400', title: 'text-success-800 dark:text-success-300' },
  iade_talebi: { box: 'bg-primary-50 dark:bg-primary-500/10 border-primary-200/70 dark:border-primary-500/30', icon: 'ri-arrow-go-back-line text-primary-600 dark:text-primary-400', title: 'text-primary-800 dark:text-primary-300' },
  iade_onayi_bekliyor: { box: 'bg-accent-100 dark:bg-accent-500/10 border-accent-300/70 dark:border-accent-500/30', icon: 'ri-hourglass-line text-accent-700 dark:text-accent-400', title: 'text-accent-900 dark:text-accent-300' },
  kapatildi: { box: 'bg-background-100 dark:bg-background-300/20 border-background-300/60 dark:border-background-400/30', icon: 'ri-archive-line text-foreground-500', title: 'text-foreground-700' },
};

function turuLabel(t: string | null | undefined): string {
  return (t && TUR_LABEL[t]) || '—';
}

function personelRolLabel(turu: string | null | undefined): string {
  if (turu === 'isg_uzmani') return 'İş Güvenliği Uzmanı';
  if (turu === 'isyeri_hekimi') return 'İşyeri Hekimi';
  if (turu === 'dsp') return 'DSP';
  if (turu === 'isg_teknikeri') return 'İSG Teknikeri';
  return '—';
}

function rolEtiket(role: string | null | undefined): string {
  if (!role) return '';
  return ROL_LABEL[role] ?? role;
}

/**
 * Zimmet detay modalı (görsel referans birebir — tek görünüm).
 * Üst başlık + 3 kolon (Fotoğraflar / Temel Bilgiler / Zimmet Bilgisi + İşlemler +
 * Türe Özel Bilgiler) + alt bilgi çubuğu. Araç ve bilgisayar için aynı yerleşim
 * kullanılır; yalnızca türe özel alanlar değişir. Veri tamamen mevcut servisten gelir.
 */
export default function ZimmetDetailModal({ zimmetId, onClose, onChanged }: ZimmetDetailModalProps) {
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();
  const { openModal, closeModal } = useModalActions();
  const { profile } = useAuth();

  const [detail, setDetail] = useState<ZimmetDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const subModalIdRef = useRef('');

  const role = profile?.role;
  const isOsgb = role === 'admin' || role === 'osgb_admin';

  const load = () => {
    setLoading(true);
    setError(null);
    fetchZimmet(zimmetId)
      .then(setDetail)
      .catch((e) => setError(friendlyZimmetError(e)))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [zimmetId]);

  const openSub = (content: React.ReactNode) => {
    const id = openModal({
      title: 'Zimmet İşlemi',
      width: 560,
      minWidth: 440,
      minHeight: 420,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content,
    });
    subModalIdRef.current = id;
    return id;
  };

  const handleTeslim = () => {
    openSub(
      <ZimmetTeslimModal
        zimmetId={zimmetId}
        onClose={() => closeModal(subModalIdRef.current)}
        onSaved={() => { load(); onChanged(); }}
      />,
    );
  };

  const handleDusur = () => {
    openSub(
      <ZimmetDusurModal
        zimmetId={zimmetId}
        onClose={() => closeModal(subModalIdRef.current)}
        onSaved={() => { load(); onChanged(); }}
      />,
    );
  };

  const handleIade = (mode: 'osgb_iade_talebi' | 'personel_iade') => {
    openSub(
      <ZimmetIadeModal
        zimmetId={zimmetId}
        mode={mode}
        onClose={() => closeModal(subModalIdRef.current)}
        onSaved={() => { load(); onChanged(); }}
      />,
    );
  };

  const handleReject = () => {
    confirm({
      title: 'Zimmeti Reddet',
      message: 'Bu zimmeti reddetmek istediğinize emin misiniz? Zimmet kapatılır ve envanter yeniden zimmetlenebilir duruma gelir.',
      variant: 'warning',
      confirmText: 'Evet, Reddet',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setBusy(true);
        rejectZimmet(zimmetId)
          .then(() => {
            addToast({ title: 'Zimmet reddedildi', message: 'Zimmet kapatıldı.', type: 'success' });
            load();
            onChanged();
          })
          .catch((e) => addToast({ title: 'İşlem başarısız', message: friendlyZimmetError(e), type: 'error' }))
          .finally(() => setBusy(false));
      },
    });
  };

  const handleIadeOnayla = () => {
    confirm({
      title: 'İadeyi Onayla ve Kapat',
      message: 'İade onaylanacak ve zimmet kapatılacak. Envanter yeniden zimmetlenebilir duruma gelecek.',
      variant: 'primary',
      confirmText: 'Evet, Onayla ve Kapat',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        setBusy(true);
        zimmetOsgbIadeOnayla(zimmetId)
          .then(() => {
            addToast({ title: 'İade onaylandı', message: 'Zimmet kapatıldı.', type: 'success' });
            load();
            onChanged();
          })
          .catch((e) => addToast({ title: 'İşlem başarısız', message: friendlyZimmetError(e), type: 'error' }))
          .finally(() => setBusy(false));
      },
    });
  };

  if (loading) {
    return <ListSkeleton rows={5} />;
  }
  if (error || !detail) {
    return (
      <div className="py-12 text-center">
        <p className="text-sm text-danger-600">{error || 'Zimmet bulunamadı'}</p>
        <button onClick={load} className="mt-3 text-sm text-primary-600 hover:text-primary-700 cursor-pointer">Tekrar dene</button>
      </div>
    );
  }

  const { zimmet, envanter, personel, gorseller, iadeGorseller, envanterGorseller, zimmetleyen } = detail;
  const durum = zimmet.durum;
  const durumTone = DURUM_TONE[durum] ?? DURUM_TONE.kapatildi;
  const isArac = envanter?.envanter_turu === 'arac';
  const isPc = envanter?.envanter_turu === 'bilgisayar';
  // Personel (Uzman / Hekim / DSP / Tekniker) tarafında araç, bilgisayar ve diğer
  // envanter detayı 2 sekmelidir (Genel / Kayıtlar); Geçmiş sekmesi yoktur.
  // OSGB yönetimi mevcut görünümü kullanır.
  const isPersonel = role === 'uzman' || role === 'hekim';
  const anaGorsel = envanterGorseller[0] ?? null;
  const meta = (key: string): string => {
    const v = envanter?.metadata?.[key];
    return v == null || v === '' ? '' : String(v);
  };
  const yakitLabel = (): string => {
    const v = meta('yakitTipi');
    return v ? (YAKIT_LABEL[v] ?? v) : '—';
  };

  const showOsgbActions = isOsgb && durum !== 'kapatildi';
  const showTeslimAction = !isOsgb && durum === 'bekliyor';
  const showIadeAction = !isOsgb && durum === 'iade_talebi';
  const hasActions = showOsgbActions || showTeslimAction || showIadeAction;

  return (
    <div className="flex flex-col h-full min-h-0 gap-3">
      {/* Başlık bloğu */}
      <div className="flex-shrink-0 flex items-center gap-3 p-4 isg-section">
        <div className="w-14 h-14 rounded-xl bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
          <i className={`${envanterTuruIcon(envanter?.envanter_turu)} text-primary-600 dark:text-primary-400 text-2xl`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-base font-semibold text-foreground-950 leading-tight truncate">{envanter?.ad || '—'}</h3>
            <Badge variant={zimmetDurumVariant(durum)} leftIcon={<i className={zimmetDurumIcon(durum)} />}>
              {zimmetDurumLabel(durum)}
            </Badge>
            {durum === 'kapatildi' && zimmet.kapanis_nedeni && (
              <Badge variant="secondary">{kapanisNedeniLabel(zimmet.kapanis_nedeni)}</Badge>
            )}
          </div>
          <p className="text-xs text-foreground-500 mt-1">
            Kod: <span className="font-medium text-foreground-700">{envanter?.envanter_kodu || '—'}</span>
            <span className="mx-2 text-foreground-300">|</span>
            Tür: <span className="font-medium text-foreground-700">{turuLabel(envanter?.envanter_turu)}</span>
          </p>
        </div>
      </div>

      {isPersonel ? (
        <div className="flex-1 min-h-0">
          <ZimmetEnvanterPersonelGorunum
            detail={detail}
            busy={busy}
            onChanged={onChanged}
            onTeslim={handleTeslim}
            onDusur={handleDusur}
            onIade={handleIade}
            onReject={handleReject}
            onIadeOnayla={handleIadeOnayla}
          />
        </div>
      ) : (
      <div className="flex-1 min-h-0 overflow-y-auto pr-0.5">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
          {/* Kolon 1 — Fotoğraflar */}
          <Card title="Fotoğraflar" padding="md" headerAction={<i className="ri-image-line text-primary-500" />}>
            {anaGorsel ? (
              <div className="space-y-2">
                <div className="w-full rounded-lg overflow-hidden border border-background-300/40 bg-background-100">
                  <ImageViewer
                    src={anaGorsel.signedUrl}
                    alt={anaGorsel.fileName}
                    fileName={anaGorsel.fileName}
                    imgClassName="w-full h-36 object-cover object-top"
                  />
                </div>
                {envanterGorseller.length > 1 && (
                  <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                    {envanterGorseller.slice(1).map((g) => (
                      <div key={g.path} className="w-14 h-14 rounded-lg overflow-hidden border border-background-300/40 bg-background-100 flex-shrink-0">
                        <ImageViewer
                          src={g.signedUrl}
                          alt={g.fileName}
                          fileName={g.fileName}
                          imgClassName="w-full h-14 object-cover object-top"
                        />
                      </div>
                    ))}
                  </div>
                )}
                <p className="text-[11px] text-foreground-500">{envanterGorseller.length} fotoğraf</p>
              </div>
            ) : (
              <div className="w-full h-36 rounded-lg border-2 border-dashed border-background-300/50 flex flex-col items-center justify-center gap-1.5 text-foreground-400">
                <i className="ri-image-line text-2xl" />
                <span className="text-xs">Fotoğraf yok</span>
              </div>
            )}

            {/* Teslim / iade görselleri (varsa) */}
            {gorseller.length > 0 && (
              <div className="mt-3 pt-3 border-t border-background-300/20 dark:border-background-400/20">
                <span className="block text-[11px] text-foreground-500 mb-1.5">Teslim Görselleri</span>
                <div className="grid grid-cols-3 gap-2">
                  {gorseller.map((g, idx) => (
                    <div key={idx} className="rounded-lg overflow-hidden border border-background-300/40 bg-background-100">
                      <ImageViewer src={g.signedUrl} alt={g.fileName} fileName={g.fileName} imgClassName="w-full h-14 object-cover object-top" />
                    </div>
                  ))}
                </div>
              </div>
            )}
            {iadeGorseller.length > 0 && (
              <div className="mt-3 pt-3 border-t border-background-300/20 dark:border-background-400/20">
                <span className="block text-[11px] text-foreground-500 mb-1.5">İade Fotoğrafları</span>
                <div className="grid grid-cols-3 gap-2">
                  {iadeGorseller.map((g, idx) => (
                    <div key={idx} className="rounded-lg overflow-hidden border border-background-300/40 bg-background-100">
                      <ImageViewer src={g.signedUrl} alt={g.fileName} fileName={g.fileName} imgClassName="w-full h-14 object-cover object-top" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </Card>

          {/* Kolon 2 — Temel Bilgiler */}
          <Card title="Temel Bilgiler" padding="md" headerAction={<i className="ri-information-line text-primary-500" />}>
            <div className="space-y-2.5">
              {isArac ? (
                <>
                  <div className="grid grid-cols-2 gap-2.5">
                    <FieldRow label="Plaka" value={meta('plaka') || '—'} />
                    <FieldRow label="Şasi No" value={meta('sasiNo') || '—'} />
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <FieldRow label="Marka" value={envanter?.marka || '—'} />
                    <FieldRow label="Model" value={envanter?.model || '—'} />
                  </div>
                  <div className="grid grid-cols-3 gap-2.5">
                    <FieldRow label="Model Yılı" value={meta('modelYili') || '—'} />
                    <FieldRow label="Kilometre" value={meta('kilometre') ? `${meta('kilometre')} km` : '—'} />
                    <FieldRow label="Yakıt" value={yakitLabel()} />
                  </div>
                  <FieldRow label="Motor No" value={meta('motorNo') || '—'} />
                </>
              ) : isPc ? (
                <>
                  <div className="grid grid-cols-2 gap-2.5">
                    <FieldRow label="Envanter Kodu" value={envanter?.envanter_kodu || '—'} />
                    <FieldRow label="Tür" value={turuLabel(envanter?.envanter_turu)} />
                  </div>
                  <FieldRow label="Ad" value={envanter?.ad || '—'} />
                  <div className="grid grid-cols-3 gap-2.5">
                    <FieldRow label="Marka" value={envanter?.marka || '—'} />
                    <FieldRow label="Model" value={envanter?.model || '—'} />
                    <FieldRow label="Seri No" value={envanter?.seri_no || '—'} />
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <FieldRow label="İşletim Sistemi" value={meta('isletimSistemi') || '—'} />
                    <FieldRow label="İşlemci" value={meta('islemci') || '—'} />
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <FieldRow label="RAM" value={meta('ram') || '—'} />
                    <FieldRow label="Depolama" value={meta('depolama') || '—'} />
                  </div>
                </>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-2.5">
                    <FieldRow label="Envanter Kodu" value={envanter?.envanter_kodu || '—'} />
                    <FieldRow label="Tür" value={turuLabel(envanter?.envanter_turu)} />
                  </div>
                  <FieldRow label="Ad" value={envanter?.ad || '—'} />
                  <div className="grid grid-cols-3 gap-2.5">
                    <FieldRow label="Marka" value={envanter?.marka || '—'} />
                    <FieldRow label="Model" value={envanter?.model || '—'} />
                    <FieldRow label="Seri No" value={envanter?.seri_no || '—'} />
                  </div>
                </>
              )}
            </div>
          </Card>

          {/* Kolon 3 — Zimmet Bilgisi + İşlemler + Türe Özel Bilgiler */}
          <div className="space-y-3">
            <Card title="Zimmet Bilgisi" padding="md" headerAction={<i className="ri-handbag-line text-primary-500" />}>
              <div className={`rounded-lg border p-3 ${durumTone.box}`}>
                <div className="flex items-start gap-2.5">
                  <i className={`${zimmetDurumIcon(durum)} text-lg ${durumTone.icon}`} />
                  <div className="min-w-0">
                    <p className={`text-sm font-semibold ${durumTone.title}`}>{zimmetDurumLabel(durum)}</p>
                    <p className="text-xs text-foreground-600 mt-0.5">{DURUM_ACIKLAMA[durum] ?? ''}</p>
                  </div>
                </div>
              </div>

              <div className="mt-3 space-y-2.5">
                <FieldRow label="Zimmet Tarihi" value={formatZimmetDate(zimmet.zimmet_tarihi)} icon="ri-calendar-line" />
                <FieldRow label="Kabul Tarihi" value={formatZimmetDateTime(zimmet.kabul_tarihi)} icon="ri-calendar-check-line" />
                <div className="flex items-start justify-between gap-3">
                  <span className="text-xs text-foreground-500 flex items-center gap-1.5 flex-shrink-0">
                    <i className="ri-user-star-line text-[13px]" />
                    Zimmetleyen
                  </span>
                  <span className="text-sm font-medium text-foreground-800 text-right">
                    {zimmetleyen?.name || '—'}
                    {zimmetleyen?.role ? (
                      <span className="block text-xs font-normal text-foreground-500">{rolEtiket(zimmetleyen.role)}</span>
                    ) : null}
                  </span>
                </div>
                <div className="flex items-start justify-between gap-3">
                  <span className="text-xs text-foreground-500 flex items-center gap-1.5 flex-shrink-0">
                    <i className="ri-user-line text-[13px]" />
                    Zimmetli Kişi
                  </span>
                  <span className="text-sm font-medium text-foreground-800 text-right">
                    {personel ? [personel.ad, personel.soyad].filter(Boolean).join(' ') : '—'}
                    {personel?.personel_turu ? (
                      <span className="block text-xs font-normal text-foreground-500">{personelRolLabel(personel.personel_turu)}</span>
                    ) : null}
                  </span>
                </div>
                <div className="pt-1">
                  <span className="block text-xs text-foreground-500 mb-1">Teslim Notu</span>
                  <p className="text-sm text-foreground-800 whitespace-pre-wrap">{zimmet.teslim_notu || '—'}</p>
                </div>
                {zimmet.iade_notu && (
                  <div className="pt-2 border-t border-background-300/20 dark:border-background-400/20">
                    <span className="block text-xs text-foreground-500 mb-1">İade Notu</span>
                    <p className="text-sm text-foreground-800 whitespace-pre-wrap">{zimmet.iade_notu}</p>
                  </div>
                )}
              </div>
            </Card>

            {hasActions && (
              <Card title="İşlemler" padding="md" headerAction={<i className="ri-flashlight-line text-accent-500" />}>
                <div className="flex flex-col gap-2">
                  {showTeslimAction && (
                    <Button variant="primary" size="sm" onClick={handleTeslim} leftIcon={<i className="ri-check-double-line" />}>
                      Zimmeti Onayla ve Teslim Al
                    </Button>
                  )}
                  {showTeslimAction && (
                    <Button variant="outline" size="sm" onClick={handleReject} disabled={busy} leftIcon={<i className="ri-close-line" />}>
                      Reddet
                    </Button>
                  )}
                  {showIadeAction && (
                    <Button variant="primary" size="sm" onClick={() => handleIade('personel_iade')} leftIcon={<i className="ri-arrow-go-back-line" />}>
                      İadeyi Gönder
                    </Button>
                  )}
                  {isOsgb && durum === 'aktif' && (
                    <Button variant="outline" size="sm" onClick={() => handleIade('osgb_iade_talebi')} leftIcon={<i className="ri-arrow-go-back-line" />}>
                      İade Talebi Başlat
                    </Button>
                  )}
                  {isOsgb && durum === 'iade_onayi_bekliyor' && (
                    <Button variant="primary" size="sm" onClick={handleIadeOnayla} disabled={busy} leftIcon={<i className="ri-check-line" />}>
                      İadeyi Onayla ve Kapat
                    </Button>
                  )}
                  {showOsgbActions && (
                    <Button variant="danger" size="sm" onClick={handleDusur} leftIcon={<i className="ri-close-circle-line" />}>
                      Zimmetten Düşür
                    </Button>
                  )}
                </div>
              </Card>
            )}

            <Card title="Türe Özel Bilgiler" padding="md" headerAction={<i className={`${envanterTuruIcon(envanter?.envanter_turu)} text-primary-500`} />}>
              <div className="space-y-2.5">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-xs text-foreground-500 flex items-center gap-1.5">
                    <i className="ri-toggle-line text-[13px]" />
                    Envanter Durumu
                  </span>
                  <Badge variant={envanter?.durum === 'aktif' ? 'success' : 'warning'}>
                    {envanter?.durum === 'aktif' ? 'Aktif' : 'Pasif'}
                  </Badge>
                </div>
                {isArac && (
                  <FieldRow label="Sonraki Bakım Tarihi" value={meta('sonrakiBakimTarihi') ? formatZimmetDate(meta('sonrakiBakimTarihi')) : '—'} icon="ri-calendar-line" />
                )}
              </div>
            </Card>
          </div>
        </div>
      </div>
      )}

      {/* Alt bilgi çubuğu */}
      <div className="flex-shrink-0 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pt-3 border-t border-background-300/20 dark:border-background-400/20">
        <div className="flex items-center gap-x-4 gap-y-1 flex-wrap text-xs text-foreground-400">
          <span className="flex items-center gap-1.5">
            <i className="ri-time-line" />
            Oluşturulma: {formatZimmetDateTime(zimmet.created_at)}
          </span>
          <span className="flex items-center gap-1.5">
            <i className="ri-refresh-line" />
            Son Güncelleme: {formatZimmetDateTime(zimmet.updated_at)}
          </span>
        </div>
        <Button variant="secondary" size="sm" onClick={onClose}>Kapat</Button>
      </div>
    </div>
  );
}

function FieldRow({ label, value, icon }: { label: string; value: React.ReactNode; icon?: string }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="text-xs text-foreground-500 flex items-center gap-1.5 flex-shrink-0">
        {icon && <i className={`${icon} text-[13px]`} />}
        {label}
      </span>
      <span className="text-sm font-medium text-foreground-800 text-right break-words">{value}</span>
    </div>
  );
}