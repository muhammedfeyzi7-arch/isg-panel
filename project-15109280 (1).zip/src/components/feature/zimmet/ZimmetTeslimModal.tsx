import { useState, useEffect } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Textarea from '@/components/ui/Textarea';
import Badge from '@/components/ui/Badge';
import Card from '@/components/ui/Card';
import { useToastActions } from '@/hooks/useToast';
import {
  fetchZimmet,
  approveZimmet,
  friendlyZimmetError,
  type ZimmetDetail,
} from '@/lib/zimmetService';
import { envanterMetaSatirlari, envanterTuruIcon, formatZimmetDate } from './zimmetUi';
import { ListSkeleton } from '@/components/ui/Skeleton';

interface ZimmetTeslimModalProps {
  zimmetId: string;
  onClose: () => void;
  onSaved: () => void;
}

const ALLOWED_IMG = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_SIZE = 10 * 1024 * 1024;

interface Photo {
  id: string;
  file: File;
  preview: string;
}

let photoIdCounter = 0;

export default function ZimmetTeslimModal({ zimmetId, onClose, onSaved }: ZimmetTeslimModalProps) {
  const { addToast } = useToastActions();
  const [detail, setDetail] = useState<ZimmetDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [notu, setNotu] = useState('');
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    let cancelled = false;
    fetchZimmet(zimmetId)
      .then((d) => { if (!cancelled) setDetail(d); })
      .catch(() => { /* detay yüklenemezse form yine çalışır */ })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [zimmetId]);

  const addPhotos = (files: FileList | null) => {
    if (!files) return;
    setError('');
    const arr = Array.from(files);
    const next: Photo[] = [];
    for (const f of arr) {
      if (!ALLOWED_IMG.includes(f.type)) {
        setError('Yalnızca JPG, PNG veya WebP görsel yükleyebilirsiniz.');
        continue;
      }
      if (f.size > MAX_SIZE) {
        setError('Görsel boyutu 10 MB sınırını aşıyor.');
        continue;
      }
      next.push({ id: `photo-${++photoIdCounter}`, file: f, preview: URL.createObjectURL(f) });
    }
    setPhotos((p) => [...p, ...next]);
  };

  const removePhoto = (id: string) => {
    setPhotos((p) => {
      const target = p.find((x) => x.id === id);
      if (target) URL.revokeObjectURL(target.preview);
      return p.filter((x) => x.id !== id);
    });
  };

  const submit = async () => {
    if (submitting) return;
    setSubmitting(true);
    setError('');
    try {
      await approveZimmet(zimmetId, {
        teslimNotu: notu.trim() || null,
        teslimGorselleri: photos.map((p) => p.file),
      });
      addToast({ title: 'Zimmet teslim alındı', message: 'Zimmet aktif duruma geçti ve OSGB bilgilendirildi.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      const msg = friendlyZimmetError(e);
      setError(msg);
      addToast({ title: 'Onay başarısız', message: msg, type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  const env = detail?.envanter ?? null;
  const metaSatirlar = envanterMetaSatirlari(env?.envanter_turu, env?.metadata);

  return (
    <div className="space-y-4">
      {/* Başlık bandı (premium) */}
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
          <i className="ri-check-double-line text-primary-600 dark:text-primary-400 text-2xl" />
        </div>
        <div className="min-w-0">
          <h3 className="text-base font-semibold text-foreground-950">Zimmeti Teslim Al</h3>
          <p className="text-sm text-foreground-500 mt-0.5">Envanteri teslim aldığınızı onaylayın ve durumunuzu belirtin.</p>
        </div>
      </div>

      {loading ? (
        <ListSkeleton rows={4} />
      ) : (
        <>
          {/* Envanter özeti — salt okunur */}
          {env && (
            <Card title="Envanter" padding="md" headerAction={<i className={`${envanterTuruIcon(env.envanter_turu)} text-primary-500`} />}>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl bg-primary-50 dark:bg-primary-500/10 flex items-center justify-center flex-shrink-0">
                  <i className={`${envanterTuruIcon(env.envanter_turu)} text-primary-600 dark:text-primary-400 text-lg`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground-950 truncate">{env.ad}</p>
                  <p className="text-xs text-foreground-500">Kod: {env.envanter_kodu}</p>
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    <Badge variant="secondary">{env.envanter_turu === 'arac' ? 'Araç' : env.envanter_turu === 'bilgisayar' ? 'Bilgisayar' : 'Diğer'}</Badge>
                    {env.marka && <Badge variant="default">{env.marka}</Badge>}
                    {env.model && <Badge variant="default">{env.model}</Badge>}
                  </div>
                </div>
              </div>

              {metaSatirlar.length > 0 && (
                <div className="mt-3 pt-3 border-t border-background-300/20 dark:border-background-400/20 space-y-1.5">
                  {metaSatirlar.map((s) => (
                    <div key={s.label} className="flex items-center justify-between gap-3">
                      <span className="text-xs text-foreground-500">{s.label}</span>
                      <span className="text-sm font-medium text-foreground-800">{s.value}</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="mt-3 pt-3 border-t border-background-300/20 dark:border-background-400/20">
                <p className="text-xs text-foreground-500">Zimmet tarihi: {formatZimmetDate(detail?.zimmet.zimmet_tarihi)}</p>
              </div>
            </Card>
          )}

          <Card title="Teslim Bilgileri" padding="md" headerAction={<i className="ri-sticky-note-line text-secondary-500" />}>
            <div className="space-y-3">
              <Textarea
                label="Teslim Notu"
                placeholder="Teslim durumuyla ilgili kısa not (opsiyonel)"
                value={notu}
                onChange={(e) => setNotu(e.target.value)}
                maxLength={500}
              />

              <div>
                <p className="isg-form-label">Teslim Görselleri</p>
                <label className="flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed border-background-300 bg-background-100 hover:bg-background-200 p-5 cursor-pointer transition-colors">
                  <i className="ri-image-add-line text-2xl text-foreground-400" />
                  <p className="text-sm text-foreground-600 text-center">
                    Teslim görseli eklemek için tıklayın veya sürükleyin
                  </p>
                  <p className="text-xs text-foreground-400">JPG, PNG, WebP — en fazla 10 MB</p>
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    multiple
                    className="hidden"
                    onChange={(e) => addPhotos(e.target.files)}
                  />
                </label>

                {photos.length > 0 && (
                  <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {photos.map((p) => (
                      <div key={p.id} className="relative group rounded-lg overflow-hidden border border-background-300/40 bg-background-100">
                        <img src={p.preview} alt={p.file.name} className="w-full h-24 object-cover object-top" />
                        <button
                          type="button"
                          onClick={() => removePhoto(p.id)}
                          className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/60 text-inverse flex items-center justify-center hover:bg-danger-600 transition-colors cursor-pointer"
                          aria-label="Görseli kaldır"
                        >
                          <i className="ri-close-line text-sm" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </Card>
        </>
      )}

      {error && (
        <Alert variant="danger">{error}</Alert>
      )}

      <div className="flex justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={submitting}>İptal</Button>
        <Button variant="primary" size="sm" isLoading={submitting} disabled={loading} onClick={submit} leftIcon={<i className="ri-check-double-line" />}>
          Zimmeti Onayla ve Teslim Al
        </Button>
      </div>
    </div>
  );
}