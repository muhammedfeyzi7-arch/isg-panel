// ---------- Zimmet UI yardımcıları (shared) ----------
// OSGB / Uzman / Hekim ekranlarında ortak kullanılan görsel sabitler.
// Business logic YOKTUR — yalnızca durum/ikon/tarih sunumu.

import { formatIstanbulDate, formatIstanbulDateTime } from '@/lib/dateFormat';

export type ZimmetBadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'secondary' | 'accent';

export function zimmetDurumVariant(durum: string): ZimmetBadgeVariant {
  switch (durum) {
    case 'bekliyor': return 'warning';
    case 'aktif': return 'success';
    case 'iade_talebi': return 'info';
    case 'iade_onayi_bekliyor': return 'accent';
    case 'kapatildi': return 'secondary';
    default: return 'default';
  }
}

export function zimmetDurumIcon(durum: string): string {
  switch (durum) {
    case 'bekliyor': return 'ri-time-line';
    case 'aktif': return 'ri-checkbox-circle-line';
    case 'iade_talebi': return 'ri-arrow-go-back-line';
    case 'iade_onayi_bekliyor': return 'ri-hourglass-line';
    case 'kapatildi': return 'ri-archive-line';
    default: return 'ri-handbag-line';
  }
}

export function envanterTuruIcon(turu: string | null | undefined): string {
  switch (turu) {
    case 'arac': return 'ri-car-line';
    case 'bilgisayar': return 'ri-computer-line';
    default: return 'ri-box-3-line';
  }
}

/** Yalnızca tarih — Europe/Istanbul temelinde "5 Eyl 2026" (gün kayması yok). */
export function formatZimmetDate(iso: string | null | undefined): string {
  return formatIstanbulDate(iso);
}

/** Tam zaman damgası — Europe/Istanbul temelinde "5 Eyl 2026 14:32". */
export function formatZimmetDateTime(iso: string | null | undefined): string {
  return formatIstanbulDateTime(iso);
}

/** Envanter metadata'sındaki araç/bilgisayar alanlarını okunabilir satırlara çevirir. */
export interface MetaSatir {
  label: string;
  value: string;
}

const ARAC_LABELS: Record<string, string> = {
  plaka: 'Plaka',
  sasiNo: 'Şasi No',
  motorNo: 'Motor No',
  modelYili: 'Model Yılı',
  yakitTipi: 'Yakıt Tipi',
  kilometre: 'Kilometre',
  sonrakiBakimTarihi: 'Sonraki Bakım Tarihi',
};

const BILGISAYAR_LABELS: Record<string, string> = {
  cihazTipi: 'Cihaz Tipi',
  isletimSistemi: 'İşletim Sistemi',
  islemci: 'İşlemci',
  ram: 'RAM',
  depolama: 'Depolama',
};

const YAKIT_LABEL: Record<string, string> = {
  benzin: 'Benzin', dizel: 'Dizel', lpg: 'LPG', elektrik: 'Elektrik', hibrit: 'Hibrit',
};
const CIHAZ_LABEL: Record<string, string> = {
  masaustu: 'Masaüstü', dizustu: 'Dizüstü', sunucu: 'Sunucu',
};

export function envanterMetaSatirlari(turu: string | null | undefined, metadata: Record<string, unknown> | null | undefined): MetaSatir[] {
  if (!metadata) return [];
  const labels = turu === 'arac' ? ARAC_LABELS : turu === 'bilgisayar' ? BILGISAYAR_LABELS : {};
  const out: MetaSatir[] = [];
  for (const [key, label] of Object.entries(labels)) {
    let v = metadata[key];
    if (v == null || v === '') continue;
    if (key === 'yakitTipi') v = YAKIT_LABEL[String(v)] ?? v;
    if (key === 'cihazTipi') v = CIHAZ_LABEL[String(v)] ?? v;
    if (key === 'sonrakiBakimTarihi') v = formatZimmetDate(String(v));
    out.push({ label, value: String(v) });
  }
  return out;
}