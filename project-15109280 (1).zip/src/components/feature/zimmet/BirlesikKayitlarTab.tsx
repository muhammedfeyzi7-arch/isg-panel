import { useMemo, useRef, useState } from 'react';
import useSWR from 'swr';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import FilterBar from '@/components/ui/FilterBar';
import type { FilterField, FilterValue } from '@/components/ui/FilterBar';
import ActionMenu from '@/components/ui/ActionMenu';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import Loading from '@/components/ui/Loading';
import { useModalActions } from '@/hooks/useModal';
import {
  fetchEnvanterOperasyonlar,
  friendlyOperasyonError,
  type AracOperasyonRow,
  type OperasyonEntityType,
  type OperasyonPersonel,
} from '@/lib/operasyonService';
import {
  aracOperasyonIcon,
  aracOperasyonVariant,
  formatOperasyonDate,
  formatPara,
  formatLitre,
} from '@/components/feature/operasyon/operasyonUi';
import OperasyonDetailModal from '@/components/feature/operasyon/OperasyonDetailModal';
import FisEkleModal from './FisEkleModal';
import KazaEkleModal from './KazaEkleModal';
import PcFisEkleModal from './PcFisEkleModal';
import PcArizaEkleModal from './PcArizaEkleModal';

interface BirlesikKayitlarTabProps {
  envanterId: string;
  /** 'arac' | 'bilgisayar' | 'diger' */
  envanterTuru: string;
  envanterAd?: string;
  envanterKod?: string;
  /** Kayıt ekleme yetkisi (aktif zimmet veya OSGB yönetimi). */
  canCreate: boolean;
  onChanged?: () => void;
}

const TUR_LABEL: Record<string, string> = {
  yakit: 'Yakıt Fişi',
  yikama: 'Yıkama Fişi',
  tamir: 'Tamir Fişi',
  servis: 'Servis Fişi',
  diger_gider: 'Gider Fişi',
  bakim_notu: 'Bakım Notu',
  kaza: 'Kaza Kaydı',
  ariza: 'Arıza Kaydı',
};

const FIS_TURLERI = ['yakit', 'yikama', 'tamir', 'servis', 'diger_gider', 'bakim_notu'];

const PERSONEL_TURU_LABEL: Record<string, string> = {
  isg_uzmani: 'İş Güvenliği Uzmanı',
  isyeri_hekimi: 'İşyeri Hekimi',
  dsp: 'DSP',
  isg_teknikeri: 'İSG Teknikeri',
};

function asStr(v: FilterValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

function turLabel(tur: string): string {
  return TUR_LABEL[tur] ?? tur;
}

function tsOf(tarih: string | null | undefined): number {
  const t = new Date(tarih ?? '').getTime();
  return Number.isNaN(t) ? 0 : t;
}

function gunFiltresi(tur: string, kayitTarihi: string | null, createdAt: string): boolean {
  if (!tur) return true;
  const n = Number(tur);
  if (!Number.isFinite(n) || n <= 0) return true;
  const raw = kayitTarihi || createdAt;
  const t = new Date(raw).getTime();
  if (Number.isNaN(t)) return true;
  return Date.now() - t <= n * 24 * 60 * 60 * 1000;
}

// Birleşik kayıt satırı — fiş + kaza/arıza kayıtları tek yapıya indirgenir.
interface KayitRow {
  id: string;
  entityType: OperasyonEntityType;
  tur: string;
  tarih: string | null;
  aciklama: string | null;
  tutar: number | string | null;
  litre: number | string | null;
  personel: OperasyonPersonel | null;
  dosyaSayisi: number;
  yorumSayisi: number;
}

/**
 * Envanter "Kayıtlar" sekmesi (ORTAK) — bilgisayar / diğer / araç ve OSGB yönetimi
 * tarafından paylaşılır. Fiş + kaza/arıza kayıtları TEK BİRLEŞİK listede, tarih
 * sırasına göre gösterilir; bölümlere ayrılmaz. Kayıt onay/durum rozeti YOKTUR.
 * Kayıt ekleme butonları envanter türüne göre değişir. Tüm veri mevcut operasyon
 * servisinden gelir; backend personel için yalnızca İÇİNDE bulunduğu açık zimmet
 * dönemine ait kayıtları döndürür.
 */
export default function BirlesikKayitlarTab({
  envanterId, envanterTuru, envanterAd, envanterKod, canCreate, onChanged,
}: BirlesikKayitlarTabProps) {
  const { openModal, closeModal } = useModalActions();
  const detailModalIdRef = useRef('');

  const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
  const [search, setSearch] = useState('');

  const isArac = envanterTuru === 'arac';
  const isBilgisayar = envanterTuru === 'bilgisayar';

  const { data, error, isLoading, mutate } = useSWR(
    ['birlesik-kayitlar', envanterId],
    () => fetchEnvanterOperasyonlar(envanterId),
  );

  const rows = useMemo<KayitRow[]>(() => {
    const fis = (data?.aracOperasyonlar ?? [])
      .filter((o) => o.tur !== 'bakim_notu')
      .map<KayitRow>((o: AracOperasyonRow) => ({
        id: o.id,
        entityType: 'arac_operasyon',
        tur: o.tur,
        tarih: o.tarih || o.created_at,
        aciklama: o.aciklama,
        tutar: o.tutar,
        litre: o.litre,
        personel: o.olusturan_personel ?? null,
        dosyaSayisi: o.dosya_sayisi ?? 0,
        yorumSayisi: o.yorum_sayisi ?? 0,
      }));

    const arizalar = (data?.arizalar ?? []).map<KayitRow>((a) => ({
      id: a.id,
      entityType: 'ariza',
      tur: 'ariza',
      tarih: a.created_at,
      aciklama: a.aciklama,
      tutar: null,
      litre: null,
      personel: a.olusturan_personel ?? null,
      dosyaSayisi: a.dosya_sayisi ?? 0,
      yorumSayisi: a.yorum_sayisi ?? 0,
    }));

    return [...fis, ...arizalar].sort((a, b) => tsOf(b.tarih) - tsOf(a.tarih));
  }, [data]);

  const turFilter = asStr(filterValues['tur']);
  const tarihFilter = asStr(filterValues['tarih']);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      const isKazaTur = r.tur === 'kaza';
      const isAriza = r.entityType === 'ariza';
      if (turFilter === 'fisler' && !FIS_TURLERI.includes(r.tur)) return false;
      if (turFilter === 'kaza' && !isKazaTur) return false;
      if (turFilter === 'ariza' && !isAriza) return false;
      if (!gunFiltresi(tarihFilter, r.tarih, r.tarih ?? '')) return false;
      if (q) {
        const hay = [
          turLabel(r.tur),
          r.aciklama ?? '',
          r.personel ? `${r.personel.ad ?? ''} ${r.personel.soyad ?? ''}` : '',
        ].join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [rows, turFilter, tarihFilter, search]);

  const reload = () => { mutate(); onChanged?.(); };

  const openDetail = (row: KayitRow) => {
    const id = openModal({
      title: 'Kayıt Detayı',
      description: turLabel(row.tur),
      variant: 'detail',
      width: 1100,
      minWidth: 440,
      minHeight: 520,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      bodyLayout: 'fill',
      content: (
        <OperasyonDetailModal
          entityType={row.entityType}
          entityId={row.id}
          onClose={() => closeModal(detailModalIdRef.current)}
          onChanged={reload}
        />
      ),
    });
    detailModalIdRef.current = id;
  };

  const openFis = () => {
    const id = openModal({
      title: 'Fiş Kaydı Ekle',
      description: isArac ? 'Araç · gider / fiş kaydı' : `${envanterTuru === 'bilgisayar' ? 'Bilgisayar' : 'Envanter'} · fiş kaydı`,
      variant: 'form',
      width: 1040,
      minWidth: 440,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: isArac ? (
        <FisEkleModal
          envanterId={envanterId}
          envanterAd={envanterAd}
          envanterKod={envanterKod}
          onClose={() => closeModal(id)}
          onSaved={reload}
        />
      ) : (
        <PcFisEkleModal
          envanterId={envanterId}
          envanterAd={envanterAd}
          envanterKod={envanterKod}
          envanterTuru={envanterTuru}
          onClose={() => closeModal(id)}
          onSaved={reload}
        />
      ),
    });
  };

  const openKaza = () => {
    const id = openModal({
      title: 'Kaza Kaydı Ekle',
      description: 'Araç · kaza kaydı',
      variant: 'form',
      width: 1040,
      minWidth: 440,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <KazaEkleModal
          envanterId={envanterId}
          envanterAd={envanterAd}
          envanterKod={envanterKod}
          onClose={() => closeModal(id)}
          onSaved={reload}
        />
      ),
    });
  };

  const openAriza = () => {
    const id = openModal({
      title: 'Arıza Kaydı Ekle',
      description: 'Bilgisayar · arıza kaydı',
      variant: 'form',
      width: 1040,
      minWidth: 440,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: (
        <PcArizaEkleModal
          envanterId={envanterId}
          envanterAd={envanterAd}
          envanterKod={envanterKod}
          onClose={() => closeModal(id)}
          onSaved={reload}
        />
      ),
    });
  };

  const filters = useMemo<FilterField[]>(() => {
    const turOptions = [{ value: 'fisler', label: 'Fişler' }];
    if (isArac) turOptions.push({ value: 'kaza', label: 'Kaza' });
    if (isBilgisayar) turOptions.push({ value: 'ariza', label: 'Arıza' });
    return [
      { key: 'tur', label: 'Tür', type: 'status', placeholder: 'Tür — Tümü', options: turOptions },
      {
        key: 'tarih',
        label: 'Tarih',
        type: 'status',
        placeholder: 'Tarih — Tümü',
        options: [
          { value: '7', label: 'Son 7 Gün' },
          { value: '30', label: 'Son 30 Gün' },
          { value: '90', label: 'Son 3 Ay' },
        ],
      },
    ];
  }, [isArac, isBilgisayar]);

  const columns: TableColumn<KayitRow>[] = [
    {
      key: 'tur',
      header: 'Kayıt Türü',
      render: (r) => {
        const isKazaTur = r.tur === 'kaza';
        const isAriza = r.entityType === 'ariza';
        const tone = isKazaTur || isAriza
          ? 'bg-danger-50 dark:bg-danger-500/15 text-danger-600 dark:text-danger-400'
          : 'bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400';
        const icon = isAriza ? 'ri-bug-line' : aracOperasyonIcon(r.tur);
        return (
          <div className="flex items-center gap-2.5 min-w-0">
            <span className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${tone}`}>
              <i className={icon} />
            </span>
            <Badge variant={isAriza ? 'secondary' : aracOperasyonVariant(r.tur)}>{turLabel(r.tur)}</Badge>
          </div>
        );
      },
    },
    {
      key: 'tarih',
      header: 'Tarih',
      render: (r) => <span className="text-sm text-foreground-700">{formatOperasyonDate(r.tarih)}</span>,
    },
    {
      key: 'olusturan',
      header: 'Kaydı Oluşturan',
      render: (r) => {
        const p = r.personel;
        if (!p) return <span className="text-sm text-foreground-400">—</span>;
        return (
          <div className="min-w-0">
            <p className="text-sm text-foreground-800 truncate">{[p.ad, p.soyad].filter(Boolean).join(' ') || '—'}</p>
            {p.personel_turu && <p className="text-xs text-foreground-500">{PERSONEL_TURU_LABEL[p.personel_turu] ?? p.personel_turu}</p>}
          </div>
        );
      },
    },
    {
      key: 'tutar',
      header: 'Tutar',
      render: (r) => (
        <div className="text-sm text-foreground-800">
          {r.tutar != null && r.tutar !== '' ? formatPara(r.tutar) : <span className="text-foreground-400">—</span>}
          {r.litre != null && r.litre !== '' && <span className="block text-xs text-foreground-500">{formatLitre(r.litre)}</span>}
        </div>
      ),
    },
    {
      key: 'aciklama',
      header: 'Açıklama',
      render: (r) => (
        <span className="text-sm text-foreground-600 line-clamp-2 max-w-[220px] block">{r.aciklama || '—'}</span>
      ),
    },
    {
      key: 'dosya',
      header: 'Dosya',
      align: 'center',
      render: (r) => (
        <span className="inline-flex items-center gap-1 text-sm text-foreground-600">
          <i className="ri-attachment-2 text-foreground-400" />
          {r.dosyaSayisi}
        </span>
      ),
    },
    {
      key: 'yorum',
      header: 'Yorum',
      align: 'center',
      render: (r) => (
        <span className="inline-flex items-center gap-1 text-sm text-foreground-600">
          <i className="ri-chat-3-line text-foreground-400" />
          {r.yorumSayisi}
        </span>
      ),
    },
  ];

  const errorMsg = error ? friendlyOperasyonError(error) : null;

  return (
    <div className="space-y-3">
      <div className="flex flex-col gap-2">
        {canCreate && (
          <div className="flex items-center justify-end gap-2 flex-wrap">
            <Button variant="primary" size="sm" onClick={openFis} leftIcon={<i className="ri-receipt-line" />}>
              {isArac ? 'Fiş Kaydı Ekle' : 'Fiş Yükle'}
            </Button>
            {isArac && (
              <Button variant="danger" size="sm" onClick={openKaza} leftIcon={<i className="ri-alert-line" />}>
                Kaza Kaydı Ekle
              </Button>
            )}
            {isBilgisayar && (
              <button
                type="button"
                onClick={openAriza}
                className="isg-btn isg-btn-sm bg-warning-500 hover:bg-warning-600 text-inverse cursor-pointer whitespace-nowrap"
              >
                <span className="isg-btn-content">
                  <i className="ri-bug-line" />
                  Arıza Kaydı Ekle
                </span>
              </button>
            )}
          </div>
        )}

        <FilterBar
          filters={filters}
          values={filterValues}
          onChange={(key, value) => setFilterValues((prev) => ({ ...prev, [key]: value }))}
          onReset={() => { setFilterValues({}); setSearch(''); }}
          onSearch={setSearch}
          searchPlaceholder="Ara... kayıt türü, açıklama, personel adı"
          searchDebounceMs={300}
        />
      </div>

      <div>
        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loading size="lg" text="Kayıtlar yükleniyor..." />
          </div>
        ) : errorMsg ? (
          <ErrorState message={errorMsg} onRetry={() => mutate()} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="ri-file-list-3-line"
            title={rows.length === 0 ? 'Henüz kayıt yok' : 'Sonuç bulunamadı'}
            description={
              rows.length === 0
                ? 'Bu envanter için fiş veya kaza/arıza kaydı bulunmuyor.'
                : 'Seçtiğiniz filtrelere uygun kayıt yok.'
            }
          />
        ) : (
          <Table
            data={filtered}
            columns={columns}
            keyExtractor={(r) => r.id}
            onRowClick={openDetail}
            rowActions={(row) => (
              <ActionMenu
                items={[{ label: 'Detayı Aç', icon: 'ri-eye-line', onClick: () => openDetail(row) }]}
              />
            )}
          />
        )}
      </div>
    </div>
  );
}