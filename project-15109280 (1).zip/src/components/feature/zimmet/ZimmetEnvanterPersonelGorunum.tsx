import { useState } from 'react';
import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import ImageViewer from '@/components/ui/ImageViewer';
import TabBar, { type TabBarItem } from '@/components/ui/TabBar';
import {
  zimmetDurumLabel,
  type ZimmetDetail,
} from '@/lib/zimmetService';
import {
  zimmetDurumVariant,
  zimmetDurumIcon,
  formatZimmetDate,
  formatZimmetDateTime,
} from '@/components/feature/zimmet/zimmetUi';
import BirlesikKayitlarTab from './BirlesikKayitlarTab';

interface ZimmetEnvanterPersonelGorunumProps {
  detail: ZimmetDetail;
  busy: boolean;
  onChanged: () => void;
  onTeslim: () => void;
  onDusur: () => void;
  onIade: (mode: 'osgb_iade_talebi' | 'personel_iade') => void;
  onReject: () => void;
  onIadeOnayla: () => void;
}

const YAKIT_LABEL: Record<string, string> = {
  benzin: 'Benzin', dizel: 'Dizel', lpg: 'LPG', elektrik: 'Elektrik', hibrit: 'Hibrit',
};

const DURUM_ACIKLAMA: Record<string, string> = {
  bekliyor: 'Tarafınıza zimmet atanmıştır.',
  aktif: 'Zimmet aktif; envanter teslim alındı.',
  iade_talebi: 'Zimmetiniz için iade talebi başlatıldı.',
  iade_onayi_bekliyor: 'İade işlemi gönderildi, onay bekleniyor.',
  kapatildi: 'Zimmet kapatıldı.',
};

const DURUM_TONE: Record<string, { box: string; icon: string; title: string }> = {
  bekliyor: { box: 'bg-warning-50 dark:bg-warning-500/10 border-warning-200/70 dark:border-warning-500/30', icon: 'ri-time-line text-warning-600 dark:text-warning-400', title: 'text-warning-800 dark:text-warning-300' },
  aktif: { box: 'bg-success-50 dark:bg-success-500/10 border-success-200/70 dark:border-success-500/30', icon: 'ri-checkbox-circle-line text-success-600 dark:text-success-400', title: 'text-success-800 dark:text-success-300' },
  iade_talebi: { box: 'bg-primary-50 dark:bg-primary-500/10 border-primary-200/70 dark:border-primary-500/30', icon: 'ri-arrow-go-back-line text-primary-600 dark:text-primary-400', title: 'text-primary-800 dark:text-primary-300' },
  iade_onayi_bekliyor: { box: 'bg-accent-100 dark:bg-accent-500/10 border-accent-300/70 dark:border-accent-500/30', icon: 'ri-hourglass-line text-accent-700 dark:text-accent-400', title: 'text-accent-900 dark:text-accent-300' },
  kapatildi: { box: 'bg-background-100 dark:bg-background-300/20 border-background-300/60 dark:border-background-400/30', icon: 'ri-archive-line text-foreground-500', title: 'text-foreground-700' },
};

const PERSONEL_TURU_LABEL: Record<string, string> = {
  isg_uzmani: 'İş Güvenliği Uzmanı',
  isyeri_hekimi: 'İşyeri Hekimi',
  dsp: 'DSP',
  isg_teknikeri: 'İSG Teknikeri',
};

const TUR_LABEL: Record<string, string> = {
  arac: 'Araç',
  bilgisayar: 'Bilgisayar',
  diger: 'Diğer',
};

function FieldRow({ label, value, icon }: { label: string; value: ReactNode; icon?: string }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <span className="text-xs text-foreground-500 flex items-center gap-1.5 flex-shrink-0">
        {icon && <i className={`${icon} text-[13px]`} />}
        {label}
      </span>
      <span className="text-sm font-medium text-foreground-800 text-right break-words">{value}</span>
    </div>
  );
}

/**
 * Uzman / Hekim / DSP / Tekniker envanter zimmet detayı — SADECE 2 SEKME
 * (Genel / Kayıtlar). Araç, Bilgisayar ve Diğer türleri için aynı yerleşim
 * kullanılır; yalnızca türe özel Temel Bilgiler alanları ve kayıt türleri
 * değişir. Geçmiş sekmesi YOKTUR; önceki personellerin geçmiş kayıtları
 * gösterilmez. Kayıt ekleme yalnızca zimmet AKTİF iken görünür. OSGB yönetim
 * tarafı bu bileşeni KULLANMAZ.
 */
export default function ZimmetEnvanterPersonelGorunum({
  detail, busy, onChanged, onTeslim, onDusur, onIade, onReject, onIadeOnayla,
}: ZimmetEnvanterPersonelGorunumProps) {
  const [activeTab, setActiveTab] = useState('genel');

  const { zimmet, envanter, personel, gorseller, iadeGorseller, envanterGorseller } = detail;
  const durum = zimmet.durum;
  const durumTone = DURUM_TONE[durum] ?? DURUM_TONE.kapatildi;
  const envanterTuru = envanter?.envanter_turu ?? 'diger';
  const isArac = envanterTuru === 'arac';
  const isPc = envanterTuru === 'bilgisayar';

  const meta = (key: string): string => {
    const v = envanter?.metadata?.[key];
    return v == null || v === '' ? '' : String(v);
  };
  const yakitLabel = (): string => {
    const v = meta('yakitTipi');
    return v ? (YAKIT_LABEL[v] ?? v) : '—';
  };

  const fotoListesi = [...envanterGorseller, ...gorseller, ...iadeGorseller];
  const anaGorsel = fotoListesi[0] ?? null;

  const showTeslimAction = durum === 'bekliyor';
  const showIadeAction = durum === 'iade_talebi';
  const hasActions = showTeslimAction || showIadeAction;

  // Kayıt ekleme yalnızca zimmet AKTİF iken mümkündür (zimmetten düşürülünce kilit).
  const canCreate = durum === 'aktif';

  const tabItems: TabBarItem[] = [
    { key: 'genel', label: 'Genel', number: 1 },
    { key: 'kayitlar', label: 'Kayıtlar', number: 2 },
  ];

  return (
    <div className="flex flex-col h-full min-h-0 gap-3">
      <div className="flex-shrink-0">
        <TabBar items={tabItems} active={activeTab} onChange={setActiveTab} />
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto pr-0.5">
        {activeTab === 'genel' && (
          <div className="space-y-3">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
              {/* Kolon 1 — Fotoğraflar */}
              <Card title="Fotoğraflar" padding="md" headerAction={<i className="ri-image-line text-primary-500" />}>
                {anaGorsel ? (
                  <div className="space-y-2">
                    <div className="w-full rounded-lg overflow-hidden border border-background-300/40 bg-background-100">
                      <ImageViewer
                        src={anaGorsel.signedUrl}
                        alt={anaGorsel.fileName}
                        fileName={anaGorsel.fileName}
                        imgClassName="w-full h-40 object-cover object-top"
                      />
                    </div>
                    {fotoListesi.length > 1 && (
                      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                        {fotoListesi.slice(1).map((g) => (
                          <div key={g.path} className="w-14 h-14 rounded-lg overflow-hidden border border-background-300/40 bg-background-100 flex-shrink-0">
                            <ImageViewer
                              src={g.signedUrl}
                              alt={g.fileName}
                              fileName={g.fileName}
                              imgClassName="w-full h-14 object-cover object-top"
                            />
                          </div>
                        ))}
                      </div>
                    )}
                    <p className="text-[11px] text-foreground-500">{fotoListesi.length} fotoğraf yüklendi</p>
                  </div>
                ) : (
                  <div className="w-full h-40 rounded-lg border-2 border-dashed border-background-300/50 flex flex-col items-center justify-center gap-1.5 text-foreground-400">
                    <i className="ri-image-line text-2xl" />
                    <span className="text-xs">Fotoğraf yok</span>
                  </div>
                )}
              </Card>

              {/* Kolon 2 — Temel Bilgiler (türe özel) */}
              <Card title="Temel Bilgiler" padding="md" headerAction={<i className="ri-information-line text-primary-500" />}>
                <div className="space-y-2.5">
                  <div className="grid grid-cols-2 gap-2.5">
                    <FieldRow label="Envanter Kodu" value={envanter?.envanter_kodu || '—'} />
                    <FieldRow label="Tür" value={TUR_LABEL[envanterTuru] ?? '—'} />
                  </div>
                  <FieldRow label="Ad" value={envanter?.ad || '—'} />

                  {isArac ? (
                    <>
                      <div className="grid grid-cols-3 gap-2.5">
                        <FieldRow label="Marka" value={envanter?.marka || '—'} />
                        <FieldRow label="Model" value={envanter?.model || '—'} />
                        <FieldRow label="Model Yılı" value={meta('modelYili') || '—'} />
                      </div>
                      <div className="grid grid-cols-2 gap-2.5">
                        <FieldRow label="Plaka" value={meta('plaka') || '—'} />
                        <FieldRow label="Şasi No" value={meta('sasiNo') || '—'} />
                      </div>
                      <div className="grid grid-cols-3 gap-2.5">
                        <FieldRow label="Yakıt Tipi" value={yakitLabel()} />
                        <FieldRow label="Son Bakım Tarihi" value={meta('sonBakimTarihi') ? formatZimmetDate(meta('sonBakimTarihi')) : '—'} />
                        <FieldRow label="Sonraki Bakım Tarihi" value={meta('sonrakiBakimTarihi') ? formatZimmetDate(meta('sonrakiBakimTarihi')) : '—'} />
                      </div>
                    </>
                  ) : isPc ? (
                    <>
                      <div className="grid grid-cols-3 gap-2.5">
                        <FieldRow label="Marka" value={envanter?.marka || '—'} />
                        <FieldRow label="Model" value={envanter?.model || '—'} />
                        <FieldRow label="Seri No" value={envanter?.seri_no || '—'} />
                      </div>
                      <div className="grid grid-cols-2 gap-2.5">
                        <FieldRow label="İşletim Sistemi" value={meta('isletimSistemi') || '—'} />
                        <FieldRow label="İşlemci" value={meta('islemci') || '—'} />
                      </div>
                      <div className="grid grid-cols-2 gap-2.5">
                        <FieldRow label="RAM" value={meta('ram') || '—'} />
                        <FieldRow label="Depolama" value={meta('depolama') || '—'} />
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="grid grid-cols-3 gap-2.5">
                        <FieldRow label="Marka" value={envanter?.marka || '—'} />
                        <FieldRow label="Model" value={envanter?.model || '—'} />
                        <FieldRow label="Seri No" value={envanter?.seri_no || '—'} />
                      </div>
                    </>
                  )}
                </div>
              </Card>

              {/* Kolon 3 — Zimmet Bilgisi + İşlemler */}
              <div className="space-y-3">
                <Card title="Zimmet Bilgisi" padding="md" headerAction={<i className="ri-handbag-line text-primary-500" />}>
                  <div className={`rounded-lg border p-3 ${durumTone.box}`}>
                    <div className="flex items-start gap-2.5">
                      <i className={`${zimmetDurumIcon(durum)} text-lg ${durumTone.icon}`} />
                      <div className="min-w-0">
                        <p className={`text-sm font-semibold ${durumTone.title}`}>{zimmetDurumLabel(durum)}</p>
                        <p className="text-xs text-foreground-600 mt-0.5">{DURUM_ACIKLAMA[durum] ?? ''}</p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 space-y-2.5">
                    <FieldRow label="Zimmet Tarihi" value={formatZimmetDate(zimmet.zimmet_tarihi)} icon="ri-calendar-line" />
                    <FieldRow label="Kabul Tarihi" value={formatZimmetDateTime(zimmet.kabul_tarihi)} icon="ri-calendar-check-line" />
                    <div className="flex items-start justify-between gap-3">
                      <span className="text-xs text-foreground-500 flex items-center gap-1.5 flex-shrink-0">
                        <i className="ri-user-line text-[13px]" />
                        Zimmetlenen Kişi
                      </span>
                      <span className="text-sm font-medium text-foreground-800 text-right">
                        {personel ? [personel.ad, personel.soyad].filter(Boolean).join(' ') : '—'}
                        {personel?.personel_turu ? (
                          <span className="block text-xs font-normal text-foreground-500">{PERSONEL_TURU_LABEL[personel.personel_turu] ?? personel.personel_turu}</span>
                        ) : null}
                      </span>
                    </div>
                  </div>
                </Card>

                {hasActions && (
                  <Card title="İşlemler" padding="md" headerAction={<i className="ri-flashlight-line text-accent-500" />}>
                    <div className="flex flex-col gap-2">
                      {showTeslimAction && (
                        <Button variant="primary" size="sm" onClick={onTeslim} leftIcon={<i className="ri-check-double-line" />}>
                          Zimmeti Onayla ve Teslim Al
                        </Button>
                      )}
                      {showTeslimAction && (
                        <Button variant="outline" size="sm" onClick={onReject} disabled={busy} leftIcon={<i className="ri-close-line" />}>
                          Reddet
                        </Button>
                      )}
                      {showIadeAction && (
                        <Button variant="primary" size="sm" onClick={() => onIade('personel_iade')} leftIcon={<i className="ri-arrow-go-back-line" />}>
                          İadeyi Gönder
                        </Button>
                      )}
                    </div>
                  </Card>
                )}
              </div>
            </div>

            {/* Notlar (tam genişlik) */}
            <Card title="Notlar" padding="md" headerAction={<i className="ri-sticky-note-line text-primary-500" />}>
              <p className="text-sm text-foreground-800 whitespace-pre-wrap">{zimmet.teslim_notu || 'Not bulunmuyor.'}</p>
              {zimmet.iade_notu && (
                <div className="mt-3 pt-3 border-t isg-divider">
                  <span className="block text-xs text-foreground-500 mb-1">İade Notu</span>
                  <p className="text-sm text-foreground-800 whitespace-pre-wrap">{zimmet.iade_notu}</p>
                </div>
              )}
            </Card>
          </div>
        )}

        {activeTab === 'kayitlar' && (
          <BirlesikKayitlarTab
            envanterId={envanter?.id ?? ''}
            envanterTuru={envanterTuru}
            envanterAd={envanter?.ad}
            envanterKod={envanter?.envanter_kodu}
            canCreate={canCreate}
            onChanged={onChanged}
          />
        )}
      </div>
    </div>
  );
}