import { useState } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import DatePicker from '@/components/ui/DatePicker';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import { useToastActions } from '@/hooks/useToast';
import { createAriza, friendlyOperasyonError } from '@/lib/operasyonService';
import DosyaSecici, { type SeciliDosya } from '@/components/feature/operasyon/DosyaSecici';

interface PcArizaEkleModalProps {
  envanterId: string;
  envanterAd?: string;
  envanterKod?: string;
  onClose: () => void;
  onSaved: () => void;
}

const ARIZA_TURU_OPTIONS = [
  { value: 'donanim', label: 'Donanım Arızası' },
  { value: 'yazilim', label: 'Yazılım Hatası' },
  { value: 'performans', label: 'Performans Sorunu' },
  { value: 'isletim_sistemi', label: 'İşletim Sistemi' },
  { value: 'ag_baglanti', label: 'Ağ / Bağlantı' },
  { value: 'diger', label: 'Diğer' },
];

const ARIZA_KATEGORI_OPTIONS = [
  { value: 'klavye', label: 'Klavye' },
  { value: 'ekran', label: 'Ekran' },
  { value: 'batarya', label: 'Batarya' },
  { value: 'anakart', label: 'Anakart' },
  { value: 'depolama', label: 'Depolama' },
  { value: 'diger', label: 'Diğer' },
];

function bugunIso(): string {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Bilgisayar envanteri için "Arıza Kaydı Ekle" modalı (Uzman / Hekim / DSP).
 * Sol: arıza fotoğrafları. Sağ: arıza bilgileri. Açıklama (veya başlık) dışındaki
 * alanlar OPSİYONELDİR. Mevcut arıza/service/storage yapısı kullanılır
 * (bilgisayar_ariza); türe özel ek alanlar additive metadata kolonunda saklanır.
 */
export default function PcArizaEkleModal({ envanterId, envanterAd, envanterKod, onClose, onSaved }: PcArizaEkleModalProps) {
  const { addToast } = useToastActions();

  const [tarih, setTarih] = useState(bugunIso());
  const [saat, setSaat] = useState('');
  const [arizaTuru, setArizaTuru] = useState('');
  const [kategori, setKategori] = useState('');
  const [baslik, setBaslik] = useState('');
  const [aciklama, setAciklama] = useState('');
  const [servisGerekli, setServisGerekli] = useState<'evet' | 'hayir' | ''>('');
  const [tahminiMaliyet, setTahminiMaliyet] = useState('');
  const [notlar, setNotlar] = useState('');
  const [files, setFiles] = useState<SeciliDosya[]>([]);
  const [submitError, setSubmitError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (loading) return;
    const aciklamaTrim = aciklama.trim();
    if (!aciklamaTrim && !baslik.trim()) {
      setSubmitError('Arıza açıklaması veya başlığı girmelisiniz.');
      return;
    }
    setLoading(true);
    setSubmitError('');
    try {
      await createAriza({
        envanterId,
        aciklama: aciklamaTrim,
        metadata: {
          arizaTarihi: tarih || null,
          arizaSaati: saat || null,
          arizaTuru: arizaTuru || null,
          arizaKategorisi: kategori || null,
          baslik: baslik.trim() || null,
          servisGerekli: servisGerekli === '' ? null : servisGerekli === 'evet',
          tahminiMaliyet: tahminiMaliyet !== '' ? Number(tahminiMaliyet) : null,
          notlar: notlar.trim() || null,
        },
        files: files.map((f) => f.file),
      });
      addToast({ title: 'Kayıt oluşturuldu', message: 'Arıza kaydı başarıyla eklendi.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      const msg = friendlyOperasyonError(e);
      setSubmitError(msg);
      addToast({ title: 'İşlem başarısız', message: msg, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full min-h-0 gap-3">
      {envanterAd && (
        <div className="flex items-center gap-3 p-3 isg-section">
          <div className="w-11 h-11 rounded-xl bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-computer-line text-primary-600 dark:text-primary-400 text-lg" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm font-semibold text-foreground-950 truncate">{envanterAd}</h3>
              <span className="inline-flex items-center gap-1 text-xs text-success-700 dark:text-success-400 font-medium">
                <i className="ri-checkbox-circle-fill text-success-500" />
                Zimmetli
              </span>
            </div>
            <p className="text-xs text-foreground-500 mt-0.5">
              {envanterKod && <>Kod: <span className="font-medium text-foreground-700">{envanterKod}</span><span className="mx-2 text-foreground-300">|</span></>}
              Tür: <span className="font-medium text-foreground-700">Bilgisayar</span>
            </p>
          </div>
        </div>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto pr-0.5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {/* SOL: Arıza fotoğrafları */}
          <div className="isg-card isg-card-pad">
            <h3 className="isg-text-card-title text-foreground-950 mb-3">Arıza Fotoğrafları</h3>
            <DosyaSecici
              label=""
              files={files}
              onChange={setFiles}
              helpText="Sürükleyin veya tıklayarak seçin · JPG, PNG, PDF (Maks. 10 MB)"
            />
          </div>

          {/* SAĞ: Arıza bilgileri */}
          <div className="isg-card isg-card-pad">
            <h3 className="isg-text-card-title text-foreground-950 mb-3">Arıza Bilgileri</h3>
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <DatePicker label="Arıza Tarihi" value={tarih} onChange={(e) => setTarih(e.target.value)} />
                <Input label="Arıza Saati" type="time" value={saat} onChange={(e) => setSaat(e.target.value)} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Select label="Arıza Türü" options={ARIZA_TURU_OPTIONS} value={arizaTuru} onChange={(e) => setArizaTuru(e.target.value)} placeholder="Seçiniz" />
                <Select label="Arıza Kategorisi" options={ARIZA_KATEGORI_OPTIONS} value={kategori} onChange={(e) => setKategori(e.target.value)} placeholder="Seçiniz" />
              </div>

              <Input label="Arıza Başlığı" placeholder="Ör. Klavye tuş arızası" value={baslik} onChange={(e) => setBaslik(e.target.value)} />

              <Textarea
                label="Arıza Açıklaması"
                placeholder="Arıza ile ilgili detayları yazın"
                value={aciklama}
                onChange={(e) => setAciklama(e.target.value)}
                maxLength={500}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
                <div>
                  <span className="isg-form-label">Servis Gerekiyor mu?</span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setServisGerekli('evet')}
                      className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-md border text-sm cursor-pointer transition-colors ${
                        servisGerekli === 'evet'
                          ? 'bg-primary-500 border-primary-500 text-inverse'
                          : 'bg-background-100 border-background-300 text-foreground-700 hover:bg-background-200 dark:bg-background-200 dark:border-background-400/40'
                      }`}
                    >
                      <i className="ri-check-line" /> Evet
                    </button>
                    <button
                      type="button"
                      onClick={() => setServisGerekli('hayir')}
                      className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-md border text-sm cursor-pointer transition-colors ${
                        servisGerekli === 'hayir'
                          ? 'bg-primary-500 border-primary-500 text-inverse'
                          : 'bg-background-100 border-background-300 text-foreground-700 hover:bg-background-200 dark:bg-background-200 dark:border-background-400/40'
                      }`}
                    >
                      <i className="ri-close-line" /> Hayır
                    </button>
                  </div>
                </div>
                <Input label="Tahmini Maliyet (₺)" type="number" min={0} step="0.01" placeholder="Ör. 0,00" value={tahminiMaliyet} onChange={(e) => setTahminiMaliyet(e.target.value)} disabled={servisGerekli === 'hayir'} />
              </div>

              <Textarea label="Notlar" placeholder="Ek notlar (opsiyonel)" value={notlar} onChange={(e) => setNotlar(e.target.value)} maxLength={500} />
            </div>
          </div>
        </div>

        {submitError && <Alert variant="danger" className="mt-3">{submitError}</Alert>}
      </div>

      <div className="flex-shrink-0 flex justify-end gap-2 pt-3 border-t isg-divider">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={loading}>İptal</Button>
        <button
          type="button"
          onClick={handleSubmit}
          disabled={loading}
          className="isg-btn isg-btn-sm bg-warning-500 hover:bg-warning-600 text-inverse disabled:opacity-55 cursor-pointer whitespace-nowrap"
        >
          <span className="isg-btn-content">
            <i className="ri-bug-line" />
            Arıza Kaydını Ekle
          </span>
        </button>
      </div>
    </div>
  );
}