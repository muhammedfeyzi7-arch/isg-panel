import { useState } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import DatePicker from '@/components/ui/DatePicker';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import { useToastActions } from '@/hooks/useToast';
import { createAracOperasyon, friendlyOperasyonError } from '@/lib/operasyonService';
import DosyaSecici, { type SeciliDosya } from '@/components/feature/operasyon/DosyaSecici';

interface KazaEkleModalProps {
  envanterId: string;
  envanterAd?: string;
  envanterKod?: string;
  onClose: () => void;
  onSaved: () => void;
}

const KAZA_TURU_OPTIONS = [
  { value: 'carpma', label: 'Çarpma' },
  { value: 'devrilme', label: 'Devrilme' },
  { value: 'yanma', label: 'Yanma' },
  { value: 'maddi_hasar', label: 'Maddi Hasarlı' },
  { value: 'diger', label: 'Diğer' },
];

const HASAR_DURUMU_OPTIONS = [
  { value: 'maddi', label: 'Maddi Hasarlı' },
  { value: 'yaralanmali', label: 'Yaralanmalı' },
  { value: 'can_kaybi', label: 'Can Kaybı' },
  { value: 'hasar_yok', label: 'Hasar Yok' },
];

function bugunIso(): string {
  return new Date().toISOString().slice(0, 10);
}

/**
 * "Kaza Kaydı Ekle" modalı (Uzman / Hekim / DSP). Sol: kaza fotoğrafları.
 * Sağ: kaza bilgileri. Tüm alanlar OPSİYONELDİR (zorunlu yok). Mevcut
 * operasyon/service/storage yapısı kullanılır (tur = 'kaza'); türe özel ek
 * alanlar backend'deki additive `metadata` kolonunda saklanır.
 */
export default function KazaEkleModal({ envanterId, envanterAd, envanterKod, onClose, onSaved }: KazaEkleModalProps) {
  const { addToast } = useToastActions();

  const [tarih, setTarih] = useState(bugunIso());
  const [saat, setSaat] = useState('');
  const [yer, setYer] = useState('');
  const [kazaTuru, setKazaTuru] = useState('');
  const [hasarDurumu, setHasarDurumu] = useState('');
  const [aciklama, setAciklama] = useState('');
  const [tutanakVar, setTutanakVar] = useState<'evet' | 'hayir' | ''>('');
  const [tutanakNo, setTutanakNo] = useState('');
  const [notlar, setNotlar] = useState('');
  const [files, setFiles] = useState<SeciliDosya[]>([]);
  const [submitError, setSubmitError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (loading) return;
    setLoading(true);
    setSubmitError('');
    try {
      await createAracOperasyon({
        kind: 'kaza',
        envanterId,
        tarih: tarih || null,
        yakitTuru: null,
        litre: null,
        tutar: null,
        aciklama: aciklama.trim() || null,
        metadata: {
          kazaSaati: saat || null,
          kazaYeri: yer.trim() || null,
          kazaTuru: kazaTuru || null,
          hasarDurumu: hasarDurumu || null,
          tutanakVar: tutanakVar === '' ? null : tutanakVar === 'evet',
          tutanakNo: tutanakNo.trim() || null,
          notlar: notlar.trim() || null,
        },
        files: files.map((f) => f.file),
      });
      addToast({ title: 'Kayıt oluşturuldu', message: 'Kaza kaydı başarıyla eklendi.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      const msg = friendlyOperasyonError(e);
      setSubmitError(msg);
      addToast({ title: 'İşlem başarısız', message: msg, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full min-h-0 gap-3">
      {envanterAd && (
        <div className="flex items-center gap-3 p-3 isg-section">
          <div className="w-11 h-11 rounded-xl bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className="ri-car-line text-primary-600 dark:text-primary-400 text-lg" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm font-semibold text-foreground-950 truncate">{envanterAd}</h3>
              <span className="inline-flex items-center gap-1 text-xs text-success-700 dark:text-success-400 font-medium">
                <i className="ri-checkbox-circle-fill text-success-500" />
                Zimmetli
              </span>
            </div>
            <p className="text-xs text-foreground-500 mt-0.5">
              {envanterKod && <>Kod: <span className="font-medium text-foreground-700">{envanterKod}</span><span className="mx-2 text-foreground-300">|</span></>}
              Tür: <span className="font-medium text-foreground-700">Araç</span>
            </p>
          </div>
        </div>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto pr-0.5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {/* SOL: Kaza fotoğrafları */}
          <div className="isg-card isg-card-pad">
            <h3 className="isg-text-card-title text-foreground-950 mb-3">Kaza Fotoğrafları</h3>
            <DosyaSecici
              label=""
              files={files}
              onChange={setFiles}
              helpText="Sürekli birkaç veya tıklayarak seçin · JPG, PNG, PDF (Maks. 10 MB)"
            />
          </div>

          {/* SAĞ: Kaza bilgileri */}
          <div className="isg-card isg-card-pad">
            <h3 className="isg-text-card-title text-foreground-950 mb-3">Kaza Bilgileri</h3>
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <DatePicker label="Kaza Tarihi" value={tarih} onChange={(e) => setTarih(e.target.value)} />
                <Input label="Kaza Saati" type="time" value={saat} onChange={(e) => setSaat(e.target.value)} />
              </div>

              <Input label="Kaza Yeri" placeholder="Ör. Ankara / Çankaya" value={yer} onChange={(e) => setYer(e.target.value)} />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Select label="Kaza Türü" options={KAZA_TURU_OPTIONS} value={kazaTuru} onChange={(e) => setKazaTuru(e.target.value)} placeholder="Seçiniz" />
                <Select label="Hasar Durumu" options={HASAR_DURUMU_OPTIONS} value={hasarDurumu} onChange={(e) => setHasarDurumu(e.target.value)} placeholder="Seçiniz" />
              </div>

              <Textarea label="Kaza Açıklaması" placeholder="Kaza ile ilgili detayları yazın" value={aciklama} onChange={(e) => setAciklama(e.target.value)} maxLength={500} />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-end">
                <div>
                  <span className="isg-form-label">Tutanak Var mı?</span>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setTutanakVar('evet')}
                      className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-md border text-sm cursor-pointer transition-colors ${
                        tutanakVar === 'evet'
                          ? 'bg-primary-500 border-primary-500 text-inverse'
                          : 'bg-background-100 border-background-300 text-foreground-700 hover:bg-background-200 dark:bg-background-200 dark:border-background-400/40'
                      }`}
                    >
                      <i className="ri-add-circle-line" /> Evet
                    </button>
                    <button
                      type="button"
                      onClick={() => setTutanakVar('hayir')}
                      className={`flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-md border text-sm cursor-pointer transition-colors ${
                        tutanakVar === 'hayir'
                          ? 'bg-primary-500 border-primary-500 text-inverse'
                          : 'bg-background-100 border-background-300 text-foreground-700 hover:bg-background-200 dark:bg-background-200 dark:border-background-400/40'
                      }`}
                    >
                      <i className="ri-checkbox-blank-circle-line" /> Hayır
                    </button>
                  </div>
                </div>
                <Input label="Tutanak No" placeholder="Ör. TR-2026-001258" value={tutanakNo} onChange={(e) => setTutanakNo(e.target.value)} disabled={tutanakVar === 'hayir'} />
              </div>

              <Textarea label="Notlar" placeholder="Ek notlar (opsiyonel)" value={notlar} onChange={(e) => setNotlar(e.target.value)} maxLength={500} />
            </div>
          </div>
        </div>

        {submitError && <Alert variant="danger" className="mt-3">{submitError}</Alert>}
      </div>

      <div className="flex-shrink-0 flex justify-end gap-2 pt-3 border-t border-background-300/20 dark:border-background-400/20">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={loading}>İptal</Button>
        <Button variant="danger" size="sm" isLoading={loading} onClick={handleSubmit} leftIcon={<i className="ri-alert-line" />}>
          Kaza Kaydını Ekle
        </Button>
      </div>
    </div>
  );
}