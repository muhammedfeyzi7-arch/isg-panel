import { useState } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import DatePicker from '@/components/ui/DatePicker';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import { useToastActions } from '@/hooks/useToast';
import {
  createAracOperasyon,
  friendlyOperasyonError,
  type AracOperasyonTur,
} from '@/lib/operasyonService';
import DosyaSecici, { type SeciliDosya } from '@/components/feature/operasyon/DosyaSecici';

interface PcFisEkleModalProps {
  envanterId: string;
  envanterAd?: string;
  envanterKod?: string;
  /** 'bilgisayar' | 'diger' — yalnızca sunum (ikon/etiket) için. */
  envanterTuru: string;
  onClose: () => void;
  onSaved: () => void;
}

// Bilgisayar / Diğer fiş kayıt türleri (referans: Gider / Tamir / Servis).
const FIS_TUR_OPTIONS: { value: AracOperasyonTur; label: string }[] = [
  { value: 'diger_gider', label: 'Gider Fişi' },
  { value: 'tamir', label: 'Tamir Fişi' },
  { value: 'servis', label: 'Servis Fişi' },
];

const GARANTI_OPTIONS = [
  { value: 'garanti_var', label: 'Garanti Var' },
  { value: 'garanti_yok', label: 'Garanti Yok' },
];

const TUR_META: Record<string, { label: string; icon: string }> = {
  bilgisayar: { label: 'Bilgisayar', icon: 'ri-computer-line' },
  diger: { label: 'Diğer', icon: 'ri-box-3-line' },
};

function bugunIso(): string {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Bilgisayar / Diğer envanterleri için "Fiş Yükle" (fiş kaydı ekle) modalı.
 * Sol: fiş görseli + yükleme. Sağ: fiş bilgileri. Tüm alanlar OPSİYONELDİR.
 * Mevcut operasyon/service/storage yapısı kullanılır (arac_operasyonlari + tur).
 * Türe özel ek alanlar backend metadata kolonunda saklanır.
 */
export default function PcFisEkleModal({ envanterId, envanterAd, envanterKod, envanterTuru, onClose, onSaved }: PcFisEkleModalProps) {
  const { addToast } = useToastActions();

  const [tur, setTur] = useState<AracOperasyonTur>('diger_gider');
  const [tarih, setTarih] = useState(bugunIso());
  const [fisNo, setFisNo] = useState('');
  const [istasyon, setIstasyon] = useState('');
  const [urunHizmet, setUrunHizmet] = useState('');
  const [adet, setAdet] = useState('');
  const [birimFiyat, setBirimFiyat] = useState('');
  const [tutar, setTutar] = useState('');
  const [aciklama, setAciklama] = useState('');
  const [cihazParca, setCihazParca] = useState('');
  const [garanti, setGaranti] = useState('');
  const [files, setFiles] = useState<SeciliDosya[]>([]);
  const [submitError, setSubmitError] = useState('');
  const [loading, setLoading] = useState(false);

  const meta = TUR_META[envanterTuru] ?? TUR_META.diger;

  // Toplam tutar boşsa ve adet + birim fiyat girildiyse otomatik hesapla.
  const handleAdet = (v: string) => {
    setAdet(v);
    if (tutar === '' && birimFiyat !== '' && v !== '') {
      const t = Number(v) * Number(birimFiyat);
      if (Number.isFinite(t)) setTutar(String(t));
    }
  };
  const handleBirim = (v: string) => {
    setBirimFiyat(v);
    const carpan = adet !== '' ? Number(adet) : 1;
    if (tutar === '' && v !== '') {
      const t = carpan * Number(v);
      if (Number.isFinite(t)) setTutar(String(t));
    }
  };

  const handleSubmit = async () => {
    if (loading) return;
    setLoading(true);
    setSubmitError('');
    try {
      await createAracOperasyon({
        kind: tur,
        envanterId,
        tarih: tarih || null,
        yakitTuru: null,
        litre: null,
        tutar: tutar !== '' ? Number(tutar) : null,
        aciklama: aciklama.trim() || null,
        metadata: {
          fisNo: fisNo.trim() || null,
          istasyonFirma: istasyon.trim() || null,
          urunHizmetTuru: urunHizmet.trim() || null,
          adet: adet !== '' ? Number(adet) : null,
          birimFiyat: birimFiyat !== '' ? Number(birimFiyat) : null,
          cihazParca: cihazParca.trim() || null,
          garantiDurumu: garanti || null,
        },
        files: files.map((f) => f.file),
      });
      addToast({ title: 'Kayıt oluşturuldu', message: 'Fiş kaydı başarıyla eklendi.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      const msg = friendlyOperasyonError(e);
      setSubmitError(msg);
      addToast({ title: 'İşlem başarısız', message: msg, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full min-h-0 gap-3">
      {envanterAd && (
        <div className="flex items-center gap-3 p-3 isg-section">
          <div className="w-11 h-11 rounded-xl bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
            <i className={`${meta.icon} text-primary-600 dark:text-primary-400 text-lg`} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <h3 className="text-sm font-semibold text-foreground-950 truncate">{envanterAd}</h3>
              <span className="inline-flex items-center gap-1 text-xs text-success-700 dark:text-success-400 font-medium">
                <i className="ri-checkbox-circle-fill text-success-500" />
                Zimmetli
              </span>
            </div>
            <p className="text-xs text-foreground-500 mt-0.5">
              {envanterKod && <>Kod: <span className="font-medium text-foreground-700">{envanterKod}</span><span className="mx-2 text-foreground-300">|</span></>}
              Tür: <span className="font-medium text-foreground-700">{meta.label}</span>
            </p>
          </div>
        </div>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto pr-0.5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {/* SOL: Fiş görseli */}
          <div className="isg-card isg-card-pad">
            <h3 className="isg-text-card-title text-foreground-950 mb-3">Fiş Görseli</h3>
            <DosyaSecici
              label=""
              files={files}
              onChange={setFiles}
              helpText="Sürükleyin veya tıklayarak seçin · JPG, PNG, PDF (Maks. 10 MB)"
            />
          </div>

          {/* SAĞ: Fiş bilgileri */}
          <div className="isg-card isg-card-pad">
            <h3 className="isg-text-card-title text-foreground-950 mb-3">Fiş Bilgileri</h3>
            <div className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Select
                  label="Kayıt Türü"
                  options={FIS_TUR_OPTIONS}
                  value={tur}
                  onChange={(e) => setTur(e.target.value as AracOperasyonTur)}
                />
                <DatePicker label="Tarih" value={tarih} onChange={(e) => setTarih(e.target.value)} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input label="Fiş No" placeholder="Ör. 000125" value={fisNo} onChange={(e) => setFisNo(e.target.value)} />
                <Input label="İstasyon / Firma" placeholder="Ör. Vatan Bilgisayar" value={istasyon} onChange={(e) => setIstasyon(e.target.value)} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input label="Ürün / Hizmet Türü" placeholder="Ör. Bilgisayar Ekipmanı" value={urunHizmet} onChange={(e) => setUrunHizmet(e.target.value)} />
                <Input label="Adet" type="number" min={0} step="1" placeholder="Ör. 1" value={adet} onChange={(e) => handleAdet(e.target.value)} />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input label="Birim Fiyat (₺)" type="number" min={0} step="0.01" placeholder="Ör. 750,00" value={birimFiyat} onChange={(e) => handleBirim(e.target.value)} />
                <Input label="Toplam Tutar (₺)" type="number" min={0} step="0.01" placeholder="Ör. 750,00" value={tutar} onChange={(e) => setTutar(e.target.value)} />
              </div>

              <Textarea
                label="Açıklama"
                placeholder="Kısa açıklama (opsiyonel)"
                value={aciklama}
                onChange={(e) => setAciklama(e.target.value)}
                maxLength={500}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Input label="Cihaz / Parça" placeholder="Ör. Logitech Mouse" value={cihazParca} onChange={(e) => setCihazParca(e.target.value)} />
                <Select
                  label="Garanti Durumu"
                  options={GARANTI_OPTIONS}
                  value={garanti}
                  onChange={(e) => setGaranti(e.target.value)}
                  placeholder="Seçiniz"
                />
              </div>
            </div>
          </div>
        </div>

        {submitError && <Alert variant="danger" className="mt-3">{submitError}</Alert>}
      </div>

      <div className="flex-shrink-0 flex justify-end gap-2 pt-3 border-t isg-divider">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={loading}>İptal</Button>
        <Button variant="primary" size="sm" isLoading={loading} onClick={handleSubmit} leftIcon={<i className="ri-save-line" />}>
          Fişi Kaydet
        </Button>
      </div>
    </div>
  );
}