import { useState } from 'react';
import Button from '@/components/ui/Button';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import Card from '@/components/ui/Card';
import Alert from '@/components/ui/Alert';
import { useToastActions } from '@/hooks/useToast';
import {
  zimmetOsgbDusur,
  friendlyZimmetError,
  type KapanisNedeni,
} from '@/lib/zimmetService';

interface ZimmetDusurModalProps {
  zimmetId: string;
  onClose: () => void;
  onSaved: () => void;
}

const NEDEN_OPTIONS: { value: string; label: string }[] = [
  { value: 'osgb_tarafindan_dusuruldu', label: 'OSGB Tarafından Düşürüldü' },
  { value: 'personel_isten_ayrildi', label: 'Personel İşten Ayrıldı' },
  { value: 'diger', label: 'Diğer' },
];

export default function ZimmetDusurModal({ zimmetId, onClose, onSaved }: ZimmetDusurModalProps) {
  const { addToast } = useToastActions();
  const [neden, setNeden] = useState<string>('osgb_tarafindan_dusuruldu');
  const [aciklama, setAciklama] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const submit = async () => {
    if (submitting) return;
    setSubmitting(true);
    setError('');
    try {
      await zimmetOsgbDusur(zimmetId, {
        kapanisNedeni: neden as KapanisNedeni,
        aciklama: aciklama.trim() || null,
      });
      addToast({ title: 'Zimmet düşürüldü', message: 'Zimmet kapatıldı ve envanter yeniden zimmetlenebilir.', type: 'success' });
      onSaved();
      onClose();
    } catch (e) {
      const msg = friendlyZimmetError(e);
      setError(msg);
      addToast({ title: 'İşlem başarısız', message: msg, type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Başlık bandı (premium) */}
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-danger-50 dark:bg-danger-500/15 flex items-center justify-center flex-shrink-0">
          <i className="ri-close-circle-line text-danger-600 dark:text-danger-400 text-2xl" />
        </div>
        <div className="min-w-0">
          <h3 className="text-base font-semibold text-foreground-950">Zimmetten Düşür</h3>
          <p className="text-sm text-foreground-500 mt-0.5">Personel onayı beklemeden zimmeti kapatın.</p>
        </div>
      </div>

      <Alert variant="warning">
        Bu işlem zimmeti personel onayı beklemeden kapatır. Kayıt silinmez, geçmiş korunur ve envanter yeniden zimmetlenebilir duruma gelir.
      </Alert>

      <Card title="Kapanış Bilgileri" padding="md" headerAction={<i className="ri-archive-line text-secondary-500" />}>
        <div className="space-y-3">
          <Select
            label="Kapanış Nedeni"
            options={NEDEN_OPTIONS}
            value={neden}
            onChange={(e) => setNeden(e.target.value)}
          />

          <Textarea
            label="Açıklama / Gerekçe"
            placeholder="Düşürme gerekçesi (opsiyonel)"
            value={aciklama}
            onChange={(e) => setAciklama(e.target.value)}
            maxLength={500}
          />
        </div>
      </Card>

      {error && <Alert variant="danger">{error}</Alert>}

      <div className="flex justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={submitting}>İptal</Button>
        <Button variant="danger" size="sm" isLoading={submitting} onClick={submit} leftIcon={<i className="ri-close-circle-line" />}>
          Zimmetten Düşür
        </Button>
      </div>
    </div>
  );
}