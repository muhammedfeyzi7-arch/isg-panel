import { useState } from 'react';
import Alert from '@/components/ui/Alert';
import Button from '@/components/ui/Button';
import Textarea from '@/components/ui/Textarea';
import Card from '@/components/ui/Card';
import { useToastActions } from '@/hooks/useToast';
import {
  zimmetIadeTalebi,
  zimmetPersonelIade,
  friendlyZimmetError,
} from '@/lib/zimmetService';

interface ZimmetIadeModalProps {
  zimmetId: string;
  mode: 'osgb_iade_talebi' | 'personel_iade';
  onClose: () => void;
  onSaved: () => void;
}

const ALLOWED_IMG = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_SIZE = 10 * 1024 * 1024;

interface Photo {
  id: string;
  file: File;
  preview: string;
}

let photoIdCounter = 0;

export default function ZimmetIadeModal({ zimmetId, mode, onClose, onSaved }: ZimmetIadeModalProps) {
  const { addToast } = useToastActions();
  const [notu, setNotu] = useState('');
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const isOsgb = mode === 'osgb_iade_talebi';

  const addPhotos = (files: FileList | null) => {
    if (!files) return;
    setError('');
    const arr = Array.from(files);
    const next: Photo[] = [];
    for (const f of arr) {
      if (!ALLOWED_IMG.includes(f.type)) {
        setError('Yalnızca JPG, PNG veya WebP görsel yükleyebilirsiniz.');
        continue;
      }
      if (f.size > MAX_SIZE) {
        setError('Görsel boyutu 10 MB sınırını aşıyor.');
        continue;
      }
      next.push({ id: `photo-${++photoIdCounter}`, file: f, preview: URL.createObjectURL(f) });
    }
    setPhotos((p) => [...p, ...next]);
  };

  const removePhoto = (id: string) => {
    setPhotos((p) => {
      const target = p.find((x) => x.id === id);
      if (target) URL.revokeObjectURL(target.preview);
      return p.filter((x) => x.id !== id);
    });
  };

  const submit = async () => {
    if (submitting) return;
    setSubmitting(true);
    setError('');
    try {
      if (isOsgb) {
        await zimmetIadeTalebi(zimmetId, notu.trim() || null);
        addToast({ title: 'İade talebi başlatıldı', message: 'Personel bilgilendirildi.', type: 'success' });
      } else {
        await zimmetPersonelIade(zimmetId, {
          iadeNotu: notu.trim() || null,
          iadeGorselleri: photos.map((p) => p.file),
        });
        addToast({ title: 'İade gönderildi', message: 'OSGB onayı bekleniyor.', type: 'success' });
      }
      onSaved();
      onClose();
    } catch (e) {
      const msg = friendlyZimmetError(e);
      setError(msg);
      addToast({ title: 'İşlem başarısız', message: msg, type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Başlık bandı (premium) */}
      <div className="flex items-start gap-3">
        <div className="w-12 h-12 rounded-xl bg-primary-50 dark:bg-primary-500/15 flex items-center justify-center flex-shrink-0">
          <i className="ri-arrow-go-back-line text-primary-600 dark:text-primary-400 text-2xl" />
        </div>
        <div className="min-w-0">
          <h3 className="text-base font-semibold text-foreground-950">
            {isOsgb ? 'İade Talebi Başlat' : 'İadeyi Gönder'}
          </h3>
          <p className="text-sm text-foreground-500 mt-0.5">
            {isOsgb ? 'Personelden envanterin iade edilmesini talep edin.' : 'Envanteri iade etmek için durum ve fotoğrafları ekleyin.'}
          </p>
        </div>
      </div>

      <Card title="İade Bilgileri" padding="md" headerAction={<i className="ri-sticky-note-line text-secondary-500" />}>
        <Textarea
          label={isOsgb ? 'İade Talebi Notu' : 'İade Notu'}
          placeholder={isOsgb ? 'İade talebinin nedeni (opsiyonel)' : 'İade teslimiyle ilgili not (opsiyonel)'}
          value={notu}
          onChange={(e) => setNotu(e.target.value)}
          maxLength={500}
        />
      </Card>

      {/* İade fotoğrafları — yalnızca personel iadesinde. */}
      {!isOsgb && (
        <Card title="İade Fotoğrafları" padding="md" headerAction={<i className="ri-camera-line text-secondary-500" />}>
          <label className="flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed border-background-300 bg-background-100 hover:bg-background-200 p-5 cursor-pointer transition-colors">
            <i className="ri-image-add-line text-2xl text-foreground-400" />
            <p className="text-sm text-foreground-600 text-center">
              İade fotoğrafı eklemek için tıklayın veya sürükleyin
            </p>
            <p className="text-xs text-foreground-400">Araç/cihaz ve hasar fotoğrafları — JPG, PNG, WebP, en fazla 10 MB</p>
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              multiple
              className="hidden"
              onChange={(e) => { addPhotos(e.target.files); e.target.value = ''; }}
            />
          </label>

          {photos.length > 0 && (
            <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2">
              {photos.map((p) => (
                <div key={p.id} className="relative group rounded-lg overflow-hidden border border-background-300/40 bg-background-100">
                  <img src={p.preview} alt={p.file.name} className="w-full h-24 object-cover object-top" />
                  <button
                    type="button"
                    onClick={() => removePhoto(p.id)}
                    className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/60 text-inverse flex items-center justify-center hover:bg-danger-600 transition-colors cursor-pointer"
                    aria-label="Görseli kaldır"
                  >
                    <i className="ri-close-line text-sm" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {error && (
        <Alert variant="danger">{error}</Alert>
      )}

      <div className="flex justify-end gap-2 pt-1">
        <Button variant="ghost" size="sm" onClick={onClose} disabled={submitting}>İptal</Button>
        <Button variant="primary" size="sm" isLoading={submitting} onClick={submit} leftIcon={<i className="ri-arrow-go-back-line" />}>
          {isOsgb ? 'İade Talebi Başlat' : 'İadeyi Gönder'}
        </Button>
      </div>
    </div>
  );
}