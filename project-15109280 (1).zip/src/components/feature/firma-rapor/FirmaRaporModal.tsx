// ─────────────────────────────────────────────────────────────────────────────
// FİRMA RAPOR AL MODALI
//
// Ekipmanlar sekmesindeki "Dışa Aktar" penceresiyle AYNI düzen: üstten alta
// numaralı bölümler (① Kayıtlar · ② Sütunlar · ③ Dosya Formatı), sabit footer.
//
// Sütunlar sistemin STANDART firma rapor kolonlarıdır (firmaKolonlari). Seçilen
// kapsam + sütun + format gerçek kurumsal Excel/CSV motoruna iletilir.
// ─────────────────────────────────────────────────────────────────────────────
import { useCallback, useMemo, useState } from 'react';
import Button from '@/components/ui/Button';
import Checkbox from '@/components/ui/Checkbox';
import Radio from '@/components/ui/Radio';
import { useToastActions } from '@/hooks/useToast';

export type FirmaExportScope = 'filtreli' | 'tumu';
export type FirmaExportFormat = 'xlsx' | 'csv';

export interface FirmaExportColumn {
  key: string;
  label: string;
}

export interface FirmaExportOptions {
  scope: FirmaExportScope;
  format: FirmaExportFormat;
  baseKeys: string[];
}

interface FirmaRaporModalProps {
  baseColumns: FirmaExportColumn[];
  /** Modalde gösterilecek firma sayısı (bilgi amaçlı). */
  toplamFirma: number;
  onExport: (options: FirmaExportOptions) => Promise<void>;
  onClose: () => void;
}

function NumberBadge({ n }: { n: number }) {
  return (
    <span className="w-6 h-6 rounded-full bg-primary-500 text-inverse text-xs font-bold flex items-center justify-center flex-shrink-0">
      {n}
    </span>
  );
}

export default function FirmaRaporModal({
  baseColumns,
  toplamFirma,
  onExport,
  onClose,
}: FirmaRaporModalProps) {
  const { addToast } = useToastActions();

  const [scope, setScope] = useState<FirmaExportScope>('filtreli');
  const [format, setFormat] = useState<FirmaExportFormat>('xlsx');
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(baseColumns.map((c) => c.key)),
  );
  const [busy, setBusy] = useState(false);

  const allKeys = useMemo(() => baseColumns.map((c) => c.key), [baseColumns]);
  const allSelected = selected.size === allKeys.length && allKeys.length > 0;

  const toggleKey = useCallback((key: string, checked: boolean) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (checked) next.add(key);
      else next.delete(key);
      return next;
    });
  }, []);

  const selectAll = useCallback(() => setSelected(new Set(allKeys)), [allKeys]);
  const clearAll = useCallback(() => setSelected(new Set()), []);

  const exportDisabled = busy || selected.size === 0 || toplamFirma === 0;

  const handleExport = useCallback(async () => {
    if (busy) return;
    if (selected.size === 0) {
      addToast({ title: 'Sütun seçin', message: 'Dışa aktarmak için en az bir sütun seçmelisiniz.', type: 'warning' });
      return;
    }
    const baseKeys = baseColumns.map((c) => c.key).filter((k) => selected.has(k));
    setBusy(true);
    try {
      await onExport({ scope, format, baseKeys });
      addToast({
        title: 'Rapor hazırlandı',
        message: format === 'csv' ? 'CSV dosyası indirildi.' : 'Excel dosyası indirildi.',
        type: 'success',
      });
      onClose();
    } catch (e) {
      const msg = e instanceof Error && e.message ? e.message : 'Dosya oluşturulamadı. Lütfen tekrar deneyin.';
      addToast({ title: 'Rapor alınamadı', message: msg, type: 'error' });
    } finally {
      setBusy(false);
    }
  }, [busy, selected, scope, baseColumns, format, onExport, addToast, onClose]);

  return (
    <div
      className="flex flex-col"
      style={{
        margin: 'calc(var(--d-modal-body-py) * -1) calc(var(--d-modal-body-px) * -1)',
        height: 'calc(100% + var(--d-modal-body-py) * 2)',
      }}
    >
      <div className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden isg-scroll-pane px-4 py-3 space-y-4">
        {/* ── Bölüm 1: Kapsam ── */}
        <div className="space-y-2.5">
          <div className="flex items-center gap-2.5">
            <NumberBadge n={1} />
            <h4 className="text-sm font-semibold text-foreground-900">Rapora Girecek Kayıtlar</h4>
          </div>
          <div className="space-y-3 pl-8">
            <Radio
              name="firma-export-scope"
              value="filtreli"
              checked={scope === 'filtreli'}
              onChange={() => setScope('filtreli')}
              label="Ekrandaki görünüm"
              helpText="Aktif sekme + uygulanan filtreler dikkate alınır."
            />
            <Radio
              name="firma-export-scope"
              value="tumu"
              checked={scope === 'tumu'}
              onChange={() => setScope('tumu')}
              label="Tüm firmalar"
              helpText="Filtrelerden bağımsız olarak OSGB kapsamındaki tüm firmalar."
            />
            <p className="text-[11px] text-foreground-400">
              Rapora girecek toplam firma (kapsam kapsamına göre değişir): {toplamFirma}
            </p>
          </div>
        </div>

        {/* ── Bölüm 2: Sütunlar ── */}
        <div className="space-y-2.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <NumberBadge n={2} />
              <h4 className="text-sm font-semibold text-foreground-900">Rapor Sütunları</h4>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="secondary" size="sm" onClick={selectAll} disabled={allSelected}>
                Tümünü Seç
              </Button>
              <Button variant="ghost" size="sm" onClick={clearAll} disabled={selected.size === 0}>
                Tümünü Kaldır
              </Button>
            </div>
          </div>
          <div className="rounded-md border border-background-300/60 bg-background-100/60 p-3">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2.5">
              {baseColumns.map((c) => (
                <Checkbox
                  key={c.key}
                  checked={selected.has(c.key)}
                  onChange={(e) => toggleKey(c.key, e.target.checked)}
                  label={c.label}
                />
              ))}
            </div>
          </div>
        </div>

        {/* ── Bölüm 3: Dosya Formatı ── */}
        <div className="space-y-2.5">
          <div className="flex items-center gap-2.5">
            <NumberBadge n={3} />
            <h4 className="text-sm font-semibold text-foreground-900">Dosya Formatı</h4>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-start gap-3 sm:gap-8 pl-8">
            <Radio
              name="firma-export-format"
              value="xlsx"
              checked={format === 'xlsx'}
              onChange={() => setFormat('xlsx')}
              label="Excel (.xlsx)"
              helpText="Önerilen. Kurumsal tasarım ve biçimlendirmeler korunur."
            />
            <Radio
              name="firma-export-format"
              value="csv"
              checked={format === 'csv'}
              onChange={() => setFormat('csv')}
              label="CSV (.csv)"
              helpText="Sade veri formatı."
            />
          </div>
        </div>
      </div>

      {/* ── Footer (sabit) ── */}
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-t isg-divider flex-shrink-0">
        <Button variant="ghost" onClick={onClose} disabled={busy}>
          İptal
        </Button>
        <Button
          variant="primary"
          leftIcon={busy ? undefined : <i className="ri-file-download-line" />}
          onClick={handleExport}
          isLoading={busy}
          disabled={exportDisabled}
        >
          {busy ? 'Hazırlanıyor...' : 'Raporu İndir'}
        </Button>
      </div>
    </div>
  );
}