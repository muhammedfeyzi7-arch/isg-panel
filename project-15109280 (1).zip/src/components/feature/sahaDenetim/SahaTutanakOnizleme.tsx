import type { ReactNode } from 'react';
import type { TutanakFirma, TutanakOsgb } from '@/lib/sahaTutanakService';

/**
 * Saha Denetim Tutanağı — A4 canlı önizleme.
 * Modalın sağ tarafında gerçek belge düzenini (kurumsal başlık + bilgi tablosu +
 * içerik + ekler + imza alanları) birebir yansıtır. Salt görüntüdür; veriyi
 * değiştirmez. Zengin metin (**kalın**, _eğik_, __altı çizili__) burada da render edilir.
 */

function renderInline(text: string): ReactNode[] {
  const nodes: ReactNode[] = [];
  const re = /(\*\*[^*]+\*\*|__[^_]+__|_[^_]+_)/g;
  let last = 0;
  let m: RegExpExecArray | null;
  let key = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) nodes.push(<span key={key++}>{text.slice(last, m.index)}</span>);
    const tok = m[1];
    if (tok.startsWith('**')) nodes.push(<strong key={key++}>{tok.slice(2, -2)}</strong>);
    else if (tok.startsWith('__')) nodes.push(<u key={key++}>{tok.slice(2, -2)}</u>);
    else nodes.push(<em key={key++}>{tok.slice(1, -1)}</em>);
    last = m.index + tok.length;
  }
  if (last < text.length) nodes.push(<span key={key++}>{text.slice(last)}</span>);
  return nodes.length ? nodes : [<span key="empty">{text}</span>];
}

function renderContent(icerik: string): ReactNode {
  return icerik
    .split(/\n{2,}/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((para, i) => {
      const lines = para.split('\n');
      return (
        <p key={i} className="text-[11px] leading-relaxed text-foreground-800 text-justify mb-2.5">
          {lines.map((ln, j) => (
            <span key={j}>
              {renderInline(ln)}
              {j < lines.length - 1 && <br />}
            </span>
          ))}
        </p>
      );
    });
}

interface Props {
  osgb: TutanakOsgb | null;
  firma: TutanakFirma | null;
  firmaAd: string;
  lokasyon: string;
  tutanakNo: string;
  tutanakTarihi: string;
  konu: string;
  icerik: string;
  denetimYapan: string;
  denetimYapanUnvan: string;
  firmaYetkili: string;
  fotolar: Array<{ id: string; url: string | null; fileName: string | null }>;
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex border border-background-300/70 dark:border-background-400/30">
      <div className="w-[34%] px-2.5 py-1.5 bg-background-200/70 dark:bg-background-300/30 border-r border-background-300/70 dark:border-background-400/30">
        <span className="text-[10px] font-semibold text-foreground-600">{label}</span>
      </div>
      <div className="flex-1 px-2.5 py-1.5">
        <span className="text-[11px] text-foreground-900">{value}</span>
      </div>
    </div>
  );
}

export default function SahaTutanakOnizleme({
  osgb,
  firma,
  firmaAd,
  lokasyon,
  tutanakNo,
  tutanakTarihi,
  konu,
  icerik,
  denetimYapan,
  denetimYapanUnvan,
  firmaYetkili,
  fotolar,
}: Props) {
  return (
    <div className="bg-white dark:bg-background-100 rounded-md border border-background-300/70 dark:border-background-400/30 p-5 min-h-[560px]">
      {/* Kurumsal başlık */}
      <div className="flex items-start justify-between gap-4 pb-3 border-b-2 border-primary-700/70">
        <div className="flex items-center gap-2.5 min-w-0">
          {osgb?.logoUrl ? (
            <img
              src={osgb.logoUrl}
              alt={osgb.unvan || 'Kurumsal logo'}
              title={`${osgb.unvan} logo`}
              className="w-11 h-11 rounded object-contain flex-shrink-0"
            />
          ) : (
            <span className="w-11 h-11 rounded bg-primary-100 dark:bg-primary-500/20 text-primary-700 flex items-center justify-center flex-shrink-0">
              <i className="ri-shield-check-line text-xl" />
            </span>
          )}
          <div className="min-w-0">
            <p className="text-sm font-bold text-foreground-950 truncate">{osgb?.unvan || 'İSGDenetim'}</p>
            <p className="text-[9px] text-foreground-400 truncate">{osgb?.slogan || 'Güvenli Yarınlar İçin, Bugünden'}</p>
          </div>
        </div>
        <p className="text-base font-bold text-primary-700 text-right flex-shrink-0 whitespace-nowrap">SAHA DENETİM TUTANAĞI</p>
      </div>

      {/* Bilgi tablosu */}
      <div className="mt-3.5 flex flex-col">
        <InfoRow label="Firma Adı" value={firmaAd || '—'} />
        <InfoRow label="Lokasyon" value={lokasyon || '—'} />
        <InfoRow label="Tutanak No" value={tutanakNo || '—'} />
        <InfoRow label="Tarih" value={tutanakTarihi || '—'} />
        <InfoRow label="Konu" value={konu || '—'} />
      </div>

      {/* İçerik */}
      <div className="mt-4">
        <p className="text-[11px] font-bold text-primary-700 tracking-wide pb-1 border-b border-background-300/70 dark:border-background-400/30 mb-2">
          TUTANAK İÇERİĞİ
        </p>
        {icerik.trim() ? (
          renderContent(icerik)
        ) : (
          <p className="text-[11px] text-foreground-400 italic">Tutanak içeriği henüz girilmedi.</p>
        )}
      </div>

      {/* Ekler */}
      {fotolar.length > 0 && (
        <div className="mt-4">
          <p className="text-[11px] font-bold text-primary-700 tracking-wide pb-1 border-b border-background-300/70 dark:border-background-400/30 mb-2">
            EKLER ({fotolar.length} FOTOĞRAF)
          </p>
          <div className="grid grid-cols-3 gap-2">
            {fotolar.map((f) => (
              <div key={f.id} className="rounded border border-background-300/70 dark:border-background-400/30 overflow-hidden aspect-[4/3] bg-background-100">
                {f.url ? (
                  <img src={f.url} alt={f.fileName ?? 'Ek fotoğraf'} title={f.fileName ?? 'Ek fotoğraf'} className="w-full h-full object-cover object-top" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-foreground-300">
                    <i className="ri-image-line" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* İmza alanları */}
      <div className="mt-6 pt-4 border-t border-background-300/70 dark:border-background-400/30 grid grid-cols-3 gap-3">
        {[
          { title: 'Denetimi Yapan', name: denetimYapan, sub: denetimYapanUnvan, dotted: false },
          { title: 'Firma Yetkilisi', name: firmaYetkili, sub: '', dotted: true },
          { title: 'Tarih', name: tutanakTarihi, sub: '', dotted: true },
        ].map((s) => (
          <div key={s.title} className="text-center">
            <p className="text-[10px] font-semibold text-foreground-800">{s.title}</p>
            <p className="text-[10px] text-foreground-700 mt-0.5 min-h-[14px]">{s.name || 'Adı Soyadı'}</p>
            {s.sub && <p className="text-[9px] text-foreground-400">{s.sub}</p>}
            <p className="mt-6 pt-1 border-t border-dashed border-foreground-300 text-[9px] text-foreground-400">
              {s.dotted ? 'İmza' : ''}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}