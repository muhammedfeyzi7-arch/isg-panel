import { useRef, useState } from 'react';
import type { ChangeEvent, ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import {
  type UygunsuzlukDetailData,
  type UygunsuzlukFoto,
} from '@/lib/sahaDenetimService';
import {
  uygunsuzlukBadgeVariant,
  formatUygunsuzlukDate,
  formatUygunsuzlukDateTime,
  terminDurum,
} from '@/pages/uzman/saha-denetimleri/components/sahaDenetimUi';
import { FotoGaleri, fotoGaleri } from '@/components/feature/sahaDenetim/UygunsuzlukFoto';
import {
  InfoRow,
  UygunsuzlukTalepKarti,
  IslemGecmisiPaneli,
  DurumSurecPaneli,
} from '@/components/feature/sahaDenetim/UygunsuzlukDetailPanels';

/**
 * Saha Denetimleri — TEK ADIMLI detay gövdesi (tab YOK).
 * Hem uzman hem firma detay modalı bu gövdeyi kullanır.
 * İçerik sırası: Genel Bilgiler → Açıklama/Önlem/Lokasyon → Tüm Fotoğraflar →
 * Tutanaklar → Sağ kolon (Durum ve Süreç / Firma / Tarih / Son İşlemler).
 */

function Section({ icon, title, children, action }: { icon: string; title: string; children: ReactNode; action?: ReactNode }) {
  return (
    <section className="rounded-lg border border-background-200/70 dark:border-background-400/25 bg-background-100 dark:bg-background-200/40 p-3">
      <div className="flex items-center justify-between gap-2 mb-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-6 h-6 rounded-md bg-primary-50 dark:bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
            <i className={`${icon} text-sm`} />
          </span>
          <h4 className="text-sm font-semibold text-foreground-900 truncate">{title}</h4>
        </div>
        {action}
      </div>
      {children}
    </section>
  );
}

function MiniCard({ icon, title, children }: { icon: string; title: string; children: ReactNode }) {
  return (
    <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 bg-background-100 dark:bg-background-200/40 p-3">
      <div className="flex items-center gap-2 mb-2">
        <span className="w-6 h-6 rounded-md bg-secondary-100 dark:bg-secondary-500/15 text-secondary-700 dark:text-secondary-400 flex items-center justify-center flex-shrink-0">
          <i className={`${icon} text-sm`} />
        </span>
        <h4 className="text-sm font-semibold text-foreground-900 truncate">{title}</h4>
      </div>
      {children}
    </div>
  );
}

interface Props {
  detail: UygunsuzlukDetailData;
  /** "Tespit Eden" için çözülen kullanıcı adı (yoksa '—'). */
  tespitEdenAd?: string | null;
  /** Uzman tarafında fotoğraf ekle/sil izni. */
  canManagePhotos?: boolean;
  onAddPhotos?: (files: File[]) => Promise<void>;
  onDeletePhoto?: (foto: UygunsuzlukFoto) => void;
  /** Tutanaklar bölümü (stage 2'de doldurulur; boşsa bilgilendirme gösterilir). */
  tutanaklar?: ReactNode;
  /** Firma kapatma talepleri (varsa talep listesi). */
  showTalepler?: boolean;
}

export default function UygunsuzlukDetayGovde({
  detail,
  tespitEdenAd,
  canManagePhotos = false,
  onAddPhotos,
  onDeletePhoto,
  tutanaklar,
  showTalepler = true,
}: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  const lokasyon = detail.lokasyon || [detail.firmaIl, detail.firmaIlce].filter(Boolean).join(' / ') || '—';
  const termin = terminDurum(detail.terminTarihi);
  const tumFoto = [...detail.openingFoto, ...detail.kapatmaFoto];
  const galeri = fotoGaleri(tumFoto);

  const handleFiles = async (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    e.target.value = '';
    if (!files.length || !onAddPhotos) return;
    setUploading(true);
    try {
      await onAddPhotos(files);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
      {/* SOL (2 kolon) */}
      <div className="lg:col-span-2 flex flex-col gap-3">
        <Section icon="ri-information-line" title="Genel Bilgiler">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6">
            <div>
              <InfoRow label="Uygunsuzluk No" value={<span className="font-semibold">{detail.no}</span>} />
              <InfoRow label="Firma" value={detail.firmaUnvan} />
              <InfoRow label="Lokasyon" value={lokasyon} />
              <InfoRow label="Açılış Tarihi" value={formatUygunsuzlukDateTime(detail.createdAt)} />
            </div>
            <div>
              <InfoRow label="Tespit Eden" value={tespitEdenAd || '—'} />
              <InfoRow label="Denetim Türü" value={detail.denetimTuru || '—'} />
              <InfoRow
                label="Termin Tarihi"
                value={
                  <span className="inline-flex items-center gap-2">
                    <span>{formatUygunsuzlukDate(detail.terminTarihi)}</span>
                    {termin && detail.durum !== 'kapali' && <Badge variant={termin.variant}>{termin.label}</Badge>}
                  </span>
                }
              />
              <InfoRow label="Durum" value={<Badge variant={uygunsuzlukBadgeVariant(detail.durum)}>{detail.durumLabel}</Badge>} />
            </div>
          </div>
        </Section>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <MiniCard icon="ri-file-text-line" title="Açıklama">
            <p className="text-sm text-foreground-700 whitespace-pre-wrap">{detail.aciklama || '—'}</p>
          </MiniCard>
          <MiniCard icon="ri-shield-check-line" title="Alınması Gereken Önlem">
            <p className="text-sm text-foreground-700 whitespace-pre-wrap">{detail.onlem || '—'}</p>
          </MiniCard>
        </div>

        <Section
          icon="ri-image-line"
          title={`Tüm Fotoğraflar (${tumFoto.length})`}
          action={
            canManagePhotos && onAddPhotos ? (
              <>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  multiple
                  className="hidden"
                  onChange={handleFiles}
                />
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  disabled={uploading}
                  className="inline-flex items-center gap-1 text-xs font-medium text-primary-600 hover:text-primary-700 cursor-pointer disabled:opacity-50 whitespace-nowrap"
                >
                  <i className={uploading ? 'ri-loader-4-line animate-spin' : 'ri-add-line'} />
                  {uploading ? 'Yükleniyor...' : 'Fotoğraf Ekle'}
                </button>
              </>
            ) : undefined
          }
        >
          <FotoGaleri
            fotolar={tumFoto}
            onDelete={canManagePhotos && onDeletePhoto ? onDeletePhoto : undefined}
            disabled={uploading}
            emptyText="Bu uygunsuzluğa ait fotoğraf kaydı yok."
          />
        </Section>

        <Section icon="ri-file-list-3-line" title="Tutanaklar">
          {tutanaklar ?? (
            <p className="text-xs text-foreground-400 py-2">Bu uygunsuzluk için henüz tutanak oluşturulmadı.</p>
          )}
        </Section>

        {showTalepler && detail.talepler.length > 0 && (
          <Section icon="ri-send-plane-line" title={`Kapatma Talepleri (${detail.talepler.length})`}>
            <div className="flex flex-col gap-2.5">
              {detail.talepler.map((t) => (
                <UygunsuzlukTalepKarti key={t.id} talep={t} />
              ))}
            </div>
          </Section>
        )}
      </div>

      {/* SAĞ KOLON */}
      <div className="flex flex-col gap-3">
        <MiniCard icon="ri-route-line" title="Durum ve Süreç">
          <DurumSurecPaneli detail={detail} />
        </MiniCard>

        <MiniCard icon="ri-building-2-line" title="Firma Bilgileri">
          <p className="text-sm font-medium text-foreground-800">{detail.firmaUnvan}</p>
          <p className="text-xs text-foreground-500 mt-0.5">
            {[detail.firmaIl, detail.firmaIlce].filter(Boolean).join(' / ') || '—'}
          </p>
        </MiniCard>

        <MiniCard icon="ri-calendar-line" title="Tarih Bilgileri">
          <InfoRow label="Açılış Tarihi" value={formatUygunsuzlukDateTime(detail.createdAt)} />
          <InfoRow label="Termin Tarihi" value={formatUygunsuzlukDate(detail.terminTarihi)} />
          {termin && detail.durum !== 'kapali' && (
            <div className="pt-2">
              <Badge variant={termin.variant}>{termin.label}</Badge>
            </div>
          )}
        </MiniCard>

        <MiniCard icon="ri-history-line" title="Son İşlemler">
          <IslemGecmisiPaneli detail={detail} />
        </MiniCard>
      </div>
    </div>
  );
}