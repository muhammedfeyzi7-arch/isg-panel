import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import ImageViewer, { type ImageViewerItem } from '@/components/ui/ImageViewer';
import {
  FOTO_KAYNAK_LABEL,
  type UygunsuzlukDetailData,
  type UygunsuzlukTalep,
} from '@/lib/sahaDenetimService';
import {
  uygunsuzlukBadgeVariant,
  formatUygunsuzlukDateTime,
} from '@/pages/uzman/saha-denetimleri/components/sahaDenetimUi';

/**
 * Saha Denetimleri detay modallarının ORTAK görüntüleme panelleri.
 * Uzman ve Firma detay modalları bu tek kaynağı kullanır.
 * Yalnızca mevcut gerçek veriler gösterilir; hiçbir alan uydurulmaz.
 */

export function InfoRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 py-2 border-b border-background-200/70 dark:border-background-400/20 last:border-0">
      <span className="text-xs text-foreground-500 flex-shrink-0">{label}</span>
      <span className="text-sm text-foreground-800 text-right break-words min-w-0">{value}</span>
    </div>
  );
}

/** Liste satırı için galeri: tüm açılış + kapatma fotoğrafları. */
export function uygunsuzlukRowGaleri(r: {
  openingFoto: Array<{ url: string | null; fileName: string | null }>;
  kapatmaFoto: Array<{ url: string | null; fileName: string | null; source: string }>;
}): ImageViewerItem[] {
  const items: ImageViewerItem[] = [];
  for (const f of r.openingFoto) {
    if (f.url) items.push({ src: f.url, alt: 'Açılış Fotoğrafı', fileName: f.fileName ?? undefined });
  }
  for (const f of r.kapatmaFoto) {
    if (f.url) {
      items.push({
        src: f.url,
        alt: FOTO_KAYNAK_LABEL[f.source as keyof typeof FOTO_KAYNAK_LABEL] ?? 'Kapatma Fotoğrafı',
        fileName: f.fileName ?? undefined,
      });
    }
  }
  return items;
}

type GecmisTone = 'primary' | 'success' | 'danger' | 'warning';

interface GecmisOlay {
  tarih: string;
  baslik: string;
  aciklama?: string;
  icon: string;
  tone: GecmisTone;
}

const TONE_CLASS: Record<GecmisTone, string> = {
  primary: 'bg-primary-50 text-primary-600 dark:bg-primary-500/15 dark:text-primary-400',
  success: 'bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-400',
  danger: 'bg-danger-50 text-danger-600 dark:bg-danger-500/15 dark:text-danger-400',
  warning: 'bg-warning-50 text-warning-600 dark:bg-warning-500/15 dark:text-warning-400',
};

function talepBadgeVariant(d: string): 'success' | 'warning' | 'danger' | 'default' {
  if (d === 'onaylandi') return 'success';
  if (d === 'reddedildi') return 'danger';
  if (d === 'bekliyor') return 'warning';
  return 'default';
}

function talepLabel(d: string): string {
  if (d === 'onaylandi') return 'Onaylandı';
  if (d === 'reddedildi') return 'Reddedildi';
  return 'Bekliyor';
}

/** Kapatma talebi kartı — talep eden, tarih, açıklama, fotoğraflar ve sonuç. */
export function UygunsuzlukTalepKarti({ talep, showEden = true }: { talep: UygunsuzlukTalep; showEden?: boolean }) {
  const initials =
    (talep.talepEdenName || '?')
      .split(' ')
      .filter(Boolean)
      .slice(0, 2)
      .map((w) => w[0]?.toUpperCase())
      .join('') || '?';

  return (
    <div className="rounded-lg border border-background-200/70 dark:border-background-400/25 p-3">
      <div className="flex items-start gap-2.5">
        <span className="w-9 h-9 rounded-full bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300 flex items-center justify-center text-xs font-bold flex-shrink-0">
          {initials}
        </span>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-foreground-800 truncate">
            {showEden ? talep.talepEdenName : 'Kapatma Talebi'}
          </p>
          <p className="text-[11px] text-foreground-400">{formatUygunsuzlukDateTime(talep.createdAt)}</p>
        </div>
        <Badge variant={talepBadgeVariant(talep.durum)}>{talepLabel(talep.durum)}</Badge>
      </div>

      {talep.aciklama && <p className="mt-2 text-sm text-foreground-700 whitespace-pre-wrap">{talep.aciklama}</p>}

      {talep.fotoUrl && (
        <div className="mt-2.5">
          <ImageViewer
            src={talep.fotoUrl}
            alt="Kapatma talebi fotoğrafı"
            gallery={[{ src: talep.fotoUrl, alt: 'Kapatma talebi fotoğrafı' }]}
            index={0}
            showHoverIcon
            wrapperClassName="w-24 h-16"
            imgClassName="w-24 h-16 rounded-md object-cover object-top border border-background-300/60"
          />
        </div>
      )}

      {talep.durum === 'reddedildi' && talep.redAciklamasi && (
        <div className="rounded-md bg-danger-50 dark:bg-danger-50/10 p-2 mt-2">
          <p className="text-[11px] font-medium text-danger-700 mb-0.5">Red Gerekçesi</p>
          <p className="text-xs text-danger-700 whitespace-pre-wrap">{talep.redAciklamasi}</p>
        </div>
      )}

      {talep.durum === 'onaylandi' && talep.sonucTarihi && (
        <p className="text-[11px] text-success-600 mt-2 flex items-center gap-1">
          <i className="ri-check-double-line" />
          Onaylandı: {formatUygunsuzlukDateTime(talep.sonucTarihi)}
        </p>
      )}
    </div>
  );
}

/** İşlem geçmişi olaylarını gerçek kayıt alanlarından türetir. */
export function buildIslemGecmisi(detail: UygunsuzlukDetailData): GecmisOlay[] {
  const olaylar: GecmisOlay[] = [];

  olaylar.push({
    tarih: detail.createdAt,
    baslik: 'Uygunsuzluk açıldı',
    aciklama: detail.aciklama || undefined,
    icon: 'ri-add-line',
    tone: 'primary',
  });

  detail.talepler.forEach((t) => {
    olaylar.push({
      tarih: t.createdAt,
      baslik: `Kapatma talebi gönderildi — ${t.talepEdenName}`,
      aciklama: t.aciklama ?? undefined,
      icon: 'ri-send-plane-line',
      tone: 'warning',
    });
    if (t.sonucTarihi && t.durum === 'onaylandi') {
      olaylar.push({ tarih: t.sonucTarihi, baslik: 'Kapatma talebi onaylandı', icon: 'ri-check-double-line', tone: 'success' });
    }
    if (t.sonucTarihi && t.durum === 'reddedildi') {
      olaylar.push({
        tarih: t.sonucTarihi,
        baslik: 'Kapatma talebi reddedildi',
        aciklama: t.redAciklamasi ?? undefined,
        icon: 'ri-close-line',
        tone: 'danger',
      });
    }
  });

  if (detail.kapatmaTarihi) {
    olaylar.push({
      tarih: detail.kapatmaTarihi,
      baslik: 'Uygunsuzluk kapatıldı',
      aciklama: detail.kapatmaAciklamasi ?? undefined,
      icon: 'ri-checkbox-circle-line',
      tone: 'success',
    });
  }

  olaylar.sort((a, b) => new Date(b.tarih).getTime() - new Date(a.tarih).getTime());
  return olaylar;
}

/** Son İşlemler — dikey zaman çizelgesi. */
export function IslemGecmisiPaneli({ detail }: { detail: UygunsuzlukDetailData }) {
  const olaylar = buildIslemGecmisi(detail);
  if (olaylar.length === 0) {
    return <p className="text-xs text-foreground-400 py-2">İşlem geçmişi bulunmuyor.</p>;
  }
  return (
    <div className="flex flex-col">
      {olaylar.map((o, idx) => (
        <div key={idx} className="flex gap-3">
          <div className="flex flex-col items-center flex-shrink-0">
            <span className={`w-7 h-7 rounded-full flex items-center justify-center ${TONE_CLASS[o.tone]}`}>
              <i className={`${o.icon} text-xs`} />
            </span>
            {idx < olaylar.length - 1 && <span className="w-px flex-1 bg-background-300/60 dark:bg-background-400/25 my-1" />}
          </div>
          <div className="pb-3.5 min-w-0">
            <p className="text-sm font-medium text-foreground-800">{o.baslik}</p>
            <p className="text-[11px] text-foreground-400">{formatUygunsuzlukDateTime(o.tarih)}</p>
            {o.aciklama && <p className="mt-1 text-xs text-foreground-600 whitespace-pre-wrap line-clamp-3">{o.aciklama}</p>}
          </div>
        </div>
      ))}
    </div>
  );
}

/** Durum ve süreç — duruma göre adım adım akış. */
export function DurumSurecPaneli({ detail }: { detail: UygunsuzlukDetailData }) {
  const kapali = detail.durum === 'kapali';
  const adimlar = [
    { key: 'acildi', label: 'Uygunsuzluk açıldı', desc: formatUygunsuzlukDateTime(detail.createdAt), done: true, active: false },
    {
      key: 'talep',
      label: kapali
        ? 'Kapatma süreci tamamlandı'
        : detail.aktifTalepVar
          ? 'Firma kapatma talebi bekleniyor'
          : 'Firma kapatma talebi oluşturabilir',
      desc: kapali
        ? 'Uygunsuzluk kapatıldı'
        : detail.aktifTalepVar
          ? 'Uzman onayı bekleniyor'
          : 'Firma panelinden talep gönderilir',
      done: detail.durum === 'onay_bekliyor' || kapali,
      active: detail.durum === 'onay_bekliyor',
    },
    {
      key: 'kapali',
      label: kapali ? 'Uygunsuzluk kapatıldı' : 'Uygunsuzluk kapatılacak',
      desc: kapali ? formatUygunsuzlukDateTime(detail.kapatmaTarihi) : 'Uzman onayı ile tamamlanır',
      done: kapali,
      active: false,
    },
  ];

  return (
    <div className="flex flex-col">
      {adimlar.map((a, idx) => (
        <div key={a.key} className="flex gap-3">
          <div className="flex flex-col items-center flex-shrink-0">
            <span
              className={`w-7 h-7 rounded-full flex items-center justify-center ${
                a.done
                  ? 'bg-success-50 text-success-600 dark:bg-success-500/15 dark:text-success-400'
                  : a.active
                    ? 'bg-warning-50 text-warning-600 dark:bg-warning-500/15 dark:text-warning-400'
                    : 'bg-background-200 text-foreground-400 dark:bg-background-300/40'
              }`}
            >
              <i className={`${a.done ? 'ri-check-line' : a.active ? 'ri-time-line' : 'ri-circle-line'} text-xs`} />
            </span>
            {idx < adimlar.length - 1 && <span className="w-px flex-1 bg-background-300/60 dark:bg-background-400/25 my-1" />}
          </div>
          <div className="pb-3.5 min-w-0">
            <p className="text-sm font-medium text-foreground-800">{a.label}</p>
            <p className="text-[11px] text-foreground-400">{a.desc}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

export { uygunsuzlukBadgeVariant };