import ImageViewer, { type ImageViewerItem } from '@/components/ui/ImageViewer';
import { FOTO_KAYNAK_LABEL, type FotoKaynak, type UygunsuzlukFoto } from '@/lib/sahaDenetimService';

/**
 * Saha Denetimleri — ortak fotoğraf bileşenleri.
 * Tek kaynak: hem uzman hem firma tarafı bu bileşenleri kullanır.
 * Kaynak etiketi (Açılış / Kapatma Talebi (Firma) / Kapatma (Uzman)) burada yönetilir.
 */

export const FOTO_KAYNAK_TONE: Record<FotoKaynak, string> = {
  OPENING: 'bg-primary-500/90 text-inverse',
  CLOSURE_REQUEST: 'bg-warning-500/90 text-inverse',
  EXPERT_CLOSURE: 'bg-success-500/90 text-inverse',
};

export const FOTO_KAYNAK_SOFT_TONE: Record<FotoKaynak, string> = {
  OPENING: 'bg-primary-100 text-primary-700 dark:bg-primary-500/20 dark:text-primary-300',
  CLOSURE_REQUEST: 'bg-warning-100 text-warning-700 dark:bg-warning-500/20 dark:text-warning-300',
  EXPERT_CLOSURE: 'bg-success-100 text-success-700 dark:bg-success-500/20 dark:text-success-300',
};

/** Fotoğraf listesini ImageViewer galerisine çevirir (yalnızca url'i olanlar). */
export function fotoGaleri(fotolar: UygunsuzlukFoto[]): ImageViewerItem[] {
  return fotolar
    .filter((f) => !!f.url)
    .map((f) => ({ src: f.url as string, alt: FOTO_KAYNAK_LABEL[f.source], fileName: f.fileName ?? undefined }));
}

/** Liste hücresi için küçük thumbnail + "+N" göstergesi. */
export function FotoThumbCell({
  foto,
  extra = 0,
  gallery,
}: {
  foto: UygunsuzlukFoto | null;
  extra?: number;
  gallery: ImageViewerItem[];
}) {
  if (!foto?.url) {
    return <span className="text-foreground-300 text-sm">—</span>;
  }
  return (
    <div className="relative inline-block">
      <ImageViewer
        src={foto.url}
        alt={FOTO_KAYNAK_LABEL[foto.source]}
        fileName={foto.fileName ?? undefined}
        gallery={gallery}
        index={0}
        showHoverIcon
        wrapperClassName="w-10 h-10"
        imgClassName="w-10 h-10 rounded-md object-cover object-top border border-background-300/60 dark:border-background-400/30"
      />
      {extra > 0 && (
        <span className="pointer-events-none absolute -right-1.5 -top-1.5 inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-foreground-900 text-background-50 text-[9px] font-bold border-2 border-background-100 dark:border-background-200">
          +{extra}
        </span>
      )}
    </div>
  );
}

/** Tek fotoğraf karesi — kaynak etiketi + opsiyonel silme. */
export function FotoKare({
  foto,
  gallery,
  index,
  onDelete,
  disabled,
  showSource = true,
}: {
  foto: UygunsuzlukFoto;
  gallery: ImageViewerItem[];
  index: number;
  onDelete?: (foto: UygunsuzlukFoto) => void;
  disabled?: boolean;
  showSource?: boolean;
}) {
  if (!foto.url) {
    return (
      <div className="flex items-center justify-center rounded-lg border border-dashed border-background-300/60 bg-background-100 dark:bg-background-200 aspect-[4/3] text-foreground-400">
        <i className="ri-image-line" />
      </div>
    );
  }
  return (
    <div className="group relative rounded-lg border border-background-300/60 dark:border-background-400/30 overflow-hidden bg-background-100 dark:bg-background-200">
      <ImageViewer
        src={foto.url}
        alt={FOTO_KAYNAK_LABEL[foto.source]}
        fileName={foto.fileName ?? undefined}
        gallery={gallery}
        index={index}
        showHoverIcon
        imgClassName="w-full aspect-[4/3] object-cover object-top"
      />
      {showSource && (
        <span className={`pointer-events-none absolute left-1.5 top-1.5 inline-flex items-center rounded-full px-2 py-0.5 text-[9px] font-semibold ${FOTO_KAYNAK_TONE[foto.source]}`}>
          {FOTO_KAYNAK_LABEL[foto.source]}
        </span>
      )}
      {onDelete && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onDelete(foto);
          }}
          disabled={disabled}
          className="absolute right-1.5 top-1.5 w-6 h-6 flex items-center justify-center rounded-full bg-black/55 text-inverse hover:bg-danger-600 transition-colors cursor-pointer disabled:opacity-50"
          aria-label="Fotoğrafı sil"
        >
          <i className="ri-delete-bin-line text-xs" />
        </button>
      )}
      {foto.fileName && (
        <p className="px-1.5 py-1 text-[10px] text-foreground-500 truncate" title={foto.fileName}>
          {foto.fileName}
          {foto.fileSize ? ` · ${Math.round(foto.fileSize / 1024)} KB` : ''}
        </p>
      )}
    </div>
  );
}

/** Fotoğraf ızgarası — kaynak etiketli + opsiyonel ekle/sil. */
export function FotoGaleri({
  fotolar,
  onDelete,
  disabled,
  showSource = true,
  onAdd,
  addLabel = 'Fotoğraf Ekle',
  emptyText = 'Bu kategoride fotoğraf yok.',
}: {
  fotolar: UygunsuzlukFoto[];
  onDelete?: (foto: UygunsuzlukFoto) => void;
  disabled?: boolean;
  showSource?: boolean;
  onAdd?: () => void;
  addLabel?: string;
  emptyText?: string;
}) {
  const items = fotoGaleri(fotolar);

  if (fotolar.length === 0 && !onAdd) {
    return <p className="text-xs text-foreground-400 py-3">{emptyText}</p>;
  }

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
      {fotolar.map((f, i) => (
        <FotoKare
          key={f.id}
          foto={f}
          gallery={items}
          index={i}
          onDelete={onDelete}
          disabled={disabled}
          showSource={showSource}
        />
      ))}
      {onAdd && (
        <button
          type="button"
          onClick={onAdd}
          disabled={disabled}
          className="flex flex-col items-center justify-center gap-1.5 rounded-lg border-2 border-dashed border-background-300/70 dark:border-background-400/40 text-foreground-500 hover:border-primary-400 hover:text-primary-600 transition-colors aspect-[4/3] cursor-pointer disabled:opacity-50"
        >
          <i className="ri-add-line text-xl" />
          <span className="text-[11px] font-medium">{addLabel}</span>
        </button>
      )}
    </div>
  );
}