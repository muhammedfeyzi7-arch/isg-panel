import { useCallback, useMemo, useRef, useState } from 'react';
import Icon from '@/components/ui/Icon';
import useSWR from 'swr';
import PageHeader from '@/components/ui/PageHeader';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import StatCard from '@/components/ui/StatCard';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import FilterBar from '@/components/ui/FilterBar';
import type { FilterField, FilterValue } from '@/components/ui/FilterBar';
import Pagination from '@/components/ui/Pagination';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import Loading from '@/components/ui/Loading';
import SharedListCard, { ListCardBadge } from '@/components/ui/SharedListCard';
import { useModalActions } from '@/hooks/useModal';
import { useRealtimeRefresh } from '@/hooks/useRealtimeRefresh';
import { useToastActions } from '@/hooks/useToast';
import { useAuth } from '@/context/AuthContext';
import { useExcelBrandMeta } from '@/hooks/useExcelBrandMeta';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import { exportSahaDenetimExcel, buildSahaDenetimFileName } from '@/lib/sahaDenetimReport/excelBranded';
import {
  type UygunsuzlukData,
  type UygunsuzlukDurum,
  fetchUygunsuzluklarPage,
  fetchUygunsuzlukFirmalari,
  fetchUygunsuzlukStats,
} from '@/lib/sahaDenetimService';
import {
  uygunsuzlukDisplayDurum,
  talepDurumDisplay,
  formatUygunsuzlukDate,
  terminDurum,
} from '@/pages/uzman/saha-denetimleri/components/sahaDenetimUi';
import { FotoThumbCell } from '@/components/feature/sahaDenetim/UygunsuzlukFoto';
import { uygunsuzlukRowGaleri } from '@/components/feature/sahaDenetim/UygunsuzlukDetailPanels';
import UygunsuzlukFormModal from '@/pages/uzman/saha-denetimleri/components/UygunsuzlukFormModal';
import SahaTutanakModal from '@/pages/uzman/saha-denetimleri/components/SahaTutanakModal';
import UygunsuzlukDetailModal from '@/pages/uzman/saha-denetimleri/components/UygunsuzlukDetailModal';
import FirmaUygunsuzlukDetailModal from '@/pages/firma/saha-denetimleri/components/FirmaUygunsuzlukDetailModal';

const DURUM_OPTIONS = [
  { value: 'acik', label: 'Açık' },
  { value: 'onay_bekliyor', label: 'Onay Bekliyor' },
  { value: 'kapali', label: 'Kapalı' },
];

function asStr(v: FilterValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

function asRange(v: FilterValue | undefined): { from: string; to: string } {
  return v && typeof v === 'object' && !Array.isArray(v) ? v : { from: '', to: '' };
}

function FirmaCell({ row }: { row: UygunsuzlukData }) {
  const lokasyon = [row.firmaIl, row.firmaIlce].filter(Boolean).join(' / ');
  return (
    <div className="min-w-0">
      <p className="text-sm font-medium text-foreground-800 truncate">{row.firmaUnvan}</p>
      {lokasyon && <p className="text-[11px] text-foreground-400 truncate">{lokasyon}</p>}
    </div>
  );
}

function TerminCell({ row }: { row: UygunsuzlukData }) {
  const durum = row.durum === 'kapali' ? null : terminDurum(row.terminTarihi);
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-sm text-foreground-600 whitespace-nowrap">{formatUygunsuzlukDate(row.terminTarihi)}</span>
      {durum && <span className="text-[11px] text-danger-500 whitespace-nowrap">{durum.label}</span>}
    </div>
  );
}

function MobileCard({ row, onDetail }: { row: UygunsuzlukData; onDetail: (r: UygunsuzlukData) => void }) {
  const lokasyon = [row.firmaIl, row.firmaIlce].filter(Boolean).join(' / ');
  const termin = row.durum === 'kapali' ? null : terminDurum(row.terminTarihi);
  const d = uygunsuzlukDisplayDurum(row);
  return (
    <SharedListCard
      recordNo={row.no}
      icon="ri-alert-line"
      iconBg="bg-danger-50 dark:bg-danger-50/15"
      iconColor="text-danger-600"
      title={row.firmaUnvan}
      description={row.aciklama}
      badges={[
        <ListCardBadge key="durum" variant={d.variant === 'danger' ? 'danger' : d.variant === 'warning' ? 'warning' : 'success'}>
          {d.label}
        </ListCardBadge>,
        ...(termin ? [<ListCardBadge key="termin" variant="danger">{termin.label}</ListCardBadge>] : []),
      ]}
      metadata={[
        { label: 'Lokasyon', value: lokasyon || row.lokasyon || '—' },
        { label: 'Termin', value: formatUygunsuzlukDate(row.terminTarihi) },
      ]}
      onClick={() => onDetail(row)}
    />
  );
}

export default function SahaDenetimListesi({ role }: { role: 'uzman' | 'firma' }) {
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const { profile } = useAuth();
  const getBrandMeta = useExcelBrandMeta();
  const isUzman = role === 'uzman';

  const formModalIdRef = useRef('');
  const detailModalIdRef = useRef('');
  const tutanakModalIdRef = useRef('');
  const [raporBusy, setRaporBusy] = useState(false);

  const [searchQuery, setSearchQuery] = useState('');
  const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  const { data: firmaOptions = [] } = useSWR(isUzman ? 'uzman-uygunsuzluk-firmalari' : null, fetchUygunsuzlukFirmalari);
  const { data: stats, mutate: mutateStats } = useSWR(`${role}-uygunsuzluk-stats`, fetchUygunsuzlukStats);

  const buildQuery = useCallback(() => {
    const range = asRange(filterValues['tarih']);
    return {
      search: searchQuery || undefined,
      durum: (asStr(filterValues['durum']) as UygunsuzlukDurum | '') || '',
      firmaId: asStr(filterValues['firma']) || '',
      tarihBaslangic: range.from || '',
      tarihBitis: range.to || '',
      page,
      pageSize,
    };
  }, [searchQuery, filterValues, page, pageSize]);

  const queryKey = useMemo(() => JSON.stringify(buildQuery()), [buildQuery]);
  const { data: pageData, error: pageError, isLoading, mutate } = useSWR(
    [`${role}-uygunsuzluklar`, queryKey],
    async () => fetchUygunsuzluklarPage(buildQuery()),
  );

  const rows = pageData?.data ?? [];
  const count = pageData?.count ?? 0;
  const loading = isLoading;
  const error = pageError ? (pageError instanceof Error ? pageError.message : 'Denetim kayıtları yüklenemedi. Lütfen tekrar deneyin.') : null;

  const load = useCallback(() => {
    void mutate();
    void mutateStats();
  }, [mutate, mutateStats]);

  // Canlı senkron: başka bir kullanıcı yeni uygunsuzluk açtığında veya kapatma
  // talebini sonuçlandırdığında liste + KPI'lar sayfa yenilemeye gerek kalmadan güncellenir.
  useRealtimeRefresh(['uygunsuzluklar', 'uygunsuzluk_talepleri'], load);

  const handleOpenTutanak = useCallback(
    (uygunsuzlukId: string) => {
      const id = openModal({
        title: 'Tutanak Oluştur',
        description: 'Bu uygunsuzluk için tutanak oluşturun. Gerekli alanları doldurun, önizleyin ve kaydedin.',
        width: 1040,
        minWidth: 420,
        minHeight: 560,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: (
          <SahaTutanakModal
            uygunsuzlukId={uygunsuzlukId}
            onClose={() => closeModal(tutanakModalIdRef.current)}
            onCreated={() => load()}
          />
        ),
      });
      tutanakModalIdRef.current = id;
    },
    [openModal, closeModal, load],
  );

  const handleAfterCreate = useCallback(
    (result?: { tutanakIstendi: boolean; uygunsuzluk: { id: string } }) => {
      load();
      if (result?.tutanakIstendi && result.uygunsuzluk?.id) {
        handleOpenTutanak(result.uygunsuzluk.id);
      }
    },
    [load, handleOpenTutanak],
  );

  const handleOpenForm = useCallback(() => {
    const id = openModal({
      title: 'Yeni Uygunsuzluk',
      description: 'Saha denetiminde tespit ettiğiniz uygunsuzluğu kaydedin.',
      width: 1040,
      minWidth: 420,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: <UygunsuzlukFormModal onClose={() => closeModal(formModalIdRef.current)} onCreated={handleAfterCreate} />,
    });
    formModalIdRef.current = id;
  }, [openModal, closeModal, handleAfterCreate]);

  const handleOpenDetail = useCallback(
    (row: UygunsuzlukData) => {
      const content = isUzman ? (
        <UygunsuzlukDetailModal uygunsuzlukId={row.id} onClose={() => closeModal(detailModalIdRef.current)} onChanged={load} />
      ) : (
        <FirmaUygunsuzlukDetailModal uygunsuzlukId={row.id} onClose={() => closeModal(detailModalIdRef.current)} onChanged={load} />
      );
      const id = openModal({
        title: 'Uygunsuzluk Detayı',
        variant: 'detail',
        width: 1120,
        minWidth: 420,
        minHeight: 560,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content,
      });
      detailModalIdRef.current = id;
    },
    [openModal, closeModal, load, isUzman],
  );

  // RAPOR AL = DOĞRUDAN İNDİRME (modal YOK). Liste ekranındaki AKTİF filtrelere
  // (arama + durum + firma + tarih) göre kayıtlar çekilir ve EKİPMAN TASARIMIYLA
  // aynı kurumsal Excel motoru ile anında indirilir.
  const handleRaporAl = useCallback(async () => {
    if (raporBusy) return;
    setRaporBusy(true);
    try {
      const q = buildQuery();
      const full = await fetchUygunsuzluklarPage({ ...q, page: 1, pageSize: 5000 });
      const data = full.data ?? [];
      if (data.length === 0) {
        addToast({ title: 'Kayıt bulunamadı', message: 'Seçili filtrelere uygun denetim kaydı bulunmuyor.', type: 'warning' });
        return;
      }
      const firmaId = asStr(filterValues['firma']) || data[0]?.firmaId || profile?.firmaId || '';
      const firmaAdi = isUzman
        ? (firmaId ? (firmaOptions.find((f) => f.value === firmaId)?.label ?? '') : '')
        : (data[0]?.firmaUnvan ?? '');
      const meta = await getBrandMeta({ firmaId, firmaAdi });
      const fileName = buildSahaDenetimFileName(firmaAdi, isUzman && !firmaId);
      await exportSahaDenetimExcel(data, meta, fileName);
      addToast({ title: 'Excel indirildi', message: `${data.length} kayıt Excel olarak indirildi.`, type: 'success' });
    } catch (e) {
      addToast({ title: 'Rapor oluşturulamadı', message: friendlyErrorMessage(e, 'İşlem tamamlanamadı. Lütfen tekrar deneyin.'), type: 'error' });
    } finally {
      setRaporBusy(false);
    }
  }, [raporBusy, buildQuery, filterValues, isUzman, firmaOptions, getBrandMeta, addToast, profile?.firmaId]);

  const filters = useMemo<FilterField[]>(() => {
    const base: FilterField[] = [];
    if (isUzman) base.push({ key: 'firma', label: 'Firma', type: 'select', options: firmaOptions });
    base.push({ key: 'durum', label: 'Durum', type: 'select', options: DURUM_OPTIONS });
    base.push({ key: 'tarih', label: 'Tarih', type: 'date-range' });
    return base;
  }, [firmaOptions, isUzman]);

  const columns: TableColumn<UygunsuzlukData>[] = useMemo(() => {
    const cols: TableColumn<UygunsuzlukData>[] = [
      {
        key: 'no',
        header: 'No',
        render: (r) => <span className="text-sm font-semibold text-foreground-800 whitespace-nowrap">{r.no}</span>,
      },
    ];
    if (isUzman) cols.push({ key: 'firma', header: 'Firma', render: (r) => <FirmaCell row={r} /> });
    cols.push(
      {
        key: 'acilisFoto',
        header: 'Açılış Fotoğrafı',
        render: (r) => (
          <FotoThumbCell
            foto={r.openingFoto[0] ?? null}
            extra={Math.max(0, r.acilisFotoCount - 1)}
            gallery={uygunsuzlukRowGaleri(r)}
          />
        ),
      },
      {
        key: 'aciklama',
        header: 'Açıklama',
        render: (r) => (
          <span className="text-sm text-foreground-600 inline-block max-w-[200px] truncate align-middle" title={r.aciklama}>
            {r.aciklama}
          </span>
        ),
      },
      {
        key: 'onlem',
        header: 'Alınması Gereken Önlem',
        render: (r) => (
          <span className="text-sm text-foreground-600 inline-block max-w-[200px] truncate align-middle" title={r.onlem}>
            {r.onlem}
          </span>
        ),
      },
      {
        key: 'talep',
        header: 'Kapatma Talebi',
        render: (r) => {
          const t = talepDurumDisplay(r.talepDurum);
          return <Badge variant={t.variant}>{t.label}</Badge>;
        },
      },
      { key: 'termin', header: 'Termin Tarihi', render: (r) => <TerminCell row={r} /> },
      {
        key: 'durum',
        header: 'Durum',
        render: (r) => {
          const d = uygunsuzlukDisplayDurum(r);
          return <Badge variant={d.variant}>{d.label}</Badge>;
        },
      },
    );
    return cols;
  }, [isUzman]);

  const totalPages = Math.max(1, Math.ceil(count / pageSize));

  return (
    <div className="isg-page">
      <PageHeader
        title="Saha Denetimleri"
        subtitle={
          isUzman
            ? 'Yetkili olduğunuz firmalarda tespit ettiğiniz uygunsuzluklar ve kapatma talepleri'
            : 'Firmanıza ait uygunsuzluklar ve kapatma talepleri'
        }
        className="flex-shrink-0"
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="secondary"
              size="sm"
              leftIcon={raporBusy ? undefined : <Icon name="excel" size="md" />}
              onClick={() => void handleRaporAl()}
              isLoading={raporBusy}
              className="whitespace-nowrap"
            >
              Rapor Al
            </Button>
            {isUzman && (
              <Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={handleOpenForm} className="whitespace-nowrap">
                Yeni Uygunsuzluk
              </Button>
            )}
          </div>
        }
      />

      <div className="isg-stat-grid">
        <StatCard
          title="Toplam Uygunsuzluk"
          value={stats ? stats.toplam : '—'}
          subtitle="kayıtlı uygunsuzluk"
          icon="ri-file-list-3-line"
          iconBg="bg-primary-50 dark:bg-primary-500/15"
          iconColor="text-primary-600 dark:text-primary-400"
        />
        <StatCard
          title="Açık Uygunsuzluk"
          value={stats ? stats.acik : '—'}
          subtitle="devam eden açık kayıtlar"
          icon="ri-error-warning-line"
          iconBg="bg-danger-50 dark:bg-danger-500/15"
          iconColor="text-danger-600 dark:text-danger-400"
        />
        <StatCard
          title="Kapatma Talebi Bekleyen"
          value={stats ? stats.talepBekleyen : '—'}
          subtitle="onay bekleyen kapatma talepleri"
          icon="ri-hourglass-line"
          iconBg="bg-warning-50 dark:bg-warning-500/15"
          iconColor="text-warning-600 dark:text-warning-400"
        />
        <StatCard
          title="Kapatılan Uygunsuzluk"
          value={stats ? stats.kapali : '—'}
          subtitle="tamamlanan uygunsuzluklar"
          icon="ri-checkbox-circle-line"
          iconBg="bg-success-50 dark:bg-success-500/15"
          iconColor="text-success-600 dark:text-success-400"
        />
      </div>

      <div className="isg-card flex flex-col p-3">
        <div className="flex items-center justify-between gap-2 mb-2">
          <div className="flex items-center gap-2 min-w-0">
            <i className="ri-alert-line text-danger-600" />
            <div className="min-w-0">
              <h4 className="text-sm font-semibold text-foreground-900">Uygunsuzluklar</h4>
              <p className="text-[11px] text-foreground-500 truncate">Denetimlerde tespit edilen uygunsuzluklar ve alınması gereken önlemler</p>
            </div>
          </div>
          {rows.length > 0 && (
            <Button
              variant="secondary"
              size="sm"
              leftIcon={raporBusy ? undefined : <i className="ri-download-2-line" />}
              onClick={() => void handleRaporAl()}
              isLoading={raporBusy}
              className="whitespace-nowrap"
            >
              Dışa Aktar
            </Button>
          )}
        </div>
        <FilterBar
          filters={filters}
          values={filterValues}
          onChange={(key, value) => {
            setFilterValues((prev) => ({ ...prev, [key]: value }));
            setPage(1);
          }}
          onReset={() => {
            setFilterValues({});
            setSearchQuery('');
            setPage(1);
          }}
          onSearch={(v) => { setSearchQuery(v); setPage(1); }}
          searchPlaceholder="Ara... no, açıklama, önlem"
          searchDebounceMs={400}
        />

        <div className="mt-3 flex-1 min-h-0">
          {loading ? (
            <div className="flex justify-center py-16">
              <Loading size="lg" text="Uygunsuzluklar yükleniyor..." />
            </div>
          ) : error ? (
            <ErrorState message={error} onRetry={load} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon="ri-search-eye-line"
              title="Henüz uygunsuzluk bulunmuyor"
              description={isUzman ? 'Saha denetimi sırasında tespit ettiğiniz uygunsuzlukları kaydederek başlayın.' : 'Firmanıza ait uygunsuzluk bulunmuyor.'}
              action={isUzman ? { label: 'Yeni Uygunsuzluk', onClick: handleOpenForm, icon: 'ri-add-line' } : undefined}
            />
          ) : (
            <>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-foreground-500">
                  Toplam <span className="font-semibold text-foreground-800">{count}</span> uygunsuzluk
                </p>
              </div>
              <div className="overflow-x-auto">
                <Table
                  data={rows}
                  columns={columns}
                  keyExtractor={(r) => r.id}
                  onRowClick={handleOpenDetail}
                  rowActions={(row) => (
                    <Button
                      variant="secondary"
                      size="sm"
                      leftIcon={<i className="ri-eye-line" />}
                      onClick={() => handleOpenDetail(row)}
                      className="whitespace-nowrap"
                    >
                      Görüntüle
                    </Button>
                  )}
                  mobileCardRenderer={(row) => <MobileCard row={row} onDetail={handleOpenDetail} />}
                />
              </div>
              <div className="mt-3 pt-3 border-t border-background-300/25 dark:border-background-400/25">
                <Pagination
                  currentPage={page}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={count}
                  onPageChange={setPage}
                  onPageSizeChange={(size) => {
                    setPageSize(size);
                    setPage(1);
                  }}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}