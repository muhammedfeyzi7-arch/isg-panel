import { useRef, useState } from 'react';
import { isSameFile, validateUploadFile } from '@/lib/fileUpload';

// Operasyonel kayıtlarda (yakıt fişi, kaza fotoğraf/tutanak, arıza dosyası) kullanılan
// ortak dosya seçici. Dosyalar gerçek base64 olarak create/upload payload'ına gönderilir;
// burada yalnızca seçim + önizleme + doğrulama yapılır (fake progress yok).

export interface SeciliDosya {
  id: string;
  file: File;
  preview: string | null;
}

interface DosyaSeciciProps {
  files: SeciliDosya[];
  onChange: (files: SeciliDosya[]) => void;
  label?: string;
  helpText?: string;
  multiple?: boolean;
  disabled?: boolean;
}

const IMG_MIME = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_SIZE = 15 * 1024 * 1024;
// Uzantı + MIME karması: doğrulama tek merkezden (src/lib/fileUpload.ts).
const ACCEPT_ATTR = 'image/jpeg,image/png,image/webp,application/pdf,.doc,.docx,.xls,.xlsx';

let counter = 0;

function extOf(name: string): string {
  const i = name.lastIndexOf('.');
  return i >= 0 ? name.slice(i + 1).toUpperCase() : 'DOSYA';
}

export default function DosyaSecici({ files, onChange, label = 'Dosyalar', helpText = 'JPG, PNG, WebP, PDF, DOC, XLS — en fazla 15 MB', multiple = true, disabled = false }: DosyaSeciciProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [error, setError] = useState('');

  const addFiles = (list: FileList | null) => {
    if (!list) return;
    setError('');
    const arr = Array.from(list);
    const next: SeciliDosya[] = [];
    for (const f of arr) {
      const err = validateUploadFile(f, { accept: ACCEPT_ATTR, maxSize: MAX_SIZE });
      if (err) {
        setError(err);
        continue;
      }
      if ([...files, ...next].some((x) => isSameFile(x.file, f))) continue;
      next.push({ id: `d-${++counter}`, file: f, preview: IMG_MIME.includes(f.type) ? URL.createObjectURL(f) : null });
    }
    onChange([...files, ...next]);
  };

  const remove = (id: string) => {
    onChange(files.filter((f) => {
      if (f.id === id && f.preview) URL.revokeObjectURL(f.preview);
      return f.id !== id;
    }));
  };

  return (
    <div>
      {label && <p className="isg-form-label">{label}</p>}
      <label className="flex flex-col items-center justify-center gap-2 rounded-lg border-2 border-dashed border-background-300 bg-background-100 hover:bg-background-200 p-5 cursor-pointer transition-colors">
        <i className="ri-file-add-line text-2xl text-foreground-400" />
        <p className="text-sm text-foreground-600 text-center">Dosya eklemek için tıklayın veya sürükleyin</p>
        <p className="text-xs text-foreground-400">{helpText}</p>
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT_ATTR}
          multiple={multiple}
          className="hidden"
          disabled={disabled}
          onChange={(e) => addFiles(e.target.files)}
        />
      </label>

      {error && (
        <p className="mt-1.5 text-xs text-danger-600 flex items-center gap-1">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      {files.length > 0 && (
        <div className="mt-3 grid grid-cols-2 sm:grid-cols-3 gap-2">
          {files.map((f) => (
            <div key={f.id} className="relative group rounded-lg overflow-hidden border border-background-300/40 bg-background-100">
              {f.preview ? (
                <img src={f.preview} alt={f.file.name} className="w-full h-24 object-cover object-top" />
              ) : (
                <div className="w-full h-24 flex flex-col items-center justify-center text-foreground-400 gap-1">
                  <i className="ri-file-3-line text-xl" />
                  <span className="text-[10px] font-semibold uppercase">{extOf(f.file.name)}</span>
                </div>
              )}
              <p className="px-1.5 py-1 text-[10px] text-foreground-500 truncate">{f.file.name}</p>
              <button
                type="button"
                onClick={() => remove(f.id)}
                className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/60 text-inverse flex items-center justify-center hover:bg-danger-600 transition-colors cursor-pointer"
                aria-label="Dosyayı kaldır"
              >
                <i className="ri-close-line text-sm" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}