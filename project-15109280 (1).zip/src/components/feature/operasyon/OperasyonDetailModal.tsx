import { useState, useEffect } from 'react';
import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import Card from '@/components/ui/Card';
import Select from '@/components/ui/Select';
import Textarea from '@/components/ui/Textarea';
import ImageViewer from '@/components/ui/ImageViewer';
import { useToastActions } from '@/hooks/useToast';
import { useAuth } from '@/context/AuthContext';
import {
  fetchOperasyonDetail,
  updateArizaDurum,
  addOperasyonYorum,
  addOperasyonDosya,
  friendlyOperasyonError,
  yakitTuruLabel,
  arizaDurumLabel,
  ARIZA_DURUM_OPTIONS,
  type OperasyonDetail,
  type ArizaDurum,
  type ArizaRow,
} from '@/lib/operasyonService';
import {
  aracOperasyonIcon,
  aracOperasyonVariant,
  arizaDurumVariant,
  arizaDurumIcon,
  formatOperasyonDate,
  formatOperasyonDateTime,
  formatPara,
  formatLitre,
} from './operasyonUi';
import DosyaSecici, { type SeciliDosya } from './DosyaSecici';
import { ListSkeleton } from '@/components/ui/Skeleton';

interface OperasyonDetailModalProps {
  entityType: 'arac_operasyon' | 'ariza';
  entityId: string;
  onClose: () => void;
  onChanged: () => void;
}

const TUR_LABEL: Record<string, string> = {
  yakit: 'Yakıt Fişi',
  yikama: 'Yıkama Fişi',
  tamir: 'Tamir Fişi',
  servis: 'Servis Fişi',
  diger_gider: 'Gider Fişi',
  kaza: 'Kaza Kaydı',
  bakim_notu: 'Bakım Notu',
};

const PERSONEL_TURU_LABEL: Record<string, string> = {
  isg_uzmani: 'İş Güvenliği Uzmanı',
  isyeri_hekimi: 'İşyeri Hekimi',
  dsp: 'DSP',
};

function Row({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 py-1.5">
      <span className="text-xs text-foreground-500 flex-shrink-0 pt-0.5">{label}</span>
      <span className="text-sm font-medium text-foreground-800 text-right min-w-0 break-words">{value}</span>
    </div>
  );
}

export default function OperasyonDetailModal({ entityType, entityId, onClose, onChanged }: OperasyonDetailModalProps) {
  const { addToast } = useToastActions();
  const { profile } = useAuth();

  const [detail, setDetail] = useState<OperasyonDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [comment, setComment] = useState('');
  const [commentLoading, setCommentLoading] = useState(false);
  const [statusLoading, setStatusLoading] = useState(false);
  const [files, setFiles] = useState<SeciliDosya[]>([]);
  const [uploadLoading, setUploadLoading] = useState(false);

  const role = profile?.role;
  const isOsgb = role === 'admin' || role === 'osgb_admin';

  const load = () => {
    setLoading(true);
    setError(null);
    fetchOperasyonDetail(entityType, entityId)
      .then(setDetail)
      .catch((e) => setError(friendlyOperasyonError(e)))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entityType, entityId]);

  const handleComment = async () => {
    if (!comment.trim() || commentLoading) return;
    setCommentLoading(true);
    try {
      await addOperasyonYorum(entityType, entityId, comment.trim());
      setComment('');
      addToast({ title: 'Yorum eklendi', message: 'Yanıt kaydedildi.', type: 'success' });
      load();
    } catch (e) {
      addToast({ title: 'İşlem başarısız', message: friendlyOperasyonError(e), type: 'error' });
    } finally {
      setCommentLoading(false);
    }
  };

  const handleStatus = async (durum: ArizaDurum) => {
    if (statusLoading) return;
    setStatusLoading(true);
    try {
      await updateArizaDurum(entityId, durum);
      addToast({ title: 'Durum güncellendi', message: `Arıza durumu: ${arizaDurumLabel(durum)}`, type: 'success' });
      load();
      onChanged();
    } catch (e) {
      addToast({ title: 'İşlem başarısız', message: friendlyOperasyonError(e), type: 'error' });
    } finally {
      setStatusLoading(false);
    }
  };

  const handleUpload = async () => {
    if (files.length === 0 || uploadLoading) return;
    setUploadLoading(true);
    try {
      await addOperasyonDosya(entityType, entityId, files.map((f) => f.file));
      setFiles([]);
      addToast({ title: 'Dosya eklendi', message: `${files.length} dosya kaydedildi.`, type: 'success' });
      load();
    } catch (e) {
      addToast({ title: 'Yükleme başarısız', message: friendlyOperasyonError(e), type: 'error' });
    } finally {
      setUploadLoading(false);
    }
  };

  if (loading) {
    return <ListSkeleton rows={5} />;
  }
  if (error || !detail) {
    return (
      <div className="py-12 text-center">
        <p className="text-sm text-danger-600">{error || 'Kayıt bulunamadı'}</p>
        <button onClick={load} className="mt-3 text-sm text-primary-600 hover:text-primary-700 cursor-pointer">Tekrar dene</button>
      </div>
    );
  }

  const { entity, envanter, personel, yorumlar, dosyalar } = detail;
  const isAriza = entityType === 'ariza';
  const tur = isAriza ? '' : (entity as { tur: string }).tur;
  const durum = isAriza ? (entity as ArizaRow).durum : null;
  const turLabel = isAriza ? 'Arıza Kaydı' : (TUR_LABEL[tur] ?? tur);
  const gorseller = dosyalar.filter((d) => d.mime_type?.startsWith('image/') && d.signedUrl);
  const belgeler = dosyalar.filter((d) => !d.mime_type?.startsWith('image/'));
  const personelAdSoyad = personel ? [personel.ad, personel.soyad].filter(Boolean).join(' ') : '';
  const personelRol = personel ? (PERSONEL_TURU_LABEL[personel.personel_turu ?? ''] ?? '') : '';
  const tarihValue = isAriza ? (entity as ArizaRow).created_at : ((entity as { tarih: string | null }).tarih || (entity as { created_at: string }).created_at);
  const tutar = isAriza ? null : (entity as { tutar: number | string | null }).tutar;
  const litre = isAriza ? null : (entity as { litre: number | string | null }).litre;
  const yakitTuru = isAriza ? null : (entity as { yakit_turu: string | null }).yakit_turu;

  return (
    <div className="space-y-3">
      {/* Başlık */}
      <div className="flex items-start gap-3 p-3 isg-section">
        <div className="w-12 h-12 rounded-xl bg-primary-50 dark:bg-primary-500/10 flex items-center justify-center flex-shrink-0">
          <i className={`${isAriza ? 'ri-computer-line' : aracOperasyonIcon(tur)} text-primary-600 dark:text-primary-400 text-lg`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="text-base font-semibold text-foreground-950">{turLabel}</h3>
            {isAriza && durum && (
              <Badge variant={arizaDurumVariant(durum)} leftIcon={<i className={arizaDurumIcon(durum)} />}>
                {arizaDurumLabel(durum)}
              </Badge>
            )}
          </div>
          <p className="text-xs text-foreground-500 mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5">
            <span className="inline-flex items-center gap-1"><i className="ri-calendar-line" />{formatOperasyonDate(tarihValue)}</span>
            {personelAdSoyad && (
              <span className="inline-flex items-center gap-1"><i className="ri-user-line" />{personelAdSoyad}{personelRol ? ` · ${personelRol}` : ''}</span>
            )}
            {envanter && (
              <span className="inline-flex items-center gap-1">
                <i className={isAriza ? 'ri-computer-line' : 'ri-car-line'} />
                {envanter.ad} ({envanter.envanter_kodu})
              </span>
            )}
          </p>
        </div>
      </div>

      {/* Belge/veri ızgarası */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {/* Sol — belge / fotoğraf görüntüleyici */}
        <Card title={isAriza ? 'Arıza Fotoğrafı' : 'Fiş / Belge'} padding="md" headerAction={<i className="ri-image-2-line text-primary-500" />}>
          {gorseller.length > 0 ? (
            <div className="space-y-3">
              <div className="w-full h-64 rounded-lg overflow-hidden border border-background-300/40 bg-background-100 dark:bg-background-300/30 flex items-center justify-center">
                <ImageViewer
                  gallery={gorseller.map((d) => ({ src: d.signedUrl as string, alt: d.original_file_name || '', fileName: d.original_file_name || '' }))}
                  index={0}
                  imgClassName="w-full h-64 object-contain"
                  wrapperClassName="w-full h-64"
                />
              </div>
              {gorseller.length > 1 && (
                <div className="flex flex-wrap gap-2">
                  {gorseller.map((d, i) => (
                    <div key={d.id} className="w-16 h-16 rounded-lg overflow-hidden border border-background-300/40 bg-background-100 flex-shrink-0">
                      <ImageViewer
                        gallery={gorseller.map((g) => ({ src: g.signedUrl as string, alt: g.original_file_name || '', fileName: g.original_file_name || '' }))}
                        index={i}
                        imgClassName="w-full h-16 object-cover object-top"
                        wrapperClassName="w-16 h-16"
                      />
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div className="w-full h-40 rounded-lg border-2 border-dashed border-background-300/50 dark:border-background-400/30 flex flex-col items-center justify-center gap-1 text-foreground-400">
              <i className="ri-image-line text-2xl" />
              <span className="text-xs">Görsel eklenmemiş</span>
            </div>
          )}

          {belgeler.length > 0 && (
            <div className="mt-3 pt-3 border-t isg-divider space-y-1.5">
              {belgeler.map((d) => (
                <a
                  key={d.id}
                  href={d.signedUrl ?? '#'}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="flex items-center gap-2 text-xs text-primary-700 dark:text-primary-400 hover:underline"
                >
                  <i className="ri-file-3-line text-foreground-400" />
                  <span className="truncate">{d.original_file_name || 'belge'}</span>
                </a>
              ))}
            </div>
          )}

          <div className="mt-3 pt-3 border-t isg-divider">
            <DosyaSecici files={files} onChange={setFiles} label="Dosya Ekle" />
            {files.length > 0 && (
              <Button variant="outline" size="sm" isLoading={uploadLoading} onClick={handleUpload} className="mt-2" leftIcon={<i className="ri-upload-line" />}>
                Dosyaları Yükle
              </Button>
            )}
          </div>
        </Card>

        {/* Sağ — kayıt bilgileri */}
        <Card title={isAriza ? 'Arıza Bilgileri' : 'Fiş Bilgileri'} padding="md" headerAction={<i className="ri-information-line text-primary-500" />}>
          <div className="divide-y divide-background-300/20 dark:divide-background-400/20">
            <Row label="Kayıt Türü" value={<Badge variant={isAriza ? 'secondary' : aracOperasyonVariant(tur)}>{turLabel}</Badge>} />
            {envanter && <Row label="Envanter" value={`${envanter.ad} (${envanter.envanter_kodu})`} />}
            <Row label="Personel" value={personelAdSoyad ? `${personelAdSoyad}${personelRol ? ` · ${personelRol}` : ''}` : '—'} />
            <Row label="Tarih" value={formatOperasyonDate(tarihValue)} />
            {yakitTuru && <Row label="Yakıt Türü" value={yakitTuruLabel(yakitTuru)} />}
            {litre != null && litre !== '' && <Row label="Litre" value={formatLitre(litre)} />}
            {tutar != null && tutar !== '' && <Row label="Tutar" value={formatPara(tutar)} />}
            {isAriza && durum && <Row label="Durum" value={arizaDurumLabel(durum)} />}
            <Row label="Oluşturulma" value={formatOperasyonDateTime((entity as { created_at: string }).created_at)} />
          </div>

          {(entity as { aciklama: string | null }).aciklama && (
            <div className="mt-3 pt-3 border-t isg-divider">
              <span className="text-xs text-foreground-500 block mb-1">{isAriza ? 'Arıza Açıklaması' : 'Açıklama'}</span>
              <p className="text-sm text-foreground-800 whitespace-pre-wrap">{(entity as { aciklama: string | null }).aciklama}</p>
            </div>
          )}

          {isAriza && isOsgb && (
            <div className="mt-3 pt-3 border-t isg-divider">
              <Select
                label="Arıza Durumu"
                options={ARIZA_DURUM_OPTIONS}
                value={durum || ''}
                onChange={(e) => handleStatus(e.target.value as ArizaDurum)}
                disabled={statusLoading}
              />
            </div>
          )}
        </Card>
      </div>

      {/* Yorumlar */}
      <Card title="Yorumlar" padding="md" headerAction={<i className="ri-chat-3-line text-primary-500" />}>
        {yorumlar.length === 0 ? (
          <p className="text-xs text-foreground-500 mb-3">Henüz yorum yok.</p>
        ) : (
          <div className="space-y-2 mb-3">
            {yorumlar.map((y) => (
              <div key={y.id} className="p-2.5 rounded-lg bg-background-100 dark:bg-background-200/50 border border-background-300/20">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-medium text-foreground-700">
                    {y.yazan_role === 'osgb_admin' || y.yazan_role === 'admin' ? 'OSGB Yönetimi' : y.yazan_role === 'uzman' ? 'Uzman' : y.yazan_role === 'hekim' ? 'Hekim' : '—'}
                  </span>
                  <span className="text-[10px] text-foreground-400">{formatOperasyonDateTime(y.created_at)}</span>
                </div>
                <p className="mt-1 text-sm text-foreground-800 whitespace-pre-wrap">{y.icerik}</p>
              </div>
            ))}
          </div>
        )}

        <Textarea
          placeholder="Yorumunuzu yazın..."
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          maxLength={500}
        />
        <div className="flex justify-end mt-2">
          <Button variant="primary" size="sm" isLoading={commentLoading} disabled={!comment.trim()} onClick={handleComment} leftIcon={<i className="ri-send-plane-line" />}>
            Gönder
          </Button>
        </div>
      </Card>
    </div>
  );
}