// ---------- Operasyon UI yardımcıları (shared) ----------
// OSGB / Uzman / Hekim ekranlarında ortak kullanılan görsel sabitler.
// Business logic YOKTUR — yalnızca durum/ikon/tarih/para sunumu.

export type OperasyonBadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'secondary' | 'accent';

export function aracOperasyonIcon(tur: string): string {
  switch (tur) {
    case 'yakit': return 'ri-gas-station-line';
    case 'yikama': return 'ri-drop-line';
    case 'bakim_notu': return 'ri-tools-line';
    case 'tamir': return 'ri-settings-3-line';
    case 'servis': return 'ri-service-line';
    case 'diger_gider': return 'ri-receipt-line';
    case 'kaza': return 'ri-alert-line';
    default: return 'ri-file-list-3-line';
  }
}

export function aracOperasyonVariant(tur: string): OperasyonBadgeVariant {
  switch (tur) {
    case 'yakit': return 'info';
    case 'yikama': return 'accent';
    case 'bakim_notu': return 'secondary';
    case 'tamir': return 'warning';
    case 'servis': return 'info';
    case 'diger_gider': return 'secondary';
    case 'kaza': return 'danger';
    default: return 'default';
  }
}

export function arizaDurumVariant(durum: string): OperasyonBadgeVariant {
  switch (durum) {
    case 'acik': return 'warning';
    case 'islemde': return 'info';
    case 'cozuldu': return 'success';
    case 'kapatildi': return 'secondary';
    default: return 'default';
  }
}

export function arizaDurumIcon(durum: string): string {
  switch (durum) {
    case 'acik': return 'ri-error-warning-line';
    case 'islemde': return 'ri-loader-4-line';
    case 'cozuldu': return 'ri-checkbox-circle-line';
    case 'kapatildi': return 'ri-archive-line';
    default: return 'ri-file-list-3-line';
  }
}

const TR_MONTHS = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

export function formatOperasyonDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return '—';
  return `${d} ${TR_MONTHS[m - 1]} ${y}`;
}

export function formatOperasyonDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return '—';
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${dt.getDate()} ${TR_MONTHS[dt.getMonth()]} ${dt.getFullYear()} ${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
}

export function formatPara(v: number | string | null | undefined): string {
  if (v == null || v === '') return '—';
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 2 }).format(n);
}

export function formatLitre(v: number | string | null | undefined): string {
  if (v == null || v === '') return '—';
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  return `${new Intl.NumberFormat('tr-TR', { maximumFractionDigits: 2 }).format(n)} L`;
}