import { useEffect, useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Toggle from '@/components/ui/Toggle';
import Checkbox from '@/components/ui/Checkbox';
import { useToastActions } from '@/hooks/useToast';
import { createSignature, deleteSignature, updateSignature } from '@/lib/mail/signatureService';
import { signatureToView, type SignatureView } from '@/lib/mail/signatureFormat';
import type { MailSignature, MailSignatureInput } from '@/lib/mail/types';
import type { EmailSenderContext } from './emailComposeTypes';

interface EmailSignaturePanelProps {
  signatures: MailSignature[];
  loading: boolean;
  refresh: () => Promise<void>;
  enabled: boolean;
  onEnabledChange: (v: boolean) => void;
  selectedId: string | null;
  onSelectedIdChange: (id: string | null) => void;
  /** Kayıtlı imza yoksa gösterilecek (profil + OSGB'den türetilen) varsayılan görünüm. */
  fallbackView: SignatureView;
  sender: EmailSenderContext;
}

const EMPTY_DRAFT = (sender: EmailSenderContext): MailSignatureInput => ({
  adSoyad: sender.adSoyad,
  unvan: sender.rolLabel,
  telefon: sender.telefon ?? '',
  email: sender.email ?? '',
  sirketAdi: sender.sirketAdi ?? '',
  website: sender.website ?? '',
  logoUrl: sender.logoUrl ?? '',
  sosyalLinkedin: '',
  sosyalX: '',
  sosyalInstagram: '',
  isDefault: true,
});

function SignaturePreview({ view }: { view: SignatureView }) {
  const socials: { icon: string; url: string; title: string }[] = [];
  if (view.sosyalLinkedin) socials.push({ icon: 'ri-linkedin-fill', url: view.sosyalLinkedin, title: 'LinkedIn' });
  if (view.sosyalX) socials.push({ icon: 'ri-twitter-x-fill', url: view.sosyalX, title: 'X' });
  if (view.sosyalInstagram) socials.push({ icon: 'ri-instagram-line', url: view.sosyalInstagram, title: 'Instagram' });

  return (
    <div className="flex items-start gap-3 p-3 rounded-lg border border-background-200/70 dark:border-background-400/30 bg-background-50 dark:bg-background-100/40">
      <div className="w-14 h-14 rounded-md bg-white dark:bg-background-50 border border-background-300/50 dark:border-background-400/30 flex items-center justify-center overflow-hidden flex-shrink-0">
        {view.logoUrl ? (
          <img src={view.logoUrl} alt={view.sirketAdi ?? 'Logo'} className="max-w-full max-h-full object-contain" />
        ) : (
          <i className="ri-shield-user-line text-2xl text-primary-500" />
        )}
      </div>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-foreground-900 break-words">{view.adSoyad || '—'}</p>
        <p className="text-xs text-foreground-500 break-words">{[view.unvan, view.sirketAdi].filter(Boolean).join(' · ') || '—'}</p>
        <div className="mt-1.5 flex flex-col gap-0.5 text-xs text-foreground-600">
          {view.telefon && (
            <span className="flex items-center gap-1.5"><i className="ri-phone-line text-foreground-400" />{view.telefon}</span>
          )}
          {view.email && (
            <span className="flex items-center gap-1.5 break-all"><i className="ri-mail-line text-foreground-400" />{view.email}</span>
          )}
          {view.website && (
            <span className="flex items-center gap-1.5 break-all"><i className="ri-global-line text-foreground-400" />{view.website}</span>
          )}
        </div>
        {socials.length > 0 && (
          <div className="mt-2 flex items-center gap-2">
            {socials.map((s) => (
              <a key={s.title} href={s.url.startsWith('http') ? s.url : `https://${s.url}`} target="_blank" rel="noopener noreferrer" className="w-6 h-6 flex items-center justify-center rounded bg-background-200/70 dark:bg-background-300/40 text-foreground-600 hover:text-primary-600" title={s.title}>
                <i className={`${s.icon} text-xs`} />
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/**
 * E-posta sağ panel — İMZA sekmesi.
 * Kayıtlı imzalar `email_signatures` (kullanıcı bazlı, RLS) üzerinden kalıcıdır.
 * Kayıt yoksa profil + OSGB kurumsal bilgilerinden türetilmiş varsayılan gösterilir.
 */
export default function EmailSignaturePanel({
  signatures,
  loading,
  refresh,
  enabled,
  onEnabledChange,
  selectedId,
  onSelectedIdChange,
  fallbackView,
  sender,
}: EmailSignaturePanelProps) {
  const { addToast } = useToastActions();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<MailSignatureInput>(EMPTY_DRAFT(sender));
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (selectedId === null && signatures.length > 0) {
      const def = signatures.find((s) => s.isDefault) ?? signatures[0];
      onSelectedIdChange(def.id);
    }
  }, [selectedId, signatures, onSelectedIdChange]);

  const selected = signatures.find((s) => s.id === selectedId) ?? null;
  const view = selected ? signatureToView(selected) : fallbackView;

  const startCreate = () => {
    setDraft(EMPTY_DRAFT(sender));
    setEditing(true);
  };

  const startEdit = () => {
    if (selected) {
      setDraft({
        adSoyad: selected.adSoyad,
        unvan: selected.unvan ?? '',
        telefon: selected.telefon ?? '',
        email: selected.email ?? '',
        sirketAdi: selected.sirketAdi ?? '',
        website: selected.website ?? '',
        logoUrl: selected.logoUrl ?? '',
        sosyalLinkedin: selected.sosyalLinkedin ?? '',
        sosyalX: selected.sosyalX ?? '',
        sosyalInstagram: selected.sosyalInstagram ?? '',
        isDefault: selected.isDefault,
      });
    } else {
      setDraft(EMPTY_DRAFT(sender));
    }
    setEditing(true);
  };

  const handleSave = async () => {
    if (!draft.adSoyad.trim()) {
      addToast({ title: 'Ad soyad zorunlu', message: 'İmza için ad soyad girin.', type: 'warning' });
      return;
    }
    if (saving) return;
    setSaving(true);
    try {
      const saved = selected
        ? await updateSignature(selected.id, draft)
        : await createSignature(draft);
      await refresh();
      onSelectedIdChange(saved.id);
      setEditing(false);
      addToast({ title: 'İmza kaydedildi', message: 'İmza bilgileriniz güncellendi.', type: 'success' });
    } catch (e) {
      addToast({ title: 'İmza kaydedilemedi', message: e instanceof Error ? e.message : 'İşlem başarısız.', type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!selected || saving) return;
    setSaving(true);
    try {
      await deleteSignature(selected.id);
      await refresh();
      onSelectedIdChange(null);
      setEditing(false);
      addToast({ title: 'İmza silindi', message: 'İmza kaydı kaldırıldı.', type: 'success' });
    } catch (e) {
      addToast({ title: 'İmza silinemedi', message: e instanceof Error ? e.message : 'İşlem başarısız.', type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  if (editing) {
    return (
      <div className="flex flex-col gap-3">
        <div className="grid grid-cols-1 gap-2.5">
          <Input label="Ad Soyad" required value={draft.adSoyad} onChange={(e) => setDraft({ ...draft, adSoyad: e.target.value })} placeholder="Ad Soyad" />
          <Input label="Unvan" value={draft.unvan ?? ''} onChange={(e) => setDraft({ ...draft, unvan: e.target.value })} placeholder="İş Güvenliği Uzmanı" />
          <Input label="Şirket Adı" value={draft.sirketAdi ?? ''} onChange={(e) => setDraft({ ...draft, sirketAdi: e.target.value })} placeholder="OSGB / Şirket unvanı" leftIcon={<i className="ri-building-4-line" />} />
          <div className="grid grid-cols-2 gap-2.5">
            <Input label="Telefon" value={draft.telefon ?? ''} onChange={(e) => setDraft({ ...draft, telefon: e.target.value })} placeholder="+90 5xx xxx xx xx" leftIcon={<i className="ri-phone-line" />} />
            <Input label="E-posta" value={draft.email ?? ''} onChange={(e) => setDraft({ ...draft, email: e.target.value })} placeholder="ornek@mail.com" leftIcon={<i className="ri-mail-line" />} />
          </div>
          <Input label="Web Sitesi" value={draft.website ?? ''} onChange={(e) => setDraft({ ...draft, website: e.target.value })} placeholder="www.ornek.com" leftIcon={<i className="ri-global-line" />} />
          <Input label="Logo URL" value={draft.logoUrl ?? ''} onChange={(e) => setDraft({ ...draft, logoUrl: e.target.value })} placeholder="https://.../logo.png" leftIcon={<i className="ri-image-line" />} />
          <div className="grid grid-cols-1 gap-2.5">
            <Input label="LinkedIn" value={draft.sosyalLinkedin ?? ''} onChange={(e) => setDraft({ ...draft, sosyalLinkedin: e.target.value })} placeholder="linkedin.com/in/..." leftIcon={<i className="ri-linkedin-fill" />} />
            <Input label="X (Twitter)" value={draft.sosyalX ?? ''} onChange={(e) => setDraft({ ...draft, sosyalX: e.target.value })} placeholder="x.com/..." leftIcon={<i className="ri-twitter-x-fill" />} />
            <Input label="Instagram" value={draft.sosyalInstagram ?? ''} onChange={(e) => setDraft({ ...draft, sosyalInstagram: e.target.value })} placeholder="instagram.com/..." leftIcon={<i className="ri-instagram-line" />} />
          </div>
          <Checkbox
            label="Varsayılan imza olarak kullan"
            checked={!!draft.isDefault}
            onChange={(e) => setDraft({ ...draft, isDefault: e.target.checked })}
          />
        </div>
        <div className="flex items-center justify-between gap-2">
          {selected ? (
            <Button variant="ghost" size="sm" leftIcon={<i className="ri-delete-bin-line" />} onClick={handleDelete} disabled={saving}>
              Sil
            </Button>
          ) : <span />}
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={() => setEditing(false)} disabled={saving}>Vazgeç</Button>
            <Button variant="primary" size="sm" isLoading={saving} onClick={handleSave} leftIcon={<i className="ri-save-line" />}>Kaydet</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      <Toggle label="İmza Ekle" checked={enabled} onChange={(e) => onEnabledChange(e.target.checked)} />

      {enabled && (
        <>
          <div className="flex items-end gap-2">
            <div className="flex-1 min-w-0">
              <Select
                label="Kullanılacak İmza"
                size="sm"
                value={selectedId ?? '__none__'}
                onChange={(e) => {
                  if (e.target.value === '__new__') startCreate();
                  else if (e.target.value === '__none__') startEdit();
                  else onSelectedIdChange(e.target.value);
                }}
                options={[
                  ...(signatures.length === 0 ? [{ value: '__none__', label: 'Varsayılan İmza (kaydedilmedi)' }] : []),
                  ...signatures.map((s) => ({ value: s.id, label: `${s.adSoyad}${s.isDefault ? ' (Varsayılan)' : ''}` })),
                  { value: '__new__', label: '+ Yeni İmza Oluştur' },
                ]}
                loading={loading}
              />
            </div>
            <Button variant="secondary" size="sm" className="mb-[22px] whitespace-nowrap" leftIcon={<i className="ri-edit-line" />} onClick={startEdit}>
              İmza Düzenle
            </Button>
          </div>

          <div className="flex flex-col gap-2">
            <p className="text-sm font-semibold text-foreground-900">İmza Önizleme</p>
            <SignaturePreview view={view} />
          </div>
        </>
      )}
    </div>
  );
}