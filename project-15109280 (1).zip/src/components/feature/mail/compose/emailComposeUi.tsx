import { useCallback, useState } from 'react';

/** Rol → görünen etiket (imza kartı ve başlıkta kullanılır). */
const ROLE_LABELS: Record<string, string> = {
  admin: 'Yönetici',
  osgb_admin: 'OSGB Yöneticisi',
  uzman: 'İş Güvenliği Uzmanı',
  hekim: 'İşyeri Hekimi',
  firma: 'Firma Yetkilisi',
};

export function roleLabel(role: string | null | undefined): string {
  if (!role) return 'İSG Profesyoneli';
  return ROLE_LABELS[role] ?? 'İSG Profesyoneli';
}

/** Ad soyaddan baş harfleri üretir (avatar). */
export function initials(name: string): string {
  const parts = (name || '').trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function formatFileSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 B';
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  return `${(kb / 1024).toFixed(1)} MB`;
}

/** MIME/uzantıya göre remix ikon sınıfı. */
export function documentIcon(mime: string | undefined, name: string): string {
  const m = (mime || '').toLowerCase();
  const ext = (name.split('.').pop() || '').toLowerCase();
  if (m.includes('pdf') || ext === 'pdf') return 'ri-file-pdf-2-line';
  if (m.includes('word') || ['doc', 'docx', 'odt'].includes(ext)) return 'ri-file-word-2-line';
  if (m.includes('sheet') || m.includes('excel') || ['xls', 'xlsx', 'ods', 'csv'].includes(ext)) return 'ri-file-excel-2-line';
  if (m.startsWith('image/') || ['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(ext)) return 'ri-image-line';
  if (m.includes('zip') || ['zip', 'rar', '7z'].includes(ext)) return 'ri-file-zip-line';
  return 'ri-file-line';
}

export function fileIconTone(mime: string | undefined, name: string): string {
  const icon = documentIcon(mime, name);
  if (icon === 'ri-file-pdf-2-line') return 'text-danger-600 dark:text-danger-400';
  if (icon === 'ri-file-word-2-line') return 'text-primary-600 dark:text-primary-400';
  if (icon === 'ri-file-excel-2-line') return 'text-success-600 dark:text-success-400';
  if (icon === 'ri-image-line') return 'text-accent-600 dark:text-accent-400';
  return 'text-foreground-500';
}

/** Bölüm başlığı (ikon kutusu + başlık). */
export function EmailSectionHead({ icon, title }: { icon: string; title: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-7 h-7 rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0">
        <i className={icon} />
      </span>
      <p className="text-sm font-semibold text-foreground-900">{title}</p>
    </div>
  );
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Çoklu e-posta çip alanı (To/Cc/Bcc). */
export function EmailChips({
  label,
  required,
  value,
  onChange,
  placeholder,
  autoFocus,
}: {
  label: string;
  required?: boolean;
  value: string[];
  onChange: (v: string[]) => void;
  placeholder?: string;
  autoFocus?: boolean;
}) {
  const [draft, setDraft] = useState('');
  const [invalid, setInvalid] = useState<string | null>(null);

  const commitRaw = useCallback(
    (raw: string) => {
      const parts = raw.split(/[,;\s]+/).map((s) => s.trim()).filter(Boolean);
      if (parts.length === 0) return;
      const bad = parts.filter((p) => !EMAIL_RE.test(p));
      if (bad.length > 0) {
        setInvalid(`Geçersiz e-posta: ${bad.join(', ')}`);
        return;
      }
      const next = [...value];
      parts.forEach((p) => {
        if (!next.includes(p)) next.push(p);
      });
      onChange(next);
      setDraft('');
      setInvalid(null);
    },
    [value, onChange],
  );

  const commit = useCallback(() => commitRaw(draft), [commitRaw, draft]);

  const handleChange = (val: string) => {
    if (/[,;]/.test(val)) {
      const parts = val.split(/[,;]+/);
      const tail = parts.pop() ?? '';
      const head = parts.join(',');
      if (head.trim()) commitRaw(head);
      setDraft(tail);
    } else {
      setDraft(val);
    }
  };

  return (
    <div className="w-full">
      <label className="isg-form-label">
        {label}
        {required && <span className="text-danger-600 ml-0.5">*</span>}
      </label>
      <div
        className={`flex flex-wrap items-center gap-1.5 rounded-md border bg-background-100 dark:bg-background-200/50 px-2 py-1.5 min-h-[38px] transition-colors ${
          invalid ? 'border-danger-500' : 'border-background-400/60 focus-within:border-primary-500'
        }`}
      >
        {value.map((mail, i) => (
          <span
            key={mail}
            className="inline-flex items-center gap-1 pl-2 pr-1 py-0.5 rounded-md bg-secondary-100 dark:bg-secondary-500/20 text-secondary-900 dark:text-secondary-100 text-xs max-w-full"
          >
            <span className="truncate">{mail}</span>
            <button
              type="button"
              onClick={() => onChange(value.filter((_, idx) => idx !== i))}
              className="w-4 h-4 flex items-center justify-center rounded-full hover:bg-secondary-200 dark:hover:bg-secondary-500/30 cursor-pointer flex-shrink-0"
              aria-label={`${mail} kaldır`}
            >
              <i className="ri-close-line text-xs" />
            </button>
          </span>
        ))}
        <input
          type="email"
          autoComplete="off"
          autoFocus={autoFocus}
          value={draft}
          onChange={(e) => handleChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ',' || e.key === ';' || e.key === 'Tab') {
              if (e.key !== 'Tab') e.preventDefault();
              commit();
            } else if (e.key === 'Backspace' && !draft && value.length > 0) {
              onChange(value.slice(0, -1));
            }
          }}
          onBlur={commit}
          placeholder={value.length === 0 ? placeholder : ''}
          className="flex-1 min-w-[140px] bg-transparent outline-none text-sm text-foreground-800 py-1 placeholder:text-foreground-400"
        />
      </div>
      {invalid && (
        <p className="mt-1 text-xs text-danger-600 flex items-center gap-1">
          <i className="ri-error-warning-line" />
          {invalid}
        </p>
      )}
    </div>
  );
}