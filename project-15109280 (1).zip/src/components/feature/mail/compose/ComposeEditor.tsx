import { useEffect, useRef, useState } from 'react';
import { sanitizeHtml } from '@/lib/sanitizeHtml';

interface ComposeEditorProps {
  value: string;
  onChange: (html: string, text: string) => void;
  placeholder?: string;
  maxLength?: number;
}

/**
 * E-posta oluşturma için zengin metin editörü (contentEditable + araç çubuğu).
 * Gönderilen HTML her zaman merkezi `sanitizeHtml` ile temizlenir (script/on*
 * handler/javascript: URL'ler DOM'a ve kayda girmez).
 */
export default function ComposeEditor({ value, onChange, placeholder = 'Mesajınızı yazın...', maxLength = 5000 }: ComposeEditorProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [expanded, setExpanded] = useState(false);
  const [block, setBlock] = useState('p');
  const [linkOpen, setLinkOpen] = useState(false);
  const [linkUrl, setLinkUrl] = useState('');
  const [imageOpen, setImageOpen] = useState(false);
  const [imageUrl, setImageUrl] = useState('');
  const [savedRange, setSavedRange] = useState<Range | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (document.activeElement === el) return;
    const clean = sanitizeHtml(value, 'rich');
    if (el.innerHTML !== clean) el.innerHTML = clean;
  }, [value]);

  const emit = () => {
    const el = ref.current;
    if (!el) return;
    const html = sanitizeHtml(el.innerHTML, 'rich');
    onChange(html, el.innerText ?? '');
  };

  const exec = (cmd: string, arg?: string) => {
    ref.current?.focus();
    document.execCommand(cmd, false, arg);
    emit();
  };

  const applyBlock = (tag: string) => {
    setBlock(tag);
    exec('formatBlock', tag);
  };

  const openLink = () => {
    const el = ref.current;
    if (el) {
      const sel = window.getSelection();
      if (sel && sel.rangeCount > 0) setSavedRange(sel.getRangeAt(0).cloneRange());
    }
    setLinkUrl('');
    setLinkOpen(true);
  };

  const applyLink = () => {
    let url = linkUrl.trim();
    if (url && !/^https?:\/\//i.test(url) && !/^mailto:/i.test(url)) url = `https://${url}`;
    const el = ref.current;
    if (el && url) {
      el.focus();
      const sel = window.getSelection();
      if (savedRange && sel) {
        sel.removeAllRanges();
        sel.addRange(savedRange);
      }
      document.execCommand('createLink', false, url);
      emit();
    }
    setLinkOpen(false);
    setLinkUrl('');
    setSavedRange(null);
  };

  const openImage = () => {
    const el = ref.current;
    if (el) {
      const sel = window.getSelection();
      if (sel && sel.rangeCount > 0) setSavedRange(sel.getRangeAt(0).cloneRange());
    }
    setImageUrl('');
    setImageOpen(true);
  };

  const applyImage = () => {
    const url = imageUrl.trim();
    const el = ref.current;
    if (el && url && /^https?:|^data:image\//i.test(url)) {
      el.focus();
      const sel = window.getSelection();
      if (savedRange && sel) {
        sel.removeAllRanges();
        sel.addRange(savedRange);
      }
      document.execCommand('insertImage', false, url);
      emit();
    }
    setImageOpen(false);
    setImageUrl('');
    setSavedRange(null);
  };

  const insertTable = () => {
    ref.current?.focus();
    document.execCommand(
      'insertHTML',
      false,
      '<table><tbody><tr><td><br></td><td><br></td><td><br></td></tr><tr><td><br></td><td><br></td><td><br></td></tr><tr><td><br></td><td><br></td><td><br></td></tr></tbody></table>',
    );
    emit();
  };

  const plainLen = (ref.current?.innerText ?? '').length;
  const over = plainLen > maxLength;

  const btn = 'w-7 h-7 flex items-center justify-center rounded text-foreground-600 hover:bg-background-200 dark:hover:bg-background-300/40 hover:text-foreground-900 transition-colors cursor-pointer';

  return (
    <div className="rounded-md border border-background-300/60 dark:border-background-400/40 bg-background-50 dark:bg-background-200/40 overflow-hidden">
      <div className="flex flex-wrap items-center gap-0.5 px-2 py-1.5 border-b border-background-300/30 dark:border-background-400/25">
        <button type="button" className={btn} title="Geri al" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('undo')}>
          <i className="ri-arrow-go-back-line text-sm" />
        </button>
        <button type="button" className={btn} title="Yinele" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('redo')}>
          <i className="ri-arrow-go-forward-line text-sm" />
        </button>
        <div className="w-px h-5 bg-background-300/60 dark:bg-background-400/30 mx-1" />
        <select
          value={block}
          onChange={(e) => applyBlock(e.target.value)}
          onMouseDown={(e) => e.stopPropagation()}
          className="h-7 rounded border border-background-300/60 dark:border-background-400/40 bg-background-50 dark:bg-background-200/60 text-xs text-foreground-700 px-1.5 cursor-pointer outline-none"
          title="Paragraf biçimi"
        >
          <option value="p">Paragraf</option>
          <option value="h3">Başlık</option>
          <option value="blockquote">Alıntı</option>
          <option value="pre">Kod</option>
        </select>
        <div className="w-px h-5 bg-background-300/60 dark:bg-background-400/30 mx-1" />
        <button type="button" className={btn} title="Kalın" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('bold')}>
          <i className="ri-bold text-sm" />
        </button>
        <button type="button" className={btn} title="İtalik" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('italic')}>
          <i className="ri-italic text-sm" />
        </button>
        <button type="button" className={btn} title="Altı çizili" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('underline')}>
          <i className="ri-underline text-sm" />
        </button>
        <div className="w-px h-5 bg-background-300/60 dark:bg-background-400/30 mx-1" />
        <button type="button" className={btn} title="Madde listesi" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('insertUnorderedList')}>
          <i className="ri-list-unordered text-sm" />
        </button>
        <button type="button" className={btn} title="Numaralı liste" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('insertOrderedList')}>
          <i className="ri-list-ordered text-sm" />
        </button>
        <div className="w-px h-5 bg-background-300/60 dark:bg-background-400/30 mx-1" />
        <button type="button" className={btn} title="Sola hizala" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('justifyLeft')}>
          <i className="ri-align-left text-sm" />
        </button>
        <button type="button" className={btn} title="Ortala" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('justifyCenter')}>
          <i className="ri-align-center text-sm" />
        </button>
        <button type="button" className={btn} title="Sağa hizala" onMouseDown={(e) => e.preventDefault()} onClick={() => exec('justifyRight')}>
          <i className="ri-align-right text-sm" />
        </button>
        <div className="w-px h-5 bg-background-300/60 dark:bg-background-400/30 mx-1" />
        <button type="button" className={btn} title="Bağlantı" onMouseDown={(e) => e.preventDefault()} onClick={openLink}>
          <i className="ri-link text-sm" />
        </button>
        <button type="button" className={btn} title="Görsel ekle" onMouseDown={(e) => e.preventDefault()} onClick={openImage}>
          <i className="ri-image-add-line text-sm" />
        </button>
        <button type="button" className={btn} title="Tablo ekle" onMouseDown={(e) => e.preventDefault()} onClick={insertTable}>
          <i className="ri-table-line text-sm" />
        </button>
        <button type="button" className={btn} title="Biçimi temizle" onMouseDown={(e) => e.preventDefault()} onClick={() => { setBlock('p'); exec('removeFormat'); }}>
          <i className="ri-eraser-line text-sm" />
        </button>
        <button
          type="button"
          className={`${btn} ml-auto`}
          title={expanded ? 'Küçült' : 'Genişlet'}
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => setExpanded((v) => !v)}
        >
          <i className={expanded ? 'ri-collapse-diagonal-line text-sm' : 'ri-expand-diagonal-line text-sm'} />
        </button>
      </div>

      {linkOpen && (
        <div className="flex items-center gap-2 px-2.5 py-2 bg-background-100 dark:bg-background-200/60 border-b border-background-300/30 dark:border-background-400/25">
          <i className="ri-link text-foreground-400 text-sm" />
          <input
            type="text"
            autoFocus
            value={linkUrl}
            onChange={(e) => setLinkUrl(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') { e.preventDefault(); applyLink(); }
              if (e.key === 'Escape') setLinkOpen(false);
            }}
            placeholder="https://ornek.com"
            className="flex-1 min-w-0 bg-transparent outline-none text-sm text-foreground-800 placeholder:text-foreground-400"
          />
          <button type="button" onClick={applyLink} className="text-xs font-medium text-primary-600 dark:text-primary-400 hover:underline cursor-pointer whitespace-nowrap">
            Ekle
          </button>
          <button type="button" onClick={() => setLinkOpen(false)} className="text-xs text-foreground-500 hover:text-foreground-800 cursor-pointer whitespace-nowrap">
            İptal
          </button>
        </div>
      )}

      {imageOpen && (
        <div className="flex items-center gap-2 px-2.5 py-2 bg-background-100 dark:bg-background-200/60 border-b border-background-300/30 dark:border-background-400/25">
          <i className="ri-image-line text-foreground-400 text-sm" />
          <input
            type="text"
            autoFocus
            value={imageUrl}
            onChange={(e) => setImageUrl(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') { e.preventDefault(); applyImage(); }
              if (e.key === 'Escape') setImageOpen(false);
            }}
            placeholder="https://ornek.com/gorsel.png"
            className="flex-1 min-w-0 bg-transparent outline-none text-sm text-foreground-800 placeholder:text-foreground-400"
          />
          <button type="button" onClick={applyImage} className="text-xs font-medium text-primary-600 dark:text-primary-400 hover:underline cursor-pointer whitespace-nowrap">
            Ekle
          </button>
          <button type="button" onClick={() => setImageOpen(false)} className="text-xs text-foreground-500 hover:text-foreground-800 cursor-pointer whitespace-nowrap">
            İptal
          </button>
        </div>
      )}

      <div className="relative">
        <div
          ref={ref}
          contentEditable
          suppressContentEditableWarning
          onInput={emit}
          onBlur={emit}
          style={{ minHeight: expanded ? 380 : 200 }}
          className="isg-rte px-3 py-2.5 text-sm text-foreground-800 leading-relaxed outline-none"
        />
        {plainLen === 0 && (
          <span className="pointer-events-none absolute left-3 top-2.5 text-sm text-foreground-400">{placeholder}</span>
        )}
      </div>

      <div className="flex items-center justify-end px-3 py-1.5 border-t border-background-300/30 dark:border-background-400/25">
        <span className={`text-[11px] tabular-nums ${over ? 'text-danger-600' : 'text-foreground-400'}`}>
          {plainLen}/{maxLength}
        </span>
      </div>
    </div>
  );
}