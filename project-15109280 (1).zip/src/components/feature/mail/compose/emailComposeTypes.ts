import type { MailAttachment } from '@/lib/mail/types';

/** Ortak e-posta modalının açılma amacı (yeni / yanıt / tümünü yanıtla / ilet). */
export type EmailComposeMode = 'new' | 'reply' | 'replyAll' | 'forward';

/** Gönderen kullanıcı bağlamı (imza kartı ve gönderen kutusu için). */
export interface EmailSenderContext {
  adSoyad: string;
  rolLabel: string;
  email: string | null;
  telefon: string | null;
  logoUrl: string | null;
  /** OSGB'nin kurumsal bilgilerinden türetilen varsayılan imza alanları. */
  sirketAdi: string | null;
  website: string | null;
}

/** Otomatik eklenecek (caller tarafından hazırlanan) belge ekleri — yalnızca bilgi. */
export interface EmailAutoAttachment {
  fileName: string;
  sizeLabel?: string;
  mimeType?: string;
}

/** E-posta gönderme noktasına ait bağlam. */
export interface EmailComposeContext {
  /** Modal başlığında gösterilen bağlam (kişi/firma adı). */
  recipientName: string;
  recipientRole?: string;
  /** Açıldığı sayfadan gelen gerçek alıcı e-postası. */
  defaultTo?: string;
  defaultCc?: string;
  defaultBcc?: string;
  defaultSubject?: string;
  /** Varsayılan gövde (düz metin; satır sonları korunur). */
  defaultBody?: string;
  /** Modalın açılma amacı. Verilmezse 'new' kabul edilir. */
  mode?: EmailComposeMode;
  /** Yanıt/ilet zinciri — gönderimde sağlayıcıya aynen iletilir. */
  threadId?: string;
  inReplyTo?: string;
  references?: string;
  /** İlet modunda taşınan orijinal ekler (kullanıcı kaldırabilir). */
  initialAttachments?: EmailComposeAttachment[];
  /** Açıldığı sayfadan gelen gönderen bilgisi. Verilmezse bileşen profil + OSGB'den türetir. */
  sender?: EmailSenderContext;
  /** Görüntülenen otomatik ekler (tutanak belgesi/ekleri gibi). */
  autoAttachments?: EmailAutoAttachment[];
  relatedModule?: string;
  relatedRecordId?: string;
}

/** Kullanıcının elle eklediği ek (base64 gömülü). */
export interface EmailComposeAttachment extends MailAttachment {
  fileName: string;
  mimeType: string;
  contentBase64: string;
}

/** Ortak modalın gönderim anında caller'a verdiği paket. */
export interface EmailComposeSendPayload {
  to: string[];
  cc: string[];
  bcc: string[];
  subject: string;
  /** İmza dahil düz metin gövde. */
  body: string;
  /** İmza dahil HTML gövde. */
  html: string;
  /** Kullanıcının elle eklediği ekler. */
  attachments: EmailComposeAttachment[];
  /** Yanıt/ilet zinciri başlıkları (yeni e-postada boş). */
  threadId?: string;
  inReplyTo?: string;
  references?: string;
}