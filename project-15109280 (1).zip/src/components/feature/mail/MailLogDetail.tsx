import type { ReactNode } from 'react';
import Badge from '@/components/ui/Badge';
import type { MailLog } from '@/lib/mail/types';
import { formatIstanbulDateTime } from '@/lib/dateFormat';

function statusVariant(status: MailLog['status']) {
  if (status === 'sent') return 'success' as const;
  if (status === 'failed') return 'danger' as const;
  return 'default' as const;
}

function statusLabel(status: MailLog['status']) {
  if (status === 'sent') return 'Gönderildi';
  if (status === 'failed') return 'Başarısız';
  return 'Bekliyor';
}

function providerLabel(provider: string | null): string {
  if (provider === 'google') return 'Google / Gmail';
  if (provider === 'microsoft') return 'Microsoft 365 / Outlook';
  if (provider === 'smtp') return 'Özel SMTP';
  return provider || '—';
}

function formatDate(iso: string | null): string {
  return formatIstanbulDateTime(iso);
}

function Row({ icon, label, value }: { icon: string; label: string; value: ReactNode }) {
  return (
    <div className="flex items-start gap-2.5 py-2 border-b isg-divider last:border-0">
      <span className="w-7 h-7 rounded-md bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center flex-shrink-0 mt-0.5">
        <i className={icon} />
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-[11px] font-medium text-foreground-500 uppercase tracking-wide">{label}</p>
        <div className="text-sm text-foreground-800 break-words mt-0.5">{value}</div>
      </div>
    </div>
  );
}

/**
 * Gönderim kaydı detay görünümü — Ayarlar → E-posta "Son Gönderimler" listesinden
 * bir kayda tıklandığında modal içeriği olarak gösterilir.
 */
export default function MailLogDetail({ log }: { log: MailLog }) {
  const attachments = log.attachmentRef;
  return (
    <div className="flex flex-col">
      <Row
        icon="ri-mail-line"
        label="Konu"
        value={log.subject ? <span className="font-semibold text-foreground-950">{log.subject}</span> : '(Konusuz)'}
      />
      <Row icon="ri-shield-check-line" label="Durum" value={<Badge variant={statusVariant(log.status)} size="sm">{statusLabel(log.status)}</Badge>} />
      <Row icon="ri-user-received-line" label="Alıcı" value={log.recipientTo || '—'} />
      {log.recipientCc && <Row icon="ri-group-line" label="Cc" value={log.recipientCc} />}
      {log.recipientBcc && <Row icon="ri-eye-off-line" label="Bcc" value={log.recipientBcc} />}
      <Row icon="ri-send-plane-line" label="Sağlayıcı" value={providerLabel(log.provider)} />
      {attachments && attachments.count > 0 && (
        <Row
          icon="ri-attachment-2"
          label={`Ekler (${attachments.count})`}
          value={
            <ul className="flex flex-col gap-1">
              {attachments.fileNames.map((name, i) => (
                <li key={`${name}-${i}`} className="flex items-center gap-1.5">
                  <i className="ri-file-line text-foreground-400" />
                  <span className="truncate">{name}</span>
                </li>
              ))}
            </ul>
          }
        />
      )}
      {log.relatedModule && <Row icon="ri-links-line" label="İlişkili Modül" value={log.relatedModule} />}
      <Row icon="ri-calendar-check-line" label="Gönderim Tarihi" value={formatDate(log.sentAt)} />
      <Row icon="ri-history-line" label="Oluşturulma" value={formatDate(log.createdAt)} />
      {log.providerMessageId && <Row icon="ri-fingerprint-line" label="Sağlayıcı Mesaj No" value={log.providerMessageId} />}
      {log.errorCode && <Row icon="ri-error-warning-line" label="Hata Kodu" value={log.errorCode} />}
      {log.errorMessage && (
        <Row
          icon="ri-alert-line"
          label="Hata Mesajı"
          value={<span className="text-danger-700 dark:text-danger-400">{log.errorMessage}</span>}
        />
      )}
    </div>
  );
}