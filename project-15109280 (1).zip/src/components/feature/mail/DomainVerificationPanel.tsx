import { useState } from 'react';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';

export interface DomainVerificationPanelProps {
  /** Doğrulanacak alan adı (ör. sirketiniz.com) */
  domain: string;
  /** DNS sağlayıcısına eklenecek TXT kaydının adı */
  recordName: string;
  /** DNS sağlayıcısına girilecek TXT değeri */
  recordValue: string;
  /** Sunucudan gelen ek açıklama (opsiyonel) */
  instructions?: string | null;
  /** Sunucu tarafındaki güncel durum */
  status: 'pending' | 'verified';
  /** Kontrol isteği sürüyor mu */
  checking: boolean;
  /** "Doğrulamayı Kontrol Et" */
  onCheck: () => void;
  /** Paneli kapat (yalnızca istenirse gösterilir) */
  onDismiss?: () => void;
}

async function copyText(value: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    return false;
  }
}

/**
 * M1 · Gönderen alan adı sahiplik doğrulama paneli.
 *
 * Kullanıcıya DNS TXT kaydını gösterir, kopyalama sağlar ve sunucudaki
 * doğrulama durumunu yansıtır. Doğrulama tamamlanana kadar panel bunu
 * açıkça belirtir; gönderim zaten sunucu tarafında engellidir.
 */
export default function DomainVerificationPanel({
  domain,
  recordName,
  recordValue,
  instructions,
  status,
  checking,
  onCheck,
  onDismiss,
}: DomainVerificationPanelProps) {
  const [copied, setCopied] = useState<'name' | 'value' | null>(null);
  const verified = status === 'verified';

  const handleCopy = async (kind: 'name' | 'value') => {
    const ok = await copyText(kind === 'name' ? recordName : recordValue);
    if (ok) {
      setCopied(kind);
      window.setTimeout(() => setCopied(null), 2000);
    }
  };

  return (
    <div
      className={`rounded-lg border p-4 space-y-3 ${
        verified
          ? 'bg-success-50 border-success-300/60'
          : 'bg-warning-50 border-warning-300/60'
      }`}
    >
      <div className="flex items-start gap-3">
        <i
          className={`${verified ? 'ri-shield-check-line text-success-700' : 'ri-shield-keyhole-line text-warning-700'} text-lg mt-0.5 flex-shrink-0`}
        />
        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <p className="text-sm font-medium text-foreground-900">Gönderen alan adı doğrulaması</p>
            <Badge variant={verified ? 'success' : 'warning'} size="sm">
              {verified ? 'Doğrulandı' : 'Bekliyor'}
            </Badge>
          </div>
          <p className="text-xs text-foreground-600 break-words">
            <strong>{domain}</strong> alan adından e-posta gönderebilmek için alan adının size ait olduğunu
            DNS kaydıyla kanıtlamanız gerekir. Doğrulama tamamlanana kadar bu adresten gönderim yapılamaz.
          </p>
        </div>
        {onDismiss && (
          <button
            type="button"
            onClick={onDismiss}
            aria-label="Paneli kapat"
            className="w-7 h-7 flex items-center justify-center rounded-md text-foreground-500 hover:bg-background-200/60 transition-colors cursor-pointer flex-shrink-0"
          >
            <i className="ri-close-line" />
          </button>
        )}
      </div>

      {!verified && (
        <div className="space-y-2">
          <div className="rounded-md bg-background-50 border border-background-300/60 p-3 space-y-2">
            <div className="space-y-1">
              <p className="text-[11px] font-medium uppercase tracking-wide text-foreground-500">Kayıt Türü</p>
              <p className="text-sm text-foreground-800">TXT</p>
            </div>
            <div className="space-y-1">
              <p className="text-[11px] font-medium uppercase tracking-wide text-foreground-500">Kayıt Adı (Host)</p>
              <div className="flex items-start gap-2">
                <code className="flex-1 min-w-0 text-xs text-foreground-900 bg-background-100 rounded-md px-2 py-1.5 break-all">
                  {recordName}
                </code>
                <Button
                  variant="outline"
                  size="xs"
                  onClick={() => void handleCopy('name')}
                  leftIcon={<i className={copied === 'name' ? 'ri-check-line' : 'ri-file-copy-line'} />}
                  className="whitespace-nowrap"
                >
                  {copied === 'name' ? 'Kopyalandı' : 'Kopyala'}
                </Button>
              </div>
            </div>
            <div className="space-y-1">
              <p className="text-[11px] font-medium uppercase tracking-wide text-foreground-500">Kayıt Değeri</p>
              <div className="flex items-start gap-2">
                <code className="flex-1 min-w-0 text-xs text-foreground-900 bg-background-100 rounded-md px-2 py-1.5 break-all">
                  {recordValue}
                </code>
                <Button
                  variant="outline"
                  size="xs"
                  onClick={() => void handleCopy('value')}
                  leftIcon={<i className={copied === 'value' ? 'ri-check-line' : 'ri-file-copy-line'} />}
                  className="whitespace-nowrap"
                >
                  {copied === 'value' ? 'Kopyalandı' : 'Kopyala'}
                </Button>
              </div>
            </div>
          </div>

          <p className="text-xs text-foreground-600">
            {instructions ||
              'DNS sağlayıcınızda yukarıdaki TXT kaydını ekleyin. Yayılım genellikle 5–30 dakika sürer; ardından doğrulamayı kontrol edin.'}
          </p>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="secondary"
              size="sm"
              isLoading={checking}
              onClick={onCheck}
              leftIcon={<i className="ri-refresh-line" />}
              className="whitespace-nowrap"
            >
              Doğrulamayı Kontrol Et
            </Button>
            <span className="text-xs text-foreground-500">Kaydı ekledikten sonra bu düğmeyi kullanın.</span>
          </div>
        </div>
      )}
    </div>
  );
}