import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Loading from '@/components/ui/Loading';
import Alert from '@/components/ui/Alert';
import ComposeEditor from './compose/ComposeEditor';
import EmailSignaturePanel from './compose/EmailSignaturePanel';
import { EmailChips, EmailSectionHead, documentIcon, fileIconTone, formatFileSize, initials, roleLabel } from './compose/emailComposeUi';
import type { EmailComposeContext, EmailComposeSendPayload, EmailSenderContext } from './compose/emailComposeTypes';
import type { EmailComposeAttachment } from './compose/emailComposeTypes';
import EmailIntegrationSection from './EmailIntegrationSection';
import { getConnection } from '@/lib/mail/mailService';
import { friendlyMailError } from '@/lib/mail/errors';
import type { MailConnection } from '@/lib/mail/types';
import { signatureToHtml, signatureToText, signatureToView, type SignatureView } from '@/lib/mail/signatureFormat';
import { useEmailSignatures } from '@/hooks/useEmailSignatures';
import { useAuth } from '@/context/AuthContext';
import { fetchKurumsalOsgb } from '@/lib/osgbService';
import { useToastActions } from '@/hooks/useToast';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_FILE = 25 * 1024 * 1024;
const ACCEPT = '.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.odt,.ods,.txt,image/jpeg,image/png,image/webp,image/gif';

interface EmailComposeModalProps {
  context: EmailComposeContext;
  /** Gerçek gönderimi yapan caller callback'i (mevcut servisi korur). */
  onSend: (payload: EmailComposeSendPayload) => Promise<void>;
  onClose: () => void;
  successTitle?: string;
  successMessage?: string;
  /** Gönderim noktasına özel belge seçenekleri (ör. Teklif PDF/Word). */
  attachmentChoices?: {
    id: string;
    label: string;
    fileName: string;
    icon?: string;
    tone?: string;
    checked: boolean;
    onChange: (v: boolean) => void;
  }[];
}

function textToHtml(text: string): string {
  if (!text) return '';
  return text
    .split('\n')
    .map((l) => l.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'))
    .join('<br>');
}

/** Virgülle ayrılmış (veya tek) adres dizesini chip listesine çevirir. */
function parseAddressList(raw?: string): string[] {
  if (!raw) return [];
  return raw
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      const comma = result.indexOf(',');
      resolve(comma >= 0 ? result.slice(comma + 1) : result);
    };
    reader.onerror = () => reject(reader.error ?? new Error('Dosya okunamadı.'));
    reader.readAsDataURL(file);
  });
}

/**
 * MERKEZİ PREMIUM "E-posta Gönder" modalı (TEK KAYNAK).
 *
 * Personel / Teklif / Tutanak ve ileride eklenecek tüm e-posta gönderme noktaları
 * bu bileşeni kullanır. Gönderim mantığı caller'a `onSend` ile delege edilir;
 * böylece mevcut servisler (`sendMail` / `sendTutanakMail`) ve bağlam (alıcı,
 * ilişkili kayıt, ekler) korunur. Bu bileşen yalnızca ORTAK deneyimi sağlar:
 * gönderen/alanlar/zengin metin/ekler/imza + doğrulama + çift-gönderim
 * koruması + loading + bildirim.
 *
 * Not: Konu ve gövde VARSAYILAN OLARAK BOŞ açılır; otomatik içerik ÜRETİLMEZ.
 */
export default function EmailComposeModal({
  context,
  onSend,
  onClose,
  successTitle = 'E-posta gönderildi',
  successMessage,
  attachmentChoices,
}: EmailComposeModalProps) {
  const { addToast } = useToastActions();
  const { profile } = useAuth();

  const [connLoading, setConnLoading] = useState(true);
  const [connection, setConnection] = useState<MailConnection | null>(null);
  const [kurumsal, setKurumsal] = useState<{ unvan: string | null; telefon: string | null; website: string | null; logoUrl: string | null } | null>(null);

  const [to, setTo] = useState<string[]>(() => parseAddressList(context.defaultTo));
  const [cc, setCc] = useState<string[]>(() => parseAddressList(context.defaultCc));
  const [bcc, setBcc] = useState<string[]>(() => parseAddressList(context.defaultBcc));
  const [showCc, setShowCc] = useState(!!context.defaultCc);
  const [showBcc, setShowBcc] = useState(!!context.defaultBcc);
  const [subject, setSubject] = useState(context.defaultSubject ?? '');
  const [bodyHtml, setBodyHtml] = useState(() => textToHtml(context.defaultBody ?? ''));
  const [bodyText, setBodyText] = useState(context.defaultBody ?? '');
  const [files, setFiles] = useState<File[]>([]);
  // İlet modunda taşınan orijinal ekler (kaldırılabilir).
  const [extraAttachments, setExtraAttachments] = useState<EmailComposeAttachment[]>(() => context.initialAttachments ?? []);
  const [dragOver, setDragOver] = useState(false);

  const [signEnabled, setSignEnabled] = useState(true);
  const [selectedSigId, setSelectedSigId] = useState<string | null>(null);

  const [sending, setSending] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const { signatures, loading: sigLoading, refresh: refreshSignatures } = useEmailSignatures();

  const loadConnection = useCallback(() => {
    setConnLoading(true);
    getConnection()
      .then(setConnection)
      .catch(() => setConnection(null))
      .finally(() => setConnLoading(false));
  }, []);

  useEffect(() => {
    loadConnection();
  }, [loadConnection]);

  const osgbId = profile?.osgbId ?? null;
  useEffect(() => {
    if (!osgbId) return undefined;
    let cancelled = false;
    fetchKurumsalOsgb(osgbId)
      .then((d) => {
        if (cancelled) return;
        setKurumsal(d ? { unvan: d.unvan, telefon: d.telefon, website: d.website, logoUrl: d.logoUrl } : null);
      })
      .catch(() => { if (!cancelled) setKurumsal(null); });
    return () => { cancelled = true; };
  }, [osgbId]);

  const sender: EmailSenderContext = useMemo(() => {
    if (context.sender) return context.sender;
    const adSoyad = `${profile?.firstName ?? ''} ${profile?.lastName ?? ''}`.trim();
    return {
      adSoyad: adSoyad || 'İSG Profesyoneli',
      rolLabel: roleLabel(profile?.role),
      email: connection?.senderEmail ?? profile?.email ?? null,
      telefon: kurumsal?.telefon ?? null,
      logoUrl: kurumsal?.logoUrl ?? null,
      sirketAdi: kurumsal?.unvan ?? null,
      website: kurumsal?.website ?? null,
    };
  }, [context.sender, profile, connection, kurumsal]);

  const fallbackView: SignatureView = useMemo(
    () => ({
      adSoyad: sender.adSoyad,
      unvan: sender.rolLabel,
      telefon: sender.telefon,
      email: sender.email,
      sirketAdi: sender.sirketAdi,
      website: sender.website,
      logoUrl: sender.logoUrl,
      sosyalLinkedin: null,
      sosyalX: null,
      sosyalInstagram: null,
    }),
    [sender],
  );

  const selectedSignature = signatures.find((s) => s.id === selectedSigId) ?? null;
  const activeView: SignatureView = selectedSignature ? signatureToView(selectedSignature) : fallbackView;

  const addFiles = useCallback((incoming: FileList | File[]) => {
    const arr = Array.from(incoming);
    const valid: File[] = [];
    for (const f of arr) {
      if (f.size > MAX_FILE) {
        addToast({ title: 'Dosya çok büyük', message: `${f.name} 25 MB sınırını aşıyor.`, type: 'warning' });
        continue;
      }
      valid.push(f);
    }
    if (valid.length === 0) return;
    setFiles((prev) => {
      const next = [...prev];
      for (const f of valid) {
        if (!next.some((x) => x.name === f.name && x.size === f.size)) next.push(f);
      }
      return next;
    });
  }, [addToast]);

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
  };

  const htmlForSend = useMemo(() => {
    const base = `<div style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#0f172a;line-height:1.6;">${bodyHtml}</div>`;
    if (!signEnabled) return base;
    return base + signatureToHtml(activeView);
  }, [bodyHtml, signEnabled, activeView]);

  const textForSend = useMemo(() => {
    if (!signEnabled) return bodyText;
    const sig = signatureToText(activeView);
    return sig ? `${bodyText}\n\n${sig}` : bodyText;
  }, [bodyText, signEnabled, activeView]);

  const handleSend = async () => {
    if (sending) return;
    const e: Record<string, string> = {};
    const toValid = to.filter((m) => EMAIL_RE.test(m));
    if (to.length === 0 || toValid.length !== to.length) e.to = 'Geçerli bir alıcı e-posta adresi girin.';
    const ccValid = cc.filter((m) => EMAIL_RE.test(m));
    if (cc.length > 0 && ccValid.length !== cc.length) e.cc = 'Geçerli bir CC e-posta adresi girin.';
    const bccValid = bcc.filter((m) => EMAIL_RE.test(m));
    if (bcc.length > 0 && bccValid.length !== bcc.length) e.bcc = 'Geçerli bir BCC e-posta adresi girin.';
    if (!subject.trim()) e.subject = 'Konu zorunludur.';
    if (!bodyText.trim()) e.body = 'Mesaj içeriği zorunludur.';
    setErrors(e);
    if (Object.keys(e).length > 0) {
      setFormError('Lütfen işaretli alanları kontrol edin.');
      return;
    }
    setFormError(null);
    setSending(true);
    try {
      const sentAttachments: EmailComposeAttachment[] = await Promise.all(
        files.map(async (f) => ({
          fileName: f.name,
          mimeType: f.type || 'application/octet-stream',
          contentBase64: await fileToBase64(f),
        })),
      );

      await onSend({
        to: toValid,
        cc: ccValid,
        bcc: bccValid,
        subject: subject.trim(),
        body: textForSend,
        html: htmlForSend,
        attachments: [...extraAttachments, ...sentAttachments],
        threadId: context.threadId,
        inReplyTo: context.inReplyTo,
        references: context.references,
      });

      addToast({ title: successTitle, message: successMessage ?? `${toValid.join(', ')} adresine e-posta gönderildi.`, type: 'success' });
      onClose();
    } catch (err) {
      const msg = friendlyMailError(err);
      setFormError(msg);
      addToast({ title: 'E-posta gönderilemedi', message: msg, type: 'error' });
    } finally {
      setSending(false);
    }
  };

  if (connLoading) {
    return (
      <div className="flex flex-1 items-center justify-center py-10">
        <Loading text="E-posta bağlantısı kontrol ediliyor..." />
      </div>
    );
  }

  if (!connection) {
    return (
      <div className="flex-1 overflow-y-auto isg-scroll-pane p-4 space-y-3">
        <div className="flex items-start gap-2 p-3 bg-warning-50 dark:bg-warning-500/10 border border-warning-200/60 dark:border-warning-500/20 rounded-lg">
          <i className="ri-alert-line text-warning-600 dark:text-warning-400 mt-0.5 flex-shrink-0" />
          <p className="text-xs text-foreground-700">
            E-posta göndermek için önce kendi e-posta hesabınızı bağlamalısınız. Bağlantıyı aşağıdan kurup
            ardından bu ekrana dönerek mail gönderebilirsiniz.
          </p>
        </div>
        <EmailIntegrationSection />
        <div className="flex justify-end">
          <Button variant="secondary" size="sm" leftIcon={<i className="ri-refresh-line" />} onClick={loadConnection}>
            Bağlantıyı Kontrol Et
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-1 min-h-0 flex-col">
      {/* Gövde: masaüstünde iki kolon — sol: e-posta oluşturma · sağ: yalnızca İmza */}
      <div className="flex-1 min-h-0 flex flex-col lg:flex-row overflow-y-auto isg-scroll-pane lg:overflow-hidden">
        {/* SOL KOLON — Gönderen · Alıcılar · Mesaj · Dosya Ekle (~%68) */}
        <div className="min-w-0 p-4 lg:pl-0 lg:flex-1 lg:min-h-0 lg:overflow-y-auto isg-scroll-pane">
          {formError && (
            <div className="mb-3">
              <Alert variant="danger" title="İşlem tamamlanamadı" onClose={() => setFormError(null)}>{formError}</Alert>
            </div>
          )}

          <div className="flex flex-col gap-4 w-full">
            {/* Gönderen */}
            <section className="isg-section p-3.5">
              <EmailSectionHead icon="ri-user-3-line" title="Gönderen" />
              <div className="mt-3 flex items-center gap-3 rounded-lg border border-background-200/70 dark:border-background-400/30 bg-background-100 dark:bg-background-200/40 p-2.5">
                <span className="w-10 h-10 rounded-full bg-primary-500/15 text-primary-600 dark:text-primary-400 flex items-center justify-center font-semibold flex-shrink-0">
                  {initials(sender.adSoyad)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-foreground-900 truncate">{sender.adSoyad}</p>
                  <p className="text-xs text-foreground-500 truncate">{[sender.rolLabel, sender.email].filter(Boolean).join(' · ')}</p>
                </div>
                {sender.telefon && (
                  <span className="hidden sm:flex items-center gap-1 text-xs text-foreground-500 whitespace-nowrap flex-shrink-0">
                    <i className="ri-phone-line" /> {sender.telefon}
                  </span>
                )}
              </div>
            </section>

            {/* Alıcı / CC / BCC / Konu */}
            <section className="isg-section p-3.5">
              <EmailSectionHead icon="ri-user-received-line" title="Alıcı Bilgileri" />
              <div className="mt-3 flex flex-col gap-3">
                <div className="relative">
                  <EmailChips label="Alıcı E-posta" required autoFocus={to.length === 0} value={to} onChange={(v) => { setTo(v); setErrors((p) => ({ ...p, to: '' })); }} placeholder="ornek@mail.com" />
                  <div className="absolute -top-0.5 right-0 flex items-center gap-1">
                    <button type="button" onClick={() => setShowCc((v) => !v)} className={`text-xs font-medium px-2 py-0.5 rounded-full cursor-pointer whitespace-nowrap ${showCc ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300' : 'text-primary-600 dark:text-primary-400 hover:bg-primary-50 dark:hover:bg-primary-500/10'}`}>CC</button>
                    <button type="button" onClick={() => setShowBcc((v) => !v)} className={`text-xs font-medium px-2 py-0.5 rounded-full cursor-pointer whitespace-nowrap ${showBcc ? 'bg-primary-100 dark:bg-primary-500/20 text-primary-700 dark:text-primary-300' : 'text-primary-600 dark:text-primary-400 hover:bg-primary-50 dark:hover:bg-primary-500/10'}`}>BCC</button>
                  </div>
                </div>
                {errors.to && <p className="text-xs text-danger-600 flex items-center gap-1 -mt-2"><i className="ri-error-warning-line" />{errors.to}</p>}

                {(showCc || showBcc) && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {showCc && <EmailChips label="Cc" value={cc} onChange={setCc} placeholder="cc@mail.com" />}
                    {showBcc && <EmailChips label="Bcc" value={bcc} onChange={setBcc} placeholder="bcc@mail.com" />}
                  </div>
                )}

                <div>
                  <Input label="Konu" required autoFocus={to.length > 0} value={subject} onChange={(e) => { setSubject(e.target.value); setErrors((p) => ({ ...p, subject: '' })); }} error={errors.subject} placeholder="E-posta konusu" leftIcon={<i className="ri-text" />} />
                </div>
              </div>
            </section>

            {/* Mesaj */}
            <section className="isg-section p-3.5">
              <EmailSectionHead icon="ri-mail-open-line" title="Mesaj" />
              <div className="mt-3">
                <ComposeEditor
                  value={bodyHtml}
                  onChange={(html, text) => { setBodyHtml(html); setBodyText(text); setErrors((p) => ({ ...p, body: '' })); }}
                />
                {errors.body && <p className="mt-1 text-xs text-danger-600 flex items-center gap-1"><i className="ri-error-warning-line" />{errors.body}</p>}
              </div>
            </section>

            {/* Ekler */}
            <section className="isg-section p-3.5">
              <EmailSectionHead icon="ri-attachment-2" title="Dosya Ekle" />
              <div className="mt-3 flex flex-col gap-2.5">
                {attachmentChoices?.map((c) => (
                  <label key={c.id} className="flex items-center gap-3 rounded-lg border border-background-200/70 dark:border-background-400/30 p-2.5 cursor-pointer">
                    <input type="checkbox" className="peer sr-only" checked={c.checked} onChange={(e) => c.onChange(e.target.checked)} />
                    <span className="w-[18px] h-[18px] min-w-[18px] rounded border-2 border-background-400 peer-checked:bg-primary-500 peer-checked:border-primary-500 flex items-center justify-center">
                      <i className="ri-check-line text-inverse text-xs" />
                    </span>
                    <i className={`${c.icon ?? 'ri-file-line'} text-lg flex-shrink-0 ${c.tone ?? 'text-foreground-500'}`} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium text-foreground-800">{c.label}</p>
                      <p className="text-[11px] text-foreground-500 truncate">{c.fileName}</p>
                    </div>
                  </label>
                ))}

                {context.autoAttachments && context.autoAttachments.length > 0 && (
                  <div className="flex flex-col gap-1.5">
                    {context.autoAttachments.map((a, i) => (
                      <div key={`${a.fileName}-${i}`} className="flex items-center gap-2.5 rounded-md bg-background-100 dark:bg-background-200/50 px-2.5 py-2">
                        <i className={`${documentIcon(a.mimeType, a.fileName)} text-base flex-shrink-0 ${fileIconTone(a.mimeType, a.fileName)}`} />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium text-foreground-800 truncate">{a.fileName}</p>
                          {a.sizeLabel && <p className="text-[11px] text-foreground-500">{a.sizeLabel}</p>}
                        </div>
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-semibold bg-secondary-100 dark:bg-secondary-500/20 text-secondary-700 dark:text-secondary-300 whitespace-nowrap flex-shrink-0">
                          <i className="ri-lock-2-line" /> Otomatik
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {extraAttachments.length > 0 && (
                  <div className="flex flex-col gap-1.5">
                    {extraAttachments.map((a, i) => (
                      <div key={`${a.fileName}-${i}`} className="flex items-center gap-2.5 rounded-md bg-background-100 dark:bg-background-200/50 px-2.5 py-2">
                        <i className={`${documentIcon(a.mimeType, a.fileName)} text-base flex-shrink-0 ${fileIconTone(a.mimeType, a.fileName)}`} />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium text-foreground-800 truncate">{a.fileName}</p>
                          <p className="text-[11px] text-foreground-500">İletilen ek</p>
                        </div>
                        <button type="button" onClick={() => setExtraAttachments((prev) => prev.filter((_, idx) => idx !== i))} className="w-6 h-6 flex items-center justify-center rounded text-foreground-400 hover:text-danger-600 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer flex-shrink-0" aria-label={`${a.fileName} kaldır`}>
                          <i className="ri-delete-bin-line text-sm" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                <div
                  onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={onDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`flex flex-col items-center justify-center gap-1.5 rounded-lg border border-dashed p-4 cursor-pointer transition-colors ${dragOver ? 'border-primary-500 bg-primary-50/60 dark:bg-primary-500/10' : 'border-background-300/70 dark:border-background-400/40 hover:border-primary-400'}`}
                >
                  <i className="ri-upload-cloud-2-line text-2xl text-primary-500" />
                  <p className="text-sm text-foreground-700"><span className="text-primary-600 dark:text-primary-400 font-medium">Dosyaları buraya sürükleyin veya tıklayın</span></p>
                  <p className="text-[11px] text-foreground-500">Maks. 25 MB • PDF, DOC, DOCX, XLS, XLSX, PNG, JPG</p>
                  <input ref={fileInputRef} type="file" multiple accept={ACCEPT} className="hidden" onChange={(e) => { if (e.target.files) addFiles(e.target.files); e.target.value = ''; }} />
                </div>

                {files.length > 0 && (
                  <ul className="flex flex-col gap-1.5">
                    {files.map((f, i) => (
                      <li key={`${f.name}-${i}`} className="flex items-center gap-2.5 rounded-md bg-background-100 dark:bg-background-200/50 px-2.5 py-2">
                        <i className={`${documentIcon(f.type, f.name)} text-base flex-shrink-0 ${fileIconTone(f.type, f.name)}`} />
                        <div className="min-w-0 flex-1">
                          <p className="text-xs font-medium text-foreground-800 truncate">{f.name}</p>
                          <p className="text-[11px] text-foreground-500">{formatFileSize(f.size)}</p>
                        </div>
                        <button type="button" onClick={() => setFiles((prev) => prev.filter((_, idx) => idx !== i))} className="w-6 h-6 flex items-center justify-center rounded text-foreground-400 hover:text-danger-600 hover:bg-danger-50 dark:hover:bg-danger-500/15 cursor-pointer flex-shrink-0" aria-label={`${f.name} kaldır`}>
                          <i className="ri-delete-bin-line text-sm" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            </section>
          </div>
        </div>

        {/* SAĞ KOLON — yalnızca İmza (~%32) */}
        <div className="border-t isg-divider lg:border-t-0 lg:border-l lg:w-[32%] lg:min-w-[300px] lg:max-w-[430px] flex-shrink-0 min-w-0 p-4 lg:min-h-0 lg:overflow-y-auto isg-scroll-pane">
          <div className="flex items-center gap-1 p-1 rounded-md bg-background-100 dark:bg-background-200/40 border border-background-200/60 dark:border-background-400/30 mb-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-primary-500/10 border border-primary-500/30 text-primary-700 dark:text-primary-300 text-sm font-semibold">
              <i className="ri-quill-pen-line" /> İmza
            </span>
          </div>
          <EmailSignaturePanel
            signatures={signatures}
            loading={sigLoading}
            refresh={refreshSignatures}
            enabled={signEnabled}
            onEnabledChange={setSignEnabled}
            selectedId={selectedSigId}
            onSelectedIdChange={setSelectedSigId}
            fallbackView={fallbackView}
            sender={sender}
          />
        </div>
      </div>

      {/* Sabit alt aksiyon çubuğu — modal genişliğini tam kaplar (gövde padding'ini nötrler). */}
      <div
        className="flex-shrink-0 border-t isg-divider px-4 py-2.5 flex items-center justify-between gap-2"
        style={{
          marginLeft: 'calc(-1 * var(--d-modal-body-px))',
          marginRight: 'calc(-1 * var(--d-modal-body-px))',
          marginBottom: 'calc(-1 * var(--d-modal-body-py))',
        }}
      >
        <Button variant="ghost" size="sm" leftIcon={<i className="ri-eye-line" />} onClick={() => setPreviewOpen(true)} disabled={sending}>
          Önizleme
        </Button>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={onClose} disabled={sending}>İptal</Button>
          <Button variant="primary" size="sm" leftIcon={<i className="ri-send-plane-2-line" />} onClick={handleSend} isLoading={sending} disabled={sending}>
            Gönder
          </Button>
        </div>
      </div>

      {/* Önizleme katmanı */}
      {previewOpen && (
        <div className="absolute inset-0 z-20 flex flex-col bg-background-50 dark:bg-background-100">
          <div className="flex items-center justify-between gap-2 px-4 py-3 border-b isg-divider flex-shrink-0">
            <div className="flex items-center gap-2 min-w-0">
              <i className="ri-eye-line text-primary-600 dark:text-primary-400" />
              <p className="text-sm font-semibold text-foreground-900">E-posta Önizlemesi</p>
            </div>
            <button type="button" onClick={() => setPreviewOpen(false)} className="w-8 h-8 flex items-center justify-center rounded text-foreground-500 hover:text-foreground-900 hover:bg-background-200 cursor-pointer" aria-label="Kapat">
              <i className="ri-close-line" />
            </button>
          </div>
          <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane p-4">
            <div className="max-w-2xl mx-auto rounded-lg border border-background-200/70 dark:border-background-400/30 overflow-hidden">
              <div className="bg-background-100 dark:bg-background-200/50 px-4 py-3 border-b isg-divider space-y-1">
                <p className="text-xs text-foreground-500">Gönderen</p>
                <p className="text-sm text-foreground-800">{sender.adSoyad} &lt;{connection.senderEmail}&gt;</p>
                <p className="text-xs text-foreground-500 mt-2">Alıcı</p>
                <p className="text-sm text-foreground-800 break-words">{to.join(', ') || '—'}</p>
                {showCc && cc.length > 0 && <p className="text-xs text-foreground-600 break-words">Cc: {cc.join(', ')}</p>}
                {showBcc && bcc.length > 0 && <p className="text-xs text-foreground-600 break-words">Bcc: {bcc.join(', ')}</p>}
                <p className="text-xs text-foreground-500 mt-2">Konu</p>
                <p className="text-sm font-semibold text-foreground-900 break-words">{subject || '(Konusuz)'}</p>
                {files.length > 0 && (
                  <div className="pt-2 flex flex-wrap gap-1.5">
                    {files.map((f, i) => (
                      <span key={`${f.name}-${i}`} className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-background-200/70 dark:bg-background-300/40 text-[11px] text-foreground-600">
                        <i className="ri-attachment-line" /> {f.name}
                      </span>
                    ))}
                  </div>
                )}
              </div>
              <div className="p-4 bg-background-50 dark:bg-background-100">
                <div dangerouslySetInnerHTML={{ __html: htmlForSend }} />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}