import { useCallback, useEffect, useState } from 'react';
import Card from '@/components/ui/Card';
import Button from '@/components/ui/Button';
import Input from '@/components/ui/Input';
import Select from '@/components/ui/Select';
import Badge from '@/components/ui/Badge';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import EmptyState from '@/components/ui/EmptyState';
import { useAuth } from '@/context/AuthContext';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import MailLogDetail from './MailLogDetail';
import DomainVerificationPanel from './DomainVerificationPanel';
import {
  getMailStatus,
  getOauthUrl,
  saveSmtpConnection,
  disconnectConnection,
  testConnection,
  fetchMailLogs,
  startSenderDomainVerification,
  verifySenderDomain,
} from '@/lib/mail/mailService';
import { MailServiceError, friendlyMailError } from '@/lib/mail/errors';
import { formatIstanbulDateTime } from '@/lib/dateFormat';
import type { MailConnection, MailLog, MailProviders, SenderDomainVerification, SmtpSecure } from '@/lib/mail/types';

const PROVIDER_LABEL: Record<string, string> = {
  google: 'Google / Gmail',
  microsoft: 'Microsoft 365 / Outlook',
  smtp: 'Özel SMTP',
};

/**
 * Yalnızca sunucuda GERÇEKTEN yapılandırılmış sağlayıcıları listeler.
 * Google/Microsoft OAuth client kimlik bilgileri tanımlı değilse ilgili seçenek
 * gösterilmez; Özel SMTP her zaman kullanılabilir.
 */
function buildProviderOptions(providers: MailProviders | null): { value: string; label: string }[] {
  const opts: { value: string; label: string }[] = [];
  // providers bilgisi (eski backend) yoksa geriye dönük uyumluluk için Google gösterilir.
  if (!providers || providers.google) opts.push({ value: 'google', label: 'Google / Gmail (OAuth)' });
  if (providers?.microsoft) opts.push({ value: 'microsoft', label: 'Microsoft 365 / Outlook (OAuth)' });
  opts.push({ value: 'smtp', label: 'Özel SMTP' });
  return opts;
}

const SECURE_OPTIONS = [
  { value: 'tls', label: 'STARTTLS (genellikle 587)' },
  { value: 'ssl', label: 'SSL/TLS (genellikle 465)' },
  { value: 'none', label: 'Şifrelemesiz' },
];

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** E-posta adresinden alan adını çıkarır (istemci tarafı gösterim amaçlı). */
function domainOf(email: string): string {
  const at = email.trim().toLowerCase().lastIndexOf('@');
  return at > 0 ? email.trim().toLowerCase().slice(at + 1) : '';
}

interface DomainPanelState {
  domain: string;
  recordName: string;
  recordValue: string;
  instructions: string | null;
  status: 'pending' | 'verified';
}

function statusVariant(status: MailConnection['status']) {
  if (status === 'connected') return 'success' as const;
  if (status === 'error') return 'danger' as const;
  return 'default' as const;
}

function statusLabel(status: MailConnection['status']) {
  if (status === 'connected') return 'Bağlı';
  if (status === 'error') return 'Hata';
  return 'Bağlı Değil';
}

function logStatusVariant(status: MailLog['status']) {
  if (status === 'sent') return 'success' as const;
  if (status === 'failed') return 'danger' as const;
  return 'default' as const;
}

function logStatusLabel(status: MailLog['status']) {
  if (status === 'sent') return 'Gönderildi';
  if (status === 'failed') return 'Başarısız';
  return 'Bekliyor';
}

function formatDate(iso: string | null): string {
  return formatIstanbulDateTime(iso);
}

/**
 * ORTAK "E-posta Entegrasyonu" ayarlar bileşeni (TEK KAYNAK).
 *
 * OSGB Yönetim / Uzman / Hekim panellerinin tamamı bu bileşeni tüketir.
 * Her kullanıcı YALNIZCA KENDİ bağlantısını yönetir (user-scoped; gönderen
 * backend `auth.uid()`'den çözülür). SMTP şifresi yalnızca backend'e gider,
 * asla geri okunmaz / localStorage'a yazılmaz / loglanmaz.
 */
export default function EmailIntegrationSection() {
  const { profile } = useAuth();
  const { addToast } = useToastActions();
  const { openModal } = useModalActions();

  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [connection, setConnection] = useState<MailConnection | null>(null);
  const [providers, setProviders] = useState<MailProviders | null>(null);
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);

  // Bağlıyken hesabı DEĞİŞTİRME / yeniden kurma modu. Bağlantı varken de bloklanmadan
  // sağlayıcı seçimine (ör. Özel SMTP) geçilebilmesini sağlar.
  const [setupMode, setSetupMode] = useState(false);

  // Görünüm: 'select' (sağlayıcı seç) | 'smtp' (SMTP formu) | 'oauth' (OAuth bilgilendirme)
  const [view, setView] = useState<'select' | 'smtp' | 'oauth'>('select');
  const [oauthProvider, setOauthProvider] = useState<string>('google');

  // SMTP form state
  const [senderName, setSenderName] = useState('');
  const [senderEmail, setSenderEmail] = useState('');
  const [smtpHost, setSmtpHost] = useState('');
  const [smtpPort, setSmtpPort] = useState('587');
  const [smtpSecure, setSmtpSecure] = useState<SmtpSecure>('tls');
  const [smtpUsername, setSmtpUsername] = useState('');
  const [smtpPassword, setSmtpPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [oauthConnecting, setOauthConnecting] = useState(false);
  const [testRecipient, setTestRecipient] = useState('');

  // M1 · DNS TXT domain doğrulama paneli
  const [domainPanel, setDomainPanel] = useState<DomainPanelState | null>(null);
  const [domainChecking, setDomainChecking] = useState(false);
  const [domainStarting, setDomainStarting] = useState(false);

  // Loglar
  const [logs, setLogs] = useState<MailLog[]>([]);
  const [logsLoading, setLogsLoading] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const { connection: conn, providers: prov } = await getMailStatus();
      setConnection(conn);
      setProviders(prov);
      setTestResult(null);
      if (conn) {
        setLogsLoading(true);
        fetchMailLogs(20)
          .then(setLogs)
          .catch(() => setLogs([]))
          .finally(() => setLogsLoading(false));
      } else {
        setLogs([]);
      }
    } catch (e) {
      setLoadError(friendlyMailError(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // OAuth dönüşü sonrası başarı/iptal bildirimi (callback sayfası ?eposta=... ile yönlendirir).
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const status = params.get('eposta');
    if (status === 'ok') {
      addToast({ title: 'Bağlandı', message: 'E-posta hesabınız başarıyla bağlandı.', type: 'success' });
    } else if (status === 'iptal') {
      addToast({ title: 'Bağlantı iptal edildi', message: 'Hesap bağlantısı kullanıcı tarafından iptal edildi.', type: 'error' });
    }
    if (status) {
      const url = new URL(window.location.href);
      url.searchParams.delete('eposta');
      window.history.replaceState({}, '', `${url.pathname}${url.search}`);
    }
  }, [addToast]);

  const handleProviderSelect = (value: string) => {
    setErrors({});
    setDomainPanel(null);
    if (value === 'smtp') {
      setView('smtp');
    } else {
      setOauthProvider(value);
      setView('oauth');
    }
  };

  /** Sunucudan dönen doğrulama kaydını panele yansıtır (secret içermez). */
  const applyVerification = useCallback((fallbackDomain: string, verification: unknown, status: string) => {
    const v = (verification ?? {}) as Partial<SenderDomainVerification>;
    if (!v.recordName || !v.recordValue) return;
    setDomainPanel({
      domain: String(v.domain || fallbackDomain || ''),
      recordName: String(v.recordName),
      recordValue: String(v.recordValue),
      instructions: v.instructions ? String(v.instructions) : null,
      status: status === 'verified' ? 'verified' : 'pending',
    });
  }, []);

  const handleDomainCheck = async () => {
    if (!domainPanel || domainChecking) return;
    setDomainChecking(true);
    try {
      const { status, verification } = await verifySenderDomain(domainPanel.domain);
      applyVerification(domainPanel.domain, verification, status);
      if (status === 'verified') {
        addToast({ title: 'Alan Adı Doğrulandı', message: 'Gönderen alan adı doğrulandı. Artık e-posta gönderebilirsiniz.', type: 'success' });
        await load();
      } else {
        addToast({ title: 'Henüz Doğrulanmadı', message: 'DNS TXT kaydı henüz görünmüyor. 5–30 dakika sonra tekrar deneyin.', type: 'warning' });
      }
    } catch (e) {
      const verification = e instanceof MailServiceError ? e.details?.verification : undefined;
      applyVerification(domainPanel.domain, verification, 'pending');
      addToast({ title: 'Doğrulanamadı', message: friendlyMailError(e), type: 'error' });
    } finally {
      setDomainChecking(false);
    }
  };

  const handleStartDomainVerification = async () => {
    const domain = domainOf(connection?.senderEmail ?? '');
    if (!domain || domainStarting) return;
    setDomainStarting(true);
    try {
      const { status, verification } = await startSenderDomainVerification(domain);
      applyVerification(domain, verification, status);
    } catch (e) {
      addToast({ title: 'Doğrulama başlatılamadı', message: friendlyMailError(e), type: 'error' });
    } finally {
      setDomainStarting(false);
    }
  };

  const handleSaveSmtp = async () => {
    const e: Record<string, string> = {};
    if (!senderEmail.trim() || !EMAIL_RE.test(senderEmail.trim())) e.senderEmail = 'Geçerli bir gönderici e-posta girin.';
    if (!smtpHost.trim()) e.smtpHost = 'SMTP sunucu adresi zorunludur.';
    const portNum = Number(smtpPort);
    if (!Number.isInteger(portNum) || portNum < 1 || portNum > 65535) e.smtpPort = 'Port 1 ile 65535 arasında olmalıdır.';
    if (!smtpUsername.trim()) e.smtpUsername = 'SMTP kullanıcı adı zorunludur.';
    if (!smtpPassword) e.smtpPassword = 'SMTP şifresi zorunludur.';
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    if (saving) return;

    setSaving(true);
    try {
      await saveSmtpConnection({
        senderName: senderName.trim(),
        senderEmail: senderEmail.trim(),
        smtpHost: smtpHost.trim(),
        smtpPort: portNum,
        smtpSecure,
        smtpUsername: smtpUsername.trim(),
        smtpPassword,
      });
      setSmtpPassword('');
      addToast({ title: 'Bağlantı Kuruldu', message: 'Özel SMTP bağlantınız başarıyla kaydedildi.', type: 'success' });
      await load();
      setView('select');
      setSetupMode(false);
    } catch (err) {
      // M1 · Alan adı doğrulanmadıysa sunucu TXT kaydını döner → paneli göster.
      const verification = err instanceof MailServiceError ? err.details?.verification : undefined;
      if (verification) applyVerification(domainOf(senderEmail), verification, 'pending');
      addToast({ title: 'Bağlantı kurulamadı', message: friendlyMailError(err), type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  const handleTest = async () => {
    if (testing) return;
    setTesting(true);
    setTestResult(null);
    const result = await testConnection(testRecipient.trim() || undefined);
    setTesting(false);
    const message = result.ok ? 'E-posta bağlantısı başarıyla test edildi. Test mesajı gönderildi.' : result.message;
    setTestResult({ ok: result.ok, message });
    if (result.ok) {
      addToast({ title: 'Bağlantı Testi', message: 'E-posta bağlantısı başarıyla test edildi.', type: 'success' });
    } else {
      addToast({ title: 'Bağlantı Testi Başarısız', message: result.message, type: 'error' });
    }
    await load();
  };

  const handleDisconnect = async () => {
    if (testing) return;
    try {
      await disconnectConnection();
      addToast({ title: 'Bağlantı Kesildi', message: 'E-posta bağlantınız kaldırıldı.', type: 'success' });
      setConnection(null);
      setLogs([]);
      setDomainPanel(null);
      setView('select');
      setSetupMode(false);
    } catch (err) {
      addToast({ title: 'İşlem başarısız', message: friendlyMailError(err), type: 'error' });
    }
  };

  const handleOauthConnect = async (provider?: string) => {
    if (oauthConnecting) return;
    const p = provider || oauthProvider;
    setOauthConnecting(true);
    try {
      const { authorizeUrl } = await getOauthUrl(p as 'google' | 'microsoft');
      window.location.assign(authorizeUrl);
    } catch (e) {
      setOauthConnecting(false);
      addToast({ title: 'Bağlanılamadı', message: friendlyMailError(e), type: 'error' });
    }
  };

  const openLogDetail = (log: MailLog) => {
    openModal({
      dedupeKey: `mail-log:${log.id}`,
      title: 'Gönderim Detayı',
      headerIcon: <i className="ri-mail-open-line text-primary-600 dark:text-primary-400" />,
      description: log.subject || '(Konusuz)',
      size: 'md',
      height: 'auto',
      showFooter: false,
      content: <MailLogDetail log={log} />,
    });
  };

  if (loading) {
    return (
      <Card padding="lg">
        <Loading text="E-posta bağlantısı yükleniyor..." />
      </Card>
    );
  }

  if (loadError) {
    return (
      <Card padding="lg">
        <ErrorState message={loadError} onRetry={() => void load()} />
      </Card>
    );
  }

  // ---------- BAĞLI DURUM ----------
  if (connection && !setupMode) {
    // M1 · SMTP gönderen alan adı doğrulanmamışsa gönderim sunucu tarafında
    // engellidir; arayüz de bunu yansıtır ve test düğmesini kapatır.
    const sendingBlocked = connection.provider === 'smtp' && connection.senderDomainVerified === false;
    return (
      <div className="space-y-4">
        <Card
          title="E-posta Entegrasyonu"
          subtitle="Bağlı e-posta hesabınız ve gönderim durumunuz."
          padding="md"
          headerAction={<Badge variant={statusVariant(connection.status)}>{statusLabel(connection.status)}</Badge>}
        >
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
              <div className="space-y-1">
                <p className="text-xs font-medium text-foreground-500 uppercase tracking-wide">Sağlayıcı</p>
                <p className="text-sm text-foreground-800 flex items-center gap-2">
                  <i className="ri-mail-send-line text-primary-500" />
                  {PROVIDER_LABEL[connection.provider ?? ''] ?? connection.provider ?? '—'}
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-xs font-medium text-foreground-500 uppercase tracking-wide">Gönderen E-posta</p>
                <p className="text-sm text-foreground-800 break-words">{connection.senderEmail || '—'}</p>
              </div>
              {connection.senderName && (
                <div className="space-y-1">
                  <p className="text-xs font-medium text-foreground-500 uppercase tracking-wide">Gönderen Adı</p>
                  <p className="text-sm text-foreground-800">{connection.senderName}</p>
                </div>
              )}
              {connection.provider === 'smtp' && connection.smtpHost && (
                <div className="space-y-1">
                  <p className="text-xs font-medium text-foreground-500 uppercase tracking-wide">SMTP Sunucu</p>
                  <p className="text-sm text-foreground-800">{connection.smtpHost}{connection.smtpPort ? `:${connection.smtpPort}` : ''}</p>
                </div>
              )}
            </div>

            {sendingBlocked && !domainPanel && (
              <div className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg bg-warning-50 border border-warning-300/50 p-3">
                <div className="flex items-start gap-3 flex-1">
                  <i className="ri-shield-keyhole-line text-warning-700 text-lg mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-foreground-800">Gönderen alan adı doğrulanmadı</p>
                    <p className="text-xs text-foreground-600">
                      <strong>{domainOf(connection.senderEmail ?? '')}</strong> alan adı için DNS TXT doğrulaması
                      gerekiyor. Doğrulama tamamlanana kadar bu bağlantı üzerinden e-posta gönderilemez.
                    </p>
                  </div>
                </div>
                <Button
                  variant="secondary"
                  size="sm"
                  isLoading={domainStarting}
                  onClick={() => void handleStartDomainVerification()}
                  leftIcon={<i className="ri-shield-check-line" />}
                  className="whitespace-nowrap"
                >
                  Alan Adını Doğrula
                </Button>
              </div>
            )}

            {domainPanel && (
              <DomainVerificationPanel
                domain={domainPanel.domain}
                recordName={domainPanel.recordName}
                recordValue={domainPanel.recordValue}
                instructions={domainPanel.instructions}
                status={domainPanel.status}
                checking={domainChecking}
                onCheck={() => void handleDomainCheck()}
                onDismiss={() => setDomainPanel(null)}
              />
            )}

            {connection.reauthorizationRequired && (
              <div className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg bg-warning-50 dark:bg-warning-100/20 border border-warning-300/50 p-3">
                <div className="flex items-start gap-3 flex-1">
                  <i className="ri-alert-line text-warning-700 text-lg mt-0.5" />
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-foreground-800">Yeniden yetkilendirme gerekiyor</p>
                    <p className="text-xs text-foreground-600">
                      Bu bağlantının erişim izni süresi doldu. Yeniden bağlanarak e-posta gönderimini sürdürebilirsiniz.
                    </p>
                  </div>
                </div>
                <Button
                  variant="secondary"
                  size="sm"
                  isLoading={oauthConnecting}
                  onClick={() => handleOauthConnect(connection.provider ?? undefined)}
                  leftIcon={<i className="ri-link" />}
                >
                  Yeniden Bağla
                </Button>
              </div>
            )}

            <div className="space-y-2">
              <p className="text-xs font-medium text-foreground-500 uppercase tracking-wide">Test E-postası Gönder</p>
              <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                <div className="flex-1">
                  <Input
                    type="email"
                    value={testRecipient}
                    onChange={(e) => setTestRecipient(e.target.value)}
                    placeholder={connection.senderEmail || 'test@example.com'}
                    leftIcon={<i className="ri-mail-line" />}
                  />
                </div>
                <Button
                  variant="secondary"
                  size="sm"
                  isLoading={testing}
                  disabled={sendingBlocked}
                  onClick={handleTest}
                  leftIcon={<i className="ri-flashlight-line" />}
                  className="whitespace-nowrap"
                >
                  Test Maili Gönder
                </Button>
              </div>
              {testResult && (
                <div
                  className={`flex items-start gap-2 rounded-lg border p-2.5 ${
                    testResult.ok
                      ? 'bg-success-50 dark:bg-success-500/10 border-success-300/50'
                      : 'bg-danger-50 dark:bg-danger-500/10 border-danger-300/50'
                  }`}
                >
                  <i
                    className={`${testResult.ok ? 'ri-checkbox-circle-line text-success-600' : 'ri-error-warning-line text-danger-600'} mt-0.5 flex-shrink-0`}
                  />
                  <p className="text-xs text-foreground-700">{testResult.message}</p>
                </div>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              <Button
                variant="outline"
                size="sm"
                onClick={() => { setView('select'); setSetupMode(true); }}
                leftIcon={<i className="ri-refresh-line" />}
              >
                Değiştir
              </Button>
              <Button
                variant="danger"
                size="sm"
                onClick={handleDisconnect}
                leftIcon={<i className="ri-link-unlink" />}
              >
                Bağlantıyı Kes
              </Button>
            </div>
          </div>
        </Card>

        <Card title="Son Gönderimler" subtitle="Hesabınızdan yapılan son e-posta gönderim kayıtları." padding="md">
          {logsLoading ? (
            <Loading text="Kayıtlar yükleniyor..." />
          ) : logs.length === 0 ? (
            <EmptyState
              icon="ri-mail-line"
              title="Gönderim kaydı yok"
              description="Henüz bu hesaptan e-posta gönderilmedi."
            />
          ) : (
            <ul className="divide-y divide-background-200 dark:divide-background-400/30">
              {logs.map((l) => (
                <li key={l.id}>
                  <button
                    type="button"
                    onClick={() => openLogDetail(l)}
                    className="w-full text-left py-2.5 flex flex-col sm:flex-row sm:items-center gap-1.5 sm:gap-3 rounded-md px-2 -mx-2 hover:bg-background-100 dark:hover:bg-background-200/50 transition-colors cursor-pointer"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-foreground-800 truncate">{l.subject || '(Konusuz)'}</p>
                      <p className="text-xs text-foreground-500 truncate">
                        {l.recipientTo || '—'} · {formatDate(l.createdAt)}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Badge variant={logStatusVariant(l.status)} size="sm">{logStatusLabel(l.status)}</Badge>
                      <i className="ri-arrow-right-s-line text-foreground-400" />
                    </div>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    );
  }

  // ---------- BAĞLI DEĞİL: SAĞLAYICI SEÇ / SMTP FORM / OAuth BİLGİ ----------
  if (view === 'oauth') {
    return (
      <Card
        title="E-posta Entegrasyonu"
        subtitle={`${PROVIDER_LABEL[oauthProvider]} hesabınızı bağlayın.`}
        padding="md"
      >
        <div className="space-y-4 max-w-xl">
          <div className="flex items-start gap-3 rounded-lg bg-background-100 dark:bg-background-200 border border-background-300/40 dark:border-background-400/40 p-4">
            <i className="ri-information-line text-secondary-600 text-lg mt-0.5" />
            <div className="space-y-1">
              <p className="text-sm font-medium text-foreground-800">Güvenli OAuth bağlantısı</p>
              <p className="text-sm text-foreground-600">
                Bağlantı {PROVIDER_LABEL[oauthProvider]}'un kendi oturum açma ekranında kurulur.
                Uygulama şifreniz istenmez; erişim token'ları yalnızca sunucuda güvenli şekilde saklanır.
              </p>
            </div>
          </div>

          <Button
            variant="primary"
            size="md"
            isLoading={oauthConnecting}
            onClick={() => handleOauthConnect()}
            leftIcon={<i className="ri-link" />}
          >
            {oauthProvider === 'google' ? 'Google hesabını bağla' : 'Microsoft hesabını bağla'}
          </Button>

          <Button variant="ghost" size="sm" onClick={() => setView('select')} leftIcon={<i className="ri-arrow-left-line" />}>
            Sağlayıcı Seçimine Dön
          </Button>
        </div>
      </Card>
    );
  }

  if (view === 'smtp') {
    return (
      <Card
        title="Özel SMTP Bağlantısı"
        subtitle="Kurumsal e-posta sunucunuzun bilgilerini girin. Şifreniz yalnızca güvenli şekilde sunucuda saklanır, tarayıcıda tutulmaz."
        padding="md"
      >
        <div className="space-y-4 max-w-xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="Gönderici Adı"
              value={senderName}
              onChange={(e) => setSenderName(e.target.value)}
              placeholder="Ahmet Yılmaz - İş Güvenliği Uzmanı"
              leftIcon={<i className="ri-user-line" />}
            />
            <Input
              label="Gönderici E-posta"
              type="email"
              required
              value={senderEmail}
              onChange={(e) => { setSenderEmail(e.target.value); setErrors((p) => ({ ...p, senderEmail: '' })); }}
              error={errors.senderEmail}
              placeholder="ahmet@example.com"
              leftIcon={<i className="ri-mail-line" />}
            />
            <Input
              label="SMTP Sunucu"
              required
              value={smtpHost}
              onChange={(e) => { setSmtpHost(e.target.value); setErrors((p) => ({ ...p, smtpHost: '' })); }}
              error={errors.smtpHost}
              placeholder="smtp.example.com"
              leftIcon={<i className="ri-server-line" />}
            />
            <div className="grid grid-cols-2 gap-3">
              <Input
                label="SMTP Port"
                required
                type="number"
                value={smtpPort}
                onChange={(e) => { setSmtpPort(e.target.value); setErrors((p) => ({ ...p, smtpPort: '' })); }}
                error={errors.smtpPort}
                placeholder="587"
              />
              <Select
                label="Güvenlik"
                options={SECURE_OPTIONS}
                value={smtpSecure}
                onChange={(e) => setSmtpSecure(e.target.value as SmtpSecure)}
              />
            </div>
            <Input
              label="SMTP Kullanıcı Adı"
              required
              value={smtpUsername}
              onChange={(e) => { setSmtpUsername(e.target.value); setErrors((p) => ({ ...p, smtpUsername: '' })); }}
              error={errors.smtpUsername}
              placeholder="kullanici@example.com"
              leftIcon={<i className="ri-user-3-line" />}
            />
            <Input
              label="SMTP Şifresi / Uygulama Parolası"
              type="password"
              required
              value={smtpPassword}
              onChange={(e) => { setSmtpPassword(e.target.value); setErrors((p) => ({ ...p, smtpPassword: '' })); }}
              error={errors.smtpPassword}
              helpText="Şifre yalnızca sunucuda saklanır ve asla geri gösterilmez."
              leftIcon={<i className="ri-lock-line" />}
            />
          </div>

          {domainPanel && (
            <DomainVerificationPanel
              domain={domainPanel.domain}
              recordName={domainPanel.recordName}
              recordValue={domainPanel.recordValue}
              instructions={domainPanel.instructions}
              status={domainPanel.status}
              checking={domainChecking}
              onCheck={() => void handleDomainCheck()}
              onDismiss={() => setDomainPanel(null)}
            />
          )}

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <Button
              variant="primary"
              size="sm"
              isLoading={saving}
              onClick={handleSaveSmtp}
              leftIcon={<i className="ri-link" />}
            >
              Bağla
            </Button>
            <Button variant="ghost" size="sm" onClick={() => setView('select')}>
              Vazgeç
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  // ---------- SAĞLAYICI SEÇ ----------
  return (
    <Card
      title="E-posta Entegrasyonu"
      subtitle="Gönderimleriniz için kullanılacak e-posta hesabını bağlayın. Bu bağlantı yalnızca sizin hesabınıza aittir."
      padding="md"
    >
      <div className="space-y-3 max-w-xl">
        {connection && (
          <div className="flex items-center justify-between gap-2 rounded-lg bg-background-100 dark:bg-background-200 border border-background-300/40 dark:border-background-400/40 p-3">
            <div className="flex items-start gap-2 min-w-0">
              <i className="ri-information-line text-secondary-600 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-foreground-600">
                Şu an <strong>{connection.senderEmail}</strong> hesabı bağlı. Yeni bir sağlayıcı seçip bağlandığınızda
                mevcut bağlantı değiştirilir.
              </p>
            </div>
            <button
              type="button"
              onClick={() => { setSetupMode(false); setView('select'); }}
              className="text-xs font-medium text-primary-600 dark:text-primary-400 hover:underline whitespace-nowrap cursor-pointer flex-shrink-0"
            >
              Vazgeç
            </button>
          </div>
        )}
        <Select
          label="Sağlayıcı"
          placeholder="Sağlayıcı seçin"
          options={buildProviderOptions(providers)}
          value=""
          onChange={(e) => handleProviderSelect(e.target.value)}
        />
        <p className="text-xs text-foreground-500">
          Google / Gmail bağlantısı OAuth ile kurulur (uygulama şifreniz istenmez);
          kurumsal özel mail sunucuları için Özel SMTP seçeneğini kullanın.
        </p>
        {providers && !providers.google && (
          <div className="flex items-start gap-2 rounded-lg bg-background-100 dark:bg-background-200 border border-background-300/40 dark:border-background-400/40 p-3">
            <i className="ri-information-line text-secondary-600 mt-0.5" />
            <p className="text-xs text-foreground-600">
              Kurumsal özel mail sunucunuzu (Özel SMTP) kullanabilirsiniz. Google ile bağlanma şu anda
              kullanılamıyor.
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}