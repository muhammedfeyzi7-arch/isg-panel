import { useState, useEffect } from 'react';
import Input from '@/components/ui/Input';
import Button from '@/components/ui/Button';
import AvatarUpload from '@/components/ui/AvatarUpload';
import TabBar from '@/components/ui/TabBar';
import { useAdminProfile } from '@/context/AdminProfileContext';
import { useToastActions } from '@/hooks/useToast';
import { useModalActions } from '@/hooks/useModal';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import { uploadAvatar, removeAvatarFile, removeAvatarPath, logProfileUpdated } from '@/lib/settingsService';
import PasswordChangeForm from '@/components/feature/auth/PasswordChangeForm';

type Sekme = 'profil' | 'sifre';

interface ProfileModalProps {
  onClose: () => void;
  /** Modal id'sini tutan ref — kaydedilmemiş değişiklik uyarısını bağlamak için. */
  modalIdRef: React.MutableRefObject<string>;
  /** Açılışta aktif olacak sekme. Varsayılan: profil bilgileri. */
  initialTab?: Sekme;
}

export default function ProfileModal({ onClose, modalIdRef, initialTab = 'profil' }: ProfileModalProps) {
  const { profile, fullName, updateProfile } = useAdminProfile();
  const { addToast } = useToastActions();
  const { setModalUnsaved } = useModalActions();
  const [aktifSekme, setAktifSekme] = useState<Sekme>(initialTab);

  // Profil form state (draft — kaydedene kadar global state'e yazılmaz).
  const [ad, setAd] = useState(profile.ad);
  const [soyad, setSoyad] = useState(profile.soyad);
  const [avatar, setAvatar] = useState<string | null>(profile.avatar || null);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [profilErrors, setProfilErrors] = useState<{ ad?: string; soyad?: string }>({});
  const [profilLoading, setProfilLoading] = useState(false);
  const [photoBusy, setPhotoBusy] = useState(false);

  // Kaydedilmemiş değişiklik algılama: draft, global profile'dan farklıysa modal
  // motoru "unsaved" olarak işaretlenir → X / küçült anında Shared Confirmation çıkar.
  const dirty =
    aktifSekme === 'profil' &&
    (ad.trim() !== profile.ad ||
      soyad.trim() !== profile.soyad ||
      (avatar || null) !== (profile.avatar || null));

  useEffect(() => {
    if (modalIdRef.current) {
      setModalUnsaved(modalIdRef.current, dirty);
    }
  }, [dirty, modalIdRef, setModalUnsaved]);

  const handleProfilKaydet = async () => {
    const errors: { ad?: string; soyad?: string } = {};
    if (!ad.trim()) errors.ad = 'Ad zorunludur.';
    if (!soyad.trim()) errors.soyad = 'Soyad zorunludur.';
    setProfilErrors(errors);
    if (Object.keys(errors).length > 0) return;
    if (photoBusy || profilLoading) return;

    setProfilLoading(true);
    let uploadedPath: string | null = null;
    try {
      let nextAvatar = profile.avatar;
      if (avatarFile) {
        const { url, path } = await uploadAvatar(avatarFile);
        uploadedPath = path;
        nextAvatar = url;
      } else if (avatar === null && profile.avatar) {
        nextAvatar = '';
        await removeAvatarFile(profile.avatar).catch(() => {});
      }
      await updateProfile({ ad: ad.trim(), soyad: soyad.trim(), avatar: nextAvatar });
      // Değiştirilmişse eski avatar dosyasını temizle (orphan birikmesin).
      if (avatarFile && profile.avatar && profile.avatar !== nextAvatar) {
        await removeAvatarFile(profile.avatar).catch(() => {});
      }
      await logProfileUpdated().catch(() => {});
      addToast({ title: 'Profil Güncellendi', message: 'Profil bilgileriniz başarıyla kaydedildi.', type: 'success' });
      onClose();
    } catch (err) {
      // Storage'a yüklendi ama DB güncellemesi başarısız olduysa orphan dosyayı temizle.
      if (uploadedPath) await removeAvatarPath(uploadedPath).catch(() => {});
      addToast({ title: 'Güncelleme başarısız', message: friendlyErrorMessage(err, 'Lütfen tekrar deneyin.'), type: 'error' });
    } finally {
      setProfilLoading(false);
    }
  };

  return (
    <div className="space-y-3">
      {/* Sekmeler — ortak TabBar */}
      <TabBar
        items={[
          { key: 'profil', label: 'Profil Bilgileri', icon: 'ri-user-line' },
          { key: 'sifre', label: 'Şifre Değiştir', icon: 'ri-lock-line' },
        ]}
        active={aktifSekme}
        onChange={(key) => setAktifSekme(key as Sekme)}
      />

      {aktifSekme === 'profil' && (
        <div className="space-y-3">
          {/* Profil fotoğrafı — Shared Avatar Upload (dosyadan, URL import yok) */}
          <AvatarUpload
            label="Profil Fotoğrafı"
            src={avatar}
            name={ad.trim() && soyad.trim() ? `${ad.trim()} ${soyad.trim()}` : fullName}
            onChange={(dataUrl) => setAvatar(dataUrl)}
            onFileSelect={setAvatarFile}
            onError={(message) =>
              addToast({ title: 'Fotoğraf Yüklenemedi', message, type: 'error' })
            }
            onBusyChange={setPhotoBusy}
            disabled={profilLoading}
          />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Input
              label="Ad"
              required
              value={ad}
              onChange={(e) => { setAd(e.target.value); setProfilErrors((p) => ({ ...p, ad: '' })); }}
              error={profilErrors.ad}
            />
            <Input
              label="Soyad"
              required
              value={soyad}
              onChange={(e) => { setSoyad(e.target.value); setProfilErrors((p) => ({ ...p, soyad: '' })); }}
              error={profilErrors.soyad}
            />
          </div>
          <Input
            label="E-posta"
            type="email"
            value={profile.email}
            readOnly
          />

          <div className="flex justify-end gap-2 pt-2">
            <Button variant="ghost" size="sm" onClick={onClose} disabled={profilLoading}>İptal</Button>
            <Button
              variant="primary"
              size="sm"
              isLoading={profilLoading}
              onClick={handleProfilKaydet}
              disabled={photoBusy}
              leftIcon={<i className="ri-save-line" />}
            >
              Kaydet
            </Button>
          </div>
        </div>
      )}

      {aktifSekme === 'sifre' && (
        <PasswordChangeForm onSuccess={onClose} />
      )}
    </div>
  );
}