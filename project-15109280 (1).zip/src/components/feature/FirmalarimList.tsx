import { useCallback, useMemo } from 'react';
import useSWR from 'swr';
import PageHeader from '@/components/ui/PageHeader';
import Badge from '@/components/ui/Badge';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import Loading from '@/components/ui/Loading';
import SharedListCard, { ListCardBadge } from '@/components/ui/SharedListCard';
import {
  fetchUzmanHekimFirmalar,
  type FirmaAtamaData,
  type AtamaDurum,
} from '@/lib/assignmentService';
import { tehlikeSinifiLabel } from '@/lib/firmaService';
import { useModalActions } from '@/hooks/useModal';
import FirmaDetayModal from '@/components/feature/firma-detay/FirmaDetayModal';

type BadgeVariant = 'default' | 'success' | 'warning' | 'danger' | 'info' | 'primary' | 'secondary' | 'accent';

const TR_MONTHS = ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'];

function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (m) return `${Number(m[3])} ${TR_MONTHS[Number(m[2]) - 1]} ${m[1]}`;
  return '—';
}

// Atama durumu backend (`uzman_hekim_firma_list`) tarafından hesaplanır; UI yalnızca gösterir.
function durumLabel(d: AtamaDurum): string {
  switch (d) {
    case 'aktif': return 'Aktif';
    case 'gelecek': return 'Yaklaşan';
    case 'suresi_doldu': return 'Süresi Doldu';
    case 'pasif': return 'Pasif';
    default: return '—';
  }
}

function durumVariant(d: AtamaDurum): BadgeVariant {
  switch (d) {
    case 'aktif': return 'success';
    case 'gelecek': return 'info';
    case 'suresi_doldu': return 'warning';
    case 'pasif': return 'default';
    default: return 'default';
  }
}

interface FirmalarimListProps {
  role: 'uzman' | 'hekim';
}

export default function FirmalarimList({ role }: FirmalarimListProps) {
  const { openModal, closeModal } = useModalActions();
  const { data: allRows, error, isLoading, mutate } = useSWR<FirmaAtamaData[]>(
    'uzman-hekim-firmalar',
    fetchUzmanHekimFirmalar,
  );
  const rows = useMemo(() => (allRows ?? []).filter((f) => f.durum === 'aktif'), [allRows]);

  const handleOpenDetail = useCallback(
    (row: FirmaAtamaData) => {
      const id = openModal({
        title: row.firmaUnvan,
        description: tehlikeSinifiLabel(row.tehlikeSinifi),
        variant: 'detail',
        width: 1400,
        minWidth: 1080,
        minHeight: 680,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        content: <FirmaDetayModal firmaId={row.firmaId} role={role} onClose={() => closeModal(id)} />,
      });
    },
    [openModal, closeModal, role],
  );

  const columns: TableColumn<FirmaAtamaData>[] = [
    {
      key: 'firma',
      header: 'Firma',
      render: (row) => (
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-lg bg-background-200 dark:bg-background-300/40 flex items-center justify-center flex-shrink-0">
            <i className="ri-briefcase-4-line text-foreground-500 text-sm" />
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-foreground-800 truncate">{row.firmaUnvan}</p>
            <p className="text-xs text-foreground-500 truncate">{tehlikeSinifiLabel(row.tehlikeSinifi)}</p>
          </div>
        </div>
      ),
    },
    {
      key: 'turu',
      header: 'Atama Türü',
      render: (row) => (
        <Badge variant={row.atamaTuru === 'uzman' ? 'info' : 'accent'}>{row.atamaTuruLabel}</Badge>
      ),
    },
    {
      key: 'baslangic',
      header: 'Başlangıç',
      render: (row) => <span className="text-sm text-foreground-600">{formatDate(row.baslangicTarihi)}</span>,
    },
    {
      key: 'bitis',
      header: 'Bitiş',
      render: (row) => (
        <span className="text-sm text-foreground-600">{row.bitisTarihi ? formatDate(row.bitisTarihi) : 'Süresiz'}</span>
      ),
    },
    {
      key: 'durum',
      header: 'Durum',
      render: (row) => <Badge variant={durumVariant(row.durum)}>{durumLabel(row.durum)}</Badge>,
    },
  ];

  return (
    <div className="isg-page">
      <PageHeader
        title="Firmalarım"
        subtitle="Yalnızca size atanmış firmalar — OSGB'nin tüm firmaları değil."
        className="flex-shrink-0"
      />

      <div className="isg-card flex flex-col p-3">
        {isLoading ? (
          <div className="flex justify-center py-16">
            <Loading size="lg" text="Firmalar yükleniyor..." />
          </div>
        ) : error ? (
          <ErrorState message={error instanceof Error ? error.message : 'Veriler yüklenemedi. Lütfen tekrar deneyin.'} onRetry={() => mutate()} />
        ) : rows.length === 0 ? (
          <EmptyState
            icon="ri-briefcase-line"
            title="Henüz bir firmaya atanmadınız"
            description="Yöneticiniz sizi bir firmaya atadığında burada görünecek."
          />
        ) : (
          <>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs text-foreground-500">
                Toplam <span className="font-semibold text-foreground-800">{rows.length}</span> firma
              </p>
            </div>
            <div className="overflow-x-auto">
              <Table
                data={rows}
                columns={columns}
                keyExtractor={(r) => r.firmaId}
                onRowClick={handleOpenDetail}
                mobileCardRenderer={(row) => (
                  <SharedListCard
                    recordNo={`#${row.firmaId.slice(0, 8).toUpperCase()}`}
                    icon="ri-briefcase-4-line"
                    iconBg="bg-primary-50 dark:bg-primary-500/20"
                    iconColor="text-primary-600 dark:text-primary-400"
                    title={row.firmaUnvan}
                    description={tehlikeSinifiLabel(row.tehlikeSinifi)}
                    badges={[
                      <ListCardBadge key="durum" variant={durumVariant(row.durum)}>
                        {durumLabel(row.durum)}
                      </ListCardBadge>,
                    ]}
                    metadata={[
                      { label: 'Tür', value: row.atamaTuruLabel },
                      { label: 'Başlangıç', value: formatDate(row.baslangicTarihi) },
                      { label: 'Bitiş', value: row.bitisTarihi ? formatDate(row.bitisTarihi) : 'Süresiz' },
                    ]}
                    showChevron={false}
                    onClick={() => handleOpenDetail(row)}
                  />
                )}
              />
            </div>
          </>
        )}
      </div>
    </div>
  );
}