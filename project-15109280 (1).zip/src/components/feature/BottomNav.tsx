import { useNavigate, useLocation } from 'react-router-dom';
import { useMemo } from 'react';
import { useBottomSheet } from '@/hooks/useBottomSheet';
import { Z_LAYERS } from '@/utils/layers';
import { getPanelFromPath, PANEL_NAV_CONFIG, type PanelNavItem } from './panelNavigation';
import { prefetchRoute } from '@/lib/routePrefetch';
import { useMesajlasma } from '@/context/MesajlasmaContext';

interface PanelConfig {
  main: PanelNavItem[];
  more: PanelNavItem[];
}

/**
 * Global Shared Bottom Navigation — mobilde tek navigasyon.
 * Daima 5 item: 4 ana sekme + "Daha Fazla".
 * "Daha Fazla" tıklanınca Global Bottom Sheet Engine açılır.
 * Desktop'ta gizlenir (lg:hidden).
 */
export default function BottomNav() {
  const navigate = useNavigate();
  const location = useLocation();
  const { isOpen, options, openSheet, closeSheet } = useBottomSheet();
  const { unreadCount } = useMesajlasma();

  const panel = getPanelFromPath(location.pathname);
  const config = useMemo<PanelConfig>(() => {
    const items = PANEL_NAV_CONFIG[panel] || PANEL_NAV_CONFIG.admin;
    // Mesajlaşma sekmesinin rozeti her zaman GERÇEK okunmamış mesaj sayısıdır.
    const withBadge = items.map((it) =>
      it.label === 'Mesajlaşma' ? { ...it, badge: unreadCount > 0 ? unreadCount : undefined } : it,
    );
    return {
      main: withBadge.slice(0, 4),
      more: withBadge.slice(4),
    };
  }, [panel, unreadCount]);

  const isMainActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const isMoreOpen = isOpen && options?.title === 'Daha Fazla';

  /** "Daha Fazla" aktif mi? — Sistem Logları veya Ayarlar açıksa veya sheet açıksa */
  const isMoreActive = useMemo(() => {
    if (isMoreOpen) return true;
    return config.more.some((item) => {
      if (item.path === '/') return location.pathname === '/';
      return location.pathname.startsWith(item.path);
    });
  }, [isMoreOpen, config.more, location.pathname]);

  const handleNav = (path: string) => {
    navigate(path);
    closeSheet();
  };

  const handleMoreClick = () => {
    if (isMoreOpen) {
      closeSheet();
      return;
    }
    openSheet({
      title: 'Daha Fazla',
      showClose: true,
      content: (
        <div className="space-y-1">
          {config.more.map((item) => {
            const active = isMainActive(item.path);
            return (
              <button
                key={item.path}
                onClick={() => handleNav(item.path)}
                onTouchStart={() => prefetchRoute(item.path)}
                className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-colors cursor-pointer ${
                  active
                    ? 'text-primary-600 bg-primary-500/10'
                    : 'text-foreground-700 dark:text-foreground-300 hover:bg-background-200 dark:hover:bg-background-300/40'
                }`}
              >
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${active ? 'bg-primary-100 dark:bg-primary-500/20' : 'bg-background-200 dark:bg-background-300/50'}`}>
                  <i className={`${item.icon} text-lg ${active ? 'text-primary-600' : 'text-foreground-500'}`} />
                </div>
                <span className="flex-1 text-sm font-medium">{item.label}</span>
                {item.badge !== undefined && item.badge > 0 && (
                  <span className="min-w-[16px] h-4 flex items-center justify-center rounded-full text-[10px] font-bold text-inverse px-1 bg-danger-500">
                    {item.badge > 99 ? '99+' : item.badge}
                  </span>
                )}
                <i className={`ri-arrow-right-s-line text-lg ${active ? 'text-primary-400' : 'text-foreground-400'}`} />
              </button>
            );
          })}
        </div>
      ),
    });
  };

  return (
    <nav
      className="isg-bottom-nav fixed bottom-0 left-0 right-0 lg:hidden bg-background-100 dark:bg-background-200 border-t border-background-300/70 dark:border-background-400/30 select-none"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)', zIndex: Z_LAYERS.bottomNav }}
    >
      <div className="flex items-center h-12">
        {/* 4 ana item */}
        {config.main.map((item) => {
          const active = isMainActive(item.path);
          return (
            <button
              key={item.path}
              onClick={() => handleNav(item.path)}
              onTouchStart={() => prefetchRoute(item.path)}
              className="flex flex-col items-center justify-center gap-0.5 flex-1 h-full touch-manipulation cursor-pointer"
              aria-label={item.label}
            >
              <div
                className={`relative flex items-center justify-center w-10 h-8 rounded-xl transition-colors ${active ? 'bg-primary-500/10' : ''}`}
              >
                <i className={`${item.icon} text-xl leading-none ${active ? 'text-primary-600' : 'text-foreground-500'}`} />
                {item.badge !== undefined && item.badge > 0 && (
                  <span
                    className={`absolute -top-1 -right-1 min-w-[16px] h-4 flex items-center justify-center rounded-full text-[10px] font-bold text-inverse px-1 ${item.badgeColor || 'bg-primary-500'}`}
                  >
                    {item.badge > 99 ? '99+' : item.badge}
                  </span>
                )}
              </div>
              <span className={`text-[10px] font-medium leading-tight whitespace-nowrap ${active ? 'text-primary-600' : 'text-foreground-500'}`}>
                {item.label}
              </span>
            </button>
          );
        })}

        {/* 5. item — Daha Fazla */}
        <div className="flex-1 relative h-full">
          <button
            onClick={handleMoreClick}
            className="flex flex-col items-center justify-center gap-0.5 w-full h-full touch-manipulation cursor-pointer"
            aria-label="Daha Fazla"
            aria-expanded={isMoreOpen}
          >
            <div
              className={`relative flex items-center justify-center w-10 h-8 rounded-xl transition-colors ${(isMoreOpen || isMoreActive) ? 'bg-primary-500/10' : ''}`}
            >
              <i className={`ri-more-line text-xl leading-none ${(isMoreOpen || isMoreActive) ? 'text-primary-600' : 'text-foreground-500'}`} />
            </div>
            <span className={`text-[10px] font-medium leading-tight whitespace-nowrap ${(isMoreOpen || isMoreActive) ? 'text-primary-600' : 'text-foreground-500'}`}>
              Daha Fazla
            </span>
          </button>
        </div>
      </div>
    </nav>
  );
}