import { useCallback, useEffect, useRef, useState } from 'react';
import Card from '@/components/ui/Card';
import Input from '@/components/ui/Input';
import PhoneInput from '@/components/ui/PhoneInput';
import Button from '@/components/ui/Button';
import Badge from '@/components/ui/Badge';
import ProvinceSelect from '@/components/ui/ProvinceSelect';
import DistrictSelect from '@/components/ui/DistrictSelect';
import Loading from '@/components/ui/Loading';
import ErrorState from '@/components/ui/ErrorState';
import EmptyState from '@/components/ui/EmptyState';
import { useAuth } from '@/context/AuthContext';
import { useToastActions } from '@/hooks/useToast';
import { friendlyErrorMessage, humanizeTechError } from '@/lib/errorMessages';
import {
  fetchKurumsalOsgb,
  updateKurumsalOsgb,
  uploadOsgbLogo,
  removeOsgbLogo,
  type KurumsalOsgb,
} from '@/lib/osgbService';

const LOGO_MIMES = ['image/jpeg', 'image/png', 'image/webp'];
const LOGO_ACCEPT = 'image/jpeg,image/png,image/webp';
const LOGO_MAX_SIZE = 3 * 1024 * 1024;

function friendlyError(e: unknown): string {
  const raw = humanizeTechError(e);
  if (raw.includes('FORBIDDEN') || raw.includes('permission') || raw.includes('row-level security') || raw.includes('policy')) {
    return 'Bu işleme erişim yetkiniz yok.';
  }
  return raw || 'İşlem tamamlanamadı. Lütfen tekrar deneyin.';
}

/** Tek satırlık salt-okunur bilgi alanı (read-only görünüm için). */
function ReadField({ label, value }: { label: string; value: string }) {
  return (
    <div className="space-y-1">
      <p className="text-xs font-medium text-foreground-500 uppercase tracking-wide">{label}</p>
      <p className="text-sm text-foreground-800 break-words">{value || '—'}</p>
    </div>
  );
}

/** Logo görselini güvenli biçimde gösterir (kırpma/stretch yok, object-contain). */
function LogoView({ url, unvan }: { url: string | null; unvan: string }) {
  return (
    <div className="w-40 h-24 rounded-lg bg-background-100 border border-background-300/40 dark:bg-background-200 dark:border-background-400/40 flex items-center justify-center overflow-hidden p-2">
      {url ? (
        <img src={url} alt={`${unvan} logosu`} className="max-w-full max-h-full object-contain" />
      ) : (
        <div className="flex flex-col items-center gap-1 text-foreground-400">
          <i className="ri-building-4-line text-2xl" />
          <span className="text-xs">Logo yok</span>
        </div>
      )}
    </div>
  );
}

/**
 * ORTAK Kurumsal Ayarlar componenti (TEK KAYNAK).
 *
 * OSGB Yönetim → EDIT MODE; Firma/Uzman/Hekim → READ ONLY.
 * Edit yetkisi role'dan türetilir (`osgb_admin`) ve ayrıca backend RPC
 * (`update_osgb_kurumsal`, SECURITY DEFINER) ile server tarafında tekrar doğrulanır.
 * Dört panelde de aynı merkezi `osgb` kaydı okunur.
 */
export default function KurumsalAyarlarSection() {
  const { profile } = useAuth();
  const { addToast } = useToastActions();

  const canEdit = profile?.role === 'osgb_admin';
  const osgbId = profile?.osgbId ?? null;

  const [data, setData] = useState<KurumsalOsgb | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form state (edit modu)
  const [unvan, setUnvan] = useState('');
  const [vergiNo, setVergiNo] = useState('');
  const [adres, setAdres] = useState('');
  const [il, setIl] = useState('');
  const [ilce, setIlce] = useState('');
  const [telefon, setTelefon] = useState('');
  const [email, setEmail] = useState('');
  const [website, setWebsite] = useState('');
  const [aciklama, setAciklama] = useState('');
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [logoRemoved, setLogoRemoved] = useState(false);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const fileRef = useRef<HTMLInputElement>(null);
  const prevPreviewRef = useRef<string | null>(null);

  const applyData = useCallback((d: KurumsalOsgb) => {
    setUnvan(d.unvan ?? '');
    setVergiNo(d.vergiNo ?? '');
    setAdres(d.adres ?? '');
    setIl(d.il ?? '');
    setIlce(d.ilce ?? '');
    setTelefon(d.telefon ?? '');
    setEmail(d.email ?? '');
    setWebsite(d.website ?? '');
    setAciklama(d.aciklama ?? '');
    setLogoUrl(d.logoUrl);
    setLogoFile(null);
    setLogoRemoved(false);
    if (prevPreviewRef.current) {
      URL.revokeObjectURL(prevPreviewRef.current);
      prevPreviewRef.current = null;
    }
    setLogoPreview(null);
  }, []);

  const load = useCallback(async () => {
    if (!osgbId) {
      setLoading(false);
      setError('Hesabınızla ilişkili bir OSGB kaydı bulunamadı.');
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const d = await fetchKurumsalOsgb(osgbId);
      setData(d);
      if (d) applyData(d);
    } catch (e) {
      setError(friendlyErrorMessage(e, 'Kurumsal bilgiler yüklenemedi.'));
    } finally {
      setLoading(false);
    }
  }, [osgbId, applyData]);

  useEffect(() => {
    void load();
    return () => {
      if (prevPreviewRef.current) {
        URL.revokeObjectURL(prevPreviewRef.current);
        prevPreviewRef.current = null;
      }
    };
  }, [load]);

  const handleLogoSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (!LOGO_MIMES.includes(f.type)) {
      addToast({ title: 'Logo yüklenemedi', message: 'Lütfen JPG, PNG veya WEBP seçin.', type: 'error' });
      return;
    }
    if (f.size > LOGO_MAX_SIZE) {
      addToast({ title: 'Logo yüklenemedi', message: 'Dosya boyutu 3 MB sınırını aşıyor.', type: 'error' });
      return;
    }
    if (prevPreviewRef.current) URL.revokeObjectURL(prevPreviewRef.current);
    const preview = URL.createObjectURL(f);
    prevPreviewRef.current = preview;
    setLogoFile(f);
    setLogoPreview(preview);
    setLogoRemoved(false);
  };

  const handleLogoRemove = () => {
    if (prevPreviewRef.current) URL.revokeObjectURL(prevPreviewRef.current);
    prevPreviewRef.current = null;
    setLogoFile(null);
    setLogoPreview(null);
    setLogoRemoved(true);
  };

  const handleSave = async () => {
    const e: Record<string, string> = {};
    if (!unvan.trim()) e.unvan = 'OSGB adı zorunludur.';
    if (email && !/^\S+@\S+\.\S+$/.test(email)) e.email = 'Geçerli bir e-posta girin.';
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    if (saving) return;

    setSaving(true);
    let uploadedPath: string | null = null;
    let nextLogo = logoRemoved ? null : logoUrl;
    try {
      if (logoFile && osgbId) {
        const res = await uploadOsgbLogo(logoFile, osgbId);
        uploadedPath = res.path;
        nextLogo = res.url;
      }

      await updateKurumsalOsgb({
        unvan: unvan.trim(),
        logoUrl: nextLogo,
        vergiNo: vergiNo.trim() || null,
        adres: adres.trim() || null,
        il: il || null,
        ilce: ilce || null,
        telefon: telefon.trim() || null,
        email: email.trim() || null,
        website: website.trim() || null,
        aciklama: aciklama.trim() || null,
      });

      // Yeni logo yüklendi ve eski logo farklıysa eski dosyayı temizle (orphan birikmesin).
      if (logoFile && logoUrl && logoUrl !== nextLogo) {
        await removeOsgbLogo(logoUrl).catch(() => {});
      } else if (logoRemoved && logoUrl) {
        await removeOsgbLogo(logoUrl).catch(() => {});
      }

      await load();
      addToast({ title: 'Kurumsal Ayarlar Güncellendi', message: 'OSGB kurumsal bilgileriniz başarıyla kaydedildi.', type: 'success' });
    } catch (err) {
      if (uploadedPath && nextLogo) await removeOsgbLogo(nextLogo).catch(() => {});
      addToast({ title: 'Kayıt başarısız', message: friendlyError(err), type: 'error' });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <Card padding="lg">
        <Loading text="Kurumsal bilgiler yükleniyor..." />
      </Card>
    );
  }

  if (error) {
    return (
      <Card padding="lg">
        <ErrorState message={error} onRetry={() => void load()} />
      </Card>
    );
  }

  if (!data) {
    return (
      <Card padding="lg">
        <EmptyState
          icon="ri-building-4-line"
          title="Kurumsal bilgi bulunamadı"
          description="Hesabınızla ilişkili OSGB kurumsal kaydına ulaşılamadı."
        />
      </Card>
    );
  }

  // ---------- READ ONLY (Firma / Uzman / Hekim) ----------
  if (!canEdit) {
    return (
      <Card
        title="Kurumsal Ayarlar"
        subtitle="Bağlı olduğunuz OSGB'nin kurumsal bilgileri. Bu bilgiler yalnızca OSGB yönetimi tarafından düzenlenir."
        padding="md"
        headerAction={<Badge variant="secondary">Salt Okunur</Badge>}
      >
        <div className="flex flex-col sm:flex-row gap-5">
          <div className="flex-shrink-0">
            <LogoView url={logoUrl} unvan={unvan} />
          </div>
          <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4 min-w-0">
            <ReadField label="OSGB Adı" value={unvan} />
            <ReadField label="Vergi No" value={vergiNo} />
            <ReadField label="İl" value={il} />
            <ReadField label="İlçe" value={ilce} />
            <ReadField label="Telefon" value={telefon} />
            <ReadField label="E-posta" value={email} />
            <ReadField label="Web Sitesi" value={website} />
            <div className="sm:col-span-2">
              <ReadField label="Adres" value={adres} />
            </div>
            {aciklama && (
              <div className="sm:col-span-2">
                <ReadField label="Açıklama" value={aciklama} />
              </div>
            )}
          </div>
        </div>
      </Card>
    );
  }

  // ---------- EDIT MODE (OSGB Yönetim) ----------
  return (
    <Card
      title="Kurumsal Ayarlar"
      subtitle="OSGB'nize ait merkezi kurumsal kimlik bilgilerini düzenleyin. Bu bilgiler tüm panellerde ve ileride rapor çıktılarında kullanılır."
      padding="md"
    >
      <div className="space-y-4">
        <div className="flex items-start gap-4">
          <LogoView url={logoPreview ?? logoUrl} unvan={unvan} />
          <div className="flex flex-col gap-2 min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <Button
                variant="secondary"
                size="sm"
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={saving}
                leftIcon={<i className="ri-upload-cloud-2-line" />}
              >
                {logoPreview || logoUrl ? 'Logoyu Değiştir' : 'Logo Yükle'}
              </Button>
              {(logoPreview || logoUrl) && (
                <Button
                  variant="ghost"
                  size="sm"
                  type="button"
                  onClick={handleLogoRemove}
                  disabled={saving}
                  leftIcon={<i className="ri-delete-bin-line" />}
                >
                  Kaldır
                </Button>
              )}
            </div>
            <p className="text-xs text-foreground-500">JPG, PNG veya WEBP — en fazla 3 MB</p>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept={LOGO_ACCEPT}
            className="hidden"
            onChange={handleLogoSelect}
            disabled={saving}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <Input
            label="OSGB Adı"
            required
            value={unvan}
            onChange={(e) => { setUnvan(e.target.value); setErrors((p) => ({ ...p, unvan: '' })); }}
            error={errors.unvan}
          />
          <Input
            label="Vergi No"
            value={vergiNo}
            onChange={(e) => setVergiNo(e.target.value)}
          />
          <ProvinceSelect
            label="İl"
            value={il}
            onChange={(v) => { setIl(v); setIlce(''); }}
          />
          <DistrictSelect
            label="İlçe"
            provinceValue={il}
            value={ilce}
            onChange={(v) => setIlce(v)}
          />
          <PhoneInput
            label="Telefon"
            value={telefon}
            onChange={setTelefon}
            leftIcon={<i className="ri-phone-line" />}
          />
          <Input
            label="E-posta"
            type="email"
            value={email}
            onChange={(e) => { setEmail(e.target.value); setErrors((p) => ({ ...p, email: '' })); }}
            error={errors.email}
            leftIcon={<i className="ri-mail-line" />}
          />
          <Input
            label="Web Sitesi"
            type="url"
            placeholder="www.ornek.com"
            value={website}
            onChange={(e) => setWebsite(e.target.value)}
            leftIcon={<i className="ri-global-line" />}
          />
          <div className="sm:col-span-2">
            <Input
              label="Adres"
              value={adres}
              onChange={(e) => setAdres(e.target.value)}
              leftIcon={<i className="ri-map-pin-line" />}
            />
          </div>
          <div className="sm:col-span-2">
            <Input
              label="Açıklama"
              value={aciklama}
              onChange={(e) => setAciklama(e.target.value)}
            />
          </div>
        </div>

        <div className="flex justify-end pt-1">
          <Button
            variant="primary"
            size="sm"
            isLoading={saving}
            onClick={handleSave}
            leftIcon={<i className="ri-save-line" />}
          >
            Kaydet
          </Button>
        </div>
      </div>
    </Card>
  );
}