import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToastActions } from '@/hooks/useToast';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import AttachmentPicker from './AttachmentPicker';
import {
  SUPPORT_CATEGORY_OPTIONS,
  SUPPORT_PRIORITY_OPTIONS,
  createTicket,
  uploadAttachment,
  friendlySupportError,
} from '@/lib/supportService';

interface NewSupportTicketModalProps {
  onClose: () => void;
  onCreated: () => void;
}

/**
 * Ortak "Yeni Destek Talebi" formu. OSGB / Firma / Uzman / Hekim panellerinde
 * kullanılır (Admin panelinde YOKTUR). Gerçek Supabase kaydı oluşturur,
 * sahte başarı göstermez, double-submit engeller.
 */
export default function NewSupportTicketModal({ onClose, onCreated }: NewSupportTicketModalProps) {
  const { profile } = useAuth();
  const { addToast } = useToastActions();

  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState('normal');
  const [message, setMessage] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    if (submitting) return;
    setError('');
    if (!subject.trim()) {
      setError('Konu zorunludur.');
      return;
    }
    if (!category) {
      setError('Kategori seçin.');
      return;
    }
    if (!message.trim()) {
      setError('Açıklama zorunludur.');
      return;
    }
    if (!profile) {
      setError('Oturumunuz sona ermiş görünüyor. Lütfen sayfayı yenileyip yeniden giriş yapın.');
      return;
    }

    setSubmitting(true);
    try {
      const result = await createTicket({
        subject: subject.trim(),
        category,
        priority,
        message: message.trim(),
        osgbId: profile.osgbId,
      });

      // İlk mesaja dosyaları ekle (varsa); başarısız dosya talebi bozmaz.
      let failedFiles = 0;
      for (const file of files) {
        try {
          await uploadAttachment(result.id, result.messageId, file);
        } catch {
          failedFiles += 1;
        }
      }

      addToast({
        title: 'Destek talebi oluşturuldu',
        message: `${result.ticketNo} numaralı talebiniz oluşturuldu.`,
        type: 'success',
      });
      if (failedFiles > 0) {
        addToast({ title: 'Dikkat', message: `${failedFiles} dosya eklenemedi.`, type: 'warning' });
      }
      onCreated();
      onClose();
    } catch (e) {
      setError(friendlySupportError(e));
      addToast({ title: 'Hata', message: 'Destek talebi oluşturulamadı.', type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4">
      <Input
        label="Konu"
        required
        value={subject}
        onChange={(e) => setSubject(e.target.value)}
        placeholder="Talebinizin konusunu yazın"
        data-autofocus
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Select
          label="Kategori"
          required
          options={SUPPORT_CATEGORY_OPTIONS}
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          placeholder="Kategori seçin"
        />
        <Select
          label="Öncelik"
          options={SUPPORT_PRIORITY_OPTIONS}
          value={priority}
          onChange={(e) => setPriority(e.target.value)}
          placeholder="Öncelik seçin"
        />
      </div>

      <Textarea
        label="Açıklama"
        required
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Sorununuzu detaylı şekilde açıklayın"
        maxLength={500}
      />

      <div>
        <p className="isg-form-label">Dosya Ekleme</p>
        <AttachmentPicker files={files} onChange={setFiles} disabled={submitting} />
      </div>

      {error && (
        <p className="text-sm text-danger-600 flex items-center gap-1.5">
          <i className="ri-error-warning-line" />
          {error}
        </p>
      )}

      <div className="flex items-center justify-end gap-2 pt-2 border-t border-background-300/25">
        <button type="button" onClick={onClose} className="isg-btn isg-btn-secondary" disabled={submitting}>
          Vazgeç
        </button>
        <button type="button" onClick={handleSubmit} disabled={submitting} className="isg-btn isg-btn-primary">
          {submitting && <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-1.5" />}
          Gönder
        </button>
      </div>
    </div>
  );
}