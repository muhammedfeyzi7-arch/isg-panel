import { useRef, useState } from 'react';
import { formatBytes, MAX_ATTACHMENT_SIZE, SUPPORT_ACCEPT_ATTR, SUPPORT_SUPPORTED_HINT } from '@/lib/supportService';
import { isSameFile, validateUploadFile } from '@/lib/fileUpload';

interface SupportFilePickerProps {
  files: File[];
  onChange: (files: File[]) => void;
  disabled?: boolean;
}

/**
 * Destek talebi — geniş, güvenli, çoklu dosya + sürükle-bırak seçici.
 * Doğrulama tek merkezden (src/lib/fileUpload.ts) yapılır: uzantı + MIME + boyut
 * + boş dosya. "Sadece JPG/PDF" gibi gereksiz kısıt uygulanmaz.
 * Gerçek Supabase Storage yüklemesi gönderim anında service katmanında yapılır.
 */
export default function SupportFilePicker({ files, onChange, disabled }: SupportFilePickerProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const [notice, setNotice] = useState('');

  const acceptFiles = (picked: File[]) => {
    const accepted: File[] = [];
    const skipped: string[] = [];
    for (const f of picked) {
      if (files.some((x) => isSameFile(x, f)) || accepted.some((x) => isSameFile(x, f))) {
        skipped.push(`“${f.name}” zaten ekli`);
        continue;
      }
      const err = validateUploadFile(f, { accept: SUPPORT_ACCEPT_ATTR, maxSize: MAX_ATTACHMENT_SIZE });
      if (err) {
        skipped.push(err);
        continue;
      }
      accepted.push(f);
    }
    if (accepted.length > 0) onChange([...files, ...accepted]);
    setNotice(skipped.length > 0 ? skipped.join(' • ') : '');
  };

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) acceptFiles(Array.from(e.target.files));
    e.target.value = '';
  };

  const openPicker = () => {
    if (!disabled) inputRef.current?.click();
  };

  return (
    <div className="w-full">
      <div
        role="button"
        tabIndex={0}
        aria-label="Dosya ekle"
        onClick={openPicker}
        onKeyDown={(e) => {
          if ((e.key === 'Enter' || e.key === ' ') && !disabled) {
            e.preventDefault();
            openPicker();
          }
        }}
        onDragOver={(e) => {
          e.preventDefault();
          if (!disabled) setDragActive(true);
        }}
        onDragLeave={() => setDragActive(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragActive(false);
          if (!disabled && e.dataTransfer.files) acceptFiles(Array.from(e.dataTransfer.files));
        }}
        className={`flex flex-col items-center justify-center text-center rounded-xl border-2 border-dashed px-4 py-5 transition-colors ${
          disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'
        } ${
          dragActive
            ? 'border-primary-400 bg-primary-50 dark:bg-primary-500/10'
            : 'border-background-300/70 dark:border-background-500/25 hover:border-primary-300 hover:bg-background-100 dark:hover:bg-background-300/20'
        }`}
      >
        <span className="w-11 h-11 rounded-full bg-primary-100 dark:bg-primary-500/15 text-primary-600 flex items-center justify-center mb-2">
          <i className="ri-upload-cloud-2-line text-xl" />
        </span>
        <p className="text-sm font-medium text-foreground-900">Dosya ekle</p>
        <p className="text-xs text-foreground-500 mt-0.5">Sürükleyip bırakın veya bilgisayarınızdan seçin</p>
        <p className="text-[11px] text-foreground-400 mt-1">
          Maks. {Math.round(MAX_ATTACHMENT_SIZE / (1024 * 1024))} MB / dosya • Çoklu dosya desteklenir
        </p>
      </div>

      <input
        ref={inputRef}
        type="file"
        multiple
        accept={SUPPORT_ACCEPT_ATTR}
        className="hidden"
        onChange={handleInput}
        disabled={disabled}
      />

      <p className="mt-1.5 text-[11px] text-foreground-400">Desteklenen formatlar: {SUPPORT_SUPPORTED_HINT}</p>

      {notice && (
        <p className="mt-1.5 text-[11px] text-warning-600 flex items-start gap-1">
          <i className="ri-error-warning-line mt-px flex-shrink-0" />
          <span className="break-words">{notice}</span>
        </p>
      )}

      {files.length > 0 && (
        <ul className="mt-2.5 space-y-1.5">
          {files.map((file, idx) => (
            <li
              key={`${file.name}-${idx}-${file.lastModified}`}
              className="flex items-center gap-2 px-2.5 py-2 rounded-lg bg-background-100 dark:bg-background-200/50 border border-background-300/60 dark:border-background-500/20"
            >
              <i className="ri-file-line text-foreground-400 text-base flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground-800 truncate">{file.name}</p>
                <p className="text-[10px] text-foreground-400">{formatBytes(file.size)}</p>
              </div>
              <button
                type="button"
                onClick={() => onChange(files.filter((_, i) => i !== idx))}
                disabled={disabled}
                className="w-6 h-6 flex items-center justify-center rounded text-foreground-400 hover:text-danger-600 hover:bg-danger-50 transition-colors cursor-pointer flex-shrink-0"
                aria-label="Dosyayı kaldır"
              >
                <i className="ri-close-line text-sm" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}