import { categoryLabel } from '@/lib/supportService';
import { formatIstanbulDate } from '@/lib/dateFormat';

// ─────────────────────────────────────────────────────────────────────────────
// DESTEK — Kullanıcı tarafı sunum yardımcıları (tek kaynak).
// Kullanıcıya "Kapatıldı" gibi iç terminoloji GÖSTERİLMEZ; resolved/closed
// durumları kullanıcı için "Çözüldü" olarak sunulur.
// ─────────────────────────────────────────────────────────────────────────────

/** Ticket kullanıcı için sonlanmış (yeni mesaj kabul etmez) mı? */
export function isResolvedStatus(status: string): boolean {
  return status === 'resolved' || status === 'closed';
}

export const USER_STATUS_LABEL: Record<string, string> = {
  open: 'Destek Ekibine İletildi',
  in_progress: 'İnceleniyor',
  waiting: 'Yanıt Bekleniyor',
  resolved: 'Çözüldü',
  closed: 'Çözüldü',
};

export function userStatusLabel(status: string): string {
  return USER_STATUS_LABEL[status] ?? status;
}

export type UserStatusVariant = 'info' | 'warning' | 'accent' | 'success' | 'default';

export function userStatusVariant(status: string): UserStatusVariant {
  switch (status) {
    case 'open': return 'info';
    case 'in_progress': return 'warning';
    case 'waiting': return 'accent';
    case 'resolved':
    case 'closed': return 'success';
    default: return 'default';
  }
}

/** Kategori etiketi — bilinmeyen slug için güvenli fallback. */
export function safeCategoryLabel(slug: string): string {
  if (!slug) return 'Belirtilmemiş';
  const label = categoryLabel(slug);
  return label && label !== slug ? label : 'Belirtilmemiş';
}

const istanbulDayKey = (d: Date): string => d.toLocaleDateString('en-CA', { timeZone: 'Europe/Istanbul' });

/** Saat — Europe/Istanbul. */
export function formatSupportTime(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit', timeZone: 'Europe/Istanbul' });
}

/** Gün ayracı — Bugün / Dün / 18 Eylül 2026. */
export function formatSupportDay(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '';
  const now = new Date();
  if (istanbulDayKey(d) === istanbulDayKey(now)) return 'Bugün';
  if (istanbulDayKey(d) === istanbulDayKey(new Date(now.getTime() - 86400000))) return 'Dün';
  return formatIstanbulDate(iso);
}

export function sameSupportDay(a: string, b: string): boolean {
  return istanbulDayKey(new Date(a)) === istanbulDayKey(new Date(b));
}

/** Geçmiş listesi için kısa tarih. */
export function formatSupportTicketDate(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return formatIstanbulDate(iso);
}

export function isImageMime(mime: string | null | undefined): boolean {
  return !!mime && mime.startsWith('image/');
}