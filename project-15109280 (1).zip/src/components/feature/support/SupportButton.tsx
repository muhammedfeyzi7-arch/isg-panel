import { useCallback, useEffect, useState, lazy, Suspense } from 'react';
import { useModalActions } from '@/hooks/useModal';
import { useAuth } from '@/context/AuthContext';
import { fetchSupportUnreadCount } from '@/lib/supportService';
import ModalFallback from '@/components/ui/ModalFallback';

// Destek merkezi ağır bir modaldır; yalnızca butona tıklanınca yüklenir (tembel).
// Böylece her panelin açılışında bundle'a dahil olmaz.
const SupportCenterModal = lazy(() => import('./SupportCenterModal'));

/**
 * Topbar destek (Headset) ikonu. Tıklanınca DROPDOWN/POPOVER AÇMAZ — doğrudan
 * tek Destek modalını açar. Kullanıcının okunmamış destek yanıtı varsa ikon
 * üzerinde küçük ve zarif bir rozet gösterilir.
 */
export default function SupportButton() {
  const { openModal, closeModal } = useModalActions();
  const { profile } = useAuth();
  const [unread, setUnread] = useState(0);

  const load = useCallback(async () => {
    if (!profile) return;
    try {
      setUnread(await fetchSupportUnreadCount());
    } catch {
      /* sessiz — rozet canlılığı kritik değil */
    }
  }, [profile]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleOpen = () => {
    const id = openModal({
      title: 'Destek',
      description: 'Sorularınızı iletin, destek ekibimiz en kısa sürede dönüş yapsın.',
      variant: 'detail',
      width: 1080,
      height: 680,
      minWidth: 680,
      minHeight: 560,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      bodyLayout: 'fill',
      headerIcon: (
        <span className="w-10 h-10 rounded-xl bg-primary-500/10 text-primary-600 flex items-center justify-center">
          <i className="ri-customer-service-2-line text-xl" />
        </span>
      ),
      onClose: () => {
        void load();
      },
      content: (
        <Suspense fallback={<ModalFallback />}>
          <SupportCenterModal onClose={() => closeModal(id)} />
        </Suspense>
      ),
    });
  };

  return (
    <button
      type="button"
      onClick={handleOpen}
      aria-label="Destek"
      title="Destek"
      className="relative w-8 h-8 flex items-center justify-center rounded text-foreground-500 hover:text-foreground-700 hover:bg-background-200 transition-colors cursor-pointer"
    >
      <i className="ri-customer-service-2-line text-lg" />
      {unread > 0 && (
        <span className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 px-1 flex items-center justify-center rounded-full bg-danger-500 text-inverse text-[10px] font-bold">
          {unread > 99 ? '99+' : unread}
        </span>
      )}
    </button>
  );
}