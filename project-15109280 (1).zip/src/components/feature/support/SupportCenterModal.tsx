import { useCallback, useEffect, useMemo, useState } from 'react';
import { fetchTickets, type SupportTicket } from '@/lib/supportService';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import { isResolvedStatus } from './supportUi';
import SupportTicketForm from './SupportTicketForm';
import SupportHistoryList from './SupportHistoryList';
import SupportConversation from './SupportConversation';

interface SupportCenterModalProps {
  onClose: () => void;
}

type SupportTab = 'new' | 'history';

/**
 * TEK DESTEK MODALI (kullanıcı tarafı). İki kolon:
 *   • Sol: sekmeler (Yeni Destek Talebi / Geçmiş Destek Talepleri)
 *   • Sağ: aktif destek görüşmesi
 * Side Panel / ayrı sayfa YOKTUR; tüm akış bu modal içinde yürür.
 * Desktop'ta scrollsuzdur (modal `bodyLayout: 'fill'` ile açılır); yalnızca
 * liste ve konuşma gövdeleri kendi iç scroll'una sahiptir.
 */
export default function SupportCenterModal({ onClose: _onClose }: SupportCenterModalProps) {
  const [tab, setTab] = useState<SupportTab>('new');
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeId, setActiveId] = useState<string | null>(null);
  const [mobileChat, setMobileChat] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const list = await fetchTickets();
      setTickets(list);
      setActiveId((cur) => {
        if (cur && list.some((t) => t.id === cur)) return cur;
        const unresolved = list.find((t) => !isResolvedStatus(t.status));
        return unresolved?.id ?? null;
      });
    } catch (e) {
      setError(friendlyErrorMessage(e, 'Destek talepleriniz yüklenemedi.'));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const activeTicket = useMemo(() => tickets.find((t) => t.id === activeId) ?? null, [tickets, activeId]);

  const handleCreated = useCallback(
    (ticketId: string) => {
      setTab('new');
      setActiveId(ticketId);
      setMobileChat(true);
      void load();
    },
    [load],
  );

  const handleSelect = useCallback((t: SupportTicket) => {
    setActiveId(t.id);
    setMobileChat(true);
  }, []);

  const handleChanged = useCallback(() => {
    void load();
  }, [load]);

  const handleNewTicket = useCallback(() => {
    setTab('new');
    setMobileChat(false);
  }, []);

  const tabs: { key: SupportTab; label: string; icon: string }[] = [
    { key: 'new', label: 'Yeni Destek Talebi', icon: 'ri-customer-service-2-line' },
    { key: 'history', label: 'Geçmiş Destek Talepleri', icon: 'ri-history-line' },
  ];

  return (
    <div className="flex-1 min-h-0 flex flex-col lg:flex-row">
      {/* ── SOL: sekmeler + form / geçmiş ── */}
      <section
        className={`flex-col min-h-0 w-full lg:w-[54%] lg:border-r border-background-300/40 dark:border-background-500/20 ${
          mobileChat ? 'hidden lg:flex' : 'flex'
        }`}
      >
        <div className="flex-shrink-0 px-4 md:px-5 pt-4">
          <div className="flex items-center gap-1 p-1 rounded-xl isg-segmented">
            {tabs.map((t) => (
              <button
                key={t.key}
                type="button"
                onClick={() => setTab(t.key)}
                className={`flex-1 min-w-0 flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                  tab === t.key
                    ? 'isg-segment-active text-primary-700 dark:text-primary-300'
                    : 'text-foreground-500 hover:text-foreground-700'
                }`}
              >
                <i className={`${t.icon} text-sm flex-shrink-0`} />
                <span className="truncate">{t.label}</span>
              </button>
            ))}
          </div>
        </div>

        {tab === 'new' ? (
          <SupportTicketForm onCreated={handleCreated} />
        ) : (
          <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane px-4 md:px-5 py-4">
            <SupportHistoryList
              tickets={tickets}
              loading={loading}
              error={error}
              activeId={activeId}
              onSelect={handleSelect}
              onRetry={load}
            />
          </div>
        )}
      </section>

      {/* ── SAĞ: aktif destek görüşmesi ── */}
      <section
        className={`flex-col min-h-0 w-full lg:w-[46%] bg-background-100/70 dark:bg-background-200/30 ${
          mobileChat ? 'flex' : 'hidden lg:flex'
        }`}
      >
        <SupportConversation
          ticket={activeTicket}
          onNewTicket={handleNewTicket}
          onChanged={handleChanged}
          onBack={() => setMobileChat(false)}
        />
      </section>
    </div>
  );
}