import { useState, useCallback, useMemo, useRef, useEffect } from 'react';
import useSWR from 'swr';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/context/AuthContext';
import { useModalActions } from '@/hooks/useModal';
import { useToastActions } from '@/hooks/useToast';
import PageHeader from '@/components/ui/PageHeader';
import FilterBar from '@/components/ui/FilterBar';
import type { FilterField, FilterValue } from '@/components/ui/FilterBar';
import Table from '@/components/ui/Table';
import type { TableColumn } from '@/components/ui/Table';
import Pagination from '@/components/ui/Pagination';
import Loading from '@/components/ui/Loading';
import EmptyState from '@/components/ui/EmptyState';
import ErrorState from '@/components/ui/ErrorState';
import StatCard from '@/components/ui/StatCard';
import Badge from '@/components/ui/Badge';
import Button from '@/components/ui/Button';
import SharedListCard, { ListCardBadge } from '@/components/ui/SharedListCard';
import ContextMenu from '@/components/ui/ContextMenu';
import IconButton from '@/components/ui/IconButton';
import SupportTicketDetail from './SupportTicketDetail';
import NewSupportTicketModal from './NewSupportTicketModal';
import { customDateRange } from '@/lib/logService';
import {
  SUPPORT_STATUS_OPTIONS,
  SUPPORT_PRIORITY_OPTIONS,
  SUPPORT_CATEGORY_OPTIONS,
  PANEL_LABEL,
  statusLabel,
  priorityLabel,
  categoryLabel,
  formatDateTime,
  fetchTicketsPage,
  fetchTicketStats,
  friendlySupportError,
  updateTicketStatus,
  type SupportTicket,
} from '@/lib/supportService';

const PANEL_ICON: Record<string, string> = {
  osgb: 'ri-building-4-line',
  firma: 'ri-briefcase-line',
  uzman: 'ri-user-star-line',
  hekim: 'ri-user-heart-line',
};

const PANEL_COLOR: Record<string, string> = {
  osgb: 'bg-primary-100 text-primary-600',
  firma: 'bg-accent-100 text-accent-600',
  uzman: 'bg-warning-100 text-warning-600',
  hekim: 'bg-success-100 text-success-600',
};

const statusVariant = (s: string): 'info' | 'warning' | 'success' | 'secondary' | 'accent' | 'default' => {
  switch (s) {
    case 'open': return 'info';
    case 'in_progress': return 'warning';
    case 'waiting': return 'accent';
    case 'resolved': return 'success';
    case 'closed': return 'secondary';
    default: return 'default';
  }
};

const priorityVariant = (p: string): 'danger' | 'warning' | 'info' | 'default' => {
  switch (p) {
    case 'critical': return 'danger';
    case 'high': return 'warning';
    case 'normal': return 'info';
    default: return 'default';
  }
};

function asStr(v: FilterValue | undefined): string {
  return typeof v === 'string' ? v : '';
}

function asRange(v: FilterValue | undefined): { from: string; to: string } {
  return v && typeof v === 'object' && !Array.isArray(v) ? v : { from: '', to: '' };
}

interface SupportTicketListProps {
  title: string;
  canCreate: boolean;
}

/**
 * Tüm 5 panelin ortak destek talebi liste motoru (sunucu-tarafı sayfalama).
 * RLS veriyi kullanıcıya göre kapsar; admin tümünü, diğerleri yalnızca kendi taleplerini görür.
 */
export default function SupportTicketList({ title, canCreate }: SupportTicketListProps) {
  const { profile } = useAuth();
  const { openModal, closeModal } = useModalActions();
  const { addToast } = useToastActions();
  const isAdmin = profile?.role === 'admin';

  const [searchQuery, setSearchQuery] = useState('');
  const [filterValues, setFilterValues] = useState<Record<string, FilterValue>>({});
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(10);
  const detailModalIdRef = useRef('');

  const status = asStr(filterValues['status']);
  const priority = asStr(filterValues['priority']);
  const category = asStr(filterValues['category']);
  const panel = asStr(filterValues['createdByPanel']);
  const dateRange = asRange(filterValues['dateRange']);

  const queryKey = useMemo(
    () => JSON.stringify({ search: searchQuery, status, priority, category, panel, from: dateRange.from, to: dateRange.to, page, pageSize }),
    [searchQuery, status, priority, category, panel, dateRange.from, dateRange.to, page, pageSize],
  );

  const { data: pageData, error: pageError, isLoading, mutate } = useSWR(
    ['support-tickets', queryKey],
    async () => {
      const range = customDateRange(dateRange.from, dateRange.to);
      return fetchTicketsPage({
        search: searchQuery,
        status: status as '' | 'open' | 'in_progress' | 'waiting' | 'resolved' | 'closed',
        priority: priority as '' | 'low' | 'normal' | 'high' | 'critical',
        category: category as '' | 'technical' | 'account' | 'usage' | 'data' | 'other',
        panel: panel as '' | 'osgb' | 'firma' | 'uzman' | 'hekim',
        from: range.from,
        to: range.to,
        page,
        pageSize,
      });
    },
  );

  const { data: stats, mutate: mutateStats } = useSWR('support-ticket-stats', fetchTicketStats);

  const rows = pageData?.data ?? [];
  const count = pageData?.count ?? 0;
  const loading = isLoading;
  const error = pageError ? (pageError instanceof Error ? pageError.message : 'Yüklenemedi') : null;
  const totalPages = Math.max(1, Math.ceil(count / pageSize));

  const load = useCallback(() => {
    void mutate();
  }, [mutate]);

  // Gerçek zamanlı liste + StatCard özeti: yeni talep, durum/öncelik değişimi veya
  // kapatma/yeniden açma olduğunda hem tablo hem sayaçlar sayfa yenilenmeden
  // güncellenir. İki ayrı SWR anahtarı invalidate edilir (['support-tickets'] liste,
  // 'support-ticket-stats' sayaçlar). RLS satır kapsamını korur.
  useEffect(() => {
    const channel = supabase
      .channel('support-tickets-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'support_tickets' }, () => {
        void mutate();
        void mutateStats();
      })
      .subscribe();
    return () => { void supabase.removeChannel(channel); };
  }, [mutate, mutateStats]);

  const handleFilterChange = (key: string, value: FilterValue) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }));
    setPage(1);
  };

  const handleReset = () => {
    setFilterValues({});
    setSearchQuery('');
    setPage(1);
  };

  const openDetail = useCallback(
    (ticket: SupportTicket) => {
      const id = openModal({
        title: 'Destek Talebi Detayı',
        description: ticket.ticketNo,
        variant: 'detail',
        width: 680,
        minWidth: 480,
        minHeight: 520,
        showFooter: false,
        closable: true,
        resizable: true,
        minimizable: true,
        bodyLayout: 'fill',
        onClose: () => {
          load();
        },
        content: <SupportTicketDetail ticket={ticket} onClose={() => closeModal(detailModalIdRef.current)} />,
      });
      detailModalIdRef.current = id;
    },
    [openModal, closeModal, load],
  );

  const openCreate = useCallback(() => {
    const id = openModal({
      title: 'Yeni Destek Talebi',
      description: 'Sorununuzu bize iletin, en kısa sürede dönüş yapalım.',
      variant: 'form',
      width: 560,
      minWidth: 440,
      minHeight: 480,
      showFooter: false,
      closable: true,
      resizable: true,
      minimizable: true,
      content: <NewSupportTicketModal onClose={() => closeModal(id)} onCreated={() => load()} />,
    });
  }, [openModal, closeModal, load]);

  const handleCloseTicket = useCallback((ticket: SupportTicket) => {
    updateTicketStatus(ticket.id, 'closed')
      .then(() => {
        addToast({ title: 'Talep kapatıldı', message: `${ticket.ticketNo} kapatıldı.`, type: 'success' });
        load();
      })
      .catch((err) => addToast({ title: 'Hata', message: friendlySupportError(err), type: 'error' }));
  }, [addToast, load]);

  const rowActions = useCallback(
    (row: SupportTicket) => (
      <div className="flex items-center gap-1">
        <IconButton
          icon={<i className="ri-eye-line" />}
          variant="ghost"
          size="sm"
          label="Görüntüle"
          onClick={(e) => { e?.stopPropagation?.(); openDetail(row); }}
        />
        <ContextMenu
          items={[
            { label: 'Detayı Aç', icon: 'ri-eye-line', onClick: () => openDetail(row) },
            ...(isAdmin && row.status !== 'closed'
              ? [{ label: 'Talebi Kapat', icon: 'ri-close-circle-line', variant: 'danger' as const, onClick: () => handleCloseTicket(row) }]
              : []),
          ]}
        />
      </div>
    ),
    [openDetail, isAdmin, handleCloseTicket],
  );

  const columns = useMemo<TableColumn<SupportTicket>[]>(() => {
    const cols: TableColumn<SupportTicket>[] = [
      {
        key: 'ticketNo',
        header: '#',
        render: (row) => <span className="text-sm font-semibold text-foreground-800 whitespace-nowrap">#{row.ticketNo}</span>,
      },
      {
        key: 'subject',
        header: 'Konu',
        render: (row) => (
          <div className="flex items-center gap-2.5">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${PANEL_COLOR[row.createdByPanel] || 'bg-background-200'}`}>
              <i className={`${PANEL_ICON[row.createdByPanel] || 'ri-chat-3-line'} text-sm`} />
            </div>
            <p className="text-sm font-medium text-foreground-800 truncate max-w-[220px]">{row.subject}</p>
          </div>
        ),
      },
    ];

    if (isAdmin) {
      cols.push({
        key: 'creatorName',
        header: 'Kullanıcı / Panel',
        render: (row) => (
          <div>
            <p className="text-sm text-foreground-700">{row.creatorName}</p>
            <p className="text-xs text-foreground-500">{PANEL_LABEL[row.createdByPanel] || row.createdByPanel}</p>
          </div>
        ),
      });
    }

    cols.push(
      {
        key: 'category',
        header: 'Kategori',
        render: (row) => <span className="text-sm text-foreground-600">{categoryLabel(row.category)}</span>,
      },
      {
        key: 'status',
        header: 'Durum',
        render: (row) => <Badge variant={statusVariant(row.status)}>{statusLabel(row.status)}</Badge>,
      },
      {
        key: 'priority',
        header: 'Öncelik',
        render: (row) => <Badge variant={priorityVariant(row.priority)}>{priorityLabel(row.priority)}</Badge>,
      },
      {
        key: 'updatedAt',
        header: 'Son Güncelleme',
        render: (row) => <span className="text-sm text-foreground-600 whitespace-nowrap">{formatDateTime(row.updatedAt)}</span>,
      },
    );

    return cols;
  }, [isAdmin]);

  const filters = useMemo<FilterField[]>(() => {
    const base: FilterField[] = [
      { key: 'status', label: 'Durum', type: 'select', options: SUPPORT_STATUS_OPTIONS },
      { key: 'priority', label: 'Öncelik', type: 'select', options: SUPPORT_PRIORITY_OPTIONS },
      { key: 'category', label: 'Kategori', type: 'select', options: SUPPORT_CATEGORY_OPTIONS },
    ];
    if (isAdmin) {
      base.push({
        key: 'createdByPanel',
        label: 'Panel',
        type: 'select',
        options: [
          { value: 'osgb', label: 'OSGB Yönetim' },
          { value: 'firma', label: 'Firma' },
          { value: 'uzman', label: 'Uzman' },
          { value: 'hekim', label: 'Hekim' },
        ],
      });
    }
    base.push({ key: 'dateRange', label: 'Tarih Aralığı', type: 'date-range' });
    return base;
  }, [isAdmin]);

  const mobileCard = useCallback(
    (row: SupportTicket) => (
      <SharedListCard
        recordNo={row.ticketNo}
        icon={PANEL_ICON[row.createdByPanel] || 'ri-customer-service-line'}
        iconBg="bg-background-200"
        iconColor="text-foreground-500"
        title={row.subject}
        description={row.creatorName}
        badges={[
          <ListCardBadge key="durum" variant={statusVariant(row.status)}>{statusLabel(row.status)}</ListCardBadge>,
          <ListCardBadge key="oncelik" variant={priorityVariant(row.priority)}>{priorityLabel(row.priority)}</ListCardBadge>,
        ]}
        metadata={[
          { value: categoryLabel(row.category) },
          { value: <><i className="ri-calendar-line mr-0.5" />{formatDateTime(row.updatedAt)}</> },
        ]}
        onClick={() => openDetail(row)}
        showChevron={false}
      />
    ),
    [openDetail],
  );

  const hasActiveFilter = searchQuery !== '' || status !== '' || priority !== '' || category !== '' || panel !== '' || dateRange.from !== '' || dateRange.to !== '';

  return (
    <div className="isg-page lg:h-full">
      <PageHeader
        title={title}
        className="flex-shrink-0"
        subtitle={isAdmin ? 'Kullanıcılardan gelen destek taleplerini görüntüleyin ve yönetin.' : 'Destek taleplerinizi görüntüleyin ve takip edin.'}
        actions={
          canCreate ? (
            <Button variant="primary" size="sm" leftIcon={<i className="ri-add-line" />} onClick={openCreate}>
              Yeni Destek Talebi
            </Button>
          ) : undefined
        }
      />

      <div className="isg-stat-grid flex-shrink-0">
        {isAdmin ? (
          <>
            <StatCard title="Tüm Talepler" value={stats?.total ?? 0} icon="ri-customer-service-line" iconColor="text-primary-500" iconBg="bg-primary-50" />
            <StatCard title="Açık" value={stats?.open ?? 0} icon="ri-add-circle-line" iconColor="text-primary-700" iconBg="bg-primary-50" />
            <StatCard title="İnceleniyor" value={stats?.inProgress ?? 0} icon="ri-loader-4-line" iconColor="text-warning-700" iconBg="bg-warning-50" />
            <StatCard title="Çözülen" value={stats?.resolved ?? 0} icon="ri-checkbox-circle-line" iconColor="text-success-700" iconBg="bg-success-50" />
            <StatCard title="Kapalı" value={stats?.closed ?? 0} icon="ri-lock-line" iconColor="text-foreground-400" iconBg="bg-background-200" />
          </>
        ) : (
          <>
            <StatCard title="Açık" value={stats?.open ?? 0} icon="ri-add-circle-line" iconColor="text-primary-700" iconBg="bg-primary-50" />
            <StatCard title="Yanıt Bekleniyor" value={stats?.waiting ?? 0} icon="ri-chat-3-line" iconColor="text-accent-700" iconBg="bg-accent-50" />
            <StatCard title="Çözüldü" value={(stats?.resolved ?? 0) + (stats?.closed ?? 0)} icon="ri-checkbox-circle-line" iconColor="text-success-700" iconBg="bg-success-50" />
          </>
        )}
      </div>

      <div className="isg-card flex flex-col p-3 lg:flex-1 lg:min-h-0">
        <FilterBar
          filters={filters}
          values={filterValues}
          onChange={handleFilterChange}
          onReset={handleReset}
          onSearch={(q) => { setSearchQuery(q); setPage(1); }}
          searchPlaceholder="Ara... Talep no, konu"
          searchDebounceMs={400}
        />

        <div className="mt-3 flex-1 min-h-0">
          {loading ? (
            <div className="flex justify-center py-16">
              <Loading size="lg" text="Talepler yükleniyor..." />
            </div>
          ) : error ? (
            <ErrorState message={error} onRetry={load} />
          ) : rows.length === 0 ? (
            <EmptyState
              icon="ri-customer-service-line"
              title={hasActiveFilter ? 'Sonuç bulunamadı' : 'Henüz destek talebi bulunmuyor.'}
              description={hasActiveFilter ? 'Arama veya filtre kriterlerinize uygun talep bulunamadı.' : 'Yeni destek talebi oluşturarak başlayın.'}
              action={hasActiveFilter ? { label: 'Filtreleri Temizle', onClick: handleReset, icon: 'ri-close-line' } : (canCreate ? { label: 'Yeni Destek Talebi', onClick: openCreate, icon: 'ri-add-line' } : undefined)}
            />
          ) : (
            <>
              <div className="flex items-center justify-between mb-2">
                <p className="text-xs text-foreground-500">
                  Toplam <span className="font-semibold text-foreground-800">{count}</span> talep
                </p>
              </div>
              <div className="overflow-x-auto">
                <Table
                  data={rows}
                  columns={columns}
                  keyExtractor={(r) => r.id}
                  onRowClick={openDetail}
                  stickyHeader
                  rowActions={rowActions}
                  mobileCardRenderer={mobileCard}
                />
              </div>
              <div className="mt-3 pt-3 border-t border-background-300/25 dark:border-background-400/25">
                <Pagination
                  currentPage={page}
                  totalPages={totalPages}
                  pageSize={pageSize}
                  totalItems={count}
                  onPageChange={setPage}
                  onPageSizeChange={(size) => {
                    setPageSize(size);
                    setPage(1);
                  }}
                />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}