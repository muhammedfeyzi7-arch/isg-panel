import { useCallback, useEffect, useRef, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToastActions } from '@/hooks/useToast';
import { getInitials } from '@/components/ui/Avatar';
import PhotoLightbox from '@/components/ui/PhotoLightbox';
import { friendlyErrorMessage } from '@/lib/errorMessages';
import { downloadBlobFile } from '@/lib/downloadFile';
import { isSameFile, validateUploadFile } from '@/lib/fileUpload';
import {
  MAX_ATTACHMENT_SIZE,
  SUPPORT_ACCEPT_ATTR,
  fetchTicketDetail,
  sendMessage,
  uploadAttachment,
  getAttachmentUrl,
  friendlySupportError,
  subscribeSupportMessages,
  subscribeSupportTicket,
  formatBytes,
  type SupportTicket,
  type SupportMessage,
  type SupportAttachment,
} from '@/lib/supportService';
import {
  isImageMime,
  formatSupportDay,
  formatSupportTime,
  safeCategoryLabel,
  sameSupportDay,
} from './supportUi';

interface SupportConversationProps {
  ticket: SupportTicket | null;
  onNewTicket: () => void;
  onChanged?: () => void;
  onBack?: () => void;
  /**
   * Admin modu: kapatılmış talepte de yanıt yazılabilir (RLS admin'e izin verir)
   * ve "yeni talep oluştur" aksiyonu gösterilmez.
   */
  adminMode?: boolean;
}

/**
 * Sağ kolon: Aktif destek görüşmesi. Gerçek Supabase verisini kullanır,
 * realtime abonelik + poll fallback ile canlı güncellenir. Çözülen ticket
 * kilitlenir (yeni mesaj kabul etmez). Dosya yükleme/görüntüleme/indirme
 * desteklenir; erişim signed URL + RLS ile korunur.
 */
export default function SupportConversation({ ticket, onNewTicket, onChanged, onBack, adminMode = false }: SupportConversationProps) {
  const { profile } = useAuth();
  const { addToast } = useToastActions();
  const ticketId = ticket?.id ?? null;

  const [messages, setMessages] = useState<SupportMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState('');
  const [status, setStatus] = useState(ticket?.status ?? 'open');

  const [draft, setDraft] = useState('');
  const [pendingFiles, setPendingFiles] = useState<File[]>([]);
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');

  const [urls, setUrls] = useState<Record<string, string>>({});
  const [lightbox, setLightbox] = useState<{ url: string; name: string } | null>(null);

  const requestedRef = useRef<Set<string>>(new Set());
  const statusRef = useRef(status);
  statusRef.current = status;
  const fileInputRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const atBottomRef = useRef(true);
  const [showJump, setShowJump] = useState(false);

  const load = useCallback(
    async (silent = false) => {
      if (!ticketId) return;
      if (!silent) setLoading(true);
      setLoadError('');
      try {
        const detail = await fetchTicketDetail(ticketId);
        setMessages(detail.messages);
        if (detail.ticket.status !== statusRef.current) {
          setStatus(detail.ticket.status);
          onChanged?.();
        }
        statusRef.current = detail.ticket.status;
      } catch (e) {
        if (!silent) setLoadError(friendlyErrorMessage(e, 'Görüşme yüklenemedi.'));
      } finally {
        if (!silent) setLoading(false);
      }
    },
    [ticketId, onChanged],
  );

  // Ticket değişince state sıfırla + yükle.
  useEffect(() => {
    setMessages([]);
    setUrls({});
    requestedRef.current = new Set();
    setSendError('');
    atBottomRef.current = true;
    if (ticketId) {
      setStatus(ticket?.status ?? 'open');
      void load();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ticketId]);

  // Realtime + poll fallback — duplicate listener oluşmaz, unmount'ta temizlenir.
  useEffect(() => {
    if (!ticketId) return undefined;
    const unsubscribe = subscribeSupportMessages(ticketId, () => {
      void load(true);
    });
    const unsubscribeTicket = subscribeSupportTicket(ticketId, () => {
      void load(true);
    });
    const poll = window.setInterval(() => {
      if (document.visibilityState === 'visible') void load(true);
    }, 12000);
    return () => {
      unsubscribe();
      unsubscribeTicket();
      window.clearInterval(poll);
    };
  }, [ticketId, load]);

  // Görsel ekler için imzalı URL (yalnızca bir kez istenir).
  useEffect(() => {
    let cancelled = false;
    (async () => {
      for (const m of messages) {
        for (const a of m.attachments) {
          if (!isImageMime(a.mimeType)) continue;
          if (requestedRef.current.has(a.id)) continue;
          requestedRef.current.add(a.id);
          try {
            const url = await getAttachmentUrl(a.filePath);
            if (!cancelled) setUrls((prev) => ({ ...prev, [a.id]: url }));
          } catch {
            requestedRef.current.delete(a.id);
          }
        }
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [messages]);

  // Yeni mesaj geldiğinde: kullanıcı aşağıdaysa otomatik aşağıda kal.
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    if (atBottomRef.current) {
      el.scrollTop = el.scrollHeight;
    } else {
      setShowJump(true);
    }
  }, [messages]);

  const handleScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    const near = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    atBottomRef.current = near;
    if (near) setShowJump(false);
  };

  const scrollToBottom = () => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
    setShowJump(false);
    atBottomRef.current = true;
  };

  const pickFiles = (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = Array.from(e.target.files ?? []);
    e.target.value = '';
    const accepted: File[] = [];
    const skipped: string[] = [];
    for (const f of list) {
      if (pendingFiles.some((x) => isSameFile(x, f)) || accepted.some((x) => isSameFile(x, f))) {
        skipped.push(`“${f.name}” zaten ekli`);
        continue;
      }
      const err = validateUploadFile(f, { accept: SUPPORT_ACCEPT_ATTR, maxSize: MAX_ATTACHMENT_SIZE });
      if (err) {
        skipped.push(err);
        continue;
      }
      accepted.push(f);
    }
    if (accepted.length > 0) setPendingFiles((prev) => [...prev, ...accepted]);
    setSendError(skipped.length > 0 ? skipped.join(' • ') : '');
  };

  const handleSend = async () => {
    if (!ticketId || sending) return;
    if (!draft.trim() && pendingFiles.length === 0) return;
    setSending(true);
    setSendError('');
    try {
      const body = draft.trim() || 'Dosya gönderildi';
      const messageId = await sendMessage(ticketId, body);
      setDraft('');
      if (textareaRef.current) textareaRef.current.style.height = 'auto';

      const failed: File[] = [];
      for (const file of pendingFiles) {
        try {
          await uploadAttachment(ticketId, messageId, file);
        } catch {
          failed.push(file);
        }
      }
      setPendingFiles(failed);
      atBottomRef.current = true;
      await load(true);
      if (failed.length > 0) {
        setSendError('Mesaj gönderildi, ancak bazı dosyalar yüklenemedi. Tekrar deneyebilirsiniz.');
        addToast({ title: 'Dikkat', message: 'Bazı dosyalar yüklenemedi.', type: 'warning' });
      }
    } catch (e) {
      const friendly = friendlySupportError(e);
      setSendError(friendly);
      addToast({ title: 'Mesaj gönderilemedi', message: friendly, type: 'error' });
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      void handleSend();
    }
  };

  const handleDownload = async (att: SupportAttachment) => {
    try {
      const url = urls[att.id] ?? (await getAttachmentUrl(att.filePath));
      // Yetkili içerik fetch edilir; indirilen ad MERKEZÎ motorda anlamlı/güvenli
      // yapılır (UUID yok). Yeni sekme AÇILMAZ.
      const res = await fetch(url);
      if (!res.ok) throw new Error('fetch');
      const blob = await res.blob();
      downloadBlobFile(blob, att.fileName);
    } catch {
      addToast({ title: 'İndirilemedi', message: 'Dosya indirilemedi. Lütfen tekrar deneyin.', type: 'error' });
    }
  };

  // UI ↔ RLS tutarlılığı: RLS (`messages_insert`) kullanıcıyı yalnızca `closed`
  // durumunda bloke eder; `resolved` durumunda mesaja izin verir. Bu nedenle
  // kullanıcı tarafı besteleyici yalnızca KAPATILDI durumunda kilitlenir.
  const isClosed = status === 'closed';
  const isResolved = status === 'resolved';

  // ── Boş durum (henüz ticket yok) ─────────────────────────────
  if (!ticket) {
    return (
      <div className="flex flex-col min-h-0 flex-1">
        <ConversationHeader ticket={null} onBack={onBack} />
        <div className="flex-1 min-h-0 flex flex-col items-center justify-center px-6 text-center">
          <div className="w-20 h-20 rounded-3xl bg-background-200 dark:bg-background-300/40 flex items-center justify-center mb-5">
            <i className="ri-chat-3-line text-3xl text-foreground-400" />
          </div>
          <p className="text-sm font-semibold text-foreground-800">Henüz bir mesaj yok</p>
          <p className="text-xs text-foreground-500 mt-1.5 max-w-[17rem]">
            Destek talebi oluşturduktan sonra destek ekibi ile görüşmelerinizi burada görüntüleyebilirsiniz.
          </p>
        </div>
        <div className="flex-shrink-0 border-t border-background-300/40 dark:border-background-500/20 px-4 md:px-5 py-3">
          <Composer
            disabled
            draft=""
            sending={false}
            pendingFiles={[]}
            sendError=""
            onDraftChange={() => undefined}
            onKeyDown={() => undefined}
            onPickFiles={() => undefined}
            onRemoveFile={() => undefined}
            onSend={() => undefined}
            inputRef={fileInputRef}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-0 flex-1">
      <ConversationHeader ticket={ticket} onBack={onBack} />

      {isClosed && (
        <div className="flex-shrink-0 mx-4 md:mx-5 mt-3 rounded-xl border border-background-300/60 dark:border-background-500/25 bg-background-100 dark:bg-background-200/40 px-3.5 py-3 flex gap-2.5">
          <i className="ri-lock-2-line text-foreground-500 text-lg flex-shrink-0" />
          <div className="min-w-0">
            <p className="text-xs font-semibold text-foreground-800">Bu destek talebi kapatıldı.</p>
            <p className="text-xs text-foreground-600 dark:text-foreground-400 mt-0.5">
              Kapatılan talebe yeni mesaj gönderilemez. Yeni bir konu için yeni bir destek talebi oluşturabilirsiniz.
            </p>
            {!adminMode && (
              <button type="button" onClick={onNewTicket} className="isg-btn isg-btn-primary isg-btn-sm mt-2 whitespace-nowrap">
                <i className="ri-add-line" /> Yeni Destek Talebi Oluştur
              </button>
            )}
          </div>
        </div>
      )}

      {isResolved && (
        <div className="flex-shrink-0 mx-4 md:mx-5 mt-3 rounded-xl border border-success-500/30 bg-success-50 dark:bg-success-500/10 px-3.5 py-3 flex gap-2.5">
          <i className="ri-checkbox-circle-fill text-success-600 text-lg flex-shrink-0" />
          <div className="min-w-0">
            <p className="text-xs font-semibold text-success-700 dark:text-success-400">Talebiniz çözüme ulaştı.</p>
            <p className="text-xs text-foreground-600 dark:text-foreground-400 mt-0.5">
              Ek bir notunuz varsa yazabilirsiniz; talep yeniden değerlendirilecektir.
            </p>
          </div>
        </div>
      )}

      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="relative flex-1 min-h-0 overflow-y-auto isg-scroll-pane px-4 md:px-5 py-4 space-y-4"
      >
        {loading ? (
          <div className="space-y-3">
            <div className="h-16 bg-background-200/70 dark:bg-background-300/30 rounded-2xl animate-pulse" />
            <div className="h-16 bg-background-200/70 dark:bg-background-300/30 rounded-2xl animate-pulse ml-8" />
          </div>
        ) : loadError ? (
          <div className="py-10 text-center px-4">
            <i className="ri-error-warning-line text-3xl text-danger-600 block mb-2" />
            <p className="text-sm text-foreground-600">{loadError}</p>
            <button type="button" onClick={() => load()} className="isg-btn isg-btn-secondary isg-btn-sm mt-3 whitespace-nowrap">
              <i className="ri-refresh-line" /> Tekrar Dene
            </button>
          </div>
        ) : messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center py-10">
            <i className="ri-chat-3-line text-3xl text-foreground-400 mb-2" />
            <p className="text-sm text-foreground-500">Henüz mesaj yok.</p>
            <p className="text-xs text-foreground-400 mt-1">İlk mesajınızı yazarak görüşmeyi başlatın.</p>
          </div>
        ) : (
          messages.map((m, i) => {
            const prev = messages[i - 1];
            const showDay = !prev || !sameSupportDay(prev.createdAt, m.createdAt);
            const isSupport = m.senderRole === 'admin';
            const own = !isSupport && m.senderId === profile?.id;
            return (
              <div key={m.id}>
                {showDay && (
                  <div className="flex justify-center mb-3">
                    <span className="px-3 py-1 rounded-full bg-background-200 dark:bg-background-300/40 text-[11px] font-medium text-foreground-500">
                      {formatSupportDay(m.createdAt)}
                    </span>
                  </div>
                )}
                <div className={`flex gap-2.5 ${own ? 'flex-row-reverse' : ''}`}>
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 text-[11px] font-bold ${
                      isSupport
                        ? 'bg-primary-500/12 text-primary-600'
                        : 'bg-primary-500 text-background-50 dark:text-foreground-950'
                    }`}
                  >
                    {isSupport ? <i className="ri-customer-service-2-line text-sm" /> : getInitials(m.senderName) || '?'}
                  </div>
                  <div className={`max-w-[78%] min-w-0 flex flex-col ${own ? 'items-end' : 'items-start'}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[11px] font-semibold text-foreground-700">
                        {isSupport ? 'Destek Ekibi' : m.senderName || 'Siz'}
                      </span>
                      <span className="text-[10px] text-foreground-400">{formatSupportTime(m.createdAt)}</span>
                    </div>

                    {m.message && (
                      <div
                        className={`rounded-2xl px-3.5 py-2 text-sm leading-relaxed whitespace-pre-wrap break-words ${
                          own
                            ? 'bg-primary-500 text-background-50 dark:text-foreground-950 rounded-tr-sm'
                            : 'bg-background-200/80 dark:bg-background-300/40 text-foreground-800 rounded-tl-sm'
                        }`}
                      >
                        {m.message}
                      </div>
                    )}

                    {m.attachments.map((att) => {
                      const imgUrl = urls[att.id];
                      if (isImageMime(att.mimeType)) {
                        return (
                          <button
                            key={att.id}
                            type="button"
                            onClick={() => imgUrl && setLightbox({ url: imgUrl, name: att.fileName })}
                            className="mt-1.5 block rounded-xl overflow-hidden border border-background-300/60 dark:border-background-500/25 cursor-pointer"
                            title={att.fileName}
                          >
                            {imgUrl ? (
                              <img src={imgUrl} alt={att.fileName} className="w-44 h-32 object-cover" />
                            ) : (
                              <div className="w-44 h-32 bg-background-200 dark:bg-background-300/40 flex items-center justify-center">
                                <i className="ri-loader-4-line animate-spin text-foreground-400" />
                              </div>
                            )}
                          </button>
                        );
                      }
                      return (
                        <button
                          key={att.id}
                          type="button"
                          onClick={() => void handleDownload(att)}
                          className="mt-1.5 flex items-center gap-2.5 px-3 py-2 rounded-xl bg-background-100 dark:bg-background-200/50 border border-background-300/60 dark:border-background-500/20 w-full max-w-[16rem] text-left cursor-pointer hover:border-primary-300 transition-colors"
                          title="Dosyayı indir"
                        >
                          <span className="w-8 h-8 rounded-lg bg-primary-500/10 text-primary-600 flex items-center justify-center flex-shrink-0">
                            <i className="ri-file-3-line text-sm" />
                          </span>
                          <span className="flex-1 min-w-0">
                            <span className="block text-xs font-medium text-foreground-800 truncate">{att.fileName}</span>
                            <span className="block text-[10px] text-foreground-500 mt-0.5">{formatBytes(att.fileSize)}</span>
                          </span>
                          <i className="ri-download-2-line text-foreground-500 flex-shrink-0" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })
        )}

        {showJump && (
          <button
            type="button"
            onClick={scrollToBottom}
            className="sticky bottom-2 left-1/2 -translate-x-1/2 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary-500 text-background-50 dark:text-foreground-950 text-xs font-medium shadow-sm cursor-pointer"
          >
            <i className="ri-arrow-down-line" /> Yeni mesaj
          </button>
        )}
      </div>

      {(!isClosed || adminMode) && (
        <div className="flex-shrink-0 border-t border-background-300/40 dark:border-background-500/20 px-4 md:px-5 py-3">
          <Composer
            disabled={false}
            draft={draft}
            sending={sending}
            pendingFiles={pendingFiles}
            sendError={sendError}
            onDraftChange={(v) => setDraft(v)}
            onKeyDown={handleKeyDown}
            onPickFiles={pickFiles}
            onRemoveFile={(idx) => setPendingFiles((p) => p.filter((_, i) => i !== idx))}
            onSend={handleSend}
            inputRef={fileInputRef}
            textareaRef={textareaRef}
          />
        </div>
      )}

      {/* Görsel önizleme — sistemin TEK merkezî fotoğraf lightbox'ı (tam ekran). */}
      {lightbox && (
        <PhotoLightbox
          items={[{ src: lightbox.url, fileName: lightbox.name }]}
          index={0}
          onClose={() => setLightbox(null)}
          title={lightbox.name}
        />
      )}
    </div>
  );
}

// ── Konuşma başlığı ───────────────────────────────────────────────
function ConversationHeader({ ticket, onBack }: { ticket: SupportTicket | null; onBack?: () => void }) {
  return (
    <div className="flex-shrink-0 px-4 md:px-5 py-3.5 border-b border-background-300/40 dark:border-background-500/20 flex items-center gap-3">
      {onBack && (
        <button
          type="button"
          onClick={onBack}
          aria-label="Geri"
          className="lg:hidden w-8 h-8 flex items-center justify-center rounded-lg text-foreground-500 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer flex-shrink-0"
        >
          <i className="ri-arrow-left-line text-lg" />
        </button>
      )}
      <span className="w-10 h-10 rounded-xl bg-primary-500/10 text-primary-600 flex items-center justify-center flex-shrink-0">
        <i className="ri-customer-service-2-line text-lg" />
      </span>
      <div className="min-w-0">
        <p className="text-sm font-semibold text-foreground-950 truncate">Destek Görüşmesi</p>
        <p className="text-xs text-foreground-500 truncate">
          {ticket
            ? `${ticket.ticketNo} • ${safeCategoryLabel(ticket.category)}`
            : 'Talebiniz oluşturulduktan sonra destek ekibi buradan görüşeceksiniz.'}
        </p>
      </div>
    </div>
  );
}

// ── Mesaj kutusu ─────────────────────────────────────────────────
interface ComposerProps {
  disabled: boolean;
  draft: string;
  sending: boolean;
  pendingFiles: File[];
  sendError: string;
  onDraftChange: (v: string) => void;
  onKeyDown: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
  onPickFiles: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onRemoveFile: (idx: number) => void;
  onSend: () => void;
  inputRef: React.RefObject<HTMLInputElement | null>;
  textareaRef?: React.RefObject<HTMLTextAreaElement | null>;
}

function Composer({
  disabled,
  draft,
  sending,
  pendingFiles,
  sendError,
  onDraftChange,
  onKeyDown,
  onPickFiles,
  onRemoveFile,
  onSend,
  inputRef,
  textareaRef,
}: ComposerProps) {
  const autoGrow = (e: React.FormEvent<HTMLTextAreaElement>) => {
    const el = e.currentTarget;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 112)}px`;
  };

  return (
    <>
      {pendingFiles.length > 0 && (
        <div className="mb-2 flex flex-wrap gap-1.5">
          {pendingFiles.map((f, idx) => (
            <span
              key={`${f.name}-${idx}-${f.lastModified}`}
              className="inline-flex items-center gap-1.5 pl-2 pr-1 py-1 rounded-lg bg-background-100 dark:bg-background-200/50 border border-background-300/60 dark:border-background-500/20 text-[11px] text-foreground-700"
            >
              <i className="ri-file-line" />
              <span className="max-w-[8rem] truncate">{f.name}</span>
              <button
                type="button"
                onClick={() => onRemoveFile(idx)}
                className="w-4 h-4 flex items-center justify-center rounded text-foreground-400 hover:text-danger-600 cursor-pointer"
                aria-label="Kaldır"
              >
                <i className="ri-close-line" />
              </button>
            </span>
          ))}
        </div>
      )}

      <div className="flex items-end gap-2">
        <button
          type="button"
          onClick={() => !disabled && inputRef.current?.click()}
          disabled={disabled}
          aria-label="Dosya ekle"
          className="w-9 h-9 flex items-center justify-center rounded-lg text-foreground-500 hover:text-foreground-700 hover:bg-background-200 dark:hover:bg-background-300/40 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0"
        >
          <i className="ri-attachment-2 text-lg" />
        </button>
        <input
          ref={inputRef}
          type="file"
          multiple
          accept={SUPPORT_ACCEPT_ATTR}
          className="hidden"
          onChange={onPickFiles}
          disabled={disabled}
        />
        <textarea
          ref={textareaRef}
          rows={1}
          value={draft}
          disabled={disabled}
          onChange={(e) => onDraftChange(e.target.value)}
          onInput={autoGrow}
          onKeyDown={onKeyDown}
          placeholder="Mesajınızı yazın…"
          className="isg-input flex-1 resize-none max-h-28 py-2 text-sm disabled:opacity-60"
        />
        <button
          type="button"
          onClick={onSend}
          disabled={disabled || sending || (!draft.trim() && pendingFiles.length === 0)}
          aria-label="Gönder"
          className="w-9 h-9 flex items-center justify-center rounded-lg bg-primary-500 text-background-50 dark:text-foreground-950 hover:bg-primary-600 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
        >
          {sending ? (
            <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
          ) : (
            <i className="ri-send-plane-fill" />
          )}
        </button>
      </div>

      {!disabled && (
        <p className="mt-1.5 text-[10px] text-foreground-400">
          Maks. {Math.round(MAX_ATTACHMENT_SIZE / (1024 * 1024))} MB / dosya • JPG, PNG, PDF, DOC, DOCX, XLS, XLSX, ZIP, RAR, MP4 vb.
        </p>
      )}

      {sendError && (
        <p className="mt-1.5 text-[11px] text-danger-600 flex items-start gap-1">
          <i className="ri-error-warning-line mt-px flex-shrink-0" />
          <span className="break-words">{sendError}</span>
        </p>
      )}
    </>
  );
}