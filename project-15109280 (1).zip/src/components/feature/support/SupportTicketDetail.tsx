import { useCallback, useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToastActions } from '@/hooks/useToast';
import { useConfirmActions } from '@/hooks/useConfirm';
import Select from '@/components/ui/Select';
import SupportConversation from './SupportConversation';
import {
  SUPPORT_STATUS_OPTIONS,
  SUPPORT_PRIORITY_OPTIONS,
  statusLabel,
  priorityLabel,
  updateTicketStatus,
  updateTicketPriority,
  type SupportTicket,
} from '@/lib/supportService';

interface SupportTicketDetailProps {
  ticket: SupportTicket;
  onClose: () => void;
  onChanged?: () => void;
}

/**
 * Admin destek talebi detay modalı. Görsel olarak kullanıcı tarafındaki
 * (OSGB/Firma/Uzman/Hekim) görüşme tasarımıyla BİREBİR aynıdır: aynı
 * `SupportConversation` bileşeni kullanılır (gün ayraçları, sağ/sol balonlar,
 * dosya görüntüleme/indirme, realtime). Admin'e özel tek fark, modal üstündeki
 * Durum / Öncelik / Talebi Kapat yönetim çubuğudur.
 *
 * NOT: Bu bileşen yalnızca görsel + yönetim katmanıdır; veri akışı ve yetki
 * mevcut service fonksiyonları üzerinden aynen yürütülür.
 */
export default function SupportTicketDetail({ ticket, onClose: _onClose, onChanged }: SupportTicketDetailProps) {
  const { profile } = useAuth();
  const { addToast } = useToastActions();
  const { confirm } = useConfirmActions();

  const isAdmin = profile?.role === 'admin';

  const [status, setStatus] = useState(ticket.status);
  const [priority, setPriority] = useState(ticket.priority);
  const [conversationKey, setConversationKey] = useState(0);

  const noop = useCallback(() => undefined, []);

  const handleStatusChange = async (value: string) => {
    try {
      await updateTicketStatus(ticket.id, value);
      setStatus(value);
      setConversationKey((k) => k + 1);
      onChanged?.();
      addToast({ title: 'Durum güncellendi', message: `Durum: ${statusLabel(value)}`, type: 'success' });
    } catch {
      addToast({ title: 'Hata', message: 'Durum güncellenemedi.', type: 'error' });
    }
  };

  const handlePriorityChange = async (value: string) => {
    try {
      await updateTicketPriority(ticket.id, value);
      setPriority(value);
      addToast({ title: 'Öncelik güncellendi', message: `Öncelik: ${priorityLabel(value)}`, type: 'success' });
    } catch {
      addToast({ title: 'Hata', message: 'Öncelik güncellenemedi.', type: 'error' });
    }
  };

  const handleClose = () => {
    confirm({
      title: 'Talebi Kapat',
      message: `${ticket.ticketNo} numaralı talebi kapatmak istediğinize emin misiniz?`,
      variant: 'warning',
      confirmText: 'Evet, Kapat',
      cancelText: 'Vazgeç',
      onConfirm: async () => {
        try {
          await updateTicketStatus(ticket.id, 'closed');
          setStatus('closed');
          setConversationKey((k) => k + 1);
          onChanged?.();
          addToast({ title: 'Talep kapatıldı', message: `${ticket.ticketNo} kapatıldı.`, type: 'success' });
        } catch {
          addToast({ title: 'Hata', message: 'Talep kapatılamadı.', type: 'error' });
        }
      },
    });
  };

  return (
    <div className="flex flex-col min-h-0 h-full">
      {isAdmin && (
        <div className="flex-shrink-0 border-b border-background-300/40 dark:border-background-500/20 px-4 md:px-5 py-3 bg-background-100/70 dark:bg-background-200/30">
          <div className="flex flex-col sm:flex-row sm:items-end gap-3">
            <div className="flex-1 min-w-0">
              <Select
                label="Durum"
                options={SUPPORT_STATUS_OPTIONS}
                value={status}
                onChange={(e) => handleStatusChange(e.target.value)}
              />
            </div>
            <div className="flex-1 min-w-0">
              <Select
                label="Öncelik"
                options={SUPPORT_PRIORITY_OPTIONS}
                value={priority}
                onChange={(e) => handlePriorityChange(e.target.value)}
              />
            </div>
            {status !== 'closed' && (
              <button
                type="button"
                onClick={handleClose}
                className="isg-btn isg-btn-secondary isg-btn-sm whitespace-nowrap flex-shrink-0"
              >
                <i className="ri-close-circle-line" /> Talebi Kapat
              </button>
            )}
          </div>
        </div>
      )}

      <SupportConversation
        key={conversationKey}
        ticket={ticket}
        onNewTicket={noop}
        onChanged={onChanged}
        adminMode
      />
    </div>
  );
}