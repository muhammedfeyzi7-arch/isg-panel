import { useRef, useState } from 'react';
import { formatBytes, MAX_ATTACHMENT_SIZE, SUPPORT_ACCEPT_ATTR } from '@/lib/supportService';
import { isSameFile, validateUploadFile } from '@/lib/fileUpload';

const ACCEPT_ATTR = SUPPORT_ACCEPT_ATTR;

interface AttachmentPickerProps {
  files: File[];
  onChange: (files: File[]) => void;
  disabled?: boolean;
}

/**
 * Ortak dosya seçici (destek mesajları / destek talebi oluşturma).
 * Boyut / tür / boş dosya kontrolü yapar, mükerrer dosyaları eler.
 * Gerçek Supabase Storage'a yüklemek üzere RAW File nesnelerini tutar
 * (sahte yükleme/URL yoktur). Yükleme, gönderim anında service katmanında yapılır.
 */
export default function AttachmentPicker({ files, onChange, disabled }: AttachmentPickerProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [validationError, setValidationError] = useState('');

  const handlePick = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0) return;
    const picked = Array.from(e.target.files);
    const accepted: File[] = [];
    const skipped: string[] = [];

    for (const f of picked) {
      if (files.some((x) => isSameFile(x, f)) || accepted.some((x) => isSameFile(x, f))) {
        skipped.push(`“${f.name}” zaten ekli`);
        continue;
      }
      // Uzantı + MIME + boyut doğrulaması tek merkezden (src/lib/fileUpload.ts).
      const err = validateUploadFile(f, { accept: ACCEPT_ATTR, maxSize: MAX_ATTACHMENT_SIZE });
      if (err) {
        skipped.push(err);
        continue;
      }
      accepted.push(f);
    }

    onChange([...files, ...accepted]);
    setValidationError(skipped.length > 0 ? `Atlandı: ${skipped.join(', ')}` : '');
    e.target.value = '';
  };

  const removeFile = (index: number) => {
    onChange(files.filter((_, i) => i !== index));
  };

  return (
    <div className="w-full">
      <button
        type="button"
        onClick={() => !disabled && inputRef.current?.click()}
        disabled={disabled}
        className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-md bg-background-100 border border-background-200/80 text-foreground-600 hover:bg-background-200 transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
      >
        <i className="ri-attachment-2 text-sm" />
        Dosya Ekle
      </button>
      <input
        ref={inputRef}
        type="file"
        multiple
        accept={ACCEPT_ATTR}
        className="hidden"
        onChange={handlePick}
        disabled={disabled}
      />

      {validationError && (
        <p className="mt-1.5 text-[11px] text-warning-600 flex items-start gap-1">
          <i className="ri-error-warning-line mt-px" />
          {validationError}
        </p>
      )}

      {files.length > 0 && (
        <ul className="mt-2 space-y-1.5">
          {files.map((file, idx) => (
            <li
              key={`${file.name}-${idx}`}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-md bg-background-50 border border-background-200/60"
            >
              <i className="ri-file-line text-foreground-400 text-sm flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-foreground-800 truncate">{file.name}</p>
                <p className="text-[10px] text-foreground-400">{formatBytes(file.size)}</p>
              </div>
              <button
                type="button"
                onClick={() => removeFile(idx)}
                className="w-6 h-6 flex items-center justify-center rounded text-foreground-400 hover:text-danger-600 hover:bg-danger-50 transition-colors cursor-pointer flex-shrink-0"
                aria-label="Dosyayı kaldır"
              >
                <i className="ri-close-line text-sm" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}