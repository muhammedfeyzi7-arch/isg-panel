import { useState } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToastActions } from '@/hooks/useToast';
import Input from '@/components/ui/Input';
import Textarea from '@/components/ui/Textarea';
import Select from '@/components/ui/Select';
import SupportFilePicker from './SupportFilePicker';
import {
  SUPPORT_CATEGORY_OPTIONS,
  createTicket,
  uploadAttachment,
  friendlySupportError,
  defaultPriorityForCategory,
} from '@/lib/supportService';

const MAX_SUBJECT = 150;
const MAX_MESSAGE = 2000;

interface SupportTicketFormProps {
  onCreated: (ticketId: string, ticketNo: string) => void;
}

/**
 * "Yeni Destek Talebi" formu (modal sol kolonu).
 * Kullanıcıdan YALNIZCA gerçekten gereken bilgi istenir. Öncelik KULLANICIYA
 * SORULMAZ; kategoriye göre sunucu-taraflı bir başlangıç değeri atanır.
 * Gerçek Supabase kaydı oluşturur; sahte başarı göstermez, double-submit engeller.
 */
export default function SupportTicketForm({ onCreated }: SupportTicketFormProps) {
  const { profile } = useAuth();
  const { addToast } = useToastActions();

  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('');
  const [message, setMessage] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const canSubmit = subject.trim() !== '' && category !== '' && message.trim() !== '' && !submitting;

  const handleSubmit = async () => {
    if (submitting) return;
    setError('');
    if (!subject.trim()) { setError('Lütfen talebinizin konusunu yazın.'); return; }
    if (!category) { setError('Lütfen bir kategori seçin.'); return; }
    if (!message.trim()) { setError('Lütfen sorununuzu detaylı şekilde açıklayın.'); return; }
    if (!profile) { setError('Oturumunuz sona ermiş görünüyor. Lütfen sayfayı yenileyip yeniden giriş yapın.'); return; }

    setSubmitting(true);
    try {
      const result = await createTicket({
        subject: subject.trim(),
        category,
        priority: defaultPriorityForCategory(category),
        message: message.trim(),
        osgbId: profile.osgbId,
      });

      // İlk mesaja dosyaları bağla (varsa). Dosya hatası talebi bozmaz.
      let failed = 0;
      for (const file of files) {
        try {
          await uploadAttachment(result.id, result.messageId, file);
        } catch {
          failed += 1;
        }
      }

      addToast({
        title: 'Destek talebiniz oluşturuldu',
        message: `${result.ticketNo} numaralı talebiniz destek ekibimize iletildi. Yanıtları bu ekran üzerinden takip edebilirsiniz.`,
        type: 'success',
      });
      if (failed > 0) {
        addToast({
          title: 'Dikkat',
          message: `${failed} dosya yüklenemedi. Görüşme ekranından tekrar gönderebilirsiniz.`,
          type: 'warning',
        });
      }

      setSubject('');
      setCategory('');
      setMessage('');
      setFiles([]);
      onCreated(result.id, result.ticketNo);
    } catch (e) {
      const friendly = friendlySupportError(e);
      setError(friendly);
      addToast({ title: 'Talep oluşturulamadı', message: friendly, type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex flex-col min-h-0 flex-1">
      {/* Kaydırılabilir orta alan (footer sabit kalır) */}
      <div className="flex-1 min-h-0 overflow-y-auto isg-scroll-pane px-4 md:px-5 py-4 space-y-4">
        <div className="rounded-xl bg-primary-50 dark:bg-primary-500/10 border border-primary-200/70 dark:border-primary-500/20 px-3.5 py-3 flex gap-2.5">
          <span className="w-5 h-5 rounded-full bg-primary-500 text-inverse text-[11px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
            i
          </span>
          <div className="min-w-0">
            <p className="text-xs font-semibold text-primary-800 dark:text-primary-300">Yeni bir konuda destek talebi oluşturun.</p>
            <p className="text-xs text-primary-700/80 dark:text-primary-300/70 mt-0.5">
              Talebiniz oluşturulduktan sonra destek ekibi ile bu ekran üzerinden görüşmeye devam edeceksiniz.
            </p>
          </div>
        </div>

        <Input
          label="Konu"
          required
          value={subject}
          maxLength={MAX_SUBJECT}
          onChange={(e) => setSubject(e.target.value)}
          placeholder="Talebinizin konusunu yazın"
          helpText={`${subject.length}/${MAX_SUBJECT}`}
        />

        <Select
          label="Kategori"
          required
          options={SUPPORT_CATEGORY_OPTIONS}
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          placeholder="Kategori seçin"
        />

        <Textarea
          label="Açıklama"
          required
          value={message}
          maxLength={MAX_MESSAGE}
          rows={4}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Sorununuzu detaylı şekilde açıklayın. Mümkünse aldığınız hata mesajını ve izlediğiniz adımları belirtin."
        />

        <div>
          <p className="mb-1.5 text-sm font-medium text-foreground-800">Dosya Ekleme</p>
          <SupportFilePicker files={files} onChange={setFiles} disabled={submitting} />
        </div>

        {error && (
          <p className="text-xs text-danger-600 flex items-start gap-1.5">
            <i className="ri-error-warning-line mt-px flex-shrink-0" />
            <span className="break-words">{error}</span>
          </p>
        )}
      </div>

      {/* Sabit footer */}
      <div className="flex-shrink-0 border-t border-background-300/40 dark:border-background-500/20 px-4 md:px-5 py-3 flex items-center justify-between gap-3">
        <p className="hidden sm:flex items-center gap-1.5 text-[11px] text-foreground-500">
          <i className="ri-lock-2-line" /> Talebiniz yalnızca destek ekibi tarafından görüntülenir.
        </p>
        <button
          type="button"
          onClick={handleSubmit}
          disabled={!canSubmit}
          className="isg-btn isg-btn-primary isg-btn-sm whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {submitting ? (
            <span className="inline-block w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" aria-hidden="true" />
          ) : (
            <i className="ri-send-plane-fill" />
          )}
          Destek Talebi Oluştur
        </button>
      </div>
    </div>
  );
}