import Badge from '@/components/ui/Badge';
import EmptyState from '@/components/ui/EmptyState';
import Loading from '@/components/ui/Loading';
import type { SupportTicket } from '@/lib/supportService';
import {
  isResolvedStatus,
  safeCategoryLabel,
  userStatusLabel,
  userStatusVariant,
  formatSupportTicketDate,
} from './supportUi';

interface SupportHistoryListProps {
  tickets: SupportTicket[];
  loading: boolean;
  error: string;
  activeId: string | null;
  onSelect: (ticket: SupportTicket) => void;
  onRetry: () => void;
}

/**
 * "Geçmiş Destek Talepleri" sekmesi — modal içinde KOMPAKT liste.
 * Eski sidebar listeleme ekranının kopyası DEĞİLDİR; satır seçilince konuşma
 * aynı modal içindeki sağ panelde açılır (ayrı sayfa/modal açılmaz).
 */
export default function SupportHistoryList({
  tickets,
  loading,
  error,
  activeId,
  onSelect,
  onRetry,
}: SupportHistoryListProps) {
  if (loading) {
    return (
      <div className="flex justify-center py-16">
        <Loading size="lg" text="Talepler yükleniyor..." />
      </div>
    );
  }

  if (error) {
    return (
      <div className="py-12 text-center px-4">
        <i className="ri-error-warning-line text-3xl text-danger-600 block mb-2" />
        <p className="text-sm text-foreground-600">{error}</p>
        <button type="button" onClick={onRetry} className="isg-btn isg-btn-secondary isg-btn-sm mt-3 whitespace-nowrap">
          <i className="ri-refresh-line" /> Tekrar Dene
        </button>
      </div>
    );
  }

  if (tickets.length === 0) {
    return (
      <EmptyState
        icon="ri-customer-service-line"
        title="Henüz destek talebiniz bulunmuyor."
        description="Yeni bir destek talebi oluşturarak destek ekibimizle iletişime geçebilirsiniz."
      />
    );
  }

  return (
    <div className="space-y-2">
      {tickets.map((t) => {
        const active = t.id === activeId;
        return (
          <button
            key={t.id}
            type="button"
            onClick={() => onSelect(t)}
            className={`w-full text-left rounded-xl border px-3.5 py-3 transition-colors cursor-pointer ${
              active
                ? 'border-primary-300 dark:border-primary-500/40 bg-primary-50/60 dark:bg-primary-500/10'
                : 'border-background-300/60 dark:border-background-500/20 bg-background-100 dark:bg-background-200/40 hover:bg-background-200/60 dark:hover:bg-background-300/30'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="text-[11px] font-semibold text-foreground-500">{t.ticketNo}</span>
              <Badge variant={userStatusVariant(t.status)} size="sm">{userStatusLabel(t.status)}</Badge>
            </div>
            <p className="text-sm font-medium text-foreground-900 mt-1 truncate">{t.subject}</p>
            <div className="flex items-center justify-between gap-2 mt-1.5">
              <span className="text-[11px] text-foreground-500 truncate">{safeCategoryLabel(t.category)}</span>
              <span className="text-[11px] text-foreground-400 whitespace-nowrap flex items-center gap-1">
                <i className={isResolvedStatus(t.status) ? 'ri-checkbox-circle-line' : 'ri-time-line'} />
                {formatSupportTicketDate(t.updatedAt)}
              </span>
            </div>
          </button>
        );
      })}
    </div>
  );
}