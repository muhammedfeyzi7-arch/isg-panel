import { useEffect } from 'react';

/**
 * Global Mobile Viewport / Keyboard Engine — İSGDenetim kalıcı standardı.
 *
 * Tüm panellerde ortak çalışır, tek kurulum. Yaptıkları:
 *
 * 1. `visualViewport` API ile mobil klavye açılışını tespit eder (polling YOK,
 *    yalnızca resize/scroll event listener'ları — hepsi temizlenir, leak yok).
 *    Klavye tespiti `requestAnimationFrame` ile throttle edilir; klavye animasyonu
 *    sırasında art arda gelen resize/scroll event'ları tek frame'e sıkıştırılır,
 *    gereksiz layout/reflow yükü oluşmaz.
 * 2. Klavye açıkken <html> elementine `keyboard-open` class'ı ekler; bu class
 *    global CSS'te fixed bottom nav'ı gizler → input/action alanı kapanmaz.
 * 3. Focus olan input/textarea/select klavyenin altında kaldıysa (native
 *    davranış onu görünüre getirmediyse) anında (smooth değil) görünür alana
 *    getirir. Smooth scroll kullanılmaz → klavye animasyonuyla çakışan uzun
 *    animasyon/jank oluşmaz.
 */
export default function ViewportManager() {
  useEffect(() => {
    const vv = window.visualViewport;
    let rafId: number | null = null;
    let pending = false;

    const applyKeyboardState = () => {
      if (!vv) return;
      // Klavye açıldığında visualViewport.height, window.innerHeight'ın
      // belirgin şekilde altına düşer. Eşik, küçük resize'ları yanlış pozitif
      // saymamak için 120px tutulur.
      const keyboardOpen = window.innerHeight - vv.height > 120;
      document.documentElement.classList.toggle('keyboard-open', keyboardOpen);
    };

    const updateKeyboard = () => {
      if (pending) return;
      pending = true;
      rafId = window.requestAnimationFrame(() => {
        pending = false;
        rafId = null;
        applyKeyboardState();
      });
    };

    const handleFocusIn = (e: FocusEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target || !vv) return;
      const tag = target.tagName?.toLowerCase();
      const isFormField =
        tag === 'input' || tag === 'textarea' || tag === 'select' || target.isContentEditable;
      if (!isFormField) return;

      // Klavye animasyonunun oturmasını bekle, sonra kontrol et.
      window.setTimeout(() => {
        if (document.activeElement !== target) return;
        const rect = target.getBoundingClientRect();
        const vvTop = vv.offsetTop;
        const vvBottom = vv.offsetTop + vv.height;
        // Input klavyenin üst sınırının altında kalıyorsa görünür alana getir.
        if (rect.bottom > vvBottom - 8 || rect.top < vvTop) {
          target.scrollIntoView({ block: 'nearest' });
        }
      }, 320);
    };

    if (vv) {
      updateKeyboard();
      vv.addEventListener('resize', updateKeyboard);
      vv.addEventListener('scroll', updateKeyboard);
    }
    window.addEventListener('resize', updateKeyboard);
    document.addEventListener('focusin', handleFocusIn);

    return () => {
      if (rafId !== null) window.cancelAnimationFrame(rafId);
      if (vv) {
        vv.removeEventListener('resize', updateKeyboard);
        vv.removeEventListener('scroll', updateKeyboard);
      }
      window.removeEventListener('resize', updateKeyboard);
      document.removeEventListener('focusin', handleFocusIn);
      document.documentElement.classList.remove('keyboard-open');
    };
  }, []);

  // Native context menu suppression — dokunmatik uzun basınca tarayıcının kendi
  // menüsü (iOS callout / Android long-press menu) UI chrome üzerinde açılmaz.
  // Düzenlenebilir içerik (input/textarea/select/contenteditable) ve aktif metin
  // seçimi (copy menüsü) DOKUNULMADAN bırakılır — kullanıcı metin kopyalayabilir.
  useEffect(() => {
    const handleContextMenu = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;

      // Aktif metin seçimi varsa (copy için) native menü kalsın.
      const selection = window.getSelection();
      if (selection && !selection.isCollapsed) return;

      const tag = target.tagName?.toLowerCase();
      const editable =
        tag === 'input' ||
        tag === 'textarea' ||
        tag === 'select' ||
        target.isContentEditable;
      if (editable) return;
      if (target.closest('[contenteditable="true"]')) return;

      e.preventDefault();
    };

    document.addEventListener('contextmenu', handleContextMenu);
    return () => document.removeEventListener('contextmenu', handleContextMenu);
  }, []);

  return null;
}