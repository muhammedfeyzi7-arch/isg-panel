import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';
import {
  SESSION_IDLE_TIMEOUT_MS,
  SESSION_MAX_DURATION_MS,
  beginSession,
  checkSessionExpiry,
  clearSessionEnded,
  clearSessionTimes,
  getLastActivityAt,
  markSessionEnded,
  readSessionEndedAt,
  touchActivity,
} from '@/lib/sessionPolicy';
import type { SessionEndReason } from '@/lib/sessionPolicy';

/** Kontrol sıklığı: süre aşımını en geç bu kadar sonra yakalarız. */
const CHECK_INTERVAL_MS = 60 * 1000;

/** Sekmeler arası bitiş işareti için dinlenen anahtar. */
const ENDED_STORAGE_KEY = 'isg:session:ended-at';

/**
 * Merkezi oturum politikası bekçisi.
 *
 * - 12 saat hareketsizlik / 7 gün maksimum süre dolduğunda:
 *     1) sunucudan çıkış yapılır (refresh token sunucuda iptal edilir)
 *     2) yerel oturum bilgisi temizlenir
 *     3) kullanıcı /login?reason=... adresine yönlendirilir
 * - Bir sekme oturumu kapattığında diğer sekmeler 'storage' olayı ile aynı
 *   davranışı uygular (sekmeler arası senkron).
 * - Sayfa yenilendiğinde / uygulama yeniden açıldığında süreler localStorage'dan
 *   okunur; böylece "yenile ile süre sıfırlama" mümkün değildir.
 *
 * Görsel çıktısı yoktur (null döner).
 */
export default function SessionPolicyGuard() {
  const navigate = useNavigate();
  const { signOut } = useAuth();
  const finishingRef = useRef(false);

  useEffect(() => {
    // Bu tarayıcı oturumu için başlangıç/etkinlik damgalarını hazırla.
    beginSession();
    clearSessionEnded();

    const finish = async (reason: SessionEndReason) => {
      if (finishingRef.current) return;
      finishingRef.current = true;
      // Diğer sekmelere "oturum bitti" bilgisini yaz.
      markSessionEnded(reason);
      try {
        await signOut();
      } catch {
        /* çıkış hatası yönlendirmeyi engellemez */
      }
      clearSessionTimes();
      navigate(`/login?reason=${reason}`, { replace: true });
    };

    const check = () => {
      const reason = checkSessionExpiry();
      if (reason) void finish(reason);
    };

    // ── Etkinlik takibi ──
    // Yüksek frekanslı olaylar throttle'lı yazılır (30 sn). "force" yalnızca
    // sekme görünür olduğunda kullanılır: kullanıcı geri döndüyse aktif sayılır.
    const onActivity = () => touchActivity();
    const onVisible = () => {
      if (document.visibilityState !== 'visible') {
        check();
        return;
      }
      const last = getLastActivityAt();
      // Sekme arka planda uzun süre kaldıysa, öne gelince önce süreyi doğrula;
      // sonra (hâlâ geçerliyse) etkinliği işaretle.
      if (last !== null && Date.now() - last >= SESSION_IDLE_TIMEOUT_MS) {
        void finish('idle');
        return;
      }
      check();
      touchActivity(true);
    };

    const activityEvents: Array<'pointerdown' | 'keydown' | 'wheel' | 'touchstart'> = ['pointerdown', 'keydown', 'wheel', 'touchstart'];
    activityEvents.forEach((evt) => document.addEventListener(evt, onActivity, { passive: true }));
    document.addEventListener('visibilitychange', onVisible);

    // ── Sekmeler arası senkron ──
    // Başka bir sekme oturumu kapattıysa (idle / 7 gün / tüm cihazlar) burada da kapat.
    const onStorage = (event: StorageEvent) => {
      if (event.key !== ENDED_STORAGE_KEY || !event.newValue) return;
      if (finishingRef.current) return;
      finishingRef.current = true;
      clearSessionTimes();
      void signOut().catch(() => {});
      navigate('/login?reason=idle', { replace: true });
    };
    window.addEventListener('storage', onStorage);

    // Sayfa açıldığında diğer sekmelerin bıraktığı bitiş işareti varsa uygula.
    if (readSessionEndedAt() !== null) {
      finish('idle');
    }

    // ── Oturum olayları ──
    // Yeni giriş yapıldığında sayaçlar sıfırlanır; token yenilemesi SIFIRLAMAZ
    // (7 günlük mutlak sınır korunur).
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'SIGNED_IN') beginSession(true);
      if (event === 'SIGNED_OUT') clearSessionTimes();
    });

    const interval = window.setInterval(check, CHECK_INTERVAL_MS);

    // Maksimum süre için kritik zamanlayıcı: son kontrolü beklemeden tam sınırda kapat.
    const startedAt = Number(localStorage.getItem('isg:session:started-at'));
    const maxTimer =
      Number.isFinite(startedAt) && startedAt > 0
        ? window.setTimeout(check, Math.max(1000, startedAt + SESSION_MAX_DURATION_MS - Date.now()))
        : undefined;

    return () => {
      activityEvents.forEach((evt) => document.removeEventListener(evt, onActivity));
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('storage', onStorage);
      sub.subscription.unsubscribe();
      window.clearInterval(interval);
      if (maxTimer) window.clearTimeout(maxTimer);
    };
  }, [navigate, signOut]);

  return null;
}