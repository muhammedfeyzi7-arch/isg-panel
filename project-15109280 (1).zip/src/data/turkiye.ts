export interface Ilce {
  value: string;
  label: string;
}

export interface Il {
  value: string;
  label: string;
  ilceler: Ilce[];
}

/**
 * Türkiye'nin 81 ilinin ve tüm ilçelerinin merkezi veri kaynağı.
 * İl/ilçe seçimi gereken tüm formlarda (Firma, OSGB, Personel, Uzman,
 * Hekim, Kullanıcı, Adres) bu veri kullanılır. Başka yerde il listesi
 * tanımlanmaz.
 */
export const iller: Il[] = [
  { value: 'Adana', label: 'Adana', ilceler: ['Aladağ', 'Ceyhan', 'Çukurova', 'Feke', 'İmamoğlu', 'Karaisalı', 'Karataş', 'Kozan', 'Pozantı', 'Saimbeyli', 'Sarıçam', 'Seyhan', 'Tufanbeyli', 'Yumurtalık', 'Yüreğir'].map(toIlce) },
  { value: 'Adıyaman', label: 'Adıyaman', ilceler: ['Besni', 'Çelikhan', 'Gerger', 'Gölbaşı', 'Kahta', 'Merkez', 'Samsat', 'Sincik', 'Tut'].map(toIlce) },
  { value: 'Afyonkarahisar', label: 'Afyonkarahisar', ilceler: ['Başmakçı', 'Bayat', 'Bolvadin', 'Çay', 'Çobanlar', 'Dazkırı', 'Dinar', 'Emirdağ', 'Evciler', 'Hocalar', 'İhsaniye', 'İscehisar', 'Kızılören', 'Merkez', 'Sandıklı', 'Sinanpaşa', 'Sultandağı', 'Şuhut'].map(toIlce) },
  { value: 'Ağrı', label: 'Ağrı', ilceler: ['Diyadin', 'Doğubayazıt', 'Eleşkirt', 'Hamur', 'Merkez', 'Patnos', 'Taşlıçay', 'Tutak'].map(toIlce) },
  { value: 'Aksaray', label: 'Aksaray', ilceler: ['Ağaçören', 'Eskil', 'Gülağaç', 'Güzelyurt', 'Merkez', 'Ortaköy', 'Sarıyahşi', 'Sultanhanı'].map(toIlce) },
  { value: 'Amasya', label: 'Amasya', ilceler: ['Göynücek', 'Gümüşhacıköy', 'Hamamözü', 'Merkez', 'Merzifon', 'Suluova', 'Taşova'].map(toIlce) },
  { value: 'Ankara', label: 'Ankara', ilceler: ['Akyurt', 'Altındağ', 'Ayaş', 'Bala', 'Beypazarı', 'Çamlıdere', 'Çankaya', 'Çubuk', 'Elmadağ', 'Etimesgut', 'Evren', 'Gölbaşı', 'Güdül', 'Haymana', 'Kahramankazan', 'Kalecik', 'Keçiören', 'Kızılcahamam', 'Mamak', 'Nallıhan', 'Polatlı', 'Pursaklar', 'Sincan', 'Şereflikoçhisar', 'Yenimahalle'].map(toIlce) },
  { value: 'Antalya', label: 'Antalya', ilceler: ['Akseki', 'Aksu', 'Alanya', 'Demre', 'Döşemealtı', 'Elmalı', 'Finike', 'Gazipaşa', 'Gündoğmuş', 'İbradı', 'Kaş', 'Kemer', 'Kepez', 'Konyaaltı', 'Korkuteli', 'Kumluca', 'Manavgat', 'Muratpaşa', 'Serik'].map(toIlce) },
  { value: 'Ardahan', label: 'Ardahan', ilceler: ['Çıldır', 'Damal', 'Göle', 'Hanak', 'Merkez', 'Posof'].map(toIlce) },
  { value: 'Artvin', label: 'Artvin', ilceler: ['Ardanuç', 'Arhavi', 'Borçka', 'Hopa', 'Kemalpaşa', 'Merkez', 'Murgul', 'Şavşat', 'Yusufeli'].map(toIlce) },
  { value: 'Aydın', label: 'Aydın', ilceler: ['Bozdoğan', 'Buharkent', 'Çine', 'Didim', 'Efeler', 'Germencik', 'İncirliova', 'Karacasu', 'Karpuzlu', 'Koçarlı', 'Köşk', 'Kuşadası', 'Kuyucak', 'Nazilli', 'Söke', 'Sultanhisar', 'Yenipazar'].map(toIlce) },
  { value: 'Balıkesir', label: 'Balıkesir', ilceler: ['Altıeylül', 'Ayvalık', 'Balya', 'Bandırma', 'Bigadiç', 'Burhaniye', 'Dursunbey', 'Edremit', 'Erdek', 'Gömeç', 'Gönen', 'Havran', 'İvrindi', 'Karesi', 'Kepsut', 'Manyas', 'Marmara', 'Savaştepe', 'Sındırgı', 'Susurluk'].map(toIlce) },
  { value: 'Bartın', label: 'Bartın', ilceler: ['Amasra', 'Kurucaşile', 'Merkez', 'Ulus'].map(toIlce) },
  { value: 'Batman', label: 'Batman', ilceler: ['Beşiri', 'Gercüş', 'Hasankeyf', 'Kozluk', 'Merkez', 'Sason'].map(toIlce) },
  { value: 'Bayburt', label: 'Bayburt', ilceler: ['Aydıntepe', 'Demirözü', 'Merkez'].map(toIlce) },
  { value: 'Bilecik', label: 'Bilecik', ilceler: ['Bozüyük', 'Gölpazarı', 'İnhisar', 'Merkez', 'Osmaneli', 'Pazaryeri', 'Söğüt', 'Yenipazar'].map(toIlce) },
  { value: 'Bingöl', label: 'Bingöl', ilceler: ['Adaklı', 'Genç', 'Karlıova', 'Kiğı', 'Merkez', 'Solhan', 'Yayladere', 'Yedisu'].map(toIlce) },
  { value: 'Bitlis', label: 'Bitlis', ilceler: ['Adilcevaz', 'Ahlat', 'Güroymak', 'Hizan', 'Merkez', 'Mutki', 'Tatvan'].map(toIlce) },
  { value: 'Bolu', label: 'Bolu', ilceler: ['Dörtdivan', 'Gerede', 'Göynük', 'Kıbrıscık', 'Mengen', 'Merkez', 'Mudurnu', 'Seben', 'Yeniçağa'].map(toIlce) },
  { value: 'Burdur', label: 'Burdur', ilceler: ['Ağlasun', 'Altınyayla', 'Bucak', 'Çavdır', 'Çeltikçi', 'Gölhisar', 'Karamanlı', 'Kemer', 'Merkez', 'Tefenni', 'Yeşilova'].map(toIlce) },
  { value: 'Bursa', label: 'Bursa', ilceler: ['Büyükorhan', 'Gemlik', 'Gürsu', 'Harmancık', 'İnegöl', 'İznik', 'Karacabey', 'Keles', 'Kestel', 'Mudanya', 'Mustafakemalpaşa', 'Nilüfer', 'Orhaneli', 'Orhangazi', 'Osmangazi', 'Yenişehir', 'Yıldırım'].map(toIlce) },
  { value: 'Çanakkale', label: 'Çanakkale', ilceler: ['Ayvacık', 'Bayramiç', 'Biga', 'Bozcaada', 'Çan', 'Eceabat', 'Ezine', 'Gelibolu', 'Gökçeada', 'Lapseki', 'Merkez', 'Yenice'].map(toIlce) },
  { value: 'Çankırı', label: 'Çankırı', ilceler: ['Atkaracalar', 'Bayramören', 'Çerkeş', 'Eldivan', 'Ilgaz', 'Kızılırmak', 'Korgun', 'Kurşunlu', 'Merkez', 'Orta', 'Şabanözü', 'Yapraklı'].map(toIlce) },
  { value: 'Çorum', label: 'Çorum', ilceler: ['Alaca', 'Bayat', 'Boğazkale', 'Dodurga', 'İskilip', 'Kargı', 'Laçin', 'Mecitözü', 'Merkez', 'Oğuzlar', 'Ortaköy', 'Osmancık', 'Sungurlu', 'Uğurludağ'].map(toIlce) },
  { value: 'Denizli', label: 'Denizli', ilceler: ['Acıpayam', 'Babadağ', 'Baklan', 'Bekilli', 'Beyağaç', 'Bozkurt', 'Buldan', 'Çal', 'Çameli', 'Çardak', 'Çivril', 'Güney', 'Honaz', 'Kale', 'Merkezefendi', 'Pamukkale', 'Sarayköy', 'Serinhisar', 'Tavas'].map(toIlce) },
  { value: 'Diyarbakır', label: 'Diyarbakır', ilceler: ['Bağlar', 'Bismil', 'Çermik', 'Çınar', 'Çüngüş', 'Dicle', 'Eğil', 'Ergani', 'Hani', 'Hazro', 'Kayapınar', 'Kocaköy', 'Kulp', 'Lice', 'Silvan', 'Sur', 'Yenişehir'].map(toIlce) },
  { value: 'Düzce', label: 'Düzce', ilceler: ['Akçakoca', 'Cumayeri', 'Çilimli', 'Gölyaka', 'Gümüşova', 'Kaynaşlı', 'Merkez', 'Yığılca'].map(toIlce) },
  { value: 'Edirne', label: 'Edirne', ilceler: ['Enez', 'Havsa', 'İpsala', 'Keşan', 'Lalapaşa', 'Meriç', 'Merkez', 'Süloğlu', 'Uzunköprü'].map(toIlce) },
  { value: 'Elazığ', label: 'Elazığ', ilceler: ['Ağın', 'Alacakaya', 'Arıcak', 'Baskil', 'Karakoçan', 'Keban', 'Kovancılar', 'Maden', 'Merkez', 'Palu', 'Sivrice'].map(toIlce) },
  { value: 'Erzincan', label: 'Erzincan', ilceler: ['Çayırlı', 'İliç', 'Kemah', 'Kemaliye', 'Merkez', 'Otlukbeli', 'Refahiye', 'Tercan', 'Üzümlü'].map(toIlce) },
  { value: 'Erzurum', label: 'Erzurum', ilceler: ['Aşkale', 'Aziziye', 'Çat', 'Hınıs', 'Horasan', 'İspir', 'Karaçoban', 'Karayazı', 'Köprüköy', 'Narman', 'Oltu', 'Olur', 'Palandöken', 'Pasinler', 'Pazaryolu', 'Şenkaya', 'Tekman', 'Tortum', 'Uzundere', 'Yakutiye'].map(toIlce) },
  { value: 'Eskişehir', label: 'Eskişehir', ilceler: ['Alpu', 'Beylikova', 'Çifteler', 'Günyüzü', 'Han', 'İnönü', 'Mahmudiye', 'Mihalgazi', 'Mihalıççık', 'Odunpazarı', 'Sarıcakaya', 'Seyitgazi', 'Sivrihisar', 'Tepebaşı'].map(toIlce) },
  { value: 'Gaziantep', label: 'Gaziantep', ilceler: ['Araban', 'İslahiye', 'Karkamış', 'Nizip', 'Nurdağı', 'Oğuzeli', 'Şahinbey', 'Şehitkamil', 'Yavuzeli'].map(toIlce) },
  { value: 'Giresun', label: 'Giresun', ilceler: ['Alucra', 'Bulancak', 'Çamoluk', 'Çanakçı', 'Dereli', 'Doğankent', 'Espiye', 'Eynesil', 'Görele', 'Güce', 'Keşap', 'Merkez', 'Piraziz', 'Şebinkarahisar', 'Tirebolu', 'Yağlıdere'].map(toIlce) },
  { value: 'Gümüşhane', label: 'Gümüşhane', ilceler: ['Kelkit', 'Köse', 'Kürtün', 'Merkez', 'Şiran', 'Torul'].map(toIlce) },
  { value: 'Hakkari', label: 'Hakkari', ilceler: ['Çukurca', 'Derecik', 'Merkez', 'Şemdinli', 'Yüksekova'].map(toIlce) },
  { value: 'Hatay', label: 'Hatay', ilceler: ['Altınözü', 'Antakya', 'Arsuz', 'Belen', 'Defne', 'Dörtyol', 'Erzin', 'Hassa', 'İskenderun', 'Kırıkhan', 'Kumlu', 'Payas', 'Reyhanlı', 'Samandağ', 'Yayladağı'].map(toIlce) },
  { value: 'Iğdır', label: 'Iğdır', ilceler: ['Aralık', 'Karakoyunlu', 'Merkez', 'Tuzluca'].map(toIlce) },
  { value: 'Isparta', label: 'Isparta', ilceler: ['Aksu', 'Atabey', 'Eğirdir', 'Gelendost', 'Gönen', 'Keçiborlu', 'Merkez', 'Senirkent', 'Sütçüler', 'Şarkikaraağaç', 'Uluborlu', 'Yalvaç', 'Yenişarbademli'].map(toIlce) },
  { value: 'İstanbul', label: 'İstanbul', ilceler: ['Adalar', 'Arnavutköy', 'Ataşehir', 'Avcılar', 'Bağcılar', 'Bahçelievler', 'Bakırköy', 'Başakşehir', 'Bayrampaşa', 'Beşiktaş', 'Beykoz', 'Beylikdüzü', 'Beyoğlu', 'Büyükçekmece', 'Çatalca', 'Çekmeköy', 'Esenler', 'Esenyurt', 'Eyüpsultan', 'Fatih', 'Gaziosmanpaşa', 'Güngören', 'Kadıköy', 'Kağıthane', 'Kartal', 'Küçükçekmece', 'Maltepe', 'Pendik', 'Sancaktepe', 'Sarıyer', 'Silivri', 'Sultanbeyli', 'Sultangazi', 'Şile', 'Şişli', 'Tuzla', 'Ümraniye', 'Üsküdar', 'Zeytinburnu'].map(toIlce) },
  { value: 'İzmir', label: 'İzmir', ilceler: ['Aliağa', 'Balçova', 'Bayındır', 'Bayraklı', 'Bergama', 'Beydağ', 'Bornova', 'Buca', 'Çeşme', 'Çiğli', 'Dikili', 'Foça', 'Gaziemir', 'Güzelbahçe', 'Karabağlar', 'Karaburun', 'Karşıyaka', 'Kemalpaşa', 'Kınık', 'Kiraz', 'Konak', 'Menderes', 'Menemen', 'Narlıdere', 'Ödemiş', 'Seferihisar', 'Selçuk', 'Tire', 'Torbalı', 'Urla'].map(toIlce) },
  { value: 'Kahramanmaraş', label: 'Kahramanmaraş', ilceler: ['Afşin', 'Andırın', 'Çağlayancerit', 'Dulkadiroğlu', 'Ekinözü', 'Elbistan', 'Göksun', 'Nurhak', 'Onikişubat', 'Pazarcık', 'Türkoğlu'].map(toIlce) },
  { value: 'Karabük', label: 'Karabük', ilceler: ['Eflani', 'Eskipazar', 'Merkez', 'Ovacık', 'Safranbolu', 'Yenice'].map(toIlce) },
  { value: 'Karaman', label: 'Karaman', ilceler: ['Ayrancı', 'Başyayla', 'Ermenek', 'Kazımkarabekir', 'Merkez', 'Sarıveliler'].map(toIlce) },
  { value: 'Kars', label: 'Kars', ilceler: ['Akyaka', 'Arpaçay', 'Digor', 'Kağızman', 'Merkez', 'Sarıkamış', 'Selim', 'Susuz'].map(toIlce) },
  { value: 'Kastamonu', label: 'Kastamonu', ilceler: ['Abana', 'Ağlı', 'Araç', 'Azdavay', 'Bozkurt', 'Cide', 'Çatalzeytin', 'Daday', 'Devrekani', 'Doğanyurt', 'Hanönü', 'İhsangazi', 'İnebolu', 'Küre', 'Merkez', 'Pınarbaşı', 'Seydiler', 'Şenpazar', 'Taşköprü', 'Tosya'].map(toIlce) },
  { value: 'Kayseri', label: 'Kayseri', ilceler: ['Akkışla', 'Bünyan', 'Develi', 'Felahiye', 'Hacılar', 'İncesu', 'Kocasinan', 'Melikgazi', 'Özvatan', 'Pınarbaşı', 'Sarıoğlan', 'Sarız', 'Talas', 'Tomarza', 'Yahyalı', 'Yeşilhisar'].map(toIlce) },
  { value: 'Kırıkkale', label: 'Kırıkkale', ilceler: ['Bahşılı', 'Balışeyh', 'Çelebi', 'Delice', 'Karakeçili', 'Keskin', 'Merkez', 'Sulakyurt', 'Yahşihan'].map(toIlce) },
  { value: 'Kırklareli', label: 'Kırklareli', ilceler: ['Babaeski', 'Demirköy', 'Kofçaz', 'Lüleburgaz', 'Merkez', 'Pehlivanköy', 'Pınarhisar', 'Vize'].map(toIlce) },
  { value: 'Kırşehir', label: 'Kırşehir', ilceler: ['Akçakent', 'Akpınar', 'Boztepe', 'Çiçekdağı', 'Kaman', 'Merkez', 'Mucur'].map(toIlce) },
  { value: 'Kilis', label: 'Kilis', ilceler: ['Elbeyli', 'Merkez', 'Musabeyli', 'Polateli'].map(toIlce) },
  { value: 'Kocaeli', label: 'Kocaeli', ilceler: ['Başiskele', 'Çayırova', 'Darıca', 'Derince', 'Dilovası', 'Gebze', 'Gölcük', 'İzmit', 'Kandıra', 'Karamürsel', 'Kartepe', 'Körfez'].map(toIlce) },
  { value: 'Konya', label: 'Konya', ilceler: ['Ahırlı', 'Akören', 'Akşehir', 'Altınekin', 'Beyşehir', 'Bozkır', 'Cihanbeyli', 'Çeltik', 'Çumra', 'Derbent', 'Derebucak', 'Doğanhisar', 'Emirgazi', 'Ereğli', 'Güneysınır', 'Hadim', 'Halkapınar', 'Hüyük', 'Ilgın', 'Kadınhanı', 'Karapınar', 'Karatay', 'Kulu', 'Meram', 'Sarayönü', 'Selçuklu', 'Seydişehir', 'Taşkent', 'Tuzlukçu', 'Yalıhüyük', 'Yunak'].map(toIlce) },
  { value: 'Kütahya', label: 'Kütahya', ilceler: ['Altıntaş', 'Aslanapa', 'Çavdarhisar', 'Domaniç', 'Dumlupınar', 'Emet', 'Gediz', 'Hisarcık', 'Merkez', 'Pazarlar', 'Simav', 'Şaphane', 'Tavşanlı'].map(toIlce) },
  { value: 'Malatya', label: 'Malatya', ilceler: ['Akçadağ', 'Arapgir', 'Arguvan', 'Battalgazi', 'Darende', 'Doğanşehir', 'Doğanyol', 'Hekimhan', 'Kale', 'Kuluncak', 'Pütürge', 'Yazıhan', 'Yeşilyurt'].map(toIlce) },
  { value: 'Manisa', label: 'Manisa', ilceler: ['Ahmetli', 'Akhisar', 'Alaşehir', 'Demirci', 'Gölmarmara', 'Gördes', 'Kırkağaç', 'Köprübaşı', 'Kula', 'Salihli', 'Sarıgöl', 'Saruhanlı', 'Selendi', 'Soma', 'Şehzadeler', 'Turgutlu', 'Yunusemre'].map(toIlce) },
  { value: 'Mardin', label: 'Mardin', ilceler: ['Artuklu', 'Dargeçit', 'Derik', 'Kızıltepe', 'Mazıdağı', 'Midyat', 'Nusaybin', 'Ömerli', 'Savur', 'Yeşilli'].map(toIlce) },
  { value: 'Mersin', label: 'Mersin', ilceler: ['Akdeniz', 'Anamur', 'Aydıncık', 'Bozyazı', 'Çamlıyayla', 'Erdemli', 'Gülnar', 'Mezitli', 'Mut', 'Silifke', 'Tarsus', 'Toroslar', 'Yenişehir'].map(toIlce) },
  { value: 'Muğla', label: 'Muğla', ilceler: ['Bodrum', 'Dalaman', 'Datça', 'Fethiye', 'Kavaklıdere', 'Köyceğiz', 'Marmaris', 'Menteşe', 'Milas', 'Ortaca', 'Seydikemer', 'Ula', 'Yatağan'].map(toIlce) },
  { value: 'Muş', label: 'Muş', ilceler: ['Bulanık', 'Hasköy', 'Korkut', 'Malazgirt', 'Merkez', 'Varto'].map(toIlce) },
  { value: 'Nevşehir', label: 'Nevşehir', ilceler: ['Acıgöl', 'Avanos', 'Derinkuyu', 'Gülşehir', 'Hacıbektaş', 'Kozaklı', 'Merkez', 'Ürgüp'].map(toIlce) },
  { value: 'Niğde', label: 'Niğde', ilceler: ['Altunhisar', 'Bor', 'Çamardı', 'Çiftlik', 'Merkez', 'Ulukışla'].map(toIlce) },
  { value: 'Ordu', label: 'Ordu', ilceler: ['Akkuş', 'Altınordu', 'Aybastı', 'Çamaş', 'Çatalpınar', 'Çaybaşı', 'Fatsa', 'Gölköy', 'Gülyalı', 'Gürgentepe', 'İkizce', 'Kabadüz', 'Kabataş', 'Korgan', 'Kumru', 'Mesudiye', 'Perşembe', 'Ulubey', 'Ünye'].map(toIlce) },
  { value: 'Osmaniye', label: 'Osmaniye', ilceler: ['Bahçe', 'Düziçi', 'Hasanbeyli', 'Kadirli', 'Merkez', 'Sumbas', 'Toprakkale'].map(toIlce) },
  { value: 'Rize', label: 'Rize', ilceler: ['Ardeşen', 'Çamlıhemşin', 'Çayeli', 'Derepazarı', 'Fındıklı', 'Güneysu', 'Hemşin', 'İkizdere', 'İyidere', 'Kalkandere', 'Merkez', 'Pazar'].map(toIlce) },
  { value: 'Sakarya', label: 'Sakarya', ilceler: ['Adapazarı', 'Akyazı', 'Arifiye', 'Erenler', 'Ferizli', 'Geyve', 'Hendek', 'Karapürçek', 'Karasu', 'Kaynarca', 'Kocaali', 'Pamukova', 'Sapanca', 'Serdivan', 'Söğütlü', 'Taraklı'].map(toIlce) },
  { value: 'Samsun', label: 'Samsun', ilceler: ['Alaçam', 'Asarcık', 'Atakum', 'Ayvacık', 'Bafra', 'Canik', 'Çarşamba', 'Havza', 'İlkadım', 'Kavak', 'Ladik', 'Ondokuzmayıs', 'Salıpazarı', 'Tekkeköy', 'Terme', 'Vezirköprü', 'Yakakent'].map(toIlce) },
  { value: 'Siirt', label: 'Siirt', ilceler: ['Baykan', 'Eruh', 'Kurtalan', 'Merkez', 'Pervari', 'Şirvan', 'Tillo'].map(toIlce) },
  { value: 'Sinop', label: 'Sinop', ilceler: ['Ayancık', 'Boyabat', 'Dikmen', 'Durağan', 'Erfelek', 'Gerze', 'Merkez', 'Saraydüzü', 'Türkeli'].map(toIlce) },
  { value: 'Sivas', label: 'Sivas', ilceler: ['Akıncılar', 'Altınyayla', 'Divriği', 'Doğanşar', 'Gemerek', 'Gölova', 'Gürün', 'Hafik', 'İmranlı', 'Kangal', 'Koyulhisar', 'Merkez', 'Suşehri', 'Şarkışla', 'Ulaş', 'Yıldızeli', 'Zara'].map(toIlce) },
  { value: 'Şanlıurfa', label: 'Şanlıurfa', ilceler: ['Akçakale', 'Birecik', 'Bozova', 'Ceylanpınar', 'Eyyübiye', 'Halfeti', 'Haliliye', 'Harran', 'Hilvan', 'Karaköprü', 'Siverek', 'Suruç', 'Viranşehir'].map(toIlce) },
  { value: 'Şırnak', label: 'Şırnak', ilceler: ['Beytüşşebap', 'Cizre', 'Güçlükonak', 'İdil', 'Merkez', 'Silopi', 'Uludere'].map(toIlce) },
  { value: 'Tekirdağ', label: 'Tekirdağ', ilceler: ['Çerkezköy', 'Çorlu', 'Ergene', 'Hayrabolu', 'Kapaklı', 'Malkara', 'Marmaraereğlisi', 'Muratlı', 'Saray', 'Süleymanpaşa', 'Şarköy'].map(toIlce) },
  { value: 'Tokat', label: 'Tokat', ilceler: ['Almus', 'Artova', 'Başçiftlik', 'Erbaa', 'Merkez', 'Niksar', 'Pazar', 'Reşadiye', 'Sulusaray', 'Turhal', 'Yeşilyurt', 'Zile'].map(toIlce) },
  { value: 'Trabzon', label: 'Trabzon', ilceler: ['Akçaabat', 'Araklı', 'Arsin', 'Beşikdüzü', 'Çarşıbaşı', 'Çaykara', 'Dernekpazarı', 'Düzköy', 'Hayrat', 'Köprübaşı', 'Maçka', 'Of', 'Ortahisar', 'Sürmene', 'Şalpazarı', 'Tonya', 'Vakfıkebir', 'Yomra'].map(toIlce) },
  { value: 'Tunceli', label: 'Tunceli', ilceler: ['Çemişgezek', 'Hozat', 'Mazgirt', 'Merkez', 'Nazımiye', 'Ovacık', 'Pertek', 'Pülümür'].map(toIlce) },
  { value: 'Uşak', label: 'Uşak', ilceler: ['Banaz', 'Eşme', 'Karahallı', 'Merkez', 'Sivaslı', 'Ulubey'].map(toIlce) },
  { value: 'Van', label: 'Van', ilceler: ['Bahçesaray', 'Başkale', 'Çaldıran', 'Çatak', 'Edremit', 'Erciş', 'Gevaş', 'Gürpınar', 'İpekyolu', 'Muradiye', 'Özalp', 'Saray', 'Tuşba'].map(toIlce) },
  { value: 'Yalova', label: 'Yalova', ilceler: ['Altınova', 'Armutlu', 'Çınarcık', 'Çiftlikköy', 'Merkez', 'Termal'].map(toIlce) },
  { value: 'Yozgat', label: 'Yozgat', ilceler: ['Akdağmadeni', 'Aydıncık', 'Boğazlıyan', 'Çandır', 'Çayıralan', 'Çekerek', 'Kadışehri', 'Merkez', 'Saraykent', 'Sarıkaya', 'Sorgun', 'Şefaatli', 'Yenifakılı', 'Yerköy'].map(toIlce) },
  { value: 'Zonguldak', label: 'Zonguldak', ilceler: ['Alaplı', 'Çaycuma', 'Devrek', 'Ereğli', 'Gökçebey', 'Kilimli', 'Kozlu', 'Merkez'].map(toIlce) },
];

function toIlce(label: string): Ilce {
  return { value: label, label };
}

/** İl listesini (yalnızca value/label) döndürür — Select için. */
export const ilSecenekleri = iller.map((i) => ({ value: i.value, label: i.label }));

/** Bir ile ait ilçe listesini döndürür. */
export function ilIlceleri(ilAdi: string): Ilce[] {
  const il = iller.find((i) => i.value === ilAdi);
  return il ? il.ilceler : [];
}