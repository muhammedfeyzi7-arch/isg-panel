import { useEffect } from "react";
import { SWRConfig } from "swr";
import { BrowserRouter } from "react-router-dom";
import { AppRoutes } from "./router";
import { I18nextProvider } from "react-i18next";
import i18n from "./i18n";
import { ThemeProvider } from "@/context/ThemeContext";
import { AuthProvider } from "@/context/AuthContext";
import { AdminProfileProvider } from "@/context/AdminProfileContext";
import { MesajlasmaProvider } from "@/context/MesajlasmaContext";
import { ToastProvider } from "@/hooks/useToast";
import { ModalProvider } from "@/hooks/useModal";
import { ConfirmProvider } from "@/hooks/useConfirm";
import { BottomSheetProvider } from "@/hooks/useBottomSheet";
import ModalManager from "@/components/ui/ModalManager";
import ToastManager from "@/components/ui/ToastManager";
import ConfirmDialog from "@/components/ui/ConfirmDialog";
import BottomSheet from "@/components/ui/BottomSheet";
import ErrorBoundary from "@/components/ui/ErrorBoundary";
import ViewportManager from "@/components/feature/ViewportManager";
import SessionBoundary from "@/components/feature/SessionBoundary";
import RouteTimingProbe from "@/components/feature/RouteTimingProbe";
import {
  registerIsgKatipSpaBridgeActivation,
  unregisterIsgKatipSpaBridgeActivation,
} from "@/lib/isgKatip/bridge";

const swrConfig = {
  // Sekme odağı/bağlantı değişiminde tüm sayfaların yeniden sorgulanması açılışı ciddi
  // yavaşlatıyordu. Veri tazeliği sayfa bazlı mount + explicit mutate ile sağlanır.
  revalidateOnFocus: false,
  revalidateOnReconnect: false,
  dedupingInterval: 30000,
  errorRetryCount: 2,
};

function App() {
  // ── GLOBAL DOSYA BIRAKMA GUARD (Shared UI tek kaynak) ──
  // Sayfa zeminine yanlışlıkla bir dosya bırakıldığında tarayıcı o dosyayı
  // açar ve uygulamadan çıkar (state kaybı). Bu guard, YALNIZCA dosya
  // sürüklemelerinde varsayılan gezinmeyi iptal eder; bileşenlerin kendi
  // dropzone'ları (stopPropagation + preventDefault) bundan etkilenmez.
  useEffect(() => {
    const isFileDrag = (e: DragEvent) =>
      !!e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files');
    const preventDefault = (e: DragEvent) => {
      if (isFileDrag(e)) e.preventDefault();
    };
    window.addEventListener('dragover', preventDefault);
    window.addEventListener('drop', preventDefault);
    return () => {
      window.removeEventListener('dragover', preventDefault);
      window.removeEventListener('drop', preventDefault);
    };
  }, []);

  useEffect(() => {
    // FAZ 6I.1B.1 — İSG-KATİP → SPA köprü AKTİVASYONU (IN-MEMORY, READ-ONLY, DOMAIN-BAĞIMSIZ).
    // NORMAL DURUMDA HİÇBİR mesaj listener'ı KURULMAZ; yalnızca pencere-global aktivasyon
    // tutamağı yayınlanır. Köprü, kullanıcı Extension popup'ında "İSGDenetim'e Bağlan"
    // aksiyonunu tetikleyip aktif sekmeye (activeTab + scripting) MAIN-world sender
    // enjekte ettiğinde kurulur. Domain HARDCODE EDİLMEZ; origin yalnızca runtime'da
    // sayfanın kendi origin'i ile karşılaştırılır. DB'ye yazma yok.
    registerIsgKatipSpaBridgeActivation();
    return () => unregisterIsgKatipSpaBridgeActivation();
  }, []);

  return (
    <SWRConfig value={swrConfig}>
      <ThemeProvider>
      <AuthProvider>
        <AdminProfileProvider>
          <MesajlasmaProvider>
            <ToastProvider>
              <ModalProvider>
                <ConfirmProvider>
                  <BottomSheetProvider>
                    <I18nextProvider i18n={i18n}>
                      <ErrorBoundary>
                        <BrowserRouter basename={__BASE_PATH__}>
                          <ViewportManager />
                          <SessionBoundary />
                          <RouteTimingProbe />
                          <AppRoutes />
                          <ModalManager />
                          <ToastManager />
                          <ConfirmDialog />
                          <BottomSheet />
                        </BrowserRouter>
                      </ErrorBoundary>
                    </I18nextProvider>
                  </BottomSheetProvider>
                </ConfirmProvider>
              </ModalProvider>
            </ToastProvider>
          </MesajlasmaProvider>
        </AdminProfileProvider>
      </AuthProvider>
      </ThemeProvider>
    </SWRConfig>
  );
}

export default App;