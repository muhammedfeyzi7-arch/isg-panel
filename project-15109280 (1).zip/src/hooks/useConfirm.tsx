import { createContext, useContext, useState, useCallback, useEffect, useMemo, type ReactNode } from 'react';
import { registerTransientReset } from '@/lib/transientUiReset';

export interface ConfirmOptions {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  variant?: 'danger' | 'warning' | 'info';
  onConfirm: () => void;
  onCancel?: () => void;
}

interface ConfirmState {
  isOpen: boolean;
  options: ConfirmOptions | null;
}

interface ConfirmActions {
  confirm: (options: ConfirmOptions) => void;
  close: () => void;
}

const ConfirmActionsContext = createContext<ConfirmActions | undefined>(undefined);
const ConfirmStateContext = createContext<ConfirmState | undefined>(undefined);

export function ConfirmProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<ConfirmState>({ isOpen: false, options: null });

  const confirm = useCallback((options: ConfirmOptions) => {
    setState({ isOpen: true, options });
  }, []);

  const close = useCallback(() => {
    setState({ isOpen: false, options: null });
  }, []);

  // ── AUTH SESSION BOUNDARY RESET (Shared UI tek kaynak) ──
  // Logout / kullanıcı değişiminde açık onay dialog'u kesin olarak kapatılır;
  // önceki oturuma ait bir confirm login ekranına sızmaz.
  useEffect(() => registerTransientReset(() => {
    setState({ isOpen: false, options: null });
  }), []);

  // Eylemler sabittir (useCallback) — onay açılıp kapandığında YALNIZCA state
  // context'i değişir; `useConfirmActions` kullanan sayfalar re-render olmaz.
  const actions = useMemo<ConfirmActions>(() => ({ confirm, close }), [confirm, close]);

  return (
    <ConfirmActionsContext.Provider value={actions}>
      <ConfirmStateContext.Provider value={state}>
        {children}
      </ConfirmStateContext.Provider>
    </ConfirmActionsContext.Provider>
  );
}

export function useConfirmActions() {
  const ctx = useContext(ConfirmActionsContext);
  if (!ctx) throw new Error('useConfirmActions must be used within ConfirmProvider');
  return ctx;
}

export function useConfirmState() {
  const ctx = useContext(ConfirmStateContext);
  if (!ctx) throw new Error('useConfirmState must be used within ConfirmProvider');
  return ctx;
}

// Geriye dönük uyumlu birleşik hook.
export function useConfirm() {
  return { ...useConfirmActions(), state: useConfirmState() };
}