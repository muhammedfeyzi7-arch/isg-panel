import { useCallback, useEffect, useLayoutEffect, useRef, useState, type RefObject } from 'react';

/**
 * Bir dropdown/panel dışına tıklandığında verilen handler'ı çalıştırır.
 * Tüm popover (select, autocomplete, menu) sistemlerinde ortak kullanılır.
 */
export function useClickOutside<T extends HTMLElement>(
  ref: RefObject<T | null>,
  handler: () => void,
  active = true,
) {
  const handlerRef = useRef(handler);
  handlerRef.current = handler;

  useEffect(() => {
    if (!active) return;

    const listener = (e: MouseEvent | TouchEvent) => {
      const el = ref.current;
      if (!el || el.contains(e.target as Node)) return;
      handlerRef.current();
    };

    document.addEventListener('mousedown', listener);
    document.addEventListener('touchstart', listener);
    return () => {
      document.removeEventListener('mousedown', listener);
      document.removeEventListener('touchstart', listener);
    };
  }, [ref, active]);
}

export interface DropdownPosition {
  direction: 'down' | 'up';
  left: number;
  top?: number;
  bottom?: number;
  width: number;
  maxHeight: number;
}

export interface DropdownPositionOptions {
  /** Panelin olmasına izin verilen üst doğal yükseklik sınırı. */
  maxHeight?: number;
  /** Trigger ile panel arasındaki boşluk (px). */
  gap?: number;
  /** Panelin minimum genişliği (px) — küçük icon trigger'lı menülerde kullanılır. */
  minWidth?: number;
  /** Yatay hizalama: 'start' trigger'ın soluna, 'end' sağına hizalar. */
  align?: 'start' | 'end';
}

/**
 * Viewport-aware dropdown konumlandırma motoru.
 *
 * Trigger'ın viewport koordinatına göre panelin aşağı mı yukarı mı açılacağını
 * belirler:
 *   1. Alt tarafta yeterli alan varsa → aşağı aç.
 *   2. Alt yoksa ama üst varsa → yukarı aç.
 *   3. İkisi de yetersizse → daha geniş olan tarafa aç ve panel yüksekliğini
 *      kullanılabilir alana sınırla (seçenek listesi kendi içinde scroll eder).
 *
 * Panel document.body'ye portal edildiği için modal body overflow'u dahil hiçbir
 * container bu paneli kırpamaz. Modal scroll / drag / resize sırasında trigger
 * hareket ettiğinde konum güncellenir.
 *
 * KRİTİK — SCROLL SENKRONİZASYONU:
 * Panel `position: fixed` olarak body'ye portal edildiği için modal içindeki
 * scroll container hareket ettiğinde çapa (anchor/input) ile birlikte otomatik
 * hareket ETMEZ. Konum React state üzerinden güncellenirse scroll'un bir frame
 * gerisinde kalır ve panel inputtan koparak "dans eden ayrı layer" gibi görünür.
 *
 * Bu yüzden yüksek frekanslı olaylarda (scroll/pointer) konum aynı frame içinde
 * DOĞRUDAN DOM'a yazılır (React render turu beklenmez) ve RAF ile frame başına
 * tek hesaplama yapılır. React state ise yalnızca re-render olduğunda imperative
 * yazılan değerle çakışmaması için eşitlenir.
 */
export function useDropdownPosition<T extends HTMLElement>(
  open: boolean,
  anchorRef: RefObject<T | null>,
  options?: DropdownPositionOptions,
) {
  const panelRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number | null>(null);
  const [pos, setPos] = useState<DropdownPosition | null>(null);
  const naturalHeightRef = useRef(0);

  const maxPanelHeight = options?.maxHeight ?? 360;
  const gap = options?.gap ?? 6;
  const minWidth = options?.minWidth ?? 0;
  const align = options?.align ?? 'start';

  // Saf konum hesabı — çapanın anlık viewport rect'inden panelin nereye ve
  // hangi yönde açılacağını döndürür. Çapa/panel yoksa null.
  const computePosition = useCallback((): DropdownPosition | null => {
    const anchor = anchorRef.current;
    const panel = panelRef.current;
    if (!anchor || !panel) return null;

    const rect = anchor.getBoundingClientRect();
    const vw = window.innerWidth;
    const vh = window.innerHeight;

    // Doğal içerik yüksekliği: ilk ölçümde (max-height clamp uygulanmadan)
    // scrollHeight ile yakalanır; sonraki hesaplarda bu sabit değer kullanılır.
    if (naturalHeightRef.current === 0) {
      naturalHeightRef.current = panel.scrollHeight;
    }
    const naturalHeight = naturalHeightRef.current || panel.scrollHeight;
    const capped = Math.min(naturalHeight, maxPanelHeight);

    const spaceBelow = vh - rect.bottom;
    const spaceAbove = rect.top;

    let direction: 'down' | 'up';
    let maxHeight: number;

    if (spaceBelow >= capped) {
      direction = 'down';
      maxHeight = Math.min(spaceBelow - gap, maxPanelHeight);
    } else if (spaceAbove >= capped) {
      direction = 'up';
      maxHeight = Math.min(spaceAbove - gap, maxPanelHeight);
    } else {
      direction = spaceBelow >= spaceAbove ? 'down' : 'up';
      const avail = Math.max(spaceBelow, spaceAbove) - gap;
      maxHeight = Math.max(Math.min(avail, maxPanelHeight), 96);
    }

    const width = Math.max(minWidth, Math.min(rect.width, vw - 16));
    const left =
      align === 'end'
        ? Math.max(8, Math.min(rect.right - width, vw - width - 8))
        : Math.max(8, Math.min(rect.left, vw - width - 8));

    const next: DropdownPosition = { direction, left, width, maxHeight };
    if (direction === 'down') {
      next.top = rect.bottom + gap;
    } else {
      next.bottom = vh - rect.top + gap;
    }

    return next;
  }, [anchorRef, maxPanelHeight, gap, minWidth, align]);

  // Panel DOM'una DOĞRUDAN yazan konumlayıcı. React render turu beklemeden
  // aynı frame içinde konumu günceller — modal scroll edilirken dropdown'ın
  // inputtan kopmasını (dans eden layer) engelleyen kritik parça budur.
  const applyToDom = useCallback((next: DropdownPosition) => {
    const panel = panelRef.current;
    if (!panel) return;
    panel.style.visibility = 'visible';
    panel.style.left = `${next.left}px`;
    panel.style.width = `${next.width}px`;
    panel.style.maxHeight = `${next.maxHeight}px`;
    if (next.top !== undefined) {
      panel.style.top = `${next.top}px`;
      panel.style.bottom = 'auto';
    } else if (next.bottom !== undefined) {
      panel.style.bottom = `${next.bottom}px`;
      panel.style.top = 'auto';
    }
  }, []);

  // Konumu hesapla → DOM'a doğrudan yaz → React state'i eşitle.
  // State yalnızca gerçek bir değişiklik olduğunda güncellenir (equal-guard),
  // böylece scroll sırasında gereksiz re-render üretilmez ama imperative yazım
  // sayesinde görsel konum her zaman günceldir.
  const recalc = useCallback(() => {
    const next = computePosition();
    if (!next) return;

    applyToDom(next);

    setPos((prev) => {
      if (
        prev &&
        prev.direction === next.direction &&
        prev.left === next.left &&
        prev.top === next.top &&
        prev.bottom === next.bottom &&
        prev.width === next.width &&
        prev.maxHeight === next.maxHeight
      ) {
        return prev;
      }
      return next;
    });
  }, [computePosition, applyToDom]);

  // Yüksek frekanslı olaylar (scroll/pointer) için RAF ile frame başına tek
  // hesaplama. RAF callback'i boyamadan hemen önce çalıştığı için panelin konumu
  // scroll ile aynı frame içinde güncellenir — görünür "atlama"/"dans" olmaz.
  const scheduleRecalc = useCallback(() => {
    if (typeof requestAnimationFrame === 'undefined') {
      recalc();
      return;
    }
    if (rafRef.current !== null) return;
    rafRef.current = requestAnimationFrame(() => {
      rafRef.current = null;
      recalc();
    });
  }, [recalc]);

  useLayoutEffect(() => {
    if (!open) {
      setPos(null);
      naturalHeightRef.current = 0;
      return;
    }

    // İlk konumlandırma boyamadan önce (flash yok).
    recalc();

    // Modal body scroll'u dahil iç scroll'ları yakalamak için capture=true.
    // Capture, scroll event'i bubble etmese bile tüm nested scroll container'ı
    // window seviyesinde yakalar.
    window.addEventListener('scroll', scheduleRecalc, true);
    window.addEventListener('resize', recalc);

    // Modal DRAG/RESIZE takibi: shared modal sürüklenirken (pointer hareketi)
    // scroll/resize olayı TETİKLENMEZ. Portal `position: fixed` bir dropdown
    // çapa elemanıyla birlikte hareket etmediği için eski konumunda kalır.
    // Pointer hareketinde yeniden hesaplayarak dropdown'ın modal ile birlikte
    // kaymasını sağlar.
    window.addEventListener('pointermove', scheduleRecalc);
    window.addEventListener('pointerup', scheduleRecalc);

    let ro: ResizeObserver | undefined;
    if (typeof ResizeObserver !== 'undefined' && panelRef.current) {
      ro = new ResizeObserver(() => recalc());
      ro.observe(panelRef.current);
    }

    return () => {
      window.removeEventListener('scroll', scheduleRecalc, true);
      window.removeEventListener('resize', recalc);
      window.removeEventListener('pointermove', scheduleRecalc);
      window.removeEventListener('pointerup', scheduleRecalc);
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
      ro?.disconnect();
    };
  }, [open, recalc, scheduleRecalc]);

  const panelStyle = pos
    ? {
        position: 'fixed' as const,
        left: `${pos.left}px`,
        width: `${pos.width}px`,
        maxHeight: `${pos.maxHeight}px`,
        top: pos.top !== undefined ? `${pos.top}px` : undefined,
        bottom: pos.bottom !== undefined ? `${pos.bottom}px` : undefined,
      }
    : undefined;

  return { panelRef, panelStyle };
}