import { createContext, useContext, useState, useCallback, useEffect } from 'react';
import type { ReactNode } from 'react';
import { registerTransientReset } from '@/lib/transientUiReset';

export interface BottomSheetOptions {
  title?: string;
  content: ReactNode;
  showClose?: boolean;
}

interface BottomSheetContextType {
  isOpen: boolean;
  options: BottomSheetOptions | null;
  openSheet: (opts: BottomSheetOptions) => void;
  closeSheet: () => void;
}

const BottomSheetContext = createContext<BottomSheetContextType | undefined>(undefined);

export function BottomSheetProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [options, setOptions] = useState<BottomSheetOptions | null>(null);

  const openSheet = useCallback((opts: BottomSheetOptions) => {
    setOptions(opts);
    setIsOpen(true);
  }, []);

  // ANİMASYONSUZ STANDART: kapanışta content'i geciktiren timer YOKTUR.
  // "TAK" açılır, "TAK" kapanır — content anında unmount edilir.
  const closeSheet = useCallback(() => {
    setIsOpen(false);
    setOptions(null);
  }, []);

  // ── AUTH SESSION BOUNDARY RESET (Shared UI tek kaynak) ──
  // Logout / kullanıcı değişiminde açık bottom sheet (drawer) kesin olarak
  // kapatılır; önceki oturuma ait bir sheet login ekranına sızmaz.
  useEffect(() => registerTransientReset(() => {
    setIsOpen(false);
    setOptions(null);
  }), []);

  return (
    <BottomSheetContext.Provider value={{ isOpen, options, openSheet, closeSheet }}>
      {children}
    </BottomSheetContext.Provider>
  );
}

export function useBottomSheet() {
  const ctx = useContext(BottomSheetContext);
  if (!ctx) throw new Error('useBottomSheet must be used within BottomSheetProvider');
  return ctx;
}