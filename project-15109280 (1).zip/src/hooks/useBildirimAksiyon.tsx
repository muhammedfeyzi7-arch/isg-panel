import { useCallback, lazy, Suspense } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useModalActions } from '@/hooks/useModal';
import { useAuth } from '@/context/AuthContext';
import ModalFallback from '@/components/ui/ModalFallback';
import { getPanelFromPath } from '@/components/feature/panelNavigation';
import { setPendingConversationId } from '@/lib/messagingTarget';
import { markBildirimOkundu } from '@/lib/bildirimService';
import type { Bildirim } from '@/lib/bildirim';

// Ağır detay modalları yalnızca bir bildirime tıklanınca yüklenir (lazy).
const AnnouncementReaderModal = lazy(() => import('@/components/feature/announcement/AnnouncementReaderModal'));
const ZimmetDetailModal = lazy(() => import('@/components/feature/zimmet/ZimmetDetailModal'));
const OperasyonDetailModal = lazy(() => import('@/components/feature/operasyon/OperasyonDetailModal'));
const UygunsuzlukDetailModal = lazy(() => import('@/pages/uzman/saha-denetimleri/components/UygunsuzlukDetailModal'));
const FirmaUygunsuzlukDetailModal = lazy(() => import('@/pages/firma/saha-denetimleri/components/FirmaUygunsuzlukDetailModal'));
const ZiyaretDetayModal = lazy(() => import('@/components/feature/ziyaretler/ZiyaretDetayModal'));

/**
 * ORTAK BİLDİRİM AKSİYONU (5 panel).
 *
 * KURAL: "BİLDİRİM → DOĞRU KAYIT → DOĞRU İŞLEM". Bildirime tıklanınca önce listeye/sekme'ye
 * gönderilmez; doğrudan mevcut detay/önizleme modalı açılır (yeni paralel modal sistemi yoktur).
 * Yalnızca kaydı olmayan (ör. mesaj/izin talebi) bildirimlerde ilgili panele yönlendirme yapılır.
 */
export function useBildirimAksiyon(onAfterAction?: () => void) {
  const { openModal, closeModal } = useModalActions();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const bitir = useCallback(() => {
    onAfterAction?.();
  }, [onAfterAction]);

  const openBildirim = useCallback(
    (b: Bildirim) => {
      // Operasyon (kaza/arıza) → operasyon detayı.
      if (b.operasyonEntityId && b.operasyonEntityType) {
        const mid = openModal({
          title: b.title,
          description: 'Operasyon Detayı',
          variant: 'detail',
          width: 560,
          minWidth: 440,
          minHeight: 460,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          content: (
            <Suspense fallback={<ModalFallback />}>
              <OperasyonDetailModal
                entityType={b.operasyonEntityType as 'arac_operasyon' | 'ariza'}
                entityId={b.operasyonEntityId}
                onClose={() => closeModal(mid)}
                onChanged={() => {
                  markBildirimOkundu(b).catch(() => undefined);
                  bitir();
                }}
              />
            </Suspense>
          ),
        });
        return;
      }

      // Zimmet → zimmet detayı.
      if (b.zimmetId) {
        const mid = openModal({
          title: b.title,
          description: 'Zimmet Detayı',
          variant: 'detail',
          width: 1100,
          minWidth: 440,
          minHeight: 520,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          bodyLayout: 'fill',
          content: (
            <Suspense fallback={<ModalFallback />}>
              <ZimmetDetailModal
                zimmetId={b.zimmetId}
                onClose={() => closeModal(mid)}
                onChanged={() => {
                  markBildirimOkundu(b).catch(() => undefined);
                  bitir();
                }}
              />
            </Suspense>
          ),
        });
        return;
      }

      // Uygunsuzluk → panel ayırt ederek ilgili detay modalı.
      if (b.uygunsuzlukId) {
        const isFirma = profile?.role === 'firma';
        const mid = openModal({
          title: b.title,
          description: 'Uygunsuzluk Detayı',
          variant: 'detail',
          width: 540,
          minWidth: 400,
          minHeight: 420,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          content: (
            <Suspense fallback={<ModalFallback />}>
              {isFirma ? (
                <FirmaUygunsuzlukDetailModal uygunsuzlukId={b.uygunsuzlukId} onClose={() => closeModal(mid)} onChanged={() => undefined} />
              ) : (
                <UygunsuzlukDetailModal uygunsuzlukId={b.uygunsuzlukId} onClose={() => closeModal(mid)} onChanged={() => undefined} />
              )}
            </Suspense>
          ),
        });
        markBildirimOkundu(b).catch(() => undefined);
        bitir();
        return;
      }

      // Duyuru → okuyucu modal (yüklendikten sonra okundu).
      if (b.kind === 'announcement' && b.announcementId) {
        const mid = openModal({
          title: 'Duyuru',
          description: b.title,
          variant: 'detail',
          width: 560,
          minWidth: 420,
          minHeight: 460,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          content: (
            <Suspense fallback={<ModalFallback />}>
              <AnnouncementReaderModal
                announcementId={b.announcementId}
                onClose={() => closeModal(mid)}
                onLoaded={() => {
                  markBildirimOkundu(b).catch(() => undefined);
                  bitir();
                }}
              />
            </Suspense>
          ),
        });
        return;
      }

      // Mesaj → ilgili sohbeti aç.
      if (b.modul === 'mesajlasma') {
        markBildirimOkundu(b).catch(() => undefined);
        if (b.conversationId) {
          setPendingConversationId(b.conversationId);
          const panel = getPanelFromPath(location.pathname);
          const msgPath = panel === 'admin'
            ? '/destek'
            : `/${panel === 'osgb' ? 'osgb-panel' : panel}/mesajlasma`;
          navigate(msgPath);
        }
        bitir();
        return;
      }

      // Ziyaret detayı → ziyaret detay modalı.
      if (b.ziyaretId) {
        openModal({
          title: b.title,
          description: 'Ziyaret Detayı',
          variant: 'detail',
          width: 960,
          minWidth: 660,
          minHeight: 580,
          showFooter: false,
          closable: true,
          resizable: true,
          minimizable: true,
          content: (
            <Suspense fallback={<ModalFallback />}>
              <ZiyaretDetayModal ziyaretId={b.ziyaretId} onChanged={() => undefined} />
            </Suspense>
          ),
        });
        markBildirimOkundu(b).catch(() => undefined);
        bitir();
        return;
      }

      // İzin/gün değişikliği bildirimi (ziyaret kaydı yoksa) → ilgili panelin ziyaret listesi.
      if (b.modul === 'ziyaret') {
        markBildirimOkundu(b).catch(() => undefined);
        const panel = getPanelFromPath(location.pathname);
        const listPath = panel === 'osgb'
          ? '/osgb-panel/ziyaret-planlama'
          : panel === 'uzman'
            ? '/uzman/ziyaretler'
            : panel === 'hekim'
              ? '/hekim/ziyaretler'
              : '/destek';
        navigate(listPath);
        bitir();
        return;
      }

      // Kalan (destek) → okundu işaretle.
      markBildirimOkundu(b).catch(() => undefined);
      bitir();
    },
    [openModal, closeModal, navigate, location.pathname, profile, bitir],
  );

  return { openBildirim };
}