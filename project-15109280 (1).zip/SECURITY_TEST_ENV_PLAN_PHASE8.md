# İSGDenetim — Faz 8: Güvenli Test Ortamı Planı

> **Amaç:** Güvenlik migration'larının gerçek PostgreSQL/RLS davranışını **üretime
> dokunmadan** doğrulayabileceğimiz izole bir test ortamı için en kısa ve güvenli yolu
> tanımlamak.
>
> **SINIR:** Bu doküman **plandır.** Bu turda hiçbir test ortamı oluşturulmadı, hiçbir
> migration/DDL üretime uygulanmadı, hiçbir veri kopyalanmadı.

---

## 1) Engel — kök neden

- Bu proje klasöründe uygulamanın **temel (base) şema migration'ları YOKTUR**. Yalnızca
  güvenlik migration'ları (`20260101000*`) bulunur.
- Bu yüzden yerel Supabase (`supabase start` + `db reset`) kurulumu, güvenlik
  migration'larının bağımlı olduğu nesnelerde durur:
  - Fonksiyonlar: `auth_role()`, `auth_osgb_id()`, `auth_firma_id()`, `auth_personel_id()`,
    `auth_personel_bilgi()`, `has_active_firma_assignment(uuid,uuid)`,
    `has_active_primary_assignment(uuid,uuid)`, `osgb_access_ok()`, `audit_log()` …
  - Tablolar: `osgb`, `firmalar`, `personeller`, `atamalar`, `teklifler`,
    `teklif_hizmetleri`, `profiles`, `storage.objects`, `storage.buckets` …
  - Trigger'lar: `on_auth_user_created` → `handle_new_user()`, çeşitli audit/lock trigger'ları.
- **Doğru yaklaşım:** base şemayı **tahmin etmek/uydurmak DEĞİL**, gerçek şemadan
  **şema-only** (verisiz) bir klon üretip izole bir projeye yüklemektir.

---

## 2) Yetkili/mevcut bir kaynak var mı?

| Kaynak | Durum | Kullanılabilirlik |
|---|---|---|
| Proje klasöründe base migration | ❌ **YOK** | Kullanılamaz |
| Git deposunda `supabase/migrations` (base) | ❌ görünmüyor | Kullanılamaz |
| **Bağlı Supabase projesi (canlı)** | ✅ Bağlı (SaaS Supabase) | **Yalnız salt-okuma** şema dump'ı için kaynak olabilir |
| Ayrı izole test projesi | ❌ yok | **Oluşturulmalı** |

> Canlı proje **şema kaynağı** olarak kullanılabilir (şema-only dump **veri içermez**),
> ancak **testler asla canlı projede çalıştırılmaz.** Testler ayrı bir izole projede yürür.

---

## 3) Önerilen güvenli yol (en kısa)

### Adım 0 — Sorumlu girdi (kim ne yapar)
| İş | Sorumlu | Gerekli yetki |
|---|---|---|
| İzole test Supabase projesi açmak | Proje sahibi | Supabase Dashboard erişimi |
| Canlıdan **şema-only** dump almak | Proje sahibi / DB erişimi olan | `pg_dump` + canlı DB connection string (yalnız okuma) |
| Dump'ı izole projeye yüklemek | Proje sahibi | İzole DB connection string |
| Testleri çalıştırmak | Geliştirici | İzole DB erişimi |

> ⚠️ Canlı DB connection string / service key **sohbete yazılmamalıdır**; yalnız yerel
> terminal ortam değişkeni (`$PROD_DB_URL`, `$TEST_DB_URL`) olarak kullanılmalıdır.

### Adım 1 — İzole proje
- Canlıdan **tamamen bağımsız** yeni bir Supabase projesi oluştur (ücretsiz plan yeterli).

### Adım 2 — Base şemayı şema-only klonla (VERİSİZ)
```bash
# Seçenek A — Supabase CLI (şema-only, veri YOK)
supabase db dump --db-url "$PROD_DB_URL" \
  --schema public,auth,storage --data-only=false > base_schema.sql

# Seçenek B — pg_dump (şema-only)
pg_dump "$PROD_DB_URL" --schema-only --no-owner --no-privileges \
  -n public -n auth -n storage > base_schema.sql
```
- `--data-only=false` / `--schema-only` → **hiçbir müşteri satırı kopyalanmaz.**
- Gerekirse `_migrations` / Supabase-özel tabloları hariç tutulur.

### Adım 3 — İzole projeye yükle
```bash
psql "$TEST_DB_URL" -f base_schema.sql
```
- Base şema yüklendikten sonra sırayla **güvenlik migration'ları** uygulanır:
  `GUV-02 → GUV-07 → GUV-06 → GUV-01 → GUV-11 → GUV-13 → GUV-13b → GUV-14 → GUV-15`
  (her biri için önce **rollback provası**, sonra migration).

### Adım 4 — Storage bucket'ları + fixtures (yalnız sahte veri)
- 4 private bucket: `atama-belgeleri`, `personel-foto`, `hazop-kanitlari`, `noter-defteri`.
- `psql "$TEST_DB_URL" -f supabase/tests/security/00_harness.sql`
  → `security_test` şeması + yardımcılar + **sahte** `create_fixtures()` (OSGB A/B, firmalar,
  personeller, kullanıcılar, teklifler, storage nesneleri). **Gerçek müşteri verisi yok.**

### Adım 5 — Testleri çalıştır (yalnız izole ortamda)
```bash
supabase test db
# veya
psql "$TEST_DB_URL" -f supabase/tests/security/guv01_storage_isolation.test.sql
# ... her *.test.sql için; her dosya BEGIN ... ROLLBACK ile sarılıdır
```

---

## 4) Fixture üretimi — gerçek veri olmadan
- `supabase/tests/security/00_harness.sql` içindeki `security_test.create_fixtures()`:
  - Sabit (hard-coded) sahte UUID'lerle OSGB A/B, iki A firması + bir B firması, personel,
    kullanıcı (`auth.users`), `profiles`, atama, teklif, teklif hizmeti ve storage nesnesi
    üretir.
  - **Hiçbir gerçek müşteri kaydı kullanılmaz.**
  - Tüm test dosyaları `BEGIN; ... ROLLBACK;` ile sarılıdır → izole ortamda bile kalıcı iz bırakmaz.

---

## 5) Kaynak bulunamazsa (fallback)
Eğer canlıdan şema-only dump alınamıyorsa:
1. **Base şema migration'larının** projeye eklenmesi gerekir (uygulama reposu sahibinden
   `supabase/migrations` **base** dosyaları talep edilmelidir).
2. Base şema elde edilene kadar DB runtime testleri **BLOCKED** kalır.
3. Bu göreve kadar **`auth_role()`/tablo uydurulmadı** ve migration'lar base şemaya göre
   **yeniden sıralanmadı.** (Uydurma şema ile yapılan test sonuçları yanıltıcı olurdu.)

---

## 6) Bu ortamdaki durum

| Adım | Durum |
|---|---|
| İzole test projesi | **Yapılmadı** (Dashboard/karar sahibi gerekiyor) — **BLOCKED** |
| Şema-only dump | **Alınmadı** (canlı DB connection string + yetki gerekiyor) — **BLOCKED** |
| Base şema yükleme | **Yapılmadı** — **BLOCKED** |
| Fixture harness | ✅ hazır (`00_harness.sql`) |
| Test dosyaları | ✅ hazır (7 dosya) |
| Runtime test çalıştırma | **BLOCKED** (izole ortam yok) |

> Özetle: test altyapısı **teknik olarak hazır**; tek eksik **izole proje + şema-only klon**,
> ki bu **kullanıcı/karar sahibi girdisi** gerektirir. Üretime hiçbir şey uygulanmadı.