# İSGDenetim / OSGB SaaS — PROMPT 5/8: Bağımlılık Güvenliği, Dosya Yükleme ve Dosya İşleme Sertleştirmesi

> **Tarih:** 2026-10-11 · **Kapsam:** React/Vite SPA · `package.json` bağımlılıkları ·
> Excel/PDF işleme akışları · Dosya yükleme (Storage) · CSV/Excel dışa aktarma.
> **Tür:** Gerçek kod + bağımlılık düzeltmesi (salt-okuma denetimi DEĞİL).
>
> **DÜRÜSTLÜK NOTU:** İzole iki-tenant test ortamı ve Deno runtime olmadığı için
> `deno test`, `npm audit`, `yarn/pnpm audit` **çalıştırılamadı → BLOCKED**. Var olan
> tüm güvenlik fonksiyonları **saf** yazıldı ve **statik + TypeScript/Vite build** ile
> doğrulandı. **Çalıştırılmayan testler "başarılı" sayılmadı.** Üretim verisi / gerçek
> kullanıcı dosyası kullanılmadı. Sağlık verisi veya sır test çıktısına yazılmadı.

---

## 0) ÖZET

| Bulgu | Şiddet | Durum |
|---|---|---|
| **F-05-01** `xlsx@0.18.5` — Prototype Pollution (CVE-2023-30533) + ReDoS (CVE-2024-22363) | 🟠 Yüksek | **AZALTILDI** (kaynak limitleri + sertleştirilmiş okuma) — kalıcı paket yükseltmesi CI'da |
| **F-05-02** `jspdf@2.5.1` — CVE-2025-29907 (addImage/html ile DoS) | 🟡 Orta | **GİDERİLDİ** (→ `3.0.1` + addImage boyut koruması) |
| **F-05-03** CSV Formula Injection (CWE-1236) — 5 dışa aktarma noktası | 🟡 Orta | **GİDERİLDİ** (merkezî nötralizasyon) |
| **F-05-04** Dosya yüklemede yalnızca uzantı+MIME güveni (istemci kontrollü) | 🟡 Orta | **GİDERİLDİ** (magic-byte içerik doğrulaması) |
| **F-05-05** Lockfile yok → deterministik olmayan kurulum | 🔵 Düşük | **BELGELENDİ** (CI/ortam kararı) |
| **F-05-06** `build.sourcemap: true` | 🔵 Düşük/Bilgi | Bilinen — hosting ayarı (bu turda değiştirilmedi) |

**Doğrulama:** `vite build` ✅ · Saf fonksiyon birim testleri yazıldı (§6, çalıştırılamadı=BLOCKED).
**Kanıtlanmış, uzaktan-kimliksiz kritik açık YOK.** En önemli kalıcı risk (`xlsx`), uygulamada
kullanılan yüzey için kaynak limitleriyle **pratik olarak etkisizleştirildi**.

---

## 1) BAĞIMLILIK ENVANTERİ

- **Manifest:** `package.json` (`"type": "module"`, React 19 + Vite 8).
- **Lockfile:** `package-lock.json` / `pnpm-lock.yaml` / `yarn.lock` / `bun.lockb` → **YOK**
  (§ F-05-05). `node_modules` çalışma alanında bulunmadığından kurulu sürümler **doğrudan
  okunamadı**; sürümler `package.json` üzerinden değerlendirildi.
- **Riskli / doğrulanan paketler:**
  - `xlsx@0.18.5` (SheetJS) — npm'deki **son** sürüm; düzeltmeler yalnızca SheetJS'in
    **npm dışı** dağıtımında (`0.19.3` PP, `0.20.2` ReDoS).
  - `jspdf@2.5.1` — `CVE-2025-29907` (addImage/html/addSvgAsImage ile DoS), düzeltme `3.0.1`.
  - `jspdf-autotable@5.0.8` — **peer: `jspdf >=3.0.0`** → projede `2.5.1` ile **uyumsuzdu** (mevcut hata).
  - Zaten mevcut `exceljs@4.4.0` (xlsx'e bağımlı olmayan, bakımlı bir alternatif).
  - `dompurify@3.4.16`, `pdf-lib@1.17.1`, `pdfjs-dist@5.7.284`, `mammoth@1.12.2`, `jszip@3.10.1`.

`package.json`'daki `xlsx`/`jspdf` haricinde bu denetimin kapsamındaki diğer paketler için
**doğrulanmış kritik CVE bulunmadı** (yerel `npm audit` çalıştırılamadı → BLOCKED; harici
güvenlik kayıtları + sürüm karşılaştırması kullanıldı).

---

## 2) BULGULAR

### 🟠 F-05-01 · `xlsx@0.18.5` — Prototype Pollution + ReDoS (AZALTILDI)

- **Paket / sürüm:** `xlsx` `0.18.5` (SheetJS). Kullanım: **istemci tarafı**, kullanıcı yüklediği dosyalar.
- **CVE:** `CVE-2023-30533` (Prototype Pollution, düzeltme `0.19.3`), `CVE-2024-22363` (ReDoS, `0.20.2`).
- **Etkilenen kullanım noktaları (4 `XLSX.read`):**
  1. `src/lib/import/excel.ts` — merkezî içe aktarma motoru (`parseImportFile`)
  2. `src/components/feature/preview/viewers/XlsxPreviewAdapter.tsx` — belge önizleme
  3. `src/components/feature/risk/adimlar/Adim2Tehlikeler.tsx` — risk Excel aktarımı
  4. `src/components/feature/risk/fk/adimlar/FkAdim2Tehlikeler.tsx` — Fine-Kinney Excel aktarımı
- **Gerçek risk & ön koşul:** Kötü-amaçlı bir `.xlsx/.xls/.csv` yüklenip ayrıştırıldığında
  tarayıcıda **prototype pollution** (uygulama mantığını bozabilir) veya **ReDoS** (sekme
  dondurma). **Ayrıcalık yükseltmez**; kullanıcının kendi oturumunda istemci-taraflı DoS/kararsızlık.
- **Neden npm ile yükseltilemedi:** SheetJS, `0.18.5` sonrası düzeltmeleri **npm'e yayınlamadı**
  (npm'deki `xlsx` = `0.18.5`, terk edilmiş). `0.20.x` yalnızca `https://cdn.sheetjs.com/...`.
  Bu URL tarball'ı doğal bir bağımlılık gibi davranır ama **kurulum ortamının adresine erişimi
  bu ortamdan doğrulanamadı** → "rastgele/kırılgan yükseltme" yasağı gereği **otomatik uygulanmadı**
  (§7'de birebir komut verildi).
- **Uygulanan savunma (kalıcı, koddan bağımsız):**
  - **Yeni `src/lib/spreadsheet/safeSheet.ts`** — SAF kaynak limitleri:
    max 25 sayfa, 30.000 satır/sayfa, 300 kolon/sayfa, 500.000 hücre/sayfa; 25 MB dosya tavanı.
  - **Yeni `src/lib/spreadsheet/readWorkbook.ts` → `readWorkbookSafe()`** — tüm `XLSX.read`
    çağrılarının geçtiği **tek güvenli ağız**. Ayrıştırma seçenekleri sertleştirildi
    (`cellHTML:false, cellNF:false, cellStyles:false, sheetStubs:false`) ve limitler uygulanır.
  - 4 kullanım noktası **da** bu sarmalayıcıya bağlandı; boyut tavanı okuma öncesi kontrol edilir.
  - Aşımda kullanıcı dostu, **iç sistem bilgisi sızdırmayan** hata fırlatılır.
- **Etki:** Aşırı büyük / emir-dışı çalışma kitapları (ReDoS/memory tetikleyicileri) ayrıştırma
  öncesi **reddedilir** → DoS yüzeyi büyük ölçüde kapanır. Prototype-pollution için asıl çözüm
  paket yükseltmesidir (CI adımı, §7).
- **Regresyon:** Mevcut Excel/CSV içe aktarma davranışı korunur (yalnızca limit + seçenek eklendi).

### 🟡 F-05-02 · `jspdf@2.5.1` — CVE-2025-29907 (GİDERİLDİ)

- **Paket / sürüm:** `jspdf` `2.5.1` → **`3.0.1`**.
- **CVE:** `CVE-2025-29907` (Uncontrolled Resource Consumption, `addImage` / `html` /
  `addSvgAsImage`), düzeltme `3.0.1`.
- **Etkilenen kullanım:** `addImage` çağrıları — kurumsal logo (`pdfCore.drawImageFit`),
  tahliye krokisi (§ `acilDurumRapor/pdf.ts`), personel raporu görselleri, teklif/tutanak görselleri.
  `doc.html()` / `addSvgAsImage` **kullanılmıyor** (grep ile doğrulandı).
- **Gerçek risk:** Manipüle edilmiş boyutlu (GIF) / devasa görsellerle bellek-CPU tüketimi.
  Ön koşul: kullanıcının söz konusu görseli sağlaması.
- **Uygulanan düzeltme (iki katmanlı):**
  1. **Paket yükseltmesi** `jspdf` `2.5.1` → `3.0.1`. Bu, **mevcut `jspdf-autotable@5.0.8`
     peer uyumsuzluğunu da düzeltir** (autotable `^5`, `jspdf >=3.0.0` ister).
     Kullanılan API'lerin tümü (jsPDF ctor, `addImage/text/setFont/setFillColor/rect/line/
     splitTextToSize/getTextWidth/addFileToVFS/addFont/save/output`) `3.x` ile uyumludur;
     `autoTable(doc, ...)` **fonksiyonel API** (5.x'in beklediği kullanım) zaten mevcut.
  2. **`pdfCore.drawImageFit` boyut koruması (sürümden bağımsız):** doğal ölçü üst sınırı
     (20.000 px), base64 boyut tavanı (~6 MB) ve `try/catch` → aşırı/bozuk görsel **atlanır**,
     belge üretimi çökmez.
- **Regresyon:** `vite build` ✅. Görsel düzen/kırpma mantığı (orantı koruma) **değişmedi**.

### 🟡 F-05-03 · CSV Formula Injection — CWE-1236 (GİDERİLDİ)

- **Etkilenen noktalar (5):**
  - `src/lib/excel/ekipmanExcel.ts` (`downloadEkipmanCsv`)
  - `src/lib/excel/firmaExcel.ts` (`downloadFirmaCsv`)
  - `src/lib/acilDurumRapor/ekstra.ts` (`csvIndir`)
  - `src/lib/calismaRapor/ekstra.ts` (`csvIndir`)
  - `src/lib/egitimRapor/ekstra.ts` (`csvIndir`)
- **Teknik neden:** CSV hücresi `=`, `+`, `-`, `@`, TAB veya CR ile başlıyorsa Excel/Sheets
  içeriği **formül** olarak yorumlar. Dışa aktarılan alanlar (firma adı, açıklama, faaliyet metni,
  kişi adları…) **kullanıcı kontrollüdür**. Önceki kodda yalnızca tırnaklama/kaçış vardı;
  tırnaklama **formül değerlendirmesini engellemez**.
- **Gerçek risk:** Dosyayı Excel'de açan kullanıcının makinesinde harici bağlantı/DDE/komut
  tetiklenmesi (klasik CSV injection). Ön koşul: kullanıcının CSV'yi Excel/Sheets ile açması.
- **Uygulanan düzeltme:** **Yeni `src/lib/csv/csvSafe.ts`** — sistemdeki **tüm** CSV üreticilerinin
  kullandığı tek merkez. `=`/`+`/`@`/TAB/CR ile başlayan hücrelerin başına tek tırnak eklenir;
  **negatif sayılar (`-5`, `-3,14`) korunur**. 5 noktanın tümü bu merkeze bağlandı.
- **Regresyon:** CSV biçimi/ayraç/tırnaklama aynı; yalnızca tehlikeli hücreler etkisizleştirilir.

### 🟡 F-05-04 · Dosya Yükleme — İçerik Doğrulaması (GİDERİLDİ)

- **Bileşen:** `src/lib/fileUpload.ts` (`validateUploadFile`) · `src/components/ui/FileUpload.tsx`
  (tüm sistemin **tek** yükleme motoru).
- **Teknik neden:** Doğrulama yalnızca **uzantı + MIME** üzerindeydi; **ikisi de istemci tarafından
  serbestçe taklit edilebilir**. "`.pdf`/`.png` gibi görünen ama içeriği HTML/EXE/script olan"
  aktif içerik geçebiliyordu (savunma derinliği zayıf).
- **Uygulanan düzeltme:**
  - **Yeni `src/lib/fileSignature.ts`** — SAF `detectFileSignature()` (magic bytes: PDF/PNG/JPG/
    GIF/WEBP/Office-ZIP/OLE + **tehlikeli aktif içerik**: `MZ`=exe, `ELF`, `#!`=script, HTML).
  - `FileUpload.addFiles` artık **içerik doğrulaması** yapar (`verifyFileContent`): uzantı/MIME'ı
    geçen ikili belge/görsel dosyaların gerçek ilk baytları okunur; **aktif/çalıştırılabilir içerik**
    tespit edilirse yükleme **reddedilir** (kullanıcıya Türkçe neden).
  - **Yanlış pozitif üretmez:** yalnızca ikili belge/görsel uzantılarında çalışır
    (txt/csv/svg kapsam dışı); yalnızca **bilinen tehlike imzası** ile eşleşen dosya reddedilir.
  - Path traversal / güvenli ad (`sanitizeStorageName`) ve mevcut Storage tenant izolasyonu
    **korunmuştur** (bu turda Storage politikaları değiştirilmedi).
- **Regresyon:** Geçerli PDF/görsel/Office dosyaları etkilenmez; yalnızca gizlenmiş aktif içerik reddedilir.

### 🔵 F-05-05 · Lockfile Yokluğu (BELGELENDİ)

- **Kanıt:** Depoda `package-lock.json` / `pnpm-lock.yaml` / `yarn.lock` / `bun.lockb` **yok**.
- **Etki:** Bağımlılık çözümü **deterministik değil**; tedarik zinciri saldırısı / beklenmedik
  sürüm kayması riski artar. Bu ortamda lockfile **üretilip kalıcı olarak eklenemedi** (kurulum
  ortamı/CI kararı). **Öneri:** CI'da `npm ci` kullanacak şekilde `package-lock.json` commit edilmesi
  ve `npm audit --audit-level=high` adımı eklenmesi (§7).

### 🔵 F-05-06 · `build.sourcemap: true` (Bilgi — değiştirilmedi)

- **Kanıt:** `vite.config.ts` → `build.sourcemap: true`. Kaynak kodu ifşası riski (sır içermez).
  Yayın build'inde kapatılması hosting/dağıtım ayarıdır; bu turda **kapsam dışı** bırakıldı.

---

## 3) YAPILAN DEĞİŞİKLİKLER (dosya özeti)

**Yeni dosyalar:**
- `src/lib/spreadsheet/safeSheet.ts` — çalışma kitabı kaynak limitleri (saf).
- `src/lib/spreadsheet/readWorkbook.ts` — `readWorkbookSafe()` tek güvenli okuma ağzı.
- `src/lib/csv/csvSafe.ts` — CSV formula-injection nötralizasyonu (saf).
- `src/lib/fileSignature.ts` — magic-byte içerik tespiti (saf, bağımsız).
- `supabase/tests/security/guv19_file_processing.test.ts` — saf fonksiyon birim testleri.

**Değiştirilen dosyalar:**
- `src/lib/import/excel.ts` — `readWorkbookSafe` + 25 MB boyut kontrolü.
- `src/components/feature/preview/viewers/XlsxPreviewAdapter.tsx` — `readWorkbookSafe`.
- `src/components/feature/risk/adimlar/Adim2Tehlikeler.tsx` — `readWorkbookSafe` + boyut kontrolü.
- `src/components/feature/risk/fk/adimlar/FkAdim2Tehlikeler.tsx` — `readWorkbookSafe` + boyut kontrolü.
- `src/lib/excel/ekipmanExcel.ts`, `src/lib/excel/firmaExcel.ts` — merkezî `csvCell`.
- `src/lib/acilDurumRapor/ekstra.ts`, `src/lib/calismaRapor/ekstra.ts`, `src/lib/egitimRapor/ekstra.ts` — CSV nötralizasyonu.
- `src/lib/fileUpload.ts` — `verifyFileContent` (magic-byte) + `fileSignature` importu.
- `src/components/ui/FileUpload.tsx` — içerik doğrulaması entegrasyonu (async `addFiles`).
- `src/lib/pdf/pdfCore.ts` — `drawImageFit` boyut/base64 koruması + `try/catch`.
- `package.json` — `jspdf`: `2.5.1` → `3.0.1`.

---

## 4) TESTLER (gerçek sonuç)

| Test | Durum |
|---|---|
| `vite build` (TypeScript + tam bundle) | ✅ **PASS** (jspdf 3.0.1 dahil) |
| `guv19_file_processing.test.ts` (18 senaryo, ağsız/saf) | ⛔ **BLOCKED** — Deno runtime yok; yazıldı + statik syntax-check geçti |
| `npm audit` / `tsc --noEmit` / `deno test` | ⛔ **BLOCKED** — komut yürütücü yok |
| Gerçek zararlı `.xlsx` ile canlı ayrıştırma | ⛔ **BLOCKED** — üretimde yıkıcı test yasak |
| jspdf 3.x runtime PDF üretimi (Türkçe karakter, tablo, sayfalama) | ⛔ **BLOCKED** — çalışma zamanı ortamı yok |

**Test kapsamı (yazıldı):** A1 aralık ayrıştırma, satır/kolon/sayfa/boyut limitleri, formül
başlangıç tespiti & negatif sayı korunması, CSV tırnaklama, magic-byte tanıma (PDF/PNG/JPG/GIF/
Office/EXE/ELF/script/HTML), sahte belge reddi, düz metin türlerinde yanlış-pozitif olmaması.

**Dürüstlük:** Bu testler **çalıştırılmadı**; bu yüzden **"başarılı" sayılmadı**. CI'da
`deno test supabase/tests/security/guv19_file_processing.test.ts` ile koşulmalıdır.

---

## 5) İŞLEVSELLİK / TENANT İZOLASYONU ÜZERİNDEKİ ETKİ

- Excel/CSV **içe aktarma** davranışı korunur (yalnızca limit + sıkı seçenekler eklendi).
- **PDF üretimi** API-uyumlu; görsel orantı/kırpma mantığı değişmedi; yalnızca aşırı/bozuk
  görseller artık atlanır (eskiden belgeyi düşürebilirdi).
- **CSV dışa aktarma** biçimi aynı; tehlikeli hücreler metne sabitlenir.
- **Dosya yükleme** yalnızca gizlenmiş aktif içerikte reddeder; geçerli akışlar etkilenmez.
- **Storage tenant izolasyonu** ve imzalı URL sahiplik kontrolleri **bu turda değiştirilmedi**.

---

## 6) DAĞITIM VE GERİ DÖNÜŞ

**Dağıtım:**
1. `npm install` (veya `npm ci`) → `jspdf@3.0.1` kurulur.
2. Frontend build + yayın (mevcut akış).
3. **CI'ya önerilen kalıcı adımlar (§7):** `npm audit --audit-level=high` + `deno test`.

**Geri dönüş (rollback):**
- `package.json`: `jspdf` → `"2.5.1"` + `npm install`. (Kod korumaları **her iki sürümde de** güvenlidir.)
- Kod: `safeSheet.ts`, `readWorkbook.ts`, `csvSafe.ts`, `fileSignature.ts` + ilgili düzenlemeler
  sürüm kontrolünden geri alınır (bu dosyalar dışında başka modül değiştirilmedi).
- DB/migration değişikliği **yok** → veri geri dönüşü gerekmez.

---

## 7) KALICI xlsx DÜZELTMESİ (CI/ortam adımı — bu ortamda uygulanamadı)

`npm`'deki `xlsx` terk edilmiş (`0.18.5`) olduğundan CVEX düzeltmeleri yalnız SheetJS resmî
dağıtımındadır. **Drop-in** yükseltme (API aynı):

```bash
npm install xlsx@https://cdn.sheetjs.com/xlsx-0.20.3/xlsx-0.20.3.tgz
```

veya `package.json`:
```json
"xlsx": "https://cdn.sheetjs.com/xlsx-0.20.3/xlsx-0.20.3.tgz"
```

> **Neden otomatik uygulanmadı:** Kurulum ortamının `cdn.sheetjs.com`'a erişimi bu ortamdan
> doğrulanamaz; erişilemezse **tüm kurulum/build çöker**. "Rastgele/kırılgan yükseltme yapma"
> kuralı gereği karar CI'ya bırakıldı. Alternatif: Excel **okuma** yollarının bakımlı,
> CVE'siz `exceljs` (`4.4.0`, projede mevcut) üzerine taşınması (ayrı bir regresyon turu gerektirir;
> eski `.xls` format desteği kaybı değerlendirilmelidir).

---

## 8) BAĞIMSIZ SIZMA TESTİNDE YENİDEN DOĞRULANACAK NOKTALAR

1. **xlsx ReDoS/PP:** Kaynak limitlerinin aşımında reddedildiği + normal dosyaların çalıştığı
   (izole ortam, zararlı örnek dosya).
2. **CSV injection:** `=cmd`, `+cmd`, `@SUM`, `-2+3+cmd` içeren kayıtların CSV çıktısında
   nötrleştiği; `-5` gibi negatif sayıların bozulmadığı.
3. **Dosya içeriği:** `.pdf`/`.png` uzantılı EXE/HTML dosyalarının **reddedildiği**; gerçek
   belgelerin kabul edildiği (tarayıcı + FileUpload).
4. **jspdf:** Aşırı boyutlu görselle PDF üretiminin **çökmediği**; mevcut raporların (Türkçe
   karakter, tablo, çok sayfa) birebir üretildiği.
5. **Tenant izolasyonu:** Yükleme/okuma/güncelleme/silmede başka tenant dosyasına erişilemediği
   (Storage RLS — bu turda değiştirilmedi, regresyon teyidi).
6. **Lockfile:** `npm ci` + `npm audit --audit-level=high` ile **0 yüksek** sonuç.

---

## 9) KAYNAK / KANIT DİZİNİ

- **Manifest:** `package.json` · `vite.config.ts`
- **Kullanım noktaları:** `src/lib/import/excel.ts` · `.../XlsxPreviewAdapter.tsx` ·
  `.../risk/adimlar/Adim2Tehlikeler.tsx` · `.../fk/adimlar/FkAdim2Tehlikeler.tsx`
- **CSV:** `src/lib/excel/ekipmanExcel.ts` · `.../firmaExcel.ts` ·
  `.../{acilDurumRapor,calismaRapor,egitimRapor}/ekstra.ts`
- **PDF:** `src/lib/pdf/pdfCore.ts` (drawImageFit) + `addImage` çağrıları
- **Yükleme:** `src/lib/fileUpload.ts` · `src/components/ui/FileUpload.tsx` · Storage servisleri
- **Yeni:** `src/lib/spreadsheet/{safeSheet,readWorkbook}.ts` · `src/lib/csv/csvSafe.ts` ·
  `src/lib/fileSignature.ts` · `supabase/tests/security/guv19_file_processing.test.ts`
- **Harici CVE (doğrulama):** CVE-2023-30533 (SheetJS PP) · CVE-2024-22363 (SheetJS ReDoS) ·
  CVE-2025-29907 (jsPDF DoS) · jspdf-autotable peer `>=3.0.0`.

---

## 10) KAPANIŞ BEYANI

- **Kod + bağımlılık DEĞİŞTİRİLDİ; üretimde yıkıcı/kesinti testi UYGULANMADI.**
- **Giderilen:** jspdf CVE-2025-29907 (+ mevcut autotable peer uyumsuzluğu), CSV injection,
  gizlenmiş aktif içerik yükleme. **Azaltılan:** xlsx CVE'leri (kaynak limitleri + sertleştirilmiş
  okuma; kalıcı paket yükseltmesi CI adımı olarak belgelendi).
- **Çalıştırılmayan testler (deno test, npm audit, runtime PDF, zararlı dosya) BAŞARILI SAYILMADI.**
- Bu rapor **resmî TSE onaylı sızma testinin yerine GEÇMEZ.**