# İSGDenetim — Güvenlik Migration Bağımlılık ve Rollback Analizi (Faz 7)

> **Kapsam:** GUV-01, GUV-02, GUV-06, GUV-07, GUV-11, GUV-13 ve GUV-14 migration'ları ile
> bunların rollback dosyalarının bağımlılık, ön koşul, idempotency ve rollback kapsamı
> analizi.
>
> **Yöntem:** (a) 7 migration + 7 rollback dosyasının tam içeriği okundu, (b) canlı
> Supabase'de **yalnızca salt-okuma** `SELECT` (pg_proc / pg_policies / information_schema
> / has_function_privilege / storage.buckets), (c) uygulama kodu incelemesi.
>
> **SINIR:** Bu doküman hazırlık amaçlıdır. Üretim veritabanına **hiçbir DDL/DML
> uygulanmadı**, hiçbir migration çalıştırılmadı, hiçbir Edge Function deploy edilmedi.
> Burada yazılanlar **gerçek çalıştırılmış test sonucu DEĞİLDİR**; statik inceleme + canlı
> metadata gözlemidir.

---

## 0) Canlı durum özeti (salt-okuma kanıtları, Faz 7)

| Kontrol | Canlı sonuç | Anlam |
|---|---|---|
| `storage_tenant_ok` fonksiyonu | **YOK** | GUV-01 uygulanmadı |
| `noter_defteri_obj_read` policy roller | **`{public}`** | GUV-01 (anon kapama) uygulanmadı |
| `teklifler` / `teklif_hizmetleri` RESTRICTIVE policy | **0 / 0** | GUV-06 uygulanmadı |
| `atamalar/evraklar/firmalar/personeller` `*_osgb_access_guard` | **RESTRICTIVE (zaten canlı)** | Guard policy'ler base şemadan; GUV-07 yalnız FONKSİYONU sertleştirir |
| `osgb_access_ok()` gövdesi | `auth_osgb_id() IS NULL` dalı **hâlâ var** | GUV-07 fonksiyon sertleştirmesi uygulanmadı |
| `handle_new_user()` metadata okuması | **hâlâ var** | GUV-02 uygulanmadı |
| 6 fonksiyon `anon` EXECUTE | **6/6 true** | GUV-11 uygulanmadı |
| anon'un EXECUTE edebildiği definer fonksiyon | **159** (çağrılabilir 104) | GUV-13 uygulanmadı |
| 4 definer fonksiyon `search_path` | **null** | GUV-14 uygulanmadı |
| 4 bucket `public` | **hepsi `false`** | RLS tek kapı; düzeltme kritik |

---

## 1) GUV-01 · Storage tenant izolasyonu

**Dosya:** `supabase/migrations/20260101000100_guv01_storage_tenant_isolation.sql`
**Rollback:** `supabase/migrations/rollback/20260101000100_guv01_storage_tenant_isolation_rollback.sql`

### Oluşturduğu/değiştirdiği nesneler
- **Yeni fonksiyon:** `public.storage_tenant_ok(text, text)` (STABLE, SECURITY DEFINER,
  `SET search_path = public`).
- `storage.objects` üzerinde **4 bucket × politika** (read + insert + update + delete;
  hazop/noter için ilgili olanlar): `atama_belgeleri_obj_*`, `personel_foto_obj_*`,
  `hazop_kanit_storage_*`, `noter_defteri_obj_*`.

### Bağımlılıklar (canlıda doğrulandı)
| Tür | Nesne | Durum |
|---|---|---|
| Fonksiyon | `auth_role()`, `auth_osgb_id()`, `auth_firma_id()` | ✅ mevcut (definer) |
| Fonksiyon | `has_active_firma_assignment(uuid, uuid)` | ✅ mevcut (definer) |
| Fonksiyon | `storage.foldername(text)` | ✅ Supabase Storage yerleşik |
| Tablo/kolon | `atama_belgeleri(dosya_path, osgb_id NOT NULL, firma_id NOT NULL)` | ✅ |
| Tablo/kolon | `personeller(foto_url, osgb_id NOT NULL, firma_id)` | ✅ |
| Tablo/kolon | `hazop_kanitlari(storage_path NOT NULL, osgb_id NULLABLE, firma_id NOT NULL)` | ✅ |
| Tablo/kolon | `noter_defteri_ekleri(storage_path, osgb_id NOT NULL, firma_id NOT NULL)` | ✅ |
| Storage | `storage.objects`, `storage.buckets` (4 bucket) | ✅ |

> Not: `hazop_kanitlari.osgb_id` **nullable**'dır; `storage_tenant_ok`'un hazop dalı
> `h.osgb_id = auth_osgb_id()` eşitliği kullandığından `osgb_id IS NULL` olan hazop
> satırları **sahibi/admin dışında kimseye görünmez** (varsayılan DENY). Bu bilinçli,
> ama test edilmesi gereken bir davranıştır.

### Ön koşullar
1. Yukarıdaki yardımcı fonksiyonlar ve tablo/kolonlar mevcut olmalı (✅ doğrulandı).
2. Düşürülen policy adları canlıyla birebir eşleşmeli
   (`atama_belgeleri_obj_read`, `personel_foto_obj_read`, `hazop_kanit_storage_select`,
   `hazop_kanit_storage_insert`, `hazop_kanit_storage_delete`, `noter_defteri_obj_read`,
   `noter_defteri_obj_insert`, `noter_defteri_obj_delete`).
3. `storage` şeması üzerinde policy oluşturma yetkisi (migration'ı çalıştıran rol).

### Idempotency
✅ İdempotent. `CREATE OR REPLACE FUNCTION`, `DROP POLICY IF EXISTS <isim>` + `CREATE POLICY`.
Tekrar çalıştırma güvenlidir; ikinci çalıştırma politika adlarını yeniden oluşturur.

### Rollback kapsamı
| Geri ALIR | Geri ALAMAZ |
|---|---|
| 4 bucket'ın 8 politikasını bucket-only / `{public}` orijinal hâline döndürür | — (veri silinmez, tablo değişmez) |
| UPDATE politikalarını kaldırır (orijinalde yoktu) | — |
| `DROP FUNCTION public.storage_tenant_ok(text, text)` | — |

### Rollback sonrası risk
⚠️ Rollback, **cross-tenant okuma + noter anon erişimi açığını GERİ AÇAR.** Yalnızca acil
geri dönüş için kullanılmalıdır.

### Meşru erişimi bozma riski
- **Düşük-orta:** İlişkisel kaydı henüz yazılmamış (orphan) bir dosyaya, sahibi/admin
  dışında biri erişmek isterse engellenir (istenen davranış, ama eski akışta çalışıyorduysa
  "erişim kaybı" gibi görünebilir).
- **Orta:** `atama-belgeleri` dalı yalnız `osgb_admin` + `admin` + sahibi kapsar; `firma`
  veya `uzman/hekim` rolleri bu bucket'ta ilişkisel kayıt üzerinden erişemez (tablo RLS'i
  zaten böyleydi → tutarlı).
- **Not:** `hazop-kanitlari` INSERT artık `folder[1]=auth.uid()` + rol ister. Uygulamada
  hazop yükleme kodu bulunamadı (bucket 0 nesne). Yükleme akışı yazıldığında yolun
  `${uid}/...` kuralına uyması zorunludur, aksi hâlde yükleme reddedilir.

---

## 2) GUV-02 · handle_new_user rol yükseltmesi

**Dosya:** `supabase/migrations/20260101000200_guv02_handle_new_user.sql`
**Rollback:** `supabase/migrations/rollback/20260101000200_guv02_handle_new_user_rollback.sql`

### Değiştirdiği nesneler
- `public.handle_new_user()` (CREATE OR REPLACE, SECURITY DEFINER, `search_path=public`).
- `REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated`.

### Bağımlılıklar
| Tür | Nesne | Durum |
|---|---|---|
| Trigger | `auth.users` üzerinde `on_auth_user_created` → `handle_new_user()` | ✅ (base şema) |
| Tablo/kolon | `profiles(id, email, role, first_name, last_name, avatar_url)` | ✅ |
| Sunucu akışı | `accept-invite` edge function (rolü `davetler.role`'den `profiles.upsert` ile yazar) | ✅ (kod incelendi) |

### Ön koşullar
- `profiles` tablosu ve `on_auth_user_created` trigger'ı mevcut olmalı.
- Bootstrap admin e-postası (`info@isgdenetim.com.tr`) sabit koddadır.

### Idempotency
✅ `CREATE OR REPLACE FUNCTION` → tekrar çalıştırma güvenli. `REVOKE` de idempotent.

### Rollback kapsamı
| Geri ALIR | Geri ALAMAZ |
|---|---|
| Orijinal gövdeyi (metadata `role` okuması) geri kurar | `accept-invite` ile atanmış profesyonel rolleri ETKİLEMEZ (trigger bağımsız) |
| `GRANT EXECUTE ... TO PUBLIC` geri kurar | — |

### Rollback sonrası risk
⚠️ İstemci metadata'sından rol okuma (privilege escalation) açığını **geri açar.**

### Meşru erişimi bozma riski
- **Çok düşük:** Davet akışı rolü `davetler.role`'den yazar; trigger metadata'sına bağımlı
  değildir → kırılmaz (kod ile doğrulandı).
- `handle_new_user()` PUBLIC'ten alınsa da trigger çalışırken çağıran EXECUTE izni
  gerekmez → akış bozulmaz.

### ⚠️ Sınır (dürüst not)
Sabit `info@isgdenetim.com.tr → admin` istisnası **yalnız e-posta karşılaştırmasıdır** ve
tek başına yeterli DEĞİLDİR. Supabase Auth'ta **self-signup KAPALI** olmalıdır. Bu ayar
koddan doğrulanamaz → Dashboard kontrolü gerekir (**BLOCKED**).

---

## 3) GUV-06 · teklifler / teklif_hizmetleri RESTRICTIVE

**Dosya:** `supabase/migrations/20260101000300_guv06_teklifler_tenant_restrictive.sql`
**Rollback:** `supabase/migrations/rollback/20260101000300_guv06_teklifler_tenant_restrictive_rollback.sql`

### Oluşturduğu nesneler
- `teklifler_tenant_restrictive` (AS RESTRICTIVE, FOR ALL) — `public.teklifler`.
- `teklif_hizmetleri_tenant_restrictive` (AS RESTRICTIVE, FOR ALL) — `public.teklif_hizmetleri`.

### Bağımlılıklar
| Tür | Nesne | Durum |
|---|---|---|
| Fonksiyon | `auth_role()`, `auth_osgb_id()` | ✅ |
| Tablo/kolon | `teklifler.osgb_id (NOT NULL)`, `teklif_hizmetleri.osgb_id (NOT NULL)` | ✅ |
| RPC (SECURITY DEFINER) | `teklif_kaydet(uuid,jsonb,jsonb)`, `teklif_sil(uuid)`, `teklif_hizmet_aciklama_kaydet(uuid,jsonb)` | ✅ (RLS'i baypas eder → yazma bozulmaz) |

### Ön koşullar
- `teklifler` / `teklif_hizmetleri` tabloları ve `osgb_id` kolonları mevcut olmalı (✅).
- Bu isimlerde daha önce RESTRICTIVE policy olmamalı (✅ canlıda 0).

### Idempotency
✅ `DROP POLICY IF EXISTS` + `CREATE POLICY` → tekrar çalıştırma güvenli.

### Rollback kapsamı
| Geri ALIR | Geri ALAMAZ |
|---|---|
| Eklenen 2 RESTRICTIVE policy'yi düşürür | Mevcut PERMISSIVE policy'leri DEĞİŞTİRMEZ (korunur) |

### Meşru erişimi bozma riski
- **Düşük:** Mevcut PERMISSIVE politikalar zaten tenant-scoped olduğundan RESTRICTIVE
  eklemek meşru okumayı bozmaz. Yazma SECURITY DEFINER RPC üzerinden → RLS devrede değil.
- **Not (dürüst sınıflandırma):** Canlı PERMISSIVE politikalar zaten
  `auth_role()='admin' OR (osgb_admin AND osgb_id=auth_osgb_id())` kapsamlıdır → **aktif
  cross-tenant sızma doğrulanamadı**; bu madde **defense-in-depth** sertleştirmesidir.

---

## 4) GUV-07 · osgb_access_ok()

**Dosya:** `supabase/migrations/20260101000400_guv07_osgb_access_ok.sql`
**Rollback:** `supabase/migrations/rollback/20260101000400_guv07_osgb_access_ok_rollback.sql`

### Değiştirdiği nesneler
- `public.osgb_access_ok()` (CREATE OR REPLACE, STABLE, SECURITY DEFINER, `search_path=public`).
  **Not:** Policy OLUŞTURMAZ. Guard policy'ler zaten base şemada canlıdadır (canlı doğrulandı:
  `atamalar_osgb_access_guard`, `evraklar_osgb_access_guard`, `firmalar_osgb_access_guard`,
  `personeller_osgb_access_guard` → hepsi RESTRICTIVE, mevcut).

### Bağımlılıklar
| Tür | Nesne | Durum |
|---|---|---|
| Fonksiyon | `auth_role()`, `auth_osgb_id()` | ✅ |
| Tablo/kolon | `osgb(id, deleted_at, is_active, erisim_baslangic, erisim_bitis)` | ✅ |
| Policy (mevcut) | 4 tablonun `*_osgb_access_guard` RESTRICTIVE policy'si | ✅ (base) |

### Ön koşullar
- `osgb` tablosu ve yukarıdaki kolonlar mevcut olmalı (✅).
- Guard policy'ler `osgb_access_ok()` çağırıyor olmalı (✅).

### Idempotency
✅ `CREATE OR REPLACE FUNCTION` → tekrar çalıştırma güvenli.

### Rollback kapsamı
| Geri ALIR | Geri ALAMAZ |
|---|---|
| Orijinal gövdeyi (`auth_osgb_id() IS NULL → TRUE` dalı dahil) geri kurar | Policy'leri DEĞİŞTİRMEZ (GUV-07 policy değiştirmiyor) |

### Rollback sonrası risk
⚠️ `NULL → TRUE` dalını geri açar → RESTRICTIVE guard'ı **etkisiz (no-op)** kılar.

### Meşru erişimi bozma riski
- **Regresyon riski DÜŞÜK (kanıtlı):** `accept-invite`, firma profillerine
  `osgb_id = davet.osgb_id` yazar (kod incelendi) → **firma kullanıcılarının `osgb_id`'si
  doludur**, sertleştirme firma erişimini bozmaz.
- **Kapatılan:** `osgb_id` NULL olan (anon, 'pending', yetkisiz) hesaplar guard'ı artık
  geçemez (istenen davranış).

---

## 5) GUV-11 · anon EXECUTE izinleri

**Dosya:** `supabase/migrations/20260101000500_guv11_revoke_anon_execute.sql`
**Rollback:** `supabase/migrations/rollback/20260101000500_guv11_revoke_anon_execute_rollback.sql`

### Değiştirdiği nesneler (yalnız GRANT/REVOKE)
| Fonksiyon | İmza | İşlem |
|---|---|---|
| `announcement_audit` | `()` | REVOKE PUBLIC, anon, authenticated |
| `announcement_normalize` | `()` | REVOKE PUBLIC, anon, authenticated |
| `atama_belgeleri_derive` | `()` | REVOKE PUBLIC, anon, authenticated |
| `_cleanup_personel_mig` | `()` | REVOKE PUBLIC, anon, authenticated |
| `auth_role` | `()` | REVOKE PUBLIC, anon → GRANT authenticated |
| `next_tutanak_no` | `()` | REVOKE PUBLIC, anon → GRANT authenticated |
| `teklif_kaydet`, `teklif_sil`, `teklif_hizmet_aciklama_kaydet`, `teklif_gonderim_kaydet`, `teklif_durum_guncelle`, `teklif_public_token_uret` | (gerçek imzalar) | REVOKE PUBLIC, anon → GRANT authenticated |
| `teklif_public_get/view/action` | (text…) | GRANT anon, authenticated (KORUNUR) |

### Bağımlılıklar
- **Fonksiyon imzaları birebir olmalı.** Canlı doğrulama:
  `_cleanup_personel_mig()` **SECURITY DEFINER = false (INVOKER)**, diğer 5'i definer.
  İmzaların hepsi `()` (argümansız) → `REVOKE ... ()` sözdizimi geçerli ✅.
- Teklif yazma RPC imzaları: `teklif_kaydet(uuid,jsonb,jsonb)`, `teklif_sil(uuid)`,
  `teklif_hizmet_aciklama_kaydet(uuid,jsonb)`, `teklif_gonderim_kaydet(uuid,text,text,text,text[],boolean)`,
  `teklif_durum_guncelle(uuid,text)`, `teklif_public_token_uret(uuid)` ✅ (canlı imzalarla eşleşiyor).

### Ön koşullar
- Bu fonksiyonlar ve **tam imzaları** mevcut olmalı. (İmza yanlışsa migration **hata verir**.)
- `teklif_public_get/view/action` ve `teklif_public_token_uret` mevcut olmalı.

### Idempotency
✅ `REVOKE` / `GRANT` idempotent → tekrar çalıştırma güvenli.

### Rollback kapsamı
| Geri ALIR | Geri ALAMAZ |
|---|---|
| Kaldırılan PUBLIC (anon dahil) izinlerini geri kurar | — |

### Rollback sonrası risk
⚠️ anon erişimini geri açar (gereksiz geniş erişim).

### Meşru erişimi bozma riski
- **Düşük:** Trigger fonksiyonları EXECUTE izni gerektirmez → akışlar bozulmaz.
- **Test edilmesi gereken:** `service_role`'ün yalnız PUBLIC grant'a bağlı çağrısı varsa
  kesilebilir (grant yalnız `authenticated` verildiği için `service_role` de
  `authenticated` değildir → **`service_role` EXECUTE'u PUBLIC grant'a bağlıydı**).
  Ancak `service_role` Edge Function'ları genelde `SERVICE_ROLE_KEY` ile PostgREST üzerinden
  çağırır; RLS bypass + fonksiyon sahibi yetkisi nedeniyle pratikte etkilenmemesi beklenir.
  **Mutlaka izole ortamda doğrulanmalıdır (BLOCKED).**

> ⚠️ **Gerçek düzeltme notu:** GUV-11'in teklif RPC'leri için `GRANT ... TO authenticated`
> vermesi `service_role`'ü kapsamaz. GUV-13 ise `service_role`'e ayrıca grant verir. Bu
> tutarsızlık, edge function RPC erişimi için izole testte doğrulanmalıdır.

---

## 6) GUV-13 · anon/PUBLIC SECURITY DEFINER RPC daraltması

**Dosya:** `supabase/migrations/20260101000600_guv13_revoke_anon_definer_rpc.sql`
**Rollback:** `supabase/migrations/rollback/20260101000600_guv13_revoke_anon_definer_rpc_rollback.sql`

### Değiştirdiği nesneler (dinamik `DO` bloğu)
- Hedef isim listesindeki **`public` şemasında `SECURITY DEFINER = true`** olan fonksiyonların
  **TÜM overload'ları** için:
  `REVOKE EXECUTE ON FUNCTION <sig> FROM PUBLIC, anon` +
  `GRANT EXECUTE ON FUNCTION <sig> TO authenticated, service_role`.

### GUV-13 hedef çözünürlüğü — GERÇEK DOĞRULAMA (salt-okuma)
Blok `pg_proc` üzerinden `p.prosecdef = true AND p.proname = ANY(hedef)` seçer ve
`p.oid::regprocedure` ile **gerçek imzayı** kullanır → imza uyuşmazlığı **imkânsız**.

- **Listedeki 54 ismin tamamı canlıda definer fonksiyon olarak MEVCUT** ✅ (tek tek doğrulandı).
- **Overload'lar (regprocedure ile çözülen):** `atama_create` ×4, `atama_update` ×2,
  `uygunsuzluk_manuel_kapat` ×2. Blok bunların **hepsini** yakalar.
- **Silinen/kaldırılan isim yok** → blok hata vermez, yalnız var olanları işler. ✅

### ⛔ GUV-13 KAPSAM AÇIĞI (yeni bulgu — Faz 7)
Canlıda `anon`'un EXECUTE edebildiği definer fonksiyon **159**, bunlardan trigger döndürmeyen
(gerçekten çağrılabilir) **104**. GUV-13 hedef listesi bunların bir kısmını kapsar; **kapsam
DIŞINDA kalan, anon'un çağırabildiği 23 definer fonksiyon** (RLS yardımcıları + birkaç
bakım/özet fonksiyonu) tespit edildi:

```
atama_firma_durum_ozet(), atama_rol_doygunluk(), firma_aktif_atamalar(uuid),
firma_aktif_personel_sayisi(uuid), firma_calisan_sayisi(uuid),
has_active_primary_assignment(uuid,uuid), has_active_primary_firma_assignment(uuid,uuid),
has_active_uzman_assignment(uuid,uuid), hazard_change_detect(uuid,text),
mesajlasma_conversation_unread_count(uuid), mesajlasma_is_participant(uuid),
mesajlasma_last_messages(uuid[]), mesajlasma_unread_count(), mesajlasma_unread_counts(uuid,uuid[]),
operasyon_bakim_hatirlatma(), operasyon_entity_accessible(text,uuid), osgb_erisim_acik(uuid),
personel_aktif_bagimliliklar(uuid), personel_atama_sure_plan(), personel_saglik_ozet(uuid[]),
personel_validity_resolve(uuid,text,date), project_myk_requirements(),
resolve_hazard_change_assignment(uuid,text)
```
- Bunlardan **RLS yardımcıları** (`mesajlasma_is_participant`, `osgb_erisim_acik`,
  `personel_validity_resolve`, `resolve_hazard_change_assignment`, `has_active_*`,
  `operasyon_entity_accessible`) politikalar içinde kullanılabilir → dokunulmaması savunulabilir.
- Ancak **`operasyon_bakim_hatirlatma()`, `personel_atama_sure_plan()`,
  `atama_firma_durum_ozet()`, `atama_rol_doygunluk()`, `project_myk_requirements()`,
  `personel_saglik_ozet()`, `firma_*` özetleri** gibi bakım/özet fonksiyonları da
  anon-çağrılabilir → **daraltılması önerilen ek hedeflerdir.**
- **`next_tutanak_no()`** bu listede görünür ama **GUV-11** tarafından zaten kapatılır.

> Bu açık, Faz 7 raporunda **"Kod incelemesi gerekli / Test edilmedi"** olarak işaretlenmiştir;
> GUV-13 hedef listesi genişletilmeden bu 23 fonksiyon için tam kapanma iddia EDİLEMEZ.

### Bağımlılıklar
- `pg_proc`, `pg_namespace` (okuma). Hedef fonksiyonların **var olması** (isim + definer).
- Hedeflerin **başka fonksiyonlar/edge function'lar tarafından çağrılıp çağrılmadığı**:
  Blok `authenticated` + `service_role` grant'ını korur → edge (service_role) ve panel
  (authenticated) erişimi korunur. **İç içe definer çağrıları** owner yetkisiyle yürüdüğü
  için etkilenmez (owner tipik olarak yüksek yetkili rol).

### Ön koşullar
- Hedef fonksiyonlar mevcut olmalı (✅ 54/54).
- `service_role` ve `authenticated` rollerinin mevcut olması (✅).

### Idempotency
✅ Dinamik `DO` + `REVOKE`/`GRANT` → tekrar çalıştırma güvenli.

### Rollback kapsamı
| Geri ALIR | Geri ALAMAZ |
|---|---|
| Listedeki fonksiyonlara `GRANT ... TO PUBLIC, anon` geri kurar | Kapsam dışı 23 fonksiyonu (zaten dokunulmamıştı) |

### Rollback sonrası risk
⚠️ anon erişimini geri açar (yüksek riskli RPC'ler tekrar anon'a açılır).

### Meşru erişimi bozma riski
- **Düşük:** `authenticated` + `service_role` grant'ı verilir → panel ve edge akışları korunur.
- **İnce nokta:** Blok yalnız `prosecdef = true` olanları hedefler. Aynı isimde bir overload
  definer değilse atlanır (beklenen). İzole testte edge/service_role RPC erişimi doğrulanmalı.

---

## 7) GUV-14 · SECURITY DEFINER search_path sabitleme

**Dosya:** `supabase/migrations/20260101000700_guv14_definer_search_path.sql`
**Rollback:** `supabase/migrations/rollback/20260101000700_guv14_definer_search_path_rollback.sql`

### Değiştirdiği nesneler (dinamik `DO` bloğu)
- `public` şemasında `SECURITY DEFINER = true` **ve** `proconfig` içinde `search_path` ayarı
  OLMAYAN **TÜM** fonksiyonlara: `ALTER FUNCTION <sig> SET search_path = public, pg_temp`.

### Hedefler — GERÇEK DOĞRULAMA (salt-okuma)
Canlıda `search_path` sabitlenmemiş (`proconfig IS NULL`) definer fonksiyonlar **tam olarak 4**:

| # | Fonksiyon | İmza | Gövde nitelikli mi? |
|---|---|---|---|
| 1 | `custom_field_definition_set_osgb` | `()` | trigger |
| 2 | `custom_field_value_set_scope` | `()` | trigger |
| 3 | `firma_evrak_klasorleri_set_scope` | `()` | ⚠️ niteliksiz `FROM firmalar` içeriyor |
| 4 | `ziyaret_auto_close_due` | `()` | fonksiyon |

> ⚠️ **Ek bulgu:** `log_system_event(text,text)` canlıda `search_path=""` (BOŞ string, set
> edilmiş) durumundadır. Bu, `search_path=%` desenine eşleştiği için **GUV-14 filtresi bu
> fonksiyonu ATLAR** → ayarına dokunmaz. Boş `search_path` güvenlik açısından zayıf bir
> yapılandırmadır; ayrı ele alınmalıdır (**kapsam dışı bırakılmış**).

### Bağımlılıklar
- `pg_proc`, `pg_namespace` (okuma). Hedef fonksiyonların var olması.
- `public` ve `pg_temp` şemalarının geçerli olması.

### Ön koşullar
- Hedef fonksiyonların gövdelerindeki referansların `search_path = public, pg_temp` altında
  doğru çözümlenmesi. `firma_evrak_klasorleri_set_scope` niteliksiz `FROM firmalar` kullanır
  → `public.firmalar` olarak çözümlenir (✅ doğru şema). Ek söz dizimi hatası beklenmez.

### Idempotency
✅ Dinamik `DO`; ikinci çalıştırmada search_path'i zaten set olanları atlar → güvenli.

### Rollback kapsamı
| Geri ALIR | Geri ALAMAZ |
|---|---|
| 4 **isimlendirilmiş** fonksiyonun `search_path` ayarını `RESET` eder | Gelecekte eklenecek/yeni null-config definer fonksiyonları (isim listesi sabit) |

### Rollback sonrası risk
⚠️ search_path hijacking riskini geri getirir (yalnız 4 fonksiyon için).

### Meşru erişimi bozma riski
- **Düşük:** `search_path = public, pg_temp` standart ve güvenli; trigger davranışını değiştirmez,
  yalnız isim çözümlemesini sabitler.
- **İnce nokta:** Gövde `extensions`/`auth` şemasındaki nesneleri **niteliksiz** kullanıyorsa
  `public, pg_temp` altında çözümlenemeyebilir. 4 hedefin fonksiyon gövdeleri izole testte
  çalıştırılarak doğrulanmalıdır (**BLOCKED**).

---

## 7b) GUV-13b · anon definer RPC kapsam TAMAMLAMA (Faz 8)

**Dosya:** `supabase/migrations/20260101000800_guv13b_anon_definer_scope.sql`
**Rollback:** `supabase/migrations/rollback/20260101000800_guv13b_anon_definer_scope_rollback.sql`

### Değiştirdiği nesneler (dinamik `DO`, 2 blok)
- **Grup 1 (17 fonksiyon):** `REVOKE EXECUTE FROM PUBLIC, anon` + `GRANT TO authenticated, service_role`
  (`atama_firma_durum_ozet`, `atama_rol_doygunluk`, `firma_aktif_atamalar`,
  `firma_aktif_personel_sayisi`, `firma_calisan_sayisi`, `hazard_change_detect`,
  `resolve_hazard_change_assignment`, `personel_saglik_ozet`, `personel_aktif_bagimliliklar`,
  `personel_validity_resolve`, `personel_firma_id`, `personel_osgb_id`,
  `mesajlasma_unread_count`, `mesajlasma_unread_counts`, `mesajlasma_conversation_unread_count`,
  `mesajlasma_last_messages`, `resolve_profile_names`).
- **Grup 2 (2 fonksiyon):** `REVOKE EXECUTE FROM PUBLIC, anon, authenticated` + `GRANT TO service_role`
  (`operasyon_bakim_hatirlatma` — guardsız+veri yazar; `project_myk_requirements` — sunucu guard'lı).

### Bağımlılıklar (canlıda doğrulandı)
- Hedef fonksiyonların tamamı `public` şemasında `SECURITY DEFINER` olarak **MEVCUT** ✅
- İmzalar `regprocedure` ile çözülür → overload/uyuşmazlık imkânsız.
- KORUNAN: RLS/erişim yardımcıları (`auth_role`, `can_access_*`, `has_active_*`,
  `mesajlasma_is_participant`, `operasyon_entity_accessible`, `osgb_erisim_acik` vb.) ve
  public akış (`teklif_public_*`, `create_support_ticket`) → **dokunulmaz**.

### Idempotency / Rollback
- ✅ `REVOKE`/`GRANT` + dinamik `DO` → tekrar güvenli.
- Rollback: `GRANT ... TO PUBLIC, anon` (grup1) ve `... TO PUBLIC, anon, authenticated` (grup2) →
  güvenlik açığını geri açar.
- **Meşru erişim riski:** düşük — `authenticated` + `service_role` korunur.

---

## 7c) GUV-15 · search_path boş/NULL kapsam TAMAMLAMA (Faz 8)

**Dosya:** `supabase/migrations/20260101000900_guv15_search_path_completion.sql`
**Rollback:** `supabase/migrations/rollback/20260101000900_guv15_search_path_completion_rollback.sql`

### Değiştirdiği nesneler (dinamik `DO`, 2 blok)
- **(1)** `search_path IS NULL` olan TÜM definer fonksiyonlara `SET search_path = public, pg_temp`
  (GUV-14 ile **idempotent**; GUV-14 uygulandıysa bu blok no-op).
- **(2)** Boş `search_path` taşıyıp gövdesi `public.` niteliksiz 7 fonksiyona
  `SET search_path = public, pg_temp`:
  `firma_isg_girdi_degisim`, `firma_lock_osgb`, `firma_prevent_delete`, `personel_lock_scope`,
  `personel_normalize`, `personel_prevent_delete`, `request_context`.

### Kapsam ayrımı (canlı, Faz 8)
| Durum | Sayı | Aksiyon |
|---|---|---|
| `search_path IS NULL` | 4 | **Sabitle** (GUV-14 ile aynı) |
| `search_path = ""` + gövde tam-nitelikli | ~28 | **DOKUNMA** (güvenli önerilen desen) |
| `search_path = ""` + gövde niteliksiz | 7 | **Sabitle** (bu migration) |

### Idempotency / Rollback
- ✅ `ALTER ... SET` + dinamik `DO` → tekrar güvenli.
- Rollback: 7 fonksiyona `RESET search_path` (NULL→boş farkı belgelenmiştir; NULL grubun rollback'i GUV-14'e aittir).
- **Meşru erişim riski:** ⚠️ trigger davranışı etkilenebilir → **izole ortamda doğrulanmalı (BLOCKED)**.

---

## 7d) log_system_event(text,text) — özel inceleme (Faz 8)

- **Gövde:** `IF public.auth_role() IS DISTINCT FROM 'admin' THEN RAISE 'ADMIN_ONLY'` +
  `PERFORM public.audit_log(...)` → **tam-nitelikli + admin guard'lı**.
- **search_path:** `""` (BOŞ, set edilmiş) → hijacking İMKÂNSIZ; **DEĞİŞTİRİLMEMELİ**.
- **Koruma:** GUV-13, bu fonksiyonu zaten `anon`'dan kapatır (gruplar arasında `log_system_event` hedef listesinde).

---

## 8) Çapraz bağımlılık matrisi

| Migration | Önce gelmeli mi? | Neden |
|---|---|---|
| GUV-01 | `auth_role/auth_osgb_id/auth_firma_id/has_active_firma_assignment` mevcut olmalı | Fonksiyonlar base şemada |
| GUV-02 | Bağımsız | Trigger + profiles |
| GUV-06 | Bağımsız | Tablolar + RPC mevcut |
| GUV-07 | `osgb` tablosu + guard policy'ler mevcut olmalı | Base şema |
| GUV-11 | İmzalar mevcut olmalı | İmza uyuşmazlığı hata verir |
| GUV-13 | Hedef fonksiyonlar mevcut olmalı | Dinamik seçim |
| GUV-13b | Hedef fonksiyonlar mevcut olmalı | Dinamik seçim |
| GUV-14 | Bağımsız | Dinamik seçim |
| GUV-15 | Bağımsız | Dinamik seçim |

**Önerilen güvenli uygulama sırası:** `GUV-02 → GUV-07 → GUV-06 → GUV-01 → GUV-11 → GUV-13 → GUV-13b → GUV-14 → GUV-15`
(önce bağımlılık fonksiyonları/kimlik zemini, en son izin daraltma + search_path sertleştirme).

---

## 9) Test ortamı eksikliği — BLOCKER

Yerel proje klasöründe **temel veritabanı migration'ları (base schema) BULUNMAMAKTADIR.**
Bu nedenle:
- `auth_role()`, `auth_osgb_id()`, `auth_firma_id()`, `has_active_firma_assignment()`,
  `osgb_access_ok()`, `osgb`, `profiles`, `teklifler`, `storage` policy'leri vb. yerelde YOKTUR.
- Yerel Supabase kurulumu bu eksik bağımlılıklarda durur.
- Bu göreve kadar **`auth_role()` veya tablo uydurulmamıştır** ve **uydurulmayacaktır.**
- Temel şema tahmin edilerek migration'lar **yeniden sıralanmamıştır.**

**İzole test ortamı için minimum kurulum adımları:**
1. Ayrı bir Supabase projesi (production'dan Bağımsız) oluştur.
2. Base şemayı production'dan **şema-only dump** ile klonla (veri hariç veya anonimleştirilmiş):
   `supabase db dump --schema public,auth,storage --data-only=false > base_schema.sql`
   (veya `pg_dump --schema-only`).
3. Storage bucket'larını oluştur (`atama-belgeleri`, `personel-foto`, `hazop-kanitlari`,
   `noter-defteri` — private).
4. Sahte test verisini `supabase/tests/security/00_harness.sql` ile yükle (yalnız izole ortam).
5. `supabase/tests/security/*.test.sql` dosyalarını pgTAP ile çalıştır
   (`supabase test db` veya `psql -f`).
6. Her migration için önce rollback provasını, sonra migration'ı uygula.

> Testler bu turda **ÇALIŞTIRILMADI** (izole ortam yok) → **BLOCKED**.

---

## 10) Özet tablo — Bağımlılık / Idempotency / Rollback

| # | Migration | Ön koşul hazır mı | Idempotent | Rollback var | Rollback sonrası risk |
|---|---|---|---|---|---|
| GUV-01 | Storage izolasyonu | ✅ (kolon+fonksiyon doğrulandı) | ✅ | ✅ | Güvenlik açığını geri açar |
| GUV-02 | handle_new_user | ✅ | ✅ | ✅ | Rol yükseltmeyi geri açar |
| GUV-06 | teklifler restrictive | ✅ | ✅ | ✅ | Restrictive guard kalkar |
| GUV-07 | osgb_access_ok | ✅ | ✅ | ✅ | NULL→TRUE dalı geri gelir |
| GUV-11 | anon EXECUTE (6+) | ✅ (imzalar eşleşiyor) | ✅ | ✅ | anon erişimi geri gelir |
| GUV-13 | anon definer RPC | ✅ (54 isim var) ⚠️ kapsam açığı | ✅ | ✅ | anon RPC erişimi geri gelir |
| GUV-14 | search_path (4 NULL) | ✅ | ✅ | ✅ | search_path hijacking riski |
| GUV-13b | anon definer RPC (19) | ✅ (mevcut) | ✅ | ✅ | anon RPC erişimi geri açılır |
| GUV-15 | search_path boş (7) + NULL | ✅ | ✅ | ✅ | trigger davranışı riski (doğrulanmalı) |

> Bu doküman resmî TSE onaylı sızma testinin yerine geçmez. Gerçek PASS için testler izole
> ortamda çalıştırılıp kanıtlanmalıdır.

---

## 11) Faz 9 · Gerçek bağımlılık sırası (dosya numarasına KÖRLEMESİNE değil)

> Faz 8'deki "önerilen sıra" dosya numaralarına yakındı; bu bölüm **yalnızca gerçek
> nesne bağımlılıklarına** dayanarak sıralamayı gerekçelendirir. Amaç: hangi migration'ın
> gerçekten hangi migration/nesneye bağlı olduğunu netleştirmek.

### 11.1 Gerçek bağımlılık grafiği

| Migration | Gerçekten ZORUNLU ön koşul | Diğer GUV'lara bağımlı mı? |
|---|---|---|
| GUV-01 | Base `auth_role/auth_osgb_id/auth_firma_id/has_active_firma_assignment` + `atama_belgeleri/personeller/hazop_kanitlari/noter_defteri_ekleri` + `storage.*` | **Hayır** |
| GUV-02 | `profiles` + `on_auth_user_created` trigger | **Hayır** |
| GUV-06 | `auth_role/auth_osgb_id` + `teklifler/teklif_hizmetleri.osgb_id` | **Hayır** |
| GUV-07 | `auth_role/auth_osgb_id` + `osgb(id,deleted_at,is_active,erisim_*)` + 4 mevcut guard policy | **Hayır** |
| GUV-11 | İmzaların **birebir** mevcut olması (yoksa **hata verir**) | **Hayır** |
| GUV-13 | Hedef definer fonksiyonlar mevcut | **Hayır** (GUV-11 ile kesişen fonksiyonlar var ama hata üretmez) |
| GUV-13b | Hedef definer fonksiyonlar mevcut | **Hayır** |
| GUV-14 | `pg_proc` + `public`/`pg_temp` | **Hayır** |
| GUV-15 | (1) bloğu GUV-14 ile **idempotent kesişir** | **EVET → GUV-14'ten sonra çalıştırılmalı** (aksi halde ikisi de aynı NULL kümesini işler; zararsız ama gereksiz) |

### 11.2 Sonuç — gerçek sıralama kısıtları (yalnız 3 tanesi)

1. **Base şema + yardımcı fonksiyonlar/tablolar** → tüm GUV-01/06/07/11 öncesinde var olmalı.
2. **GUV-14 → GUV-15(1)** : GUV-15'in NULL bloğu GUV-14 ile aynı kümeyi hedefler; GUV-14
   önce uygulanırsa GUV-15(1) **no-op** olur (doğru davranış). Ters sırada da hata olmaz ama
   GUV-14'ün rollback'i (isim listesi sabit) ile GUV-15(1) (küme tabanlı) çakışabilir;
   **GUV-14 önce önerilir.**
3. **GUV-11 imza katılığı** : GUV-11 statik `REVOKE ... (imza)` kullanır; hedef imzalardan
   herhangi biri yoksa **o ifade hata verir** ve transaction geri alınır. Bu yüzden GUV-11
   yalnızca imzaların **tam mevcut olduğu** base şema üzerinde çalıştırılmalıdır.

### 11.3 Diğer tüm çiftler için sıra SERBESTTİR

GUV-02, GUV-06, GUV-07, GUV-13, GUV-13b birbirinden **bağımsız** nesneleri değiştirir
(farklı fonksiyon/policy kümeleri). Dosya numarası sırası **teknik zorunluluk değildir**;
kolaylık/denetlenebilirliktir. İzole ortamda uygulanacak **önerilen** (zorunlu değil) sıra:

`GUV-02 → GUV-07 → GUV-06 → GUV-01 → GUV-11 → GUV-13 → GUV-13b → GUV-14 → GUV-15`

> Gerekçe: önce fonksiyon/veri zemini (02/07/06/01), sonra izin ve search_path
> sertleştirmeleri (11/13/13b/14/15). Sertleştirmeler en sonda → test edilebilir ara durum bırakır.

### 11.4 Çakışma / tekrar çalıştırma riskleri

- **GUV-14 vs GUV-15(1):** İkisi de NULL-config definer kümesini hedefler → **idempotent**,
  çakışma yok; yalnız GUV-14 önce uygulanırsa GUV-15(1) gereksiz iş yapmaz.
- **GUV-11 vs GUV-13/13b:** Kesişen fonksiyonlar var (ör. `teklif_sil`, `log_system_event`,
  `next_tutanak_no`). Her ikisi de `REVOKE`+`GRANT` (idempotent) → tekrar uygulama hatası yok.
- **GUV-13 vs GUV-13b:** Hedef listeleri **kesişmez** (13b, 13'ten kalan 23 fonksiyonu kapsar).
- **Tüm migration'lar tekrar çalıştırılabilir** (CREATE OR REPLACE / DROP IF EXISTS / dinamik DO).

### 11.5 Rollback SIRASI bağımlılığı

- **GUV-15 rollback**, GUV-14 rollback'inden **sonra** çalıştırılmamalıdır (GUV-15 rollback
  yalnız 7 fonksiyonu `RESET` eder; GUV-14 rollback 4 fonksiyonu `RESET` eder → farklı kümeler,
  çakışma yok ama karışıklığı önlemek için sıralı uygulanmalı).
- **GUV-01 rollback**, `storage_tenant_ok()` fonksiyonunu `DROP` eder → bu fonksiyona bağlı
  başka nesne **yok**, güvenli.
- **Veri kaybı:** Tüm rollback'ler **YALNIZ** policy/fonksiyon/grant değiştirir; **hiçbir
  tablo/satır silinmez/güncellenmez.**