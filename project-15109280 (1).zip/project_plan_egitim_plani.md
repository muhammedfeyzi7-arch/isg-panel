# Yıllık Eğitim Planı Sihirbazı — Plan Notu

## Amaç
İSGDenetim Sihirbazı içinde **Yıllık Eğitim Planı** modülünü, **Yıllık Çalışma Planı
(ve 5x5 / Fine-Kinney / HAZOP)** ile birebir aynı 4 adımlı mimaride, AI destekli,
yerel (hiçbir yere bağlanmayan) ve **Word / PDF / Excel** üreten bir modül olarak kurmak.

## Akış (4 adım)
1. **Temel Bilgiler ve Kapsam** — Plan Adı, Plan Yılı, firma/NACE/tehlike sınıfı/çalışan
   sayısı, düzenleme tarihi, geçerlilik; 10 maddelik **Eğitim Kapsamı** (checkbox + Tümünü
   Seç + özel madde), Plan Ekibi, Referans Dokümanlar, Rapor künyesi. Sağda "Yıllık Eğitim
   Planı Hakkında" + **Mevzuat Asgari Eğitim Süreleri** (Ek-1).
2. **Eğitimler** — satır içi düzenlenebilir eğitim kartları (Kategori · Eğitim Konusu ·
   Açıklama · Tür · Hedef Grup · Eğitici · Süre(saat) · Periyot · Öncelik). Sağda **AI Asistan**
   + **22 eğitim şablonu** + örnek sorular.
3. **Aylık Planlama** — 12 aylık matris (Ocak…Aralık), "Tamamını Temizle" ve **"Önerilen Planı
   Uygula"** (periyoda göre otomatik dağıtım) + Planlama Özeti + Periyot Dağıtımı.
4. **Rapor ve Önizleme** — özet kartları, asgari süre kontrolü, kategori dağılımı donut'u,
   aylık yoğunluk grafiği, matris önizlemesi, **imza alanları (İmzacılar)**, mevzuat listesi,
   gerçek **PDF önizleme** ve **Word / PDF / Excel** indirme (+ "Diğer": CSV · TXT · özet kopyala).

## Mevzuat (araştırıldı ve gömüldü)
- 6331 sayılı Kanun — **m.17** (eğitim yükümlülüğü).
- **Çalışanların İSG Eğitimlerinin Usul ve Esasları Hakkında Yönetmelik — Ek-1**
  asgari temel eğitim süreleri: **Az tehlikeli 8 saat · Tehlikeli 12 saat · Çok tehlikeli 16 saat.**
  Yenileme süresi tüm sınıflarda **asgari 8 saat**.
- Yenileme (periyodik) aralıkları: **Az tehlikeli 3 yılda · Tehlikeli 2 yılda · Çok tehlikeli yılda** bir.
- Bu dayanaklar hem adım ekranında hem raporun "Mevzuat Dayanakları" bölümünde görünür.

## Teknik
- **Tipler/Sabitler:** `src/components/feature/risk/egitimTypes.ts` (asgari süreler, kategoriler,
  türler, kapsam, şablonlar, periyot→ay eşlemesi).
- **Veri katmanı (GEÇİCİ):** `src/components/feature/risk/egitimWorkspaceStore.ts` (IndexedDB,
  ayrı DB adı `isgdenetim-egitim-sihirbaz`). **Kalıcı kayıt/arşiv YOKTUR**, Supabase'e veri gitmez.
- **Rapor motoru:** `src/lib/egitimRapor/` → `model.ts` (tek merkez hesap), `pdf.ts` (jsPDF +
  autotable, A4 yatay, gömülü Türkçe font, 7 bölüm), `word.ts` (gerçek .docx, kapak dikey +
  yatay bölümler, kesintisiz akış → gereksiz boş sayfa yok), `excel.ts` (tek sayfa kurumsal),
  `ekstra.ts` (CSV · TXT).
- **Orkestratör:** `src/components/feature/risk/EgitimSihirbazContent.tsx`.
- **Adımlar:** `src/components/feature/risk/egitim/adimlar/EgitimAdim1..4*.tsx`.
- **Bağlama:** `RiskModulSecim.tsx` → "Yıllık Eğitim Planı" AKTİF; `RiskSihirbazModal.tsx` →
  `egitim` ekranı; `RiskSihirbazHeader.tsx` → `EgitimHeaderIcon`.
- **AI:** `risk-ai-oneriler` edge function → `egitim` bloğu (`buildEgitimPrompt` / `handleEgitim`).
  Bağlam (firma/tesis/NACE/tehlike sınıfı/plan yılı/kapsam) + mevcut eğitimler gönderilir; model
  tekrar etmeyen TAM 10 eğitim önerir; kategori/tür/periyot/öncelik geçerli aralıklara zorlanır.
  API key frontend'e inmez.

## Çıktılar
PDF A4 yatay · Word .docx (kapak dikey + bölümler yatay) · Excel tek sayfa kurumsal ·
CSV ve TXT. Logo ve OSGB künyesi Kurumsal Ayarlar'dan gerçek kayıttan gelir. Tüm çıktılar
5x5 / Fine-Kinney / HAZOP / Çalışma Planı ile aynı kurumsal tasarımdadır.

## Notlar
- Eğitim **süresi saat** olarak kullanılır.
- Rapor bölümleri: (1) Firma/Plan Bilgileri, (2) Eğitim Kapsamı, (3) Yıllık Eğitim Matrisi,
  (4) Eğitim Detayları, (5) Özet ve Dağılım, (6) Mevzuat Dayanakları, (7) Onay ve İmza.
- İlk açılışta referans örnek eğitimlerle gelir; "Sıfırla" ile temizlenir.