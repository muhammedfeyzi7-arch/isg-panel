# İSGDenetim — Storage Bucket Boyut + MIME Sertleştirme (GUV-24) · 2026-10-12

> **Yöntem:** Canlı Supabase'de salt-okuma `SELECT` (storage.buckets) ile mevcut durum
> çıkarıldı; uygulama kodu (`grep`) ile her bucket'a giren gerçek dosya türleri ve
> kodun kendi boyut/MIME sabitleri derlendi; ardından metadata güncellendi ve tekrar
> salt-okuma ile **kanıtlandı.**
>
> **Kapsam:** Uygulama kodu, RLS ve policy gövdeleri DEĞİŞMEDİ. Yalnızca
> `storage.buckets.file_size_limit` + `allowed_mime_types` güncellendi.

---

## 1) Bulgu (öncesi)

- 16 bucket'ın **14'ünde `file_size_limit = NULL`** → **sınırsız** (DoS / kaynak
  tüketimi bulgusu).
- Hiçbir bucket'ta **`allowed_mime_types` yok** → içerik türü bucket seviyesinde
  kısıtlanmıyordu (yalnız istemci + edge doğrulaması).
- **Yan bulgu (tutarsızlık):** `support` bucket limiti **10 MB** idi ama uygulama
  `MAX_ATTACHMENT_SIZE = 25 MB` ile kullanıcıya 25 MB'a kadar izin veriyordu →
  **10–25 MB arası destek ekleri sessizce reddediliyordu.** (Gerçek kullanıcı hatası.)

## 2) Yapılan (GUV-24)

Migration: `supabase/migrations/20260101001400_guv24_storage_bucket_limits.sql`
Rollback: `supabase/migrations/rollback/20260101001400_guv24_storage_bucket_limits_rollback.sql`

Boyut limitleri, **koddaki istemci/sunucu tavanlarının ÜZERİNDE** tutuldu → normal
yüklemeler etkilenmez. Görsel bucket'larına görsel MIME; `support` / `mesajlasma` /
`operasyon` bucket'larına **kodun KENDİ izin listesiyle birebir** MIME allowlist'i.

| Bucket | Boyut (önce → sonra) | MIME |
|---|---|---|
| avatars | ∞ → 10 MB | jpeg/png/webp |
| osgb-logos | ∞ → 5 MB | jpeg/png/webp |
| personel-foto | ∞ → 10 MB | jpeg/png/webp |
| ekipman-gorselleri | ∞ → 10 MB | jpeg/png/webp |
| saha-denetimleri | ∞ → 15 MB | jpeg/png/webp |
| **support** | **10 MB → 30 MB** | kod `ALLOWED_ATTACHMENT_TYPES` (40 tür) |
| mesajlasma | ∞ → 20 MB | kod `ALLOWED_MIME` (17 tür) |
| operasyon | ∞ → 20 MB | kod `ALLOWED_MIME` (8 tür) |
| envanter / zimmet / ekipman-belgeleri | ∞ → 25 MB | serbest |
| atama-belgeleri / noter-defteri / hazop-kanitlari / announcements | ∞ → 50 MB | serbest |
| evraklar | 200 MB (değişmedi) | serbest |

## 3) Kanıt (uygulama sonrası, salt-okuma)

- `SELECT id FROM storage.buckets WHERE file_size_limit IS NULL` → **0 satır** ✅
  (artık hiçbir bucket sınırsız değil).
- Görsel bucket'ları → `allowed_mime_types = {image/jpeg,image/png,image/webp}` ✅
- `support` → 30 MB + 40 tür ✅ · `mesajlasma` → 20 MB + 17 tür ✅ · `operasyon` → 20 MB + 8 tür ✅

## 4) İşlevsellik etkisi

- **Olumlu:** `support` 10→30 MB → 10–25 MB arası destek ekleri artık çalışır
  (önceki sessiz hata kapatıldı).
- Boyut limitleri tüm akışların kendi tavanlarından yüksek → **hiçbir normal yükleme
  reddedilmez.**
- MIME kısıtları yalnız kodda zaten kabul edilen türlerle sınırlı → yeni ret oluşmaz.
- MIME kısıtı **mevcut dosyaları etkilemez** (yalnız yeni yüklemelere uygulanır).
- Geri dönüş: rollback dosyası tek komutla orijinal hâle döndürür.

---

Bu doküman resmî TSE onaylı sızma testinin yerine geçmez; yalnızca yapılan kontrol ve
kanıtını kaydeder.