# İBYS Uyumlu — Türkiye'de Self-Hosted Supabase Yol Haritası

> Amaç: İBYS'nin "kişisel ve sağlık verileri Türkiye'de tutulacak" şartını karşılamak
> ve "yurt içi IP" zorunluluğunu aynı altyapıyla çözmek.
>
> **Doğrulandı:** İBYS 2.0 Web Servisleri (REST v2) yurt dışı IP erişimlerini
> kapatmıştır. Bu nedenle Türkiye'de sabit yurt içi IP'li sunucu **opsiyonel
> değil, ZORUNLUDUR** — self-host olmadan İBYS test ortamına bile bağlanılamaz.

---

## Neden bu yol?

- İBYS başvurusunda, işlenen **kişisel + özel nitelikli (sağlık) verilerin Türkiye'de
  barındırılması zorunlu**dur.
- Supabase Cloud (SaaS) yalnızca AWS bölgelerinde çalışır (Frankfurt, İrlanda, ABD,
  Singapur...). **Türkiye bölgesi yoktur.**
- Bu yüzden SaaS Supabase ile bu şart karşılanamaz.
- Çözüm: **Supabase'in açık kaynak sürümünü Türkiye'de bir sunucuya kurmak.**
  - Veri fiziksel olarak Türkiye'de kalır → veri barındırma şartı ✅
  - Sunucunun sabit yurt içi IP'si olur → İBYS "yurt içi IP" şartı ✅
  - Uygulama kodu (React + Supabase client + RLS + edge functions) korunur; sadece
    bağlanılan adres değişir.

---

## Sızma Testi Zamanlaması — KARAR (2026-10-12)

> **KARAR:** Sızma testi (TSE onaylı A sınıfı, Uygulama Sızma Testi) **taşıma
> tamamlandıktan sonra**, Türkiye'de barındırılan nihai sistem üzerinde çalıştırılacaktır.

- **Gerekçe:** İBYS başvurusunda istenen sızma testi raporu, **Türkiye'de barındırılan**
  sistem için düzenlenmiş olmalıdır. SaaS kurulumu üzerinde yapılan test, taşıma sonrası
  geçersiz kalır ve ikinci bir teste (ek maliyet) yol açar.
- **Alınan teklif:** Nesil Grup Bilişim Teknoloji A.Ş. — Teklif No **NT-PT-2026-118**,
  **20.000 TL + KDV (24.000 TL)**, geçerlilik **11.11.2026** (30 gün), bir kez retest dahil.
- **Etki:** Taşıma tamamlanana kadar sızma testi **başlatılmayacak**. Ön koşullar (test
  hesapları, yetkilendirme yazısı, yedek, irtibat kişisi) taşıma sonrası hazırlanacak.
- **UYARI — Teklif geçerliliği:** Teklif 30 gün geçerli. Taşıma takvimi bu pencereye
  sığmazsa teklif yenilenmeli / yeni fiyat alınmalıdır.
- **UYARI — Testçi erişimi:** Taşıma sonrası yurt dışı IP bloklanırsa, uzaktan test eden
  ekibin IP'leri **whitelist**'e eklenmelidir; aksi halde testçiler hedefe ulaşamaz.

---

## İş Bölümü

### Sende olan (kod dışı)
- Türkiye'de veri merkezi olan bir sağlayıcıdan **sabit yurt içi IP'li sunucu** kiralamak.
- Alan adı + DNS yönetimi (karar: `app.isgdenetim.com.tr` + `api.isgdenetim.com.tr`).
- İBYS başvurusunda **sunucunun sabit IP'sini** beyan etmek.
- Sağlayıcı/sözleşme/İBYS evrak iletişimi.

### Bende olan (kod/teknik)
- Sunucu üzerinde Supabase self-host kurulum adımları ve dosyaları.
- Mevcut şemayı + veriyi yeni ortama taşıma script'leri.
- Edge function envanteri ve yeniden deploy planı.
- Uygulamanın yeni adrese yönlendirilmesi (env + client).
- İBYS için gereken Yedekleme ve Veritabanı Değişiklik prosedür taslakları.

---

## Durum — Sunucu Alındı (2026-10-13)

- **Sağlayıcı:** Turhost — **VDS TR 6** (KVM/root erişimli, paylaşımlı hosting DEĞİL ✅).
- **Sunucu adı:** `srv.ibys-prod.com`
- **Sabit yurt içi IP:** `37.230.105.216` (Türkiye 🇹🇷)
- **SSH:** port `23422`, kullanıcı `root` — şifre Turhost panelinden alınır (kod/dosyaya yazılmaz).
- **İşletim sistemi:** Ubuntu 24.04 LTS.
- **Kaynaklar:** 6 vCPU / 16 GB RAM / 300 GB SSD → İBYS stack'i (Postgres + Auth +
  Storage + Edge + Studio) için **fazlasıyla yeterli**.
- **Taşıma kiti hazır:** `deploy/` klasörü (README + `.env.example` + 4 script).
- **Kaynak sistem:** `https://cmgfalpoiouflnbppjjk.supabase.co` — **kullanıcının kendi
  Supabase projesi** (şema + veri + auth + storage + ~50 edge function + secrets taşınacak).
- **Karar (frontend) — GÜNCELLENDİ (2026-10-13):** Web arayüzü **Readdy yayınında**
  kalacak (`app.isgdenetim.com.tr → CNAME → publish.readdy.site`). Frontend yalnızca
  statik varlıklardan (JS/CSS) oluşur ve **kişisel/sağlık verisi barındırmaz**; tüm veri
  self-hosted Supabase'de (Türkiye) kalır. Böylece veri barındırma şartı korunur, frontend
  için ekstra deploy/ops yükü doğmaz. `api.isgdenetim.com.tr` (Supabase API) ise Caddy ile
  sunucuya yönlendirilir.
- **Not (CORS):** Arayüz Readdy'den, API kendi sunucudan servis edileceği için ileride
  Envoy/Caddy ve edge fonksiyonlarında `https://app.isgdenetim.com.tr` origin'inin CORS
  izinli olması gerekir (Faz 3 doğrulamasında kontrol edilecek).
- **Yürütücü:** Sunucu kurulumu talimatla yürütülür (script'ler hazır); gerekirse
  tek seferlik kurulum bir sysadmin ile yapılır.
- **Alan adı (karar):** `app.isgdenetim.com.tr` (uygulama) + `api.isgdenetim.com.tr` (API).
- **Bekleyen (sende):** (a) kaynak **DB connection string** + **service_role** anahtarı,
  (b) edge function **sırları** (Resend, Gemini, OAuth vb.).

---

## Faz 0 — Kararlar ve Gereksinimler

- [ ] Sunucu: Türkiye veri merkezi, **sabit yurt içi IP**, Ubuntu (LTS).
- [ ] Kaynak: Postgres + Storage + Edge + Auth taşınacağı için **küçük VPS yetmez**
      (RAM/disk/CPU planlanacak; veri büyüklüğüne göre belirlenecek).
- [ ] Alan adı + TLS (HTTPS) planı.
- [ ] Kapsam: Pratikte **tüm kişisel/sağlık verisi** İBYS kapsamında olduğundan
      backend'in tamamı taşınır (parçalı taşıma önerilmez).

## Faz 1 — Sunucu + Supabase Kurulumu

- [x] Sunucu kiralandı: Turhost VDS TR 6 (Ubuntu 24.04, sabit yurt içi IP).
- [x] Sunucu kurulumu: Docker + Docker Compose, güvenlik duvarı (`deploy/scripts/01-sunucu-hazirla.sh`).
- [x] Supabase self-host (Docker Compose ile: Postgres, GoTrue/Auth, Storage,
      Edge Functions, Studio, Kong/reverse proxy) — **12/12 servis `healthy`**.
- [x] **Blok 3 doğrulaması (2026-10-13)** — taze init sonrası sağlık testleri:
      auth health (apikey) = `200`, auth settings = `200`, REST service_role = `200`,
      auth `admin/users` (service_role) = `200` → Auth ↔ Postgres bağlantısı kanıtlandı.
      (`/rest/v1/` anon kökünün `403` dönmesi beklenen davranıştır — OpenAPI kök yolu
      anon'a kapalı; hata değildir.)
- [x] TLS + alan adı yönlendirmesi. **(BLOK 4 — TAMAMLANDI 2026-10-13)**
      Karar: yalnızca `api.isgdenetim.com.tr → 37.230.105.216` (A, DNS only) Caddy ile
      proxy'lenir; `app.isgdenetim.com.tr` Readdy CNAME'inde kalır.
      - Cloudflare: `app` CNAME'ine dokunulmadı; yalnızca `api` A kaydı eklendi (DNS only).
        (`app` için A kaydı eklenmeye çalışıldığında "CNAME zaten var" hatası alındı → iptal.)
      - Caddy kuruldu, Caddyfile **yalnızca `api` bloğu** içeriyor (`reverse_proxy 127.0.0.1:8000`).
      - `dig +short api.isgdenetim.com.tr` → `37.230.105.216` ✅
      - Caddy 80/443 dinliyor, ufw'de 80/443 açık ✅
      - Let's Encrypt sertifikası **otomatik alındı** (`certificate obtained successfully`,
        tls-alpn-01) ✅
      - Doğrulama: `auth/v1/health` = `200`, `rest/v1/` kök = `403` (beklenen), TLS el sıkışması
        başarılı (`HTTP/2`). Blok 4 kapandı.

## Faz 2 — Veri Taşıma

- [x] Şema: mevcut `supabase/migrations/*` + `pg_dump --schema-only`.
- [x] Veri: `pg_dump` ile tablo verilerinin aktarımı (`02-db-tasi.sh`).
- [x] **Auth kullanıcıları** (`auth.users`) aktarımı + CASCADE'la boşalan 7 tablo
      telafisi (`02b-auth-veri-tasi.sh`) — doğrulandı.
- [x] Storage bucket'larının ve dosyaların kopyalanması — **16 bucket** ile
      taşıma tamam (`03-storage-tasi.mjs`).
- [ ] Doğrulama: satır sayıları, kritik ilişkiler, **RLS testleri**.

## Faz 3 — Uygulamayı Yönlendirme

- [ ] `.env`: `VITE_PUBLIC_SUPABASE_URL` ve `VITE_PUBLIC_SUPABASE_ANON_KEY`
      yeni (self-hosted) adrese çevrilir.
- [ ] Edge function endpoint'lerinin doğrulanması.
- [ ] Uçtan uca test: giriş, yetkilendirme (RLS), kritik akışlar (personel, sağlık,
      eğitim, risk, ekipman, mail, davet...).

## Faz 4 — İşletim ve İBYS Belgeleri

- [ ] **Yedekleme Prosedürü** (İBYS zorunlu belge): sıklık, saklama, geri yükleme testi.
- [ ] **Veritabanı Değişiklik Prosedürü** (İBYS zorunlu belge): değişiklik talepleri
      yalnızca veri sahibinden, kayıt/işleyiş.
- [ ] İzleme/uptime, güncelleme takvimi, olay müdahale.
- [ ] **Sızma testi** (TSE onaylı A Seviye firma, Uygulama Sızma Testi) — **taşıma
      sonrası** çalıştırılır (bkz. "Sızma Testi Zamanlaması — KARAR").

---

## Riskler / Dikkat

- **Geri dönüş planı şart:** taşıma öncesi mevcut SaaS verisinin tam yedeği alınır;
  hiçbir veri/ayar **silinmez**, taşınana kadar mevcut sistem çalışır.
- **Ops yükü:** yedekleme, güncelleme, sertifika, güvenlik artık bizim sorumluluğumuzda.
- **Platform bağlantısı:** uygulama kendi Supabase örneğine bağlandığında, Readdy'nin
  SaaS Supabase entegrasyon paneli artık bu veriyi göstermez; yönetim self-hosted
  panelden (Studio) yapılır.

---

## Sıradaki İlk Adım

1. ✅ Sunucu kiralandı (Turhost VDS TR 6).
2. ✅ Taşıma kiti hazır: `deploy/README.md` + `deploy/scripts/*`.
3. ✅ Supabase self-host kuruldu, 12/12 servis `healthy` (Faz 1 / Blok 3).
4. ✅ DNS + Caddy + TLS tamam: `api.isgdenetim.com.tr` sertifikalı ve çalışıyor
   (Faz 1 / Blok 4).
5. ✅ **Veri Taşıma (Faz 2) tamam:** şema + veri (`02-db-tasi.sh`), auth kullanıcıları
   (`02b-auth-veri-tasi.sh`), storage — **16 bucket** (`03-storage-tasi.mjs`).
6. ⏳ **Sıradaki adım (Blok 5 — Edge Function / Adım 7):** `04-edge-deploy.sh` ile
   ~50 edge function'ı self-host fonksiyon dizinine kopyalayıp yayınla; ardından
   Adım 8 (sırlar/secrets) → Adım 9 (frontend `.env` yeni adres) → Adım 10 (uçtan uca test).