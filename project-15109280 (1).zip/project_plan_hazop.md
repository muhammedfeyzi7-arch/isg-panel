# İSGDenetim — HAZOP Risk Değerlendirmesi Modülü (Eklenti Planı)

> Bu dosya, ana `project_plan.md`'ye ek olarak HAZOP yönteminin mimarisini belgeler.
> Ana plan 2900+ satıra ulaştığı için "küçük odaklı dosyalara ayır" ilkesine uygun
> olarak bu geliştirme ayrı bir plan dosyasında tutulur.

## 1. Amaç
Uzman > Evraklar > Risk Değerlendirmesi sihirbazına, mevcut 5x5 L Tipi Matris ve
Fine-Kinney yöntemlerini BOZMADAN üçüncü aktif yöntem olarak **HAZOP** (süreç odaklı
tehlike analizi) eklemek. Gerçek DB, gerçek Gemini AI (backend üzerinden), gerçek
DOCX raporu ve mevcut revizyon/imzalı belge sistemine entegrasyon.

## 2. Veri Modeli (yeni, izole — mevcut tablolara dokunulmadı)
- `hazop_dugumleri` — düğümler (node)
- `hazop_parametreleri` — düğüm parametreleri (parameter)
- `hazop_sapmalari` — sapmalar (deviation: rehber kelime + neden + sonuç + risk puanı)
- `hazop_kontrolleri` — mevcut kontroller (yeterlilik)
- `hazop_onlemleri` — ilave önlemler (tür/sorumlu/termin/durum)

Tümü `osgb_id` + `firma_id` izole, RLS mevcut desenle aynı (`auth_role()`,
`auth_osgb_id()`, `auth_firma_id()`, `has_active_firma_assignment`). AI rate-limit
mevcut `risk_degerlendirme_ai_kullanim` tablosundan paylaşılır.

## 3. Yöntem (Method Registry)
- `riskMatris.ts` → `YONTEMLER` içinde `HAZOP` artık `aktif: true`.
- `riskMatris.ts` içine HAZOP motoru, rehber kelimeler ve şablon kütüphanesi eklendi.
- `HazopForm` ayrı state modeli; ortak `risk_degerlendirmeleri` (yontem='HAZOP') +
  ortak revizyon/belge kayıtları kullanılır (ikinci kez veri tutulmaz).

## 4. 5 Adımlı Sihirbaz (4. adım referans görsellerine sadık)
1. Yöntem Seçimi (paylaşılan `Adim1Yontem` + HAZOP sağ paneli)
2. Temel Bilgiler (çalışma adı, tarih, ekip, toplantı no, proses, kapsam)
3. Düğümler ve Parametreler (düğüm/parametre tabloları + şablon + AI parametre önerisi)
4. Tehlikeler ve Riskler = Sapmalar (rehber kelime + neden + sonuç + O/Ş puan + AI sapma önerisi)
5. Kontroller ve Onay (mevcut kontrol + ilave önlem + sonuç dağılımı + rapor)

## 5. Gemini AI
- Ayrı `hazop-rapor` edge function (mevcut `risk-degerlendirme-rapor` bozulmadı).
- `GEMINI_API_KEY` yalnızca server-side (Deno.env). Sadece kullanıcı butonu ile çalışır.
- Aksiyonlar: `ai-parametre`, `ai-sapma`. Rate-limit + AI kaynak etiketi (`AI_SUGGESTION`).
- AI önerisi kullanıcı KABUL etmeden DB'ye resmi kayıt olarak yazılmaz. Mevzuat uydurma prompt'ta yasak.

## 6. Word Raporu
- Gerçek OOXML DOCX (docx kütüphanesi), kapak + doküman kontrolü + işyeri + amaç/kapsam +
  ekip + HAZOP yöntemi + düğüm/parametre + **yatay LANDSCAPE sapma tablosu** + mevcut
  kontroller + ilave önlemler + sonuç + imzalar + ekler.
- Derin DOCX validation (ZIP/[Content_Types]/document.xml/rels/medya). Hata halinde indirme engellenir.
- Firma/logo her zaman aktif firmadan; hard-code yok.

## 7. Durum
- [x] DB tabloları + RLS
- [x] Method registry aktif
- [x] 5 adımlı sihirbaz + şablon kütüphanesi
- [x] Gemini AI (backend)
- [x] Word (DOCX) raporu + validation
- [x] Mevcut revizyon + imzalı belge akışına bağlı (method-agnostic)

## 8. Gelecek
- DÖF/Aksiyon aktarımı, İSG Gereksinim `requirement_id` ilişkisi, ek bağlam verisi
  (ekipman/kimyasal/uygunsuzluk/ramak kala) AI bağlamına — ayrı turlar.