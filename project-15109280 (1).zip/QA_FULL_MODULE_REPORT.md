# İSGDenetim — Tüm Modülleri Kapsayan QA Raporu (Tek Seferlik Kapsamlı Denetim)

> **TUR SINIRI (tam uyum):** Bu turda **üretim veritabanına hiçbir DDL/DML UYGULANMADI**,
> **hiçbir migration ÇALIŞTIRILMADI**, **hiçbir Edge Function DEPLOY EDİLMEDİ**, **hiçbir
> secret/connection string/parola/JWT rapora YAZILMADI**, **hiçbir gerçek kullanıcı/OSGB/firma/
> personel/teklif/atama/dosya kaydı değiştirilmedi/silinmedi/kopyalanmadı**. Veritabanına
> yalnızca **salt-okuma** `SELECT` ile bakıldı.

**Tarih:** 2026-10-09 · **Yöntem:** mevcut 12 güvenlik dokümanı + 9 migration + 9 rollback +
7 test + harness okundu; `grep` ile statik tarama; production build; canlı Supabase salt-okuma.

> **⟳⟳ Sonuçlandırma turu — yeni taze kanıtlar (bu tur):**
> - **Kök neden:** canlıda `auth_role/osgb_id/firma_id/has_active_firma_assignment/osgb_access_ok/`
>   `storage.foldername` **HEPSİ MEVCUT** → "auth_role() yok" hatası proje klasöründe
>   **base şema/`config.toml` olmamasından** (canlı şemadan DEĞİL).
> - **Migration imza/kolon uyumu ✅ PASS:** 34 imza + tüm referanslı kolon + 4 `public=false`
>   bucket canlıda birebir doğrulandı → şema-uyumsuzluğu riski yok.
> - **Edge dosya yazılabilir** (mevcut `functions/*/index.ts`); `_shared/*` + `vite.config.ts` kilitli.
> - **Hiç şema dump / `config.toml` / base migration YOK** (glob) → izole ortam dış girdi ister.

> **⟳ Kalan hataları kapatma turu — taze doğrulama:** build **PASS**; CORS wildcard **43**
> (yeniden sayıldı); JWT doğrulama **40/43**; service-role **41/43**; frontend
> XSS/secret/alert/yönlendirme hepsi temiz. Canlı salt-okuma: `definer=162`,
> `null_search_path=4`, `anon_definer_exec=159`, `storage_tenant_ok=0` → **9 migration
> uygulanmadı, veri katmanı açık**. **Çağıran analizi**, guardsız definer fonksiyonlara
> gövdesel guard eklemenin **RLS/trigger'ı kıracağını** gösterdi → grant-narrowing tasarımı
> teyit edildi; **yeni migration bilerek üretilmedi**. `_shared/cors.ts` ve `vite.config.ts`
> değişiklikleri **platform tarafından reddedildi** (kanıt: hata mesajları). Kapanış kriterleri
> karşılanmadı → "tüm hatalar kapandı" DENMEDİ.

---

## 0) ÖZET — Neler GERÇEKTEN doğrulandı, neler BLOCKED

| Katman | Doğrulama türü | Durum |
|---|---|---|
| Production build | Çalıştırıldı | ✅ **PASS** |
| Frontend güvenlik (XSS / secret / alert / yönlendirme) | Statik `grep` | ✅ **PASS** |
| Edge Functions (CORS / JWT / service-role sayımı) | Statik `grep` | ✅ **PASS (katalog)** |
| Supabase client (singleton, auth.lock, persist) | Kod incelemesi | ✅ **PASS** |
| CSP meta politikası | Kod incelemesi | ✅ Uyumlu (frame-ancestors hariç — HTTP başlığı gerekir) |
| Veri katmanı (RLS/tenant/storage/RPC/search_path) | **Runtime** | ⛔ **BLOCKED** (izole ortam yok) |
| TypeScript `tsc --noEmit` / ESLint / `npm audit` | Komut yürütücü | ⛔ **BLOCKED** |
| Supabase Auth/Storage Dashboard ayarları | Dashboard | ⛔ **BLOCKED** |
| Hosting HTTP başlıkları | Hosting | ❌ **Kod ile yapılamaz** |

> **Kritik kural:** Çalıştırılmamış hiçbir DB/RLS testi PASS sayılmadı. Tüm veri-katmanı
> bulguları **FIXED—UNVERIFIED** (dosya hazır) veya **BLOCKED** (ortam yok) durumundadır.

---

## 1) MODÜL ENVANTERİ (gerçek dosya sayımı)

`src/pages/**/page.tsx` → **64 sayfa**. Paneller:

| Panel | Örnek modüller | Sayfa |
|---|---|---|
| **Admin** | dashboard, osgb, ayarlar, duyurular, logs, destek, meslek-evrak-yonetimi, nace-import | 8 |
| **OSGB** | genel-bakis, firmalar, personeller, atamalar, teklifler, envanter, ziyaret-planlama, mesajlasma, ayarlar, destek-talepleri | 10 |
| **Uzman** | genel-bakis, firmalarim, personeller, evraklar, ekipmanlar, saha-denetimleri, tutanaklar, ziyaretler, zimmet, mesajlasma, ayarlar, destek-talepleri | 12 |
| **Hekim** | genel-bakis, firmalarim, personeller, muayene-planlama, muayeneler, tetkik-tahlillar, saglik-evraklari, tutanaklar, ziyaretler, zimmet, mesajlasma, ayarlar, destek-talepleri | 13 |
| **Firma** | genel-bakis, personeller, evraklar, ekipmanlar, saha-denetimleri, tutanaklar, mesajlasma, ayarlar, destek-talepleri | 9 |
| **Ortak/Public** | login, sifre-sifirla, sifremi-unuttum, invite/accept, teklif-public, ekipman-qr, bildirimler, email-oauth-callback, home | 9 |

**Bileşen katmanı:** `src/components/feature` (panel/modül bileşenleri) + `src/components/ui`
(temel kontroller) + `src/lib` (servisler). Kod modülerdir (dosya başına <500 satır hedefi genel
olarak korunur).

---

## 2) GÜVENLİK QA (statik + derleme — ÇALIŞTIRILDI, PASS)

### 2.1 XSS / HTML enjeksiyonu
| Nokta | Karar | Kanıt |
|---|---|---|
| `dangerouslySetInnerHTML` (5 nokta) | ✅ Hepsi `sanitizeHtml(...)` sarmalı | grep |
| `innerHTML` atama (5 nokta) | ✅ 2'si düzeltildi (RichTextEditor yükleme, ocrService PDF); 3'ü temizleme/sabit metin | grep |
| `RichTextEditor.tsx` (yükleme yolu) | ✅ `sanitizeHtml(value,'rich')` | kod |
| `ocrService.ts` (PDF üretimi) | ✅ `sanitizeHtml(html,'preview')` | kod |
| `main.tsx` `body.innerHTML=` | ✅ Sabit statik metin, kullanıcı girdisi yok | kod |
| `DocxPreviewAdapter` `host.innerHTML=''` | ✅ Yalnızca temizleme | kod |

### 2.2 Gizli bilgi / secret
| Kontrol | Sonuç |
|---|---|
| `service_role` / `sb_secret` istemci bundle'ında | ✅ **0** |
| `src` içinde hardcoded API key | ✅ **0** |
| `.gitignore` | ✅ `.env*`, `*.key`, `service-account*`, `supabase/.env` korumalı |
| `.env` | ✅ Yalnız **public anon** anahtar (istemcide bulunması normal) |
| `console.log/debug/info` (src) | ✅ **0** — üretimde sızıntı yok |
| `localStorage` | ✅ Yalnız firma-id/tema; token/parola YOK |

> ⚠️ Not: `.gitignore` yalnızca bundan **sonraki** takibi korur. `.env` daha önce commit'lendiyse
> **rotate** edilmelidir — git geçmişi bu ortamdan incelenemedi → **BLOCKED (D5)**.

### 2.3 Navigasyon / etkileşim hijyeni
| Kontrol | Sonuç |
|---|---|
| `window.location.href =` (SPA içi) | ✅ **0** — react-router kullanılıyor |
| `alert(` | ✅ **0** — kendi modal/toast altyapısı |

---

## 3) EDGE FUNCTIONS QA (statik katalog — ÇALIŞTIRILDI, PASS)

| Metrik | Sayı |
|---|---|
| `Access-Control-Allow-Origin: *` (wildcard CORS) | **43** dosya |
| Çağıran JWT'sini `auth.getUser` ile doğrulayan | **40 / 43** |
| `SUPABASE_SERVICE_ROLE_KEY` kullanan | **41 / 43** |
| `tani-bilgi` (devre dışı, 410 döner) | 1 (pratikte 42 aktif) |
| `_shared/cors.ts` ortak modülü | ❌ workspace'te oluşturulamıyor (platform) |

**Değerlendirme:**
- **GUV-04 (wildcard CORS):** 43 fonksiyon hâlâ `*` döner. Ortak allowlist modülü **hazır**
  (`SECURITY_FINAL_REMEDIATION_REPORT.md §5.1`) ancak **deploy yasak** + `_shared/*` workspace'te
  yazılamıyor → **PREPARED — NOT APPLIED**.
- **Neden toplu refactor EDİLMEDİ:** Edge dosyaları Vite build/type-check'e **dahil değil** →
  hatalı toplu düzenleme derlemede yakalanmaz, **çalışma zamanında** tüm backend'i çökertebilir.
  "Çalışan akışları koru / küçük ve geri alınabilir tut" kuralı gereği **her fonksiyon tek tek,
  deploy öncesi kendi ortamında test edilerek** dönüştürülmelidir.

---

## 4) VERİ KATMANI QA (runtime — BLOCKED)

Aşağıdaki **gerçek PostgreSQL senaryoları ÇALIŞTIRILAMADI** (izole test DB + base şema yok):

| # | Senaryo | Durum |
|---|---|---|
| 1 | OSGB A/B SELECT/INSERT/UPDATE/DELETE tenant izolasyonu (firma, personel, atama, evrak, teklif) | ⛔ BLOCKED |
| 2 | Bilinen başka tenant UUID'siyle erişim denemesi | ⛔ BLOCKED |
| 3 | Sahte `osgb_id` / `firma_id` / `user_id` / rol enjeksiyonu | ⛔ BLOCKED |
| 4 | NULL tenant + devre dışı / süresi dolmuş OSGB | ⛔ BLOCKED |
| 5 | Parent-child kayıt ilişkileri (atama_belgeleri/hazop/noter) | ⛔ BLOCKED |
| 6 | Storage okuma/yükleme/güncelleme/silme + anon erişim + yol manipülasyonu | ⛔ BLOCKED |
| 7 | anon RPC EXECUTE + SECURITY DEFINER yetkilendirmesi | ⛔ BLOCKED |
| 8 | NULL/boş `search_path` düzeltme davranışı | ⛔ BLOCKED |
| 9 | Trigger ve Auth (`handle_new_user`) davranışı | ⛔ BLOCKED |
| 10 | teklifler / teklif_hizmetleri RESTRICTIVE RLS | ⛔ BLOCKED |

**Canlı (salt-okuma) kanıt — değişmedi:** `storage_tenant_ok` **YOK**, `null_searchpath` **4**,
definer toplam **162** → **9 migration'ın hiçbiri uygulanmamış, veri katmanı AÇIK.**

> Harness fixturu (Faz 9 düzeltmesi) gerçek zorunlu kolonlarla uyumlu **ama izole ortam
> olmadığı için yine çalıştırılmadı.**

---

## 5) FRONTEND / DERLEME QA

| Kontrol | Sonuç |
|---|---|
| Production build | ✅ **PASS** |
| Derleme-düzeyi TS/tip hatası | ✅ Derleme geçtiği için **yok** kabul |
| `tsc --noEmit` (bağımsız) | ⛔ BLOCKED |
| ESLint (bağımsız `npm run lint`) | ⛔ BLOCKED |
| `npm audit` (bağımlılık zafiyeti) | ⛔ BLOCKED |
| Runtime (E2E) test | ⛔ BLOCKED |

---

## 6) CSP / HOSTING / AUTH QA

| Kontrol | Sonuç |
|---|---|
| CSP meta (`index.html`) | ✅ Gerçek origin'lerle uyumlu (Supabase, OSM, Nominatim, Overpass, cdnjs, Google Fonts, readdy) |
| `object-src 'none'` / `base-uri 'self'` | ✅ mevcut |
| `frame-ancestors` (clickjacking) | ❌ `<meta>` ile verilemez → **HTTP başlığı (GUV-10)** |
| HSTS / `nosniff` / `Referrer-Policy` | ❌ Kod ile uygulanamaz → hosting katmanı |
| `vite.config.ts` sourcemap | ❌ **Platform reddetti** ("modification prohibited") → GUV-03 kod ile çözülemez |
| Supabase Auth (self-signup, parola politikası, rate-limit) | ⛔ BLOCKED (Dashboard) |

---

## 7) BULGU DURUM ÖZETİ (takip sözlüğü ile)

| Durum | Adet | Örnekler |
|---|---|---|
| ✅ **CLOSED** | 2 | RichTextEditor yükleme XSS, ocrService PDF XSS (build PASS) |
| 🟨 **FIXED — UNVERIFIED** | 9 | GUV-01/02/06/07/11/13/13b/14/15 (migration dosyası hazır, canlıda uygulanmadı) |
| 🟨 **PREPARED — NOT APPLIED** | 3 | GUV-04 CORS modülü + 43 refactor + `ALLOWED_ORIGINS` secret |
| ⛔ **BLOCKED** | 6 | DB runtime, tsc/eslint/audit, Auth Dashboard, CORS runtime, git geçmişi, hosting başlıkları |
| ❌ **NOT APPLICABLE (kod)** | 2 | GUV-03 sourcemap, GUV-10 HTTP başlıkları |
| 🔴 **AÇIK (canlı)** | 1 | Veri katmanı (GUV-01/02/06/07/11/13/13b/14/15 uygulanmadı) |

**"Tüm hatalar kapandı" ifadesi KULLANILMADI** — kapanış kriterleri (çalıştırılmış + retest
edilmiş test) karşılanmadı.

---

## 8) ÜRETİM GEÇİŞİ İÇİN ONAY VE ADIMLAR

1. **İzole test ortamı** kur (ayrı Supabase projesi + **şema-only dump**, gerçek veri YOK) →
   `supabase/tests/security/*` çalıştır.
2. Runtime testleri PASS olmadan **hiçbir migration üretime alınmaz.**
3. Migration sırası (gerçek bağımlılık, dosya numarası DEĞİL):
   `GUV-02 → GUV-07 → GUV-06 → GUV-01 → GUV-11 → GUV-13 → GUV-13b → GUV-14 → GUV-15`
   (GUV-14 → GUV-15(1) kısıtı + GUV-11 statik imza katılığı korunur).
4. **GUV-04 CORS**: `ALLOWED_ORIGINS` secret → modül deploy → her fonksiyon preflight tek tek test.
5. **GUV-10 başlıkları** hosting/CDN'de yapılandır.
6. **GUV-03**: platform build ayarında `sourcemap:false`.
7. Supabase Auth: **self-signup KAPALI**, parola politikası + rate-limit doğrula.
8. Her adım **açık onay + rollback planı** ile yürüt.

> Bu çalışma **resmî TSE onaylı sızma testinin yerine GEÇMEZ.**

---

## 9) SORUMLU GİRDİLER (kalan engeller için gereken erişim/dosya)

| # | Gerekli girdi | Kime bağlı |
|---|---|---|
| D1 | Ayrı Supabase **test projesi** + `pg_dump --schema-only` çıktısı | Proje sahibi / DevOps |
| D2 | Komut yürütücü (tsc / eslint / npm audit / supabase CLI) | Platform |
| D3 | Supabase **Auth Dashboard** erişimi | Proje sahibi |
| D4 | Gerçek üretim **origin** + `ALLOWED_ORIGINS` secret yazma izni | Proje sahibi |
| D5 | **Git geçmişi** (`.env` commit edilmiş mi) | Repo erişimi |
| D6 | **Hosting/CDN** başlık yapılandırma erişimi | Proje sahibi / platform |
| D7 | Platform **build ayarı** (sourcemap kapatma) | Platform desteği |