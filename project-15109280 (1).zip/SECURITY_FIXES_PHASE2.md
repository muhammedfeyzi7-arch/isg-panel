# İSGDenetim — Güvenlik Düzeltmeleri Faz 2 (Uygulama & Doğrulama Planı)

> Bu doküman **hazırlık** amaçlıdır. Üretim veritabanına, Storage politikalarına veya
> canlı kullanıcı verilerine **hiçbir müdahale yapılmamıştır**. Aşağıdaki DB
> değişikliklerinin tamamı **kontrollü bir test ortamında** doğrulandıktan sonra,
> ayrıca açık onay alınarak uygulanmalıdır.

Ortam notu: `vite.config.ts` yazmaya kapalı; `supabase/functions/_shared/*` yalnızca
`deploy_edge_function` ile oluşturulabilir; `package.json` script değişiklikleri
platform tarafından geri alınıyor. Bu kısıtlar nedeniyle bazı maddeler "hazır" ama
"uygulanmadı" olarak işaretlidir.

---

## BÖLÜM 1 — GUV-04 · Edge Functions CORS (origin allowlist)

**Production origin (tespit edildi, kullanıcı bildirdi):** `https://app.isgdenetim.com.tr`

**Neden gerekli:** 41 Edge Function'ın tamamı `Access-Control-Allow-Origin: *` döndürüyor
(kanıt: `grep` → 41 dosya). Bu, herhangi bir origin'in bu API'leri çağırabilmesi demektir.

### 1.1 Paylaşılan yardımcı (deploy aracıyla oluşturulacak)

Dosya: `supabase/functions/_shared/cors.ts`

```ts
// Merkezi CORS — origin allowlist. Wildcard YOK.
const PROD_ORIGIN = 'https://app.isgdenetim.com.tr';

/** ALLOWED_ORIGINS secret'ı + production origin. Geliştirme origin'leri YALNIZCA
 *  geliştirme ortamında secret ile eklenir; production secret'ında bulunmaz. */
function allowedOrigins(): string[] {
  const raw = (Deno.env.get('ALLOWED_ORIGINS') ?? '').trim();
  const configured = raw ? raw.split(',').map((s) => s.trim()).filter(Boolean) : [];
  return Array.from(new Set([PROD_ORIGIN, ...configured]));
}

export function corsHeaders(req: Request): Record<string, string> {
  const base: Record<string, string> = {
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Vary': 'Origin',
  };
  const origin = req.headers.get('origin');
  // Yalnızca izinli origin'e ACAO döner; izinsiz/eksik origin'de ACAO GÖNDERİLMEZ.
  if (origin && allowedOrigins().includes(origin)) {
    return { ...base, 'Access-Control-Allow-Origin': origin };
  }
  return base;
}

export function preflight(req: Request): Response {
  return new Response('ok', { headers: corsHeaders(req) });
}
```

> Not: Bu dosya bu ortamda `deploy_edge_function` dışında oluşturulamadığı için
> **henüz sisteme yazılmadı**. İçeriği buraya hazır olarak bırakıldı.

### 1.2 Her fonksiyonda uygulanacak düzenleme

```ts
// 1) Dosya başına ekle:
import { corsHeaders, preflight } from '../_shared/cors.ts';

// 2) Sabit CORS nesnesini KALDIR ve json'u request'e bağla:
const json = (req: Request, body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders(req), 'Content-Type': 'application/json' },
  });

// 3) OPTIONS yanıtı:
if (req.method === 'OPTIONS') return preflight(req);

// 4) Tüm json(...) çağrılarını json(req, ...) yap.
```

> ⚠️ Edge Function dosyaları bu projede **build/type-check'e dahil değildir** (Vite SPA
> derlemesi bunları kapsamaz). Bu yüzden 41 dosyayı toplu düzenlemek, hata yapıldığında
> **derleme ile yakalanmaz** ve yalnızca çalışma zamanında ortaya çıkar. Bu nedenle
> değişiklikler tek tek, her fonksiyon deploy öncesi test edilerek yapılmalıdır.

**JWT/rol:** CORS değişikliği kimlik doğrulamayı ETKİLEMEZ. Her fonksiyondaki
`auth.getUser(jwt)` + sunucu tarafı `profiles.role`/kapsam kontrolü AYNEN korunur.

### 1.3 Gerekli secret

Supabase Dashboard → **Edge Functions → Secrets** (SaaS Supabase):

| Secret | Değer | Kapsam |
|---|---|---|
| `ALLOWED_ORIGINS` | `https://app.isgdenetim.com.tr` | Production |

- Geliştirme origin'leri (`http://localhost:3000` vb.) **production secret'ına eklenmez**;
  yalnızca yerel/dev ortamın secret'ında tanımlanır.
- `ALLOWED_ORIGINS` tanımlı olmasa bile production origin sabit (kod içinde) izinlidir →
  **wildcard'a dönüş yok.**

### 1.4 Doğrulama adımları

```bash
# İZİNLİ origin → ACAO yansımalı olmalı
curl -i -X OPTIONS 'https://<ref>.supabase.co/functions/v1/<fn>' \
  -H 'Origin: https://app.isgdenetim.com.tr' \
  -H 'Access-Control-Request-Method: POST'
# beklenen: Access-Control-Allow-Origin: https://app.isgdenetim.com.tr

# İZİNSİZ origin → ACAO OLMAMALI (veya eşleşmemeli)
curl -i -X OPTIONS 'https://<ref>.supabase.co/functions/v1/<fn>' \
  -H 'Origin: https://evil.example.com' \
  -H 'Access-Control-Request-Method: POST'
# beklenen: Access-Control-Allow-Origin başlığı YOK
```
Her fonksiyon için (41/41) sonuç tablosu çıkarılmalıdır.

**Durum:** ⚠️ **Hazırlandı — UYGULANMADI** (paylaşılan dosya deploy aracı dışında
oluşturulamıyor; 41 dosyada toplu düzenleme derleme-dışı olduğu için riskli; deploy
prod değişikliği → onay bekliyor).

---

## BÖLÜM 2 — GUV-03 · Production sourcemap

- `vite.config.ts` → **yazmaya kapalı** (`modification prohibited to avoid compilation failure`).
- Alternatif denendi: `package.json` `"build"` script'ine build-sonrası `.map` temizleme
  adımı eklendi → **platform geri aldı** (dosyada hâlâ `"build": "vite build"`).
- **Sonuç:** ❌ **DÜZELTİLEMEDİ** (bu ortamda her iki yol da kilitli).
- **Öneri (elle):** Platform build ayarından `sourcemap: false` yapılması VEYA dağıtım
  ortamında `vite build --sourcemap=false` benzeri bir geçersiz kılma. Doğrulama:
  yayındaki JS bundle yanında `*.js.map` erişilebilir OLMAMALI.

---

## BÖLÜM 3 — GUV-10 · HSTS / nosniff / frame-ancestors (hosting katmanı)

`<meta>` ile **gönderilemez**; yalnızca HTTP yanıt başlığı olarak ayarlanır.
Barındırma/CDN katmanında aşağıdaki başlıklar eklenmelidir:

```
Strict-Transport-Security: max-age=31536000; includeSubDomains; preload
X-Content-Type-Options: nosniff
Content-Security-Policy: frame-ancestors 'self'
Referrer-Policy: strict-origin-when-cross-origin
```

> CSP'nin geri kalanı (script/style/img/connect/frame) `index.html` içindeki meta ile
> veriliyor ve **bu fazda düzeltildi** (aşağıya bkz. Ek). `frame-ancestors` meta ile
> YOK SAYILIR → mutlaka başlık olarak gönderilmelidir.

**Durum:** ⚠️ **Kod tarafından uygulanamaz** — hosting erişimi gerekir; buradan
doğrulanamadı.

**Bu fazda gerçekten düzeltilen CSP kırılması (`index.html`):** Eklenen CSP, üç özelliği
fiilen kırıyordu; eksik origin'ler eklend **ve build başarılı**:
- `img-src` → `https://*.tile.openstreetmap.org` (Leaflet haritaları)
- `connect-src` → `https://nominatim.openstreetmap.org`, `https://overpass-api.de`,
  `https://overpass.kumi.systems`, `https://overpass.private.coffee` (adres geocode)
- `frame-src` → `blob:` (rapor önizlemeleri) + `https://*.supabase.co` (imzalı belge önizleme)

---

## BÖLÜM 4 — 5 SQL migration · Kontrollü Test Planı

> Üretime **uygulanmadı**. Aşağıdaki statik inceleme gerçek şema + kodla karşılaştırılarak
> yapıldı; ancak **çalıştırılmadı** (kontrollü test ortamı/ayrı Supabase projesi yok).

Ortak test prensibi: İki test OSGB'si (**A**, **B**) ve şu kullanıcılar/roller:
`A1=osgb_admin@A`, `A2=uzman@A`, `B1=osgb_admin@B`, `anon`, `admin`.

### GUV-01 — Storage tenant izolasyonu

- **Sözdizimi/şema uyumu:** `atama_belgeleri.dosya_path`, `personeller.foto_url`,
  `hazop_kanitlari.storage_path`, `noter_defteri_ekleri.storage_path`, hepsinde `osgb_id`
  mevcut ✅. `osgb(id, deleted_at, is_active, erisim_baslangic, erisim_bitis)` mevcut ✅.
- **Bağımlılıklar:** `storage_tenant_ok()` yeni fonksiyon; `auth_role()`, `auth_osgb_id()`
  çağırır. 4 bucket'ın her birinde tek SELECT + gerekli DELETE/INSERT politikası
  yönetiliyor. **Bucket'ların tamamı private (`public=false`)** → RLS tek kapı ✅.
- **Dosya yolları:** `atama-belgeleri`=`${uid}/…`, `personel-foto`=`${uid}/…`,
  `noter-defteri`=`${uid}/…`; `foto_url`/`dosya_path` PATH saklar → `foldername[1]=auth.uid()`
  ve `X.osgb_id=auth_osgb_id()` eşleşmeleri doğru ✅.
- **Öncesi:** authenticated (ve `noter-defteri` için anon) herkes `bucket_id` şartıyla
  okuyabiliyordu (cross-tenant).
- **Sonrası:** yalnız admin / dosya sahibi (uid) / aynı OSGB kapsamı; `noter-defteri` anon erişimi kapalı.
- **Testler:**
  1. A1 → kendi dosyası: `list` + `createSignedUrl` → **başarılı olmalı**
  2. B1 → A dosyasına `createSignedUrl` → **hata/0 satır**
  3. anon → `noter-defteri` `createSignedUrl` → **yetki yok**
  4. A2 (uzman, osgb_id=A) → ilişkisel kaydı olan A dosyası → **başarılı**
- **Idempotent:** `CREATE OR REPLACE` + `DROP POLICY IF EXISTS` → tekrar çalıştırma güvenli ✅
- **Rollback SQL:** Orijinal politikalara dönüş:
  ```sql
  DROP POLICY IF EXISTS atama_belgeleri_obj_read ON storage.objects;
  CREATE POLICY atama_belgeleri_obj_read ON storage.objects FOR SELECT TO authenticated
    USING (bucket_id = 'atama-belgeleri');
  -- personel-foto / hazop-kanitlari / noter-defteri için de aynı şekilde bucket-only politika geri kurulur.
  DROP FUNCTION IF EXISTS public.storage_tenant_ok(text, text);
  ```
  (Uyarı: rollback güvenlik açığını geri açar → yalnızca acil geri dönüş için.)
- **Kırılma noktaları (risk):** (a) İlişkisel kaydı OLMAYAN ve sahibi olmadığınız bir
  dosyaya erişim gerekirse engellenir. (b) `firma` rolü (osgb_id dolu) teorik olarak aynı
  OSGB'nin tüm dosyalarını görebilir (tablo RLS'i satırı kısıtlar ama storage politikası
  firma-kapsamlı değil) → **kalan orta seviye artık risk**, ayrıca sıkılaştırılabilir.
- **Durum:** 🧪 **Yalnızca kod incelemesi yapıldı** (şema/sözdizimi/bağımlılık doğrulandı);
  test ortamı olmadığı için çalıştırılmadı.

### GUV-02 — handle_new_user rol yükseltme

- **Şema:** `profiles(id, email, role, first_name, last_name, avatar_url)` ✅
- **Bağımlılıklar:** `accept-invite` edge fn rolü `profiles.upsert` ile **sunucu tarafında**
  yazıyor → trigger metadata okumasına bağımlı DEĞİL ✅ (davet akışı bozulmaz).
- **Öncesi:** `role = COALESCE(NULLIF(raw_user_meta_data->>'role',''),'pending')` (istemci kontrolü).
- **Sonrası:** metadata yok sayılır; normal kayıt `'pending'`; yalnız sabit e-posta admin.
- **Testler:** (1) metadata `{role:'admin',osgb_id,firma_id}` ile signup → profil `'pending'`,
  osgb/firma boş. (2) Davet akışı → rol davet kaydından doğru atanır. (3) `info@isgdenetim.com.tr` → admin.
- **Ek aksiyon (Dashboard):** Auth → **self-signup KAPALI** olmalı (koddan doğrulanamaz).
- **Idempotent:** `CREATE OR REPLACE FUNCTION` ✅
- **Rollback:** Orijinal `handle_new_user` gövdesi geri kurulur (bilinen tanım).
- **Durum:** 🧪 **Yalnızca kod incelemesi yapıldı** — test ortamı yok.

### GUV-06 — teklifler / teklif_hizmetleri RESTRICTIVE

- **Şema:** `osgb_id` her iki tabloda `NOT NULL`, trigger yok ✅
- **Bağımlılıklar:** Yazma yolu `teklif_kaydet`/`teklif_sil`/`teklif_hizmet_aciklama_kaydet`
  → hepsi **SECURITY DEFINER** (RLS'i baypas eder) ✅ → RESTRICTIVE ekleme yazmayı KIRMAZ.
  Okuma doğrudan `SELECT` ile → RESTRICTIVE tenant kapısı etkili olur.
- **Öncesi:** tüm politikalar PERMISSIVE (OR) → tenant guard'ları denetlenemiyor.
- **Sonrası:** RESTRICTIVE (AND) tenant guard → cross-tenant okuma/yazma imkânsız; meşru akış korunur.
- **Testler:** A1/B1 ile SELECT (yalnız kendi OSGB), INSERT (`osgb_id=A` kabul, `=B` red), UPDATE/DELETE (yalnız kendi satırı).
- **Idempotent:** `DROP POLICY IF EXISTS` + `CREATE POLICY` ✅
- **Rollback:** `DROP POLICY IF EXISTS teklifler_tenant_restrictive ON public.teklifler;` (+ teklif_hizmetleri)
- **Kırılma noktaları:** Gelecekte doğrudan (RPC'siz) insert `osgb_id` null ile yapılırsa reddedilir → şu an böyle bir yol yok.
- **Durum:** 🧪 **Yalnızca kod incelemesi yapıldı** — test ortamı yok.

### GUV-07 — osgb_access_ok() sertleştirme

- **Bağımlılıklar:** Yalnız 4 tablonun (atamalar, evraklar, firmalar, personeller)
  RESTRICTIVE ALL guard'ında kullanılıyor ✅. `osgb` kolonları mevcut ✅.
- **Öncesi:** `auth_role()='admin' OR auth_osgb_id() IS NULL OR EXISTS(aktif osgb)` → `NULL` dalı koşulsuz TRUE.
- **Sonrası:** `admin OR (osgb_id IS NOT NULL AND geçerli/aktif/sil-inmemiş OSGB)`.
- **Testler:** (1) osgb_id BOŞ uzman → 4 tabloda 0 satır. (2) admin → tümü. (3) geçerli osgb_admin → kendi kapsamı. (4) `is_active=false`/`erisim_bitis` geçmiş OSGB → erişim yok.
- **Idempotent:** `CREATE OR REPLACE FUNCTION` ✅
- **Rollback:** Orijinal `osgb_access_ok` gövdesi (NULL dalı dahil) geri kurulur.
- **Kırılma noktaları:** osgb_id'si boş ama meşru erişim bekleyen hesap → kapalı (istenen davranış).
- **Durum:** 🧪 **Yalnızca kod incelemesi yapıldı** — test ortamı yok.

### GUV-11 — anon EXECUTE revoke

- **Şema/imza:** 6 fonksiyonun imzası da `()` (argümansız) → `REVOKE` sözdizimi geçerli ✅
- **Mevcut grant:** PUBLIC/anon/authenticated (kanıt: `information_schema.routine_privileges`).
- **Trigger fonksiyonları** (`announcement_audit`, `announcement_normalize`,
  `atama_belgeleri_derive`) çalışma-zamanı EXECUTE gerektirmez → revoke güvenli ✅.
  `_cleanup_personel_mig` artık migration → istemci çağrısı yok. `auth_role`/`next_tutanak_no`
  authenticated'e açık bırakılır (RLS + olası RPC için).
- **Testler:** anon ile `rpc('auth_role'|'next_tutanak_no'|'announcement_audit')` → **permission denied**;
  authenticated ile `auth_role()` → başarılı; announcement/atama insert-update → hatasız.
- **Idempotent:** `REVOKE`/`GRANT` ✅
- **Rollback:** `GRANT EXECUTE ON FUNCTION public.auth_role() TO PUBLIC, anon;` (+ diğerleri)
- **Kırılma noktaları:** İstemciden `next_tutanak_no` çağrısı varsa (grep: yok) etkilenmez; authenticated açık kaldı.
- **Durum:** 🧪 **Yalnızca kod incelemesi yapıldı** — test ortamı yok.

### Migration durum özeti

| # | Migration | Durum |
|---|---|---|
| 1 | GUV-01 Storage izolasyonu | Yalnızca kod incelemesi yapıldı (test ortamı yok) |
| 2 | GUV-02 handle_new_user | Yalnızca kod incelemesi yapıldı (test ortamı yok) |
| 3 | GUV-06 teklifler RLS | Yalnızca kod incelemesi yapıldı (test ortamı yok) |
| 4 | GUV-07 osgb_access_ok | Yalnızca kod incelemesi yapıldı (test ortamı yok) |
| 5 | GUV-11 anon EXECUTE | Yalnızca kod incelemesi yapıldı (test ortamı yok) |

---

## BÖLÜM 5 — Test / Araç durumu

| Kontrol | Sonuç |
|---|---|
| Production build | ✅ Başarılı |
| `.map` çıktısı | ⚠️ Doğrulanamadı (out/ git-ignore'lu) |
| Dedicated `tsc`/`eslint` | ⚠️ Çalıştırılamadı (komut yürütücü yok) |
| DB migration testleri | ⛔ Çalıştırılmadı (test ortamı yok) |
| npm audit | ⛔ Çalıştırılmadı |

---

## BÖLÜM 6 — Faz 3 · Gerçek uygulanan düzeltme + canlı DB teyidi

### 6.1 Gerçekten uygulanan kod düzeltmesi (build doğrulandı ✅)

**GUV-05 / GUV-08 — `PptxPreviewAdapter` ana slayt sahnesi sanitize edilmiyordu.**
- Değişen dosya: `src/components/feature/preview/viewers/PptxPreviewAdapter.tsx` (satır ~457).
- Öncesi: `dangerouslySetInnerHTML={{ __html: current?.html ?? '' }}` (ray satırı 415
  sanitize edilirken ana sahne edilmiyordu → tutarsız, savunma derinliği eksikliği).
- Sonrası: `dangerouslySetInnerHTML={{ __html: sanitizeHtml(current?.html ?? '', 'preview') }}`.
- Test: production build → ✅ **Build successful** (çalışma-zamanı XSS testi bu ortamdan
  yapılamadı; kod incelemesi + derleme doğrulaması mevcut).
- Yeniden tarama: `dangerouslySetInnerHTML` yutaklarının TAMAMI artık sanitize ediyor
  (NoterKayitDetailModal, Docx, Pptx ×2, Xlsx). `document.write` / `insertAdjacentHTML` yok.

### 6.2 Canlı DB teyidi (salt-okuma SELECT — hiçbir şey UYGULANMADI)

Faz 3'te canlı veritabanı metadata'sı salt-okuma ile yeniden doğrulandı; migration'ların
**uygulanmadığı** birebir görüldü:

| Kanıt sorgusu | Canlı sonuç | Anlam |
|---|---|---|
| `pg_get_functiondef(handle_new_user)` | hâlâ `raw_user_meta_data->>'role'` okuyor | GUV-02 açık |
| `pg_get_functiondef(osgb_access_ok)` | hâlâ `auth_osgb_id() IS NULL` dalı var | GUV-07 açık |
| `storage_tenant_ok` fonksiyonu | **YOK** | GUV-01 uygulanmadı |
| `pg_policies` teklifler/teklif_hizmetleri | **13 policy, hepsi PERMISSIVE** | GUV-06 açık |
| `has_function_privilege('anon', ...)` | 6/6 fonksiyon `anon_can=true` | GUV-11 açık |
| `storage.buckets.public` | 4 bucket da `false` (private) | RLS tek kapı (düzeltme kritik) |
| storage read politikaları | bucket-only; `noter-defteri` `{public}` | GUV-01 cross-tenant + anon |

> Migration dosyalarının varlığı açığı KAPATMIYOR — canlı kanıt bunu gösteriyor.

### 6.3 Bu ortamda gerçekten uygulanamayanlar

- **GUV-03 sourcemap:** `vite.config.ts` hâlâ `sourcemap: true`; yazmaya kapalı;
  `package.json` build script değişiklikleri platform tarafından geri alınıyor.
  → ❌ Düzeltilemedi (desteklenen yol: platform build ayarı / dağıtım ortamı).
- **GUV-04 CORS:** 41/41 fonksiyon hâlâ `Access-Control-Allow-Origin: *`; paylaşılan
  `_shared/cors.ts` deploy aracı dışında oluşturulamıyor; canlı deploy yasak.
  → ⚠️ Hazır (Bölüm 1) — UYGULANMADI.
- **GUV-10 HSTS / nosniff / frame-ancestors:** yalnızca hosting HTTP başlığı → kod tarafından
  uygulanamaz (Bölüm 3).

---

## BÖLÜM 7 — Faz 5 · Migration eksiklerinin giderilmesi (kod düzeyi)

> Faz 4'te tespit edilen eksikler dosya düzeyinde giderildi. **Üretim veritabanına hiçbir
> şey UYGULANMADI**, hiçbir Edge Function deploy edilmedi, canlı RLS/Storage değiştirilmedi.
> Tüm değişiklikler `supabase/migrations/` altındaki SQL dosyalarındadır.

### 7.1 GUV-01 — Storage tenant izolasyonu (KRİTİK) — **Düzeltildi**

- **`storage_tenant_ok()` yeniden yazıldı: rol-farkındalıklı.**
  - admin → tümü; dosya sahibi (folder[1]=auth.uid()) → kendi dosyası.
  - osgb_admin → ilişkisel kaydın `osgb_id`'si kendi OSGB'siyle eşleşmeli.
  - firma → ilişkisel kaydın `firma_id`'si kendi firmasıyla eşleşmeli (**aynı OSGB'de olmak
    tek başına tüm firma dosyalarını okuma yetkisi vermez**).
  - uzman/hekim → ilişkisel kaydın firmasında **aktif atama** (`has_active_firma_assignment`).
  - İlişkisel kayıt yoksa (dosya_path/storage_path boş) → **varsayılan DENY**.
- **hazop-kanitlari INSERT boşluğu KAPATILDI:** artık `folder[1]=auth.uid()` + rol kontrolü
  (`admin/osgb_admin/uzman/hekim`); bucket-only değil.
- **noter-defteri anon (`{public}`) erişimi KALDIRILDI:** tüm politikalar `TO authenticated`.
- **UPDATE politikaları** eklendi (sahip/admin) — `upsert:true` güvenliği (yol benzersiz
  olduğu için normal akışta INSERT yeterlidir; UPDATE savunma amaçlıdır).
- **Dosya yolu doğrulaması:** atama-belgeleri/personel-foto/noter-defteri kodu `${uid}/...`
  biçiminde üretir → `foldername[1]=auth.uid()` varsayımı mevcut veriyle uyumlu. hazop için
  kod bulunamadı (0 nesne); uid-prefix varsayıldı, dosya yükleme akışı yazıldığında hizalanmalı.

### 7.2 GUV-02 — Güvenilir rol ataması (YÜKSEK) — **Düzeltildi**

- `raw_user_meta_data.role` okuması KALDIRILDI → normal kayıt `'pending'`.
- `osgb_id`/`firma_id` metadata'dan okunmaz/yazılmaz → istemci kendini keyfî OSGB/firmaya
  bağlayamaz.
- Sabit bootstrap admin e-postası korundu; **yalnızca e-posta karşılaştırmasının yeterli
  OLMADIĞI** ve self-signup'ın KAPALI olması gerektiği açıkça belgelendi.
- `handle_new_user()` EXECUTE izinleri PUBLIC'ten kaldırıldı (savunma derinliği).
- Davet akışı regresyon riski: `accept-invite` rolü `davetler.role`'den yazar → bozulmaz.

### 7.3 GUV-06 — teklifler RESTRICTIVE (YÜKSEK) — **Düzeltildi (defense-in-depth)**

- RESTRICTIVE tenant guard eklendi. **Dürüst sınıflandırma:** mevcut permissive politikalar
  zaten tenant-scoped olduğundan **aktif sızma doğrulanamadı**; bu madde sertleştirmedir.
- Yazma RPC'leri SECURITY DEFINER olduğundan RESTRICTIVE eklemek yazmayı bozmaz.

### 7.4 GUV-07 — osgb_access_ok() (KRİTİK) — **Düzeltildi**

- `auth_osgb_id() IS NULL → TRUE` dalı KALDIRILDI. Artık admin VEYA geçerli/aktif/sil-inmemiş
  OSGB'ye bağlı kullanıcı → true.
- **Kritik regresyon doğrulaması (kod + canlı DB):** `accept-invite`, firma profillerine
  `osgb_id = davet.osgb_id` yazar → firma kullanıcılarının osgb_id'si DOLUDUR. Bu yüzden
  sertleştirme firma erişimini bozmaz.

### 7.5 GUV-11 — anon EXECUTE izinleri (ORTA) — **Düzeltildi (genişletildi)**

- Altı fonksiyonun anon/PUBLIC izinleri kaldırıldı (`auth_role`/`next_tutanak_no` → authenticated).
- **Ek (defense-in-depth):** teklif yazma RPC'leri (`teklif_kaydet`, `teklif_sil`,
  `teklif_hizmet_aciklama_kaydet`, `teklif_gonderim_kaydet`, `teklif_durum_guncelle`,
  `teklif_public_token_uret`) anon'dan kapatıldı; bunlar gövdesel `AUTH_REQUIRED` guard
  içerdiğinden aktif açık değildi.
- **Public teklif akışı korundu:** `teklif_public_get/view/action` anon erişimi AÇIK bırakıldı.

### 7.6 Değiştirilen/oluşturulan dosyalar

| Dosya | Durum |
|---|---|
| `supabase/migrations/20260101000100_guv01_storage_tenant_isolation.sql` | **Düzeltildi** (yeniden yazıldı) |
| `supabase/migrations/20260101000200_guv02_handle_new_user.sql` | **Düzeltildi** (doc + hande revoke) |
| `supabase/migrations/20260101000300_guv06_teklifler_tenant_restrictive.sql` | **Düzeltildi** (doc) |
| `supabase/migrations/20260101000400_guv07_osgb_access_ok.sql` | **Düzeltildi** (doc + regresyon kanıtı) |
| `supabase/migrations/20260101000500_guv11_revoke_anon_execute.sql` | **Düzeltildi** (genişletildi) |
| `supabase/migrations/rollback/20260101000100_..._rollback.sql` | **Yeni** |
| `supabase/migrations/rollback/20260101000200_..._rollback.sql` | **Yeni** |
| `supabase/migrations/rollback/20260101000300_..._rollback.sql` | **Yeni** |
| `supabase/migrations/rollback/20260101000400_..._rollback.sql` | **Yeni** |
| `supabase/migrations/rollback/20260101000500_..._rollback.sql` | **Yeni** |
| `SECURITY_MIGRATION_TEST_PLAN.md` | **Yeni** (test senaryoları + beklenen sonuçlar) |

### 7.7 Idempotency / kilit / erişim kaybı / veri kaybı

| Risk | Değerlendirme |
|---|---|
| Tekrar çalıştırılabilirlik | Tümü idempotent (CREATE OR REPLACE, DROP IF EXISTS, REVOKE/GRANT) ✅ |
| Yanlış politika silme | DROP `IF EXISTS <isim>` bilinçli; isimler canlı politikalarla birebir eşleşiyor |
| Kilit | Yalnızca kısa metadata lock; tablo verisi kopyalanmaz → risk düşük |
| Veri kaybı | **YOK** — hiçbir migration tablo/satır silmez/güncellemez |
| Erişim kaybı | Yanlış politika → erişim kaybı olabilir; rollback ile geri alınır |

### 7.8 Test durumu (gerçek)

| Kontrol | Sonuç |
|---|---|
| Migration sözdizimi (statik) | ✅ Geçti |
| Rollback dosyaları | ✅ 5/5 mevcut |
| İzole ortam A/B testleri | ⛔ **Test edilmedi** (izole iki-OSGB ortamı yok) |
| CORS preflight | ⛔ **Test edilmedi** |
| `npm audit` / tsc / eslint ayrı | ⛔ **Engellendi** (komut yürütücü yok) |
| Auth Dashboard / hosting başlıkları | ⛔ **Doğrulanamadı** (erişim yok) |

> **Kritik uyarı:** Migration dosyalarının varlığı/düzeltilmesi bunları **canlı
> veritabanına uygulanmadı**. Faz 3'te canlı DB metadata'sı (salt-okuma) bunu
> doğruladı. Uygulama, izole test ortamında doğrulama + açık onay sonrası yapılmalıdır.
> Bu çalışma resmî TSE onaylı sızma testinin yerine geçmez.

---

## BÖLÜM 8 — Faz 6 · Kapsamlı QA, test, düzeltme ve retest

> **Yöntem:** Kaynak kod okuma + `grep` + canlı Supabase'de **yalnızca salt-okuma**
> `SELECT` (pg_proc / pg_policies / storage.objects / storage.buckets /
> has_function_privilege / information_schema) + production build. **Hiçbir DDL/DML
> üretime uygulanmadı**, hiçbir Edge Function deploy edilmedi, canlı RLS/Storage
> değiştirilmedi, kullanıcı verisi değiştirilmedi.

### 8.1 Canlı durum teyidi (salt-okuma kanıtları)

| Kontrol | Canlı sonuç | Anlam |
|---|---|---|
| `handle_new_user` gövdesi | `raw_user_meta_data` okuması **hâlâ var** | GUV-02 açık |
| `osgb_access_ok` gövdesi | `auth_osgb_id() IS NULL` dalı **hâlâ var** | GUV-07 açık |
| `storage_tenant_ok` fonksiyonu | **YOK** | GUV-01 uygulanmadı |
| teklifler/teklif_hizmetleri policy | **13 policy, hepsi PERMISSIVE** | GUV-06 uygulanmadı |
| storage read politikaları | atama/personel/hazop = bucket-only; noter-defteri = `{public}` | GUV-01 doğrulandı |
| `hazop_kanit_storage_insert` | `with_check = bucket_id` (yalnızca) | INSERT boşluğu doğrulandı |
| 6 fonksiyon `anon` EXECUTE | 6/6 `anon_can = true` | GUV-11 uygulanmadı |
| 4 bucket `public` | hepsi `false` (private) | RLS tek kapı |
| RLS kapalı public tablo | **YOK** (0 satır) | ✅ İyi haber |
| Migration bağımlılıkları (fonksiyon imzaları, `osgb` kolonları) | **hepsi mevcut** | Migration'lar şema-uyumlu |

### 8.2 YENİ BULGULAR (bu fazda tespit edildi)

**GUV-13 — anon/PUBLIC SECURITY DEFINER RPC EXECUTE izinleri (YÜKSEK)**
- Canlı ölçüm: anon'un EXECUTE edebildiği SECURITY DEFINER fonksiyon **159**; bunlardan
  **trigger döndürmeyen (gerçekten çağrılabilir) 104**.
- **En kritik:** gövdesel yetki kontrolü OLMAYAN, veri değiştiren ve anon'un
  çağırabildiği definer fonksiyonlar: `auto_close_ziyaretler()`, `auto_renew_programlar()`,
  `atama_suresi_dolanlari_guncelle()`, `evrak_durum_senkron()`.
- Yüksek riskli diğerleri (`delete_osgb_permanent`, `admin_dashboard_summary`,
  `atama_create/update`, `create_announcement`, `ekipman_insert` vb.) **gövdesel
  auth.uid()/auth_role() kontrolü içerdiğinden aktif istismar doğrulanamadı**; grant
  daraltması savunma derinliği içindir.
- **Düzeltme (dosya):** `supabase/migrations/20260101000600_guv13_revoke_anon_definer_rpc.sql`
  — dinamik `DO` bloğu ile seçili iç/yönetim/zamanlayıcı RPC'lerden PUBLIC+anon EXECUTE
  kaldırılır, `authenticated`+`service_role` korunur. Rollback: `.../rollback/...guv13...`

**GUV-14 — SECURITY DEFINER search_path sabitlenmemiş (ORTA)**
- Canlı ölçüm: `search_path` sabitlenmemiş definer fonksiyonlar (4): `custom_field_definition_set_osgb`,
  `custom_field_value_set_scope`, `firma_evrak_klasorleri_set_scope` (niteliksiz `FROM firmalar`),
  `ziyaret_auto_close_due`.
- **Düzeltme (dosya):** `supabase/migrations/20260101000700_guv14_definer_search_path.sql`
  — dinamik `DO` bloğu, `search_path`'i olmayan TÜM definer fonksiyonlara
  `search_path = public, pg_temp` sabitler. Rollback: `.../rollback/...guv14...`

**GUV-04 — CORS güncel sayı**: 41 değil **43** Edge Function `Access-Control-Allow-Origin: *`
kullanıyor (canlı tarama). Paylaşılan `_shared/cors.ts` **yalnızca `deploy_edge_function`
ile oluşturulabiliyor** ve **canlı deploy yasak** → bu fazda **uygulanamadı** (hazırlık
Bölüm 1'de).

**GUV-15 (görece iyi haber)**: public şemada **RLS kapalı tek tablo YOK**.

### 8.3 Bu ortamda engellenen (desteklenen yol yok)

| Bulgu | Neden engellendi | Durum |
|---|---|---|
| GUV-03 sourcemap | `vite.config.ts` **yazmaya kapalı** ("modification prohibited") | **Düzeltilemedi** |
| GUV-04 CORS | `_shared/cors.ts` yalnızca deploy aracıyla; deploy yasak | **Hazır, uygulanmadı** |
| GUV-10 HSTS/nosniff/frame-ancestors | yalnızca HTTP yanıt başlığı; hosting katmanı gerekir | **Kod ile uygulanamaz** |

### 8.4 Faz 5 düzeltmelerinin retest edilen kısımları

- İstemci side XSS: `dangerouslySetInnerHTML` kullanan 5 nokta (NoterKayitDetailModal,
  Docx, Pptx ×2, Xlsx) **hepsi `sanitizeHtml(...)` ile sarmalı** — `grep` ile yeniden
  doğrulandı; `document.write`/`insertAdjacentHTML` yok. ✅
- CSP (`index.html`): `object-src 'none'`, `base-uri 'self'`, Supabase/OSM/Nominatim/
  Overpass/cdnjs/fonts origin'leri mevcut; firebase istemcide **kullanılmıyor** (`grep`).

### 8.5 Durum sınıflandırması (Faz 6)

| Bulgu | Dosya düzeltmesi | Runtime testi |
|---|---|---|
| GUV-01 Storage | Düzeltildi (Faz 5 dosyası) | **Test edilmedi** (izole ortam yok) |
| GUV-02 rol | Düzeltildi | **Test edilmedi** |
| GUV-06 teklifler | Düzeltildi | **Test edilmedi** |
| GUV-07 osgb_access_ok | Düzeltildi | **Test edilmedi** |
| GUV-11 anon EXECUTE (6) | Düzeltildi | **Test edilmedi** |
| **GUV-13 anon definer RPC (104)** | **Düzeltildi (yeni migration)** | **Test edilmedi** |
| **GUV-14 definer search_path** | **Düzeltildi (yeni migration)** | **Test edilmedi** |
| GUV-03 sourcemap | **Düzeltilemedi** | — |
| GUV-04 CORS | Hazır, uygulanmadı | — |
| GUV-10 başlıklar | Kod ile uygulanamaz | — |
| RLS kapalı tablo | ✅ Bulunamadı | — |

> **Net durum:** İstemci-kod tarafı ve migration DOSYALARI sağlam; ancak **veri katmanı
> (GUV-01/02/06/07/11/13/14) canlıda hâlâ açık** — bu dosyalar canlıya UYGULANMADI.
> Bu hâliyle **sızma testine hazır değil**. Bu çalışma resmî TSE onaylı sızma testinin
> yerine geçmez.

---

## BÖLÜM 9 — Faz 7 · Migration doğrulama ve test hazırlığı (salt inceleme)

> **SINIR:** Bu turda **hiçbir dosya, migration, RLS/Storage politikası veya canlı ortam
> değiştirilmedi.** Yalnızca 7 migration + 7 rollback incelendi, canlı DB **salt-okuma**
> sorgulandı, izole test dosyaları hazırlandı. Gerçek runtime testi **çalıştırılmadı**.

### 9.1 Bu turda üretilen dosyalar
- **`SECURITY_MIGRATION_DEPENDENCIES.md`** — 7 migration + rollback için bağımlılık,
  ön koşul, idempotency ve rollback kapsamı; çapraz bağımlılık matrisi; test ortamı blocker.
- **`SECURITY_TEST_RESULTS_PHASE7.md`** — PASS/FAIL/BLOCKED sınıflandırmalı sonuç raporu.
- **`supabase/tests/security/`** — izole ortamda çalıştırılacak güvenli SQL test seti
  (`00_harness.sql` + 6 `.test.sql`), yalnız sahte veri + transaction/rollback.

### 9.2 Yeni bulgular (Faz 7)
- **GUV-13 kapsam açığı:** Canlıda anon'un çağırabildiği **104** definer fonksiyondan
  **23'ü** hedef listesi dışında (bakım/özet + RLS yardımcıları). Bakım/özet olanların
  (ör. `operasyon_bakim_hatirlatma`, `personel_atama_sure_plan`, `project_myk_requirements`)
  da daraltılması önerilir → **"Kod incelemesi gerekli"**.
- **GUV-14 kapsam dışı:** `log_system_event(text,text)` canlıda `search_path=""` (boş, set
  edilmiş) → GUV-14 filtresi bu fonksiyonu **atlar**; ayrı ele alınmalıdır.
- **GUV-07 kapsam netleşmesi:** `atamalar/evraklar/firmalar/personeller` üzerindeki
  `*_osgb_access_guard` politikaları canlıda **zaten RESTRICTIVE**; GUV-07 yalnız
  `osgb_access_ok()` **fonksiyon gövdesini** sertleştirir (policy oluşturmaz).

### 9.3 Doğrulanan bağımlılıklar (canlı, salt-okuma)
- `firma_id` kolonları: `atama_belgeleri`(NOT NULL), `personeller`(nullable),
  `hazop_kanitlari`(NOT NULL), `noter_defteri_ekleri`(NOT NULL) → GUV-01 bağımlılığı ✅.
- Yardımcı fonksiyonlar (`auth_role`, `auth_osgb_id`, `auth_firma_id`,
  `has_active_firma_assignment`) mevcut ✅. `_cleanup_personel_mig` definer=false (INVOKER).
- GUV-13 hedef isimlerinin **tamamı** definer olarak mevcut (overload'lar dahil) ✅.
- GUV-14 hedefleri tam **4** fonksiyon, `proconfig=null` ✅.

### 9.4 Durum (Faz 7)
| Kontrol | Sonuç |
|---|---|
| 7 migration statik inceleme | ✅ Tamamlandı |
| 7 rollback dosyası | ✅ 7/7 mevcut |
| İzole DB runtime testleri | ⛔ **BLOCKED** (base şema/izole ortam yok) |
| Production build | ✅ PASS |
| Canlı ortama müdahale | ❌ YOK |

> Veri katmanı (GUV-01/02/06/07/11/13/14) canlıda **hâlâ açık**; migration dosyaları
> UYGULANMADI. Detaylar: `SECURITY_TEST_RESULTS_PHASE7.md`.