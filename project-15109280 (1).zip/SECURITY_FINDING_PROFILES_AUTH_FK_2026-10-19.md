# GÜVENLİK BULGUSU — GUV-32

## `public.profiles` ↔ `auth.users` referans bütünlüğü eksik (hesap silmede yetim profil / veri artığı)

| Alan | Değer |
|---|---|
| Bulgu ID | GUV-32 |
| Tarih | 2026-10-19 |
| Önem | **ORTA** (veri artığı + e-posta eşleşme akışlarında kimlik karışması riski) |
| Durum | Düzeltme hazır — üretime uygulanmayı bekliyor |
| Bileşen | PostgreSQL şeması / `public.profiles` |
| Migration | `supabase/migrations/20260101002300_guv32_profiles_auth_users_fk.sql` |
| Rollback | `supabase/migrations/rollback/20260101002300_guv32_profiles_auth_users_fk_rollback.sql` |
| Test | `supabase/tests/security/guv32_profiles_auth_users_fk.test.sql` |
| Keşfedildiği yer | GUV-31 doğrulaması sırasında, test kullanıcısı temizliği |

---

## 1. Bulgu

`public.profiles` tablosunda `id` kolonunun `auth.users(id)` tablosuna bakan **hiçbir foreign key'i yoktur.** Tablodaki tek FK'lar `firma_id` ve `osgb_id` içindir ve ikisinin de `ON DELETE` davranışı `SET NULL`'dır.

Bu nedenle Supabase Auth üzerinden bir kullanıcı silindiğinde, `public.profiles` içindeki karşılık gelen satır **veritabanında kalmaya devam eder.**

## 2. Kanıt (üretim veritabanı, 2026-10-19)

### 2.1 FK kataloğu

```
        conname         | confdeltype | davranis
------------------------+-------------+----------
 profiles_firma_id_fkey | n           | SET NULL
 profiles_osgb_id_fkey  | n           | SET NULL
(2 rows)
```

`profiles.id → auth.users(id)` için **kayıt yok.**

### 2.2 Canlı davranış testi

Geçici kullanıcı `esc.test@pentest.local` Admin API ile oluşturuldu, profili otomatik oluştu (`role = pending`), ardından kullanıcı silindi:

```
--- 1) auth kullanici silindi ---
auth kullanici silindi -> 200

 auth_kalan
------------
          0        ← auth.users temiz

 profil_kalan
--------------
            1        ← public.profiles satırı KALDI

 mail_kalan
------------
          1        ← e-posta da KALDI
```

Ardından satır elle silindi:

```
DELETE 1
 auth_kalan: 0   profil_kalan: 0   mail_kalan: 0
```

### 2.3 Yetim profil taraması (test sonrası)

```
 toplam_profil | yetim_profil
---------------+--------------
            15 |            0
```

Şu an üretimde yetim satır **yok** — ancak bu, kuralın değil, geçmişte hesap silme yapılmamış olmasının sonucu. FK olmadığı sürece her yeni silme işlemi yeni bir yetim satır üretir.

## 3. Etki

1. **KVKK / GDPR silme hakkı ihlali.** Hesap silme talebi işlendiğinde e-posta, ad-soyad ve avatar gibi kişisel veriler `public.profiles` içinde süresiz kalır.
2. **Hayalet kayıt kirliliği.** `profiles` tablosuna join yapan tüm listelerde (personel, atama, bildirim, istatistik) auth karşılığı olmayan satırlar görünür.
3. **E-posta eşleşme akışlarında kimlik karışması.** `accept-invite`, `personel-hesap`, `osgb-davet`, `firma-davet` gibi Edge Function'lar kayıtları e-posta üzerinden bulup yeniden kullanabiliyor. Yetim bir satır ileride aynı e-posta ile açılan yeni bir hesapla "eşleşirse" eski `role` / `osgb_id` / `firma_id` bilgisi taşınabilir. Bu, yetki yükseltmesine dönüşme potansiyeli taşıyan bir yoldur (dolaylı, ancak gerçek).
4. **Referans bütünlüğü garantisi yok.** `profiles.id` herhangi bir uuid olabilir. `service_role` ile çalışan bir Edge Function hatası veya elle yapılan bir müdahale, hiç var olmayan bir kullanıcıya ait profil üretebilir.

**Neden bu GUV-31 kadar kritik değil:** GUV-31 sonrası `anon` ve `authenticated` rolleri için `public.profiles` üzerinde **tablo düzeyi INSERT yetkisi yoktur.** Yani istemci kendi profiline keyfî bir `id` yazamaz. Saldırganın doğrudan kullanabileceği bir yetki yükseltme vektörü **ölçülmedi**; risk, veri saklama ve e-posta eşleşme akışları üzerinden dolaylıdır.

## 4. Düzeltme

`profiles.id` üzerine `auth.users(id)` FK'si, `ON DELETE CASCADE` ile eklenir.

- Auth kullanıcısı silinince profil de silinir → yetim satır oluşması DB seviyesinde imkânsız.
- Kullanıcı oluşturma akışı (`handle_new_user()` trigger'ı) etkilenmez; `auth.users` satırı önce oluştuğu için FK sağlanır.
- `accept-invite` / `personel-hesap` akışları etkilenmez: onlar da `auth.users` kaydı oluşturduktan sonra `profiles` satırını yazar.

Migration **yetim satır varsa çalışmayı reddeder** (`RAISE EXCEPTION`) — otomatik veri silmez.

## 5. Uygulama öncesi zorunlu kontrol (yayılma riski)

FK zinciri devreye girdiğinde, `profiles(id)`'e bağlı **diğer** tabloların `ON DELETE` davranışı da çalışır. Bir tablo `CASCADE` ile bağlıysa, auth kullanıcısı silindiğinde o tablodaki kayıtlar da silinir. İSG kayıtları gibi yasal saklama yükümlülüğü olan veriler için bu kabul edilebilir olmayabilir.

Uygulamadan **önce** çalıştır:

```sql
SELECT c.conname,
       t2.relname AS bagli_tablo,
       a.attname  AS bagli_kolon,
       CASE c.confdeltype
         WHEN 'c' THEN 'CASCADE'  WHEN 'n' THEN 'SET NULL'
         WHEN 'r' THEN 'RESTRICT' WHEN 'a' THEN 'NO ACTION'
       END AS silme_davranisi
FROM pg_constraint c
JOIN pg_class t2      ON t2.oid = c.conrelid
JOIN pg_namespace n2  ON n2.oid = t2.relnamespace
JOIN pg_attribute a   ON a.attrelid = t2.oid AND a.attnum = ANY (c.conkey)
WHERE c.contype = 'f'
  AND c.confrelid = 'public.profiles'::regclass
ORDER BY t2.relname;

SELECT count(*) AS yetim
FROM public.profiles p
LEFT JOIN auth.users u ON u.id = p.id
WHERE u.id IS NULL;   -- 0 olmalı
```

`CASCADE` çıkan tablolar için karar: ya yasal saklama gereği `profiles` satırı silinmeden önce arşivlenecek, ya da o tabloların FK'si `RESTRICT` / `SET NULL`'a çekilecek. Bu karar **teknik değil, uyum kararıdır** — atlanmamalı.

## 6. Uygulama

```bash
cd /opt/ibys/supabase/docker
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 \
  -f /opt/ibys/supabase/migrations/20260101002300_guv32_profiles_auth_users_fk.sql
```

veya projedeki mevcut uygulama betiğiyle:

```bash
cd /opt/ibys && bash supabase/tests/security/pentest_gunu/07_guvenlik_migrationlarini_uygula.sh
```

## 7. Doğrulama

```sql
-- FK ve davranışı
SELECT conname, confdeltype
FROM pg_constraint
WHERE conrelid = 'public.profiles'::regclass AND contype = 'f';

-- Yetim sayısı
SELECT count(*)
FROM public.profiles p
LEFT JOIN auth.users u ON u.id = p.id
WHERE u.id IS NULL;
```

Beklenen: `profiles_id_auth_users_fkey | c` + iki `SET NULL` FK; yetim = 0.

Davranış testi (izole ortam veya geçici kullanıcı ile):

```
1) Admin API ile kullanıcı oluştur      → profiles satırı oluşur
2) Admin API ile kullanıcıyı sil        → HTTP 200
3) profiles WHERE id=<uid>              → 0   (GUV-32 öncesi 1 idi)
```

Regresyon kontrolü:

- Kayıt / davet kabul akışı ile yeni kullanıcı → `profiles` satırı oluşuyor mu?
- Panel → Ayarlar → Profil → ad-soyad güncelleme çalışıyor mu?
- Admin paneli kullanıcı silme akışı hata veriyor mu?
- Mesajlaşma heartbeat (`last_seen_at`) çalışıyor mu?

## 8. Rapora yapıştırılacak metin

> **GUV-32 — `profiles` ↔ `auth.users` referans bütünlüğü eksikliği (hesap silmede veri artığı)**
>
> Üretim veritabanında `public.profiles` üzerindeki tek foreign key'ler `firma_id` ve `osgb_id` için tanımlıdır (ikisi de `ON DELETE SET NULL`). `profiles.id → auth.users(id)` üzerinde foreign key **bulunmamaktadır**.
>
> Bu eksiklik canlı olarak doğrulandı: Admin API ile oluşturulan geçici kullanıcı (`role = pending`) `DELETE /auth/v1/admin/users/<uid>` ile silindiğinde yanıt `HTTP 200` döndü ve `auth.users` içinde satır kalmadı (`count = 0`); ancak `public.profiles` içindeki karşılık gelen satır silinmedi (`count = 1`) ve e-posta adresi veritabanında kaldı (`count = 1`). Kalan satır elle silinerek aynı id ve aynı e-posta için kayıt sayısı 0'a indirildi. Test sonrası yapılan taramada `toplam_profil = 15`, `yetim_profil = 0` ölçüldü.
>
> Etki: hesap silme taleplerinde kişisel verinin (e-posta, ad-soyad, avatar) süresiz kalması (KVKK/GDPR silme hakkı); `profiles` tablosuna join yapan listelerde auth karşılığı olmayan hayalet kayıtlar; `accept-invite`, `personel-hesap`, `osgb-davet` gibi e-posta üzerinden eşleştirme yapan Edge Function'larda eski `role` / `osgb_id` / `firma_id` bilgisinin yeni hesaba taşınması riski. Doğrudan bir yetki yükseltme vektörü tespit edilmemiştir; GUV-31 sonrası `anon` ve `authenticated` için `profiles` üzerinde tablo düzeyi INSERT yetkisi bulunmadığından istemci keyfî `id` ile satır oluşturamaz.
>
> Düzeltme: `profiles.id → auth.users(id) ON DELETE CASCADE` foreign key'i. İlgili migration yetim satır bulunması hâlinde çalışmayı reddeder (otomatik veri silmez). Uygulama öncesinde `profiles(id)`'e bağlı diğer tabloların `ON DELETE` davranışları envanterlenmeli; yasal saklama yükümlülüğü olan tablolar için `CASCADE` yerine alternatif davranış değerlendirilmelidir.
>
> **Durum: düzeltme hazır (migration + rollback + pgTAP testi), üretime uygulanmayı bekliyor.**