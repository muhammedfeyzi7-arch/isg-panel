# İSG-KATİP Özellik Yol Haritası

> Bu dosya, İSG-KATİP entegrasyonunun bundan sonraki gelişim planını tanımlar.
> Referans: piyasadaki "KATİP Otomasyonu" tipi ticari eklentilerin özellikleri.

## 0. KALICI KARAR KİLİDİ — READ-ONLY

İSGDenetim, İSG-KATİP üzerinde **işlem YAPMAZ**. Bu bir tercih değil, kalıcı tasarım kilididir:

- KATİP'e **yazma yok**: atama/onay/fesih/sözleşme güncelleme tetiklenmez.
- **İkinci authenticated istek atılmaz**; yalnızca KATİP SPA'nın KENDİ isteği salt-gözlemle (interception) okunur.
- **Tıklama/UI otomasyonu yok**; toplu indirme için KATİP ekranı sürülmez.
- Sadece: **oku → analiz et → raporla → kendi sistemimize (İSGDenetim) aktar.**

Gerekçe: (1) devlet sistemine otomatik yazma yasal/risk olarak ağır, (2) mevcut mimari güvenliği buna göre kurulmuş, (3) veri kalitesi ve denetlenebilirlik korunur.

## 1. Referans Eklenti vs İSGDenetim (gerçek fark)

| Referans eklenti özelliği | İSGDenetim kararı | Not |
|---|---|---|
| Otomatik sözleşme güncelleme (KATİP'te) | ❌ Yapılmaz | Yazma yok. Tespit + rapor yapılır. |
| Sözleşme analizi + Excel rapor | ✅ Yapılır (FAZ-K2) | Aktiflik/eşleşme/çalışan sayısı altyapısı hazır |
| Personel kalan-dakika takip | 🟡 Kısmen (FAZ-K4) | Mevzuat kuralları tanımlanmalı |
| Hızlı atama asistanı | 🟡 Plan tarafı (FAZ-K3) | KATİP'e atama YAZILMAZ |
| Çoklu atama | 🟡 Plan/rapor (FAZ-K3) | KATİP'te işlem yok |
| Çoklu hizmet/personel sözleşmesi PDF indirme | ❌ Toplu otomasyon yok | Yalnızca sayfa-içi (xhr/fetch) yakalanan belge tek tek indirilebilir |
| Alt taşeron sözleşmesi indirme | ❌ | İlişki verisi parse edilmiyor |
| Sabit tıbbi tetkik ataması | ❌ | KATİP'e yazma gerektirir |
| Akıllı arama + filtreleme | ✅ Yapılır (FAZ-K5) | Türkçe-duyarlı arama altyapısı var |

## 2. Faz Planı (sıralı)

### FAZ-K1 — Tek-işyeri aktarım hattını bitir + cilala  ← İLK ÖNCELİK
Mevcut zincir: işyeri seç → kontrol (dry run) → onay → atomik yazma → doğrulama.
Bu fazda **yeni motor kurulmaz**; mevcut hat tamamlanır ve temizlenir.

Aday iş kalemleri:
- Belge yakalama panelindeki **yanlış-alarm satırlarını gizle** ("Bilinmiyor" / yalnızca adres gözlemleri). Sadece içeriği gerçekten yakalanan belgeler gösterilir; panel etiketi netleştirilir.
- **Mevcut (zaten bağlı) firmaların KATİP bilgilerini güncelleme** akışını arayüze bağla (kodda hazır: backfill).
- Aktarım sonucu geri bildirimini netleştir (başarı/doğrulama/kısmi durumlar).
- Boş/hata/kenar durumları (KATİP sekmesi kapalı, veri eksik, kapsam yok) mesajlarını sadeleştir.

### FAZ-K2 — Sözleşme Analizi + Excel Rapor  ← TAMAMLANDI
- Mevcut kanonik aktiflik (aktif/sonlandırılmış/iptal/süresi dolmuş/belirsiz) + eşleşme verisinden rapor.
- Rapor içeriği: güncellenmesi gerekenler, süresi geçenler, çalışan sayısı 0'a düşen atamalar, eşleşme/çakışma özeti.
- Excel çıktısı mevcut excel motorlarıyla (yeni sistem kurulmaz).

**Uygulama notları (hayata geçen):**
- `src/lib/isgKatip/contractAnalysis.ts` — SAF analiz motoru. Kategoriler: `EXPIRED` (kanonik süresi dolmuş),
  `NEEDS_UPDATE` (yalnızca KATİP `sozlesmeMevzuataUygunMu` AÇIKÇA olumsuz), `ZERO_EMPLOYEE` (KATİP çalışan
  sayısı 0 + İSGDenetim'de bağlı işyeri). Mevzuat oranı/süresi İCAT EDİLMEZ; PII taşınmaz.
- `src/lib/isgKatip/contractAnalysisExcel.ts` — Mevcut KURUMSAL Excel motoru (`@/lib/excel/isgExcelCore`)
  üzerine TEK dosya / ÇOK sayfa: Özet + Süresi Geçenler + Güncellenmesi Gerekenler + Çalışan Sayısı 0.
- `src/components/feature/isgKatip/KatipSozlesmeAnalizSection.tsx` — OSGB → Ayarlar → İSG-KATİP Entegrasyonu
  altında analiz paneli + Excel indirme. KATİP Entegrasyon bölümüne bağlandı.
- Aktarım sonucu ekranına `AppliedBreakdownDetail` (KatipImportPanels) ile "işlenen kayıtların dökümü"
  (hangi işyeri / personel / yasal atama ve aksiyonu) daha görünür biçimde eklendi.

### FAZ-K3 — Atama Planlama Asistanı (KATİP'e yazmadan)  ← TAMAMLANDI
- Tehlike sınıfı (+ çalışan sayısı) → gereken dakika hesabı.
- Uygun personel önerisi + kalan süre görselleştirmesi + plan Excel raporu.
- **KATİP'e atama yapılmaz**; çıktı yalnızca plan/rapordur.

**Uygulama notları (hayata geçen):**
- `src/lib/isgKatip/planning.ts` — SAF planlama motoru (`buildKatipPlanning`) + personel yükü (`buildPersonnelLoad`).
  Gereksinim değerleri YALNIZCA `firma_gereksinimleri` sonucundan okunur; mevzuat oranı İCAT EDİLMEZ.
- `src/lib/isgKatip/planningService.ts` — SALT-OKUMA girdi servisi (firma + gereksinim + personel + atama).
- `src/lib/isgKatip/planningExcel.ts` — Kurumsal Excel motoru üzerine TEK dosya / ÇOK sayfa.
- `src/components/feature/isgKatip/KatipAtamaPlanlamaSection.tsx` — Atama Planı + Personel Yükü sekmeleri.

### FAZ-K4 — Personel kalan-dakika takip paneli  ← TAMAMLANDI (kısmi; kapasite tanımlı değil)
- Personelin atanan/toplam/kalan süresi görünümü.
- Mevzuat kuralı netleşmeden hiçbir oran/süre uydurulmaz.

**Uygulama notları:** K4, K3 ile aynı panelde "Personel Yükü" sekmesi olarak sunulur. Kapasite/kalan süre
hesabı için mevzuat katsayısı tanımlı OLMADIĞINDAN uydurulmaz; bunun yerine personel başına aktif firma
sayısı ve kapsanan aylık gereksinim süresi (gerçek veriden toplam) gösterilir.

### FAZ-K5 — Gelişmiş arama + filtre + çoklu seçim  ← TAMAMLANDI
- İşyeri listesinde Türkçe-duyarlı gelişmiş arama, filtreler, çoklu seçim.

**Uygulama notları:** `IsgKatipFirmaSec.tsx` içinde Türkçe-duyarlı arama (`trFold`), çoklu seçim
(checkbox + "Tümünü Seç") ve seçilenleri toplu aktarma (ilerleme çubuğu) mevcut çekirdek üzerinden çalışır.

## 3. Değişmeyen Kurallar
- READ-ONLY kilit (bkz. Bölüm 0).
- Yeni aktarım/eşleştirme/yazma motoru kurulmaz; mevcut `src/lib/isgKatip/*` yeniden kullanılır.
- Mevzuat oranı/süresi doğrulanmadan hardcode EDİLMEZ.
- PII (TC/ad-soyad/token/cookie) hiçbir yerde saklanmaz/gösterilmez.
- UI, mevcut SharedUICore motorlarını kullanır; yeni UI sistemi kurulmaz.

## 4. Durum Takibi
- [x] FAZ-K1 — Tek-işyeri aktarım hattı finalize
- [x] FAZ-K2 — Sözleşme analizi + Excel rapor
- [x] FAZ-K3 — Atama planlama asistanı
- [x] FAZ-K4 — Personel kalan-dakika paneli (kapasite tanımlı olmadığından yük görünümü)
- [x] FAZ-K5 — Gelişmiş arama/filtre/çoklu seçim

## 5. Excel Motoru Düzeltmesi (bugfix)
- **Sorun:** "Cannot merge already merged cells" — Özet sayfası 2 kolonken kurumsal başlık motorunun beyaz
  bilgi bloğu ile lacivert paneli aynı hücreyi birleştirmeye çalışıyordu.
- **Çözüm (kalıcı):** (1) `excelCell.mergePut` artık çakışan eski birleşimi önce çözer (kayıt defteri ile
  güvenli birleştirme), (2) `excelCompanyHeader` bilgi bloğunu panel ile çakıştığında atlar ve dar panelde
  etiket+değeri tek hücrede gösterir, (3) Sözleşme analizi Özet sayfası GENİŞ KPI şeridine çevrildi.

## 6. Firma Sözleşmesi Onay Akışı (yeni özellik)
- `firma_sozlesmeleri` tablosuna `onay_durumu`, `onaylayan_id`, `onaylayan_ad`, `onay_tarihi`, `onay_notu`
  kolonları eklendi (varsayılan: `beklemede`).
- `firma-sozlesme` Edge Function: onay/red işlemi; onaylayan kimliği ve onay tarihi SUNUCU tarafında atanır
  (onaylama yalnızca admin/osgb_admin).
- Firma Detay → Sözleşmeler kartında onay durumu rozeti + Onayla/Reddet aksiyonları + onaylayan/onay tarihi.

## 7. Çalışan Sayısı Kaynak Ayrımı (mimari kararı)
İki kavram KESİN olarak ayrılmıştır:

- **Firma (merkezi) çalışan sayısı** = `firmalar.calisan_sayisi`. Kaynağı yalnızca MANUEL firma
  oluşturma/düzenlemedir. İSG-KATİP bu alanı **ASLA değiştirmez**.
- **İSG-KATİP çalışan sayısı** = `firmalar.isg_katip_calisan_sayisi` (ayrı/güvenilir alan;
  `hizmetAlanIsyeriCalisanSayisi`). KATİP aktarımı buraya yazar.
- **İSG gereksinim çalışan sayısı** = merkezi resolver (`firma_calisan_sayisi` RPC, sunucu):
  firma İSG-KATİP ile eşleşmiş (`isg_katip_id` dolu) VE geçerli KATİP değeri (>0) varsa KATİP değeri;
  aksi halde `firmalar.calisan_sayisi`. Client aynası: `resolveISGRequirementEmployeeCount()`.

Gereksinim/yükümlülük motorları (`gereksinim-hesapla`, `firma-yukumluluk`) bu resolver'ı kullanır; firma
listeleme/detay/gösterim daima merkezi alanı kullanır. KATİP çalışan sayısı değiştiğinde merkezi alan
değişmez, yalnızca İSG gereksinimleri yeniden hesaplanır (`isg_girdi_degisti` bayrağı ile).