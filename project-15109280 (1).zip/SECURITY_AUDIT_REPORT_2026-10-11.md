# İSGDenetim / OSGB SaaS — Bağımsız Güvenlik Denetimi Raporu

> **Tarih:** 2026-10-11 · **Kapsam:** React/Vite SPA · Supabase Auth · PostgreSQL (RLS/RPC)
> · Edge Functions · Storage · Roller.
>
> **TUR SINIRI (uyum):** Bu denetimde **hiçbir kod dosyası, migration, RLS politikası,
> Edge Function veya secret DEĞİŞTİRİLMEDİ/DEPLOY EDİLMEDİ.** Veritabanına yalnızca
> **salt-okuma `SELECT`** (sistem katalogları + `pg_policies` + `information_schema`) ile
> bakıldı. Gerçek kullanıcı/tenant verisi okunmadı, kopyalanmadı, değiştirilmedi.
>
> **Yöntem:** (a) kaynak kod okuma (`src/**`, `supabase/functions/**`, `supabase/migrations/**`),
> (b) canlı şema/RLS/grant katalog sorguları, (c) statik `grep` taraması, (d) mevcut güvenlik
> dokümanları (SECURITY_* serisi) ile çapraz kontrol.
>
> **Dürüstlük notu:** Bu denetim, **resmî TSE onaylı bir sızma testi DEĞİLDİR.** İzole
> iki-tenant test ortamı olmadığı için **hiçbir RLS/tenant davranışı runtime çalıştırılarak
> kanıtlanmadı**; politika davranışı **canlı metadata + statik muhakeme** ile değerlendirildi.
> Doğrulanamayan alanlar açıkça **"Doğrulanamadı / BLOCKED"** olarak işaretlendi.

---

## 0) YÖNETİCİ ÖZETİ

| Alan | Durum | Kanıt türü |
|---|---|---|
| RLS kapsamı | ✅ **176/176 tabloda RLS aktif (kapalı tablo 0)** | canlı katalog |
| RESTRICTIVE tenant guard | ✅ 9 politika (atamalar/evraklar/firmalar/personeller/teklifler/teklif_hizmetleri) | canlı katalog |
| Storage tenant izolasyonu | ✅ `storage_tenant_ok` canlıda var (GUV-01 uygulanmış) | canlı katalog |
| SECURITY DEFINER `search_path` | ✅ Sabitlenmemiş definer **0** (GUV-14/15 uygulanmış) | canlı katalog |
| anon definer RPC kısıtı | ✅ anon-çağrılabilir definer **22 yardımcı/public akış** (159→22) | canlı katalog |
| Kayıt akışı rol yükseltmesi | ✅ Metadata'dan rol okuma yok; yeni kayıt `pending` (GUV-02/16 uygulanmış) | migration + kod |
| Edge Function CORS | ⚠️ **43 dosyada `Access-Control-Allow-Origin: *`** | statik `grep` |
| anon tablo yetkileri | ⚠️ **176/176 tabloda anon'a geniş tablo GRANT'ı** → RLS tek kapı | canlı katalog |
| CSP | ⚠️ `script-src 'unsafe-inline' 'unsafe-eval'`; `frame-ancestors` meta ile yok | `index.html` |
| Auth Dashboard / JWT config | ⛔ **Doğrulanamadı** (erişim yok) | — |
| Runtime tenant testleri | ⛔ **BLOCKED** (izole ortam yok) | — |

**Genel değerlendirme:** Sistem, önceki fazlarda uygulanan 10+ güvenlik migration'ı ile
**veri katmanında olgun ve kapalı** görünüyor (RLS %100, tenant guard'lar, storage izolasyonu,
search_path, anon RPC daraltması canlıda doğrulandı). Kalan maddeler ağırlıklı olarak
**sertleştirme/savunma derinliği** ve **doğrulanamayan (Dashboard/hosting) alanlar**dır.
**Kesin (exploitable) bir açık bu turda DOĞRULANMADI.**

---

## 1) MİMARİ ENVANTERİ

### 1.1 Roller
`src/components/feature/ProtectedLayout.tsx` (satır ~11-18) ve `accept-invite/index.ts`'ten
doğrulanan roller:

| Rol | Panel kökü | Kapsam |
|---|---|---|
| `admin` | `/` + `/osgb-panel` | Platform yöneticisi (tüm tenant) |
| `osgb_admin` | `/osgb-panel` | Kendi OSGB'si |
| `firma` | `/firma` | Kendi firması (`firma_id` + `osgb_id`) |
| `uzman` | `/uzman` | Aktif atama kapsamı |
| `hekim` | `/hekim` | Aktif atama kapsamı |
| `pending` | — | Kayıt olmuş ama yetki verilmemiş (GUV-02) |

Yetki, istemcide değil **sunucuda** türetilir: `ProtectedLayout` render'ı, `osgb-status`,
`maintenance`, `personel durumu` ve rol-yol eşleşmesini **fail-closed** uygular
(`ProtectedLayout.tsx` ~satır 220-320). Bu iyi bir tasarım.

### 1.2 Veritabanı
- Canlı: **176 public tablo**, tamamında **RLS aktif**, **563 politika** (9 RESTRICTIVE).
- Kritik tablolar (canlı): `profiles, osgb, firmalar, personeller, atamalar, atama_belgeleri,
  teklifler, teklif_hizmetleri, evraklar, ekipmanlar, envanter, zimmetler, davetler,
  system_logs, system_settings, support_tickets, support_messages, nace_kodlari,
  ibys_* (4 tablo)` ve ~160 diğer modül tablosu.

### 1.3 Edge Functions (52 kayıtlı)
Dosya: `supabase/functions/<slug>/index.ts`. Envanteri (künye) `accept-invite`,
`firma-davet`, `osgb-davet`, `personel-hesap`, `send-reset-email`, `auth-log`,
`osgb-status`, `tutanak`, `mail`, `ekipman`, `envanter`, `zimmet`, `mesajlasma`,
`isg-katip-sync`, `ibys-gonderim`, `saha-denetim*`, `teklif-*`, `osgb-delete-permanent` vb.

**Ortak desen (kod ile doğrulandı):**
- Her fonksiyon çağıranın JWT'sini `auth.getUser(jwt)` ile **ANON istemci** üzerinden
  doğrular (örn. `firma-davet/index.ts` ~satır 240-246); privileged DB işlemi ayrı
  **service-role** istemci ile yapılır. Bu, doğru ve güvenli ayrımdır.
- `accept-invite`, `send-reset-email` gibi token/talep akışları JWT yerine **tek-kullanımlık
  davet token'ı** ile korunur (tasarım gereği).

### 1.4 Storage
Canlı: **16 bucket**, yalnız **2 tanesi `public=true`** (`avatars`, `osgb-logos`).
Diğer 14 bucket **private**; erişim **RLS ile** (tek kapı). GUV-01 ile
`atama-belgeleri / personel-foto / hazop-kanitlari / noter-defteri` politikaları
`{authenticated}` + `storage_tenant_ok(...)` kapsamına alınmış (canlı doğrulandı).

### 1.5 RPC / Yardımcı Fonksiyonlar
- anon'un EXECUTE edebildiği definer fonksiyon: **77**; bunlardan **trigger olmayan
  (gerçekten çağrılabilir): 22**. Liste: `auth_firma_id, auth_osgb_id, auth_personel_bilgi,
  auth_personel_id, can_access_announcement(_path), can_access_ticket, create_support_ticket,
  has_active_* , is_icon_admin, is_maintenance_active, mesajlasma_is_participant,
  operasyon_entity_accessible, osgb_access_ok, osgb_erisim_acik, request_context,
  teklif_public_get/view/action`. Bunlar **kasıtlı** RLS yardımcıları + meşru public akış.

---

## 2) CANLI DOĞRULANAN GÜVENLİK KONTROLLERİ (PASS · kanıtlı)

| # | Kontrol | Canlı sonuç | Değerlendirme |
|---|---|---|---|
| 2.1 | RLS kapsamı | `toplam_tablo=176, rls_acik=176, rls_kapali=0` | ✅ Tüm tablolar RLS korumalı |
| 2.2 | RESTRICTIVE tenant guard | `restrictive=9` — `atamalar_osgb_access_guard`, `evraklar_osgb_access_guard`, `firmalar_osgb_access_guard`, `personeller_osgb_access_guard`, `teklifler_tenant_restrictive`, `teklif_hizmetleri_tenant_restrictive`, + `evraklar_client_write_deny_*` (3) | ✅ AND-kapı; permissive politika genişlese bile cross-tenant engellenir |
| 2.3 | Storage tenant izolasyonu | `storage_tenant_ok` **mevcut** | ✅ GUV-01 uygulanmış |
| 2.4 | Definer `search_path` | `search_path_sabitlenmemis=0` | ✅ GUV-14/15 uygulanmış (hijacking kapalı) |
| 2.5 | anon definer RPC | `definer_toplam=167`, anon-çağrılabilir **77** / non-trigger **22** | ✅ GUV-11/13/13b uygulanmış (159→22) |
| 2.6 | Rol yükseltme (kayıt) | `handle_new_user` metadata rol okumuyor; yeni kayıt `pending` (GUV-02/16) | ✅ |
| 2.7 | İstemci secret sızıntısı | `src/lib/supabase.ts` yalnız **anon** public key kullanır; service-role istemcide yok | ✅ |
| 2.8 | Hata mesajı sızıntısı | `src/lib/errorMessages.ts` ham Postgres/PostgREST metnini kullanıcıya sızdırmaz (merkezi çeviri) | ✅ iyi uygulama |
| 2.9 | Public teklif akışı | `teklif_public_*` RPC'leri token tabanlı, sunucu doğrulamalı (`teklif-public/page.tsx`) | ✅ tasarım |

---

## 3) BULGULAR (kanıt + değerlendirme)

> Aşağıda **kesin açık** olarak yalnızca canlı/kod kanıtıyla doğrulananlar verilir; geri
> kalanlar **risk / doğrulanmalı** olarak işaretlenmiştir. Kesin exploit doğrulanmadı.

### F-01 · anon rolüne geniş tablo yetkisi (Savunma Derinliği · ORTA)
- **Kanıt (canlı):** `anon` rolü, **176/176 public tabloda** `SELECT, INSERT, UPDATE, DELETE,
  REFERENCES, TRIGGER, TRUNCATE` yetkilerine sahip (`information_schema.role_table_grants`).
- **Anlam:** Veri güvenliği **tek başına RLS'e** bağlıdır. RLS kapalı bir tablo **yok**
  (F-01'i düşürür), ancak gelecekte yanlış yazılmış bir permissive politika doğrudan
  anon erişimine dönüşür.
- **Öneri:** `REVOKE` ile anon'un gereksiz tablo yetkileri daraltılabilir veya politikalar
  `TO authenticated` ile kapsamlandırılabilir (bkz F-02). **Kesin exploit yok.**

### F-02 · Politikaların %81'i `TO public` rolünde (Savunma Derinliği · ORTA)
- **Kanıt (canlı):** `public_rol_politika=456 / 563`. Örnek hassas tablolar:
  `profiles_select_own` (qual `id=auth.uid() OR admin`), `system_logs_select`
  (qual `auth_role()='admin'`), `davetler_*_admin`, `system_settings_*`.
- **Değerlendirme:** Bu politikaların **koşulları auth bağımlı** olduğundan anon
  (`auth.uid()=NULL`, `auth_role()=NULL`) için **false → DENY** üretir. Sistematik tarama
  (`qual/with_check` auth bağımsız politikalar) yalnızca **referans tablolarını** işaretledi
  (bkz F-03) + `false`/`osgb_access_ok()` guard politikalarını. **Aktif anon sızması bulunamadı.**
- **Öneri:** Yeni politikalar `TO authenticated` tercih edilmeli; `TO public` yalnız
  gerçekten anonim erişilmesi gereken yerlerde (public teklif vb.) kullanılmalı.

### F-03 · Referans/arama tabloları anon'a açık (BİLGİ · DÜŞÜK)
- **Kanıt (canlı):** `qual='true'` + `roles={public}` + anon SELECT grant'ı olan tablolar:
  `occupations`, `occupation_nace_map`, `myk_qualifications`, `myk_document_requirements`,
  `requirement_rules`, `requirement_document_equivalents`, `diploma_equivalences`,
  `mastership_equivalences`.
- **Değerlendirme:** Bunlar **global referans/katalog** verileridir (MYK meslekleri, NACE
  eşlemeleri, gereksinim kuralları) — tenant/PII içermez. **Muhtemelen kasıtlıdır.**
- **Öneri:** Niyet doğrulanmalı; istenmiyorsa `TO authenticated`'e alınmalı. **Kesin açık değil.**

### F-04 · Edge Functions CORS wildcard (`*`) (ORTA · bilinen GUV-04)
- **Kanıt (statik):** 43 fonksiyon dosyasında `const CORS = { 'Access-Control-Allow-Origin': '*' }`.
  Örnekler: `supabase/functions/accept-invite/index.ts` (satır ~3-7),
  `firma-davet/index.ts` (~3-7), `osgb-davet/index.ts` (~3-7),
  `personel-hesap/index.ts` (~3-7), `send-reset-email/index.ts` (~3-7),
  `auth-log/index.ts` (~3-7).
- **Etki:** Herhangi bir origin, kullanıcı tarayıcısından bu API'leri çağırabilir. Ancak
  **kimlik doğrulama JWT/tek-kullanımlık token ile sunucuda yapıldığından** çerez/oturum
  tabanlı CSRF benzeri sömürü doğrudan mümkün değildir (Bearer token elle eklenir).
- **Durum:** Çözüm (origin allowlist modülü) hazır ancak uygulanmadı
  (`SECURITY_FINAL_REMEDIATION_REPORT.md §5.1`). **Doğrulanmış exploit yok.**

### F-05 · `auth-log` uç noktası anonim log yazımı (DÜŞÜK)
- **Kanıt (kod):** `supabase/functions/auth-log/index.ts` — `AUTH_LOGIN_FAILED` + e-posta ile
  JWT olmadan çağrılabilir; `profiles` e-posta eşleşmesi (`ilike email`) ile `role/osgb_id`
  çözülür ve `system_logs`'a yazılır.
- **Etki:** Yetkisiz bir kişi **sahte başarısız-giriş log kaydı** üretebilir (log kirliliği).
  **Veri sızması/dosya erişimi yok.** İzin verilen olay türleri beyaz listeye alınmış
  (`ALLOWED_EVENTS`).
- **Öneri:** Bu uç, login ekranından anonim çağrılır; oran sınırı (rate-limit) düşünülebilir.

### F-06 · `send-reset-email` servis-rol kullanımı (İYİ TASARIM · bilgi)
- **Kanıt (kod):** `send-reset-email/index.ts` her durumda `{ ok: true }` döner (kullanıcı
  enumerasyonunu engeller); `admin.generateLink({type:'recovery'})` ile bağlantı üretir.
- **Değerlendirme:** Kullanıcı varlığını sızdırmaması **doğru** bir güvenlik tercihidir.

### F-07 · IBYS global referans satırları çok-tenantlı YAZILABİLİR (DOĞRULANMALI · ORTA)
- **Kanıt (canlı):** `ibys_referans_eslesmeleri` politikaları
  `auth_role()='osgb_admin' AND (osgb_id IS NULL OR osgb_id = auth_osgb_id())` (INSERT/SELECT/UPDATE).
- **Değerlendirme:** `osgb_id IS NULL` olan **global** referans eşleşmeleri **herhangi bir
  OSGB yöneticisi tarafından** değiştirilebilir. Bu, başka OSGB'leri etkileyebilecek
  **paylaşımlı yazma** anlamına gelebilir (yasak değil, tasarım kararı olabilir).
- **Öneri:** Global (`osgb_id IS NULL`) satırların yazımı yalnız `admin`'e kısıtlanmalı mı? — **Niyet doğrulanmalı.**

### F-08 · CSP zayıflıkları (index.html)
- **Kanıt:** `index.html` satır ~18-21: `script-src 'self' 'unsafe-inline' 'unsafe-eval' ...`;
  `frame-ancestors` **yok** (meta ile de verilemez).
- **Etki:** `'unsafe-inline'/'unsafe-eval'` XSS savunmasını zayıflatır (bazı kütüphanelerin
  gereksinimi olabilir). `frame-ancestors` yokluğu → **clickjacking** yalnız HTTP başlığıyla
  engellenebilir (hosting katmanı; GUV-10). `index.html` içinde `referrer` meta mevcut ✅.
- **Öneri:** `'unsafe-eval'` kaldırılabilir mi araştırın; HSTS/nosniff/frame-ancestors'ı
  hosting katmanında ekleyin.

### F-09 · Operasyonel sertleştirme durumu (DOĞRULANAMADI)
- **Kanıt:** Depo kökünde `supabase/config.toml` yok; `verify_jwt` deseni kodda yok
  (platform/Dashboard yönetiminde). Bu ortamdan **okunamadı.**
- **Açık sorular:** Tüm Edge Function'larda JWT zorunlu mu? Auth self-signup kapalı mı?
  Parola politikası / rate-limit? Bunlar **Dashboard'dan doğrulanmalıdır.**

---

## 4) İNCELENEMEYEN / DOĞRULANAMAYAN ALANLAR (dürüst liste)

| Alan | Neden | Durum |
|---|---|---|
| Supabase Auth Dashboard (self-signup, parola politikası, rate-limit, e-posta doğrulama) | Panel erişimi yok | ⛔ Doğrulanamadı |
| Edge Function başına `verify_jwt` konfigürasyonu | `config.toml` yok / platform yönetimli | ⛔ Doğrulanamadı |
| **Runtime** RLS/tenant davranışı (iki-OSGB A/B, storage list/signedUrl/insert/delete) | İzole test ortamı yok; canlıya yazmak yasak | ⛔ BLOCKED |
| `.env` git geçmişi (sır sızıntısı / rotate ihtiyacı) | Git geçmişi bu ortamdan okunamadı | ⛔ BLOCKED |
| `npm audit` / bağımlılık zafiyet taraması | Komut yürütücü yok | ⛔ BLOCKED |
| 563 politikanın **satır satır** okunması | Kapsam; bu tur agrega + hedefli desen taraması yapıldı | ⚠️ Kısmi |
| Service-role kısayolu / `service_role` grant tutarlılığı (GUV-11 sonrası edge RPC) | Runtime test gerektirir | ⛔ BLOCKED |
| Üçüncü taraf (Resend, Shopify, Stripe) gizli anahtar yönetimi | Bu turda kapsam dışı | ➖ Kapsam dışı |

---

## 5) ÖNERİLEN AKSİYONLAR (öncelik sırasıyla — bu turda UYGULANMADI)

1. **Auth Dashboard doğrulaması:** self-signup KAPALI, e-posta doğrulama, parola politikası,
   rate-limit — görsel/ekran kanıtıyla teyit (F-09, §4).
2. **anon tablo GRANT'larını daralt** (F-01) ve yeni politikaları `TO authenticated` yaz (F-02).
3. **Edge CORS allowlist** (F-04): `ALLOWED_ORIGINS` secret + `_shared/cors.ts` modülü, her
   fonksiyon **tek tek deploy + preflight testi** ile (çalışan akışları bozmadan).
4. **CSP sertleştirme + hosting başlıkları** (F-08/GUV-10): `unsafe-eval` kaldırma araştırması,
   HSTS/nosniff/frame-ancestors başlıkları.
5. **IBYS global referans yazımı** niyetini netleştir; gerekirse `admin`-only yap (F-07).
6. **`auth-log`** için basit oran sınırı (F-05).
7. **İzole test ortamı** kurup `supabase/tests/security/*` suite'ini gerçek DB'de çalıştır
   (§4'teki tüm BLOCKED maddeleri kapatır).

---

## 6) KAYNAK / KANIT DİZİNİ

- **Migration'lar:** `supabase/migrations/20260101000{1..9}00_guv*.sql`,
  `20260101001000_guv16_*.sql` (+ `rollback/`).
- **RLS/tenant guard:** yukarıdaki migration'lar + canlı `pg_policies` gözlemi (9 RESTRICTIVE).
- **Edge güvenlik deseni:** `supabase/functions/{accept-invite,firma-davet,osgb-davet,
  personel-hesap,auth-log,send-reset-email}/index.ts`.
- **İstemci auth:** `src/context/AuthContext.tsx` (oturum, `changePassword` mevcut-şifre
  doğrulamalı), `src/lib/supabase.ts` (singleton, anon key), `src/lib/errorMessages.ts`.
- **Rota koruması:** `src/components/feature/ProtectedLayout.tsx`,
  `src/router/config.tsx`.
- **CSP:** `index.html`.
- **Public akışlar:** `src/pages/teklif-public/page.tsx`, `src/pages/ekipman-qr/page.tsx`.
- **Önceki güvenlik dokümanları:** `SECURITY_DAY_SUMMARY_2026-10-09.md` (güncel durum),
  `SECURITY_FINAL_REMEDIATION_REPORT.md`, `SECURITY_MIGRATION_DEPENDENCIES.md`,
  `SECURITY_RUNTIME_VALIDATION_PHASE9.md`, `SECURITY_PHASE10_TEST_ENV_CHECKLIST.md`,
  `QA_FULL_MODULE_REPORT.md`.

> **Sonuç:** Bu denetimde **kod/DB değiştirilmedi.** Kesin (exploitable) bir açık
> **doğrulanmadı**; tespitler ağırlıklı olarak **savunma derinliği sertleştirmeleri** ve
> **runtime/Dashboard doğrulaması gerektiren** alanlardır. Bu rapor **resmî TSE onaylı sızma
> testinin yerine geçmez.**