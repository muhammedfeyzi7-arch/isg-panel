# PROMPT 1 — Kapsamlı Güvenlik Denetimi (Sızma Testi Hazırlık Raporu)

> **Sistem:** İSGDenetim / OSGB SaaS — React + Vite SPA · Supabase Auth · PostgreSQL + RLS · RPC · Edge Functions · Supabase Storage
> **Tarih:** 2026-10-11
> **Rol:** Kıdemli siber güvenlik uzmanı (bağımsız gözden geçirme)
> **Kural:** ⛔ Bu aşamada **hiçbir kod, veritabanı, politika veya yapılandırma DEĞİŞTİRİLMEDİ.** Yalnızca inceleme + canlıdan **salt-okuma** metadata kanıtı.
> **Veri güvenliği:** Gerçek müşteri verisi, TC kimlik, sağlık kaydı veya gizli anahtar **kopyalanmadı**; yalnızca şema/politika/fonksiyon metadata'sı ve sayımlar.

---

## 0. YÖNETİCİ ÖZETİ (Executive Summary)

Sistem güvenlik olgunluğu **yüksek**. Önceki denetim turlarında tespit edilen sertleştirmeler **büyük ölçüde üretime uygulanmış durumda** ve bu turda canlıdan yeniden doğrulandı:

| Doğrulanan kontrol | Canlı sonuç |
|---|---|
| RLS etkin tablo | **176 / 176** (kapalı tek tablo yok) |
| RESTRICTIVE tenant guard | **9** guard (atamalar/evraklar/firmalar/personeller + teklifler/teklif_hizmetleri) |
| SECURITY DEFINER fonksiyon sayısı | **167** — **tamamında `search_path` ayarlı** (0 eksik) |
| anon'un çağırabildiği non-trigger definer RPC | **22** — hepsi bilinçli korunan RLS yardımcısı + public teklif/destek akışı |
| Sağlık verisi (muayene/tetkik) | `firma` ve `uzman` SELECT politikaları **= `false`** (erişim yok); yalnız hekim/OSGB/admin |
| Rol/kimlik yükseltme | `profile_lock_role` trigger'ı aktif (ROLE_LOCK/OSGB_LOCK/FIRMA_LOCK) |
| İstemci sır sızıntısı | `.env` yalnız **public publishable anon key**; `src` altında `service_role` **yok** |

**En önemli teknik açık:** **F-01 · Kimliği doğrulanmış SSRF** — `mail` Edge Function'ında `smtpHost`/`smtpPort` doğrudan kullanıcı girdisinden alınıp `Deno.connect`/`Deno.connectTls` ile **allowlist/özel-IP (SSRF) filtresi olmadan** bağlantı açılması. Yetkili bir oturum, sunucuyu iç ağ / cloud metadata uç noktalarına bağlamaya zorlayabilir. **YÜKSEK.**

Diğer gerçek bulgular çoğunlukla **savunma derinliği** (defense-in-depth) ve **yapılandırma** seviyesindedir (geniş tablo GRANT'ları, CORS `*`, CSP `unsafe-*`, bağımlılık CVE'leri). **Uzaktan-kimliksiz, doğrudan sömürülebilir Kritik açık tespit edilmedi.**

**Dürüst sınırlar:** İzole iki-tenant test ortamı olmadığından **aktif (runtime) IDOR/tenant testi YAPILAMADI**; `npm audit`/Git geçmişi/Auth Dashboard ayarları bu ortamdan **doğrulanamadı**. Test edilmeyen kontroller raporda **"Doğrulanamadı"** olarak işaretlendi — başarı sayılmadı.

---

## 1. MİMARİ VE KİMLİK DOĞRULAMA AKIŞLARI

### 1.1 Bileşen envanteri (kod kanıtı)
- **İstemci:** React 19 + Vite SPA (`src/`), tek Supabase singleton istemci (`src/lib/supabase.ts`), `react-router-dom` ile korumalı rotalar (`src/router/config.tsx`, `ProtectedLayout`).
- **Auth:** Supabase Auth (`src/context/AuthContext.tsx`): `signInWithPassword`, oturum kalıcılığı, "Beni hatırla" oturum işareti (sessionStorage), `onAuthStateChange` senkron-safe, `withTimeout` ile bootstrap kilidi koruma.
- **Veri:** PostgreSQL + RLS; iş mantığının bir kısmı **RPC** (167 definer fonksiyon) ve **47 Edge Function** üzerinde.
- **Depolama:** Supabase Storage — 16 bucket.

### 1.2 İstemci/sunucu kontrol ayrımı
- **Sunucu tarafı (güvenilen):** RLS politikaları, SECURITY DEFINER RPC'ler, Edge Functions'ta `auth.getUser(jwt)` + `profiles`'tan rol/tenant türetme.
- **İstemci tarafı (güvenilmeyen):** Sadece UX/ön kontrol (ör. `firmaDetayPermissions`). **Kritik yetkiler sunucuda yeniden doğrulanıyor** (aşağıda kanıtlı).

---

## 2. VERİTABANI VE RLS — BULGULAR

### ✅ Doğrulanan güçlü kontroller
- **176/176 tabloda RLS açık** (`relrowsecurity=true`).
- Politika dağılımı: **456 → `public`**, **106 → `authenticated`**, **1 → `postgres`** (toplam 563 politika).
- **9 RESTRICTIVE guard:** `atamalar_osgb_access_guard`, `evraklar_osgb_access_guard`, `firmalar_osgb_access_guard`, `personeller_osgb_access_guard`, `teklifler_tenant_restrictive`, `teklif_hizmetleri_tenant_restrictive`, `evraklar_client_write_deny_{insert,update,delete}`.
- **`osgb_access_ok()` sertleştirilmiş sürüm canlıda:** eski tehlikeli `auth_osgb_id() IS NULL → TRUE` dalı **yok**; yalnız admin VEYA aktif/kapsam-penceresi-içindeki geçerli OSGB.
- **Tenant kimliği istemciden güvenilmiyor:** politikalar `auth_uid → profiles → osgb_id/firma_id` zincirini kullanır.

### ✅ Sağlık verisi kilidi (KVKK açısından güçlü)
- `personel_saglik_muayeneleri` → `personel_saglik_select_firma.qual = false`, `personel_saglik_select_uzman.qual = false`.
- Yalnız: `hekim` (aktif firma ataması + `personel_firma_id`) · `osgb_admin` (kendi OSGB) · admin.
- `personel_tetkikler` → aynı desen; hekim/admin/osgb dışına kapalı.

---

### 🔴 F-01 — Kimliği doğrulanmış SSRF (mail Edge Function) · **[YÜKSEK]**
- **Etkilenen bileşen:** `supabase/functions/mail/index.ts` → `handleSaveSmtp`, `openSmtpConnection`, `sendSmtpMail`, `verifySmtp`, `resolveSmtpConfig`.
- **Teknik kanıt (kod):**
  - `const smtpHost = String(body.smtpHost ?? '').trim(); const smtpPort = Number(body.smtpPort);` (kullanıcı gövdesinden)
  - `conn.smtp_host` / `conn.smtp_port` DB'ye yazılıp sonra `resolveSmtpConfig()` ile geri okunuyor.
  - `openSmtpConnection` → `Deno.connect({ hostname: cfg.host, port: cfg.port })` / `Deno.connectTls(...)`.
  - **Allowlist yok, RFC1918/link-local/loopback/metadata (169.254.169.254) blokajı yok, port kısıtı yok** (yalnız `1..65535` aralık kontrolü).
- **Yetki kapısı:** `ALLOWED_ROLES = ['admin','osgb_admin','uzman','hekim']` + geçerli JWT. Yani **herhangi yetkili panel kullanıcısı**, "SMTP" sağlayıcı kaydı ile sunucuya iç ağa bağlantı açma denemesi yaptırabilir (TCP/TLS connect + kısmi SMTP banner yanıtı ile iç servis varlığı keşfi).
- **Olası etki:** İç ağ keşfi (port/ servis parmak izi), cloud metadata uç noktalarına erişim denemesi, bulut ortamında kimlik bilgisi sızdırma zincirinin ilk halkası. Kimliksiz değildir ancak savunmasızdır.
- **Doğrulama durumu:** **DOĞRULANDI (kod kanıtı).** Runtime exploit izole ortam olmadığından denenmedi.
- **Önerilen düzeltme:**
  1. `smtpHost` bir **allowlist**'e (ör. bilinen sağlayıcı alan adları) veya en azından **DNS çözümlemesi sonrası IP bloklama** (RFC1918 · loopback · link-local 169.254/16 · CGNAT 100.64/10 · unique-local IPv6) ile sınırlandırılmalı.
  2. Yalnız izinli portlar (25/465/587 veya allowlist).
  3. "İşaretle & tıkla (click)"-sonrası yeniden çözümleme (DNS rebinding koruması).
- **Sonraki aşama testi:** İzole ortamda: (a) `smtpHost=127.0.0.1`, (b) `smtpHost=169.254.169.254`, (c) `smtpHost=<iç-servis-ip>` ile `save-smtp` → **400/403 dönmeli**, bağlantı **kurulmamalı**.

---

### 🟠 F-02 — `anon`/`authenticated` rolüne 176 tabloda geniş tablo-seviyesi GRANT · **[ORTA · Savunma Derinliği]**
- **Etkilenen:** tüm `public` tabloları (tablo-seviyesi yetkiler).
- **Teknik kanıt (canlı):** `anon` ve `authenticated`, **176 tablonun her birinde** `SELECT, INSERT, UPDATE, DELETE, TRUNCATE, REFERENCES, TRIGGER` yetkisine sahip.
- **Olası etki:** Güvenlik **tek kapıya (RLS)** bağlı. `TRUNCATE` RLS tarafından engellenmez (ancak PostgREST/RLS yoluyla erişilemez — sömürü için doğrudan DB bağlantısı gerekir). Bir RLS politikası hatalıysa, geniş GRANT çarpanı büyütür.
- **Doğrulama durumu:** **DOĞRULANDI (metadata).** Doğrudan sömürü **doğrulanmadı** (RLS açık).
- **Önerilen düzeltme:** Kullanılmayan `TRUNCATE`/`REFERENCES`/`TRIGGER` yetkilerini `anon` ve `authenticated`'tan `REVOKE`; gereksiz tablolarda `INSERT/UPDATE/DELETE` yetkilerini rol bazında daralt (least privilege).
- **Sonraki aşama testi:** İzole ortamda `revoke` sonrası panel akışlarının bozulmadığının regresyonu.

---

### 🟠 F-03 — `profiles_update_own` politikasında `WITH CHECK` yok · **[ORTA]**
- **Etkilenen:** `public.profiles` → `profiles_update_own`.
- **Teknik kanıt (canlı):** `qual = (id = auth.uid())`, **`with_check = null`**.
- **Telafi edici kontrol (doğrulandı):** `profile_lock_role` trigger'ı — `role`/`osgb_id`/`firma_id` değişimini `ROLE_LOCK`/`OSGB_LOCK`/`FIRMA_LOCK` (ERRCODE 23514) ile bloklar; service_role ve FK `ON DELETE SET NULL` iç güncellemelerinde (trigger_depth > 1) devre dışıdır.
- **Olası etki:** Politika tek başına yetersiz; koruma tamamen trigger'a bağlı. Trigger'ın kaldırılması/yeniden oluşturulmaması hâlinde **dikey + yatay yetki yükseltme** açığa çıkar.
- **Doğrulama durumu:** **DOĞRULANDI (metadata).** Yükseltme **bloklu** (trigger). Exploit **başarısız**.
- **Önerilen düzeltme:** Politikaya `WITH CHECK (id = auth.uid() AND role = (SELECT role FROM profiles WHERE id = auth.uid()) AND osgb_id IS NOT DISTINCT FROM ... AND firma_id IS NOT DISTINCT FROM ...)` ekleyerek **çift katmanlı** koruma.
- **Sonraki aşama testi:** İzole ortamda kendi satırında `role='admin'` güncelleme denemesi → **hata** (hem trigger hem politika).

---

### 🟡 F-04 — Politikaların büyük çoğunluğu `TO public` (anon'u kapsar) · **[DÜŞÜK-ORTA · Savunma Derinliği]**
- **Teknik kanıt (canlı):** 563 politikanın **456'sı `{public}`**, 106'sı `{authenticated}`, 1'i `{postgres}`.
- **Olası etki:** `public` = `anon` dahil tüm roller. Politikaların çoğu `auth.uid()`/`auth_role()` tabanlı olduğundan anon'da güvenli şekilde `false/0 satır` döner; ancak kapsam geniştir.
- **Doğrulama durumu:** **DOĞRULANDI (metadata).** Aktif açık **doğrulanmadı**.
- **Önerilen düzeltme:** Yalnız panel istemcisine ait politikaların rolünü açıkça `TO authenticated`'a daraltmak (kademeli).

---

### 🟡 F-05 — `qual = true` koşulsuz SELECT politikaları (yalnız referans tablolar) · **[BİLGİ]**
- **Teknik kanıt (canlı):** SELECT `qual = true` yalnız şu referans tablolarda: `activity_attributes`, `custom_icons`, `diploma_equivalences`, `evrak_onerileri`. (Not: INSERT politikalarında `qual = null` normaldir; koşul `WITH CHECK`'tedir — bulgu değildir.)
- **Olası etki:** Referans/sözlük verisi — düşük. Yine de niyet teyidi gerekir.
- **Doğrulama durumu:** **DOĞRULANDI (metadata).**
- **Önerilen düzeltme:** Niyet doğrulanıp gerekiyorsa `TO authenticated` ile daraltma; içerik hassas değilse dokunma.

---

### 🔵 F-06 — `evraklar_select_legacy` politikası rolü `postgres` · **[BİLGİ]**
- **Teknik kanıt (canlı):** `evraklar_select_legacy` → `roles = {postgres}`, SELECT.
- **Olası etki:** Yalnız postgres rolüne etkir; `anon`/`authenticated` kapsamaz. Legacy/artık.
- **Doğrulama durumu:** **DOĞRULANDI (metadata).**
- **Önerilen düzeltme:** Güvenle kaldırılabilir (regresyon sonrası).

---

### ✅ F-07 (Doğrulanmış iyi) — Anon definer RPC yüzeyi 22'ye daraltılmış
- **Teknik kanıt (canlı):** 167 definer fonksiyon; anon `EXECUTE edebilen = 77` (trigger-döndürenler dahil, RPC ile çağrılamaz); **trigger-döndürmeyen gerçek anon RPC yüzeyi = 22**.
- Bu 22'nin tamamı **bilinçli korunan**: RLS yardımcıları (`auth_*`, `has_active_*`, `osgb_access_ok`, `can_access_*`, `is_*`, `mesajlasma_is_participant`, `operasyon_entity_accessible`, `request_context`) + public akış (`teklif_public_get/view/action`, `create_support_ticket`).
- **Önceki turdaki "77 çelişkisi" çözüldü:** 77 sayısı trigger fonksiyonlarını içeriyordu; gerçek anon RPC yüzeyi 22'dir. **GUV-11/13/13b daraltmaları üretime uygulanmış görünüyor.**
- **Not:** `operasyon_bakim_hatirlatma`, `personel_atama_sure_plan`, `personel_firma_id` gibi **gövdesel guard'sız** fonksiyonlar artık anon listesinde **değil** (yalnız authenticated/service_role).

### ✅ F-08 (Doğrulanmış iyi) — Tüm definer fonksiyonlarda `search_path` ayarlı
- **Teknik kanıt (canlı):** 167/167 definer fonksiyonun `proconfig`'i dolu; `search_path` ayarsız **0** fonksiyon.
- Dağılım: 128 `search_path=public`, 27 `search_path=""`, 11 `public, pg_temp`, 1 (+`statement_timeout`).
- **GUV-14/15 search_path sertleştirmeleri uygulanmış.**

---

## 3. KİMLİK DOĞRULAMA — BULGULAR

### ✅ Doğrulananlar
- `AuthContext`: `onAuthStateChange` **senkron** döner; bootstrap `withTimeout` + `finally setLoading(false)` ile sonsuz spinner engellenir.
- Oturum "Beni hatırla" kapatıldıysa ve bu tarayıcı oturumunda giriş işareti yoksa oturum güvenli şekilde düşürülür.
- **Kullanıcı enumerasyonu:** `send-reset-email` her durumda `{ ok: true }` döner (kullanıcı yok/mail yok farkı sızdırılmaz).

### 🟠 F-09 — Şifre değişince diğer oturumlar iptal edilmiyor · **[ORTA]**
- **Etkilenen:** `src/context/AuthContext.tsx` → `changePassword` (yalnız `updateUser({ password })`).
- **Olası etki:** Çalınmış bir oturum, parola değişiminden sonra da geçerli kalabilir.
- **Doğrulama durumu:** **DOĞRULANDI (kod kanıtı).**
- **Önerilen düzeltme:** Parola değişiminde diğer oturumların iptali stratejisi (Supabase `signOut({ scope: 'others' })` veya global revoke) uygulanması.
- **Sonraki aşama testi:** Aynı hesapla iki oturum; birinde parola değiş; diğer istemcide token'ın geçersiz olduğunu doğrula.

### 🟠 F-10 — Brute-force / rate-limit / CAPTCHA yok · **[ORTA]**
- **Etkilenen:** Giriş akışı (`signIn`) ve `send-reset-email` (e-posta bombardımanı).
- **Olası etki:** Parola deneme saldırıları; reset e-posta spam'i (mail abuse).
- **Doğrulama durumu:** **Kısmen doğrulandı (kod)** — istemcide rate-limit yok. Sunucu/Auth Dashboard tarafı **doğrulanamadı**.
- **Önerilen düzeltme:** Supabase Auth rate-limit / CAPTCHA + deneme sayacı; reset akışına throttle.

### ✅ Rol matrisi (doğrulanan)
| Rol | Kapsam özeti (kod/politika kanıtı) |
|---|---|
| `admin` | Platform geneli; `auth_role()='admin'` birçok politikada bypass |
| `osgb_admin` | Kendi OSGB kapsamı (`auth_osgb_id()`), sağlıkta kendi OSGB |
| `firma` | Kendi firması; sağlık muayene/tetkik SELECT **= false** |
| `uzman` | Aktif firma ataması olan firmalar; sağlık SELECT **= false** |
| `hekim` | Aktif firma ataması; sağlık kayıtlarına **tek erişen** saha rolü |
| `DSP` | Ayrı rol **yok**; hekim rolü kapsamında ele alınır (`firmaDetayPermissions` içindeki `'dsp'` anahtarı ölü kod) |

---

## 4. EDGE FUNCTIONS VE API — BULGULAR

### ✅ Doğrulanan desen
- Kritik fonksiyonlarda `auth.getUser(jwt)` → 401 kapısı; rol `profiles`'tan türetilir; `osgb_admin` istemci `osgbId`'sini yok sayar; kaynak ID'leri (`firma_id`, `personel_id`, `tutanakId`) için **sahiplik yeniden doğrulanır** (`CROSS_OSGB`/`CROSS_FIRMA`, `has_active_firma_assignment`).
- `mail/send-tutanak`: yalnız `belge_durumu='signed'` gönderilebilir; uzman→aktif atama, osgb_admin→kendi OSGB kontrolü. **Sunucu tarafı doğrulama sağlam.**
- `osgb-status`: kullanıcı rolünü `profiles`'tan alır; OSGB yaşam döngüsü + firma hizmet sonlandırma ayrı kontrol edilir.

### 🟠 F-11 — Tüm Edge Function'larda CORS `Access-Control-Allow-Origin: *` · **[ORTA]**
- **Teknik kanıt (kod):** `mail`, `auth-log`, `send-reset-email`, `osgb-status` vb. `const CORS = { 'Access-Control-Allow-Origin': '*' ... }`.
- **Olası etki:** Bearer JWT tabanlı API'de tarayıcı origin kısıtı yoksa, bir XSS/kötü origin'den token'lı istek tetiklenebilmesi kolaylaşır (CSRF'den farklı; token gerektirir).
- **Doğrulama durumu:** **DOĞRULANDI (kod kanıtı).**
- **Önerilen düzeltme:** CORS origin allowlist (`app.isgdenetim.com.tr` + yerel geliştirme).
- **Sonraki aşama testi:** İzinli/izinsiz Origin ile preflight yanıtları.

### 🟡 F-12 — `auth-log` anonim yazma / log zehirleme · **[ORTA]**
- **Teknik kanıt (kod):** `auth-log` JWT opsiyonel; `AUTH_LOGIN_FAILED` + herhangi bir e-posta ile `profiles` eşlemesi yapıp `system_logs`'a **service_role ile INSERT** eder. Anon çağrı yapabilir.
- **Olası etki:** `system_logs` tablosuna sahte kayıt enjeksiyonu (log zehirleme), `last_login_at` gibi alanların dolaylı etkilenmesi.
- **Doğrulama durumu:** **DOĞRULANDI (kod kanıtı).**
- **Önerilen düzeltme:** `AUTH_LOGIN_SUCCESS/LOGOUT` için JWT zorunlu; `AUTH_LOGIN_FAILED` için hız sınırı + IP throttle.

---

## 5. KRİTİK SSRF BULGUSU (mail Edge Function) — DETAY
Bkz. **F-01**. Özetle: `smtpHost`/`smtpPort` kullanıcıdan → `Deno.connect(Tls)` → **allowlist/özel-IP/metadata blokajı yok**. Kimliği doğrulanmış (admin/osgb_admin/uzman/hekim) herhangi bir oturum sunucuya iç ağa bağlantı açtırabilir.
- **Kod değiştirilmedi** (talep gereği).
- **Düzeltme gereksinimleri:** host+port allowlist; RFC1918/loopback/link-local/CGNAT/ULA IPv6 blokajı; DNS çözümlemesi sonrası IP kontrolü + rebinding koruması.
- **Test senaryoları:** `127.0.0.1` · `169.254.169.254` · iç servis IP · `[::1]` → tümü reddedilmeli.

---

## 6. SAĞLIK VERİLERİ VE STORAGE — BULGULAR

### ✅ Sağlık verisi (KVKK açısından güçlü) — bkz. §2
- Muayene/tetkik tablolarında `firma`/`uzman` SELECT = `false`; erişim yalnız hekim (aktif atama) / osgb_admin (kendi) / admin.
- RPC `personel_saglik_ozet` yalnız durum+tarih döner; teşhis/kurum/dosya dönmez (önceki tur gövde kanıtı; bu turda politika koşulları yeniden doğrulandı).
- **İstemci ham tabloya gitmiyor**; özet kullanılıyor.

### ✅ Storage (doğrulanan)
- 16 bucket; **yalnız `avatars` + `osgb-logos` public** (tasarım gereği logo/avatar).
- Diğer bucket'larda (`evraklar`, `saha-denetimleri`, `ekipman-*`, `envanter`, `zimmet`, `operasyon`, `mesajlasma`, `atama-belgeleri`, `noter-defteri`, `hazop-kanitlari`...) **istemci SELECT politikası yok → istemciden erişilemez**; dosyalar Edge Function + **imzalı URL (1 saat)** ile sunulur, üretim öncesi sahiplik kontrolü yapılır.
- **`support` bucket** rolü `{public}` görünse de koşul `auth.uid()`'e bağlı:
  - `support_obj_read`: `bucket_id='support' AND (auth_role()='admin' OR EXISTS(... t.created_by = auth.uid() ...))` → **anon'da eşleşmez.**
  - `support_obj_insert`: aynı + `status <> 'closed'` → **anon'da eşleşmez.**
- `avatars_obj_insert` → `foldername[1] = auth.uid()`; `osgb_logos_insert` → `auth_role()='osgb_admin' AND foldername[1]=auth_osgb_id()` → **anon'da eşleşmez.**

### 🟡 F-13 — Storage INSERT `WITH CHECK`'te dosya türü/boyut doğrulaması politikada yok · **[DÜŞÜK]**
- **Teknik kanıt:** Politikalar yalnız yol/sahiplik kontrol ediyor; MIME/boyut kısıtı politikada yok.
- **Olası etki:** Kötü niyetli dosya yükleme (tür/boyut) → uygulama katmanına bağlı.
- **Doğrulama durumu:** **DOĞRULANDI (metadata).**
- **Önerilen düzeltme:** `WITH CHECK`'e `storage.extension`/MIME + boyut sınırı; uygulama tarafında da doğrulama.

---

## 7. BAĞIMLILIKLAR VE YAPILANDIRMA — BULGULAR

### 🟠 F-14 — `xlsx@0.18.5` bilinen güvenlik açıkları · **[ORTA]**
- **Teknik kanıt:** `package.json` → `"xlsx": "0.18.5"`. Kullanıcıdan gelen Excel dosyaları parse edilir (personel/envanter/ekipman import).
- **Bilinen CVE'ler:** SheetJS `<0.19.3` prototype pollution (CVE-2023-30533) ve `<0.20.2` ReDoS (CVE-2024-22363). **npm registry'deki `0.18.5` güvenli sürüm değildir** (düzeltilmiş sürümler farklı dağıtım kanalından gelir).
- **Doğrulama durumu:** **DOĞRULANDI (sürüm) + CVE kaydı (web).** Exploit edilebilirlik runtime testi yapılmadı.
- **Önerilen düzeltme:** Güvenli sürüme geçiş / alternatif kütüphane değerlendirmesi; import akışında dosya boyutu + hücre sayısı sınırları.
- **Sonraki aşama testi:** Kötü niyetli XLSX fixture ile import → sanitizasyon/limit doğrulaması.

### 🟠 F-15 — `jspdf@2.5.1` bilinen güvenlik açıkları · **[ORTA]**
- **Teknik kanıt:** `package.json` → `"jspdf": "2.5.1"`. Sürüm, bilinen birçok CVE'ye (ör. DoS/ReDoS sınıfı) konu olan eski seridir.
- **Doğrulama durumu:** **DOĞRULANDI (sürüm/cve).**
- **Önerilen düzeltme:** Güncel sürüme yükseltme.

### 🟠 F-16 — CSP `unsafe-inline` + `unsafe-eval` içeriyor · **[ORTA]**
- **Teknik kanıt:** `index.html` CSP → `script-src 'self' 'unsafe-inline' 'unsafe-eval' ...`.
- **Olası etki:** XSS savunmasında CSP koruması zayıflar (inline/eval yasaklanmadığından).
- **Doğrulama durumu:** **DOĞRULANDI (kod kanıtı).**
- **Önerilen düzeltme:** Nonce/hash tabanlı CSP'ye geçiş; `unsafe-eval` kaldırma (build bağımlılıkları doğrulanarak).
- **Not:** HSTS/nosniff/frame-ancestors `<meta>` ile gönderilemez → **hosting katmanında** (yalnız HTTP yanıt başlığı) yapılandırılmalı; bu **doğrulanamadı**.

### 🟡 F-17 — `build.sourcemap: true` · **[DÜŞÜK]**
- **Teknik kanıt:** `vite.config.ts` → `build: { sourcemap: true }`.
- **Olası etki:** Üretimde kaynak kod haritası yayınlanırsa kod okunabilirliği artar (bilgi ifşası).
- **Doğrulama durumu:** **DOĞRULANDI (kod kanıtı).** Yayınlanan artifact'ın sourcemap içerdiği **doğrulanamadı**.
- **Önerilen düzeltme:** Üretimde `sourcemap: false` veya kaynak haritalarını gizli tut.

### ✅ Doğrulanan iyi — Sır yönetimi
- `.env` yalnız **public** (`VITE_PUBLIC_SUPABASE_URL`, `VITE_PUBLIC_SUPABASE_ANON_KEY` = `sb_publishable_...`).
- `src/` altında `service_role`/özel anahtar **yok**; tüm sır çağrıları Edge Function içinde `Deno.env.get(...)` ile.
- `sanitizeHtml.ts` + DOMPurify XSS noktalarında kullanılıyor.

### 🟡 F-18 — IBYS global referans kayıtları çok-tenantlı yazılabilir · **[BİLGİ]**
- **Teknik kanıt:** `ibys_referans_eslesmeleri` başlığı ve önceki tur bulgusu; global referans satırlarının tenant'lar arası yazılabilmesi.
- **Doğrulama durumu:** **Kısmen (metadata).** Runtime testi yapılmadı.

### 🔵 F-19 — MFA yok · **[BİLGİ]**
- Yönetici hesapları için ikinci faktör bulunmuyor. **Öneri:** admin/osgb_admin için MFA zorunluluğu.

---

## 8. DOĞRULAMA KURALLARI (uygulanan metodoloji)
- Önceki rapor bulguları **körü körüne doğru kabul edilmedi**; RLS, definer EXECUTE, search_path, profiles trigger, sağlık politikaları, storage politikaları ve SSRF **canlıdan yeniden doğrulandı** (bkz. §2 "77 → 22" çelişkisinin çözümü).
- **Kaynak-kodu kanıtı** ile **canlı metadata kanıtı** raporda ayrı etiketlendi; **runtime/çalıştırma kanıtı** (izole ortam olmadığından) **üretilemedi**.
- Test edilmeyen kontroller **"Doğrulanamadı"** olarak işaretlendi; başarılı sayılmadı.
- **Üretim verisi değiştirilmedi/silinmedi.** Gizli anahtar ve gerçek sağlık verisi rapora yazılmadı. **Kod/DB/config değiştirilmedi.**

---

## 9. RAPOR FORMATI — BULGU LİSTESİ (ID · Başlık · Önem · Kanıt türü · Durum)

| ID | Başlık | Önem | Kanıt | Durum |
|---|---|---|---|---|
| F-01 | mail SSRF (smtpHost/smtpPort kontrolsüz) | **YÜKSEK** | Kod | Doğrulandı |
| F-02 | anon/authenticated 176 tabloda geniş GRANT | Orta (savunma) | Metadata | Doğrulandı |
| F-03 | profiles_update_own WITH CHECK yok | Orta | Metadata | Doğrulandı (trigger telafi) |
| F-04 | Politikalar çoğu TO public | Düşük-Orta | Metadata | Doğrulandı |
| F-05 | 4 referans tabloda qual=true SELECT | Bilgi | Metadata | Doğrulandı |
| F-06 | evraklar_select_legacy rol=postgres | Bilgi | Metadata | Doğrulandı |
| F-07 | ✓ anon definer RPC yüzeyi 22 (iyi) | — | Metadata | Doğrulandı |
| F-08 | ✓ tüm definer search_path ayarlı (iyi) | — | Metadata | Doğrulandı |
| F-09 | Şifre değişince oturum iptali yok | Orta | Kod | Doğrulandı |
| F-10 | Brute-force/rate-limit/CAPTCHA yok | Orta | Kod (kısmi) | Kısmen |
| F-11 | Tüm Edge CORS `*` | Orta | Kod | Doğrulandı |
| F-12 | auth-log anonim yazma (log zehirleme) | Orta | Kod | Doğrulandı |
| F-13 | Storage'da tür/boyut kısıtı yok | Düşük | Metadata | Doğrulandı |
| F-14 | xlsx@0.18.5 CVE | Orta | Sürüm+CVE | Doğrulandı |
| F-15 | jspdf@2.5.1 CVE | Orta | Sürüm+CVE | Doğrulandı |
| F-16 | CSP unsafe-inline/unsafe-eval | Orta | Kod | Doğrulandı |
| F-17 | sourcemap:true | Düşük | Kod | Doğrulandı (yayın teyitsiz) |
| F-18 | IBYS global referans çok-tenant yazım | Bilgi | Metadata | Kısmen |
| F-19 | MFA yok | Bilgi | Kod | Doğrulandı |

---

## 10. SONUÇ SINIFLANDIRMASI

### 10.1 Doğrulanmış bulgular
**F-01 (YÜKSEK)**, F-02, F-03, F-04, F-05, F-06, F-09, F-11, F-12, F-13, F-14, F-15, F-16, F-17, F-19.

### 10.2 Olası bulgular (kısmi kanıt / senaryo)
- **F-10** (rate-limit — sunucu/Auth Dashboard doğrulanamadı).
- **F-18** (IBYS çok-tenant — runtime testi yok).
- **Hosting başlıkları** (HSTS / nosniff / frame-ancestors — yanıt başlığı katmanı doğrulanamadı).

### 10.3 Doğrulanamayan kontroller (⚠ başarı sayılmadı)
- **Runtime IDOR / tenant izolasyon testi** — izole iki-OSGB/iki-firma ortamı yok, canlıda yıkıcı test yasak.
- **Per-function `verify_jwt`** — workspace'te `supabase/config.toml` yok; panelden doğrulanmalı.
- **Auth Dashboard** — self-signup, parola politikası, JWT süresi, rate-limit, e-posta doğrulama.
- **`npm audit` / bağımlılık tam taraması** — araç ortamda çalıştırılamadı.
- **Git geçmişi** — `.git` mevcut değil; sır rotasyonu geçmişi teyit edilemedi.
- **Klasik CSRF ve istemci SQLi** — bu mimaride **N/A** (Bearer JWT + PostgREST parametreli sorgular).

---

## 11. ÖNCELİKLİ DÜZELTME PLANI (dosya bazlı)

### Aşama 1 — Kritik (hedef: hemen)
1. **F-01 SSRF** — `supabase/functions/mail/index.ts`:
   - `smtpHost` allowlist + DNS-sonrası IP bloklama yardımcı fonksiyonu; `smtpPort` allowlist.
   - `openSmtpConnection` çağrılmadan önce host/port doğrulaması.
   - **Regresyon:** `127.0.0.1`, `169.254.169.254`, iç servis IP, `[::1]` reddi; meşru SMTP sağlayıcı gönderimi **çalışmaya devam etmeli**.

### Aşama 2 — Yüksek/Orta sertleştirme
2. **F-12** `auth-log` → success/logout için JWT zorunlu; failed için throttle.
3. **F-03** `profiles_update_own` → `WITH CHECK` ekle (trigger korunur).
4. **F-11** Tüm Edge CORS → origin allowlist.
5. **F-16** CSP → nonce/hash; `unsafe-eval` kaldır.
6. **F-09** Parola değişiminde oturum iptali.
7. **F-02** Kullanılmayan GRANT/TRUNCATE/REFERENCES daralt.

### Aşama 3 — Bağımlılık ve yapılandırma
8. **F-14/F-15** `xlsx`, `jspdf` güvenli sürümlere yükselt; import limitleri.
9. **F-17** Üretimde `sourcemap: false`.
10. **F-04/F-05/F-06** Kademeli politika rol daraltma + legacy temizliği.
11. **F-19** Yönetici MFA.

### Aşama 4 — Doğrulama (izole ortam gerekli)
12. İki-OSGB/iki-firma test harness (`supabase/tests/security/`) çalıştır; IDOR ve tenant izolasyonunu **runtime** doğrula.
13. Per-function `verify_jwt` ve Auth Dashboard ayarlarını panelden doğrula.

---

## 12. REGRESYON TESTLERİ (sonraki aşama için hazır kriterler)
- **RLS:** admin/osgb_admin/firma/uzman/hekim her rol için "yalnız izinli kayıt" doğrulaması (0 satır gereken yerde 0).
- **Tenant izolasyonu:** OSGB-A kullanıcısı OSGB-B kaydını `id` değiştirerek çekmeye çalışsın → **0 satır/403**.
- **Sağlık verisi:** `firma`/`uzman` rolleri muayene/tetkik SELECT → **boş**; hekim (aktif) → dolu.
- **profiles:** Kendi satırında `role='admin'` güncelleme → **ROLE_LOCK hatası** (hem trigger hem politika).
- **SSRF:** Aşama 1 test senaryoları → **reddedilmeli**; meşru SMTP gönderimi **başarılı**.
- **Storage:** Bir firma kullanıcısı başka firmanın dosya yolunu isteyerek imzalı URL alamasın.
- **anon RPC:** `auto_close_ziyaretler`, `delete_osgb_permanent`, `personel_atama_sure_plan` → **permission denied**.

---

*Bu rapor yalnızca inceleme amaçlıdır. Belirtilen düzeltmeler bu aşamada UYGULANMAMIŞTIR.*