# FAZ 11 — Merkezi Oturum Güvenliği, Şifre Politikası ve E-posta Doğrulama

**Tarih:** 2026-10-19
**Kapsam:** Oturum politikası (12 saat / 7 gün), şifre politikası (12 karakter + son 3 şifre),
şifre değişiminde e-posta kodu, kurumsal e-posta tasarımı, beş panel + mobil oturum davranışı.

> **DÜRÜSTLÜK NOTU — OKUYUN**
> Bu doküman bir *uygulama planı + kod paketi*dır. Aşağıdaki komutlar, migration'lar ve sunucu
> ayarları **bu ortamda ÇALIŞTIRILMADI**. Supabase/Readdy Backend bu çalışma alanına bağlı
> değildir; Edge Function deploy edilemedi. Dolayısıyla hiçbir bulgu "kapatıldı" olarak
> işaretlenmemiştir. Yalnızca `npm run build` sonucu doğrulanmıştır (bkz. §A.3).

---

## 0) Mevcut mimari analizi (kod okunarak yapıldı)

| Katman | Bulgu |
|---|---|
| Auth | Self-host Supabase GoTrue; `src/lib/supabase.ts` tek singleton client. `AuthContext` oturum + profil yönetiyor, "beni hatırla" için `localStorage` + `sessionStorage` işareti var. |
| Şifre değişimi | `PasswordChangeForm` → `AuthContext.changePassword*` → `supabase.auth.updateUser({ password, nonce })`. Kod adımı **GoTrue'nun `/reauthenticate` ucuna** bağlıydı. |
| Kök neden (bildirilen hata) | GoTrue, `Error sending reauthentication email` döndürüyor: self-host SMTP / reauthentication şablonu yok. Yani kod **hiç gönderilmiyordu**. |
| Şifre politikası | İstemcide `src/lib/passwordPolicy.ts` (12 karakter + karmaşıklık). Sunucuda yalnızca GoTrue'nun genel politikası; **geçmiş kontrolü yok**. |
| E-posta | `supabase/functions/send-reset-email` içinde markalı (navy + kırmızı accent) responsive HTML şablonu var. Resend kullanılıyor. |
| Paneller | `ProtectedLayout` rol → yol eşlemesi, OSGB erişim durumu, bakım modu, personel çalışma durumu kontrolleri. Tenant izolasyonu RLS + RPC tarafında. |
| Mobil | Bu depoda ayrı mobil istemci yok; `chrome-extension/` var. Mobil davranışı yalnızca tarayıcı/viewport düzeyinde ele alındı. |

---

## A) Kodda yapılan değişiklikler

### A.1 Yeni dosyalar

| Dosya | Amaç |
|---|---|
| `src/lib/sessionPolicy.ts` | 12 saat idle / 7 gün maksimum süre sabitleri, localStorage zaman damgaları, sekmeler arası "oturum bitti" işareti, süre kontrolü. |
| `src/components/feature/SessionPolicyGuard.tsx` | Politikayı uygulayan görünmez bileşen. Süre dolunca **sunucudan çıkış** yapar, yerel veriyi temizler, `/login?reason=...` adresine yönlendirir. |
| `src/lib/sifreDogrulama.ts` | Edge Function istemcisi: `sifreKoduGonder`, `sifreKoduIleDegistir`, tipli hata sınıfları (`SifreApiError`, `EdgeDogrulamaYokError`). |
| `deploy/edge-functions/sifre-dogrulama/index.ts` | **Edge Function kaynağı.** `supabase/functions/` yolu bu çalışma alanında düzenlenemediği için buraya konuldu; kurulumda kopyalanır (§B.1). |
| `supabase/migrations/20260101002800_guv40_sifre_gecmisi.sql` | `password_history` tablosu (RLS açık, politika yok), `auth.users` trigger'ı, `sifre_guncelle_atomik()` fonksiyonu. |
| `supabase/migrations/20260101002900_guv41_sifre_kodlari.sql` | `sifre_dogrulama_kodlari` tablosu (yalnızca SHA-256 özeti) + temizlik fonksiyonu. |
| `supabase/migrations/rollback/*.sql` | İki migration'ın geri alma dosyaları. |

### A.2 Değişen dosyalar

| Dosya | Değişiklik | Neden |
|---|---|---|
| `src/components/feature/auth/PasswordChangeForm.tsx` | Kod adımı artık **Edge Function** üzerinden. GoTrue `reauthenticate` yalnızca yedek yol. Hata kodları ayrı ayrı mesaja çevriliyor. Toast'a yalnızca kullanıcı dostu metin gidiyor; teknik ayrıntı sadece uyarı kutusunda. "Tüm cihazlardan çıkış" bağlantısı eklendi. | Bildirilen hata: kod hiç gönderilmiyordu. Ayrıca "hata mesajları hep aynı" şikâyeti. |
| `src/context/AuthContext.tsx` | `signOutEverywhere()` eklendi (`scope: 'global'` → sunucuda tüm refresh token iptali). Çıkışta oturum zaman damgaları temizleniyor. | "Tüm cihazlardaki oturumları kapat" gereksinimi; istemcide silmenin sunucuda iptal garantisi olmaması. |
| `src/lib/authErrorMessages.ts` | Yaygın/ele geçirilmiş şifre mesajı sadeleştirildi ("veri ihlali" ifadesi kaldırıldı). `friendlyPasswordErrorCode()` eklendi. | Kullanıcı dostu, duruma özel mesajlar. |
| `src/components/feature/ProtectedLayout.tsx` | `<SessionPolicyGuard />` eklendi. | Oturum politikasının tüm panellerde merkezi uygulanması. |
| `src/pages/login/page.tsx` | `?reason=idle|max-duration|all-devices|signedout` için bilgilendirme kutusu. | Süresi dolan oturumda "güvenli yeniden giriş" deneyimi. |
| `src/pages/admin/ayarlar/components/SecuritySection.tsx` | "Oturum Güvenliği" kartı + tüm cihazlardan çıkış butonu (sunucu tarafı iptal). | Gereksinim 2. |

### A.3 Doğrulanan tek sonuç

```
npm run build  →  Build successful
```
Başka hiçbir komut, migration veya deploy çalıştırılmadı.

---

## B) Terminalde çalıştıracağınız komutlar

> Tüm komutlar **proje kök dizininde** (`isg-denetim/`) çalıştırılır.
> Gerçek sırları komut satırına yazmayın; `.env` dosyasından okunur.

### B.1 Edge Function'ı yerine koyma ve deploy

**Amaç:** `deploy/edge-functions/` altındaki kaynağı Supabase'in beklediği yola taşımak.
**Beklenen sonuç:** `supabase/functions/sifre-dogrulama/index.ts` oluşur.

```bash
mkdir -p supabase/functions/sifre-dogrulama
cp deploy/edge-functions/sifre-dogrulama/index.ts supabase/functions/sifre-dogrulama/index.ts
```

**Amaç:** Fonksiyonu yayına almak (JWT doğrulaması açık kalır — istemci token'ı zorunlu).
**Beklenen sonuç:** `Deployed Functions on project ...: sifre-dogrulama`

```bash
supabase functions deploy sifre-dogrulama --project-ref <PROJE_REF>
```

> Self-host kurulumda CLI yerine kendi deploy betiğinizi kullanıyorsanız:
> `deploy/scripts/04-edge-deploy.sh` dosyasına `sifre-dogrulama` satırını ekleyip
> `bash deploy/scripts/04-edge-deploy.sh` çalıştırın. **Bu betiğin içeriğini
> çalıştırmadan önce gözden geçirin** — üretim ortamına dokunur.

### B.2 Build ve mevcut testler

```bash
npm install
npm run build
```

**Beklenen:** `Build successful` / hata yok.

```bash
npm run lint
```

**Beklenen:** Yeni dosyalarda hata yok (mevcut uyarılar devam edebilir).

---

## C) SQL migration blokları

### C.0 Ön koşullar ve yedekleme

1. `pgcrypto` eklentisi (Supabase imajında hazır).
2. Migration yetkisi: `postgres` / `supabase_admin`.
3. **Yedek (zorunlu, üretimde):**

```bash
# DB yedeği — dosya adına tarih yazın, üzerine yazmayın
docker compose exec -T db pg_dump -U postgres -d postgres -Fc \
  > backup_before_guv40_guv41_$(date +%Y%m%d_%H%M).dump
```

**Beklenen:** Sıfırdan büyük `.dump` dosyası. Bu dosya olmadan devam etmeyin.

### C.1 Uygulama sırası (KESİN)

```
1) 20260101002800_guv40_sifre_gecmisi.sql
2) 20260101002900_guv41_sifre_kodlari.sql
3) Edge Function deploy (§B.1)
```

> Sıra önemli: Edge Function `sifre_guncelle_atomik` ve
> `sifre_dogrulama_kodlari` tablosuna bağımlıdır. Migration'lar olmadan deploy
> ederseniz kod adımı `SERVER_ERROR` döner (şifre değişmez — veri bozulmaz).

**Dosya yolları:** `supabase/migrations/20260101002800_guv40_sifre_gecmisi.sql`,
`supabase/migrations/20260101002900_guv41_sifre_kodlari.sql` (tam içerik depoda).

Uygulama (self-host):

```bash
supabase db push --db-url "postgresql://postgres:<PAROLA>@127.0.0.1:5432/postgres"
```

> `<PAROLA>` kısmını komuta gömmeyin; `read -s` ile değişkene alın veya
> `.env`'deki `POSTGRES_PASSWORD` üzerinden geçin.

### C.2 Migration doğrulama (salt okunur)

```sql
-- Tablolar oluştu mu?
select table_name, row_security
  from information_schema.tables t
  join pg_class c on c.relname = t.table_name
 where t.table_schema = 'public'
   and t.table_name in ('password_history','sifre_dogrulama_kodlari');

-- Trigger bağlı mı?
select tgname from pg_trigger where tgname = 'trg_auth_users_password_history';

-- Fonksiyonlar var mı?
select proname from pg_proc
 where proname in ('sifre_guncelle_atomik','auth_users_password_history_capture',
                   'sifre_dogrulama_kodlarini_temizle');

-- anon/authenticated erişimi KAPALI olmalı (boş dönmeli)
select grantee, privilege_type
  from information_schema.role_table_grants
 where table_name in ('password_history','sifre_dogrulama_kodlari')
   and grantee in ('anon','authenticated');
```

**Beklenen:** 2 tablo, 1 trigger, 3 fonksiyon; son sorgu **0 satır**.
0 satır dönmezse migration'ı geri alın ve nedenini inceleyin.

### C.3 Davranış testi (üretimde DEĞİL, test ortamında)

```sql
-- ÖNEMLİ: Bu sorgu gerçek bir kullanıcının şifresini değiştirir.
-- YALNIZCA test hesabında çalıştırın.
select public.sifre_guncelle_atomik('<TEST_USER_UUID>', 'GeciciSifre!2026');
-- 1. çağrı: OK
select public.sifre_guncelle_atomik('<TEST_USER_UUID>', 'GeciciSifre!2026');
-- 2. çağrı: PASSWORD_SAME
select public.sifre_guncelle_atomik('<TEST_USER_UUID>', 'GeciciSifre!2026');
-- aynı şifre: PASSWORD_SAME
select public.sifre_guncelle_atomik('<TEST_USER_UUID>', 'BaskaSifre!2027');
-- yeni şifre: OK  → eski özet geçmişe düşer
select public.sifre_guncelle_atomik('<TEST_USER_UUID>', 'GeciciSifre!2026');
-- tekrar eski: PASSWORD_REUSED
```

---

## D) Sunucu yapılandırma blokları

### D.1 GoTrue — gerçek sunucu tarafı oturum sınırları

İstemci kontrolü tek başına yetmez; **sunucuda da** sınır konulmalıdır.
`docker-compose` / `deploy/docker-compose.auth-hardening.yml` içindeki **`auth`**
servisinin `environment` bölümüne şu satırları ekleyin (dosyanın tamamını
değiştirmeyin, yalnızca bu satırları ekleyin):

```yaml
      # ── FAZ 11 · Oturum politikası ──
      # ⚠️ DÜZELTME (2026-10-20): Bu değerler Go time.Duration olarak
      # ayrıştırılır. ÇIPLAK SAYI ("43200") YAZILMAZ → GoTrue açılışta
      # fatal verip restart döngüsüne girer. Birim ZORUNLU.
      # 12 saat hareketsizlik → oturum geçersiz
      GOTRUE_SESSIONS_INACTIVITY_TIMEOUT: "43200s"
      # Girişten itibaren maksimum 7 gün → oturum geçersiz
      GOTRUE_SESSIONS_TIMEBOX: "604800s"
      # Refresh token rotasyonu + yeniden kullanım aralığı
      GOTRUE_SECURITY_REFRESH_TOKEN_ROTATION_ENABLED: "true"
      GOTRUE_SECURITY_REFRESH_TOKEN_REUSE_INTERVAL: "10"
      # ── Şifre politikası (istemci ile aynı) ──
      GOTRUE_PASSWORD_MIN_LENGTH: "12"
      # Karmaşıklık: küçük, büyük, rakam, özel karakter
      GOTRUE_PASSWORD_REQUIRED_CHARACTERS: "abcdefghijklmnopqrstuvwxyz:1,ABCDEFGHIJKLMNOPQRSTUVWXYZ:1,0123456789:1,!@#$%^&*()-_=+:1"
      # ⚠️ ÇELİŞKİ NOTU (2026-10-20): Aşağıdaki satır bu belgede önceden
      # "false" yazıyordu. CANLIDA GEÇERLİ OLAN DEĞER "true"'dur ve
      # deploy/docker-compose.auth-hardening.yml bu değeri sabitler
      # (F1 retesti 400 reauthentication_needed ile doğrulandı).
      # "false" yazılması F1 (CVSS 8.1) bulgusunu yeniden açar.
      # Aşağıdaki satır yalnızca TARİHSEL kayıttır; canlıya uygulanacak
      # değer "true" olanıdır.
      # GOTRUE_SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION: "false"
```

> **Canlı doğrulama (2026-10-19):** `GOTRUE_SECURITY_UPDATE_PASSWORD_REQUIRE_REAUTHENTICATION=true`
> hem merge çıktısında hem container içinde görüldü; 3 günlük oturumla yapılan
> `PUT /auth/v1/user` isteği `400 reauthentication_needed` döndü.
> **Geçerli değer `true`'dur.**

**Kontrollü uygulama:**

```bash
# 1) Yalnızca auth servisini yeniden başlat (tüm stack'i değil)
docker compose up -d --no-deps auth

# 2) Ayarların yüklendiğini doğrula
docker compose logs auth --tail 60 | grep -iE "session|password|inactiv|timebox"
```

**Beklenen:** Logda oturum/şifre politikası satırları görünür, hata yok.
`GOTRUE_SESSIONS_*` anahtarlarını GoTrue sürümünüz tanımıyorsa logda
"unknown"/"unrecognized" uyarısı çıkar — o durumda istemci katmanı (A.1) tek
başına çalışır ve bu **kalan risk** olarak raporlanır (§G).

> **Neden `REQUIRE_REAUTHENTICATION=false`?** Yeniden doğrulama artık bizim
> e-posta kodumuzla yapılıyor ve kod doğrulanmadan `auth.users` şifresi
> değiştirilemiyor (`sifre_guncelle_atomik` yalnızca `service_role`). GoTrue'nun
> kendi nonce mekanizmasını açık bırakmak, çalışmayan e-posta gönderimi yüzünden
> kullanıcıyı kilitliyordu.

### D.2 Edge Function ortam değişkenleri

Mevcut `RESEND_API_KEY` ve `RESEND_FROM_DOMAIN` yeniden kullanılır (**yeni sır
gerekmez**). `send-reset-email` çalışıyorsa bu ikisi zaten tanımlıdır.

```bash
# Yalnızca VARLIĞINI kontrol edin, değeri yazdırmayın
supabase secrets list --project-ref <PROJE_REF>
```

**Beklenen:** Listedе `RESEND_API_KEY` ve `RESEND_FROM_DOMAIN` görünür
(değerler maskelidir).

### D.3 CORS

Edge Function origin allowlist'i `send-reset-email` ile aynıdır:
`app.isgdenetim.com.tr`, `www.isgdenetim.com.tr`, `isgdenetim.com.tr`,
`localhost:3000/5173`, `127.0.0.1:3000` + `ALLOWED_ORIGINS` env'i.
Üretim alan adınız farklıysa `ALLOWED_ORIGINS`'e ekleyin.

---

## E) Environment değişkenleri

| Değişken | Yer | Amaç | Nasıl ayarlanır |
|---|---|---|---|
| `RESEND_API_KEY` | Edge Function secret | Doğrulama kodu + güvenlik bildirimi gönderimi | Mevcut değeri kullanın; yoksa panelden ekleyin: `supabase secrets set RESEND_API_KEY=...` (değeri sohbete yazmayın) |
| `RESEND_FROM_DOMAIN` | Edge Function secret | `noreply@<domain>` gönderen adresi | Domain doğrulanmış olmalı; `send-reset-email` ile aynı değer |
| `ALLOWED_ORIGINS` | Edge Function secret (ops.) | Ek CORS origin'leri (virgülle) | `supabase secrets set ALLOWED_ORIGINS=https://...` |
| `GOTRUE_SESSIONS_INACTIVITY_TIMEOUT` | auth servisi env | 12 saat idle (saniye) | §D.1 |
| `GOTRUE_SESSIONS_TIMEBOX` | auth servisi env | 7 gün maksimum (saniye) | §D.1 |
| `GOTRUE_PASSWORD_MIN_LENGTH` | auth servisi env | 12 karakter | §D.1 |

> Frontend'de **yeni** `VITE_PUBLIC_*` değişkeni gerekmedi.

---

## F) Doğrulama komutları ve test senaryoları

### F.1 Otomatik (bu ortamda çalıştırılabilen)

```bash
npm run build     # beklenen: Build successful
npm run lint      # beklenen: yeni hata yok
```

### F.2 Manuel kabul testleri (test ortamı — üretimde yapmayın)

| # | Senaryo | Beklenen sonuç | Durum |
|---|---|---|---|
| 1 | Ayarlar → Güvenlik → Mevcut + yeni şifre → "Doğrulama Kodu Gönder" | E-postaya **markalı** e-posta, 6 haneli kod | ⏳ Uygulanmadı |
| 2 | Kodu gir → "Doğrula ve Güncelle" | Şifre değişir, "Şifreniz güncellendi" toast'u, ikinci e-posta (bildirim) | ⏳ |
| 3 | Aynı kodu tekrar kullan | `CODE_INVALID` → "Doğrulama kodu geçersiz" (tek kullanımlık doğrulandı) | ⏳ |
| 4 | 11 dakika bekleyip kodu gir | `CODE_EXPIRED` → net mesaj + yeni kod istemi | ⏳ |
| 5 | 6 kez yanlış kod | `CODE_ATTEMPTS` → kod adımı kapanır | ⏳ |
| 6 | Son 3 şifreden birini denemek | `PASSWORD_REUSED` → "son 3 şifrenizden biri" mesajı | ⏳ |
| 7 | Mevcut şifre = yeni şifre | Alan altında anında uyarı; sunucu `PASSWORD_SAME` | ⏳ |
| 8 | İki sekmede aynı anda şifre değiştirme | Advisory lock → ikinci istek sıralı; ikisi de geçmiş kontrolünden geçer | ⏳ |
| 9 | Şifre değiştikten sonra diğer tarayıcı | O cihazın oturumu düşer (refresh token iptal) | ⏳ |
| 10 | 12 saat dokunmadan bekle (veya localStorage `isg:session:last-activity` değerini 12 saat geriye çek) | `/login?reason=idle` + bilgilendirme kutusu | ⏳ |
| 11 | `isg:session:started-at` değerini 7 gün geriye çek, sayfayı yenile | `/login?reason=max-duration` | ⏳ |
| 12 | İki sekme açıkken birinde oturumu kapat | Diğer sekme de `/login`'e düşer (storage olayı) | ⏳ |
| 13 | "Tüm cihazlardan çıkış yap" | Tüm cihazlarda giriş gerekir | ⏳ |
| 14 | Beş panelde rol/tenant | `ProtectedLayout` davranışı değişmedi; yabancı tenant verisi görünmüyor | ⏳ |
| 15 | Türkçe karakterler (`ş ğ ı İ ö ü ç`) e-posta başlığı/gövdesi | Bozulma yok, UTF-8 doğru | ⏳ |
| 16 | Resend anahtarı kaldırılmış hâlde kod gönder | `MAIL_NOT_CONFIGURED` → **başarı mesajı gösterilmez** | ⏳ |

### F.3 Tek satırlık istemci tarafı hızlandırma (test ortamı, tarayıcı konsolu)

```js
// 12 saat idle simülasyonu — sonra sayfayı yenile
localStorage.setItem('isg:session:last-activity', String(Date.now() - 13*60*60*1000));
// 7 gün maksimum simülasyonu
localStorage.setItem('isg:session:started-at', String(Date.now() - 8*24*60*60*1000));
```

> Bu iki komut **yalnızca test tarayıcısında** kullanılmalıdır.

---

## G) Geri dönüş planı (rollback)

| Değişiklik | Geri dönüş | Risk |
|---|---|---|
| Migration GUV-41 | `supabase/migrations/rollback/20260101002900_guv41_sifre_kodlari_rollback.sql` | Kod adımı çalışmaz → form eski GoTrue yoluna düşer |
| Migration GUV-40 | `supabase/migrations/rollback/20260101002800_guv40_sifre_gecmisi_rollback.sql` (**önce** Edge Function'ı durdurun) | Şifre değişimi tamamen durur |
| Edge Function | `supabase functions delete sifre-dogrulama --project-ref <ref>` | Form otomatik olarak GoTrue `reauthenticate` yoluna düşer (o da SMTP istiyor) |
| GoTrue env (§D.1) | Eklenen satırları silin → `docker compose up -d --no-deps auth` | Oturum süreleri sınırsız hâle döner |
| Frontend | `git revert <commit>` / sürüm geçmişinden geri dön | — |
| Tam DB geri dönüşü | `pg_restore -U postgres -d postgres --clean backup_*.dump` | **YIKICI**: yedek sonrası tüm veriler kaybolur |

Frontend geri dönüşü güvenlidir: yeni bileşenler bağımsız, mevcut akışlar
korunmuştur. Edge Function yoksa form otomatik yedek yola geçer.

---

## H) Bilinen kalan riskler (açıkça)

1. **GoTrue kendi şifre değiştirme yolu geçmiş kontrolünden geçmez.**
   `supabase.auth.updateUser({ password })` çağrısı (şifre sıfırlama ekranı)
   `sifre_guncelle_atomik`'i kullanmaz. Trigger eski özeti geçmişe yazar ama
   "son 3 şifre" kuralını GoTrue yoluyla uygulayamayız (düz metin sunucuda yok).
   → Öneri: şifre sıfırlama ekranı da ileride aynı Edge Function'a taşınmalı.
2. **Yeni giriş uyarısı e-postası** henüz gönderilmiyor. Şablon hazır
   (`renderIsgEmail`), tetikleyici (GoTrue auth hook / login sonrası Edge çağrısı)
   eklenmedi.
3. **Mobil istemci** bu depoda yok; SecureStore/refresh akışı incelenemedi.
4. **`GOTRUE_SESSIONS_*` desteği** GoTrue sürümüne bağlı. Sürüm desteklemiyorsa
   12sa/7gün yalnızca istemcide uygulanır — bu, teknik olarak atlatılabilir bir
   katmandır (token ömrü sunucuda kısalana kadar).
5. **IP tespiti** ters proxy başlıklarına bağlı; proxy başlıkları temizlemiyorsa
   hız sınırı yanlış anahtarlanabilir (fail-open davranır, kullanıcıyı kilitlemez).
6. **`sifre_dogrulama_kodlari` temizliği** periyodik çağrılmazsa tablo büyür.
   `sifre_dogrulama_kodlarini_temizle()` bir cron/pg_cron görevine bağlanmalı.