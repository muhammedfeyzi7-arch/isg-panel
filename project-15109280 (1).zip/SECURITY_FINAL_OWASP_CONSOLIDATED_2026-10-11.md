# İSGDenetim / OSGB SaaS — OWASP Top 10 Nihai Konsolide Güvenlik Denetimi

> **Tarih:** 2026-10-11 · **Kapsam:** React/Vite SPA · Supabase Auth · PostgreSQL (RLS/RPC)
> · Edge Functions (47) · Storage · Harici entegrasyonlar (İSG-KATİP, Resend/mail, İBYS) ·
> Bağımlılıklar · Build yapılandırması · İş mantığı.
>
> **TUR SINIRI (tam uyum):** Bu denetimde **hiçbir kod dosyası, migration, RLS politikası,
> Edge Function, bağımlılık sürümü veya secret DEĞİŞTİRİLMEDİ/DEPLOY EDİLMEDİ.** Üretimde
> **yıkıcı payload / kesinti testi uygulanmadı.** Veritabanına yalnızca **salt-okuma** ile
> bakıldı. Gerçek kullanıcı/tenant/çalışan/sağlık verisi okunmadı, kopyalanmadı, değiştirilmedi.
>
> **Yöntem:** (a) kaynak kod okuma (`src/**`, `supabase/functions/**`, `supabase/migrations/**`,
> `chrome-extension/**`), (b) statik `grep` taraması (secret/CORS/innerHTML/fetch), (c) canlı
> salt-okuma metadata, (d) bağımlılık CVE doğrulaması (harici güvenlik kayıtları), (e) önceki
> **14 güvenlik denetiminin** birleştirilmesi.
>
> **DÜRÜSTLÜK NOTU:** Bu, **resmî TSE onaylı bir sızma testi DEĞİLDİR.** İzole iki-tenant test
> ortamı olmadığı için **runtime ile hiçbir exploit DOĞRULANMADI**; bulgular **kod + canlı
> metadata kanıtı** üzerinden değerlendirildi. **Çalıştırılmayan testler "başarılı" sayılmadı.**
> `npm audit` / `tsc` / `supabase test db` bu ortamda **çalıştırılamadı → BLOCKED** olarak
> işaretlendi; sonuç uydurulmadı.

---

## 0) YÖNETİCİ ÖZETİ

| Alan (OWASP 2021) | Durum | Kanıt türü |
|---|---|---|
| A01 Broken Access Control (tenant/rol) | ✅ **Olgun** — 176/176 tablo RLS, 9 RESTRICTIVE guard, sunucu tarafı tenant türetimi | canlı katalog + kod |
| A02 Cryptographic Failures | ✅ İyi — JWT/HTTPS; sunucu sırları yalnız Edge Function'da | kod |
| A03 Injection (SQLi) | ✅ Düşük — parameterized PostgREST/RPC, dinamik SQL yok | kod + migration |
| A03 Injection (XSS) | ⚠️ **Orta** — tüm `innerHTML` sanitizer'lı ama CSP `unsafe-inline/unsafe-eval` | kod (`index.html`) |
| A04 Insecure Design | ⚠️ **Orta** — SMTP host kullanıcı kontrollü (**SSRF**), MFA yok | kod (`mail/index.ts`) |
| A05 Security Misconfiguration | ⚠️ **Orta** — CORS `*` (43 fn), `sourcemap:true`, eksik HTTP başlıkları | statik grep + `vite.config.ts` |
| A06 Vulnerable Components | ⚠️ **Orta** — `xlsx@0.18.5` (prototype pollution + ReDoS), `jspdf@2.5.1` (çoklu CVE) | paket + CVE kaydı |
| A07 Auth Failures | ⚠️ **Düşük-Orta** — uygulama lockout yok, çıkışta diğer oturumlar iptal edilmiyor | kod |
| A08 Integrity Failures | ✅ Düşük — imza/şema doğrulaması sunucuda | kod |
| A09 Logging/Monitoring | ⚠️ **Düşük** — `auth-log` anonim; log zehirlenmesi mümkün | kod |
| A10 SSRF | ⚠️ **YÜKSEK** — kullanıcı kontrollü SMTP host → sunucu iç ağa bağlanabilir | kod (`mail/index.ts`) |
| Secret sızıntısı | ✅ İyi — istemcide `service_role` yok; `.env` yalnız public anon | grep + `.env` |
| Git geçmişi / build çıktısı | ⛔ **Doğrulanamadı** (`.git` yok) / ⚠️ sourcemap açık | — |

**Genel değerlendirme:** Sistem veri katmanında **olgun** (RLS %100, tenant guard'lar, storage
izolasyonu, sunucu tarafı yetki). Bu turda **yeni ve doğrulanmış en önemli teknik bulgu**, `mail`
Edge Function'ındaki **kimliği doğrulanmış SSRF** (kullanıcı SMTP host'unu serbestçe belirleyip
sunucuya iç ağa bağlantı açtırabiliyor). Diğerleri ağırlıklı **sertleştirme** ve **bağımlılık
güncellemesi**. **Doğrulanmış, uzaktan-kimliksiz (exploitable) kritik bir açık bulunmadı.**

---

## 1) KAPSAMDA İNCELENEN ÖNCEKİ 14 DENETİM (birleştirme kaynağı)

`SECURITY_AUDIT_REPORT_2026-10-11` · `SECURITY_AUDIT_AUTH_2026-10-11` ·
`SECURITY_AUDIT_RLS_TENANT_ROLES_2026-10-11` · `SECURITY_AUDIT_IDOR_EDGE_HEALTH_STORAGE_2026-10-11`
· `SECURITY_COVERAGE_PHASE8` · `SECURITY_DAY_SUMMARY_2026-10-09` · `SECURITY_FINAL_REMEDIATION_REPORT`
· `SECURITY_FIXES_PHASE2` · `SECURITY_MIGRATION_DEPENDENCIES` · `SECURITY_MIGRATION_TEST_PLAN`
· `SECURITY_PHASE10_TEST_ENV_CHECKLIST` · `SECURITY_REMAINING_ISSUES` ·
`SECURITY_RUNTIME_VALIDATION_PHASE9` · `SECURITY_TEST_ENV_PLAN_PHASE8` ·
`SECURITY_TEST_RESULTS_PHASE7/8` · `QA_FULL_MODULE_REPORT`.

**Birleşik kapanış durumu:** Frontend XSS düzeltmeleri **CLOSED**; veri katmanı migration'ları
(GUV-01/02/06/07/11/13/13b/14/15) **FIXED-UNVERIFIED** (dosya hazır, izole ortamda çalıştırılmadı);
CORS allowlist (GUV-04) **PREPARED-NOT-APPLIED**; sourcemap/HTTP başlıkları **NOT APPLICABLE (kod)**.

---

## 2) GİZLİ ANAHTAR SIZINTI TARAMASI (kanıt)

| # | Konu | Kanıt | Sonuç |
|---|---|---|---|
| S1 | İstemci `service_role`/`sb_secret` | `src/**` grep → **0 eşleşme**; `src/lib/supabase.ts` yalnız `VITE_PUBLIC_SUPABASE_ANON_KEY` | ✅ Sızıntı yok |
| S2 | `.env` içeriği | Yalnız `VITE_PUBLIC_SUPABASE_ANON_KEY="sb_publishable_…"` + `VITE_PUBLIC_SUPABASE_URL` — **publishable/anon** anahtar, sunucu sırrı DEĞİL | ✅ Beklenen |
| S3 | Edge Function sırları | `Deno.env.get('SUPABASE_SERVICE_ROLE_KEY' / 'GEMINI_API_KEY' / 'RESEND_API_KEY' / 'IBYS_*')` → yalnız server-side; yanıtlarda yalnız "var/yok" boolean | ✅ |
| S4 | Extension | `service-worker.ts` `apikey: config.supabaseAnonKey` (public) + kullanıcının kendi `authToken`'ı (hardcode değil) | ✅ |
| S5 | Log redaction | `errorLogger.ts` + `logService` + `mail/sanitizeError` token/password/secret desenlerini `[REDACTED]` yapar; `LogDetailContent` `SENSITIVE_KEY` filtresi | ✅ İyi uygulama |
| S6 | `.gitignore` | `.env*`, `*.key`, `*.pem`, `service-account*.json`, `supabase/functions/**/*.env` korunuyor | ✅ |
| S7 | Git geçmişi | Depoda `.git/` **yok** (glob: eşleşme yok) | ⛔ **BLOCKED** — rotate gereksinimi teyit edilemedi |
| S8 | Build çıktısı (`out/`) | `vite.config.ts` → `build.sourcemap: true`; `out/` workspace'te yok | ⚠️ Kaynak haritası yayınlanıyorsa **kaynak kodu ifşası** riski (sır değil) |

**Sonuç:** İstemci bundle'ında ve depoda **doğrulanmış sır sızıntısı bulunmadı**. Git geçmişi ve
gerçek build çıktısı **erişilemediği için** bu iki alan **başarı olarak sayılmadı**.

---

## 3) BULGULAR — SINIFLANDIRILMIŞ (benzersiz ID · kanıt · etki · ön koşul · düzeltme · retest)

> `[DOĞRULANMIŞ]` = kod/canlı kanıtla kesin. `[OLASI]` = güçlü gösterge, izole ortamda teyit gerekli.
> `[BİLGİ]` = risk değil, kayıt amaçlı.

### 🔴 KRİTİK
Bu turda **kriterlere uyan Kanıtlanmış Kritik bulgu YOK.** (GUV-01 storage cross-tenant KAPANIŞI
canlıda doğrulandı: `storage_tenant_ok` politikaları aktif → önceki "kritik" kapandı. Bkz §5.)

### 🟠 YÜKSEK

**OWASP-A10-01 · [DOĞRULANMIŞ] Kimliği doğrulanmış SSRF — kullanıcı kontrollü SMTP host**
- **Bileşen:** `supabase/functions/mail/index.ts` → `handleSaveSmtp` / `openSmtpConnection` / `verifySmtp`.
- **Kanıt (kod):** `smtpHost = String(body.smtpHost ?? '').trim()` **kullanıcıdan** alınır ve
  `Deno.connectTls({ hostname: cfg.host, port: cfg.port })` / `Deno.connect(...)` ile **doğrudan
  bağlantı** açılır. Host için **allowlist/özel-IP/AHOST bloklama YOKtur**. Rol kapısı
  `ALLOWED_ROLES = ['admin','osgb_admin','uzman','hekim']` — yani **herhangi bir oturumlu rol**
  bu çağrıyı yapabilir. `verifySmtp`, kaydetmeden önce bağlantıyı dener.
- **Etki:** Sunucu, saldırganın seçtiği **herhangi bir host:port**'a bağlantı açar → iç ağ port
  taraması, bulut metadata uç noktalarına (ör. 169.254.169.254), iç servislere erişim denemesi;
  ayrıca hata mesajı farkıyla **iç ağ keşfi**. (Banner/SMTP diyaloğu kısıtlı olsa da bağlantı
  kuran/aramayan ayrımı bilgi sızdırır.)
- **İstismar ön koşulu:** Geçerli bir kullanıcı oturumu (rol ∈ ALLOWED_ROLES). Kimliksiz değil.
- **Düzeltme önerisi:** (1) SMTP host için **allowlist** ya da en azından **RFC1918 / link-local /
  loopback / metadata IP bloklama**; (2) host'u çözüp IP'yi doğrulama (DNS rebinding'e dikkat);
  (3) `verifySmtp`'i yalnız admin'e veya beyaz listeye kısıtlama; (4) port allowlist (25/465/587/2525).
- **Tekrar test kriteri:** `smtpHost` = `127.0.0.1` / `169.254.169.254` / iç IP ile kaydetme denemesi
  **reddedilmeli**; izinli host kabul edilmeli. İzole ortamda doğrulanır.

### 🟡 ORTA

**OWASP-A05-01 · [DOĞRULANMIŞ] Edge Function CORS wildcard (`Access-Control-Allow-Origin: *`)**
- **Bileşen:** **43 Edge Function** (ör. `accept-invite`, `firma-davet`, `osgb-davet`,
  `personel-hesap`, `send-reset-email`, `auth-log`, `mail`, `ibys-gonderim`).
- **Kanıt (statik):** `const CORS = { 'Access-Control-Allow-Origin': '*', … }`.
- **Etki:** Herhangi bir origin bu API'leri çağırabilir. Kimlik **Bearer JWT / tek-kullanımlık
  token** ile sunucuda doğrulandığından **çerez tabanlı CSRF doğrudan mümkün değildir**; ancak
  savunma derinliği zayıflar ve token sızdıysa kullanım yüzeyi genişler.
- **Ön koşul:** Tarayıcı bağlamı; genelde ek kimlik bilgisi gerekir.
- **Düzeltme:** `_shared/cors.ts` + `ALLOWED_ORIGINS` secret ile **origin allowlist**; her fonksiyon
  **tek tek** deploy + preflight testi. (Modül içeriği `SECURITY_FINAL_REMEDIATION_REPORT.md §5.1`.)
- **Retest:** İzinli origin → `ACAO` döner; izinsiz origin → `ACAO` **dönmez**. Her fonksiyon için.

**OWASP-A03-02 · [DOĞRULANMIŞ] CSP zayıflığı (`unsafe-inline` + `unsafe-eval`)**
- **Bileşen:** `index.html` `<meta http-equiv="Content-Security-Policy">`.
- **Kanıt:** `script-src 'self' 'unsafe-inline' 'unsafe-eval' …`; `object-src 'none'`, `base-uri 'self'`
  mevcut; ancak `frame-ancestors` `<meta>` ile verilemez.
- **Etki:** XSS gerçekleşirse inline script çalışır → `localStorage`'daki Supabase token'ı
  çalınabilir (AUTH-01 ile zincir). Tüm `dangerouslySetInnerHTML` noktaları `sanitizeHtml` (DOMPurify)
  ile korunuyor → **tek başına açık değil**, savunma derinliği zayıf.
- **Düzeltme:** `unsafe-eval` kaldırılabilir mi araştır; mümkünse `unsafe-inline` yerine nonce/hash.
  HSTS/`X-Content-Type-Options`/`frame-ancestors` **HTTP başlığı** olarak hosting katmanında.
- **Retest:** CSP Reporting veya tarayıcı konsolunda ihlal; eval gerektiren yol kalmadığında kaldır.

**OWASP-A06-01 · [DOĞRULANMIŞ] Güncel olmayan bağımlılıklar (bilinen CVE)**
- **Bileşen:** `package.json` → `xlsx@0.18.5`, `jspdf@2.5.1`.
- **Kanıt:** `xlsx@0.18.5`, **kullanıcı yüklediği dosyaları** işleyen `XlsxPreviewAdapter` ve
  `ExcelPersonelImportModal` içinde `import * as XLSX from 'xlsx'` ile kullanılır. Harici CVE
  kayıtları: **CVE-2023-30533** (Prototype Pollution), **CVE-2024-22363** (ReDoS) — düzeltme
  yalnız SheetJS'in **npm dışı** dağıtımında (`>=0.19.3`/`0.20.x`). `jspdf@2.5.1` için çoklu CVE
  (ör. `CVE-2020-7691`, GIF-kaynaklı DoS; Node-özel path traversal CVE-2025-68428 tarayıcıyı etkilemez).
- **Etki:** Kötü-amaçlı bir `.xlsx` yüklendiğinde tarayıcıda **prototype pollution / ReDoS (dondurma)**.
  İstemci-taraflı; ayrıcalık yükseltmez ama **DoS/kararsızlık** ve ileride birleşebilir risk.
- **Ön koşul:** Kullanıcının zararlı dosyayı yüklemesi.
- **Düzeltme:** `xlsx`'i SheetJS resmî CDN sürümüne (`0.20.x`) geçir veya alternatif (`exceljs` zaten var);
  `jspdf`'i güncel sürüme yükselt. **Sürüm değiştirmeden** önce regresyon testi.
- **Retest:** `npm audit` (mevcut ortamda BLOCKED) + zararlı test dosyasıyla import akışı sağlam.

**OWASP-A01-01 · [DOĞRULANMIŞ] anon rolüne geniş tablo yetkisi (savunma derinliği)**
- **Bileşen:** PostgreSQL — `anon` rolü 176/176 tabloda geniş tablo GRANT'ına sahip.
- **Kanıt (canlı):** RLS **176/176 açık** olduğundan aktif sızma YOK; ancak güvenlik **tek kapıya (RLS)**
  bağlı. Yanlış yazılmış bir permissive politika doğrudan anon erişimine dönüşür.
- **Düzeltme:** Gereksiz tablo yetkilerini `REVOKE`; yeni politikaları `TO authenticated` yaz.
- **Retest:** İzole ortamda anon SELECT denemesi → beklenen tablolarda `permission denied`/boş.

**OWASP-A07-01 · [DOĞRULANMIŞ] Şifre değişiminde diğer oturumlar iptal edilmiyor**
- **Bileşen:** `src/context/AuthContext.tsx` (`changePassword`, mevcut-şifre doğrulamalı).
- **Kanıt:** `signOut({ scope: 'others' })` çağrısı **yok**.
- **Etki:** Ele geçirilmiş bir oturum, şifre değişse dahi ayakta kalır.
- **Düzeltme:** Şifre değişiminden sonra diğer oturumları sonlandır (`scope: 'others'`).
- **Retest:** İki oturumda A şifre değiştirir → B oturumu düşmeli.

**OWASP-A07-02 · [DOĞRULANMIŞ] Uygulama seviyesinde lockout/CAPTCHA yok**
- **Bileşen:** giriş akışı; tek savunma Supabase tümleşik rate-limit.
- **Kanıt:** Canlı log sayımı: **41 başarılı / 39 başarısız giriş** kayıtlı; istemcide sayaç/CAPTCHA yok.
- **Düzeltme:** İstemci/Edge tarafı deneme sayacı + CAPTCHA; Supabase rate-limit ayarlarını doğrula.
- **Retest:** N başarısız denemeden sonra kilit/CAPTCHA tetiklenmeli.

**OWASP-A09-01 · [DOĞRULANMIŞ] `auth-log` anonim yazma (log zehirlenmesi)**
- **Bileşen:** `supabase/functions/auth-log/index.ts` — JWT'siz çağrılabilir; olay beyaz listeli.
- **Kanıt (kod):** `AUTH_LOGIN_FAILED` + e-posta ile JWT olmadan insert; `ALLOWED_EVENTS` ile sınırlı.
- **Etki:** **Veri sızmaz/dosya açılmaz**; sahte başarısız-giriş satırlarıyla denetim kaydı kirletilebilir.
- **Düzeltme:** Basit oran sınırı (rate-limit) veya captcha doğrulaması.
- **Retest:** Aşırı istekte 429/throttle; meşru akış bozulmamalı.

### 🔵 DÜŞÜK

**OWASP-A01-02 · [OLASI] IBYS global referans satırları çok-tenantlı yazılabilir**
- **Bileşen:** `ibys_referans_eslesmeleri` RLS politikaları.
- **Kanıt (canlı):** `auth_role()='osgb_admin' AND (osgb_id IS NULL OR osgb_id = auth_osgb_id())`.
- **Etki:** `osgb_id IS NULL` **global** satırlar **herhangi bir OSGB yöneticisi** tarafından
  değiştirilebilir → başka OSGB'leri etkileyebilecek paylaşımlı yazma. **Tasarım kararı olabilir.**
- **Düzeltme (niyet teyidi sonrası):** Global satırların yazımını `admin`'e kısıtla.
- **Retest:** osgb_admin, global satırı güncelleyememeli (isteniyorsa).

**OWASP-A04-01 · [DOĞRULANMIŞ] `send-reset-email` kimlik doğrulama yapmıyor (e-posta bombardımanı)**
- **Bileşen:** `send-reset-email/index.ts` — her koşulda `{ ok: true }` (kullanıcı enumerasyonu **engelli** ✅).
- **Etki:** Kimliksiz çağrı ile hedef e-postaya **art arda sıfırlama e-postası** tetiklenebilir.
- **Düzeltme:** IP/e-posta başına oran sınırı.
- **Retest:** Aşırı istekte throttle; enumerasyon hâlâ sızmamalı.

**OWASP-A05-02 · [BİLGİ] `build.sourcemap: true`**
- **Bileşen:** `vite.config.ts`.
- **Etki:** Yayınlanırsa **kaynak kod** okunabilir (sır içermez ama saldırgana kolaylık). `vite.config.ts`
  bu ortamda **yazmaya kapalı**; platform/dağıtım ayarı gerekir.
- **Düzeltme:** Yayında `sourcemap:false` (platform build ayarı).

### ⚪ BİLGİLENDİRME

- **A06-02 · [BİLGİ]** `firebase@12.0.0`, `@stripe/react-stripe-js@4.0.2` gibi kullanılmayan/izole
  bağımlılıklar bundle'ı şişiriyor olabilir; kullanımı doğrulanmalı (güvenlik değil, hijyen).
- **A07-03 · [BİLGİ]** MFA/TOTP yok.
- **A07-04 · [BİLGİ]** Kayıt akışı yok → e-posta doğrulama **tasarım gereği** kullanılmıyor
  (hesaplar davetle, `email_confirm: true` ile açılıyor). Self-signup KAPALI olmalı (Dashboard teyidi).
- **A03-03 · [BİLGİ]** `target="_blank"` kullanan 5 noktanın tümünde `rel="noopener noreferrer"`
  mevcut → ters-sekme **kapalı**.

---

## 4) UYGULANAMAYAN / UYGULANMASI ANLAMSIZ TESTLER (açıkça belirtildi)

| Test | Neden uygulanamaz / anlamsız |
|---|---|
| **Klasik CSRF (çerez tabanlı)** | Kimlik **Bearer JWT** (Authorization header) ile; oturum çerezi yok → klasik CSRF **N/A**. CORS wildcard ayrı madde olarak ele alındı. |
| **SQL Injection (istemci)** | Veri erişimi `supabase-js`/PostgREST (parameterized) ve RPC parametreleri ile; istemcide **dinamik SQL string birleştirme yok** → N/A. |
| **SQL Injection (sunucu definer)** | İncelemelerde `SECURITY DEFINER` gövdelerinde **dinamik SQL / string birleştirme görülmedi**; `search_path` sabitlenmiş (GUV-14/15) → risk düşük. |
| **HSTS / `X-Content-Type-Options` / `frame-ancestors`** | Yalnızca **HTTP yanıt başlığı** ile verilir; `<meta>` ile **verilemez** → kod ile N/A (hosting katmanı). |
| **Yıkıcı payload / kesinti testi** | Kural gereği **üretimde YASAK** → uygulanmadı. |
| **`npm audit` / `tsc --noEmit` / `supabase test db`** | Komut yürütücü / izole ortam yok → **BLOCKED**; sonuç uydurulmadı. |
| **Runtime IDOR/RLS/Storage iki-tenant testi** | İzole iki-OSGB ortamı yok; canlıya yazmak yasak → **BLOCKED**. |

---

## 5) DOĞRULANMIŞ POZİTİF KONTROLLER (kanıtlı — PASS)

| # | Kontrol | Kanıt |
|---|---|---|
| P1 | RLS kapsamı | **176/176 tablo açık**, kapalı 0 (canlı) |
| P2 | RESTRICTIVE tenant guard | **9** politika (atamalar/evraklar/firmalar/personeller/teklifler + yazım-deny) |
| P3 | Storage tenant izolasyonu | `storage.objects` politikaları tenant-scoped; 16 bucket'tan yalnız `avatars`+`osgb-logos` public |
| P4 | Tenant kimliği sunucuda | İstemci `osgb_id`/`firma_id`'ye **güvenilmez**; `profiles`'tan `auth.uid()` ile türetilir |
| P5 | Rol yükseltme koruması | `profile_lock_role` trigger `role/osgb_id/firma_id` değişimini bloklar |
| P6 | Edge Function auth deseni | Her kritik fn `auth.getUser(jwt)` → `401`; service-role yalnız doğrulama **sonrası** |
| P7 | XSS | Tüm `dangerouslySetInnerHTML` / `innerHTML` noktaları `sanitizeHtml` (DOMPurify + hook) ile |
| P8 | Açık yönlendirme | OAuth `redirect_uri` yalnız `https` + sabit `/email/oauth/callback` soneki; aksi halde güvenli varsayılana düşer |
| P9 | OAuth CSRF | `mail_oauth_states` + PKCE (`code_challenge S256`) + `state` doğrulaması; callback `user_id` eşleşmesi |
| P10 | E-posta/none enumerasyon | `send-reset-email` her koşulda `{ ok:true }` |
| P11 | Hassas sağlık verisi | `personel_saglik_muayeneleri`/`personel_tetkikler`: `firma`/`uzman` SELECT **kapalı**; `personel_saglik_ozet` yalnız durum+tarih döner |
| P12 | Hata sızıntısı | `errorMessages`/`errorLogger`/`mail.sanitizeError` ham DB/sır metnini maskeler |
| P13 | İBYS dış çağrı | `IBYS_SERVIS_URL` **env secret'tan** (client'tan değil); Basic Auth; başarı yalnız 2xx + hata-işaretsiz |
| P14 | İSG-KATİP | Sabit host `isgkatip.csgb.gov.tr`; extension **yeni** authenticated istek atmadan captured response okur; token taşımaz |

---

## 6) İŞ MANTIĞI / SUNUCU TARAFI DOĞRULAMA DENETİMİ

| Alan | Gözlem | Değerlendirme |
|---|---|---|
| Firma/personel/atama/evrak | Yetki kararları **RLS + Edge Function**'da; frontend filtreleri yalnız UX | ✅ Sunucu tarafı |
| Gereksinim hesaplama | `gereksinim-hesapla` Edge Function (service-role, tenant doğrulamalı) | ✅ Sunucu |
| Teklif yaşam döngüsü | `teklif_public_action` token+süre+geçiş doğrulaması sunucuda; `teklifler` RESTRICTIVE guard | ✅ |
| Mükerrer istek / yarış | `tutanak_no_reservations`, sayaç tabloları (`*_sayaclari`), unique constraint | ⚠️ **Kısmi** — kritik akışlarda yapı var; **idempotency key** standardı tüm toplu işlemlerde teyit edilmeli |
| Mevzuat hesapları | Kanıt olmadan **hata ilan edilmedi** | ➖ İnceleme dışı bırakıldı (kuralca) |
| `firmaDetayPermissions` | Frontend izin eşlemesi — **UI-only**; sunucu RLS ile destekleniyor | ✅ Savunma sunucuda |

**Not:** İş kuralı ihlali iddiası için **izole ortamda uçtan uca senaryo** gerekir (BLOCKED).

---

## 7) BAĞIMLILIK / BUILD / YAPILANDIRMA DENETİMİ

| # | Konu | Kanıt | Risk |
|---|---|---|---|
| D1 | `xlsx@0.18.5` (kullanıcı dosyası parse eder) | `npm` dağıtımında düzeltme yok; CVE-2023-30533 / CVE-2024-22363 | **Orta** |
| D2 | `jspdf@2.5.1` | Çoklu CVE; tarayıcıyı etkileyenler için güncelleme | **Orta** |
| D3 | `build.sourcemap: true` | `vite.config.ts`; dosya yazmaya kapalı | Düşük-Orta |
| D4 | `vite@^8.0.1`, `typescript ~5.8.3` | Sürüm uyumu doğrulanamadı (npm audit BLOCKED) | ⛔ Doğrulanamadı |
| D5 | debug/`console.error` | `errorLogger` prod'da minimal kayıt; `mail` 5xx'te `console.error` | Bilgi |
| D6 | CI/CD sır ifşası | CI yapılandırması depoda **görülmedi** | ⛔ Doğrulanamadı |

---

## 8) ÖNCELİKLİ DÜZELTME PLANI

**P0 — Kısa vade (yüksek etki, düşük risk):**
1. **SMTP SSRF'i kapat** (OWASP-A10-01): host/port allowlist + özel/link-local/loopback bloklama.
   → En yüksek teknik bulgu. İzole ortamda retest.

**P1 — Orta vade:**
2. **Edge CORS allowlist** (GUV-04) — `_shared/cors.ts` + `ALLOWED_ORIGINS`, fonksiyon fonksiyon.
3. **Bağımlılık güncellemesi** — `xlsx`, `jspdf` güncel/sürdürülebilir sürüme; regresyon testi.
4. **Hosting HTTP başlıkları** — HSTS, `X-Content-Type-Options`, `frame-ancestors`, `Referrer-Policy`.
5. **CSP sertleştirme** — `unsafe-eval` kaldırma araştırması; mümkünse nonce/hash.

**P2 — Savunma derinliği:**
6. **anon tablo GRANT daraltma** + yeni politikaları `TO authenticated`.
7. **Şifre değişiminde diğer oturumları iptal** + uygulama seviyesi lockout/CAPTCHA.
8. **`auth-log` / `send-reset-email` oran sınırı.**
9. **IBYS global referans yazımı** niyet teyidi → admin-only.
10. **`sourcemap:false`** (yayın build'inde).

**P3 — Kurumsal:**
11. İzole iki-tenant test ortamı kurup `supabase/tests/security/*` suite'ini gerçek DB'de çalıştır
    (§4'teki tüm BLOCKED maddeleri kapatır). MFA değerlendirmesi.

---

## 9) KAYNAK / KANIT DİZİNİ

- **Kod:** `src/lib/supabase.ts`, `src/lib/sanitizeHtml.ts`, `src/utils/errorLogger.ts`,
  `src/pages/teklif-public/page.tsx`, `index.html`, `vite.config.ts`, `.env`, `.gitignore`.
- **Edge:** `supabase/functions/mail/index.ts`, `ibys-gonderim/index.ts`, `osgb-status/index.ts`,
  `send-reset-email/index.ts`, `isg-katip-sync/index.ts`.
- **Entegrasyon:** `src/lib/isgKatip/endpoints.ts`, `chrome-extension/background/service-worker.ts`.
- **Canlı (salt-okuma):** RLS 176/176, policy/role dağılımı, `storage.objects` politikaları, CVE kayıtları.
- **Önceki raporlar:** bkz §1.

---

## 10) KAPANIŞ BEYANI

- **Kod/DB/bağımlılık DEĞİŞTİRİLMEDİ; üretimde yıkıcı/kesinti testi UYGULANMADI.**
- **Doğrulanmış açık:** OWASP-A10-01 SSRF (kimliği doğrulanmış) en yüksek teknik bulgu; diğerleri
  sertleştirme/bağımlılık. **Kanıtlanmış, uzaktan-kimliksiz kritik açık YOK.**
- **Çalıştırılmayan testler (nm audit, tsc, runtime tenant, git geçmişi) BAŞARILI SAYILMADI.**
- Bu rapor **resmî TSE onaylı sızma testinin yerine GEÇMEZ.**