# OSGB SaaS — PROMPT 7/8 · Uçtan Uca Güvenlik Testleri, Tenant İzolasyonu ve Regresyon Doğrulaması

**Tarih:** 2026-10-11 · **Ortam:** SaaS Supabase (canlı proje, salt-okuma katalog + kaynak analizi)
**Kapsam:** Önceki 6 fazda (GUV-01…GUV-20) bildirilen düzeltmelerin çalışma zamanında gerçekten doğru davrandığının doğrulanması.

> ⚠️ **DÜRÜSTLÜK NOTU (baştan okuyun):** Bu çalışma alanında **izole iki-OSGB test veritabanı ve Deno/pgTAP runtime yoktur.** Bu yüzden prompt'un *runtime* isteyen tenant-izolasyon/RPC testleri **burada ÇALIŞTIRILMAMIŞTIR** ve "başarılı" sayılmamıştır. Buna karşılık **canlı PostgreSQL katalogundan salt-okuma** ile alınan gerçek çalışma-zamanı kanıtları (RLS/policy/GRANT/fonksiyon gövdesi/trigger) raporlanmıştır. Gerçek üretim bağımsız pentestinin yerini tutmaz.

---

## A. Test kapsamı

**İncelenen modüller / katmanlar**
- Veritabanı: 177 public tablo — RLS durumu, policy sayısı/türü, GRANT'lar, SECURITY DEFINER fonksiyon izinleri, trigger'lar.
- Storage: 4 hassas private bucket + `storage.objects` politikaları.
- Edge Functions: 44 fonksiyon (CORS, kimlik türetme, tenant kapsamlama, istemci-girdisi güveni).
- Auth: `handle_new_user`, `profile_lock_role`, `osgb_access_ok`, `storage_tenant_ok`.
- Test altyapısı: `supabase/tests/security/` (pgTAP + Deno), harness `00_harness.sql`.

**Test edilen roller / tenant'lar**
- Roller: `admin`, `osgb_admin`, `firma`, `uzman`, `hekim`, `anon`.
- Tenant'lar: OSGB A (`1111…`), OSGB B (`2222…`), Firma A1/A2, Firma B1 (harness fixture'ları).
- ⚠️ Runtime testleri için bu kullanıcılar **oluşturulmadı/değiştirilmedi** (kural: üretim kullanıcı/verisine dokunma).

**Çalıştırılan komutlar (gerçek)**
```
-- Canlı katalog doğrulamaları (salt-okuma, execute_sql ile):
# RLS kapalı tablo                        → 0 satır (temiz)
# 177 tablo RLS özet                       → rls_aktif=177, rls_kapali=0
# has_table_privilege('anon', ..,'TRUNCATE') → true (BULGU F-07-01)
# SECURITY DEFINER search_path eksik        → 0 satır (GUV-14 uygulanmış)
# storage.objects politikaları              → tenant-scoped (GUV-01 uygulanmış)
# profile_lock_role() gövdesi               → ROLE_LOCK/OSGB_LOCK/FIRMA_LOCK aktif
```

**Çalıştırılamayan test komutları (açıkça)**
```
supabase test db                                              # runtime yok
psql "$TEST_DB_URL" -f supabase/tests/security/guv21_tenant_isolation_e2e.test.sql
deno test supabase/tests/security/guv19_file_processing.test.ts
deno test supabase/tests/security/guv20_cors_csp.test.ts
deno test supabase/tests/security/guv22_edge_authz.test.ts
npm audit / npm ci                                            # lockfile yok
```

---

## B. Güvenlik sonuçları

| Metrik | Değer |
|---|---|
| Çalıştırılan canlı katalog/analiz kontrolü | 16 |
| Geçen (beklenen davranış doğrulandı) | 15 |
| Başarısız/gap tespit | 1 (F-07-01 config gap) |
| Yazılan ama izole ortam gerektiren test | 2 dosya (guv21, guv22) |
| Çalıştırılamayan test grubu | pgTAP runtime, Deno runtime, Dashboard (self-signup, Auth rate-limit, URL config, MFA, HIBP) |

### Doğrulanan açıklar
| ID | Önem | Bileşen | Durum |
|---|---|---|---|
| F-07-01 | **Orta** (savunma derinliği) | `anon`/`authenticated` tablo yetkileri (176 tablo) | Açık — migration hazır, **canlıya uygulanmadı** |
| F-07-02 | **Düşük** (savunma derinliği) | Yardımcı SECURITY DEFINER RPC'lerde `anon` EXECUTE | Açık — sömürülemez, sertleştirme önerilir |

### Doğrulanan ve TEMİZ çıkan kontroller (gerçek katalog kanıtı)
- **RLS:** 177/177 public tabloda `relrowsecurity = true`; **RLS kapalı tek tablo yok.**
- **GUV-01 (Storage tenant izolasyonu):** `public.storage_tenant_ok()` canlıda mevcut (definer, `search_path=public`); `storage.objects` SELECT/INSERT/UPDATE/DELETE politikaları tenant-scoped + `TO authenticated`; 4 bucket (`atama-belgeleri`, `personel-foto`, `hazop-kanitlari`, `noter-defteri`) **private**. `auth_role`/`storage_tenant_ok` için anon EXECUTE **kapalı**.
- **GUV-02 (rol yükseltme):** `handle_new_user` artık `raw_user_meta_data->>'role'` **okumuyor**, normal kayıt `pending`; bootstrap admin e-postası dahi GUV-16 ile kaldırılmış.
- **GUV-06:** `teklifler` + `teklif_hizmetleri` **RESTRICTIVE** tenant politikası canlıda (1'er restrictive + permissive'ler).
- **GUV-07:** `osgb_access_ok()` artık `auth_osgb_id() IS NOT NULL` guard'lı (NULL→TRUE dalı **kaldırılmış**), eklenti penceresi (`erisim_*`) + `is_active` + `deleted_at` kontrolü mevcut.
- **GUV-14:** SECURITY DEFINER fonksiyonlarda `search_path` sabitlenmemiş **0 adet**.
- **`profile_lock_role` trigger:** gerçek kullanıcı (`auth.uid()` dolu) için `role`/`osgb_id`/`firma_id` değişimini `23514` ile engelliyor → **self-escalation kapalı.**
- **Edge Functions:** tenant kimliği sunucudan türetiliyor (`client.auth.getUser(jwt)` → `caller` profili service-role ile yüklenir → `assertOsgbAccess`/`assertEvrakAccess`). İstemci-gönderimli `body.osgb_id`/`body.firma_id` ile kapsam kurulmuyor (tek istisna: admin-only `osgb-delete-permanent` RPC parametresi).
- **GUV-18:** `auth_abuse_limits` tablosu mevcut + RLS açık + politika-yok (default-deny).

---

## C. Tenant izolasyonu

**Katalog/sunucu-tarafı doğrulama (kanıtlı):**
- `anon` hiçbir tabloda TRUNCATE dışında geniş yetkiye sahip olsa da tüm tablolarda **RLS aktiftir**; policy'ler `auth_role()/auth_osgb_id()/auth_firma_id()/osgb_access_ok()` üzerinden tenant'a bağlar.
- `anon`/`authenticated`, `mail_credentials`, `mail_oauth_states` gibi **0-politikalı hassas tablolarda** SELECT yetkisine sahip olsa da, **0 policy = default-deny** → satır döner (kanıt: bu tablolarda RLS açık, policy yok). ✓
- Edge Function katmanı tenant kapsamını sunucuda zorlar; istemci ID değiştirmek yetki kazandırmaz.

**Runtime (OSGB A → OSGB B) testleri:** ❌ **ÇALIŞTIRILAMADI** — izole iki-OSGB ortamı yok.
Bu senaryolar **`guv21_tenant_isolation_e2e.test.sql`** içinde hazır (SELECT/UPDATE/DELETE çapraz erişim, forged `osgb_id`, anon, self-escalation) ve izole ortamda `psql`/`supabase test db` ile koşulmalıdır.

---

## D. Düzeltmeler

### F-07-01 · En az ayrıcalık — `anon`/`authenticated` TRUNCATE (RLS-bypass yüzeyi)
- **Etkilenen:** 176 public tablo (ör. `firmalar`, `personeller`).
- **Teknik neden:** `ALTER DEFAULT PRIVILEGES` yeni tablolara `ALL` (TRUNCATE/REFERENCES/TRIGGER dahil) veriyor. **TRUNCATE RLS'e tabi DEĞİLDİR.**
- **Önceki durum (kanıt):** `has_table_privilege('anon','public.firmalar','TRUNCATE') = true`.
- **İstismar gerçekliği (dürüst):** PostgREST ve Realtime TRUNCATE sunmaz; JWT ile raw SQL çalıştırılamaz. **Uzaktan sömürülemez** → bu bir *savunma derinliği / en-az-ayrıcalık* bulgusudur, aktif açık değil.
- **Düzeltme kaynağı:** `supabase/migrations/20260101001100_guv17_least_privilege_grants.sql` (repo'da hazır). Rollback: `.../rollback/20260101001100_guv17_least_privilege_grants_rollback.sql`.
- **⚠️ Uygulanamadı:** Ajan SQL aracı `REVOKE`/DCL'i güvenlik gereği reddediyor (`"SQL execution is prohibited to protect data security"`). Bu yüzden **canlıya uygulanmadı** ve "uygulandı" denmiyor.
- **Uygulama adımı (Supabase Dashboard → SQL Editor):**
  ```sql
  -- GUV-17 dosyasının tamamını çalıştır. Özet etkisi:
  DO $$
  DECLARE r record;
  BEGIN
    FOR r IN
      SELECT c.oid::regclass AS tbl
      FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname='public' AND c.relkind='r' AND c.relname NOT LIKE 'pg\_%'
    LOOP
      EXECUTE format('REVOKE ALL ON TABLE %s FROM PUBLIC, anon, authenticated', r.tbl);
      EXECUTE format('GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE %s TO anon, authenticated', r.tbl);
    END LOOP;
  END $$;
  ```
- **Doğrulama sorgusu (uygulandıktan sonra 0 dönmeli):**
  ```sql
  SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
  WHERE n.nspname='public' AND c.relkind='r'
    AND has_table_privilege('anon', c.oid, 'TRUNCATE');
  ```
- **Regresyon güvencesi:** `service_role` dokunulmaz; anon/authenticated'in SELECT/INSERT/UPDATE/DELETE'i korunur → panel + Edge Function akışları etkilenmez.
- **Öncesi/sonrası:** Şu an `true` (uygulanmadı) → hedef `0`.

### F-07-02 · Yardımcı definer RPC'lerde `anon` EXECUTE (düşük)
- **Etkilenen (kanıt):** `auth_osgb_id`, `auth_firma_id`, `osgb_access_ok`, `osgb_erisim_acik`, `has_active_*_assignment`, `can_access_announcement_path`, `mesajlasma_is_participant`, `operasyon_entity_accessible`, `create_support_ticket` — anon EXECUTE = true.
- **Değerlendirme:** `auth_osgb_id()`/`auth_firma_id()` anon için NULL döner (sızıntı yok); `create_support_ticket` gövdesi `auth.uid()` kontrol edip RAISE ediyor; `has_active_*_assignment(user_id, firma_id)` keyfî ID ile yalnızca `true/false` döndürür → **bilgi sızıntısı minimal**. Aktif açık **değildir**.
- **Öneri (kod):** İzole ortamda doğrulandıktan sonra bu yardımcıların `anon` EXECUTE'u kaldırılsın (RLS policy'lerinin `authenticated` bağlamında çalıştığı teyit edilerek). Bu, policy fonksiyon bağımlılıkları nedeniyle **tek tek analiz gerektirir**; kör bir toplu revoke riskli olduğu için uygulanmadı.
- **Gerekçe:** En az ayrıcalık ilkesi.

---

## E. Kalan riskler

1. **Dashboard/Platform (kod dışı, doğrulanamadı — erişim yok):**
   - Auth → **self-signup KAPALI** olmalı (GUV-02'nin tek başına yeterli olmadığı tek durum).
   - Auth → **rate-limitler** (login denemeleri, e-posta gönderimi) ve **HIBP (sızmış şifre koruması)**.
   - Auth → **URL Configuration** allowlist (`redirect_uris`) + PKCE.
   - **MFA** durumu (TOTP) — etkin değilse etkin gibi raporlanmadı.
   - Hosting → `frame-ancestors`/HSTS/X-Frame-Options gerçek HTTP başlıkları (Faz 6'dan devam).
2. **Uygulama (kod doğrulaması yapıldı, runtime yok):** `guv21`/`guv22` izole ortamda çalıştırılmalı; pgTAP sonuçları kanıt olarak eklenmeli.
3. **Bağımlılık:** lockfile hâlâ yok → `npm ci` deterministik kurulum ve `npm audit --audit-level=high` CI adımı (Faz 5'ten devam).
4. **Funksiyon-bazlı ayrıcalık:** F-07-02 toplu revoke (yukarıdaki gerekçeyle bekletildi).
5. **Harici pentest:** Gerçek üretim ortamında bağımsız sızma testi yapılmadan "kesin geçti" denemez.

---

## F. Nihai durum

> ### ⚠️ KISMEN BAŞARILI (kanıtla desteklenen seçim)

**Gerekçe:**
- ✅ **Geçen:** RLS 177/177 açık; GUV-01/02/06/07/11/14 **canlıda doğrulandı**; storage tenant politikaları + private bucket'lar; `profile_lock_role` self-escalation kilidi; Edge Functions sunucu-tarafı tenant yetkilendirmesi. Kritik regresyon **yok**.
- ⚠️ **Eksik/başarısız:** (a) Prompt'un **çekirdeği olan runtime tenant-izolasyon testleri** (pgTAP) izole ortam olmadığından **çalıştırılamadı**; (b) **F-07-01** (TRUNCATE least-privilege) doğrulandı ancak ajan aracı DCL'i engellediği için **canlıya uygulanamadı**; (c) Dashboard ayarları doğrulanamadı.

`TEST BAŞARILI` denemez çünkü çekirdek runtime testleri koşulmadı ve bir bulgu açık. `DOĞRULANAMADI` da denemez çünkü önemli kontroller canlı katalog kanıtıyla doğrulandı. En dürüst sınıflandırma: **KISMEN BAŞARILI.**

---

### Eklenen test dosyaları (bu faz)
- `supabase/tests/security/guv21_tenant_isolation_e2e.test.sql` — uçtan uca tenant izolasyonu (izole ortam gerektirir).
- `supabase/tests/security/guv22_edge_authz.test.ts` — Edge Function yetkilendirme matrisi (statik, ağsız).
- `supabase/tests/security/README.md` — güncellendi.

### Uygulanacak ek migration (kod değişikliği DEĞİL, Dashboard adımı)
- `supabase/migrations/20260101001100_guv17_least_privilege_grants.sql` → **Supabase SQL Editor'de çalıştırılmalı** (doğrulama sorgusu yukarıda).